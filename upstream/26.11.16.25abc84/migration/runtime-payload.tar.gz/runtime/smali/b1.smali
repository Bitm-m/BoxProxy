.class public final synthetic Lb1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Landroid/content/Context;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Lb34;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;Lb34;B)V
    .locals 0

    .line 13
    iput-byte p4, p0, Lb1;->i:B

    iput-object p1, p0, Lb1;->j:Landroid/content/Context;

    iput-object p2, p0, Lb1;->k:Ljava/lang/String;

    iput-object p3, p0, Lb1;->l:Lb34;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lb34;Ljava/lang/String;Landroid/content/Context;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lb1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lb1;->l:Lb34;

    .line 4
    .line 5
    iput-object p2, p0, Lb1;->k:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lb1;->j:Landroid/content/Context;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lb34;Landroid/content/Context;B)V
    .locals 0

    .line 14
    iput-byte p4, p0, Lb1;->i:B

    iput-object p1, p0, Lb1;->k:Ljava/lang/String;

    iput-object p2, p0, Lb1;->l:Lb34;

    iput-object p3, p0, Lb1;->j:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lb1;->i:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Loc7;->a:Loc7;

    .line 5
    .line 6
    iget-object v3, p0, Lb1;->j:Landroid/content/Context;

    .line 7
    .line 8
    iget-object v4, p0, Lb1;->k:Ljava/lang/String;

    .line 9
    .line 10
    iget-object p0, p0, Lb1;->l:Lb34;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast p1, Ljava/lang/String;

    .line 16
    .line 17
    if-nez p1, :cond_0

    .line 18
    .line 19
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-interface {p0, p1}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    invoke-static {p1}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-nez p0, :cond_1

    .line 30
    .line 31
    move-object v4, p1

    .line 32
    :cond_1
    invoke-static {v3, v4}, Lhw6;->o(Landroid/content/Context;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :goto_0
    return-object v2

    .line 36
    :pswitch_0
    check-cast p1, Ljava/lang/String;

    .line 37
    .line 38
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 39
    .line 40
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    if-eqz p1, :cond_2

    .line 44
    .line 45
    move-object v4, p1

    .line 46
    :cond_2
    invoke-static {v3, v4}, Lhw6;->o(Landroid/content/Context;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v2

    .line 50
    :pswitch_1
    check-cast p1, Ljava/lang/String;

    .line 51
    .line 52
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 53
    .line 54
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    if-eqz p1, :cond_3

    .line 58
    .line 59
    move-object v4, p1

    .line 60
    :cond_3
    invoke-static {v3, v4}, Lhw6;->o(Landroid/content/Context;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    return-object v2

    .line 64
    :pswitch_2
    check-cast p1, Ljava/lang/String;

    .line 65
    .line 66
    if-nez p1, :cond_4

    .line 67
    .line 68
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 69
    .line 70
    invoke-interface {p0, p1}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_4
    invoke-static {p1}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 75
    .line 76
    .line 77
    move-result p0

    .line 78
    if-nez p0, :cond_5

    .line 79
    .line 80
    move-object v4, p1

    .line 81
    :cond_5
    invoke-static {v3, v4}, Lhw6;->o(Landroid/content/Context;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    :goto_1
    return-object v2

    .line 85
    :pswitch_3
    check-cast p1, Lzr;

    .line 86
    .line 87
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    .line 89
    .line 90
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    check-cast v0, Lzr;

    .line 95
    .line 96
    if-eq p1, v0, :cond_6

    .line 97
    .line 98
    sget-object v0, Lr6;->z:Lr6;

    .line 99
    .line 100
    invoke-virtual {v0, v3, p1}, Lr6;->h(Landroid/content/Context;Lzr;)V

    .line 101
    .line 102
    .line 103
    invoke-interface {p0, p1}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    invoke-static {v3, v4, v1}, Lcom/box/app/vpn/FToast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 111
    .line 112
    .line 113
    :cond_6
    return-object v2

    .line 114
    :pswitch_4
    check-cast p1, Lzr;

    .line 115
    .line 116
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    check-cast v0, Lzr;

    .line 124
    .line 125
    if-eq p1, v0, :cond_7

    .line 126
    .line 127
    sget-object v0, Lr6;->z:Lr6;

    .line 128
    .line 129
    invoke-virtual {v0, v3, p1}, Lr6;->h(Landroid/content/Context;Lzr;)V

    .line 130
    .line 131
    .line 132
    invoke-interface {p0, p1}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    invoke-static {v3, v4, v1}, Lcom/box/app/vpn/FToast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 136
    .line 137
    .line 138
    move-result-object p0

    .line 139
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 140
    .line 141
    .line 142
    :cond_7
    return-object v2

    .line 143
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
