.class Lb73;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field private a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/github/rosemoe/sora/langs/textmate/registry/model/GrammarDefinition;",
            ">;"
        }
    .end annotation

    .annotation runtime Lg86;
        value = "languages"
    .end annotation
.end field


# direct methods
.method public static bridge synthetic a(Lb73;)Ljava/util/List;
    .locals 0

    .line 1
    iget-object p0, p0, Lb73;->a:Ljava/util/List;

    .line 2
    .line 3
    return-object p0
.end method
