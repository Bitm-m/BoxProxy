.class public final synthetic Lb80;
.super Lw92;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic j:B


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V
    .locals 0

    .line 1
    iput-byte p7, p0, Lb80;->j:B

    .line 2
    .line 3
    invoke-direct/range {p0 .. p6}, Lw92;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte v0, p0, Lb80;->j:B

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    const/4 v2, 0x2

    .line 5
    const/16 v3, 0x10

    .line 6
    .line 7
    const/16 v4, 0xa

    .line 8
    .line 9
    const/4 v5, 0x0

    .line 10
    const/16 v6, 0x8

    .line 11
    .line 12
    const/16 v7, 0xd

    .line 13
    .line 14
    const/16 v8, 0x9

    .line 15
    .line 16
    const/4 v9, 0x6

    .line 17
    const/16 v10, 0xe

    .line 18
    .line 19
    const/4 v11, 0x1

    .line 20
    sget-object v12, Loc7;->a:Loc7;

    .line 21
    .line 22
    packed-switch v0, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    check-cast p1, Ljava/lang/Boolean;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p0, Liv;

    .line 34
    .line 35
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    new-instance v0, Lwr;

    .line 39
    .line 40
    invoke-direct {v0, v10, p1}, Lwr;-><init>(BZ)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 44
    .line 45
    .line 46
    return-object v12

    .line 47
    :pswitch_0
    check-cast p1, Lhi4;

    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast p0, Liv;

    .line 55
    .line 56
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    new-instance v0, Lgv;

    .line 60
    .line 61
    invoke-direct {v0, p1, v11}, Lgv;-><init>(Lhi4;B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 65
    .line 66
    .line 67
    return-object v12

    .line 68
    :pswitch_1
    check-cast p1, Ljava/lang/String;

    .line 69
    .line 70
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 74
    .line 75
    check-cast p0, Liv;

    .line 76
    .line 77
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 78
    .line 79
    .line 80
    new-instance v0, Lg;

    .line 81
    .line 82
    invoke-direct {v0, p1, v8}, Lg;-><init>(Ljava/lang/String;B)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 86
    .line 87
    .line 88
    return-object v12

    .line 89
    :pswitch_2
    check-cast p1, Ljava/lang/Boolean;

    .line 90
    .line 91
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 92
    .line 93
    .line 94
    move-result p1

    .line 95
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast p0, Liv;

    .line 98
    .line 99
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 100
    .line 101
    .line 102
    new-instance v0, Lwr;

    .line 103
    .line 104
    invoke-direct {v0, v7, p1}, Lwr;-><init>(BZ)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 108
    .line 109
    .line 110
    return-object v12

    .line 111
    :pswitch_3
    check-cast p1, Lii4;

    .line 112
    .line 113
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 114
    .line 115
    .line 116
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p0, Liv;

    .line 119
    .line 120
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    new-instance v0, Lev;

    .line 124
    .line 125
    invoke-direct {v0, p1, v11}, Lev;-><init>(Lii4;B)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 129
    .line 130
    .line 131
    return-object v12

    .line 132
    :pswitch_4
    check-cast p1, Ljava/lang/String;

    .line 133
    .line 134
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 138
    .line 139
    check-cast p0, Liv;

    .line 140
    .line 141
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    .line 143
    .line 144
    new-instance v0, Lg;

    .line 145
    .line 146
    invoke-direct {v0, p1, v6}, Lg;-><init>(Ljava/lang/String;B)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 150
    .line 151
    .line 152
    return-object v12

    .line 153
    :pswitch_5
    check-cast p1, Ljava/lang/String;

    .line 154
    .line 155
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast p0, Liv;

    .line 161
    .line 162
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 163
    .line 164
    .line 165
    new-instance v0, Lg;

    .line 166
    .line 167
    invoke-direct {v0, p1, v9}, Lg;-><init>(Ljava/lang/String;B)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 171
    .line 172
    .line 173
    return-object v12

    .line 174
    :pswitch_6
    check-cast p1, Ljava/lang/Number;

    .line 175
    .line 176
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 177
    .line 178
    .line 179
    move-result p1

    .line 180
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 181
    .line 182
    check-cast p0, Liv;

    .line 183
    .line 184
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    .line 186
    .line 187
    new-instance v0, Lfv;

    .line 188
    .line 189
    invoke-direct {v0, p1, v11}, Lfv;-><init>(IB)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 193
    .line 194
    .line 195
    return-object v12

    .line 196
    :pswitch_7
    check-cast p1, Lhi4;

    .line 197
    .line 198
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 199
    .line 200
    .line 201
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 202
    .line 203
    check-cast p0, Liv;

    .line 204
    .line 205
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    .line 207
    .line 208
    new-instance v0, Lgv;

    .line 209
    .line 210
    invoke-direct {v0, p1, v5}, Lgv;-><init>(Lhi4;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 214
    .line 215
    .line 216
    return-object v12

    .line 217
    :pswitch_8
    check-cast p1, Ljava/lang/String;

    .line 218
    .line 219
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 220
    .line 221
    .line 222
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast p0, Liv;

    .line 225
    .line 226
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    new-instance v0, Lg;

    .line 230
    .line 231
    invoke-direct {v0, p1, v4}, Lg;-><init>(Ljava/lang/String;B)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 235
    .line 236
    .line 237
    return-object v12

    .line 238
    :pswitch_9
    check-cast p1, Ljava/lang/Boolean;

    .line 239
    .line 240
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 241
    .line 242
    .line 243
    move-result p1

    .line 244
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast p0, Liv;

    .line 247
    .line 248
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 249
    .line 250
    .line 251
    new-instance v0, Lwr;

    .line 252
    .line 253
    invoke-direct {v0, v3, p1}, Lwr;-><init>(BZ)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 257
    .line 258
    .line 259
    return-object v12

    .line 260
    :pswitch_a
    check-cast p1, Lhi4;

    .line 261
    .line 262
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 263
    .line 264
    .line 265
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast p0, Liv;

    .line 268
    .line 269
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    .line 271
    .line 272
    new-instance v0, Lgv;

    .line 273
    .line 274
    invoke-direct {v0, p1, v2}, Lgv;-><init>(Lhi4;B)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 278
    .line 279
    .line 280
    return-object v12

    .line 281
    :pswitch_b
    check-cast p1, Ljava/lang/String;

    .line 282
    .line 283
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 284
    .line 285
    .line 286
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 287
    .line 288
    check-cast p0, Liv;

    .line 289
    .line 290
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 291
    .line 292
    .line 293
    new-instance v0, Lg;

    .line 294
    .line 295
    invoke-direct {v0, p1, v1}, Lg;-><init>(Ljava/lang/String;B)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 299
    .line 300
    .line 301
    return-object v12

    .line 302
    :pswitch_c
    check-cast p1, Ljava/lang/String;

    .line 303
    .line 304
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 305
    .line 306
    .line 307
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast p0, Liv;

    .line 310
    .line 311
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    new-instance v0, Lg;

    .line 315
    .line 316
    invoke-direct {v0, p1, v1}, Lg;-><init>(Ljava/lang/String;B)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 320
    .line 321
    .line 322
    return-object v12

    .line 323
    :pswitch_d
    check-cast p1, Ljava/lang/Boolean;

    .line 324
    .line 325
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 326
    .line 327
    .line 328
    move-result p1

    .line 329
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast p0, Liv;

    .line 332
    .line 333
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 334
    .line 335
    .line 336
    new-instance v0, Lwr;

    .line 337
    .line 338
    invoke-direct {v0, v10, p1}, Lwr;-><init>(BZ)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 342
    .line 343
    .line 344
    return-object v12

    .line 345
    :pswitch_e
    check-cast p1, Lhi4;

    .line 346
    .line 347
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 348
    .line 349
    .line 350
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 351
    .line 352
    check-cast p0, Liv;

    .line 353
    .line 354
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 355
    .line 356
    .line 357
    new-instance v0, Lgv;

    .line 358
    .line 359
    invoke-direct {v0, p1, v11}, Lgv;-><init>(Lhi4;B)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 363
    .line 364
    .line 365
    return-object v12

    .line 366
    :pswitch_f
    check-cast p1, Ljava/lang/String;

    .line 367
    .line 368
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 369
    .line 370
    .line 371
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast p0, Liv;

    .line 374
    .line 375
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 376
    .line 377
    .line 378
    new-instance v0, Lg;

    .line 379
    .line 380
    invoke-direct {v0, p1, v8}, Lg;-><init>(Ljava/lang/String;B)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 384
    .line 385
    .line 386
    return-object v12

    .line 387
    :pswitch_10
    check-cast p1, Ljava/lang/Boolean;

    .line 388
    .line 389
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 394
    .line 395
    check-cast p0, Liv;

    .line 396
    .line 397
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 398
    .line 399
    .line 400
    new-instance v0, Lwr;

    .line 401
    .line 402
    invoke-direct {v0, v7, p1}, Lwr;-><init>(BZ)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 406
    .line 407
    .line 408
    return-object v12

    .line 409
    :pswitch_11
    check-cast p1, Lii4;

    .line 410
    .line 411
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 412
    .line 413
    .line 414
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 415
    .line 416
    check-cast p0, Liv;

    .line 417
    .line 418
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 419
    .line 420
    .line 421
    new-instance v0, Lev;

    .line 422
    .line 423
    invoke-direct {v0, p1, v11}, Lev;-><init>(Lii4;B)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 427
    .line 428
    .line 429
    return-object v12

    .line 430
    :pswitch_12
    check-cast p1, Ljava/lang/String;

    .line 431
    .line 432
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 433
    .line 434
    .line 435
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 436
    .line 437
    check-cast p0, Liv;

    .line 438
    .line 439
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 440
    .line 441
    .line 442
    new-instance v0, Lg;

    .line 443
    .line 444
    invoke-direct {v0, p1, v6}, Lg;-><init>(Ljava/lang/String;B)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 448
    .line 449
    .line 450
    return-object v12

    .line 451
    :pswitch_13
    check-cast p1, Ljava/lang/String;

    .line 452
    .line 453
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 454
    .line 455
    .line 456
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 457
    .line 458
    check-cast p0, Liv;

    .line 459
    .line 460
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 461
    .line 462
    .line 463
    new-instance v0, Lg;

    .line 464
    .line 465
    invoke-direct {v0, p1, v9}, Lg;-><init>(Ljava/lang/String;B)V

    .line 466
    .line 467
    .line 468
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 469
    .line 470
    .line 471
    return-object v12

    .line 472
    :pswitch_14
    check-cast p1, Lhi4;

    .line 473
    .line 474
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 475
    .line 476
    .line 477
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 478
    .line 479
    check-cast p0, Liv;

    .line 480
    .line 481
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 482
    .line 483
    .line 484
    new-instance v0, Lgv;

    .line 485
    .line 486
    invoke-direct {v0, p1, v5}, Lgv;-><init>(Lhi4;B)V

    .line 487
    .line 488
    .line 489
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 490
    .line 491
    .line 492
    return-object v12

    .line 493
    :pswitch_15
    check-cast p1, Ljava/lang/String;

    .line 494
    .line 495
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 496
    .line 497
    .line 498
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 499
    .line 500
    check-cast p0, Liv;

    .line 501
    .line 502
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 503
    .line 504
    .line 505
    new-instance v0, Lg;

    .line 506
    .line 507
    invoke-direct {v0, p1, v4}, Lg;-><init>(Ljava/lang/String;B)V

    .line 508
    .line 509
    .line 510
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 511
    .line 512
    .line 513
    return-object v12

    .line 514
    :pswitch_16
    check-cast p1, Ljava/lang/Boolean;

    .line 515
    .line 516
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 517
    .line 518
    .line 519
    move-result p1

    .line 520
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 521
    .line 522
    check-cast p0, Liv;

    .line 523
    .line 524
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 525
    .line 526
    .line 527
    new-instance v0, Lwr;

    .line 528
    .line 529
    invoke-direct {v0, v3, p1}, Lwr;-><init>(BZ)V

    .line 530
    .line 531
    .line 532
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 533
    .line 534
    .line 535
    return-object v12

    .line 536
    :pswitch_17
    check-cast p1, Lhi4;

    .line 537
    .line 538
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 539
    .line 540
    .line 541
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 542
    .line 543
    check-cast p0, Liv;

    .line 544
    .line 545
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 546
    .line 547
    .line 548
    new-instance v0, Lgv;

    .line 549
    .line 550
    invoke-direct {v0, p1, v2}, Lgv;-><init>(Lhi4;B)V

    .line 551
    .line 552
    .line 553
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 554
    .line 555
    .line 556
    return-object v12

    .line 557
    :pswitch_18
    check-cast p1, Ljava/lang/Number;

    .line 558
    .line 559
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 560
    .line 561
    .line 562
    move-result p1

    .line 563
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 564
    .line 565
    check-cast p0, Liv;

    .line 566
    .line 567
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 568
    .line 569
    .line 570
    new-instance v0, Lfv;

    .line 571
    .line 572
    invoke-direct {v0, p1, v11}, Lfv;-><init>(IB)V

    .line 573
    .line 574
    .line 575
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 576
    .line 577
    .line 578
    return-object v12

    .line 579
    :pswitch_19
    check-cast p1, Lu90;

    .line 580
    .line 581
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 582
    .line 583
    .line 584
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 585
    .line 586
    check-cast p0, Ls70;

    .line 587
    .line 588
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 589
    .line 590
    .line 591
    iget-object p0, p0, Ls70;->c:Lm84;

    .line 592
    .line 593
    invoke-virtual {p0}, Lm84;->a()V

    .line 594
    .line 595
    .line 596
    invoke-virtual {p0, p1}, Lm84;->b(Lu90;)V

    .line 597
    .line 598
    .line 599
    return-object v12

    .line 600
    :pswitch_1a
    check-cast p1, Lao2;

    .line 601
    .line 602
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 603
    .line 604
    .line 605
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 606
    .line 607
    check-cast p0, Liv;

    .line 608
    .line 609
    invoke-virtual {p0, p1}, Liv;->b(Lao2;)V

    .line 610
    .line 611
    .line 612
    return-object v12

    .line 613
    :pswitch_1b
    check-cast p1, Ljava/lang/Boolean;

    .line 614
    .line 615
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 616
    .line 617
    .line 618
    move-result p1

    .line 619
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 620
    .line 621
    check-cast p0, Liv;

    .line 622
    .line 623
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 624
    .line 625
    .line 626
    new-instance v0, Lwr;

    .line 627
    .line 628
    invoke-direct {v0, v9, p1}, Lwr;-><init>(BZ)V

    .line 629
    .line 630
    .line 631
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 632
    .line 633
    .line 634
    return-object v12

    .line 635
    :pswitch_1c
    check-cast p1, Lz17;

    .line 636
    .line 637
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 638
    .line 639
    .line 640
    iget-object p0, p0, Loi0;->receiver:Ljava/lang/Object;

    .line 641
    .line 642
    check-cast p0, Liv;

    .line 643
    .line 644
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 645
    .line 646
    .line 647
    new-instance v0, Lu2;

    .line 648
    .line 649
    invoke-direct {v0, p1, v10}, Lu2;-><init>(Ljava/lang/Object;B)V

    .line 650
    .line 651
    .line 652
    invoke-virtual {p0, v0}, Liv;->c(Lh92;)V

    .line 653
    .line 654
    .line 655
    return-object v12

    .line 656
    nop

    .line 657
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
