.class public final synthetic Laq6;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lmz3;

.field public final synthetic j:J

.field public final synthetic k:F

.field public final synthetic l:Lyz0;


# direct methods
.method public synthetic constructor <init>(Lmz3;JFLyz0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laq6;->i:Lmz3;

    .line 5
    .line 6
    iput-wide p2, p0, Laq6;->j:J

    .line 7
    .line 8
    iput p4, p0, Laq6;->k:F

    .line 9
    .line 10
    iput-object p5, p0, Laq6;->l:Lyz0;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    sget-object v0, Lu60;->a0:Lor2;

    .line 2
    .line 3
    check-cast p1, Lla2;

    .line 4
    .line 5
    check-cast p2, Ljava/lang/Integer;

    .line 6
    .line 7
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    and-int/lit8 v1, p2, 0x3

    .line 12
    .line 13
    const/4 v2, 0x2

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x1

    .line 16
    if-eq v1, v2, :cond_0

    .line 17
    .line 18
    move v1, v4

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    move v1, v3

    .line 21
    :goto_0
    and-int/2addr p2, v4

    .line 22
    invoke-virtual {p1, p2, v1}, Lla2;->S(IZ)Z

    .line 23
    .line 24
    .line 25
    move-result p2

    .line 26
    if-eqz p2, :cond_3

    .line 27
    .line 28
    invoke-virtual {p1}, Lla2;->N()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p2

    .line 32
    sget-object v1, Ld21;->a:Lq9;

    .line 33
    .line 34
    if-ne p2, v1, :cond_1

    .line 35
    .line 36
    new-instance p2, Lq66;

    .line 37
    .line 38
    const/16 v1, 0x17

    .line 39
    .line 40
    invoke-direct {p2, v1}, Lq66;-><init>(B)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p1, p2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    check-cast p2, Lh92;

    .line 47
    .line 48
    iget-object v1, p0, Laq6;->i:Lmz3;

    .line 49
    .line 50
    invoke-static {v1, v3, p2}, Ly66;->a(Lmz3;ZLh92;)Lmz3;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    iget-wide v1, p0, Laq6;->j:J

    .line 55
    .line 56
    iget v5, p0, Laq6;->k:F

    .line 57
    .line 58
    invoke-static {p2, v0, v1, v2, v5}, Lcb3;->K(Lmz3;Lw96;JF)Lmz3;

    .line 59
    .line 60
    .line 61
    move-result-object p2

    .line 62
    sget-object v0, Lr6;->k:Ln20;

    .line 63
    .line 64
    invoke-static {v0, v4}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    iget-wide v1, p1, Lla2;->T:J

    .line 69
    .line 70
    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    .line 71
    .line 72
    .line 73
    move-result v1

    .line 74
    invoke-virtual {p1}, Lla2;->m()Lky4;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    invoke-static {p1, p2}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 79
    .line 80
    .line 81
    move-result-object p2

    .line 82
    sget-object v5, Lv11;->d:Lr6;

    .line 83
    .line 84
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    invoke-virtual {p1}, Lla2;->e0()V

    .line 88
    .line 89
    .line 90
    iget-boolean v5, p1, Lla2;->S:Z

    .line 91
    .line 92
    if-eqz v5, :cond_2

    .line 93
    .line 94
    sget-object v5, Lq83;->a0:Lif2;

    .line 95
    .line 96
    invoke-virtual {p1, v5}, Lla2;->l(Lw82;)V

    .line 97
    .line 98
    .line 99
    goto :goto_1

    .line 100
    :cond_2
    invoke-virtual {p1}, Lla2;->n0()V

    .line 101
    .line 102
    .line 103
    :goto_1
    sget-object v5, Lr6;->S:La11;

    .line 104
    .line 105
    invoke-static {v5, p1, v0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    sget-object v0, Lr6;->R:La11;

    .line 109
    .line 110
    invoke-static {v0, p1, v2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    sget-object v1, Lr6;->T:La11;

    .line 118
    .line 119
    invoke-static {v1, p1, v0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-static {p1}, Lxt6;->k(Lla2;)V

    .line 123
    .line 124
    .line 125
    sget-object v0, Lr6;->Q:La11;

    .line 126
    .line 127
    invoke-static {v0, p1, p2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    iget-object p0, p0, Laq6;->l:Lyz0;

    .line 131
    .line 132
    invoke-static {v3, p0, p1, v4}, Lly1;->v(ILyz0;Lla2;Z)V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_3
    invoke-virtual {p1}, Lla2;->V()V

    .line 137
    .line 138
    .line 139
    :goto_2
    sget-object p0, Loc7;->a:Loc7;

    .line 140
    .line 141
    return-object p0
.end method
