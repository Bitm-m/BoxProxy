.class public final Lah7;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lin1;


# instance fields
.field public volatile i:Lpj1;


# virtual methods
.method public final b()Loj1;
    .locals 0

    .line 1
    iget-object p0, p0, Lah7;->i:Lpj1;

    .line 2
    .line 3
    return-object p0
.end method
