.class public final La76;
.super Llz3;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lz66;


# instance fields
.field public final synthetic w:Lh92;


# direct methods
.method public constructor <init>(Lh92;)V
    .locals 0

    .line 1
    iput-object p1, p0, La76;->w:Lh92;

    .line 2
    .line 3
    invoke-direct {p0}, Llz3;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final R0(Li76;)V
    .locals 0

    .line 1
    iget-object p0, p0, La76;->w:Lh92;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
