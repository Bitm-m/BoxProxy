.class public final Lav4;
.super Lda1;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public i:I

.field public j:Lnj6;

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lcv4;

.field public m:I


# direct methods
.method public constructor <init>(Lcv4;Lca1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lav4;->l:Lcv4;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lda1;-><init>(Lca1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iput-object p1, p0, Lav4;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lav4;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lav4;->m:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 v0, 0x0

    .line 12
    iget-object v1, p0, Lav4;->l:Lcv4;

    .line 13
    .line 14
    invoke-virtual {v1, p1, v0, p0}, Lcv4;->f(ILnj6;Lca1;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method
