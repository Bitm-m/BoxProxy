.class public abstract La67;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lbt4;

.field public static final b:F

.field public static final c:F

.field public static final d:F


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lbt4;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, v1, v1, v1}, Lbt4;-><init>(FFFF)V

    .line 5
    .line 6
    .line 7
    sput-object v0, La67;->a:Lbt4;

    .line 8
    .line 9
    const/high16 v0, 0x42800000    # 64.0f

    .line 10
    .line 11
    sput v0, La67;->b:F

    .line 12
    .line 13
    sput v0, La67;->c:F

    .line 14
    .line 15
    const/high16 v0, 0x42f00000    # 120.0f

    .line 16
    .line 17
    sput v0, La67;->d:F

    .line 18
    .line 19
    return-void
.end method

.method public static a(Ln67;Lla2;)Lk02;
    .locals 6

    .line 1
    invoke-virtual {p1}, Lla2;->N()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Ld21;->a:Lq9;

    .line 6
    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    new-instance v0, Ly21;

    .line 10
    .line 11
    const/16 v2, 0x16

    .line 12
    .line 13
    invoke-direct {v0, v2}, Ly21;-><init>(B)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, v0}, Lla2;->k0(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    check-cast v0, Lw82;

    .line 20
    .line 21
    const/4 v2, 0x3

    .line 22
    invoke-static {v2, p1}, Lta3;->J(ILla2;)Lg22;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-static {p1}, Ljj6;->a(Lla2;)Lfh1;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    invoke-virtual {p1, p0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    invoke-virtual {p1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    or-int/2addr v4, v5

    .line 39
    invoke-virtual {p1, v2}, Lla2;->g(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    or-int/2addr v4, v5

    .line 44
    invoke-virtual {p1, v3}, Lla2;->g(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v5

    .line 48
    or-int/2addr v4, v5

    .line 49
    invoke-virtual {p1}, Lla2;->N()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    if-nez v4, :cond_1

    .line 54
    .line 55
    if-ne v5, v1, :cond_2

    .line 56
    .line 57
    :cond_1
    new-instance v5, Lk02;

    .line 58
    .line 59
    invoke-direct {v5, p0, v2, v3, v0}, Lk02;-><init>(Ln67;Lg22;Lfh1;Lw82;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1, v5}, Lla2;->k0(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_2
    check-cast v5, Lk02;

    .line 66
    .line 67
    return-object v5
.end method

.method public static b(Luv0;)Lz57;
    .locals 14

    .line 1
    iget-object v0, p0, Luv0;->c0:Lz57;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Lz57;

    .line 6
    .line 7
    const/16 v0, 0x22

    .line 8
    .line 9
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 10
    .line 11
    .line 12
    move-result-wide v2

    .line 13
    const/16 v0, 0x24

    .line 14
    .line 15
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 16
    .line 17
    .line 18
    move-result-wide v4

    .line 19
    const/16 v0, 0x11

    .line 20
    .line 21
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 22
    .line 23
    .line 24
    move-result-wide v6

    .line 25
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 26
    .line 27
    .line 28
    move-result-wide v8

    .line 29
    const/16 v0, 0x12

    .line 30
    .line 31
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 32
    .line 33
    .line 34
    move-result-wide v10

    .line 35
    invoke-static {p0, v0}, Lvv0;->d(Luv0;I)J

    .line 36
    .line 37
    .line 38
    move-result-wide v12

    .line 39
    invoke-direct/range {v1 .. v13}, Lz57;-><init>(JJJJJJ)V

    .line 40
    .line 41
    .line 42
    iput-object v1, p0, Luv0;->c0:Lz57;

    .line 43
    .line 44
    return-object v1

    .line 45
    :cond_0
    return-object v0
.end method

.method public static c(JJJJJLla2;)Lz57;
    .locals 20

    .line 1
    sget-wide v0, Lov0;->h:J

    .line 2
    .line 3
    sget-object v2, Lbq3;->b:Lps1;

    .line 4
    .line 5
    move-object/from16 v3, p10

    .line 6
    .line 7
    invoke-virtual {v3, v2}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    check-cast v2, Lyp3;

    .line 12
    .line 13
    iget-object v2, v2, Lyp3;->a:Luv0;

    .line 14
    .line 15
    invoke-static {v2}, La67;->b(Luv0;)Lz57;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const-wide/16 v3, 0x10

    .line 20
    .line 21
    cmp-long v5, p0, v3

    .line 22
    .line 23
    if-eqz v5, :cond_0

    .line 24
    .line 25
    move-wide/from16 v8, p0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    iget-wide v5, v2, Lz57;->a:J

    .line 29
    .line 30
    move-wide v8, v5

    .line 31
    :goto_0
    cmp-long v5, p2, v3

    .line 32
    .line 33
    if-eqz v5, :cond_1

    .line 34
    .line 35
    move-wide/from16 v10, p2

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    iget-wide v5, v2, Lz57;->b:J

    .line 39
    .line 40
    move-wide v10, v5

    .line 41
    :goto_1
    cmp-long v5, p4, v3

    .line 42
    .line 43
    if-eqz v5, :cond_2

    .line 44
    .line 45
    move-wide/from16 v12, p4

    .line 46
    .line 47
    goto :goto_2

    .line 48
    :cond_2
    iget-wide v5, v2, Lz57;->c:J

    .line 49
    .line 50
    move-wide v12, v5

    .line 51
    :goto_2
    cmp-long v5, p6, v3

    .line 52
    .line 53
    if-eqz v5, :cond_3

    .line 54
    .line 55
    move-wide/from16 v14, p6

    .line 56
    .line 57
    goto :goto_3

    .line 58
    :cond_3
    iget-wide v5, v2, Lz57;->d:J

    .line 59
    .line 60
    move-wide v14, v5

    .line 61
    :goto_3
    cmp-long v5, p8, v3

    .line 62
    .line 63
    if-eqz v5, :cond_4

    .line 64
    .line 65
    move-wide/from16 v16, p8

    .line 66
    .line 67
    goto :goto_4

    .line 68
    :cond_4
    iget-wide v5, v2, Lz57;->e:J

    .line 69
    .line 70
    move-wide/from16 v16, v5

    .line 71
    .line 72
    :goto_4
    cmp-long v3, v0, v3

    .line 73
    .line 74
    if-eqz v3, :cond_5

    .line 75
    .line 76
    :goto_5
    move-wide/from16 v18, v0

    .line 77
    .line 78
    goto :goto_6

    .line 79
    :cond_5
    iget-wide v0, v2, Lz57;->f:J

    .line 80
    .line 81
    goto :goto_5

    .line 82
    :goto_6
    new-instance v7, Lz57;

    .line 83
    .line 84
    invoke-direct/range {v7 .. v19}, Lz57;-><init>(JJJJJJ)V

    .line 85
    .line 86
    .line 87
    return-object v7
.end method
