.class public final Las3;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field public final synthetic i:Lbs3;


# direct methods
.method public constructor <init>(Lbs3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Las3;->i:Lbs3;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onDismiss()V
    .locals 0

    .line 1
    iget-object p0, p0, Las3;->i:Lbs3;

    .line 2
    .line 3
    invoke-virtual {p0}, Lbs3;->c()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
