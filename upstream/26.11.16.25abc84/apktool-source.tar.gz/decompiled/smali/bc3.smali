.class public final Lbc3;
.super Llz3;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lz66;


# instance fields
.field public A:Lg26;

.field public final B:Lzb3;

.field public C:Lzb3;

.field public w:Lx53;

.field public x:Lvb3;

.field public y:Lio4;

.field public z:Z


# direct methods
.method public constructor <init>(Lx53;Lvb3;Lio4;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Llz3;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbc3;->w:Lx53;

    .line 5
    .line 6
    iput-object p2, p0, Lbc3;->x:Lvb3;

    .line 7
    .line 8
    iput-object p3, p0, Lbc3;->y:Lio4;

    .line 9
    .line 10
    iput-boolean p4, p0, Lbc3;->z:Z

    .line 11
    .line 12
    new-instance p1, Lzb3;

    .line 13
    .line 14
    const/4 p2, 0x0

    .line 15
    invoke-direct {p1, p0, p2}, Lzb3;-><init>(Lbc3;B)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Lbc3;->B:Lzb3;

    .line 19
    .line 20
    invoke-virtual {p0}, Lbc3;->G1()V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final G1()V
    .locals 4

    .line 1
    new-instance v0, Lg26;

    .line 2
    .line 3
    new-instance v1, Lac3;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, p0, v2}, Lac3;-><init>(Lbc3;B)V

    .line 7
    .line 8
    .line 9
    new-instance v2, Lac3;

    .line 10
    .line 11
    const/4 v3, 0x1

    .line 12
    invoke-direct {v2, p0, v3}, Lac3;-><init>(Lbc3;B)V

    .line 13
    .line 14
    .line 15
    invoke-direct {v0, v1, v2}, Lg26;-><init>(Lw82;Lw82;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lbc3;->A:Lg26;

    .line 19
    .line 20
    iget-boolean v0, p0, Lbc3;->z:Z

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    new-instance v0, Lzb3;

    .line 25
    .line 26
    const/4 v1, 0x1

    .line 27
    invoke-direct {v0, p0, v1}, Lzb3;-><init>(Lbc3;B)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/4 v0, 0x0

    .line 32
    :goto_0
    iput-object v0, p0, Lbc3;->C:Lzb3;

    .line 33
    .line 34
    return-void
.end method

.method public final R0(Li76;)V
    .locals 7

    .line 1
    invoke-static {p1}, Lg76;->p(Li76;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lbc3;->B:Lzb3;

    .line 5
    .line 6
    sget-object v1, Lf76;->P:Lh76;

    .line 7
    .line 8
    invoke-interface {p1, v1, v0}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lbc3;->y:Lio4;

    .line 12
    .line 13
    iget-object v1, p0, Lbc3;->A:Lg26;

    .line 14
    .line 15
    const/16 v2, 0xd

    .line 16
    .line 17
    const-string v3, "scrollAxisRange"

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    sget-object v5, Lio4;->i:Lio4;

    .line 21
    .line 22
    if-ne v0, v5, :cond_1

    .line 23
    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    sget-object v0, Lf76;->w:Lh76;

    .line 27
    .line 28
    sget-object v3, Lg76;->a:[Ly53;

    .line 29
    .line 30
    aget-object v5, v3, v2

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    invoke-interface {p1, v0, v1}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    invoke-static {v3}, Lf13;->V(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v4

    .line 43
    :cond_1
    if-eqz v1, :cond_3

    .line 44
    .line 45
    sget-object v0, Lf76;->v:Lh76;

    .line 46
    .line 47
    sget-object v3, Lg76;->a:[Ly53;

    .line 48
    .line 49
    const/16 v5, 0xc

    .line 50
    .line 51
    aget-object v5, v3, v5

    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    invoke-interface {p1, v0, v1}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :goto_0
    iget-object v0, p0, Lbc3;->C:Lzb3;

    .line 60
    .line 61
    if-eqz v0, :cond_2

    .line 62
    .line 63
    sget-object v1, Lv66;->f:Lh76;

    .line 64
    .line 65
    new-instance v5, Lp4;

    .line 66
    .line 67
    invoke-direct {v5, v4, v0}, Lp4;-><init>(Ljava/lang/String;Lt92;)V

    .line 68
    .line 69
    .line 70
    invoke-interface {p1, v1, v5}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    :cond_2
    new-instance v0, Lac3;

    .line 74
    .line 75
    const/4 v1, 0x2

    .line 76
    invoke-direct {v0, p0, v1}, Lac3;-><init>(Lbc3;B)V

    .line 77
    .line 78
    .line 79
    sget-object v1, Lv66;->C:Lh76;

    .line 80
    .line 81
    new-instance v5, Lp4;

    .line 82
    .line 83
    new-instance v6, Lvf5;

    .line 84
    .line 85
    invoke-direct {v6, v0, v2}, Lvf5;-><init>(Ljava/lang/Object;B)V

    .line 86
    .line 87
    .line 88
    invoke-direct {v5, v4, v6}, Lp4;-><init>(Ljava/lang/String;Lt92;)V

    .line 89
    .line 90
    .line 91
    invoke-interface {p1, v1, v5}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    iget-object p0, p0, Lbc3;->x:Lvb3;

    .line 95
    .line 96
    invoke-interface {p0}, Lvb3;->c()Lbv0;

    .line 97
    .line 98
    .line 99
    move-result-object p0

    .line 100
    sget-object v0, Lf76;->f:Lh76;

    .line 101
    .line 102
    const/16 v1, 0x18

    .line 103
    .line 104
    aget-object v1, v3, v1

    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    invoke-interface {p1, v0, p0}, Li76;->a(Lh76;Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    return-void

    .line 113
    :cond_3
    invoke-static {v3}, Lf13;->V(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    throw v4
.end method

.method public final v1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
