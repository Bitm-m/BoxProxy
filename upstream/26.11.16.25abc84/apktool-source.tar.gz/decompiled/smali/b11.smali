.class public final Lb11;
.super Lu4;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public c:Lw82;


# virtual methods
.method public final p()V
    .locals 0

    .line 1
    iget-object p0, p0, Lb11;->c:Lw82;

    .line 2
    .line 3
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
