.class public final synthetic Lal;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lak;

.field public final synthetic k:Lpp0;

.field public final synthetic l:Lh92;


# direct methods
.method public synthetic constructor <init>(BLak;Lpp0;Lh92;)V
    .locals 0

    .line 14
    iput-byte p1, p0, Lal;->i:B

    iput-object p2, p0, Lal;->j:Lak;

    iput-object p3, p0, Lal;->k:Lpp0;

    iput-object p4, p0, Lal;->l:Lh92;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lpp0;Lak;Lh92;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lal;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lal;->k:Lpp0;

    .line 8
    .line 9
    iput-object p2, p0, Lal;->j:Lak;

    .line 10
    .line 11
    iput-object p3, p0, Lal;->l:Lh92;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lal;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    iget-object v4, v0, Lal;->l:Lh92;

    .line 9
    .line 10
    iget-object v5, v0, Lal;->j:Lak;

    .line 11
    .line 12
    iget-object v0, v0, Lal;->k:Lpp0;

    .line 13
    .line 14
    const/4 v7, 0x1

    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v15, p1

    .line 19
    .line 20
    check-cast v15, Lla2;

    .line 21
    .line 22
    move-object/from16 v1, p2

    .line 23
    .line 24
    check-cast v1, Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    and-int/lit8 v8, v1, 0x3

    .line 31
    .line 32
    if-eq v8, v3, :cond_0

    .line 33
    .line 34
    move v3, v7

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    const/4 v3, 0x0

    .line 37
    :goto_0
    and-int/2addr v1, v7

    .line 38
    invoke-virtual {v15, v1, v3}, Lla2;->S(IZ)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_7

    .line 43
    .line 44
    const v1, 0x7f0f0182

    .line 45
    .line 46
    .line 47
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v8

    .line 51
    invoke-static {v0, v15}, Lhn;->r(Lpp0;Lla2;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v9

    .line 55
    iget-boolean v1, v0, Lpp0;->b:Z

    .line 56
    .line 57
    if-eqz v1, :cond_1

    .line 58
    .line 59
    invoke-virtual {v0}, Lpp0;->b()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    invoke-static {v3}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    if-nez v3, :cond_1

    .line 68
    .line 69
    move v10, v7

    .line 70
    goto :goto_1

    .line 71
    :cond_1
    const/4 v10, 0x0

    .line 72
    :goto_1
    iget-boolean v11, v5, Lak;->g:Z

    .line 73
    .line 74
    invoke-virtual {v15, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v3

    .line 78
    invoke-virtual {v15, v5}, Lla2;->i(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v12

    .line 82
    or-int/2addr v3, v12

    .line 83
    invoke-virtual {v15}, Lla2;->N()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v12

    .line 87
    sget-object v13, Ld21;->a:Lq9;

    .line 88
    .line 89
    if-nez v3, :cond_2

    .line 90
    .line 91
    if-ne v12, v13, :cond_3

    .line 92
    .line 93
    :cond_2
    new-instance v12, Lkk;

    .line 94
    .line 95
    const/16 v3, 0x11

    .line 96
    .line 97
    invoke-direct {v12, v3, v5, v4}, Lkk;-><init>(BLak;Lh92;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v15, v12}, Lla2;->k0(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    :cond_3
    check-cast v12, Lh92;

    .line 104
    .line 105
    sget-object v3, Lbx0;->a:Lps1;

    .line 106
    .line 107
    invoke-virtual {v15, v3}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v14

    .line 111
    check-cast v14, Lax0;

    .line 112
    .line 113
    invoke-virtual {v14}, Lax0;->i()J

    .line 114
    .line 115
    .line 116
    move-result-wide v16

    .line 117
    move-wide/from16 v19, v16

    .line 118
    .line 119
    move-object/from16 v17, v13

    .line 120
    .line 121
    move-wide/from16 v13, v19

    .line 122
    .line 123
    const/16 v16, 0x0

    .line 124
    .line 125
    move-object/from16 v6, v17

    .line 126
    .line 127
    invoke-static/range {v8 .. v16}, Lx60;->h(Ljava/lang/String;Ljava/lang/String;ZZLh92;JLla2;I)V

    .line 128
    .line 129
    .line 130
    const v8, 0x7f0f018b

    .line 131
    .line 132
    .line 133
    invoke-static {v8, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v8

    .line 137
    invoke-static {v0, v15}, Lhn;->s(Lpp0;Lla2;)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v9

    .line 141
    if-eqz v1, :cond_4

    .line 142
    .line 143
    iget-object v0, v0, Lpp0;->f:Ljava/lang/String;

    .line 144
    .line 145
    if-eqz v0, :cond_4

    .line 146
    .line 147
    invoke-static {v0}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-nez v0, :cond_4

    .line 152
    .line 153
    move v10, v7

    .line 154
    goto :goto_2

    .line 155
    :cond_4
    const/4 v10, 0x0

    .line 156
    :goto_2
    iget-boolean v11, v5, Lak;->h:Z

    .line 157
    .line 158
    invoke-virtual {v15, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    invoke-virtual {v15, v5}, Lla2;->i(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    or-int/2addr v0, v1

    .line 167
    invoke-virtual {v15}, Lla2;->N()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    if-nez v0, :cond_5

    .line 172
    .line 173
    if-ne v1, v6, :cond_6

    .line 174
    .line 175
    :cond_5
    new-instance v1, Lkk;

    .line 176
    .line 177
    const/16 v0, 0xa

    .line 178
    .line 179
    invoke-direct {v1, v0, v5, v4}, Lkk;-><init>(BLak;Lh92;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v15, v1}, Lla2;->k0(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    :cond_6
    move-object v12, v1

    .line 186
    check-cast v12, Lh92;

    .line 187
    .line 188
    invoke-virtual {v15, v3}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    check-cast v0, Lax0;

    .line 193
    .line 194
    invoke-virtual {v0}, Lax0;->i()J

    .line 195
    .line 196
    .line 197
    move-result-wide v13

    .line 198
    const/16 v16, 0x0

    .line 199
    .line 200
    invoke-static/range {v8 .. v16}, Lx60;->h(Ljava/lang/String;Ljava/lang/String;ZZLh92;JLla2;I)V

    .line 201
    .line 202
    .line 203
    goto :goto_3

    .line 204
    :cond_7
    invoke-virtual {v15}, Lla2;->V()V

    .line 205
    .line 206
    .line 207
    :goto_3
    return-object v2

    .line 208
    :pswitch_0
    move-object/from16 v9, p1

    .line 209
    .line 210
    check-cast v9, Lla2;

    .line 211
    .line 212
    move-object/from16 v1, p2

    .line 213
    .line 214
    check-cast v1, Ljava/lang/Integer;

    .line 215
    .line 216
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    and-int/lit8 v6, v1, 0x3

    .line 221
    .line 222
    if-eq v6, v3, :cond_8

    .line 223
    .line 224
    move v6, v7

    .line 225
    goto :goto_4

    .line 226
    :cond_8
    const/4 v6, 0x0

    .line 227
    :goto_4
    and-int/2addr v1, v7

    .line 228
    invoke-virtual {v9, v1, v6}, Lla2;->S(IZ)Z

    .line 229
    .line 230
    .line 231
    move-result v1

    .line 232
    if-eqz v1, :cond_9

    .line 233
    .line 234
    iget-boolean v1, v5, Lak;->d:Z

    .line 235
    .line 236
    xor-int/lit8 v3, v1, 0x1

    .line 237
    .line 238
    new-instance v1, Lel;

    .line 239
    .line 240
    invoke-direct {v1, v7, v5, v0, v4}, Lel;-><init>(BLak;Lpp0;Lh92;)V

    .line 241
    .line 242
    .line 243
    const v0, 0x2925b90b

    .line 244
    .line 245
    .line 246
    invoke-static {v0, v1, v9}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 247
    .line 248
    .line 249
    move-result-object v8

    .line 250
    const/high16 v10, 0x30000

    .line 251
    .line 252
    const/16 v11, 0x1e

    .line 253
    .line 254
    const/4 v4, 0x0

    .line 255
    const/4 v5, 0x0

    .line 256
    const/4 v6, 0x0

    .line 257
    const/4 v7, 0x0

    .line 258
    invoke-static/range {v3 .. v11}, Lnn3;->O(ZLmz3;Lmy1;Lf02;Ljava/lang/String;Lyz0;Lla2;II)V

    .line 259
    .line 260
    .line 261
    goto :goto_5

    .line 262
    :cond_9
    invoke-virtual {v9}, Lla2;->V()V

    .line 263
    .line 264
    .line 265
    :goto_5
    return-object v2

    .line 266
    :pswitch_1
    move-object/from16 v1, p1

    .line 267
    .line 268
    check-cast v1, Lla2;

    .line 269
    .line 270
    move-object/from16 v6, p2

    .line 271
    .line 272
    check-cast v6, Ljava/lang/Integer;

    .line 273
    .line 274
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 275
    .line 276
    .line 277
    move-result v6

    .line 278
    and-int/lit8 v8, v6, 0x3

    .line 279
    .line 280
    if-eq v8, v3, :cond_a

    .line 281
    .line 282
    move v3, v7

    .line 283
    goto :goto_6

    .line 284
    :cond_a
    const/4 v3, 0x0

    .line 285
    :goto_6
    and-int/2addr v6, v7

    .line 286
    invoke-virtual {v1, v6, v3}, Lla2;->S(IZ)Z

    .line 287
    .line 288
    .line 289
    move-result v3

    .line 290
    if-eqz v3, :cond_b

    .line 291
    .line 292
    iget-boolean v3, v5, Lak;->d:Z

    .line 293
    .line 294
    xor-int/lit8 v10, v3, 0x1

    .line 295
    .line 296
    new-instance v3, Lel;

    .line 297
    .line 298
    const/4 v6, 0x0

    .line 299
    invoke-direct {v3, v6, v5, v0, v4}, Lel;-><init>(BLak;Lpp0;Lh92;)V

    .line 300
    .line 301
    .line 302
    const v0, 0x4bd7362b    # 2.8208214E7f

    .line 303
    .line 304
    .line 305
    invoke-static {v0, v3, v1}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 306
    .line 307
    .line 308
    move-result-object v15

    .line 309
    const/high16 v17, 0x30000

    .line 310
    .line 311
    const/16 v18, 0x1e

    .line 312
    .line 313
    const/4 v11, 0x0

    .line 314
    const/4 v12, 0x0

    .line 315
    const/4 v13, 0x0

    .line 316
    const/4 v14, 0x0

    .line 317
    move-object/from16 v16, v1

    .line 318
    .line 319
    invoke-static/range {v10 .. v18}, Lnn3;->O(ZLmz3;Lmy1;Lf02;Ljava/lang/String;Lyz0;Lla2;II)V

    .line 320
    .line 321
    .line 322
    goto :goto_7

    .line 323
    :cond_b
    move-object/from16 v16, v1

    .line 324
    .line 325
    invoke-virtual/range {v16 .. v16}, Lla2;->V()V

    .line 326
    .line 327
    .line 328
    :goto_7
    return-object v2

    .line 329
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
