.class public final Lah4;
.super Lgy;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public a:Lou2;


# virtual methods
.method public final a()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lah4;->a:Lou2;

    .line 3
    .line 4
    return-void
.end method
