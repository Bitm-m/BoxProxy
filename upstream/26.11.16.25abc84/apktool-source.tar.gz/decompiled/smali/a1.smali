.class public final synthetic La1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw82;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lb34;


# direct methods
.method public synthetic constructor <init>(Lb34;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La1;->j:Lb34;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 14

    .line 1
    iget-byte v0, p0, La1;->i:B

    .line 2
    .line 3
    const-string v1, "Required value was null."

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    sget-object v3, Loc7;->a:Loc7;

    .line 7
    .line 8
    iget-object p0, p0, La1;->j:Lb34;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    new-instance v4, Lqd1;

    .line 14
    .line 15
    const/4 v12, 0x0

    .line 16
    const/16 v13, 0x7ff

    .line 17
    .line 18
    const/4 v5, 0x0

    .line 19
    const/4 v6, 0x0

    .line 20
    const/4 v7, 0x0

    .line 21
    const/4 v8, 0x0

    .line 22
    const/4 v9, 0x0

    .line 23
    const/4 v10, 0x0

    .line 24
    const/4 v11, 0x0

    .line 25
    invoke-direct/range {v4 .. v13}, Lqd1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;I)V

    .line 26
    .line 27
    .line 28
    invoke-interface {p0, v4}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    return-object v3

    .line 32
    :pswitch_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    return-object v3

    .line 38
    :pswitch_1
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 39
    .line 40
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-object v3

    .line 44
    :pswitch_2
    invoke-interface {p0, v2}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    return-object v3

    .line 48
    :pswitch_3
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 49
    .line 50
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-object v3

    .line 54
    :pswitch_4
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 55
    .line 56
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    return-object v3

    .line 60
    :pswitch_5
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    return-object v3

    .line 66
    :pswitch_6
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 67
    .line 68
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    return-object v3

    .line 72
    :pswitch_7
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    check-cast v0, Ljava/lang/Boolean;

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    xor-int/lit8 v0, v0, 0x1

    .line 83
    .line 84
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    return-object v3

    .line 92
    :pswitch_8
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 93
    .line 94
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    return-object v3

    .line 98
    :pswitch_9
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 99
    .line 100
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    return-object v3

    .line 104
    :pswitch_a
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 105
    .line 106
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    return-object v3

    .line 110
    :pswitch_b
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p0

    .line 114
    check-cast p0, Lw82;

    .line 115
    .line 116
    if-eqz p0, :cond_0

    .line 117
    .line 118
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    :cond_0
    return-object v3

    .line 122
    :pswitch_c
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    check-cast p0, Landroid/content/Context;

    .line 127
    .line 128
    return-object p0

    .line 129
    :pswitch_d
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    check-cast p0, Liz2;

    .line 134
    .line 135
    iget-wide v0, p0, Liz2;->a:J

    .line 136
    .line 137
    return-object p0

    .line 138
    :pswitch_e
    invoke-interface {p0, v2}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    return-object v3

    .line 142
    :pswitch_f
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object p0

    .line 146
    check-cast p0, Lw82;

    .line 147
    .line 148
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    return-object v3

    .line 152
    :pswitch_10
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object p0

    .line 156
    check-cast p0, Lw82;

    .line 157
    .line 158
    if-eqz p0, :cond_1

    .line 159
    .line 160
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    :cond_1
    return-object v3

    .line 164
    :pswitch_11
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object p0

    .line 168
    check-cast p0, Lw82;

    .line 169
    .line 170
    if-eqz p0, :cond_2

    .line 171
    .line 172
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    :cond_2
    return-object v3

    .line 176
    :pswitch_12
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object p0

    .line 180
    check-cast p0, Landroid/content/Context;

    .line 181
    .line 182
    return-object p0

    .line 183
    :pswitch_13
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    check-cast p0, Lw82;

    .line 188
    .line 189
    if-eqz p0, :cond_3

    .line 190
    .line 191
    invoke-interface {p0}, Lw82;->invoke()Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    :cond_3
    return-object v3

    .line 195
    :pswitch_14
    if-eqz p0, :cond_4

    .line 196
    .line 197
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object p0

    .line 201
    move-object v2, p0

    .line 202
    check-cast v2, Ljava/util/List;

    .line 203
    .line 204
    :cond_4
    return-object v2

    .line 205
    :pswitch_15
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    check-cast p0, Lz73;

    .line 210
    .line 211
    if-eqz p0, :cond_5

    .line 212
    .line 213
    move-object v2, p0

    .line 214
    goto :goto_0

    .line 215
    :cond_5
    invoke-static {v1}, Ljx2;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 216
    .line 217
    .line 218
    invoke-static {}, Lhh1;->l()V

    .line 219
    .line 220
    .line 221
    :goto_0
    return-object v2

    .line 222
    :pswitch_16
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object p0

    .line 226
    check-cast p0, Landroid/content/Context;

    .line 227
    .line 228
    return-object p0

    .line 229
    :pswitch_17
    invoke-interface {p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object p0

    .line 233
    check-cast p0, Lz73;

    .line 234
    .line 235
    if-eqz p0, :cond_6

    .line 236
    .line 237
    move-object v2, p0

    .line 238
    goto :goto_1

    .line 239
    :cond_6
    invoke-static {v1}, Ljx2;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 240
    .line 241
    .line 242
    invoke-static {}, Lhh1;->l()V

    .line 243
    .line 244
    .line 245
    :goto_1
    return-object v2

    .line 246
    :pswitch_18
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 247
    .line 248
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 249
    .line 250
    .line 251
    return-object v3

    .line 252
    :pswitch_19
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 253
    .line 254
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    return-object v3

    .line 258
    :pswitch_1a
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 259
    .line 260
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    return-object v3

    .line 264
    :pswitch_1b
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 265
    .line 266
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    return-object v3

    .line 270
    :pswitch_1c
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 271
    .line 272
    invoke-interface {p0, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 273
    .line 274
    .line 275
    return-object v3

    .line 276
    nop

    .line 277
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
