.class public abstract La43;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lcx2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "kotlinx.serialization.json.JsonUnquotedLiteral"

    .line 2
    .line 3
    sget-object v1, Lxl6;->a:Lxl6;

    .line 4
    .line 5
    invoke-static {v0, v1}, Ldj;->p(Ljava/lang/String;Lz53;)Lcx2;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, La43;->a:Lcx2;

    .line 10
    .line 11
    return-void
.end method

.method public static final a(Ly33;)Lv43;
    .locals 3

    .line 1
    instance-of v0, p0, Lv43;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    move-object v0, p0

    .line 7
    check-cast v0, Lv43;

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object v0, v1

    .line 11
    :goto_0
    if-eqz v0, :cond_1

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-static {p0}, Lhj5;->a(Ljava/lang/Class;)Lbs0;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const-string v0, " is not a JsonPrimitive"

    .line 23
    .line 24
    const-string v2, "Element "

    .line 25
    .line 26
    invoke-static {v2, p0, v0}, Lhh1;->o(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-object v1
.end method

.method public static final b(Lv43;)J
    .locals 5

    .line 1
    sget-object v0, Li33;->d:Ly23;

    .line 2
    .line 3
    invoke-virtual {p0}, Lv43;->b()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {v0, p0}, Lmb3;->s(Li33;Ljava/lang/String;)Lgp;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    iget-object v0, p0, Lgp;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {p0}, Lgp;->i()J

    .line 16
    .line 17
    .line 18
    move-result-wide v1

    .line 19
    invoke-virtual {p0}, Lgp;->f()B

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    const/16 v4, 0xa

    .line 24
    .line 25
    if-eq v3, v4, :cond_2

    .line 26
    .line 27
    iget v1, p0, Lgp;->b:I

    .line 28
    .line 29
    if-lez v1, :cond_0

    .line 30
    .line 31
    add-int/lit8 v2, v1, -0x1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    move v2, v1

    .line 35
    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    if-eq v1, v3, :cond_1

    .line 40
    .line 41
    if-ltz v2, :cond_1

    .line 42
    .line 43
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-static {v0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    goto :goto_1

    .line 52
    :cond_1
    const-string v0, "EOF"

    .line 53
    .line 54
    :goto_1
    const-string v1, "Expected input to contain a single valid number, but got \'"

    .line 55
    .line 56
    const-string v3, "\' after it"

    .line 57
    .line 58
    invoke-static {v1, v0, v3}, Lly1;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    const/4 v1, 0x4

    .line 63
    const/4 v3, 0x0

    .line 64
    invoke-static {p0, v0, v2, v3, v1}, Lgp;->m(Lgp;Ljava/lang/String;ILjava/lang/String;I)V

    .line 65
    .line 66
    .line 67
    throw v3

    .line 68
    :cond_2
    return-wide v1
.end method
