.class public final La21;
.super Lkm;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lkz3;


# instance fields
.field public final n:Lm92;


# direct methods
.method public constructor <init>(Lm92;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La21;->n:Lm92;

    .line 5
    .line 6
    return-void
.end method
