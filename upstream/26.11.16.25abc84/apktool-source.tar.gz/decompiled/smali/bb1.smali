.class public final Lbb1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Ldk5;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ldk5;

    .line 2
    .line 3
    const-string v1, "[A-Fa-f0-9]{64}"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ldk5;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lbb1;->a:Ldk5;

    .line 9
    .line 10
    return-void
.end method

.method public static f(Lorg/json/JSONObject;)Lcb1;
    .locals 10

    .line 1
    const-string v0, "draft"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    const/4 v2, 0x0

    .line 9
    const-string v3, "tag_name"

    .line 10
    .line 11
    if-nez v0, :cond_5

    .line 12
    .line 13
    const-string v0, "assets"

    .line 14
    .line 15
    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-nez v0, :cond_0

    .line 20
    .line 21
    new-instance v0, Lorg/json/JSONArray;

    .line 22
    .line 23
    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 24
    .line 25
    .line 26
    :cond_0
    invoke-static {}, Lkm;->Q()Lgh3;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    :goto_0
    const-string v6, "name"

    .line 35
    .line 36
    if-ge v1, v5, :cond_3

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 39
    .line 40
    .line 41
    move-result-object v7

    .line 42
    if-eqz v7, :cond_2

    .line 43
    .line 44
    invoke-static {v6, v7}, Lzi6;->q(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v6

    .line 48
    const-string v8, "browser_download_url"

    .line 49
    .line 50
    invoke-static {v8, v7}, Lzi6;->q(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    invoke-static {v6}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result v9

    .line 58
    if-nez v9, :cond_2

    .line 59
    .line 60
    invoke-static {v8}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 61
    .line 62
    .line 63
    move-result v9

    .line 64
    if-nez v9, :cond_2

    .line 65
    .line 66
    const-string v9, "digest"

    .line 67
    .line 68
    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    invoke-static {v7}, Lam6;->n1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 76
    .line 77
    .line 78
    move-result-object v7

    .line 79
    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v7

    .line 83
    const-string v9, "sha256:"

    .line 84
    .line 85
    invoke-static {v7, v9}, Lam6;->X0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    sget-object v9, Lbb1;->a:Ldk5;

    .line 90
    .line 91
    invoke-virtual {v9, v7}, Ldk5;->d(Ljava/lang/CharSequence;)Z

    .line 92
    .line 93
    .line 94
    move-result v9

    .line 95
    if-nez v9, :cond_1

    .line 96
    .line 97
    move-object v7, v2

    .line 98
    :cond_1
    new-instance v9, Lwa1;

    .line 99
    .line 100
    invoke-direct {v9, v6, v8, v7}, Lwa1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v4, v9}, Lgh3;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_3
    invoke-static {v4}, Lkm;->N(Lgh3;)Lgh3;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-static {v3, p0}, Lzi6;->q(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-static {v1}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    if-eqz v2, :cond_4

    .line 122
    .line 123
    invoke-static {v6, p0}, Lzi6;->q(Ljava/lang/String;Lorg/json/JSONObject;)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    :cond_4
    new-instance p0, Lcb1;

    .line 128
    .line 129
    invoke-direct {p0, v0, v1}, Lcb1;-><init>(Lgh3;Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    return-object p0

    .line 133
    :cond_5
    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    const v0, 0x7f0f0170

    .line 145
    .line 146
    .line 147
    invoke-static {v0, p0}, Lkn0;->A(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    invoke-static {p0}, Lhh1;->d(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    return-object v2
.end method


# virtual methods
.method public final a(Lwa1;Ljava/io/File;Lda1;)Ljava/lang/Object;
    .locals 7

    .line 1
    instance-of v0, p3, Lxa1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lxa1;

    .line 7
    .line 8
    iget v1, v0, Lxa1;->m:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lxa1;->m:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lxa1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lxa1;-><init>(Lbb1;Lda1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p0, v0, Lxa1;->k:Ljava/lang/Object;

    .line 26
    .line 27
    iget p3, v0, Lxa1;->m:I

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    const/4 v2, 0x1

    .line 31
    const/4 v3, 0x0

    .line 32
    if-eqz p3, :cond_2

    .line 33
    .line 34
    if-ne p3, v2, :cond_1

    .line 35
    .line 36
    iget-object p2, v0, Lxa1;->j:Ljava/io/File;

    .line 37
    .line 38
    iget-object p1, v0, Lxa1;->i:Lwa1;

    .line 39
    .line 40
    invoke-static {p0}, Lcb3;->L(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v3

    .line 50
    :cond_2
    invoke-static {p0}, Lcb3;->L(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    new-instance p0, Ljg2;

    .line 54
    .line 55
    const/4 p3, 0x7

    .line 56
    invoke-direct {p0, p3}, Ljg2;-><init>(B)V

    .line 57
    .line 58
    .line 59
    sget-object p3, Lko1;->a:Ljava/util/Set;

    .line 60
    .line 61
    iget-object p3, p1, Lwa1;->b:Ljava/lang/String;

    .line 62
    .line 63
    invoke-static {p3}, Lko1;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p3

    .line 67
    invoke-virtual {p0, p3}, Ljg2;->z(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    const-string p3, "User-Agent"

    .line 71
    .line 72
    const-string v4, "box"

    .line 73
    .line 74
    invoke-virtual {p0, p3, v4}, Ljg2;->r(Ljava/lang/String;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p0}, Ljg2;->h()V

    .line 78
    .line 79
    .line 80
    new-instance p3, Lal5;

    .line 81
    .line 82
    invoke-direct {p3, p0}, Lal5;-><init>(Ljg2;)V

    .line 83
    .line 84
    .line 85
    sget-object p0, Lhb0;->a:Lzq6;

    .line 86
    .line 87
    sget-object p0, Lhb0;->m:Lzq6;

    .line 88
    .line 89
    invoke-virtual {p0}, Lzq6;->getValue()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    check-cast p0, Luk4;

    .line 94
    .line 95
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    .line 97
    .line 98
    new-instance v4, Lrh5;

    .line 99
    .line 100
    invoke-direct {v4, p0, p3, v1}, Lrh5;-><init>(Luk4;Lal5;Z)V

    .line 101
    .line 102
    .line 103
    iput-object p1, v0, Lxa1;->i:Lwa1;

    .line 104
    .line 105
    iput-object p2, v0, Lxa1;->j:Ljava/io/File;

    .line 106
    .line 107
    iput v2, v0, Lxa1;->m:I

    .line 108
    .line 109
    invoke-static {v4, v0}, Lkm;->J(Lrh5;Lca1;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object p0

    .line 113
    sget-object p3, Lie1;->i:Lie1;

    .line 114
    .line 115
    if-ne p0, p3, :cond_3

    .line 116
    .line 117
    return-object p3

    .line 118
    :cond_3
    :goto_1
    check-cast p0, Ljava/io/Closeable;

    .line 119
    .line 120
    :try_start_0
    move-object p3, p0

    .line 121
    check-cast p3, Lxl5;

    .line 122
    .line 123
    iget-boolean v0, p3, Lxl5;->x:Z

    .line 124
    .line 125
    if-eqz v0, :cond_5

    .line 126
    .line 127
    const-string v0, "SHA-256"

    .line 128
    .line 129
    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    iget-object p3, p3, Lxl5;->o:Lzl5;

    .line 134
    .line 135
    invoke-virtual {p3}, Lzl5;->b()Ljava/io/InputStream;

    .line 136
    .line 137
    .line 138
    move-result-object p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    .line 139
    :try_start_1
    new-instance v2, Ljava/security/DigestInputStream;

    .line 140
    .line 141
    invoke-direct {v2, p3, v0}, Ljava/security/DigestInputStream;-><init>(Ljava/io/InputStream;Ljava/security/MessageDigest;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 142
    .line 143
    .line 144
    :try_start_2
    new-instance v4, Ljava/lang/Long;

    .line 145
    .line 146
    const-wide/32 v5, 0xc000000

    .line 147
    .line 148
    .line 149
    invoke-direct {v4, v5, v6}, Ljava/lang/Long;-><init>(J)V

    .line 150
    .line 151
    .line 152
    const/16 v5, 0x8

    .line 153
    .line 154
    invoke-static {p2, v2, v4, v5}, Lr6;->w(Ljava/io/File;Ljava/io/InputStream;Ljava/lang/Long;I)J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 155
    .line 156
    .line 157
    :try_start_3
    invoke-interface {v2}, Ljava/io/Closeable;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 158
    .line 159
    .line 160
    :try_start_4
    invoke-interface {p3}, Ljava/io/Closeable;->close()V

    .line 161
    .line 162
    .line 163
    iget-object p1, p1, Lwa1;->c:Ljava/lang/String;

    .line 164
    .line 165
    if-eqz p1, :cond_4

    .line 166
    .line 167
    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    .line 168
    .line 169
    .line 170
    move-result-object p3

    .line 171
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    .line 173
    .line 174
    new-instance v0, Lvw0;

    .line 175
    .line 176
    const/16 v2, 0x19

    .line 177
    .line 178
    invoke-direct {v0, v2}, Lvw0;-><init>(B)V

    .line 179
    .line 180
    .line 181
    const/16 v2, 0x1e

    .line 182
    .line 183
    invoke-static {p3, v0, v2}, Lkw;->u0([BLh92;I)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p3

    .line 187
    invoke-virtual {p3, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 188
    .line 189
    .line 190
    move-result p1

    .line 191
    if-nez p1, :cond_4

    .line 192
    .line 193
    invoke-virtual {p2}, Ljava/io/File;->delete()Z

    .line 194
    .line 195
    .line 196
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 197
    .line 198
    new-array p2, v1, [Ljava/lang/Object;

    .line 199
    .line 200
    const p3, 0x7f0f0167

    .line 201
    .line 202
    .line 203
    invoke-static {p3, p2}, Lkn0;->A(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p2

    .line 207
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object p2

    .line 211
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    throw p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 215
    :cond_4
    invoke-static {p0, v3}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 216
    .line 217
    .line 218
    sget-object p0, Loc7;->a:Loc7;

    .line 219
    .line 220
    return-object p0

    .line 221
    :catchall_0
    move-exception p1

    .line 222
    :try_start_5
    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 223
    :catchall_1
    move-exception p2

    .line 224
    :try_start_6
    invoke-static {v2, p1}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 225
    .line 226
    .line 227
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 228
    :catchall_2
    move-exception p1

    .line 229
    :try_start_7
    throw p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 230
    :catchall_3
    move-exception p2

    .line 231
    :try_start_8
    invoke-static {p3, p1}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 232
    .line 233
    .line 234
    throw p2

    .line 235
    :cond_5
    iget p1, p3, Lxl5;->l:I

    .line 236
    .line 237
    new-instance p2, Ljava/lang/Integer;

    .line 238
    .line 239
    invoke-direct {p2, p1}, Ljava/lang/Integer;-><init>(I)V

    .line 240
    .line 241
    .line 242
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    const p2, 0x7f0f00bd

    .line 247
    .line 248
    .line 249
    invoke-static {p2, p1}, Lkn0;->A(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 254
    .line 255
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    throw p2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 263
    :catchall_4
    move-exception p1

    .line 264
    :try_start_9
    throw p1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 265
    :catchall_5
    move-exception p2

    .line 266
    invoke-static {p0, p1}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 267
    .line 268
    .line 269
    throw p2
.end method

.method public final b(Ljava/lang/String;ZLda1;)Ljava/lang/Object;
    .locals 5

    .line 1
    instance-of v0, p3, Lya1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lya1;

    .line 7
    .line 8
    iget v1, v0, Lya1;->l:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lya1;->l:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lya1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lya1;-><init>(Lbb1;Lda1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, Lya1;->j:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lya1;->l:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x2

    .line 31
    const/4 v4, 0x1

    .line 32
    if-eqz v1, :cond_3

    .line 33
    .line 34
    if-eq v1, v4, :cond_2

    .line 35
    .line 36
    if-ne v1, v3, :cond_1

    .line 37
    .line 38
    iget-object p1, v0, Lya1;->i:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {p3}, Lcb3;->L(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v2

    .line 50
    :cond_2
    invoke-static {p3}, Lcb3;->L(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-object p3

    .line 54
    :cond_3
    invoke-static {p3}, Lcb3;->L(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    const-string p3, "https://api.github.com/repos/"

    .line 58
    .line 59
    sget-object v1, Lie1;->i:Lie1;

    .line 60
    .line 61
    if-eqz p2, :cond_4

    .line 62
    .line 63
    const-string p2, "/releases/latest"

    .line 64
    .line 65
    invoke-static {p3, p1, p2}, Lly1;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object v2, v0, Lya1;->i:Ljava/lang/String;

    .line 70
    .line 71
    iput v4, v0, Lya1;->l:I

    .line 72
    .line 73
    invoke-virtual {p0, p1, v0}, Lbb1;->d(Ljava/lang/String;Lda1;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    if-eq p0, v1, :cond_5

    .line 78
    .line 79
    return-object p0

    .line 80
    :cond_4
    const-string p2, "/releases?per_page=30"

    .line 81
    .line 82
    invoke-static {p3, p1, p2}, Lly1;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    iput-object p1, v0, Lya1;->i:Ljava/lang/String;

    .line 87
    .line 88
    iput v3, v0, Lya1;->l:I

    .line 89
    .line 90
    invoke-virtual {p0, p2, v0}, Lbb1;->e(Ljava/lang/String;Lda1;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p3

    .line 94
    if-ne p3, v1, :cond_6

    .line 95
    .line 96
    :cond_5
    return-object v1

    .line 97
    :cond_6
    :goto_1
    check-cast p3, Ljava/lang/String;

    .line 98
    .line 99
    new-instance p0, Lorg/json/JSONArray;

    .line 100
    .line 101
    invoke-direct {p0, p3}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    .line 105
    .line 106
    .line 107
    move-result p2

    .line 108
    const/4 p3, 0x0

    .line 109
    move v0, p3

    .line 110
    :goto_2
    if-ge v0, p2, :cond_8

    .line 111
    .line 112
    invoke-virtual {p0, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    if-eqz v1, :cond_7

    .line 117
    .line 118
    const-string v3, "draft"

    .line 119
    .line 120
    invoke-virtual {v1, v3, p3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    if-nez v3, :cond_7

    .line 125
    .line 126
    invoke-static {v1}, Lbb1;->f(Lorg/json/JSONObject;)Lcb1;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    return-object p0

    .line 131
    :cond_7
    add-int/lit8 v0, v0, 0x1

    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_8
    const p0, 0x7f0f016a

    .line 135
    .line 136
    .line 137
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    invoke-static {p0, p1}, Lkn0;->A(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p0

    .line 145
    invoke-static {p0}, Lhh1;->d(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    return-object v2
.end method

.method public final c(Ljava/lang/String;Ljava/lang/String;Lda1;)Ljava/lang/Object;
    .locals 6

    .line 1
    const-string v0, "https://api.github.com/repos/"

    .line 2
    .line 3
    const-string v1, "/releases/tags"

    .line 4
    .line 5
    invoke-static {v0, p1, v1}, Lly1;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    new-instance v0, Lbt2;

    .line 10
    .line 11
    invoke-direct {v0}, Lbt2;-><init>()V

    .line 12
    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-virtual {v0, v1, p1}, Lbt2;->c(Lct2;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lbt2;->a()Lct2;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {p1}, Lct2;->f()Lbt2;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    const/4 v4, 0x0

    .line 34
    const/4 v5, 0x0

    .line 35
    const/4 v2, 0x0

    .line 36
    move-object v1, p2

    .line 37
    invoke-virtual/range {v0 .. v5}, Lbt2;->d(Ljava/lang/String;IIZZ)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Lbt2;->a()Lct2;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    iget-object p1, p1, Lct2;->i:Ljava/lang/String;

    .line 45
    .line 46
    invoke-virtual {p0, p1, p3}, Lbb1;->d(Ljava/lang/String;Lda1;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0
.end method

.method public final d(Ljava/lang/String;Lda1;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lza1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lza1;

    .line 7
    .line 8
    iget v1, v0, Lza1;->l:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lza1;->l:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lza1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lza1;-><init>(Lbb1;Lda1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lza1;->j:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lza1;->l:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    iget-object p0, v0, Lza1;->i:Lbb1;

    .line 35
    .line 36
    invoke-static {p2}, Lcb3;->L(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    const/4 p0, 0x0

    .line 46
    return-object p0

    .line 47
    :cond_2
    invoke-static {p2}, Lcb3;->L(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iput-object p0, v0, Lza1;->i:Lbb1;

    .line 51
    .line 52
    iput v2, v0, Lza1;->l:I

    .line 53
    .line 54
    invoke-virtual {p0, p1, v0}, Lbb1;->e(Ljava/lang/String;Lda1;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    sget-object p1, Lie1;->i:Lie1;

    .line 59
    .line 60
    if-ne p2, p1, :cond_3

    .line 61
    .line 62
    return-object p1

    .line 63
    :cond_3
    :goto_1
    check-cast p2, Ljava/lang/String;

    .line 64
    .line 65
    new-instance p1, Lorg/json/JSONObject;

    .line 66
    .line 67
    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    invoke-static {p1}, Lbb1;->f(Lorg/json/JSONObject;)Lcb1;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    return-object p0
.end method

.method public final e(Ljava/lang/String;Lda1;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lab1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lab1;

    .line 7
    .line 8
    iget v1, v0, Lab1;->k:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lab1;->k:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lab1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lab1;-><init>(Lbb1;Lda1;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p0, v0, Lab1;->i:Ljava/lang/Object;

    .line 26
    .line 27
    iget p2, v0, Lab1;->k:I

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    const/4 v2, 0x0

    .line 31
    if-eqz p2, :cond_2

    .line 32
    .line 33
    if-ne p2, v1, :cond_1

    .line 34
    .line 35
    invoke-static {p0}, Lcb3;->L(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v2

    .line 45
    :cond_2
    invoke-static {p0}, Lcb3;->L(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    new-instance p0, Ljg2;

    .line 49
    .line 50
    const/4 p2, 0x7

    .line 51
    invoke-direct {p0, p2}, Ljg2;-><init>(B)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0, p1}, Ljg2;->z(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    const-string p1, "Accept"

    .line 58
    .line 59
    const-string p2, "application/vnd.github+json"

    .line 60
    .line 61
    invoke-virtual {p0, p1, p2}, Ljg2;->r(Ljava/lang/String;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    const-string p1, "User-Agent"

    .line 65
    .line 66
    const-string p2, "box"

    .line 67
    .line 68
    invoke-virtual {p0, p1, p2}, Ljg2;->r(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0}, Ljg2;->h()V

    .line 72
    .line 73
    .line 74
    new-instance p1, Lal5;

    .line 75
    .line 76
    invoke-direct {p1, p0}, Lal5;-><init>(Ljg2;)V

    .line 77
    .line 78
    .line 79
    sget-object p0, Lhb0;->a:Lzq6;

    .line 80
    .line 81
    sget-object p0, Lhb0;->m:Lzq6;

    .line 82
    .line 83
    invoke-virtual {p0}, Lzq6;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    check-cast p0, Luk4;

    .line 88
    .line 89
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    new-instance p2, Lrh5;

    .line 93
    .line 94
    const/4 v3, 0x0

    .line 95
    invoke-direct {p2, p0, p1, v3}, Lrh5;-><init>(Luk4;Lal5;Z)V

    .line 96
    .line 97
    .line 98
    iput v1, v0, Lab1;->k:I

    .line 99
    .line 100
    invoke-static {p2, v0}, Lkm;->J(Lrh5;Lca1;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object p0

    .line 104
    sget-object p1, Lie1;->i:Lie1;

    .line 105
    .line 106
    if-ne p0, p1, :cond_3

    .line 107
    .line 108
    return-object p1

    .line 109
    :cond_3
    :goto_1
    check-cast p0, Ljava/io/Closeable;

    .line 110
    .line 111
    :try_start_0
    move-object p1, p0

    .line 112
    check-cast p1, Lxl5;

    .line 113
    .line 114
    iget-boolean p2, p1, Lxl5;->x:Z

    .line 115
    .line 116
    if-eqz p2, :cond_4

    .line 117
    .line 118
    iget-object p1, p1, Lxl5;->o:Lzl5;

    .line 119
    .line 120
    invoke-virtual {p1}, Lzl5;->b()Ljava/io/InputStream;

    .line 121
    .line 122
    .line 123
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 124
    :try_start_1
    new-instance p2, Ljava/lang/String;

    .line 125
    .line 126
    invoke-static {p1}, Loq;->b0(Ljava/io/InputStream;)[B

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    sget-object v1, Lno0;->a:Ljava/nio/charset/Charset;

    .line 131
    .line 132
    invoke-direct {p2, v0, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 133
    .line 134
    .line 135
    :try_start_2
    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 136
    .line 137
    .line 138
    invoke-static {p0, v2}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 139
    .line 140
    .line 141
    return-object p2

    .line 142
    :catchall_0
    move-exception p2

    .line 143
    :try_start_3
    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 144
    :catchall_1
    move-exception v0

    .line 145
    :try_start_4
    invoke-static {p1, p2}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 146
    .line 147
    .line 148
    throw v0

    .line 149
    :cond_4
    iget p1, p1, Lxl5;->l:I

    .line 150
    .line 151
    new-instance p2, Ljava/lang/Integer;

    .line 152
    .line 153
    invoke-direct {p2, p1}, Ljava/lang/Integer;-><init>(I)V

    .line 154
    .line 155
    .line 156
    filled-new-array {p2}, [Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    const p2, 0x7f0f016f

    .line 161
    .line 162
    .line 163
    invoke-static {p2, p1}, Lkn0;->A(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 168
    .line 169
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    throw p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 177
    :catchall_2
    move-exception p1

    .line 178
    :try_start_5
    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 179
    :catchall_3
    move-exception p2

    .line 180
    invoke-static {p0, p1}, Lhq;->r(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 181
    .line 182
    .line 183
    throw p2
.end method
