.class public final Lab2;
.super Llz3;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ld87;


# static fields
.field public static final x:Lq21;


# instance fields
.field public final w:Lza2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lq21;

    .line 2
    .line 3
    const/16 v1, 0x11

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lq21;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lab2;->x:Lq21;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Lza2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Llz3;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lab2;->w:Lza2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final d()Ljava/lang/Object;
    .locals 0

    .line 1
    sget-object p0, Lab2;->x:Lq21;

    .line 2
    .line 3
    return-object p0
.end method
