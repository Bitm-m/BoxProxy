.class public interface abstract Lao1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lxn1;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lxn1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lao1;->a:Lxn1;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public abstract a(Ljava/lang/String;)Ljava/util/List;
.end method

.method public b(Lzn1;)Lym3;
    .locals 2

    .line 1
    new-instance v0, Lym3;

    .line 2
    .line 3
    sget-object v1, Lht6;->l:Lht6;

    .line 4
    .line 5
    invoke-direct {v0, v1, p0, p1}, Lym3;-><init>(Lht6;Lao1;Lzn1;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method
