.class public final synthetic La51;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 10
    iput-byte p1, p0, La51;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IB)V
    .locals 0

    .line 9
    iput-byte p2, p0, La51;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLg22;Lg22;)V
    .locals 0

    .line 1
    const/16 p1, 0x1d

    .line 2
    .line 3
    iput-byte p1, p0, La51;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte p0, p0, La51;->i:B

    .line 2
    .line 3
    sget-object v0, Lq83;->a0:Lif2;

    .line 4
    .line 5
    sget-object v1, Ljz3;->i:Ljz3;

    .line 6
    .line 7
    const/4 v2, 0x2

    .line 8
    const/4 v3, 0x0

    .line 9
    const/4 v4, 0x1

    .line 10
    sget-object v5, Loc7;->a:Loc7;

    .line 11
    .line 12
    packed-switch p0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast p1, Lla2;

    .line 16
    .line 17
    check-cast p2, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    and-int/lit8 p2, p0, 0x3

    .line 24
    .line 25
    if-eq p2, v2, :cond_0

    .line 26
    .line 27
    move p2, v4

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    move p2, v3

    .line 30
    :goto_0
    and-int/2addr p0, v4

    .line 31
    invoke-virtual {p1, p0, p2}, Lla2;->S(IZ)Z

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    if-eqz p0, :cond_2

    .line 36
    .line 37
    sget-object p0, Lr6;->o:Ln20;

    .line 38
    .line 39
    invoke-static {p0, v3}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    iget-wide v6, p1, Lla2;->T:J

    .line 44
    .line 45
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 46
    .line 47
    .line 48
    move-result p2

    .line 49
    invoke-virtual {p1}, Lla2;->m()Lky4;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-static {p1, v1}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    sget-object v6, Lv11;->d:Lr6;

    .line 58
    .line 59
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Lla2;->e0()V

    .line 63
    .line 64
    .line 65
    iget-boolean v6, p1, Lla2;->S:Z

    .line 66
    .line 67
    if-eqz v6, :cond_1

    .line 68
    .line 69
    invoke-virtual {p1, v0}, Lla2;->l(Lw82;)V

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_1
    invoke-virtual {p1}, Lla2;->n0()V

    .line 74
    .line 75
    .line 76
    :goto_1
    sget-object v0, Lr6;->S:La11;

    .line 77
    .line 78
    invoke-static {v0, p1, p0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    sget-object p0, Lr6;->R:La11;

    .line 82
    .line 83
    invoke-static {p0, p1, v2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    sget-object p2, Lr6;->T:La11;

    .line 91
    .line 92
    invoke-static {p2, p1, p0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    invoke-static {p1}, Lxt6;->k(Lla2;)V

    .line 96
    .line 97
    .line 98
    sget-object p0, Lr6;->Q:La11;

    .line 99
    .line 100
    invoke-static {p0, p1, v1}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    const p0, 0x7b90a275

    .line 104
    .line 105
    .line 106
    invoke-virtual {p1, p0}, Lla2;->b0(I)V

    .line 107
    .line 108
    .line 109
    new-instance p0, Ly01;

    .line 110
    .line 111
    const/16 p2, 0x12

    .line 112
    .line 113
    invoke-direct {p0, p2}, Ly01;-><init>(B)V

    .line 114
    .line 115
    .line 116
    const p2, -0x10291182

    .line 117
    .line 118
    .line 119
    invoke-static {p2, p0, p1}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    const/4 p2, 0x6

    .line 124
    invoke-static {p0, p1, p2}, Lyr3;->i(Lyz0;Lla2;I)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1, v3}, Lla2;->r(Z)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p1, v4}, Lla2;->r(Z)V

    .line 131
    .line 132
    .line 133
    goto :goto_2

    .line 134
    :cond_2
    invoke-virtual {p1}, Lla2;->V()V

    .line 135
    .line 136
    .line 137
    :goto_2
    return-object v5

    .line 138
    :pswitch_0
    check-cast p1, Ljava/lang/Integer;

    .line 139
    .line 140
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    check-cast p2, Lgp3;

    .line 144
    .line 145
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    iget-object p0, p2, Lgp3;->a:Ljava/lang/String;

    .line 149
    .line 150
    return-object p0

    .line 151
    :pswitch_1
    check-cast p1, Ljz5;

    .line 152
    .line 153
    check-cast p2, Lvc3;

    .line 154
    .line 155
    invoke-virtual {p2}, Lvc3;->e()Ljava/util/Map;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    invoke-interface {p0}, Ljava/util/Map;->isEmpty()Z

    .line 160
    .line 161
    .line 162
    move-result p1

    .line 163
    if-eqz p1, :cond_3

    .line 164
    .line 165
    const/4 p0, 0x0

    .line 166
    :cond_3
    return-object p0

    .line 167
    :pswitch_2
    check-cast p1, Ljz5;

    .line 168
    .line 169
    check-cast p2, Lsc3;

    .line 170
    .line 171
    invoke-virtual {p2}, Lsc3;->h()I

    .line 172
    .line 173
    .line 174
    move-result p0

    .line 175
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 176
    .line 177
    .line 178
    move-result-object p0

    .line 179
    invoke-virtual {p2}, Lsc3;->i()I

    .line 180
    .line 181
    .line 182
    move-result p1

    .line 183
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    filled-new-array {p0, p1}, [Ljava/lang/Integer;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 192
    .line 193
    .line 194
    move-result-object p0

    .line 195
    return-object p0

    .line 196
    :pswitch_3
    check-cast p1, Ljz5;

    .line 197
    .line 198
    check-cast p2, Lia3;

    .line 199
    .line 200
    invoke-virtual {p2}, Lia3;->g()I

    .line 201
    .line 202
    .line 203
    move-result p0

    .line 204
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 205
    .line 206
    .line 207
    move-result-object p0

    .line 208
    invoke-virtual {p2}, Lia3;->h()I

    .line 209
    .line 210
    .line 211
    move-result p1

    .line 212
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    filled-new-array {p0, p1}, [Ljava/lang/Integer;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 221
    .line 222
    .line 223
    move-result-object p0

    .line 224
    return-object p0

    .line 225
    :pswitch_4
    check-cast p1, Lda3;

    .line 226
    .line 227
    check-cast p2, Ljava/lang/Integer;

    .line 228
    .line 229
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 230
    .line 231
    .line 232
    new-instance p0, Ltg2;

    .line 233
    .line 234
    const-wide/16 p1, 0x1

    .line 235
    .line 236
    invoke-direct {p0, p1, p2}, Ltg2;-><init>(J)V

    .line 237
    .line 238
    .line 239
    return-object p0

    .line 240
    :pswitch_5
    check-cast p1, Lla2;

    .line 241
    .line 242
    check-cast p2, Ljava/lang/Integer;

    .line 243
    .line 244
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    invoke-static {v4}, Lt36;->a0(I)I

    .line 248
    .line 249
    .line 250
    move-result p0

    .line 251
    invoke-static {p0, p1}, Lcj;->k(ILla2;)V

    .line 252
    .line 253
    .line 254
    return-object v5

    .line 255
    :pswitch_6
    check-cast p1, Lla2;

    .line 256
    .line 257
    check-cast p2, Ljava/lang/Integer;

    .line 258
    .line 259
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 260
    .line 261
    .line 262
    invoke-static {v4}, Lt36;->a0(I)I

    .line 263
    .line 264
    .line 265
    move-result p0

    .line 266
    invoke-static {p0, p1}, Lzi;->l(ILla2;)V

    .line 267
    .line 268
    .line 269
    return-object v5

    .line 270
    :pswitch_7
    check-cast p1, Ljz5;

    .line 271
    .line 272
    check-cast p2, Lb34;

    .line 273
    .line 274
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    .line 276
    .line 277
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 278
    .line 279
    .line 280
    invoke-interface {p2}, Lok6;->getValue()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    check-cast p0, La03;

    .line 285
    .line 286
    instance-of p1, p0, Lwz2;

    .line 287
    .line 288
    if-eqz p1, :cond_4

    .line 289
    .line 290
    check-cast p0, Lwz2;

    .line 291
    .line 292
    iget-wide p0, p0, Lwz2;->b:J

    .line 293
    .line 294
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 295
    .line 296
    .line 297
    move-result p2

    .line 298
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 299
    .line 300
    .line 301
    move-result-object p2

    .line 302
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 303
    .line 304
    .line 305
    move-result p0

    .line 306
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 307
    .line 308
    .line 309
    move-result-object p0

    .line 310
    const-string p1, "Press"

    .line 311
    .line 312
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object p0

    .line 316
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 317
    .line 318
    .line 319
    move-result-object p0

    .line 320
    goto/16 :goto_3

    .line 321
    .line 322
    :cond_4
    instance-of p1, p0, Lyz2;

    .line 323
    .line 324
    if-eqz p1, :cond_5

    .line 325
    .line 326
    check-cast p0, Lyz2;

    .line 327
    .line 328
    iget-wide p0, p0, Lyz2;->b:J

    .line 329
    .line 330
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 331
    .line 332
    .line 333
    move-result p2

    .line 334
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 335
    .line 336
    .line 337
    move-result-object p2

    .line 338
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 339
    .line 340
    .line 341
    move-result p0

    .line 342
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 343
    .line 344
    .line 345
    move-result-object p0

    .line 346
    const-string p1, "Tap"

    .line 347
    .line 348
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object p0

    .line 352
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 353
    .line 354
    .line 355
    move-result-object p0

    .line 356
    goto/16 :goto_3

    .line 357
    .line 358
    :cond_5
    instance-of p1, p0, Luz2;

    .line 359
    .line 360
    if-eqz p1, :cond_6

    .line 361
    .line 362
    check-cast p0, Luz2;

    .line 363
    .line 364
    iget-wide p0, p0, Luz2;->b:J

    .line 365
    .line 366
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 367
    .line 368
    .line 369
    move-result p2

    .line 370
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 371
    .line 372
    .line 373
    move-result-object p2

    .line 374
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 375
    .line 376
    .line 377
    move-result p0

    .line 378
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 379
    .line 380
    .line 381
    move-result-object p0

    .line 382
    const-string p1, "LongPress"

    .line 383
    .line 384
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 385
    .line 386
    .line 387
    move-result-object p0

    .line 388
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 389
    .line 390
    .line 391
    move-result-object p0

    .line 392
    goto/16 :goto_3

    .line 393
    .line 394
    :cond_6
    instance-of p1, p0, Lvz2;

    .line 395
    .line 396
    if-eqz p1, :cond_7

    .line 397
    .line 398
    check-cast p0, Lvz2;

    .line 399
    .line 400
    iget-wide p0, p0, Lvz2;->b:J

    .line 401
    .line 402
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 403
    .line 404
    .line 405
    move-result p2

    .line 406
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 407
    .line 408
    .line 409
    move-result-object p2

    .line 410
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 411
    .line 412
    .line 413
    move-result p0

    .line 414
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 415
    .line 416
    .line 417
    move-result-object p0

    .line 418
    const-string p1, "Move"

    .line 419
    .line 420
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 421
    .line 422
    .line 423
    move-result-object p0

    .line 424
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 425
    .line 426
    .line 427
    move-result-object p0

    .line 428
    goto/16 :goto_3

    .line 429
    .line 430
    :cond_7
    instance-of p1, p0, Lxz2;

    .line 431
    .line 432
    if-eqz p1, :cond_8

    .line 433
    .line 434
    check-cast p0, Lxz2;

    .line 435
    .line 436
    iget-wide p0, p0, Lxz2;->b:J

    .line 437
    .line 438
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 439
    .line 440
    .line 441
    move-result p2

    .line 442
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 443
    .line 444
    .line 445
    move-result-object p2

    .line 446
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 447
    .line 448
    .line 449
    move-result p0

    .line 450
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 451
    .line 452
    .line 453
    move-result-object p0

    .line 454
    const-string p1, "Release"

    .line 455
    .line 456
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object p0

    .line 460
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 461
    .line 462
    .line 463
    move-result-object p0

    .line 464
    goto :goto_3

    .line 465
    :cond_8
    instance-of p1, p0, Lzz2;

    .line 466
    .line 467
    if-eqz p1, :cond_9

    .line 468
    .line 469
    check-cast p0, Lzz2;

    .line 470
    .line 471
    iget-wide p0, p0, Lzz2;->b:J

    .line 472
    .line 473
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 474
    .line 475
    .line 476
    move-result p2

    .line 477
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 478
    .line 479
    .line 480
    move-result-object p2

    .line 481
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 482
    .line 483
    .line 484
    move-result p0

    .line 485
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 486
    .line 487
    .line 488
    move-result-object p0

    .line 489
    const-string p1, "Zoom"

    .line 490
    .line 491
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 492
    .line 493
    .line 494
    move-result-object p0

    .line 495
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 496
    .line 497
    .line 498
    move-result-object p0

    .line 499
    goto :goto_3

    .line 500
    :cond_9
    instance-of p1, p0, Lsz2;

    .line 501
    .line 502
    if-eqz p1, :cond_a

    .line 503
    .line 504
    check-cast p0, Lsz2;

    .line 505
    .line 506
    iget-wide p0, p0, Lsz2;->b:J

    .line 507
    .line 508
    invoke-static {p0, p1}, Lcc3;->C(J)F

    .line 509
    .line 510
    .line 511
    move-result p2

    .line 512
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 513
    .line 514
    .line 515
    move-result-object p2

    .line 516
    invoke-static {p0, p1}, Lcc3;->D(J)F

    .line 517
    .line 518
    .line 519
    move-result p0

    .line 520
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 521
    .line 522
    .line 523
    move-result-object p0

    .line 524
    const-string p1, "Enter"

    .line 525
    .line 526
    filled-new-array {p1, p2, p0}, [Ljava/lang/Object;

    .line 527
    .line 528
    .line 529
    move-result-object p0

    .line 530
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 531
    .line 532
    .line 533
    move-result-object p0

    .line 534
    goto :goto_3

    .line 535
    :cond_a
    instance-of p1, p0, Ltz2;

    .line 536
    .line 537
    if-eqz p1, :cond_b

    .line 538
    .line 539
    check-cast p0, Ltz2;

    .line 540
    .line 541
    iget-wide p1, p0, Ltz2;->b:J

    .line 542
    .line 543
    invoke-static {p1, p2}, Lcc3;->C(J)F

    .line 544
    .line 545
    .line 546
    move-result v0

    .line 547
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 548
    .line 549
    .line 550
    move-result-object v0

    .line 551
    invoke-static {p1, p2}, Lcc3;->D(J)F

    .line 552
    .line 553
    .line 554
    move-result p1

    .line 555
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 556
    .line 557
    .line 558
    move-result-object p1

    .line 559
    iget-boolean p0, p0, Ltz2;->c:Z

    .line 560
    .line 561
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 562
    .line 563
    .line 564
    move-result-object p0

    .line 565
    const-string p2, "Exit"

    .line 566
    .line 567
    filled-new-array {p2, v0, p1, p0}, [Ljava/lang/Object;

    .line 568
    .line 569
    .line 570
    move-result-object p0

    .line 571
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 572
    .line 573
    .line 574
    move-result-object p0

    .line 575
    goto :goto_3

    .line 576
    :cond_b
    sget-object p0, Lbx1;->i:Lbx1;

    .line 577
    .line 578
    :goto_3
    return-object p0

    .line 579
    :pswitch_8
    sget-object p0, Lx60;->n:Lyz0;

    .line 580
    .line 581
    check-cast p1, Lla2;

    .line 582
    .line 583
    check-cast p2, Ljava/lang/Integer;

    .line 584
    .line 585
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 586
    .line 587
    .line 588
    move-result p2

    .line 589
    and-int/lit8 v6, p2, 0x3

    .line 590
    .line 591
    if-eq v6, v2, :cond_c

    .line 592
    .line 593
    move v2, v4

    .line 594
    goto :goto_4

    .line 595
    :cond_c
    move v2, v3

    .line 596
    :goto_4
    and-int/2addr p2, v4

    .line 597
    invoke-virtual {p1, p2, v2}, Lla2;->S(IZ)Z

    .line 598
    .line 599
    .line 600
    move-result p2

    .line 601
    if-eqz p2, :cond_e

    .line 602
    .line 603
    const/high16 p2, 0x42200000    # 40.0f

    .line 604
    .line 605
    invoke-static {p2, p2}, Ldj;->l(FF)J

    .line 606
    .line 607
    .line 608
    move-result-wide v6

    .line 609
    invoke-static {v6, v7}, Lpo1;->b(J)F

    .line 610
    .line 611
    .line 612
    move-result p2

    .line 613
    invoke-static {v6, v7}, Lpo1;->a(J)F

    .line 614
    .line 615
    .line 616
    move-result v2

    .line 617
    invoke-static {v1, p2, v2}, Lef6;->n(Lmz3;FF)Lmz3;

    .line 618
    .line 619
    .line 620
    move-result-object p2

    .line 621
    sget-object v1, Lr6;->o:Ln20;

    .line 622
    .line 623
    invoke-static {v1, v3}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 624
    .line 625
    .line 626
    move-result-object v1

    .line 627
    iget-wide v6, p1, Lla2;->T:J

    .line 628
    .line 629
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 630
    .line 631
    .line 632
    move-result v2

    .line 633
    invoke-virtual {p1}, Lla2;->m()Lky4;

    .line 634
    .line 635
    .line 636
    move-result-object v6

    .line 637
    invoke-static {p1, p2}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 638
    .line 639
    .line 640
    move-result-object p2

    .line 641
    sget-object v7, Lv11;->d:Lr6;

    .line 642
    .line 643
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 644
    .line 645
    .line 646
    invoke-virtual {p1}, Lla2;->e0()V

    .line 647
    .line 648
    .line 649
    iget-boolean v7, p1, Lla2;->S:Z

    .line 650
    .line 651
    if-eqz v7, :cond_d

    .line 652
    .line 653
    invoke-virtual {p1, v0}, Lla2;->l(Lw82;)V

    .line 654
    .line 655
    .line 656
    goto :goto_5

    .line 657
    :cond_d
    invoke-virtual {p1}, Lla2;->n0()V

    .line 658
    .line 659
    .line 660
    :goto_5
    sget-object v0, Lr6;->S:La11;

    .line 661
    .line 662
    invoke-static {v0, p1, v1}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 663
    .line 664
    .line 665
    sget-object v0, Lr6;->R:La11;

    .line 666
    .line 667
    invoke-static {v0, p1, v6}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 668
    .line 669
    .line 670
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 671
    .line 672
    .line 673
    move-result-object v0

    .line 674
    sget-object v1, Lr6;->T:La11;

    .line 675
    .line 676
    invoke-static {v1, p1, v0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 677
    .line 678
    .line 679
    invoke-static {p1}, Lxt6;->k(Lla2;)V

    .line 680
    .line 681
    .line 682
    sget-object v0, Lr6;->Q:La11;

    .line 683
    .line 684
    invoke-static {v0, p1, p2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 685
    .line 686
    .line 687
    invoke-static {v3, p0, p1, v4}, Lly1;->v(ILyz0;Lla2;Z)V

    .line 688
    .line 689
    .line 690
    goto :goto_6

    .line 691
    :cond_e
    invoke-virtual {p1}, Lla2;->V()V

    .line 692
    .line 693
    .line 694
    :goto_6
    return-object v5

    .line 695
    :pswitch_9
    check-cast p1, Lla2;

    .line 696
    .line 697
    check-cast p2, Ljava/lang/Integer;

    .line 698
    .line 699
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 700
    .line 701
    .line 702
    invoke-static {v4}, Lt36;->a0(I)I

    .line 703
    .line 704
    .line 705
    move-result p0

    .line 706
    invoke-static {p0, p1}, Lpn7;->l(ILla2;)V

    .line 707
    .line 708
    .line 709
    return-object v5

    .line 710
    :pswitch_a
    check-cast p1, Lla2;

    .line 711
    .line 712
    check-cast p2, Ljava/lang/Integer;

    .line 713
    .line 714
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 715
    .line 716
    .line 717
    invoke-static {v4}, Lt36;->a0(I)I

    .line 718
    .line 719
    .line 720
    move-result p0

    .line 721
    invoke-static {p0, p1}, Ljd7;->f(ILla2;)V

    .line 722
    .line 723
    .line 724
    return-object v5

    .line 725
    :pswitch_b
    check-cast p1, Lla2;

    .line 726
    .line 727
    check-cast p2, Ljava/lang/Integer;

    .line 728
    .line 729
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 730
    .line 731
    .line 732
    invoke-static {v4}, Lt36;->a0(I)I

    .line 733
    .line 734
    .line 735
    move-result p0

    .line 736
    invoke-static {p0, p1}, Lzi;->j(ILla2;)V

    .line 737
    .line 738
    .line 739
    return-object v5

    .line 740
    :pswitch_c
    check-cast p1, Lla2;

    .line 741
    .line 742
    check-cast p2, Ljava/lang/Integer;

    .line 743
    .line 744
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 745
    .line 746
    .line 747
    invoke-static {v4}, Lt36;->a0(I)I

    .line 748
    .line 749
    .line 750
    move-result p0

    .line 751
    invoke-static {p0, p1}, Loq;->m(ILla2;)V

    .line 752
    .line 753
    .line 754
    return-object v5

    .line 755
    :pswitch_d
    check-cast p1, Ljz5;

    .line 756
    .line 757
    check-cast p2, Lce2;

    .line 758
    .line 759
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 760
    .line 761
    .line 762
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 763
    .line 764
    .line 765
    iget-object p0, p2, Lce2;->a:Liw4;

    .line 766
    .line 767
    invoke-virtual {p0}, Liw4;->getValue()Ljava/lang/Object;

    .line 768
    .line 769
    .line 770
    move-result-object p0

    .line 771
    check-cast p0, Ljava/lang/Boolean;

    .line 772
    .line 773
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 774
    .line 775
    .line 776
    return-object p0

    .line 777
    :pswitch_e
    check-cast p1, Lee2;

    .line 778
    .line 779
    check-cast p2, Lkz3;

    .line 780
    .line 781
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 782
    .line 783
    .line 784
    instance-of p0, p2, Lfe2;

    .line 785
    .line 786
    if-eqz p0, :cond_f

    .line 787
    .line 788
    check-cast p2, Lfe2;

    .line 789
    .line 790
    iget-object p1, p2, Lfe2;->i:Lee2;

    .line 791
    .line 792
    :cond_f
    return-object p1

    .line 793
    :pswitch_f
    invoke-static {p1, p2}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 794
    .line 795
    .line 796
    move-result p0

    .line 797
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 798
    .line 799
    .line 800
    move-result-object p0

    .line 801
    return-object p0

    .line 802
    :pswitch_10
    check-cast p1, Lmz2;

    .line 803
    .line 804
    check-cast p2, Lmz2;

    .line 805
    .line 806
    return-object v5

    .line 807
    :pswitch_11
    check-cast p1, Lyq1;

    .line 808
    .line 809
    check-cast p2, Lh92;

    .line 810
    .line 811
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 812
    .line 813
    .line 814
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 815
    .line 816
    .line 817
    invoke-interface {p2, p1}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 818
    .line 819
    .line 820
    return-object v5

    .line 821
    :pswitch_12
    check-cast p1, Ljz5;

    .line 822
    .line 823
    check-cast p2, Lyi1;

    .line 824
    .line 825
    invoke-virtual {p2}, Lcv4;->k()I

    .line 826
    .line 827
    .line 828
    move-result p0

    .line 829
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 830
    .line 831
    .line 832
    move-result-object p0

    .line 833
    invoke-virtual {p2}, Lcv4;->l()F

    .line 834
    .line 835
    .line 836
    move-result p1

    .line 837
    const/high16 v0, -0x41000000    # -0.5f

    .line 838
    .line 839
    const/high16 v1, 0x3f000000    # 0.5f

    .line 840
    .line 841
    invoke-static {p1, v0, v1}, Lub3;->y(FFF)F

    .line 842
    .line 843
    .line 844
    move-result p1

    .line 845
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 846
    .line 847
    .line 848
    move-result-object p1

    .line 849
    invoke-virtual {p2}, Lyi1;->n()I

    .line 850
    .line 851
    .line 852
    move-result p2

    .line 853
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 854
    .line 855
    .line 856
    move-result-object p2

    .line 857
    filled-new-array {p0, p1, p2}, [Ljava/lang/Object;

    .line 858
    .line 859
    .line 860
    move-result-object p0

    .line 861
    invoke-static {p0}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 862
    .line 863
    .line 864
    move-result-object p0

    .line 865
    return-object p0

    .line 866
    :pswitch_13
    check-cast p1, Lyd1;

    .line 867
    .line 868
    check-cast p2, Lwd1;

    .line 869
    .line 870
    invoke-interface {p1, p2}, Lyd1;->k(Lyd1;)Lyd1;

    .line 871
    .line 872
    .line 873
    move-result-object p0

    .line 874
    return-object p0

    .line 875
    :pswitch_14
    check-cast p1, Lyd1;

    .line 876
    .line 877
    check-cast p2, Lwd1;

    .line 878
    .line 879
    invoke-interface {p1, p2}, Lyd1;->k(Lyd1;)Lyd1;

    .line 880
    .line 881
    .line 882
    move-result-object p0

    .line 883
    return-object p0

    .line 884
    :pswitch_15
    check-cast p1, Ljava/lang/Boolean;

    .line 885
    .line 886
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 887
    .line 888
    .line 889
    move-result p0

    .line 890
    check-cast p2, Lwd1;

    .line 891
    .line 892
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 893
    .line 894
    .line 895
    move-result-object p0

    .line 896
    return-object p0

    .line 897
    :pswitch_16
    check-cast p1, Lyd1;

    .line 898
    .line 899
    check-cast p2, Lwd1;

    .line 900
    .line 901
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 902
    .line 903
    .line 904
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 905
    .line 906
    .line 907
    invoke-interface {p2}, Lwd1;->getKey()Lxd1;

    .line 908
    .line 909
    .line 910
    move-result-object p0

    .line 911
    invoke-interface {p1, p0}, Lyd1;->A(Lxd1;)Lyd1;

    .line 912
    .line 913
    .line 914
    move-result-object p0

    .line 915
    sget-object p1, Lxw1;->i:Lxw1;

    .line 916
    .line 917
    if-eq p0, p1, :cond_12

    .line 918
    .line 919
    sget-object v0, Lr6;->Z:Lr6;

    .line 920
    .line 921
    invoke-interface {p0, v0}, Lyd1;->p(Lxd1;)Lwd1;

    .line 922
    .line 923
    .line 924
    move-result-object v1

    .line 925
    check-cast v1, Lae1;

    .line 926
    .line 927
    if-nez v1, :cond_10

    .line 928
    .line 929
    new-instance p1, Lby0;

    .line 930
    .line 931
    invoke-direct {p1, p2, p0}, Lby0;-><init>(Lwd1;Lyd1;)V

    .line 932
    .line 933
    .line 934
    :goto_7
    move-object p2, p1

    .line 935
    goto :goto_8

    .line 936
    :cond_10
    invoke-interface {p0, v0}, Lyd1;->A(Lxd1;)Lyd1;

    .line 937
    .line 938
    .line 939
    move-result-object p0

    .line 940
    if-ne p0, p1, :cond_11

    .line 941
    .line 942
    new-instance p0, Lby0;

    .line 943
    .line 944
    invoke-direct {p0, v1, p2}, Lby0;-><init>(Lwd1;Lyd1;)V

    .line 945
    .line 946
    .line 947
    move-object p2, p0

    .line 948
    goto :goto_8

    .line 949
    :cond_11
    new-instance p1, Lby0;

    .line 950
    .line 951
    new-instance v0, Lby0;

    .line 952
    .line 953
    invoke-direct {v0, p2, p0}, Lby0;-><init>(Lwd1;Lyd1;)V

    .line 954
    .line 955
    .line 956
    invoke-direct {p1, v1, v0}, Lby0;-><init>(Lwd1;Lyd1;)V

    .line 957
    .line 958
    .line 959
    goto :goto_7

    .line 960
    :cond_12
    :goto_8
    return-object p2

    .line 961
    :pswitch_17
    check-cast p1, Lla2;

    .line 962
    .line 963
    check-cast p2, Ljava/lang/Integer;

    .line 964
    .line 965
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 966
    .line 967
    .line 968
    invoke-static {v4}, Lt36;->a0(I)I

    .line 969
    .line 970
    .line 971
    move-result p0

    .line 972
    invoke-static {p0, p1}, Luj;->k(ILla2;)V

    .line 973
    .line 974
    .line 975
    return-object v5

    .line 976
    :pswitch_18
    check-cast p1, Lla2;

    .line 977
    .line 978
    check-cast p2, Ljava/lang/Integer;

    .line 979
    .line 980
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 981
    .line 982
    .line 983
    move-result p0

    .line 984
    and-int/lit8 p2, p0, 0x3

    .line 985
    .line 986
    if-eq p2, v2, :cond_13

    .line 987
    .line 988
    move p2, v4

    .line 989
    goto :goto_9

    .line 990
    :cond_13
    move p2, v3

    .line 991
    :goto_9
    and-int/2addr p0, v4

    .line 992
    invoke-virtual {p1, p0, p2}, Lla2;->S(IZ)Z

    .line 993
    .line 994
    .line 995
    move-result p0

    .line 996
    if-eqz p0, :cond_14

    .line 997
    .line 998
    invoke-static {}, Lmb3;->G()Ldv2;

    .line 999
    .line 1000
    .line 1001
    move-result-object p0

    .line 1002
    invoke-static {p0, v4, p1, v3}, Lzi;->k(Ldv2;ZLla2;I)V

    .line 1003
    .line 1004
    .line 1005
    goto :goto_a

    .line 1006
    :cond_14
    invoke-virtual {p1}, Lla2;->V()V

    .line 1007
    .line 1008
    .line 1009
    :goto_a
    return-object v5

    .line 1010
    :pswitch_19
    check-cast p1, Lla2;

    .line 1011
    .line 1012
    check-cast p2, Ljava/lang/Integer;

    .line 1013
    .line 1014
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1015
    .line 1016
    .line 1017
    invoke-static {v4}, Lt36;->a0(I)I

    .line 1018
    .line 1019
    .line 1020
    move-result p0

    .line 1021
    invoke-static {p0, p1}, Lsj;->i(ILla2;)V

    .line 1022
    .line 1023
    .line 1024
    return-object v5

    .line 1025
    :pswitch_1a
    check-cast p1, Lla2;

    .line 1026
    .line 1027
    check-cast p2, Ljava/lang/Integer;

    .line 1028
    .line 1029
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 1030
    .line 1031
    .line 1032
    move-result p0

    .line 1033
    and-int/lit8 p2, p0, 0x3

    .line 1034
    .line 1035
    if-eq p2, v2, :cond_15

    .line 1036
    .line 1037
    move p2, v4

    .line 1038
    goto :goto_b

    .line 1039
    :cond_15
    move p2, v3

    .line 1040
    :goto_b
    and-int/2addr p0, v4

    .line 1041
    invoke-virtual {p1, p0, p2}, Lla2;->S(IZ)Z

    .line 1042
    .line 1043
    .line 1044
    move-result p0

    .line 1045
    if-eqz p0, :cond_16

    .line 1046
    .line 1047
    invoke-static {}, Lub3;->I()Ldv2;

    .line 1048
    .line 1049
    .line 1050
    move-result-object p0

    .line 1051
    invoke-static {p0, v4, p1, v3}, Loq;->n(Ldv2;ZLla2;I)V

    .line 1052
    .line 1053
    .line 1054
    goto :goto_c

    .line 1055
    :cond_16
    invoke-virtual {p1}, Lla2;->V()V

    .line 1056
    .line 1057
    .line 1058
    :goto_c
    return-object v5

    .line 1059
    :pswitch_1b
    check-cast p1, Lla2;

    .line 1060
    .line 1061
    check-cast p2, Ljava/lang/Integer;

    .line 1062
    .line 1063
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1064
    .line 1065
    .line 1066
    invoke-static {v4}, Lt36;->a0(I)I

    .line 1067
    .line 1068
    .line 1069
    move-result p0

    .line 1070
    invoke-static {p0, p1}, Lp51;->a(ILla2;)V

    .line 1071
    .line 1072
    .line 1073
    return-object v5

    .line 1074
    :pswitch_1c
    check-cast p1, Lla2;

    .line 1075
    .line 1076
    check-cast p2, Ljava/lang/Integer;

    .line 1077
    .line 1078
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1079
    .line 1080
    .line 1081
    invoke-static {v4}, Lt36;->a0(I)I

    .line 1082
    .line 1083
    .line 1084
    move-result p0

    .line 1085
    invoke-static {p0, p1}, Lj51;->a(ILla2;)V

    .line 1086
    .line 1087
    .line 1088
    return-object v5

    .line 1089
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
