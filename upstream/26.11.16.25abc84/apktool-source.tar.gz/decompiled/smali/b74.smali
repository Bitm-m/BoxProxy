.class public final synthetic Lb74;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw82;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lb74;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte p0, p0, Lb74;->i:B

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    const/4 v1, 0x0

    .line 5
    packed-switch p0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    sget-object p0, Llf4;->a:Llf4;

    .line 9
    .line 10
    invoke-static {v0}, Llf4;->h(Z)V

    .line 11
    .line 12
    .line 13
    sget-object p0, Loc7;->a:Loc7;

    .line 14
    .line 15
    return-object p0

    .line 16
    :pswitch_0
    sget-object p0, Loc7;->a:Loc7;

    .line 17
    .line 18
    return-object p0

    .line 19
    :pswitch_1
    sget-object p0, Llf4;->a:Llf4;

    .line 20
    .line 21
    invoke-static {v0}, Llf4;->h(Z)V

    .line 22
    .line 23
    .line 24
    sget-object p0, Loc7;->a:Loc7;

    .line 25
    .line 26
    return-object p0

    .line 27
    :pswitch_2
    sget-object p0, Llf4;->l:Lrh5;

    .line 28
    .line 29
    if-eqz p0, :cond_0

    .line 30
    .line 31
    invoke-virtual {p0}, Lrh5;->c()V

    .line 32
    .line 33
    .line 34
    :cond_0
    sget-object p0, Loc7;->a:Loc7;

    .line 35
    .line 36
    return-object p0

    .line 37
    :pswitch_3
    sget-object p0, Llf4;->c:Ljava/util/List;

    .line 38
    .line 39
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    monitor-enter p0

    .line 43
    :try_start_0
    invoke-static {p0}, Liv0;->k1(Ljava/lang/Iterable;)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    monitor-exit p0

    .line 48
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    check-cast v0, Lrh5;

    .line 63
    .line 64
    invoke-virtual {v0}, Lrh5;->c()V

    .line 65
    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_1
    sget-object p0, Loc7;->a:Loc7;

    .line 69
    .line 70
    return-object p0

    .line 71
    :catchall_0
    move-exception v0

    .line 72
    monitor-exit p0

    .line 73
    throw v0

    .line 74
    :pswitch_4
    sget-object p0, Llf4;->b:Luk4;

    .line 75
    .line 76
    iget-object p0, p0, Luk4;->E:Lk12;

    .line 77
    .line 78
    invoke-virtual {p0}, Lk12;->q()V

    .line 79
    .line 80
    .line 81
    sget-object p0, Loc7;->a:Loc7;

    .line 82
    .line 83
    return-object p0

    .line 84
    :pswitch_5
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 85
    .line 86
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0

    .line 91
    :pswitch_6
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 92
    .line 93
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0

    .line 98
    :pswitch_7
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 99
    .line 100
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 101
    .line 102
    .line 103
    move-result-object p0

    .line 104
    return-object p0

    .line 105
    :pswitch_8
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 106
    .line 107
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    return-object p0

    .line 112
    :pswitch_9
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 113
    .line 114
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    return-object p0

    .line 119
    :pswitch_a
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 120
    .line 121
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 122
    .line 123
    .line 124
    move-result-object p0

    .line 125
    return-object p0

    .line 126
    :pswitch_b
    invoke-static {v1}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    return-object p0

    .line 131
    :pswitch_c
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 132
    .line 133
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    return-object p0

    .line 138
    :pswitch_d
    const-string p0, ""

    .line 139
    .line 140
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    return-object p0

    .line 145
    :pswitch_e
    const-string p0, ""

    .line 146
    .line 147
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    return-object p0

    .line 152
    :pswitch_f
    const-string p0, ""

    .line 153
    .line 154
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 155
    .line 156
    .line 157
    move-result-object p0

    .line 158
    return-object p0

    .line 159
    :pswitch_10
    const-string p0, ""

    .line 160
    .line 161
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 162
    .line 163
    .line 164
    move-result-object p0

    .line 165
    return-object p0

    .line 166
    :pswitch_11
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 167
    .line 168
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    return-object p0

    .line 173
    :pswitch_12
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 174
    .line 175
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 176
    .line 177
    .line 178
    move-result-object p0

    .line 179
    return-object p0

    .line 180
    :pswitch_13
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 181
    .line 182
    invoke-static {p0}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 183
    .line 184
    .line 185
    move-result-object p0

    .line 186
    return-object p0

    .line 187
    :pswitch_14
    sget-object p0, Lrb7;->a:Lrb7;

    .line 188
    .line 189
    return-object p0

    .line 190
    :pswitch_15
    sget-object p0, Lbi0;->a:Loh1;

    .line 191
    .line 192
    return-object p0

    .line 193
    :pswitch_16
    sget-object p0, Lhb0;->a:Lzq6;

    .line 194
    .line 195
    invoke-static {}, Lhb0;->b()Luk4;

    .line 196
    .line 197
    .line 198
    move-result-object p0

    .line 199
    invoke-virtual {p0}, Luk4;->a()Ltk4;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    const-wide/16 v0, 0x0

    .line 204
    .line 205
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 206
    .line 207
    invoke-virtual {p0, v0, v1, v2}, Ltk4;->a(JLjava/util/concurrent/TimeUnit;)V

    .line 208
    .line 209
    .line 210
    const-wide/16 v0, 0xf

    .line 211
    .line 212
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 213
    .line 214
    invoke-virtual {p0, v0, v1, v2}, Ltk4;->c(JLjava/util/concurrent/TimeUnit;)V

    .line 215
    .line 216
    .line 217
    new-instance v0, Luk4;

    .line 218
    .line 219
    invoke-direct {v0, p0}, Luk4;-><init>(Ltk4;)V

    .line 220
    .line 221
    .line 222
    return-object v0

    .line 223
    :pswitch_17
    sget-object p0, Lhb0;->a:Lzq6;

    .line 224
    .line 225
    invoke-static {}, Lhb0;->b()Luk4;

    .line 226
    .line 227
    .line 228
    move-result-object p0

    .line 229
    invoke-virtual {p0}, Luk4;->a()Ltk4;

    .line 230
    .line 231
    .line 232
    move-result-object p0

    .line 233
    const/4 v0, 0x0

    .line 234
    iput-boolean v0, p0, Ltk4;->i:Z

    .line 235
    .line 236
    iput-boolean v0, p0, Ltk4;->j:Z

    .line 237
    .line 238
    new-instance v0, Luk4;

    .line 239
    .line 240
    invoke-direct {v0, p0}, Luk4;-><init>(Ltk4;)V

    .line 241
    .line 242
    .line 243
    return-object v0

    .line 244
    :pswitch_18
    sget-object p0, Lxw1;->i:Lxw1;

    .line 245
    .line 246
    invoke-static {p0}, Loq;->k(Lyd1;)Laa1;

    .line 247
    .line 248
    .line 249
    move-result-object p0

    .line 250
    invoke-static {p0, v1}, Loq;->y(Lhe1;Ljava/util/concurrent/CancellationException;)V

    .line 251
    .line 252
    .line 253
    return-object p0

    .line 254
    :pswitch_19
    sget-object p0, Ll84;->i:Ll84;

    .line 255
    .line 256
    new-instance v0, Lk84;

    .line 257
    .line 258
    invoke-direct {v0, p0}, Lk84;-><init>(Ll84;)V

    .line 259
    .line 260
    .line 261
    return-object v0

    .line 262
    :pswitch_1a
    return-object v1

    .line 263
    :pswitch_1b
    sget-object p0, Loc7;->a:Loc7;

    .line 264
    .line 265
    return-object p0

    .line 266
    :pswitch_1c
    sget-object p0, Loc7;->a:Loc7;

    .line 267
    .line 268
    return-object p0

    .line 269
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
