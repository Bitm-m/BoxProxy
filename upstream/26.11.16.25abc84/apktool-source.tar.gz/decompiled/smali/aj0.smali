.class public interface abstract Laj0;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lca1;


# virtual methods
.method public abstract g(Ljava/lang/Object;Lm92;)V
.end method

.method public abstract h(Ljava/lang/Object;Lm92;)Llw1;
.end method

.method public abstract n(Ljava/lang/Throwable;)Z
.end method

.method public abstract s(Ljava/lang/Object;)V
.end method
