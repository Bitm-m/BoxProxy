.class public final La05;
.super Lda1;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public j:I


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La05;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, La05;->j:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, La05;->j:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-static {p1, p1, p0}, Lb05;->b(Lpa;Ll92;Lda1;)V

    .line 12
    .line 13
    .line 14
    sget-object p0, Lie1;->i:Lie1;

    .line 15
    .line 16
    return-object p0
.end method
