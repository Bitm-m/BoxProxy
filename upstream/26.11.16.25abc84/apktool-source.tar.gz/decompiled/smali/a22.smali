.class public abstract La22;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lbo4;

.field public static final b:Lq9;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Lu60;->E()Lbo4;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sput-object v0, La22;->a:Lbo4;

    .line 6
    .line 7
    new-instance v0, Lq9;

    .line 8
    .line 9
    const/16 v1, 0x12

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lq9;-><init>(B)V

    .line 12
    .line 13
    .line 14
    sput-object v0, La22;->b:Lq9;

    .line 15
    .line 16
    return-void
.end method
