.class public interface abstract Lbe1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lwd1;


# virtual methods
.method public abstract q(Lyd1;Ljava/lang/Throwable;)V
.end method
