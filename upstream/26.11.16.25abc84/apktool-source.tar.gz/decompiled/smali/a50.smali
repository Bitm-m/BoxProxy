.class public final synthetic La50;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:Lb34;

.field public final synthetic j:Lb34;

.field public final synthetic k:Lhe1;

.field public final synthetic l:Lkg;

.field public final synthetic m:Llk1;

.field public final synthetic n:Z

.field public final synthetic o:Lw82;

.field public final synthetic p:Lfw4;

.field public final synthetic q:Lew4;

.field public final synthetic r:Lb34;

.field public final synthetic s:Lh92;


# direct methods
.method public synthetic constructor <init>(Lb34;Lb34;Lhe1;Lkg;Llk1;ZLw82;Lfw4;Lew4;Lb34;Lh92;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La50;->i:Lb34;

    .line 5
    .line 6
    iput-object p2, p0, La50;->j:Lb34;

    .line 7
    .line 8
    iput-object p3, p0, La50;->k:Lhe1;

    .line 9
    .line 10
    iput-object p4, p0, La50;->l:Lkg;

    .line 11
    .line 12
    iput-object p5, p0, La50;->m:Llk1;

    .line 13
    .line 14
    iput-boolean p6, p0, La50;->n:Z

    .line 15
    .line 16
    iput-object p7, p0, La50;->o:Lw82;

    .line 17
    .line 18
    iput-object p8, p0, La50;->p:Lfw4;

    .line 19
    .line 20
    iput-object p9, p0, La50;->q:Lew4;

    .line 21
    .line 22
    iput-object p10, p0, La50;->r:Lb34;

    .line 23
    .line 24
    iput-object p11, p0, La50;->s:Lh92;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    check-cast p1, Ljava/lang/Float;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 4
    .line 5
    .line 6
    move-result v4

    .line 7
    iget-object p1, p0, La50;->i:Lb34;

    .line 8
    .line 9
    invoke-interface {p1}, Lok6;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Lo23;

    .line 14
    .line 15
    const/4 v12, 0x0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-interface {v0, v12}, Lo23;->c(Ljava/util/concurrent/CancellationException;)V

    .line 19
    .line 20
    .line 21
    :cond_0
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 22
    .line 23
    iget-object v8, p0, La50;->j:Lb34;

    .line 24
    .line 25
    invoke-interface {v8, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Lj50;

    .line 29
    .line 30
    const/4 v11, 0x0

    .line 31
    iget-object v1, p0, La50;->l:Lkg;

    .line 32
    .line 33
    iget-object v2, p0, La50;->m:Llk1;

    .line 34
    .line 35
    iget-boolean v3, p0, La50;->n:Z

    .line 36
    .line 37
    iget-object v5, p0, La50;->o:Lw82;

    .line 38
    .line 39
    iget-object v6, p0, La50;->p:Lfw4;

    .line 40
    .line 41
    iget-object v7, p0, La50;->q:Lew4;

    .line 42
    .line 43
    iget-object v9, p0, La50;->r:Lb34;

    .line 44
    .line 45
    iget-object v10, p0, La50;->s:Lh92;

    .line 46
    .line 47
    invoke-direct/range {v0 .. v11}, Lj50;-><init>(Lkg;Llk1;ZFLw82;Lfw4;Lew4;Lb34;Lb34;Lh92;Lca1;)V

    .line 48
    .line 49
    .line 50
    const/4 v1, 0x3

    .line 51
    iget-object p0, p0, La50;->k:Lhe1;

    .line 52
    .line 53
    invoke-static {p0, v12, v12, v0, v1}, Llm;->Z(Lhe1;Lb3;Lke1;Ll92;I)Lek6;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    invoke-interface {p1, p0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    sget-object p0, Loc7;->a:Loc7;

    .line 61
    .line 62
    return-object p0
.end method
