.class public final synthetic Lai7;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw82;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lh92;

.field public final synthetic k:Leq3;


# direct methods
.method public synthetic constructor <init>(Lh92;Leq3;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lai7;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lai7;->j:Lh92;

    .line 4
    .line 5
    iput-object p2, p0, Lai7;->k:Leq3;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lai7;->i:B

    .line 2
    .line 3
    sget-object v1, Loc7;->a:Loc7;

    .line 4
    .line 5
    iget-object v2, p0, Lai7;->k:Leq3;

    .line 6
    .line 7
    iget-object p0, p0, Lai7;->j:Lh92;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v0, v2, Leq3;->a:Ljava/lang/String;

    .line 13
    .line 14
    invoke-interface {p0, v0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    return-object v1

    .line 18
    :pswitch_0
    iget-object v0, v2, Leq3;->a:Ljava/lang/String;

    .line 19
    .line 20
    invoke-interface {p0, v0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    return-object v1

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
