.class public interface abstract Lb94;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# virtual methods
.method public abstract a(Landroid/view/View;Landroid/view/View;II)V
.end method

.method public abstract b(Landroid/view/View;I)V
.end method

.method public abstract d(II[II)V
.end method

.method public abstract e(Landroidx/core/widget/NestedScrollView;IIIII)V
.end method

.method public abstract i(Landroid/view/View;Landroid/view/View;II)Z
.end method
