.class public final Lac5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ln92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/List;

.field public final synthetic k:Ljd5;

.field public final synthetic l:Ljava/util/Set;

.field public final synthetic m:Lud5;

.field public final synthetic n:I

.field public final synthetic o:Ljava/util/Map;

.field public final synthetic p:Ljava/util/Map;

.field public final synthetic q:Z

.field public final synthetic r:Lb34;

.field public final synthetic s:Lh92;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljd5;Ljava/util/Set;Lud5;ILjava/util/Map;Ljava/util/Map;ZLb34;Lh92;B)V
    .locals 0

    .line 1
    iput-byte p11, p0, Lac5;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lac5;->j:Ljava/util/List;

    .line 4
    .line 5
    iput-object p2, p0, Lac5;->k:Ljd5;

    .line 6
    .line 7
    iput-object p3, p0, Lac5;->l:Ljava/util/Set;

    .line 8
    .line 9
    iput-object p4, p0, Lac5;->m:Lud5;

    .line 10
    .line 11
    iput p5, p0, Lac5;->n:I

    .line 12
    .line 13
    iput-object p6, p0, Lac5;->o:Ljava/util/Map;

    .line 14
    .line 15
    iput-object p7, p0, Lac5;->p:Ljava/util/Map;

    .line 16
    .line 17
    iput-boolean p8, p0, Lac5;->q:Z

    .line 18
    .line 19
    iput-object p9, p0, Lac5;->r:Lb34;

    .line 20
    .line 21
    iput-object p10, p0, Lac5;->s:Lh92;

    .line 22
    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lac5;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    iget-object v3, v0, Lac5;->j:Ljava/util/List;

    .line 8
    .line 9
    const/16 v4, 0x92

    .line 10
    .line 11
    const/16 v5, 0x10

    .line 12
    .line 13
    const/16 v6, 0x20

    .line 14
    .line 15
    const/4 v7, 0x2

    .line 16
    const/4 v8, 0x4

    .line 17
    const/4 v9, 0x1

    .line 18
    const/4 v10, 0x0

    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object/from16 v1, p1

    .line 23
    .line 24
    check-cast v1, Lla3;

    .line 25
    .line 26
    move-object/from16 v11, p2

    .line 27
    .line 28
    check-cast v11, Ljava/lang/Number;

    .line 29
    .line 30
    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v11

    .line 34
    move-object/from16 v12, p3

    .line 35
    .line 36
    check-cast v12, Lla2;

    .line 37
    .line 38
    move-object/from16 v13, p4

    .line 39
    .line 40
    check-cast v13, Ljava/lang/Number;

    .line 41
    .line 42
    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    .line 43
    .line 44
    .line 45
    move-result v13

    .line 46
    and-int/lit8 v14, v13, 0x6

    .line 47
    .line 48
    if-nez v14, :cond_1

    .line 49
    .line 50
    invoke-virtual {v12, v1}, Lla2;->g(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_0

    .line 55
    .line 56
    move v7, v8

    .line 57
    :cond_0
    or-int/2addr v7, v13

    .line 58
    goto :goto_0

    .line 59
    :cond_1
    move v7, v13

    .line 60
    :goto_0
    and-int/lit8 v13, v13, 0x30

    .line 61
    .line 62
    if-nez v13, :cond_3

    .line 63
    .line 64
    invoke-virtual {v12, v11}, Lla2;->e(I)Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    if-eqz v1, :cond_2

    .line 69
    .line 70
    move v5, v6

    .line 71
    :cond_2
    or-int/2addr v7, v5

    .line 72
    :cond_3
    and-int/lit16 v1, v7, 0x93

    .line 73
    .line 74
    if-eq v1, v4, :cond_4

    .line 75
    .line 76
    move v1, v9

    .line 77
    goto :goto_1

    .line 78
    :cond_4
    move v1, v10

    .line 79
    :goto_1
    and-int/2addr v7, v9

    .line 80
    invoke-virtual {v12, v7, v1}, Lla2;->S(IZ)Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-eqz v1, :cond_5

    .line 85
    .line 86
    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    move-object v14, v1

    .line 91
    check-cast v14, Lyc5;

    .line 92
    .line 93
    const v1, -0x61b8f595

    .line 94
    .line 95
    .line 96
    invoke-virtual {v12, v1}, Lla2;->b0(I)V

    .line 97
    .line 98
    .line 99
    iget-boolean v1, v14, Lyc5;->f:Z

    .line 100
    .line 101
    iget-boolean v3, v14, Lyc5;->g:Z

    .line 102
    .line 103
    new-instance v13, Lxb5;

    .line 104
    .line 105
    iget-object v4, v0, Lac5;->s:Lh92;

    .line 106
    .line 107
    const/16 v24, 0x1

    .line 108
    .line 109
    iget-object v15, v0, Lac5;->k:Ljd5;

    .line 110
    .line 111
    iget-object v5, v0, Lac5;->l:Ljava/util/Set;

    .line 112
    .line 113
    iget-object v6, v0, Lac5;->m:Lud5;

    .line 114
    .line 115
    iget v7, v0, Lac5;->n:I

    .line 116
    .line 117
    iget-object v8, v0, Lac5;->o:Ljava/util/Map;

    .line 118
    .line 119
    iget-object v9, v0, Lac5;->p:Ljava/util/Map;

    .line 120
    .line 121
    iget-boolean v11, v0, Lac5;->q:Z

    .line 122
    .line 123
    iget-object v0, v0, Lac5;->r:Lb34;

    .line 124
    .line 125
    move-object/from16 v22, v0

    .line 126
    .line 127
    move-object/from16 v23, v4

    .line 128
    .line 129
    move-object/from16 v16, v5

    .line 130
    .line 131
    move-object/from16 v17, v6

    .line 132
    .line 133
    move/from16 v18, v7

    .line 134
    .line 135
    move-object/from16 v19, v8

    .line 136
    .line 137
    move-object/from16 v20, v9

    .line 138
    .line 139
    move/from16 v21, v11

    .line 140
    .line 141
    invoke-direct/range {v13 .. v24}, Lxb5;-><init>(Lyc5;Ljd5;Ljava/util/Set;Lud5;ILjava/util/Map;Ljava/util/Map;ZLb34;Lh92;B)V

    .line 142
    .line 143
    .line 144
    const v0, 0x4d32de8f    # 1.87558128E8f

    .line 145
    .line 146
    .line 147
    invoke-static {v0, v13, v12}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 148
    .line 149
    .line 150
    move-result-object v15

    .line 151
    const/16 v17, 0xc00

    .line 152
    .line 153
    const/4 v14, 0x0

    .line 154
    move v13, v3

    .line 155
    move-object/from16 v16, v12

    .line 156
    .line 157
    move v12, v1

    .line 158
    invoke-static/range {v12 .. v17}, Ljd7;->n(ZZLmz3;Lyz0;Lla2;I)V

    .line 159
    .line 160
    .line 161
    move-object/from16 v0, v16

    .line 162
    .line 163
    invoke-virtual {v0, v10}, Lla2;->r(Z)V

    .line 164
    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_5
    move-object v0, v12

    .line 168
    invoke-virtual {v0}, Lla2;->V()V

    .line 169
    .line 170
    .line 171
    :goto_2
    return-object v2

    .line 172
    :pswitch_0
    move-object/from16 v1, p1

    .line 173
    .line 174
    check-cast v1, Lla3;

    .line 175
    .line 176
    move-object/from16 v11, p2

    .line 177
    .line 178
    check-cast v11, Ljava/lang/Number;

    .line 179
    .line 180
    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    .line 181
    .line 182
    .line 183
    move-result v11

    .line 184
    move-object/from16 v12, p3

    .line 185
    .line 186
    check-cast v12, Lla2;

    .line 187
    .line 188
    move-object/from16 v13, p4

    .line 189
    .line 190
    check-cast v13, Ljava/lang/Number;

    .line 191
    .line 192
    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    .line 193
    .line 194
    .line 195
    move-result v13

    .line 196
    and-int/lit8 v14, v13, 0x6

    .line 197
    .line 198
    if-nez v14, :cond_7

    .line 199
    .line 200
    invoke-virtual {v12, v1}, Lla2;->g(Ljava/lang/Object;)Z

    .line 201
    .line 202
    .line 203
    move-result v1

    .line 204
    if-eqz v1, :cond_6

    .line 205
    .line 206
    move v7, v8

    .line 207
    :cond_6
    or-int/2addr v7, v13

    .line 208
    goto :goto_3

    .line 209
    :cond_7
    move v7, v13

    .line 210
    :goto_3
    and-int/lit8 v13, v13, 0x30

    .line 211
    .line 212
    if-nez v13, :cond_9

    .line 213
    .line 214
    invoke-virtual {v12, v11}, Lla2;->e(I)Z

    .line 215
    .line 216
    .line 217
    move-result v1

    .line 218
    if-eqz v1, :cond_8

    .line 219
    .line 220
    move v5, v6

    .line 221
    :cond_8
    or-int/2addr v7, v5

    .line 222
    :cond_9
    and-int/lit16 v1, v7, 0x93

    .line 223
    .line 224
    if-eq v1, v4, :cond_a

    .line 225
    .line 226
    move v1, v9

    .line 227
    goto :goto_4

    .line 228
    :cond_a
    move v1, v10

    .line 229
    :goto_4
    and-int/2addr v7, v9

    .line 230
    invoke-virtual {v12, v7, v1}, Lla2;->S(IZ)Z

    .line 231
    .line 232
    .line 233
    move-result v1

    .line 234
    if-eqz v1, :cond_b

    .line 235
    .line 236
    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    move-object v14, v1

    .line 241
    check-cast v14, Lyc5;

    .line 242
    .line 243
    const v1, -0x612abaf0

    .line 244
    .line 245
    .line 246
    invoke-virtual {v12, v1}, Lla2;->b0(I)V

    .line 247
    .line 248
    .line 249
    iget-object v15, v0, Lac5;->k:Ljd5;

    .line 250
    .line 251
    iget-boolean v1, v15, Ljd5;->k:Z

    .line 252
    .line 253
    iget-boolean v3, v14, Lyc5;->f:Z

    .line 254
    .line 255
    iget-boolean v4, v14, Lyc5;->g:Z

    .line 256
    .line 257
    new-instance v13, Lxb5;

    .line 258
    .line 259
    iget-object v5, v0, Lac5;->s:Lh92;

    .line 260
    .line 261
    const/16 v24, 0x0

    .line 262
    .line 263
    iget-object v6, v0, Lac5;->l:Ljava/util/Set;

    .line 264
    .line 265
    iget-object v7, v0, Lac5;->m:Lud5;

    .line 266
    .line 267
    iget v8, v0, Lac5;->n:I

    .line 268
    .line 269
    iget-object v9, v0, Lac5;->o:Ljava/util/Map;

    .line 270
    .line 271
    iget-object v11, v0, Lac5;->p:Ljava/util/Map;

    .line 272
    .line 273
    iget-boolean v10, v0, Lac5;->q:Z

    .line 274
    .line 275
    iget-object v0, v0, Lac5;->r:Lb34;

    .line 276
    .line 277
    move-object/from16 v22, v0

    .line 278
    .line 279
    move-object/from16 v23, v5

    .line 280
    .line 281
    move-object/from16 v16, v6

    .line 282
    .line 283
    move-object/from16 v17, v7

    .line 284
    .line 285
    move/from16 v18, v8

    .line 286
    .line 287
    move-object/from16 v19, v9

    .line 288
    .line 289
    move/from16 v21, v10

    .line 290
    .line 291
    move-object/from16 v20, v11

    .line 292
    .line 293
    invoke-direct/range {v13 .. v24}, Lxb5;-><init>(Lyc5;Ljd5;Ljava/util/Set;Lud5;ILjava/util/Map;Ljava/util/Map;ZLb34;Lh92;B)V

    .line 294
    .line 295
    .line 296
    const v0, -0x22b3d15

    .line 297
    .line 298
    .line 299
    invoke-static {v0, v13, v12}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 300
    .line 301
    .line 302
    move-result-object v16

    .line 303
    const/16 v18, 0x6000

    .line 304
    .line 305
    const/4 v15, 0x0

    .line 306
    move v13, v3

    .line 307
    move v14, v4

    .line 308
    move-object/from16 v17, v12

    .line 309
    .line 310
    move v12, v1

    .line 311
    invoke-static/range {v12 .. v18}, Lub3;->c(ZZZLmz3;Lyz0;Lla2;I)V

    .line 312
    .line 313
    .line 314
    move-object/from16 v0, v17

    .line 315
    .line 316
    const/4 v1, 0x0

    .line 317
    invoke-virtual {v0, v1}, Lla2;->r(Z)V

    .line 318
    .line 319
    .line 320
    goto :goto_5

    .line 321
    :cond_b
    move-object v0, v12

    .line 322
    invoke-virtual {v0}, Lla2;->V()V

    .line 323
    .line 324
    .line 325
    :goto_5
    return-object v2

    .line 326
    nop

    .line 327
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
