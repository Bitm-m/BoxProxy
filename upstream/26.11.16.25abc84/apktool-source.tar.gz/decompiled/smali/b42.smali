.class public final Lb42;
.super Lda1;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public i:Lx32;

.field public j:Lon0;

.field public k:Lue0;

.field public l:Z

.field public synthetic m:Ljava/lang/Object;

.field public n:I


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lb42;->m:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lb42;->n:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lb42;->n:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {p1, p1, v0, p0}, Lom;->J(Lx32;Lon0;ZLca1;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
