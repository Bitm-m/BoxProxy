.class public final Lb95;
.super Lhq6;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public i:Z

.field public final synthetic j:Lsc3;

.field public final synthetic k:I

.field public final synthetic l:Ljava/util/List;

.field public final synthetic m:Ljava/lang/String;

.field public final synthetic n:I

.field public final synthetic o:Ljava/util/List;

.field public final synthetic p:I

.field public final synthetic q:Z

.field public final synthetic r:Ljava/util/Set;

.field public final synthetic s:Lbd5;

.field public final synthetic t:Ljava/util/Map;

.field public final synthetic u:Ljava/util/Map;

.field public final synthetic v:Ljava/util/Map;

.field public final synthetic w:B

.field public final synthetic x:I


# direct methods
.method public constructor <init>(Lsc3;ILjava/util/List;Ljava/lang/String;ILjava/util/List;IZLjava/util/Set;Lbd5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;IILca1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lb95;->j:Lsc3;

    .line 2
    .line 3
    iput p2, p0, Lb95;->k:I

    .line 4
    .line 5
    iput-object p3, p0, Lb95;->l:Ljava/util/List;

    .line 6
    .line 7
    iput-object p4, p0, Lb95;->m:Ljava/lang/String;

    .line 8
    .line 9
    iput p5, p0, Lb95;->n:I

    .line 10
    .line 11
    iput-object p6, p0, Lb95;->o:Ljava/util/List;

    .line 12
    .line 13
    iput p7, p0, Lb95;->p:I

    .line 14
    .line 15
    iput-boolean p8, p0, Lb95;->q:Z

    .line 16
    .line 17
    iput-object p9, p0, Lb95;->r:Ljava/util/Set;

    .line 18
    .line 19
    iput-object p10, p0, Lb95;->s:Lbd5;

    .line 20
    .line 21
    iput-object p11, p0, Lb95;->t:Ljava/util/Map;

    .line 22
    .line 23
    iput-object p12, p0, Lb95;->u:Ljava/util/Map;

    .line 24
    .line 25
    iput-object p13, p0, Lb95;->v:Ljava/util/Map;

    .line 26
    .line 27
    iput-byte p14, p0, Lb95;->w:B

    .line 28
    .line 29
    iput p15, p0, Lb95;->x:I

    .line 30
    .line 31
    const/4 p1, 0x2

    .line 32
    move-object/from16 p2, p16

    .line 33
    .line 34
    invoke-direct {p0, p1, p2}, Lhq6;-><init>(ILca1;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lca1;)Lca1;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Lb95;

    .line 4
    .line 5
    iget-byte v14, v0, Lb95;->w:B

    .line 6
    .line 7
    iget v15, v0, Lb95;->x:I

    .line 8
    .line 9
    move-object v2, v1

    .line 10
    iget-object v1, v0, Lb95;->j:Lsc3;

    .line 11
    .line 12
    move-object v3, v2

    .line 13
    iget v2, v0, Lb95;->k:I

    .line 14
    .line 15
    move-object v4, v3

    .line 16
    iget-object v3, v0, Lb95;->l:Ljava/util/List;

    .line 17
    .line 18
    move-object v5, v4

    .line 19
    iget-object v4, v0, Lb95;->m:Ljava/lang/String;

    .line 20
    .line 21
    move-object v6, v5

    .line 22
    iget v5, v0, Lb95;->n:I

    .line 23
    .line 24
    move-object v7, v6

    .line 25
    iget-object v6, v0, Lb95;->o:Ljava/util/List;

    .line 26
    .line 27
    move-object v8, v7

    .line 28
    iget v7, v0, Lb95;->p:I

    .line 29
    .line 30
    move-object v9, v8

    .line 31
    iget-boolean v8, v0, Lb95;->q:Z

    .line 32
    .line 33
    move-object v10, v9

    .line 34
    iget-object v9, v0, Lb95;->r:Ljava/util/Set;

    .line 35
    .line 36
    move-object v11, v10

    .line 37
    iget-object v10, v0, Lb95;->s:Lbd5;

    .line 38
    .line 39
    move-object v12, v11

    .line 40
    iget-object v11, v0, Lb95;->t:Ljava/util/Map;

    .line 41
    .line 42
    move-object v13, v12

    .line 43
    iget-object v12, v0, Lb95;->u:Ljava/util/Map;

    .line 44
    .line 45
    iget-object v0, v0, Lb95;->v:Ljava/util/Map;

    .line 46
    .line 47
    move-object/from16 v16, v13

    .line 48
    .line 49
    move-object v13, v0

    .line 50
    move-object/from16 v0, v16

    .line 51
    .line 52
    move-object/from16 v16, p2

    .line 53
    .line 54
    invoke-direct/range {v0 .. v16}, Lb95;-><init>(Lsc3;ILjava/util/List;Ljava/lang/String;ILjava/util/List;IZLjava/util/Set;Lbd5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;IILca1;)V

    .line 55
    .line 56
    .line 57
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lhe1;

    .line 2
    .line 3
    check-cast p2, Lca1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lb95;->create(Ljava/lang/Object;Lca1;)Lca1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lb95;

    .line 10
    .line 11
    sget-object p1, Loc7;->a:Loc7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lb95;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget-boolean v0, p0, Lb95;->i:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lcb3;->L(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_1
    invoke-static {p1}, Lcb3;->L(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p0, Lb95;->m:Ljava/lang/String;

    .line 23
    .line 24
    iget v0, p0, Lb95;->n:I

    .line 25
    .line 26
    iget-object v2, p0, Lb95;->l:Ljava/util/List;

    .line 27
    .line 28
    invoke-static {v0, p1, v2}, Lva3;->R(ILjava/lang/String;Ljava/util/List;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iget-byte v12, p0, Lb95;->w:B

    .line 33
    .line 34
    iget v13, p0, Lb95;->x:I

    .line 35
    .line 36
    iget-object v2, p0, Lb95;->l:Ljava/util/List;

    .line 37
    .line 38
    iget-object v3, p0, Lb95;->o:Ljava/util/List;

    .line 39
    .line 40
    iget v4, p0, Lb95;->p:I

    .line 41
    .line 42
    iget v5, p0, Lb95;->n:I

    .line 43
    .line 44
    iget-boolean v6, p0, Lb95;->q:Z

    .line 45
    .line 46
    iget-object v7, p0, Lb95;->r:Ljava/util/Set;

    .line 47
    .line 48
    iget-object v8, p0, Lb95;->s:Lbd5;

    .line 49
    .line 50
    iget-object v9, p0, Lb95;->t:Ljava/util/Map;

    .line 51
    .line 52
    iget-object v10, p0, Lb95;->u:Ljava/util/Map;

    .line 53
    .line 54
    iget-object v11, p0, Lb95;->v:Ljava/util/Map;

    .line 55
    .line 56
    invoke-static/range {v2 .. v13}, Lab3;->Y(Ljava/util/List;Ljava/util/List;IIZLjava/util/Set;Lbd5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;II)I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    new-instance v2, Ljava/lang/Integer;

    .line 61
    .line 62
    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 63
    .line 64
    .line 65
    iput-boolean v1, p0, Lb95;->i:Z

    .line 66
    .line 67
    iget-object v0, p0, Lb95;->j:Lsc3;

    .line 68
    .line 69
    iget v1, p0, Lb95;->k:I

    .line 70
    .line 71
    invoke-static {v0, v1, p1, v2, p0}, Lab3;->C(Lsc3;ILjava/lang/String;Ljava/lang/Integer;Lda1;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    sget-object p1, Lie1;->i:Lie1;

    .line 76
    .line 77
    if-ne p0, p1, :cond_2

    .line 78
    .line 79
    return-object p1

    .line 80
    :cond_2
    :goto_0
    sget-object p0, Loc7;->a:Loc7;

    .line 81
    .line 82
    return-object p0
.end method
