.class public final Lb31;
.super Ln55;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public final b:Lc31;


# direct methods
.method public constructor <init>(Lh92;)V
    .locals 2

    .line 1
    new-instance v0, Ly21;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1}, Ly21;-><init>(B)V

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, v0}, Ln55;-><init>(Lw82;)V

    .line 8
    .line 9
    .line 10
    new-instance v0, Lc31;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Lc31;-><init>(Lh92;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lb31;->b:Lc31;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final b()Lud7;
    .locals 0

    .line 1
    iget-object p0, p0, Lb31;->b:Lc31;

    .line 2
    .line 3
    return-object p0
.end method
