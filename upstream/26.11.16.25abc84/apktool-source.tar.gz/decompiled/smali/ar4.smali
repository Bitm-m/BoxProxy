.class public final synthetic Lar4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lhe1;


# direct methods
.method public synthetic constructor <init>(Lhe1;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lar4;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lar4;->j:Lhe1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lar4;->i:B

    .line 2
    .line 3
    iget-object p0, p0, Lar4;->j:Lhe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Ljava/util/List;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Lgw5;

    .line 14
    .line 15
    invoke-direct {v0, p0}, Lgw5;-><init>(Lhe1;)V

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    check-cast p0, Ljava/lang/String;

    .line 27
    .line 28
    iget-object v1, v0, Lgw5;->d:Liw4;

    .line 29
    .line 30
    invoke-virtual {v1, p0}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    sget-object p0, Lty5;->a:Lty5;

    .line 34
    .line 35
    invoke-virtual {v0}, Lgw5;->e()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-static {p0}, Lty5;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    iget-object v1, v0, Lgw5;->e:Liw4;

    .line 44
    .line 45
    invoke-virtual {v1, p0}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    const/4 p0, 0x1

    .line 49
    invoke-interface {p1, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    check-cast v1, Ljava/lang/Integer;

    .line 57
    .line 58
    iget-object v2, v0, Lgw5;->j:Liw4;

    .line 59
    .line 60
    invoke-virtual {v2, v1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    const/4 v1, 0x2

    .line 64
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    check-cast p1, Ljava/lang/Integer;

    .line 72
    .line 73
    iget-object v1, v0, Lgw5;->k:Liw4;

    .line 74
    .line 75
    invoke-virtual {v1, p1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iget-object p1, v0, Lgw5;->l:Liw4;

    .line 79
    .line 80
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 81
    .line 82
    invoke-virtual {p1, v1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v0, p0}, Lgw5;->q(Z)V

    .line 86
    .line 87
    .line 88
    return-object v0

    .line 89
    :pswitch_0
    check-cast p1, Lh92;

    .line 90
    .line 91
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    new-instance v0, Ll50;

    .line 95
    .line 96
    const/4 v1, 0x5

    .line 97
    const/4 v2, 0x0

    .line 98
    invoke-direct {v0, p1, v2, v1}, Ll50;-><init>(Lh92;Lca1;B)V

    .line 99
    .line 100
    .line 101
    const/4 p1, 0x3

    .line 102
    invoke-static {p0, v2, v2, v0, p1}, Llm;->Z(Lhe1;Lb3;Lke1;Ll92;I)Lek6;

    .line 103
    .line 104
    .line 105
    sget-object p0, Loc7;->a:Loc7;

    .line 106
    .line 107
    return-object p0

    .line 108
    nop

    .line 109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
