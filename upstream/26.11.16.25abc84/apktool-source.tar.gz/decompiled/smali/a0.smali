.class public final synthetic La0;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lrd3;

.field public final synthetic k:Lsc3;

.field public final synthetic l:Lbt4;

.field public final synthetic m:Lmz3;


# direct methods
.method public synthetic constructor <init>(Lrd3;Lbt4;Lsc3;Lmz3;I)V
    .locals 0

    .line 16
    const/4 p5, 0x0

    iput-byte p5, p0, La0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La0;->j:Lrd3;

    iput-object p2, p0, La0;->l:Lbt4;

    iput-object p3, p0, La0;->k:Lsc3;

    iput-object p4, p0, La0;->m:Lmz3;

    return-void
.end method

.method public synthetic constructor <init>(Lrd3;Lsc3;Lbt4;Lmz3;I)V
    .locals 0

    .line 1
    const/4 p5, 0x1

    .line 2
    iput-byte p5, p0, La0;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La0;->j:Lrd3;

    .line 8
    .line 9
    iput-object p2, p0, La0;->k:Lsc3;

    .line 10
    .line 11
    iput-object p3, p0, La0;->l:Lbt4;

    .line 12
    .line 13
    iput-object p4, p0, La0;->m:Lmz3;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La0;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    packed-switch v1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    move-object/from16 v5, p1

    .line 12
    .line 13
    check-cast v5, Lla2;

    .line 14
    .line 15
    move-object/from16 v1, p2

    .line 16
    .line 17
    check-cast v1, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {v3}, Lt36;->a0(I)I

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    iget-object v6, v0, La0;->k:Lsc3;

    .line 27
    .line 28
    iget-object v7, v0, La0;->j:Lrd3;

    .line 29
    .line 30
    iget-object v8, v0, La0;->m:Lmz3;

    .line 31
    .line 32
    iget-object v9, v0, La0;->l:Lbt4;

    .line 33
    .line 34
    invoke-static/range {v4 .. v9}, Lfw;->a(ILla2;Lsc3;Lrd3;Lmz3;Lbt4;)V

    .line 35
    .line 36
    .line 37
    return-object v2

    .line 38
    :pswitch_0
    move-object/from16 v11, p1

    .line 39
    .line 40
    check-cast v11, Lla2;

    .line 41
    .line 42
    move-object/from16 v1, p2

    .line 43
    .line 44
    check-cast v1, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    invoke-static {v3}, Lt36;->a0(I)I

    .line 50
    .line 51
    .line 52
    move-result v10

    .line 53
    iget-object v12, v0, La0;->k:Lsc3;

    .line 54
    .line 55
    iget-object v13, v0, La0;->j:Lrd3;

    .line 56
    .line 57
    iget-object v14, v0, La0;->m:Lmz3;

    .line 58
    .line 59
    iget-object v15, v0, La0;->l:Lbt4;

    .line 60
    .line 61
    invoke-static/range {v10 .. v15}, Lnn3;->E(ILla2;Lsc3;Lrd3;Lmz3;Lbt4;)V

    .line 62
    .line 63
    .line 64
    return-object v2

    .line 65
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
