.class public final synthetic Lay5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lgw5;

.field public final synthetic k:Ljava/util/ArrayList;

.field public final synthetic l:Ljava/util/ArrayList;

.field public final synthetic m:Ln53;

.field public final synthetic n:Lzy5;


# direct methods
.method public synthetic constructor <init>(Lgw5;Ljava/util/ArrayList;Ljava/util/ArrayList;Ln53;Lzy5;B)V
    .locals 0

    .line 1
    iput-byte p6, p0, Lay5;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lay5;->j:Lgw5;

    .line 4
    .line 5
    iput-object p2, p0, Lay5;->k:Ljava/util/ArrayList;

    .line 6
    .line 7
    iput-object p3, p0, Lay5;->l:Ljava/util/ArrayList;

    .line 8
    .line 9
    iput-object p4, p0, Lay5;->m:Ln53;

    .line 10
    .line 11
    iput-object p5, p0, Lay5;->n:Lzy5;

    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lay5;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x0

    .line 9
    const/4 v5, 0x1

    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget-object v6, Lvx0;->b:Lvx0;

    .line 14
    .line 15
    move-object/from16 v13, p1

    .line 16
    .line 17
    check-cast v13, Lla2;

    .line 18
    .line 19
    move-object/from16 v1, p2

    .line 20
    .line 21
    check-cast v1, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    and-int/lit8 v7, v1, 0x3

    .line 28
    .line 29
    if-eq v7, v3, :cond_0

    .line 30
    .line 31
    move v7, v5

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    move v7, v4

    .line 34
    :goto_0
    and-int/2addr v1, v5

    .line 35
    invoke-virtual {v13, v1, v7}, Lla2;->S(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_4

    .line 40
    .line 41
    iget-object v1, v0, Lay5;->j:Lgw5;

    .line 42
    .line 43
    invoke-virtual {v1}, Lgw5;->d()Z

    .line 44
    .line 45
    .line 46
    move-result v7

    .line 47
    iget-object v8, v0, Lay5;->m:Ln53;

    .line 48
    .line 49
    if-eqz v7, :cond_3

    .line 50
    .line 51
    const v7, -0x6dea147c

    .line 52
    .line 53
    .line 54
    invoke-virtual {v13, v7}, Lla2;->b0(I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v13, v1}, Lla2;->g(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v7

    .line 61
    iget-object v9, v0, Lay5;->l:Ljava/util/ArrayList;

    .line 62
    .line 63
    invoke-virtual {v13, v9}, Lla2;->i(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v10

    .line 67
    or-int/2addr v7, v10

    .line 68
    invoke-virtual {v13, v8}, Lla2;->g(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v10

    .line 72
    or-int/2addr v7, v10

    .line 73
    invoke-virtual {v13}, Lla2;->N()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v10

    .line 77
    if-nez v7, :cond_1

    .line 78
    .line 79
    sget-object v7, Ld21;->a:Lq9;

    .line 80
    .line 81
    if-ne v10, v7, :cond_2

    .line 82
    .line 83
    :cond_1
    new-instance v10, Lcx5;

    .line 84
    .line 85
    invoke-direct {v10, v1, v9, v8, v5}, Lcx5;-><init>(Lgw5;Ljava/util/ArrayList;Ln53;B)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v13, v10}, Lla2;->k0(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_2
    check-cast v10, Lh92;

    .line 92
    .line 93
    sget-object v1, Ljz3;->i:Ljz3;

    .line 94
    .line 95
    const/high16 v5, 0x3f800000    # 1.0f

    .line 96
    .line 97
    invoke-static {v1, v5}, Lef6;->d(Lmz3;F)Lmz3;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    sget-object v5, Lpl7;->w:Ljava/util/WeakHashMap;

    .line 102
    .line 103
    invoke-static {v13}, Lbv6;->j(Lla2;)Lpl7;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    iget-object v5, v5, Lpl7;->g:Lhg;

    .line 108
    .line 109
    invoke-static {v13}, Lbv6;->j(Lla2;)Lpl7;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    iget-object v7, v7, Lpl7;->b:Lhg;

    .line 114
    .line 115
    new-instance v9, Lh7;

    .line 116
    .line 117
    invoke-direct {v9, v5, v7}, Lh7;-><init>(Lik7;Lik7;)V

    .line 118
    .line 119
    .line 120
    const/16 v5, 0xf

    .line 121
    .line 122
    invoke-static {v9, v5, v1}, Lzi6;->g(Lh7;ILmz3;)Lmz3;

    .line 123
    .line 124
    .line 125
    move-result-object v9

    .line 126
    const/4 v15, 0x0

    .line 127
    const/16 v17, 0x0

    .line 128
    .line 129
    iget-object v7, v0, Lay5;->k:Ljava/util/ArrayList;

    .line 130
    .line 131
    move-object v1, v8

    .line 132
    move-object v8, v10

    .line 133
    const/4 v10, 0x0

    .line 134
    const/4 v11, 0x0

    .line 135
    const/4 v12, 0x0

    .line 136
    move-object/from16 v16, v13

    .line 137
    .line 138
    const/4 v13, 0x0

    .line 139
    const/4 v14, 0x0

    .line 140
    invoke-static/range {v7 .. v17}, Luj;->d(Ljava/util/ArrayList;Lh92;Lmz3;IZLjd0;Lbt4;FLdw2;Lla2;I)V

    .line 141
    .line 142
    .line 143
    move-object/from16 v13, v16

    .line 144
    .line 145
    invoke-virtual {v13, v4}, Lla2;->r(Z)V

    .line 146
    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_3
    move-object v1, v8

    .line 150
    const v5, -0x6ddb84db

    .line 151
    .line 152
    .line 153
    invoke-virtual {v13, v5}, Lla2;->b0(I)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v13, v4}, Lla2;->r(Z)V

    .line 157
    .line 158
    .line 159
    :goto_1
    iget-object v0, v0, Lay5;->n:Lzy5;

    .line 160
    .line 161
    invoke-virtual {v0}, Lzy5;->b()Z

    .line 162
    .line 163
    .line 164
    move-result v7

    .line 165
    sget-object v5, Lmb0;->b:Lbf1;

    .line 166
    .line 167
    const/16 v8, 0xfa

    .line 168
    .line 169
    invoke-static {v8, v4, v5, v3}, Lba7;->j0(IILws1;I)Lr87;

    .line 170
    .line 171
    .line 172
    move-result-object v9

    .line 173
    const/16 v10, 0xe

    .line 174
    .line 175
    invoke-static {v9, v10}, Lgy1;->d(Lr87;I)Lmy1;

    .line 176
    .line 177
    .line 178
    move-result-object v9

    .line 179
    invoke-static {v8, v4, v5, v3}, Lba7;->j0(IILws1;I)Lr87;

    .line 180
    .line 181
    .line 182
    move-result-object v5

    .line 183
    invoke-static {v5, v3}, Lgy1;->e(Lg22;I)Lmy1;

    .line 184
    .line 185
    .line 186
    move-result-object v5

    .line 187
    invoke-virtual {v9, v5}, Lmy1;->a(Lmy1;)Lmy1;

    .line 188
    .line 189
    .line 190
    move-result-object v9

    .line 191
    sget-object v5, Lmb0;->c:Lbf1;

    .line 192
    .line 193
    const/16 v8, 0x78

    .line 194
    .line 195
    invoke-static {v8, v4, v5, v3}, Lba7;->j0(IILws1;I)Lr87;

    .line 196
    .line 197
    .line 198
    move-result-object v11

    .line 199
    invoke-static {v11, v10}, Lgy1;->j(Lr87;I)Lf02;

    .line 200
    .line 201
    .line 202
    move-result-object v10

    .line 203
    invoke-static {v8, v4, v5, v3}, Lba7;->j0(IILws1;I)Lr87;

    .line 204
    .line 205
    .line 206
    move-result-object v4

    .line 207
    invoke-static {v4, v3}, Lgy1;->f(Lg22;I)Lf02;

    .line 208
    .line 209
    .line 210
    move-result-object v3

    .line 211
    invoke-virtual {v10, v3}, Lf02;->a(Lf02;)Lf02;

    .line 212
    .line 213
    .line 214
    move-result-object v10

    .line 215
    new-instance v3, Lkc5;

    .line 216
    .line 217
    const/4 v4, 0x4

    .line 218
    invoke-direct {v3, v0, v1, v4}, Lkc5;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 219
    .line 220
    .line 221
    const v0, -0x78e3da7b

    .line 222
    .line 223
    .line 224
    invoke-static {v0, v3, v13}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 225
    .line 226
    .line 227
    move-result-object v12

    .line 228
    const/high16 v14, 0x180000

    .line 229
    .line 230
    const/16 v15, 0x12

    .line 231
    .line 232
    const/4 v8, 0x0

    .line 233
    const/4 v11, 0x0

    .line 234
    invoke-static/range {v6 .. v15}, Lnn3;->L(Lvx0;ZLmz3;Lmy1;Lf02;Ljava/lang/String;Lyz0;Lla2;II)V

    .line 235
    .line 236
    .line 237
    goto :goto_2

    .line 238
    :cond_4
    invoke-virtual {v13}, Lla2;->V()V

    .line 239
    .line 240
    .line 241
    :goto_2
    return-object v2

    .line 242
    :pswitch_0
    move-object/from16 v6, p1

    .line 243
    .line 244
    check-cast v6, Lla2;

    .line 245
    .line 246
    move-object/from16 v1, p2

    .line 247
    .line 248
    check-cast v1, Ljava/lang/Integer;

    .line 249
    .line 250
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    and-int/lit8 v7, v1, 0x3

    .line 255
    .line 256
    if-eq v7, v3, :cond_5

    .line 257
    .line 258
    move v4, v5

    .line 259
    :cond_5
    and-int/2addr v1, v5

    .line 260
    invoke-virtual {v6, v1, v4}, Lla2;->S(IZ)Z

    .line 261
    .line 262
    .line 263
    move-result v1

    .line 264
    if-eqz v1, :cond_6

    .line 265
    .line 266
    new-instance v7, Lay5;

    .line 267
    .line 268
    const/4 v13, 0x1

    .line 269
    iget-object v8, v0, Lay5;->j:Lgw5;

    .line 270
    .line 271
    iget-object v9, v0, Lay5;->k:Ljava/util/ArrayList;

    .line 272
    .line 273
    iget-object v10, v0, Lay5;->l:Ljava/util/ArrayList;

    .line 274
    .line 275
    iget-object v11, v0, Lay5;->m:Ln53;

    .line 276
    .line 277
    iget-object v12, v0, Lay5;->n:Lzy5;

    .line 278
    .line 279
    invoke-direct/range {v7 .. v13}, Lay5;-><init>(Lgw5;Ljava/util/ArrayList;Ljava/util/ArrayList;Ln53;Lzy5;B)V

    .line 280
    .line 281
    .line 282
    const v0, -0x4ef30ca3

    .line 283
    .line 284
    .line 285
    invoke-static {v0, v7, v6}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 286
    .line 287
    .line 288
    move-result-object v5

    .line 289
    const/16 v7, 0x180

    .line 290
    .line 291
    const/4 v8, 0x3

    .line 292
    const/4 v3, 0x0

    .line 293
    const/4 v4, 0x0

    .line 294
    invoke-static/range {v3 .. v8}, Lyy3;->i(Lmz3;FLyz0;Lla2;II)V

    .line 295
    .line 296
    .line 297
    goto :goto_3

    .line 298
    :cond_6
    invoke-virtual {v6}, Lla2;->V()V

    .line 299
    .line 300
    .line 301
    :goto_3
    return-object v2

    .line 302
    nop

    .line 303
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
