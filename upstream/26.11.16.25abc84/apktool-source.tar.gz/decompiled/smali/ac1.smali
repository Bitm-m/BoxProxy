.class public final synthetic Lac1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lhi2;

.field public final synthetic k:Lw82;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Lw82;


# direct methods
.method public synthetic constructor <init>(Lhi2;Lw82;Ljava/lang/String;Lw82;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lac1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lac1;->j:Lhi2;

    .line 4
    .line 5
    iput-object p2, p0, Lac1;->k:Lw82;

    .line 6
    .line 7
    iput-object p3, p0, Lac1;->l:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p4, p0, Lac1;->m:Lw82;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lac1;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x2

    .line 9
    const/4 v5, 0x1

    .line 10
    packed-switch v1, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    move-object/from16 v14, p1

    .line 14
    .line 15
    check-cast v14, Lla2;

    .line 16
    .line 17
    move-object/from16 v1, p2

    .line 18
    .line 19
    check-cast v1, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    and-int/lit8 v6, v1, 0x3

    .line 26
    .line 27
    if-eq v6, v4, :cond_0

    .line 28
    .line 29
    move v3, v5

    .line 30
    :cond_0
    and-int/2addr v1, v5

    .line 31
    invoke-virtual {v14, v1, v3}, Lla2;->S(IZ)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_1

    .line 36
    .line 37
    const/16 v11, 0x46

    .line 38
    .line 39
    const/4 v12, 0x2

    .line 40
    sget-object v6, Ljz3;->i:Ljz3;

    .line 41
    .line 42
    iget-object v7, v0, Lac1;->j:Lhi2;

    .line 43
    .line 44
    const/4 v8, 0x0

    .line 45
    iget-object v9, v0, Lac1;->k:Lw82;

    .line 46
    .line 47
    move-object v10, v14

    .line 48
    invoke-static/range {v6 .. v12}, Lfi2;->c(Lmz3;Lhi2;ZLw82;Lla2;II)Lmz3;

    .line 49
    .line 50
    .line 51
    move-result-object v7

    .line 52
    new-instance v1, Lq;

    .line 53
    .line 54
    iget-object v3, v0, Lac1;->l:Ljava/lang/String;

    .line 55
    .line 56
    const/16 v4, 0x15

    .line 57
    .line 58
    invoke-direct {v1, v3, v4}, Lq;-><init>(Ljava/lang/String;B)V

    .line 59
    .line 60
    .line 61
    const v3, 0x65d1c4b7

    .line 62
    .line 63
    .line 64
    invoke-static {v3, v1, v14}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    new-instance v1, Lj;

    .line 69
    .line 70
    iget-object v0, v0, Lac1;->m:Lw82;

    .line 71
    .line 72
    invoke-direct {v1, v0, v4}, Lj;-><init>(Lw82;B)V

    .line 73
    .line 74
    .line 75
    const v0, -0x6511830b

    .line 76
    .line 77
    .line 78
    invoke-static {v0, v1, v14}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 79
    .line 80
    .line 81
    move-result-object v8

    .line 82
    const/16 v15, 0x186

    .line 83
    .line 84
    const/16 v16, 0x1f8

    .line 85
    .line 86
    const/4 v9, 0x0

    .line 87
    const/4 v10, 0x0

    .line 88
    const/4 v11, 0x0

    .line 89
    const/4 v12, 0x0

    .line 90
    const/4 v13, 0x0

    .line 91
    invoke-static/range {v6 .. v16}, Lzo;->c(Lyz0;Lmz3;Lyz0;Lyz0;FLue3;Lz57;Lbt4;Lla2;II)V

    .line 92
    .line 93
    .line 94
    goto :goto_0

    .line 95
    :cond_1
    invoke-virtual {v14}, Lla2;->V()V

    .line 96
    .line 97
    .line 98
    :goto_0
    return-object v2

    .line 99
    :pswitch_0
    move-object/from16 v1, p1

    .line 100
    .line 101
    check-cast v1, Lla2;

    .line 102
    .line 103
    move-object/from16 v6, p2

    .line 104
    .line 105
    check-cast v6, Ljava/lang/Integer;

    .line 106
    .line 107
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 108
    .line 109
    .line 110
    move-result v6

    .line 111
    and-int/lit8 v7, v6, 0x3

    .line 112
    .line 113
    if-eq v7, v4, :cond_2

    .line 114
    .line 115
    move v3, v5

    .line 116
    :cond_2
    and-int/2addr v6, v5

    .line 117
    invoke-virtual {v1, v6, v3}, Lla2;->S(IZ)Z

    .line 118
    .line 119
    .line 120
    move-result v3

    .line 121
    if-eqz v3, :cond_3

    .line 122
    .line 123
    sget-object v3, Lfi2;->a:Lps1;

    .line 124
    .line 125
    iget-object v5, v0, Lac1;->j:Lhi2;

    .line 126
    .line 127
    invoke-virtual {v3, v5}, Lps1;->a(Ljava/lang/Object;)Lr55;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    new-instance v4, Lac1;

    .line 132
    .line 133
    const/4 v9, 0x1

    .line 134
    iget-object v6, v0, Lac1;->k:Lw82;

    .line 135
    .line 136
    iget-object v7, v0, Lac1;->l:Ljava/lang/String;

    .line 137
    .line 138
    iget-object v8, v0, Lac1;->m:Lw82;

    .line 139
    .line 140
    invoke-direct/range {v4 .. v9}, Lac1;-><init>(Lhi2;Lw82;Ljava/lang/String;Lw82;B)V

    .line 141
    .line 142
    .line 143
    const v0, 0x32b843fb

    .line 144
    .line 145
    .line 146
    invoke-static {v0, v4, v1}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    const/16 v4, 0x38

    .line 151
    .line 152
    invoke-static {v3, v0, v1, v4}, Lhn;->c(Lr55;Ll92;Lla2;I)V

    .line 153
    .line 154
    .line 155
    goto :goto_1

    .line 156
    :cond_3
    invoke-virtual {v1}, Lla2;->V()V

    .line 157
    .line 158
    .line 159
    :goto_1
    return-object v2

    .line 160
    nop

    .line 161
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
