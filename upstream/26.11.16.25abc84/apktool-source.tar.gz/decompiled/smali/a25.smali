.class public final La25;
.super Lcb3;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final f:La25;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La25;

    .line 2
    .line 3
    invoke-direct {v0}, Lcb3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La25;->f:La25;

    .line 7
    .line 8
    return-void
.end method
