.class public abstract Law2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lps1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lif2;

    .line 2
    .line 3
    const/16 v1, 0x11

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lif2;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lps1;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v1, v0, v2}, Lps1;-><init>(Lw82;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, Law2;->a:Lps1;

    .line 15
    .line 16
    return-void
.end method

.method public static final a(Lmz3;Lc03;Ldw2;)Lmz3;
    .locals 1

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    return-object p0

    .line 4
    :cond_0
    new-instance v0, Lbw2;

    .line 5
    .line 6
    invoke-direct {v0, p1, p2}, Lbw2;-><init>(Lc03;Ldw2;)V

    .line 7
    .line 8
    .line 9
    invoke-interface {p0, v0}, Lmz3;->a0(Lmz3;)Lmz3;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method
