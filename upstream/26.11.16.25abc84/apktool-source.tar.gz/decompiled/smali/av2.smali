.class public interface abstract Lav2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ljava/lang/AutoCloseable;


# virtual methods
.method public abstract C()Lcf0;
.end method

.method public abstract getFileSystem()Ln12;
.end method

.method public abstract o()Lax4;
.end method

.method public abstract s()Lkm;
.end method
