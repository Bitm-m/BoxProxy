.class public final Lak1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lei6;


# instance fields
.field public final a:Ljz6;


# direct methods
.method public constructor <init>(Ljz6;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lak1;->a:Ljz6;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    iget-object p0, p0, Lak1;->a:Ljz6;

    .line 2
    .line 3
    iget-object p0, p0, Ljz6;->a:Lc05;

    .line 4
    .line 5
    invoke-interface {p0}, Lc05;->f()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final b()V
    .locals 1

    .line 1
    iget-object p0, p0, Lak1;->a:Ljz6;

    .line 2
    .line 3
    iget-object v0, p0, Ljz6;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lmz6;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object p0, p0, Ljz6;->a:Lc05;

    .line 14
    .line 15
    invoke-interface {p0}, Lc05;->d()V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method
