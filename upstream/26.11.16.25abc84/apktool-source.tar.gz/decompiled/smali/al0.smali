.class public final Lal0;
.super Lda1;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public i:Ljava/lang/Object;

.field public j:Lkk0;

.field public k:Lok0;

.field public l:Lmk0;

.field public m:Lvx3;

.field public n:Lpk0;

.field public o:Lu14;

.field public p:Lqk0;

.field public q:Lvx3;

.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:Lel0;

.field public t:I


# direct methods
.method public constructor <init>(Lel0;Lda1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lal0;->s:Lel0;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lda1;-><init>(Lca1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iput-object p1, p0, Lal0;->r:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lal0;->t:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lal0;->t:I

    .line 9
    .line 10
    const/4 v8, 0x0

    .line 11
    const/4 v9, 0x0

    .line 12
    iget-object v0, p0, Lal0;->s:Lel0;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x0

    .line 16
    const/4 v3, 0x0

    .line 17
    const/4 v4, 0x0

    .line 18
    const/4 v5, 0x0

    .line 19
    const/4 v6, 0x0

    .line 20
    const/4 v7, 0x0

    .line 21
    move-object v10, p0

    .line 22
    invoke-virtual/range {v0 .. v10}, Lel0;->a(Ljava/lang/Object;Lkk0;Lok0;Lmk0;Lvx3;Lpk0;Lu14;Lqk0;Lvx3;Lda1;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0
.end method
