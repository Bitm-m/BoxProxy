.class public final La72;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lz62;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    sget-object v0, Lr6;->b0:Lr6;

    .line 2
    .line 3
    new-instance v1, Lz62;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, v0, v2}, Lz62;-><init>(Lxd1;B)V

    .line 7
    .line 8
    .line 9
    sput-object v1, La72;->a:Lz62;

    .line 10
    .line 11
    return-void
.end method
