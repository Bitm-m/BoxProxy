.class public final synthetic Lb2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 17
    iput-byte p5, p0, Lb2;->i:B

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lzq4;Ljava/lang/String;Lw82;)V
    .locals 1

    .line 1
    const/16 v0, 0xb

    .line 2
    .line 3
    iput-byte v0, p0, Lb2;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lb2;->k:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p2, p0, Lb2;->j:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    .line 13
    .line 14
    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/ArrayList;Lej5;Ljava/util/List;ILw93;)V
    .locals 0

    .line 18
    const/4 p4, 0x6

    iput-byte p4, p0, Lb2;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p5, p0, Lb2;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb2;->i:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x3

    .line 7
    const/16 v6, 0x20

    .line 8
    .line 9
    const/16 v7, 0xb

    .line 10
    .line 11
    const/4 v8, 0x2

    .line 12
    const/4 v9, 0x0

    .line 13
    const/4 v10, 0x0

    .line 14
    const/4 v11, 0x1

    .line 15
    sget-object v12, Loc7;->a:Loc7;

    .line 16
    .line 17
    iget-object v13, v0, Lb2;->m:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v14, v0, Lb2;->l:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v15, v0, Lb2;->k:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v0, v0, Lb2;->j:Ljava/lang/Object;

    .line 24
    .line 25
    packed-switch v1, :pswitch_data_0

    .line 26
    .line 27
    .line 28
    check-cast v0, Lw82;

    .line 29
    .line 30
    check-cast v15, Lu00;

    .line 31
    .line 32
    check-cast v14, Lty6;

    .line 33
    .line 34
    check-cast v13, Lp17;

    .line 35
    .line 36
    move-object/from16 v1, p1

    .line 37
    .line 38
    check-cast v1, Lvu6;

    .line 39
    .line 40
    invoke-interface {v0}, Lw82;->invoke()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    if-eqz v15, :cond_0

    .line 44
    .line 45
    invoke-virtual {v15}, Lu00;->invoke()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    check-cast v0, Ljava/lang/Boolean;

    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 52
    .line 53
    .line 54
    move-result v11

    .line 55
    :cond_0
    if-eqz v11, :cond_1

    .line 56
    .line 57
    invoke-interface {v1}, Lvu6;->close()V

    .line 58
    .line 59
    .line 60
    :cond_1
    invoke-virtual {v14, v13}, Lty6;->x(Lp17;)V

    .line 61
    .line 62
    .line 63
    return-object v12

    .line 64
    :pswitch_0
    check-cast v0, Lzj6;

    .line 65
    .line 66
    check-cast v15, Lov0;

    .line 67
    .line 68
    check-cast v14, Lmg2;

    .line 69
    .line 70
    move-object/from16 v17, v13

    .line 71
    .line 72
    check-cast v17, Lbo4;

    .line 73
    .line 74
    move-object/from16 v1, p1

    .line 75
    .line 76
    check-cast v1, Ls83;

    .line 77
    .line 78
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    .line 80
    .line 81
    iget-object v2, v1, Ls83;->i:Lhj0;

    .line 82
    .line 83
    invoke-interface {v2}, Lyq1;->b()J

    .line 84
    .line 85
    .line 86
    move-result-wide v18

    .line 87
    const-wide v20, 0xffffffffL

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    shr-long v4, v18, v6

    .line 93
    .line 94
    long-to-int v4, v4

    .line 95
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 96
    .line 97
    .line 98
    move-result v4

    .line 99
    invoke-interface {v2}, Lyq1;->b()J

    .line 100
    .line 101
    .line 102
    move-result-wide v18

    .line 103
    move v5, v6

    .line 104
    and-long v6, v18, v20

    .line 105
    .line 106
    long-to-int v6, v6

    .line 107
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 108
    .line 109
    .line 110
    move-result v6

    .line 111
    invoke-static {v4, v6}, Ljava/lang/Math;->max(FF)F

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    const/high16 v6, 0x45000000    # 2048.0f

    .line 116
    .line 117
    cmpg-float v4, v4, v6

    .line 118
    .line 119
    if-gtz v4, :cond_3

    .line 120
    .line 121
    if-eqz v15, :cond_2

    .line 122
    .line 123
    iget-wide v2, v15, Lov0;->a:J

    .line 124
    .line 125
    const/16 v26, 0x0

    .line 126
    .line 127
    const/16 v27, 0x7e

    .line 128
    .line 129
    const-wide/16 v21, 0x0

    .line 130
    .line 131
    const-wide/16 v23, 0x0

    .line 132
    .line 133
    const/16 v25, 0x0

    .line 134
    .line 135
    move-object/from16 v18, v1

    .line 136
    .line 137
    move-wide/from16 v19, v2

    .line 138
    .line 139
    invoke-static/range {v18 .. v27}, Lyq1;->n0(Lyq1;JJJFII)V

    .line 140
    .line 141
    .line 142
    :cond_2
    invoke-virtual {v1}, Ls83;->c()V

    .line 143
    .line 144
    .line 145
    invoke-static {v1, v0, v11, v11}, Lvj6;->c(Ls83;Lzj6;ZZ)V

    .line 146
    .line 147
    .line 148
    goto/16 :goto_3

    .line 149
    .line 150
    :cond_3
    new-instance v4, Llo3;

    .line 151
    .line 152
    invoke-direct {v4, v1, v11}, Llo3;-><init>(Ls83;B)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1}, Ls83;->b()J

    .line 156
    .line 157
    .line 158
    move-result-wide v6

    .line 159
    invoke-static {v6, v7}, Lhn;->S(J)J

    .line 160
    .line 161
    .line 162
    move-result-wide v6

    .line 163
    invoke-virtual {v1, v14, v6, v7, v4}, Ls83;->c0(Lmg2;JLh92;)V

    .line 164
    .line 165
    .line 166
    invoke-interface {v2}, Lyq1;->b()J

    .line 167
    .line 168
    .line 169
    move-result-wide v6

    .line 170
    shr-long/2addr v6, v5

    .line 171
    long-to-int v4, v6

    .line 172
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 173
    .line 174
    .line 175
    move-result v16

    .line 176
    invoke-interface {v2}, Lyq1;->b()J

    .line 177
    .line 178
    .line 179
    move-result-wide v6

    .line 180
    and-long v6, v6, v20

    .line 181
    .line 182
    long-to-int v4, v6

    .line 183
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 184
    .line 185
    .line 186
    move-result v23

    .line 187
    iget-object v4, v2, Lhj0;->j:Lh27;

    .line 188
    .line 189
    invoke-virtual {v4}, Lh27;->s()Lfj0;

    .line 190
    .line 191
    .line 192
    move-result-object v4

    .line 193
    invoke-interface {v2}, Lyq1;->b()J

    .line 194
    .line 195
    .line 196
    move-result-wide v6

    .line 197
    invoke-virtual {v0, v10, v6, v7}, Lzj6;->d(IJ)F

    .line 198
    .line 199
    .line 200
    move-result v10

    .line 201
    invoke-virtual {v0, v11, v6, v7}, Lzj6;->d(IJ)F

    .line 202
    .line 203
    .line 204
    move-result v6

    .line 205
    invoke-static {v10, v6}, Ljava/lang/Math;->max(FF)F

    .line 206
    .line 207
    .line 208
    move-result v6

    .line 209
    invoke-interface {v2}, Lyq1;->b()J

    .line 210
    .line 211
    .line 212
    move-result-wide v10

    .line 213
    invoke-virtual {v0, v8, v10, v11}, Lzj6;->d(IJ)F

    .line 214
    .line 215
    .line 216
    move-result v7

    .line 217
    invoke-virtual {v0, v3, v10, v11}, Lzj6;->d(IJ)F

    .line 218
    .line 219
    .line 220
    move-result v3

    .line 221
    invoke-static {v7, v3}, Ljava/lang/Math;->max(FF)F

    .line 222
    .line 223
    .line 224
    move-result v3

    .line 225
    add-float v7, v6, v3

    .line 226
    .line 227
    cmpg-float v7, v23, v7

    .line 228
    .line 229
    if-gtz v7, :cond_4

    .line 230
    .line 231
    const/16 v25, 0x1

    .line 232
    .line 233
    const/16 v26, 0x0

    .line 234
    .line 235
    const/16 v22, 0x0

    .line 236
    .line 237
    const/16 v24, 0x1

    .line 238
    .line 239
    move-object/from16 v21, v0

    .line 240
    .line 241
    move-object/from16 v19, v1

    .line 242
    .line 243
    move-object/from16 v20, v14

    .line 244
    .line 245
    move-object/from16 v18, v15

    .line 246
    .line 247
    move-object v15, v4

    .line 248
    invoke-static/range {v15 .. v26}, Lvj6;->b(Lfj0;FLbo4;Lov0;Ls83;Lmg2;Lzj6;FFZZZ)V

    .line 249
    .line 250
    .line 251
    goto/16 :goto_3

    .line 252
    .line 253
    :cond_4
    move-object/from16 v21, v0

    .line 254
    .line 255
    move-object/from16 v19, v1

    .line 256
    .line 257
    move-object/from16 v20, v14

    .line 258
    .line 259
    move-object/from16 v18, v15

    .line 260
    .line 261
    move/from16 v0, v23

    .line 262
    .line 263
    move-object v15, v4

    .line 264
    float-to-double v7, v6

    .line 265
    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    .line 266
    .line 267
    .line 268
    move-result-wide v7

    .line 269
    double-to-float v1, v7

    .line 270
    sub-float v4, v0, v3

    .line 271
    .line 272
    float-to-double v7, v4

    .line 273
    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    .line 274
    .line 275
    .line 276
    move-result-wide v7

    .line 277
    double-to-float v4, v7

    .line 278
    cmpl-float v6, v6, v9

    .line 279
    .line 280
    if-lez v6, :cond_5

    .line 281
    .line 282
    const/16 v25, 0x0

    .line 283
    .line 284
    const/16 v26, 0x1

    .line 285
    .line 286
    const/16 v22, 0x0

    .line 287
    .line 288
    const/16 v24, 0x1

    .line 289
    .line 290
    move/from16 v23, v1

    .line 291
    .line 292
    invoke-static/range {v15 .. v26}, Lvj6;->b(Lfj0;FLbo4;Lov0;Ls83;Lmg2;Lzj6;FFZZZ)V

    .line 293
    .line 294
    .line 295
    :goto_0
    move-object v6, v15

    .line 296
    move-object/from16 v15, v18

    .line 297
    .line 298
    move-object/from16 v14, v20

    .line 299
    .line 300
    move-object/from16 v1, v21

    .line 301
    .line 302
    goto :goto_1

    .line 303
    :cond_5
    move/from16 v23, v1

    .line 304
    .line 305
    goto :goto_0

    .line 306
    :goto_1
    invoke-interface {v2}, Lyq1;->b()J

    .line 307
    .line 308
    .line 309
    move-result-wide v7

    .line 310
    shr-long/2addr v7, v5

    .line 311
    long-to-int v5, v7

    .line 312
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 313
    .line 314
    .line 315
    move-result v25

    .line 316
    iget-object v2, v2, Lhj0;->j:Lh27;

    .line 317
    .line 318
    invoke-virtual {v2}, Lh27;->E()J

    .line 319
    .line 320
    .line 321
    move-result-wide v7

    .line 322
    invoke-virtual {v2}, Lh27;->s()Lfj0;

    .line 323
    .line 324
    .line 325
    move-result-object v5

    .line 326
    invoke-interface {v5}, Lfj0;->n()V

    .line 327
    .line 328
    .line 329
    :try_start_0
    iget-object v5, v2, Lh27;->j:Ljava/lang/Object;

    .line 330
    .line 331
    move-object/from16 v22, v5

    .line 332
    .line 333
    check-cast v22, Llh7;

    .line 334
    .line 335
    move/from16 v24, v23

    .line 336
    .line 337
    const/16 v23, 0x0

    .line 338
    .line 339
    const/16 v27, 0x1

    .line 340
    .line 341
    move/from16 v26, v4

    .line 342
    .line 343
    invoke-virtual/range {v22 .. v27}, Llh7;->k(FFFFI)V

    .line 344
    .line 345
    .line 346
    if-eqz v15, :cond_6

    .line 347
    .line 348
    iget-wide v10, v15, Lov0;->a:J

    .line 349
    .line 350
    const/16 v26, 0x0

    .line 351
    .line 352
    const/16 v27, 0x7e

    .line 353
    .line 354
    const-wide/16 v21, 0x0

    .line 355
    .line 356
    const-wide/16 v23, 0x0

    .line 357
    .line 358
    const/16 v25, 0x0

    .line 359
    .line 360
    move-object/from16 v18, v19

    .line 361
    .line 362
    move-wide/from16 v19, v10

    .line 363
    .line 364
    invoke-static/range {v18 .. v27}, Lyq1;->n0(Lyq1;JJJFII)V

    .line 365
    .line 366
    .line 367
    move-object/from16 v5, v18

    .line 368
    .line 369
    goto :goto_2

    .line 370
    :cond_6
    move-object/from16 v5, v19

    .line 371
    .line 372
    :goto_2
    invoke-static {v5, v14}, Ljn;->D(Lyq1;Lmg2;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 373
    .line 374
    .line 375
    invoke-static {v2, v7, v8}, Lzi6;->z(Lh27;J)V

    .line 376
    .line 377
    .line 378
    cmpl-float v2, v3, v9

    .line 379
    .line 380
    if-lez v2, :cond_7

    .line 381
    .line 382
    const/16 v25, 0x1

    .line 383
    .line 384
    const/16 v26, 0x1

    .line 385
    .line 386
    const/16 v24, 0x0

    .line 387
    .line 388
    move/from16 v23, v0

    .line 389
    .line 390
    move-object/from16 v21, v1

    .line 391
    .line 392
    move/from16 v22, v4

    .line 393
    .line 394
    move-object/from16 v19, v5

    .line 395
    .line 396
    move-object/from16 v20, v14

    .line 397
    .line 398
    move-object/from16 v18, v15

    .line 399
    .line 400
    move-object v15, v6

    .line 401
    invoke-static/range {v15 .. v26}, Lvj6;->b(Lfj0;FLbo4;Lov0;Ls83;Lmg2;Lzj6;FFZZZ)V

    .line 402
    .line 403
    .line 404
    :cond_7
    :goto_3
    return-object v12

    .line 405
    :catchall_0
    move-exception v0

    .line 406
    invoke-static {v2, v7, v8}, Lzi6;->z(Lh27;J)V

    .line 407
    .line 408
    .line 409
    throw v0

    .line 410
    :pswitch_1
    check-cast v0, Ldj5;

    .line 411
    .line 412
    check-cast v15, Lzt4;

    .line 413
    .line 414
    check-cast v14, Ltu4;

    .line 415
    .line 416
    check-cast v13, Ly6;

    .line 417
    .line 418
    move-object/from16 v1, p1

    .line 419
    .line 420
    check-cast v1, Lyh;

    .line 421
    .line 422
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 423
    .line 424
    .line 425
    iget-object v2, v1, Lyh;->e:Liw4;

    .line 426
    .line 427
    invoke-virtual {v2}, Liw4;->getValue()Ljava/lang/Object;

    .line 428
    .line 429
    .line 430
    move-result-object v2

    .line 431
    check-cast v2, Ljava/lang/Number;

    .line 432
    .line 433
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 434
    .line 435
    .line 436
    move-result v2

    .line 437
    iget v3, v0, Ldj5;->i:F

    .line 438
    .line 439
    sub-float/2addr v2, v3

    .line 440
    invoke-static {v2}, Ldh1;->t(F)Z

    .line 441
    .line 442
    .line 443
    move-result v3

    .line 444
    if-nez v3, :cond_9

    .line 445
    .line 446
    iget-object v3, v15, Lyh4;->d:Ljava/lang/Object;

    .line 447
    .line 448
    check-cast v3, Luu4;

    .line 449
    .line 450
    invoke-virtual {v3, v14, v2, v11}, Luu4;->a(Ltu4;FI)F

    .line 451
    .line 452
    .line 453
    move-result v3

    .line 454
    sub-float v3, v2, v3

    .line 455
    .line 456
    invoke-static {v3}, Ldh1;->t(F)Z

    .line 457
    .line 458
    .line 459
    move-result v3

    .line 460
    if-nez v3, :cond_8

    .line 461
    .line 462
    invoke-virtual {v1}, Lyh;->a()V

    .line 463
    .line 464
    .line 465
    goto :goto_4

    .line 466
    :cond_8
    iget v3, v0, Ldj5;->i:F

    .line 467
    .line 468
    add-float/2addr v3, v2

    .line 469
    iput v3, v0, Ldj5;->i:F

    .line 470
    .line 471
    :cond_9
    iget v0, v0, Ldj5;->i:F

    .line 472
    .line 473
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 474
    .line 475
    .line 476
    move-result-object v0

    .line 477
    invoke-virtual {v13, v0}, Ly6;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    move-result-object v0

    .line 481
    check-cast v0, Ljava/lang/Boolean;

    .line 482
    .line 483
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 484
    .line 485
    .line 486
    move-result v0

    .line 487
    if-eqz v0, :cond_a

    .line 488
    .line 489
    invoke-virtual {v1}, Lyh;->a()V

    .line 490
    .line 491
    .line 492
    :cond_a
    :goto_4
    return-object v12

    .line 493
    :pswitch_2
    check-cast v15, Ljava/lang/String;

    .line 494
    .line 495
    check-cast v0, Lzq4;

    .line 496
    .line 497
    move-object/from16 v16, v14

    .line 498
    .line 499
    check-cast v16, Ljava/lang/String;

    .line 500
    .line 501
    move-object/from16 v17, v13

    .line 502
    .line 503
    check-cast v17, Lw82;

    .line 504
    .line 505
    move-object/from16 v1, p1

    .line 506
    .line 507
    check-cast v1, Lgc3;

    .line 508
    .line 509
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 510
    .line 511
    .line 512
    if-eqz v15, :cond_b

    .line 513
    .line 514
    new-instance v13, Lil;

    .line 515
    .line 516
    const/16 v18, 0xe

    .line 517
    .line 518
    move-object v14, v15

    .line 519
    move-object v15, v0

    .line 520
    invoke-direct/range {v13 .. v18}, Lil;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 521
    .line 522
    .line 523
    move-object/from16 v14, v16

    .line 524
    .line 525
    new-instance v0, Lyz0;

    .line 526
    .line 527
    const v2, -0x3d240a0b

    .line 528
    .line 529
    .line 530
    invoke-direct {v0, v2, v11, v13}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 531
    .line 532
    .line 533
    const-string v2, "status"

    .line 534
    .line 535
    invoke-static {v1, v2, v0, v8}, Lgc3;->j0(Lgc3;Ljava/lang/String;Lm92;I)V

    .line 536
    .line 537
    .line 538
    goto :goto_5

    .line 539
    :cond_b
    move-object v15, v0

    .line 540
    move-object/from16 v14, v16

    .line 541
    .line 542
    :goto_5
    iget-object v0, v15, Lzq4;->b:Ljava/util/List;

    .line 543
    .line 544
    new-instance v2, Lqf4;

    .line 545
    .line 546
    const/16 v3, 0x15

    .line 547
    .line 548
    invoke-direct {v2, v3}, Lqf4;-><init>(B)V

    .line 549
    .line 550
    .line 551
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 552
    .line 553
    .line 554
    move-result v3

    .line 555
    new-instance v4, Lc0;

    .line 556
    .line 557
    const/16 v5, 0x13

    .line 558
    .line 559
    invoke-direct {v4, v2, v0, v5}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 560
    .line 561
    .line 562
    new-instance v2, Ld0;

    .line 563
    .line 564
    invoke-direct {v2, v0, v7}, Ld0;-><init>(Ljava/util/List;B)V

    .line 565
    .line 566
    .line 567
    new-instance v5, Lhc1;

    .line 568
    .line 569
    invoke-direct {v5, v0, v15, v14, v8}, Lhc1;-><init>(Ljava/util/List;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 570
    .line 571
    .line 572
    new-instance v0, Lyz0;

    .line 573
    .line 574
    const v6, 0x2fd4df92

    .line 575
    .line 576
    .line 577
    invoke-direct {v0, v6, v11, v5}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 578
    .line 579
    .line 580
    invoke-virtual {v1, v3, v4, v2, v0}, Lgc3;->k0(ILh92;Lh92;Lyz0;)V

    .line 581
    .line 582
    .line 583
    return-object v12

    .line 584
    :pswitch_3
    check-cast v0, Ljava/util/List;

    .line 585
    .line 586
    check-cast v15, Lh92;

    .line 587
    .line 588
    check-cast v14, Lb34;

    .line 589
    .line 590
    check-cast v13, Lb34;

    .line 591
    .line 592
    move-object/from16 v1, p1

    .line 593
    .line 594
    check-cast v1, Lvd4;

    .line 595
    .line 596
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 597
    .line 598
    .line 599
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 600
    .line 601
    invoke-interface {v14, v2}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 602
    .line 603
    .line 604
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 605
    .line 606
    .line 607
    move-result v0

    .line 608
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 609
    .line 610
    .line 611
    move-result-object v0

    .line 612
    invoke-interface {v13, v0}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 613
    .line 614
    .line 615
    invoke-interface {v15, v1}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 616
    .line 617
    .line 618
    return-object v12

    .line 619
    :pswitch_4
    check-cast v0, Ldj5;

    .line 620
    .line 621
    check-cast v15, Lq04;

    .line 622
    .line 623
    check-cast v14, Lm36;

    .line 624
    .line 625
    check-cast v13, Ly6;

    .line 626
    .line 627
    move-object/from16 v1, p1

    .line 628
    .line 629
    check-cast v1, Lyh;

    .line 630
    .line 631
    iget-object v2, v1, Lyh;->e:Liw4;

    .line 632
    .line 633
    invoke-virtual {v2}, Liw4;->getValue()Ljava/lang/Object;

    .line 634
    .line 635
    .line 636
    move-result-object v2

    .line 637
    check-cast v2, Ljava/lang/Number;

    .line 638
    .line 639
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 640
    .line 641
    .line 642
    move-result v2

    .line 643
    iget v3, v0, Ldj5;->i:F

    .line 644
    .line 645
    sub-float/2addr v2, v3

    .line 646
    invoke-static {v2}, Lva3;->I(F)Z

    .line 647
    .line 648
    .line 649
    move-result v3

    .line 650
    if-nez v3, :cond_d

    .line 651
    .line 652
    invoke-virtual {v15, v14, v2}, Lq04;->d(Lm36;F)F

    .line 653
    .line 654
    .line 655
    move-result v3

    .line 656
    sub-float v3, v2, v3

    .line 657
    .line 658
    invoke-static {v3}, Lva3;->I(F)Z

    .line 659
    .line 660
    .line 661
    move-result v3

    .line 662
    if-nez v3, :cond_c

    .line 663
    .line 664
    invoke-virtual {v1}, Lyh;->a()V

    .line 665
    .line 666
    .line 667
    goto :goto_6

    .line 668
    :cond_c
    iget v3, v0, Ldj5;->i:F

    .line 669
    .line 670
    add-float/2addr v3, v2

    .line 671
    iput v3, v0, Ldj5;->i:F

    .line 672
    .line 673
    :cond_d
    iget v0, v0, Ldj5;->i:F

    .line 674
    .line 675
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 676
    .line 677
    .line 678
    move-result-object v0

    .line 679
    invoke-virtual {v13, v0}, Ly6;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    check-cast v0, Ljava/lang/Boolean;

    .line 684
    .line 685
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 686
    .line 687
    .line 688
    move-result v0

    .line 689
    if-eqz v0, :cond_e

    .line 690
    .line 691
    invoke-virtual {v1}, Lyh;->a()V

    .line 692
    .line 693
    .line 694
    :cond_e
    :goto_6
    return-object v12

    .line 695
    :pswitch_5
    check-cast v0, Lnx3;

    .line 696
    .line 697
    check-cast v15, Lgj;

    .line 698
    .line 699
    check-cast v14, Lm67;

    .line 700
    .line 701
    check-cast v13, Lb34;

    .line 702
    .line 703
    move-object/from16 v1, p1

    .line 704
    .line 705
    check-cast v1, Ljava/lang/Float;

    .line 706
    .line 707
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 708
    .line 709
    .line 710
    move-result v2

    .line 711
    if-eqz v0, :cond_f

    .line 712
    .line 713
    if-eqz v15, :cond_f

    .line 714
    .line 715
    iget-object v3, v0, Lnx3;->b:Ljava/util/LinkedHashMap;

    .line 716
    .line 717
    invoke-interface {v3, v15, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 718
    .line 719
    .line 720
    iget-object v1, v0, Lnx3;->c:Lgj;

    .line 721
    .line 722
    if-ne v15, v1, :cond_10

    .line 723
    .line 724
    iget-object v0, v0, Lnx3;->d:Lm67;

    .line 725
    .line 726
    if-eqz v0, :cond_10

    .line 727
    .line 728
    iget-object v0, v0, Lm67;->c:Lew4;

    .line 729
    .line 730
    invoke-virtual {v0, v2}, Lew4;->h(F)V

    .line 731
    .line 732
    .line 733
    goto :goto_7

    .line 734
    :cond_f
    invoke-interface {v13}, Lok6;->getValue()Ljava/lang/Object;

    .line 735
    .line 736
    .line 737
    move-result-object v0

    .line 738
    check-cast v0, Ljava/lang/Boolean;

    .line 739
    .line 740
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 741
    .line 742
    .line 743
    move-result v0

    .line 744
    if-eqz v0, :cond_10

    .line 745
    .line 746
    iget-object v0, v14, Lm67;->c:Lew4;

    .line 747
    .line 748
    invoke-virtual {v0, v2}, Lew4;->h(F)V

    .line 749
    .line 750
    .line 751
    :cond_10
    :goto_7
    return-object v12

    .line 752
    :pswitch_6
    check-cast v0, Lqb3;

    .line 753
    .line 754
    check-cast v15, Lza3;

    .line 755
    .line 756
    check-cast v14, Lun6;

    .line 757
    .line 758
    check-cast v13, Lf35;

    .line 759
    .line 760
    move-object/from16 v1, p1

    .line 761
    .line 762
    check-cast v1, Lln1;

    .line 763
    .line 764
    new-instance v1, Lom1;

    .line 765
    .line 766
    invoke-direct {v1, v15, v14, v13}, Lom1;-><init>(Lza3;Lun6;Lf35;)V

    .line 767
    .line 768
    .line 769
    iput-object v1, v0, Lqb3;->c:Lom1;

    .line 770
    .line 771
    new-instance v1, La7;

    .line 772
    .line 773
    invoke-direct {v1, v0, v7}, La7;-><init>(Ljava/lang/Object;B)V

    .line 774
    .line 775
    .line 776
    return-object v1

    .line 777
    :pswitch_7
    move v5, v6

    .line 778
    const-wide v20, 0xffffffffL

    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    check-cast v0, Ljava/util/ArrayList;

    .line 784
    .line 785
    check-cast v15, Lej5;

    .line 786
    .line 787
    check-cast v14, Ljava/util/List;

    .line 788
    .line 789
    check-cast v13, Lw93;

    .line 790
    .line 791
    move-object/from16 v1, p1

    .line 792
    .line 793
    check-cast v1, Le35;

    .line 794
    .line 795
    iget-object v2, v1, Le35;->e:Ltn6;

    .line 796
    .line 797
    if-eqz v2, :cond_11

    .line 798
    .line 799
    invoke-interface {v2}, Ltn6;->d()I

    .line 800
    .line 801
    .line 802
    move-result v2

    .line 803
    goto :goto_8

    .line 804
    :cond_11
    move v2, v10

    .line 805
    :goto_8
    move v3, v10

    .line 806
    :goto_9
    if-ge v10, v2, :cond_15

    .line 807
    .line 808
    iget-object v4, v13, Lw93;->r:Lio4;

    .line 809
    .line 810
    iget-object v6, v1, Le35;->e:Ltn6;

    .line 811
    .line 812
    const-wide/16 v7, 0x0

    .line 813
    .line 814
    sget-object v9, Lio4;->i:Lio4;

    .line 815
    .line 816
    if-ne v4, v9, :cond_13

    .line 817
    .line 818
    if-eqz v6, :cond_12

    .line 819
    .line 820
    invoke-interface {v6, v10}, Ltn6;->c(I)J

    .line 821
    .line 822
    .line 823
    move-result-wide v7

    .line 824
    :cond_12
    and-long v7, v7, v20

    .line 825
    .line 826
    :goto_a
    long-to-int v4, v7

    .line 827
    goto :goto_b

    .line 828
    :cond_13
    if-eqz v6, :cond_14

    .line 829
    .line 830
    invoke-interface {v6, v10}, Ltn6;->c(I)J

    .line 831
    .line 832
    .line 833
    move-result-wide v7

    .line 834
    :cond_14
    shr-long/2addr v7, v5

    .line 835
    goto :goto_a

    .line 836
    :goto_b
    add-int/2addr v3, v4

    .line 837
    add-int/lit8 v10, v10, 0x1

    .line 838
    .line 839
    goto :goto_9

    .line 840
    :cond_15
    if-eqz v0, :cond_16

    .line 841
    .line 842
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 843
    .line 844
    .line 845
    move-result-object v1

    .line 846
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 847
    .line 848
    .line 849
    :cond_16
    iget v0, v15, Lej5;->i:I

    .line 850
    .line 851
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 852
    .line 853
    .line 854
    move-result v1

    .line 855
    if-eq v0, v1, :cond_17

    .line 856
    .line 857
    iget v0, v15, Lej5;->i:I

    .line 858
    .line 859
    add-int/2addr v0, v11

    .line 860
    iput v0, v15, Lej5;->i:I

    .line 861
    .line 862
    :cond_17
    return-object v12

    .line 863
    :pswitch_8
    check-cast v0, Lb34;

    .line 864
    .line 865
    check-cast v15, Lvw2;

    .line 866
    .line 867
    check-cast v14, Ldj5;

    .line 868
    .line 869
    check-cast v13, Lhe1;

    .line 870
    .line 871
    move-object/from16 v1, p1

    .line 872
    .line 873
    check-cast v1, Ljava/lang/Long;

    .line 874
    .line 875
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 876
    .line 877
    .line 878
    move-result-wide v1

    .line 879
    invoke-interface {v0}, Lok6;->getValue()Ljava/lang/Object;

    .line 880
    .line 881
    .line 882
    move-result-object v0

    .line 883
    check-cast v0, Lok6;

    .line 884
    .line 885
    if-eqz v0, :cond_18

    .line 886
    .line 887
    invoke-interface {v0}, Lok6;->getValue()Ljava/lang/Object;

    .line 888
    .line 889
    .line 890
    move-result-object v0

    .line 891
    check-cast v0, Ljava/lang/Number;

    .line 892
    .line 893
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 894
    .line 895
    .line 896
    move-result-wide v3

    .line 897
    goto :goto_c

    .line 898
    :cond_18
    move-wide v3, v1

    .line 899
    :goto_c
    iget-wide v5, v15, Lvw2;->c:J

    .line 900
    .line 901
    iget-object v0, v15, Lvw2;->a:Ld34;

    .line 902
    .line 903
    const-wide/high16 v7, -0x8000000000000000L

    .line 904
    .line 905
    cmp-long v5, v5, v7

    .line 906
    .line 907
    if-eqz v5, :cond_19

    .line 908
    .line 909
    iget v5, v14, Ldj5;->i:F

    .line 910
    .line 911
    invoke-interface {v13}, Lhe1;->e()Lyd1;

    .line 912
    .line 913
    .line 914
    move-result-object v6

    .line 915
    invoke-static {v6}, Ln86;->N(Lyd1;)F

    .line 916
    .line 917
    .line 918
    move-result v6

    .line 919
    cmpg-float v5, v5, v6

    .line 920
    .line 921
    if-eqz v5, :cond_1b

    .line 922
    .line 923
    :cond_19
    iput-wide v1, v15, Lvw2;->c:J

    .line 924
    .line 925
    iget-object v1, v0, Ld34;->i:[Ljava/lang/Object;

    .line 926
    .line 927
    iget v2, v0, Ld34;->k:I

    .line 928
    .line 929
    move v5, v10

    .line 930
    :goto_d
    if-ge v5, v2, :cond_1a

    .line 931
    .line 932
    aget-object v6, v1, v5

    .line 933
    .line 934
    check-cast v6, Lsw2;

    .line 935
    .line 936
    iput-boolean v11, v6, Lsw2;->n:Z

    .line 937
    .line 938
    add-int/lit8 v5, v5, 0x1

    .line 939
    .line 940
    goto :goto_d

    .line 941
    :cond_1a
    invoke-interface {v13}, Lhe1;->e()Lyd1;

    .line 942
    .line 943
    .line 944
    move-result-object v1

    .line 945
    invoke-static {v1}, Ln86;->N(Lyd1;)F

    .line 946
    .line 947
    .line 948
    move-result v1

    .line 949
    iput v1, v14, Ldj5;->i:F

    .line 950
    .line 951
    :cond_1b
    iget v1, v14, Ldj5;->i:F

    .line 952
    .line 953
    cmpg-float v2, v1, v9

    .line 954
    .line 955
    if-nez v2, :cond_1c

    .line 956
    .line 957
    iget-object v1, v0, Ld34;->i:[Ljava/lang/Object;

    .line 958
    .line 959
    iget v0, v0, Ld34;->k:I

    .line 960
    .line 961
    :goto_e
    if-ge v10, v0, :cond_21

    .line 962
    .line 963
    aget-object v2, v1, v10

    .line 964
    .line 965
    check-cast v2, Lsw2;

    .line 966
    .line 967
    iget-object v3, v2, Lsw2;->l:Lzs6;

    .line 968
    .line 969
    iget-object v3, v3, Lzs6;->c:Ljava/lang/Object;

    .line 970
    .line 971
    iget-object v4, v2, Lsw2;->k:Liw4;

    .line 972
    .line 973
    invoke-virtual {v4, v3}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 974
    .line 975
    .line 976
    iput-boolean v11, v2, Lsw2;->n:Z

    .line 977
    .line 978
    add-int/lit8 v10, v10, 0x1

    .line 979
    .line 980
    goto :goto_e

    .line 981
    :cond_1c
    iget-wide v5, v15, Lvw2;->c:J

    .line 982
    .line 983
    sub-long/2addr v3, v5

    .line 984
    long-to-float v2, v3

    .line 985
    div-float/2addr v2, v1

    .line 986
    float-to-long v1, v2

    .line 987
    iget-object v3, v0, Ld34;->i:[Ljava/lang/Object;

    .line 988
    .line 989
    iget v0, v0, Ld34;->k:I

    .line 990
    .line 991
    move v4, v10

    .line 992
    move v5, v11

    .line 993
    :goto_f
    if-ge v4, v0, :cond_20

    .line 994
    .line 995
    aget-object v6, v3, v4

    .line 996
    .line 997
    check-cast v6, Lsw2;

    .line 998
    .line 999
    iget-boolean v7, v6, Lsw2;->m:Z

    .line 1000
    .line 1001
    if-nez v7, :cond_1e

    .line 1002
    .line 1003
    iget-object v7, v6, Lsw2;->p:Lvw2;

    .line 1004
    .line 1005
    iget-object v7, v7, Lvw2;->b:Liw4;

    .line 1006
    .line 1007
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1008
    .line 1009
    invoke-virtual {v7, v8}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1010
    .line 1011
    .line 1012
    iget-boolean v7, v6, Lsw2;->n:Z

    .line 1013
    .line 1014
    if-eqz v7, :cond_1d

    .line 1015
    .line 1016
    iput-boolean v10, v6, Lsw2;->n:Z

    .line 1017
    .line 1018
    iput-wide v1, v6, Lsw2;->o:J

    .line 1019
    .line 1020
    :cond_1d
    iget-wide v7, v6, Lsw2;->o:J

    .line 1021
    .line 1022
    sub-long v7, v1, v7

    .line 1023
    .line 1024
    iget-object v9, v6, Lsw2;->l:Lzs6;

    .line 1025
    .line 1026
    invoke-virtual {v9, v7, v8}, Lzs6;->b(J)Ljava/lang/Object;

    .line 1027
    .line 1028
    .line 1029
    move-result-object v9

    .line 1030
    iget-object v13, v6, Lsw2;->k:Liw4;

    .line 1031
    .line 1032
    invoke-virtual {v13, v9}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1033
    .line 1034
    .line 1035
    iget-object v9, v6, Lsw2;->l:Lzs6;

    .line 1036
    .line 1037
    invoke-interface {v9, v7, v8}, Luh;->g(J)Z

    .line 1038
    .line 1039
    .line 1040
    move-result v7

    .line 1041
    iput-boolean v7, v6, Lsw2;->m:Z

    .line 1042
    .line 1043
    :cond_1e
    if-nez v7, :cond_1f

    .line 1044
    .line 1045
    move v5, v10

    .line 1046
    :cond_1f
    add-int/lit8 v4, v4, 0x1

    .line 1047
    .line 1048
    goto :goto_f

    .line 1049
    :cond_20
    xor-int/2addr v5, v11

    .line 1050
    iget-object v0, v15, Lvw2;->d:Liw4;

    .line 1051
    .line 1052
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1053
    .line 1054
    .line 1055
    move-result-object v1

    .line 1056
    invoke-virtual {v0, v1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1057
    .line 1058
    .line 1059
    :cond_21
    return-object v12

    .line 1060
    :pswitch_9
    check-cast v0, Lw82;

    .line 1061
    .line 1062
    check-cast v15, Lj02;

    .line 1063
    .line 1064
    check-cast v14, Lu77;

    .line 1065
    .line 1066
    check-cast v13, Lw82;

    .line 1067
    .line 1068
    move-object/from16 v1, p1

    .line 1069
    .line 1070
    check-cast v1, Lpg2;

    .line 1071
    .line 1072
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1073
    .line 1074
    .line 1075
    if-eqz v0, :cond_22

    .line 1076
    .line 1077
    invoke-interface {v0}, Lw82;->invoke()Ljava/lang/Object;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v0

    .line 1081
    check-cast v0, Ljava/lang/Number;

    .line 1082
    .line 1083
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1084
    .line 1085
    .line 1086
    move-result v0

    .line 1087
    :goto_10
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1088
    .line 1089
    .line 1090
    move-result-object v2

    .line 1091
    goto :goto_11

    .line 1092
    :cond_22
    if-eqz v15, :cond_23

    .line 1093
    .line 1094
    iget-object v0, v15, Lj02;->a:Lm67;

    .line 1095
    .line 1096
    if-eqz v0, :cond_23

    .line 1097
    .line 1098
    iget-object v2, v0, Lm67;->b:Lew4;

    .line 1099
    .line 1100
    invoke-virtual {v2}, Lew4;->g()F

    .line 1101
    .line 1102
    .line 1103
    move-result v2

    .line 1104
    iget-object v0, v0, Lm67;->c:Lew4;

    .line 1105
    .line 1106
    invoke-virtual {v0}, Lew4;->g()F

    .line 1107
    .line 1108
    .line 1109
    move-result v0

    .line 1110
    add-float/2addr v0, v2

    .line 1111
    goto :goto_10

    .line 1112
    :cond_23
    :goto_11
    const/high16 v0, 0x3f800000    # 1.0f

    .line 1113
    .line 1114
    if-eqz v2, :cond_24

    .line 1115
    .line 1116
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 1117
    .line 1118
    .line 1119
    move-result v2

    .line 1120
    neg-float v2, v2

    .line 1121
    const/high16 v3, 0x42400000    # 48.0f

    .line 1122
    .line 1123
    invoke-interface {v1}, Llk1;->a()F

    .line 1124
    .line 1125
    .line 1126
    move-result v4

    .line 1127
    mul-float/2addr v4, v3

    .line 1128
    div-float/2addr v2, v4

    .line 1129
    invoke-static {v2, v9, v0}, Lub3;->y(FFF)F

    .line 1130
    .line 1131
    .line 1132
    move-result v2

    .line 1133
    goto :goto_12

    .line 1134
    :cond_24
    iget-object v2, v14, Lu77;->p:Liw4;

    .line 1135
    .line 1136
    invoke-virtual {v2}, Liw4;->getValue()Ljava/lang/Object;

    .line 1137
    .line 1138
    .line 1139
    move-result-object v2

    .line 1140
    check-cast v2, Ljava/lang/Number;

    .line 1141
    .line 1142
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 1143
    .line 1144
    .line 1145
    move-result v2

    .line 1146
    :goto_12
    invoke-interface {v13}, Lw82;->invoke()Ljava/lang/Object;

    .line 1147
    .line 1148
    .line 1149
    move-result-object v3

    .line 1150
    check-cast v3, Ljava/lang/Number;

    .line 1151
    .line 1152
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 1153
    .line 1154
    .line 1155
    move-result v3

    .line 1156
    invoke-static {v3, v9, v0}, Lub3;->y(FFF)F

    .line 1157
    .line 1158
    .line 1159
    move-result v0

    .line 1160
    mul-float/2addr v0, v2

    .line 1161
    invoke-interface {v1, v0}, Lpg2;->v(F)V

    .line 1162
    .line 1163
    .line 1164
    return-object v12

    .line 1165
    :pswitch_a
    check-cast v0, Lhd3;

    .line 1166
    .line 1167
    check-cast v15, Ljz6;

    .line 1168
    .line 1169
    check-cast v14, Ldz6;

    .line 1170
    .line 1171
    check-cast v13, Lmv2;

    .line 1172
    .line 1173
    move-object/from16 v1, p1

    .line 1174
    .line 1175
    check-cast v1, Lln1;

    .line 1176
    .line 1177
    invoke-virtual {v0}, Lhd3;->b()Z

    .line 1178
    .line 1179
    .line 1180
    move-result v1

    .line 1181
    if-eqz v1, :cond_25

    .line 1182
    .line 1183
    iget-object v1, v0, Lhd3;->d:Lvx2;

    .line 1184
    .line 1185
    iget-object v2, v0, Lhd3;->v:Llc1;

    .line 1186
    .line 1187
    iget-object v3, v0, Lhd3;->w:Llc1;

    .line 1188
    .line 1189
    new-instance v4, Lgj5;

    .line 1190
    .line 1191
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 1192
    .line 1193
    .line 1194
    new-instance v5, Lox3;

    .line 1195
    .line 1196
    const/16 v6, 0x18

    .line 1197
    .line 1198
    invoke-direct {v5, v1, v2, v4, v6}, Lox3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1199
    .line 1200
    .line 1201
    iget-object v1, v15, Ljz6;->a:Lc05;

    .line 1202
    .line 1203
    invoke-interface {v1, v14, v13, v5, v3}, Lc05;->b(Ldz6;Lmv2;Lox3;Llc1;)V

    .line 1204
    .line 1205
    .line 1206
    new-instance v2, Lmz6;

    .line 1207
    .line 1208
    invoke-direct {v2, v15, v1}, Lmz6;-><init>(Ljz6;Lc05;)V

    .line 1209
    .line 1210
    .line 1211
    iget-object v1, v15, Ljz6;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1212
    .line 1213
    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 1214
    .line 1215
    .line 1216
    iput-object v2, v4, Lgj5;->i:Ljava/lang/Object;

    .line 1217
    .line 1218
    iput-object v2, v0, Lhd3;->e:Lmz6;

    .line 1219
    .line 1220
    :cond_25
    new-instance v0, Lrd;

    .line 1221
    .line 1222
    const/16 v1, 0x8

    .line 1223
    .line 1224
    invoke-direct {v0, v1}, Lrd;-><init>(B)V

    .line 1225
    .line 1226
    .line 1227
    return-object v0

    .line 1228
    :pswitch_b
    check-cast v0, Ljava/util/List;

    .line 1229
    .line 1230
    check-cast v15, Lmn3;

    .line 1231
    .line 1232
    check-cast v14, Lpa0;

    .line 1233
    .line 1234
    check-cast v13, Liv;

    .line 1235
    .line 1236
    move-object/from16 v1, p1

    .line 1237
    .line 1238
    check-cast v1, Ljava/lang/Boolean;

    .line 1239
    .line 1240
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1241
    .line 1242
    .line 1243
    move-result v1

    .line 1244
    iget-object v2, v15, Lmn3;->c:Lfw4;

    .line 1245
    .line 1246
    invoke-virtual {v2}, Lfw4;->g()I

    .line 1247
    .line 1248
    .line 1249
    move-result v2

    .line 1250
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1251
    .line 1252
    .line 1253
    invoke-static {v2, v0}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 1254
    .line 1255
    .line 1256
    move-result-object v0

    .line 1257
    check-cast v0, Lc40;

    .line 1258
    .line 1259
    if-nez v0, :cond_26

    .line 1260
    .line 1261
    sget-object v0, Lc40;->m:Lc40;

    .line 1262
    .line 1263
    :cond_26
    invoke-static {v1}, Ltj;->N(Z)Ljava/util/List;

    .line 1264
    .line 1265
    .line 1266
    move-result-object v2

    .line 1267
    invoke-static {v2, v0}, Ltj;->G(Ljava/util/List;Lc40;)I

    .line 1268
    .line 1269
    .line 1270
    move-result v0

    .line 1271
    if-eqz v1, :cond_27

    .line 1272
    .line 1273
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1274
    .line 1275
    .line 1276
    move-result-object v0

    .line 1277
    iget-object v2, v14, Lpa0;->g:Liw4;

    .line 1278
    .line 1279
    invoke-virtual {v2, v0}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1280
    .line 1281
    .line 1282
    goto :goto_13

    .line 1283
    :cond_27
    invoke-virtual {v15, v0}, Lmn3;->b(I)V

    .line 1284
    .line 1285
    .line 1286
    :goto_13
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1287
    .line 1288
    .line 1289
    new-instance v0, Lwr;

    .line 1290
    .line 1291
    invoke-direct {v0, v7, v1}, Lwr;-><init>(BZ)V

    .line 1292
    .line 1293
    .line 1294
    invoke-virtual {v13, v0}, Liv;->c(Lh92;)V

    .line 1295
    .line 1296
    .line 1297
    return-object v12

    .line 1298
    :pswitch_c
    check-cast v0, Lkg;

    .line 1299
    .line 1300
    check-cast v15, Lai;

    .line 1301
    .line 1302
    check-cast v14, Lh92;

    .line 1303
    .line 1304
    check-cast v13, Lcj5;

    .line 1305
    .line 1306
    move-object/from16 v1, p1

    .line 1307
    .line 1308
    check-cast v1, Lyh;

    .line 1309
    .line 1310
    iget-object v2, v0, Lkg;->c:Lai;

    .line 1311
    .line 1312
    invoke-static {v1, v2}, Ln86;->k0(Lyh;Lai;)V

    .line 1313
    .line 1314
    .line 1315
    iget-object v2, v1, Lyh;->e:Liw4;

    .line 1316
    .line 1317
    invoke-virtual {v2}, Liw4;->getValue()Ljava/lang/Object;

    .line 1318
    .line 1319
    .line 1320
    move-result-object v3

    .line 1321
    invoke-virtual {v0, v3}, Lkg;->c(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1322
    .line 1323
    .line 1324
    move-result-object v3

    .line 1325
    invoke-virtual {v2}, Liw4;->getValue()Ljava/lang/Object;

    .line 1326
    .line 1327
    .line 1328
    move-result-object v2

    .line 1329
    invoke-static {v3, v2}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1330
    .line 1331
    .line 1332
    move-result v2

    .line 1333
    if-nez v2, :cond_29

    .line 1334
    .line 1335
    iget-object v2, v0, Lkg;->c:Lai;

    .line 1336
    .line 1337
    iget-object v2, v2, Lai;->j:Liw4;

    .line 1338
    .line 1339
    invoke-virtual {v2, v3}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1340
    .line 1341
    .line 1342
    iget-object v2, v15, Lai;->j:Liw4;

    .line 1343
    .line 1344
    invoke-virtual {v2, v3}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 1345
    .line 1346
    .line 1347
    if-eqz v14, :cond_28

    .line 1348
    .line 1349
    invoke-interface {v14, v0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1350
    .line 1351
    .line 1352
    :cond_28
    invoke-virtual {v1}, Lyh;->a()V

    .line 1353
    .line 1354
    .line 1355
    iput-boolean v11, v13, Lcj5;->i:Z

    .line 1356
    .line 1357
    goto :goto_14

    .line 1358
    :cond_29
    if-eqz v14, :cond_2a

    .line 1359
    .line 1360
    invoke-interface {v14, v0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1361
    .line 1362
    .line 1363
    :cond_2a
    :goto_14
    return-object v12

    .line 1364
    :pswitch_d
    check-cast v0, Lpf;

    .line 1365
    .line 1366
    check-cast v15, Ljava/lang/String;

    .line 1367
    .line 1368
    check-cast v14, Ll92;

    .line 1369
    .line 1370
    check-cast v13, Landroid/content/Context;

    .line 1371
    .line 1372
    move-object/from16 v1, p1

    .line 1373
    .line 1374
    check-cast v1, Lgc3;

    .line 1375
    .line 1376
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1377
    .line 1378
    .line 1379
    new-instance v4, Lc2;

    .line 1380
    .line 1381
    invoke-direct {v4, v0, v15, v10}, Lc2;-><init>(Lpf;Ljava/lang/String;B)V

    .line 1382
    .line 1383
    .line 1384
    new-instance v0, Lyz0;

    .line 1385
    .line 1386
    const v5, 0x290b7044

    .line 1387
    .line 1388
    .line 1389
    invoke-direct {v0, v5, v11, v4}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1390
    .line 1391
    .line 1392
    invoke-static {v1, v2, v0, v3}, Lgc3;->j0(Lgc3;Ljava/lang/String;Lm92;I)V

    .line 1393
    .line 1394
    .line 1395
    new-instance v0, Ld2;

    .line 1396
    .line 1397
    invoke-direct {v0, v14, v13, v10}, Ld2;-><init>(Ll92;Landroid/content/Context;B)V

    .line 1398
    .line 1399
    .line 1400
    new-instance v4, Lyz0;

    .line 1401
    .line 1402
    const v5, 0xa6505fb

    .line 1403
    .line 1404
    .line 1405
    invoke-direct {v4, v5, v11, v0}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1406
    .line 1407
    .line 1408
    invoke-static {v1, v2, v4, v3}, Lgc3;->j0(Lgc3;Ljava/lang/String;Lm92;I)V

    .line 1409
    .line 1410
    .line 1411
    return-object v12

    .line 1412
    nop

    .line 1413
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
