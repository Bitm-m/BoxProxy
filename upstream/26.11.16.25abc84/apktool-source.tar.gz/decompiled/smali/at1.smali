.class public final Lat1;
.super Ljavax/net/ssl/SSLException;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"
