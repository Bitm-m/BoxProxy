.class public final Lb62;
.super Llz3;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements La62;


# instance fields
.field public w:Lz52;


# virtual methods
.method public final x0(Lw52;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb62;->w:Lz52;

    .line 2
    .line 3
    iget-object p0, p0, Lz52;->a:Lh92;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method
