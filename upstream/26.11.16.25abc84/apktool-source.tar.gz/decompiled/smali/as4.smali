.class public final Las4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/String;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Las4;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Las4;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Las4;->k:Ljava/lang/String;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Las4;->i:B

    .line 4
    .line 5
    const/16 v3, 0x36

    .line 6
    .line 7
    const/4 v4, 0x3

    .line 8
    const/high16 v5, 0x40800000    # 4.0f

    .line 9
    .line 10
    const/16 v6, 0x12

    .line 11
    .line 12
    sget-object v9, Loc7;->a:Loc7;

    .line 13
    .line 14
    sget-object v10, Lq83;->a0:Lif2;

    .line 15
    .line 16
    iget-object v11, v0, Las4;->j:Ljava/lang/Object;

    .line 17
    .line 18
    sget-object v12, Ljz3;->i:Ljz3;

    .line 19
    .line 20
    const/4 v13, 0x1

    .line 21
    const/4 v14, 0x0

    .line 22
    packed-switch v1, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    move-object/from16 v1, p1

    .line 26
    .line 27
    check-cast v1, Lvx0;

    .line 28
    .line 29
    move-object/from16 v2, p2

    .line 30
    .line 31
    check-cast v2, Lla2;

    .line 32
    .line 33
    move-object/from16 v3, p3

    .line 34
    .line 35
    check-cast v3, Ljava/lang/Number;

    .line 36
    .line 37
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    and-int/lit8 v1, v3, 0x11

    .line 45
    .line 46
    const/16 v4, 0x10

    .line 47
    .line 48
    if-eq v1, v4, :cond_0

    .line 49
    .line 50
    move v1, v13

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    move v1, v14

    .line 53
    :goto_0
    and-int/2addr v3, v13

    .line 54
    invoke-virtual {v2, v3, v1}, Lla2;->S(IZ)Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    if-eqz v1, :cond_2

    .line 59
    .line 60
    const/high16 v1, 0x41800000    # 16.0f

    .line 61
    .line 62
    invoke-static {v12, v1}, Lif0;->P(Lmz3;F)Lmz3;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    check-cast v11, Lqd1;

    .line 67
    .line 68
    sget-object v3, Lba7;->d:Lpv;

    .line 69
    .line 70
    sget-object v4, Lr6;->w:Ll20;

    .line 71
    .line 72
    invoke-static {v3, v4, v2, v14}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    iget-wide v4, v2, Lla2;->T:J

    .line 77
    .line 78
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 79
    .line 80
    .line 81
    move-result v4

    .line 82
    invoke-virtual {v2}, Lla2;->m()Lky4;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    invoke-static {v2, v1}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    sget-object v6, Lv11;->d:Lr6;

    .line 91
    .line 92
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v2}, Lla2;->e0()V

    .line 96
    .line 97
    .line 98
    iget-boolean v6, v2, Lla2;->S:Z

    .line 99
    .line 100
    if-eqz v6, :cond_1

    .line 101
    .line 102
    invoke-virtual {v2, v10}, Lla2;->l(Lw82;)V

    .line 103
    .line 104
    .line 105
    goto :goto_1

    .line 106
    :cond_1
    invoke-virtual {v2}, Lla2;->n0()V

    .line 107
    .line 108
    .line 109
    :goto_1
    sget-object v6, Lr6;->S:La11;

    .line 110
    .line 111
    invoke-static {v6, v2, v3}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    sget-object v3, Lr6;->R:La11;

    .line 115
    .line 116
    invoke-static {v3, v2, v5}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    sget-object v4, Lr6;->T:La11;

    .line 124
    .line 125
    invoke-static {v4, v2, v3}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    invoke-static {v2}, Lxt6;->k(Lla2;)V

    .line 129
    .line 130
    .line 131
    sget-object v3, Lr6;->Q:La11;

    .line 132
    .line 133
    invoke-static {v3, v2, v1}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 134
    .line 135
    .line 136
    iget-object v15, v11, Lqd1;->b:Ljava/lang/String;

    .line 137
    .line 138
    sget-object v1, Lbq3;->b:Lps1;

    .line 139
    .line 140
    invoke-virtual {v2, v1}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    check-cast v3, Lyp3;

    .line 145
    .line 146
    iget-object v3, v3, Lyp3;->b:Lja7;

    .line 147
    .line 148
    iget-object v3, v3, Lja7;->h:Lk17;

    .line 149
    .line 150
    const/16 v35, 0x0

    .line 151
    .line 152
    const v36, 0x1fffe

    .line 153
    .line 154
    .line 155
    const/16 v16, 0x0

    .line 156
    .line 157
    const-wide/16 v17, 0x0

    .line 158
    .line 159
    const-wide/16 v19, 0x0

    .line 160
    .line 161
    const/16 v21, 0x0

    .line 162
    .line 163
    const/16 v22, 0x0

    .line 164
    .line 165
    const-wide/16 v23, 0x0

    .line 166
    .line 167
    const/16 v25, 0x0

    .line 168
    .line 169
    const-wide/16 v26, 0x0

    .line 170
    .line 171
    const/16 v28, 0x0

    .line 172
    .line 173
    const/16 v29, 0x0

    .line 174
    .line 175
    const/16 v30, 0x0

    .line 176
    .line 177
    const/16 v31, 0x0

    .line 178
    .line 179
    const/16 v34, 0x0

    .line 180
    .line 181
    move-object/from16 v33, v2

    .line 182
    .line 183
    move-object/from16 v32, v3

    .line 184
    .line 185
    invoke-static/range {v15 .. v36}, Lrz6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v2, v1}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    check-cast v1, Lyp3;

    .line 193
    .line 194
    iget-object v1, v1, Lyp3;->b:Lja7;

    .line 195
    .line 196
    iget-object v1, v1, Lja7;->k:Lk17;

    .line 197
    .line 198
    iget-object v15, v0, Las4;->k:Ljava/lang/String;

    .line 199
    .line 200
    move-object/from16 v32, v1

    .line 201
    .line 202
    invoke-static/range {v15 .. v36}, Lrz6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v2, v13}, Lla2;->r(Z)V

    .line 206
    .line 207
    .line 208
    goto :goto_2

    .line 209
    :cond_2
    invoke-virtual {v2}, Lla2;->V()V

    .line 210
    .line 211
    .line 212
    :goto_2
    return-object v9

    .line 213
    :pswitch_0
    move-object/from16 v1, p1

    .line 214
    .line 215
    check-cast v1, Lov0;

    .line 216
    .line 217
    iget-wide v7, v1, Lov0;->a:J

    .line 218
    .line 219
    move-object/from16 v1, p2

    .line 220
    .line 221
    check-cast v1, Lla2;

    .line 222
    .line 223
    move-object/from16 v17, p3

    .line 224
    .line 225
    check-cast v17, Ljava/lang/Number;

    .line 226
    .line 227
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 228
    .line 229
    .line 230
    move-result v17

    .line 231
    and-int/lit8 v18, v17, 0x6

    .line 232
    .line 233
    if-nez v18, :cond_4

    .line 234
    .line 235
    invoke-virtual {v1, v7, v8}, Lla2;->f(J)Z

    .line 236
    .line 237
    .line 238
    move-result v18

    .line 239
    if-eqz v18, :cond_3

    .line 240
    .line 241
    const/4 v15, 0x4

    .line 242
    goto :goto_3

    .line 243
    :cond_3
    const/4 v15, 0x2

    .line 244
    :goto_3
    or-int v17, v17, v15

    .line 245
    .line 246
    :cond_4
    and-int/lit8 v15, v17, 0x13

    .line 247
    .line 248
    if-eq v15, v6, :cond_5

    .line 249
    .line 250
    move v6, v13

    .line 251
    goto :goto_4

    .line 252
    :cond_5
    move v6, v14

    .line 253
    :goto_4
    and-int/lit8 v15, v17, 0x1

    .line 254
    .line 255
    invoke-virtual {v1, v15, v6}, Lla2;->S(IZ)Z

    .line 256
    .line 257
    .line 258
    move-result v6

    .line 259
    if-eqz v6, :cond_8

    .line 260
    .line 261
    sget-object v6, Lr6;->x:Ll20;

    .line 262
    .line 263
    new-instance v15, Lrv;

    .line 264
    .line 265
    new-instance v2, Lzy1;

    .line 266
    .line 267
    invoke-direct {v2, v4}, Lzy1;-><init>(B)V

    .line 268
    .line 269
    .line 270
    invoke-direct {v15, v5, v13, v2}, Lrv;-><init>(FZLzy1;)V

    .line 271
    .line 272
    .line 273
    check-cast v11, Lmz3;

    .line 274
    .line 275
    invoke-static {v15, v6, v1, v3}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 276
    .line 277
    .line 278
    move-result-object v2

    .line 279
    iget-wide v3, v1, Lla2;->T:J

    .line 280
    .line 281
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 282
    .line 283
    .line 284
    move-result v3

    .line 285
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 286
    .line 287
    .line 288
    move-result-object v4

    .line 289
    invoke-static {v1, v11}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 290
    .line 291
    .line 292
    move-result-object v5

    .line 293
    sget-object v6, Lv11;->d:Lr6;

    .line 294
    .line 295
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 296
    .line 297
    .line 298
    invoke-virtual {v1}, Lla2;->e0()V

    .line 299
    .line 300
    .line 301
    iget-boolean v6, v1, Lla2;->S:Z

    .line 302
    .line 303
    if-eqz v6, :cond_6

    .line 304
    .line 305
    invoke-virtual {v1, v10}, Lla2;->l(Lw82;)V

    .line 306
    .line 307
    .line 308
    goto :goto_5

    .line 309
    :cond_6
    invoke-virtual {v1}, Lla2;->n0()V

    .line 310
    .line 311
    .line 312
    :goto_5
    sget-object v6, Lr6;->S:La11;

    .line 313
    .line 314
    invoke-static {v6, v1, v2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    sget-object v2, Lr6;->R:La11;

    .line 318
    .line 319
    invoke-static {v2, v1, v4}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 323
    .line 324
    .line 325
    move-result-object v3

    .line 326
    sget-object v4, Lr6;->T:La11;

    .line 327
    .line 328
    invoke-static {v4, v1, v3}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    invoke-static {v1}, Lxt6;->k(Lla2;)V

    .line 332
    .line 333
    .line 334
    sget-object v3, Lr6;->Q:La11;

    .line 335
    .line 336
    invoke-static {v3, v1, v5}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 337
    .line 338
    .line 339
    sget-object v5, Lr6;->o:Ln20;

    .line 340
    .line 341
    invoke-static {v5, v14}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 342
    .line 343
    .line 344
    move-result-object v5

    .line 345
    iget-wide v13, v1, Lla2;->T:J

    .line 346
    .line 347
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 348
    .line 349
    .line 350
    move-result v11

    .line 351
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 352
    .line 353
    .line 354
    move-result-object v13

    .line 355
    invoke-static {v1, v12}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 356
    .line 357
    .line 358
    move-result-object v14

    .line 359
    invoke-virtual {v1}, Lla2;->e0()V

    .line 360
    .line 361
    .line 362
    iget-boolean v15, v1, Lla2;->S:Z

    .line 363
    .line 364
    if-eqz v15, :cond_7

    .line 365
    .line 366
    invoke-virtual {v1, v10}, Lla2;->l(Lw82;)V

    .line 367
    .line 368
    .line 369
    goto :goto_6

    .line 370
    :cond_7
    invoke-virtual {v1}, Lla2;->n0()V

    .line 371
    .line 372
    .line 373
    :goto_6
    invoke-static {v6, v1, v5}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 374
    .line 375
    .line 376
    invoke-static {v2, v1, v13}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 377
    .line 378
    .line 379
    invoke-static {v11, v1, v4, v1}, Lzi6;->y(ILla2;La11;Lla2;)V

    .line 380
    .line 381
    .line 382
    invoke-static {v3, v1, v14}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 383
    .line 384
    .line 385
    const/16 v2, 0x11

    .line 386
    .line 387
    invoke-static {v2}, Lcu6;->f(I)J

    .line 388
    .line 389
    .line 390
    move-result-wide v21

    .line 391
    sget-object v23, Lt72;->m:Lt72;

    .line 392
    .line 393
    sget-wide v19, Lov0;->g:J

    .line 394
    .line 395
    const/16 v37, 0x6000

    .line 396
    .line 397
    const v38, 0x3bfaa

    .line 398
    .line 399
    .line 400
    const-string v17, "0"

    .line 401
    .line 402
    const/16 v18, 0x0

    .line 403
    .line 404
    const/16 v24, 0x0

    .line 405
    .line 406
    const-wide/16 v25, 0x0

    .line 407
    .line 408
    const/16 v27, 0x0

    .line 409
    .line 410
    const-wide/16 v28, 0x0

    .line 411
    .line 412
    const/16 v30, 0x0

    .line 413
    .line 414
    const/16 v31, 0x0

    .line 415
    .line 416
    const/16 v32, 0x1

    .line 417
    .line 418
    const/16 v33, 0x0

    .line 419
    .line 420
    const/16 v34, 0x0

    .line 421
    .line 422
    const v36, 0x186186

    .line 423
    .line 424
    .line 425
    move-object/from16 v35, v1

    .line 426
    .line 427
    invoke-static/range {v17 .. v38}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 428
    .line 429
    .line 430
    const v2, 0x3f19999a    # 0.6f

    .line 431
    .line 432
    .line 433
    invoke-static {v12, v2}, Lef6;->d(Lmz3;F)Lmz3;

    .line 434
    .line 435
    .line 436
    move-result-object v2

    .line 437
    const v3, 0x414c0001    # 12.750001f

    .line 438
    .line 439
    .line 440
    invoke-static {v2, v3}, Lef6;->e(Lmz3;F)Lmz3;

    .line 441
    .line 442
    .line 443
    move-result-object v2

    .line 444
    const v3, 0x40cc0001    # 6.3750005f

    .line 445
    .line 446
    .line 447
    invoke-static {v3}, Lmo5;->a(F)Lko5;

    .line 448
    .line 449
    .line 450
    move-result-object v3

    .line 451
    invoke-static {v2, v3}, Lom;->z(Lmz3;Lw96;)Lmz3;

    .line 452
    .line 453
    .line 454
    move-result-object v2

    .line 455
    sget-object v3, Lu60;->a0:Lor2;

    .line 456
    .line 457
    invoke-static {v2, v7, v8, v3}, Leb;->z(Lmz3;JLw96;)Lmz3;

    .line 458
    .line 459
    .line 460
    move-result-object v2

    .line 461
    const/4 v3, 0x0

    .line 462
    invoke-static {v2, v1, v3}, Ljb0;->a(Lmz3;Lla2;I)V

    .line 463
    .line 464
    .line 465
    const/4 v2, 0x1

    .line 466
    invoke-virtual {v1, v2}, Lla2;->r(Z)V

    .line 467
    .line 468
    .line 469
    sget-object v2, Lbx0;->a:Lps1;

    .line 470
    .line 471
    invoke-virtual {v1, v2}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 472
    .line 473
    .line 474
    move-result-object v2

    .line 475
    check-cast v2, Lax0;

    .line 476
    .line 477
    invoke-virtual {v2}, Lax0;->n()J

    .line 478
    .line 479
    .line 480
    move-result-wide v19

    .line 481
    const/16 v2, 0xc

    .line 482
    .line 483
    invoke-static {v2}, Lcu6;->f(I)J

    .line 484
    .line 485
    .line 486
    move-result-wide v21

    .line 487
    const/16 v37, 0x6180

    .line 488
    .line 489
    const v38, 0x3afea

    .line 490
    .line 491
    .line 492
    iget-object v0, v0, Las4;->k:Ljava/lang/String;

    .line 493
    .line 494
    const/16 v23, 0x0

    .line 495
    .line 496
    const/16 v30, 0x2

    .line 497
    .line 498
    const/16 v36, 0x6000

    .line 499
    .line 500
    move-object/from16 v17, v0

    .line 501
    .line 502
    invoke-static/range {v17 .. v38}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 503
    .line 504
    .line 505
    const/4 v2, 0x1

    .line 506
    invoke-virtual {v1, v2}, Lla2;->r(Z)V

    .line 507
    .line 508
    .line 509
    goto :goto_7

    .line 510
    :cond_8
    invoke-virtual {v1}, Lla2;->V()V

    .line 511
    .line 512
    .line 513
    :goto_7
    return-object v9

    .line 514
    :pswitch_1
    move-object/from16 v1, p1

    .line 515
    .line 516
    check-cast v1, Lov0;

    .line 517
    .line 518
    iget-wide v1, v1, Lov0;->a:J

    .line 519
    .line 520
    move-object/from16 v7, p2

    .line 521
    .line 522
    check-cast v7, Lla2;

    .line 523
    .line 524
    move-object/from16 v8, p3

    .line 525
    .line 526
    check-cast v8, Ljava/lang/Number;

    .line 527
    .line 528
    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    .line 529
    .line 530
    .line 531
    move-result v8

    .line 532
    and-int/lit8 v13, v8, 0x6

    .line 533
    .line 534
    if-nez v13, :cond_a

    .line 535
    .line 536
    invoke-virtual {v7, v1, v2}, Lla2;->f(J)Z

    .line 537
    .line 538
    .line 539
    move-result v13

    .line 540
    if-eqz v13, :cond_9

    .line 541
    .line 542
    const/4 v15, 0x4

    .line 543
    goto :goto_8

    .line 544
    :cond_9
    const/4 v15, 0x2

    .line 545
    :goto_8
    or-int/2addr v8, v15

    .line 546
    :cond_a
    and-int/lit8 v13, v8, 0x13

    .line 547
    .line 548
    if-eq v13, v6, :cond_b

    .line 549
    .line 550
    const/4 v6, 0x1

    .line 551
    :goto_9
    const/4 v13, 0x1

    .line 552
    goto :goto_a

    .line 553
    :cond_b
    const/4 v6, 0x0

    .line 554
    goto :goto_9

    .line 555
    :goto_a
    and-int/2addr v8, v13

    .line 556
    invoke-virtual {v7, v8, v6}, Lla2;->S(IZ)Z

    .line 557
    .line 558
    .line 559
    move-result v6

    .line 560
    if-eqz v6, :cond_e

    .line 561
    .line 562
    sget-object v6, Lr6;->x:Ll20;

    .line 563
    .line 564
    new-instance v8, Lrv;

    .line 565
    .line 566
    new-instance v14, Lzy1;

    .line 567
    .line 568
    invoke-direct {v14, v4}, Lzy1;-><init>(B)V

    .line 569
    .line 570
    .line 571
    invoke-direct {v8, v5, v13, v14}, Lrv;-><init>(FZLzy1;)V

    .line 572
    .line 573
    .line 574
    check-cast v11, Lmz3;

    .line 575
    .line 576
    invoke-static {v8, v6, v7, v3}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 577
    .line 578
    .line 579
    move-result-object v3

    .line 580
    iget-wide v4, v7, Lla2;->T:J

    .line 581
    .line 582
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 583
    .line 584
    .line 585
    move-result v4

    .line 586
    invoke-virtual {v7}, Lla2;->m()Lky4;

    .line 587
    .line 588
    .line 589
    move-result-object v5

    .line 590
    invoke-static {v7, v11}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 591
    .line 592
    .line 593
    move-result-object v6

    .line 594
    sget-object v8, Lv11;->d:Lr6;

    .line 595
    .line 596
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 597
    .line 598
    .line 599
    invoke-virtual {v7}, Lla2;->e0()V

    .line 600
    .line 601
    .line 602
    iget-boolean v8, v7, Lla2;->S:Z

    .line 603
    .line 604
    if-eqz v8, :cond_c

    .line 605
    .line 606
    invoke-virtual {v7, v10}, Lla2;->l(Lw82;)V

    .line 607
    .line 608
    .line 609
    goto :goto_b

    .line 610
    :cond_c
    invoke-virtual {v7}, Lla2;->n0()V

    .line 611
    .line 612
    .line 613
    :goto_b
    sget-object v8, Lr6;->S:La11;

    .line 614
    .line 615
    invoke-static {v8, v7, v3}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 616
    .line 617
    .line 618
    sget-object v3, Lr6;->R:La11;

    .line 619
    .line 620
    invoke-static {v3, v7, v5}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 621
    .line 622
    .line 623
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 624
    .line 625
    .line 626
    move-result-object v4

    .line 627
    sget-object v5, Lr6;->T:La11;

    .line 628
    .line 629
    invoke-static {v5, v7, v4}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 630
    .line 631
    .line 632
    invoke-static {v7}, Lxt6;->k(Lla2;)V

    .line 633
    .line 634
    .line 635
    sget-object v4, Lr6;->Q:La11;

    .line 636
    .line 637
    invoke-static {v4, v7, v6}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 638
    .line 639
    .line 640
    sget-object v6, Lr6;->o:Ln20;

    .line 641
    .line 642
    const/4 v11, 0x0

    .line 643
    invoke-static {v6, v11}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 644
    .line 645
    .line 646
    move-result-object v6

    .line 647
    iget-wide v13, v7, Lla2;->T:J

    .line 648
    .line 649
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 650
    .line 651
    .line 652
    move-result v11

    .line 653
    invoke-virtual {v7}, Lla2;->m()Lky4;

    .line 654
    .line 655
    .line 656
    move-result-object v13

    .line 657
    invoke-static {v7, v12}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 658
    .line 659
    .line 660
    move-result-object v14

    .line 661
    invoke-virtual {v7}, Lla2;->e0()V

    .line 662
    .line 663
    .line 664
    iget-boolean v15, v7, Lla2;->S:Z

    .line 665
    .line 666
    if-eqz v15, :cond_d

    .line 667
    .line 668
    invoke-virtual {v7, v10}, Lla2;->l(Lw82;)V

    .line 669
    .line 670
    .line 671
    goto :goto_c

    .line 672
    :cond_d
    invoke-virtual {v7}, Lla2;->n0()V

    .line 673
    .line 674
    .line 675
    :goto_c
    invoke-static {v8, v7, v6}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 676
    .line 677
    .line 678
    invoke-static {v3, v7, v13}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    invoke-static {v11, v7, v5, v7}, Lzi6;->y(ILla2;La11;Lla2;)V

    .line 682
    .line 683
    .line 684
    invoke-static {v4, v7, v14}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 685
    .line 686
    .line 687
    sget-object v3, Lbq3;->b:Lps1;

    .line 688
    .line 689
    invoke-virtual {v7, v3}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 690
    .line 691
    .line 692
    move-result-object v4

    .line 693
    check-cast v4, Lyp3;

    .line 694
    .line 695
    iget-object v4, v4, Lyp3;->b:Lja7;

    .line 696
    .line 697
    iget-object v4, v4, Lja7;->h:Lk17;

    .line 698
    .line 699
    sget-object v23, Lt72;->m:Lt72;

    .line 700
    .line 701
    sget-wide v19, Lov0;->g:J

    .line 702
    .line 703
    const/16 v37, 0x6000

    .line 704
    .line 705
    const v38, 0x1bfba

    .line 706
    .line 707
    .line 708
    const-string v17, "0"

    .line 709
    .line 710
    const/16 v18, 0x0

    .line 711
    .line 712
    const-wide/16 v21, 0x0

    .line 713
    .line 714
    const/16 v24, 0x0

    .line 715
    .line 716
    const-wide/16 v25, 0x0

    .line 717
    .line 718
    const/16 v27, 0x0

    .line 719
    .line 720
    const-wide/16 v28, 0x0

    .line 721
    .line 722
    const/16 v30, 0x0

    .line 723
    .line 724
    const/16 v31, 0x0

    .line 725
    .line 726
    const/16 v32, 0x1

    .line 727
    .line 728
    const/16 v33, 0x0

    .line 729
    .line 730
    const v36, 0x180186

    .line 731
    .line 732
    .line 733
    move-object/from16 v34, v4

    .line 734
    .line 735
    move-object/from16 v35, v7

    .line 736
    .line 737
    invoke-static/range {v17 .. v38}, Lrz6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 738
    .line 739
    .line 740
    move-object/from16 v4, v35

    .line 741
    .line 742
    const v5, 0x3f19999a    # 0.6f

    .line 743
    .line 744
    .line 745
    invoke-static {v12, v5}, Lef6;->d(Lmz3;F)Lmz3;

    .line 746
    .line 747
    .line 748
    move-result-object v5

    .line 749
    invoke-static {v4}, Lho3;->H(Lla2;)F

    .line 750
    .line 751
    .line 752
    move-result v6

    .line 753
    invoke-static {v5, v6}, Lef6;->e(Lmz3;F)Lmz3;

    .line 754
    .line 755
    .line 756
    move-result-object v5

    .line 757
    invoke-static {v4}, Lho3;->H(Lla2;)F

    .line 758
    .line 759
    .line 760
    move-result v6

    .line 761
    const/high16 v7, 0x40000000    # 2.0f

    .line 762
    .line 763
    div-float/2addr v6, v7

    .line 764
    invoke-static {v6}, Lmo5;->a(F)Lko5;

    .line 765
    .line 766
    .line 767
    move-result-object v6

    .line 768
    invoke-static {v5, v6}, Lom;->z(Lmz3;Lw96;)Lmz3;

    .line 769
    .line 770
    .line 771
    move-result-object v5

    .line 772
    sget-object v6, Lu60;->a0:Lor2;

    .line 773
    .line 774
    invoke-static {v5, v1, v2, v6}, Leb;->z(Lmz3;JLw96;)Lmz3;

    .line 775
    .line 776
    .line 777
    move-result-object v1

    .line 778
    const/4 v11, 0x0

    .line 779
    invoke-static {v1, v4, v11}, Ljb0;->a(Lmz3;Lla2;I)V

    .line 780
    .line 781
    .line 782
    const/4 v2, 0x1

    .line 783
    invoke-virtual {v4, v2}, Lla2;->r(Z)V

    .line 784
    .line 785
    .line 786
    invoke-virtual {v4, v3}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v1

    .line 790
    check-cast v1, Lyp3;

    .line 791
    .line 792
    iget-object v1, v1, Lyp3;->b:Lja7;

    .line 793
    .line 794
    iget-object v1, v1, Lja7;->n:Lk17;

    .line 795
    .line 796
    invoke-virtual {v4, v3}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 797
    .line 798
    .line 799
    move-result-object v2

    .line 800
    check-cast v2, Lyp3;

    .line 801
    .line 802
    iget-object v2, v2, Lyp3;->a:Luv0;

    .line 803
    .line 804
    iget-wide v2, v2, Luv0;->s:J

    .line 805
    .line 806
    const/16 v37, 0x6180

    .line 807
    .line 808
    const v38, 0x1affa

    .line 809
    .line 810
    .line 811
    iget-object v0, v0, Las4;->k:Ljava/lang/String;

    .line 812
    .line 813
    const/16 v23, 0x0

    .line 814
    .line 815
    const/16 v30, 0x2

    .line 816
    .line 817
    const/16 v36, 0x0

    .line 818
    .line 819
    move-object/from16 v17, v0

    .line 820
    .line 821
    move-object/from16 v34, v1

    .line 822
    .line 823
    move-wide/from16 v19, v2

    .line 824
    .line 825
    invoke-static/range {v17 .. v38}, Lrz6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 826
    .line 827
    .line 828
    const/4 v2, 0x1

    .line 829
    invoke-virtual {v4, v2}, Lla2;->r(Z)V

    .line 830
    .line 831
    .line 832
    goto :goto_d

    .line 833
    :cond_e
    move-object v4, v7

    .line 834
    invoke-virtual {v4}, Lla2;->V()V

    .line 835
    .line 836
    .line 837
    :goto_d
    return-object v9

    .line 838
    nop

    .line 839
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
