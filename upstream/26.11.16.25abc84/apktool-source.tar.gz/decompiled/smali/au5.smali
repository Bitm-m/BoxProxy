.class public final synthetic Lau5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lw82;

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Lov0;

.field public final synthetic m:Leu5;

.field public final synthetic n:F

.field public final synthetic o:F

.field public final synthetic p:F

.field public final synthetic q:Lmz3;

.field public final synthetic r:F

.field public final synthetic s:Lh92;

.field public final synthetic t:Lh92;

.field public final synthetic u:Lmz3;


# direct methods
.method public synthetic constructor <init>(Lw82;ZZLov0;Leu5;FFFLmz3;FLh92;Lh92;Lmz3;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lau5;->i:Lw82;

    .line 5
    .line 6
    iput-boolean p2, p0, Lau5;->j:Z

    .line 7
    .line 8
    iput-boolean p3, p0, Lau5;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Lau5;->l:Lov0;

    .line 11
    .line 12
    iput-object p5, p0, Lau5;->m:Leu5;

    .line 13
    .line 14
    iput p6, p0, Lau5;->n:F

    .line 15
    .line 16
    iput p7, p0, Lau5;->o:F

    .line 17
    .line 18
    iput p8, p0, Lau5;->p:F

    .line 19
    .line 20
    iput-object p9, p0, Lau5;->q:Lmz3;

    .line 21
    .line 22
    iput p10, p0, Lau5;->r:F

    .line 23
    .line 24
    iput-object p11, p0, Lau5;->s:Lh92;

    .line 25
    .line 26
    iput-object p12, p0, Lau5;->t:Lh92;

    .line 27
    .line 28
    iput-object p13, p0, Lau5;->u:Lmz3;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v13, p1

    .line 4
    .line 5
    check-cast v13, Lla2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const/16 v1, 0x1b1

    .line 15
    .line 16
    invoke-static {v1}, Lt36;->a0(I)I

    .line 17
    .line 18
    .line 19
    move-result v14

    .line 20
    iget-object v1, v0, Lau5;->i:Lw82;

    .line 21
    .line 22
    move-object v2, v1

    .line 23
    iget-boolean v1, v0, Lau5;->j:Z

    .line 24
    .line 25
    move-object v3, v2

    .line 26
    iget-boolean v2, v0, Lau5;->k:Z

    .line 27
    .line 28
    move-object v4, v3

    .line 29
    iget-object v3, v0, Lau5;->l:Lov0;

    .line 30
    .line 31
    move-object v5, v4

    .line 32
    iget-object v4, v0, Lau5;->m:Leu5;

    .line 33
    .line 34
    move-object v6, v5

    .line 35
    iget v5, v0, Lau5;->n:F

    .line 36
    .line 37
    move-object v7, v6

    .line 38
    iget v6, v0, Lau5;->o:F

    .line 39
    .line 40
    move-object v8, v7

    .line 41
    iget v7, v0, Lau5;->p:F

    .line 42
    .line 43
    move-object v9, v8

    .line 44
    iget-object v8, v0, Lau5;->q:Lmz3;

    .line 45
    .line 46
    move-object v10, v9

    .line 47
    iget v9, v0, Lau5;->r:F

    .line 48
    .line 49
    move-object v11, v10

    .line 50
    iget-object v10, v0, Lau5;->s:Lh92;

    .line 51
    .line 52
    move-object v12, v11

    .line 53
    iget-object v11, v0, Lau5;->t:Lh92;

    .line 54
    .line 55
    iget-object v0, v0, Lau5;->u:Lmz3;

    .line 56
    .line 57
    move-object v15, v12

    .line 58
    move-object v12, v0

    .line 59
    move-object v0, v15

    .line 60
    invoke-static/range {v0 .. v14}, Lta3;->h(Lw82;ZZLov0;Leu5;FFFLmz3;FLh92;Lh92;Lmz3;Lla2;I)V

    .line 61
    .line 62
    .line 63
    sget-object v0, Loc7;->a:Loc7;

    .line 64
    .line 65
    return-object v0
.end method
