.class public final Lb24;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lc03;


# instance fields
.field public final a:Lia6;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lse0;->j:Lse0;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    const/16 v2, 0x10

    .line 8
    .line 9
    invoke-static {v2, v1, v0}, Lkt6;->o(IILse0;)Lia6;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, Lb24;->a:Lia6;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final a()Lw32;
    .locals 0

    .line 1
    iget-object p0, p0, Lb24;->a:Lia6;

    .line 2
    .line 3
    return-object p0
.end method

.method public final b(Lb03;Lca1;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lb24;->a:Lia6;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lia6;->d(Ljava/lang/Object;Lca1;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    sget-object p1, Lie1;->i:Lie1;

    .line 8
    .line 9
    if-ne p0, p1, :cond_0

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    sget-object p0, Loc7;->a:Loc7;

    .line 13
    .line 14
    return-object p0
.end method

.method public final c(Lb03;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb24;->a:Lia6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lia6;->e(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method
