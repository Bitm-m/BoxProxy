.class public final La42;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lx32;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ll45;


# direct methods
.method public synthetic constructor <init>(Ll45;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La42;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La42;->j:Ll45;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;Lca1;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte p2, p0, La42;->i:B

    .line 2
    .line 3
    sget-object v0, Loc7;->a:Loc7;

    .line 4
    .line 5
    iget-object p0, p0, La42;->j:Ll45;

    .line 6
    .line 7
    packed-switch p2, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast p1, Ljn2;

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Ll45;->setValue(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-object v0

    .line 16
    :pswitch_0
    invoke-virtual {p0, p1}, Ll45;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
