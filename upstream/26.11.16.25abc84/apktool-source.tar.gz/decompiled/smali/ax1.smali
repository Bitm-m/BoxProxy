.class public Lax1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ly63;


# static fields
.field public static final a:Lh27;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lh27;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lh27;-><init>(Lwq6;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lax1;->a:Lh27;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public a()Lu4;
    .locals 0

    .line 1
    sget-object p0, Lzw1;->c:Lzw1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final b()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public c(Lo91;Lio0;Lyy0;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public d()[Lzg4;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    new-array p0, p0, [Lzg4;

    .line 3
    .line 4
    return-object p0
.end method

.method public destroy()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e(Lo91;II)I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final f()Lr6;
    .locals 0

    .line 1
    sget-object p0, Lr6;->i0:Lr6;

    .line 2
    .line 3
    return-object p0
.end method

.method public g()Lh27;
    .locals 0

    .line 1
    sget-object p0, Lax1;->a:Lh27;

    .line 2
    .line 3
    return-object p0
.end method

.method public h()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
