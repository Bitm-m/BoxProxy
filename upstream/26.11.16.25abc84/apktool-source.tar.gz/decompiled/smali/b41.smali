.class public final synthetic Lb41;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lj41;

.field public final synthetic k:Ljava/util/List;

.field public final synthetic l:Ll41;


# direct methods
.method public synthetic constructor <init>(Lj41;Ljava/util/List;Ll41;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lb41;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lb41;->j:Lj41;

    .line 4
    .line 5
    iput-object p2, p0, Lb41;->k:Ljava/util/List;

    .line 6
    .line 7
    iput-object p3, p0, Lb41;->l:Ll41;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb41;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    iget-object v5, v0, Lb41;->l:Ll41;

    .line 11
    .line 12
    iget-object v6, v0, Lb41;->k:Ljava/util/List;

    .line 13
    .line 14
    iget-object v0, v0, Lb41;->j:Lj41;

    .line 15
    .line 16
    const/4 v7, 0x0

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lla3;

    .line 23
    .line 24
    move-object/from16 v8, p2

    .line 25
    .line 26
    check-cast v8, Lla2;

    .line 27
    .line 28
    move-object/from16 v9, p3

    .line 29
    .line 30
    check-cast v9, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v9, 0x11

    .line 40
    .line 41
    if-eq v1, v3, :cond_0

    .line 42
    .line 43
    move v1, v4

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v1, v7

    .line 46
    :goto_0
    and-int/2addr v9, v4

    .line 47
    invoke-virtual {v8, v9, v1}, Lla2;->S(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_1

    .line 52
    .line 53
    invoke-static {v8}, Llc3;->t(Lla2;)Llj0;

    .line 54
    .line 55
    .line 56
    move-result-object v11

    .line 57
    new-instance v1, Lb41;

    .line 58
    .line 59
    invoke-direct {v1, v0, v6, v5, v7}, Lb41;-><init>(Lj41;Ljava/util/List;Ll41;B)V

    .line 60
    .line 61
    .line 62
    const v0, -0x388da501

    .line 63
    .line 64
    .line 65
    invoke-static {v0, v1, v8}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 66
    .line 67
    .line 68
    move-result-object v17

    .line 69
    const/16 v19, 0x0

    .line 70
    .line 71
    const/16 v20, 0x3f7

    .line 72
    .line 73
    move-object/from16 v18, v8

    .line 74
    .line 75
    const/4 v8, 0x0

    .line 76
    const/4 v9, 0x0

    .line 77
    const/4 v10, 0x0

    .line 78
    const/4 v12, 0x0

    .line 79
    const/4 v13, 0x0

    .line 80
    const/4 v14, 0x0

    .line 81
    const/4 v15, 0x0

    .line 82
    const/16 v16, 0x0

    .line 83
    .line 84
    invoke-static/range {v8 .. v20}, Lpv3;->a(Lmz3;FLbt4;Llj0;Lh35;ZLw82;Lw82;ZLyz0;Lla2;II)V

    .line 85
    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_1
    move-object/from16 v18, v8

    .line 89
    .line 90
    invoke-virtual/range {v18 .. v18}, Lla2;->V()V

    .line 91
    .line 92
    .line 93
    :goto_1
    return-object v2

    .line 94
    :pswitch_0
    move-object/from16 v1, p1

    .line 95
    .line 96
    check-cast v1, Lvx0;

    .line 97
    .line 98
    move-object/from16 v8, p2

    .line 99
    .line 100
    check-cast v8, Lla2;

    .line 101
    .line 102
    move-object/from16 v9, p3

    .line 103
    .line 104
    check-cast v9, Ljava/lang/Integer;

    .line 105
    .line 106
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 107
    .line 108
    .line 109
    move-result v9

    .line 110
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 111
    .line 112
    .line 113
    and-int/lit8 v1, v9, 0x11

    .line 114
    .line 115
    if-eq v1, v3, :cond_2

    .line 116
    .line 117
    move v1, v4

    .line 118
    goto :goto_2

    .line 119
    :cond_2
    move v1, v7

    .line 120
    :goto_2
    and-int/2addr v9, v4

    .line 121
    invoke-virtual {v8, v9, v1}, Lla2;->S(IZ)Z

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    if-eqz v1, :cond_6

    .line 126
    .line 127
    iget-object v1, v0, Lj41;->a:Ljava/lang/String;

    .line 128
    .line 129
    invoke-static {v1}, Lkm;->f0(Ljava/lang/Object;)Ljava/util/List;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    invoke-static {v1, v6}, Liv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-static {v1}, Liv0;->n1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-static {v1}, Liv0;->k1(Ljava/lang/Iterable;)Ljava/util/List;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    const v3, 0x7f0f00eb

    .line 146
    .line 147
    .line 148
    invoke-static {v3, v8}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v10

    .line 152
    const v3, 0x7f0f00ea

    .line 153
    .line 154
    .line 155
    invoke-static {v3, v8}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    invoke-static {v3}, Lkm;->d0(Ljava/lang/Object;)Ljava/util/List;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    invoke-static {v3, v1}, Liv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    iget-object v0, v0, Lj41;->a:Ljava/lang/String;

    .line 168
    .line 169
    if-eqz v0, :cond_3

    .line 170
    .line 171
    invoke-interface {v1, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    add-int/lit8 v7, v0, 0x1

    .line 176
    .line 177
    :cond_3
    move v9, v7

    .line 178
    invoke-virtual {v8, v5}, Lla2;->g(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    invoke-virtual {v8, v1}, Lla2;->i(Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    move-result v4

    .line 186
    or-int/2addr v0, v4

    .line 187
    invoke-virtual {v8}, Lla2;->N()Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v4

    .line 191
    if-nez v0, :cond_4

    .line 192
    .line 193
    sget-object v0, Ld21;->a:Lq9;

    .line 194
    .line 195
    if-ne v4, v0, :cond_5

    .line 196
    .line 197
    :cond_4
    new-instance v4, Lk2;

    .line 198
    .line 199
    const/16 v0, 0x14

    .line 200
    .line 201
    invoke-direct {v4, v5, v1, v0}, Lk2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v8, v4}, Lla2;->k0(Ljava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    :cond_5
    move-object/from16 v21, v4

    .line 208
    .line 209
    check-cast v21, Lh92;

    .line 210
    .line 211
    const/16 v24, 0x0

    .line 212
    .line 213
    const v25, 0xfff8

    .line 214
    .line 215
    .line 216
    const/4 v11, 0x0

    .line 217
    const/4 v12, 0x0

    .line 218
    const/4 v13, 0x0

    .line 219
    const/4 v14, 0x0

    .line 220
    const/4 v15, 0x0

    .line 221
    const/16 v16, 0x0

    .line 222
    .line 223
    const/16 v17, 0x0

    .line 224
    .line 225
    const/16 v18, 0x0

    .line 226
    .line 227
    const/16 v19, 0x0

    .line 228
    .line 229
    const/16 v20, 0x0

    .line 230
    .line 231
    const/16 v23, 0x0

    .line 232
    .line 233
    move-object/from16 v22, v8

    .line 234
    .line 235
    move-object v8, v3

    .line 236
    invoke-static/range {v8 .. v25}, Liw3;->d(Ljava/util/List;ILjava/lang/String;Lmz3;Lj00;Ljava/lang/String;Lj00;Ltr1;Lyz0;Lbt4;ZZZLh92;Lla2;III)V

    .line 237
    .line 238
    .line 239
    goto :goto_3

    .line 240
    :cond_6
    move-object/from16 v22, v8

    .line 241
    .line 242
    invoke-virtual/range {v22 .. v22}, Lla2;->V()V

    .line 243
    .line 244
    .line 245
    :goto_3
    return-object v2

    .line 246
    nop

    .line 247
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
