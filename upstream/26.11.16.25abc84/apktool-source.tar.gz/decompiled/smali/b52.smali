.class public final Lb52;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw04;
.implements Lto5;


# instance fields
.field public final a:Lqv;

.field public final b:Lsv;

.field public final c:F

.field public final d:Lre1;

.field public final e:F

.field public final f:Lz42;


# direct methods
.method public constructor <init>(Lqv;Lsv;FLre1;FLz42;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb52;->a:Lqv;

    .line 5
    .line 6
    iput-object p2, p0, Lb52;->b:Lsv;

    .line 7
    .line 8
    iput p3, p0, Lb52;->c:F

    .line 9
    .line 10
    iput-object p4, p0, Lb52;->d:Lre1;

    .line 11
    .line 12
    iput p5, p0, Lb52;->e:F

    .line 13
    .line 14
    iput-object p6, p0, Lb52;->f:Lz42;

    .line 15
    .line 16
    return-void
.end method

.method public static k(Ljava/util/List;IIILz42;)I
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-static {v2, v2}, Lcz2;->a(II)J

    .line 7
    .line 8
    .line 9
    move-result-wide v3

    .line 10
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v5

    .line 14
    if-nez v5, :cond_b

    .line 15
    .line 16
    const v5, 0x7fffffff

    .line 17
    .line 18
    .line 19
    invoke-static {v2, v1, v2, v5}, Lw71;->a(IIII)J

    .line 20
    .line 21
    .line 22
    move-result-wide v8

    .line 23
    new-instance v10, Lw42;

    .line 24
    .line 25
    move/from16 v11, p3

    .line 26
    .line 27
    move-object/from16 v7, p4

    .line 28
    .line 29
    move-object v6, v10

    .line 30
    move/from16 v10, p2

    .line 31
    .line 32
    invoke-direct/range {v6 .. v11}, Lw42;-><init>(Lz42;JII)V

    .line 33
    .line 34
    .line 35
    move-object v10, v6

    .line 36
    invoke-static {v2, v0}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    check-cast v6, Liq3;

    .line 41
    .line 42
    if-eqz v6, :cond_0

    .line 43
    .line 44
    invoke-interface {v6, v1}, Liq3;->h0(I)I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    invoke-interface {v6, v7}, Liq3;->S(I)I

    .line 49
    .line 50
    .line 51
    move-result v8

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move v7, v2

    .line 54
    move v8, v7

    .line 55
    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 56
    .line 57
    .line 58
    move-result v9

    .line 59
    const/4 v11, 0x1

    .line 60
    if-le v9, v11, :cond_1

    .line 61
    .line 62
    move v9, v11

    .line 63
    goto :goto_1

    .line 64
    :cond_1
    move v9, v11

    .line 65
    move v11, v2

    .line 66
    :goto_1
    invoke-static {v1, v5}, Lcz2;->a(II)J

    .line 67
    .line 68
    .line 69
    move-result-wide v13

    .line 70
    const/16 v21, 0x0

    .line 71
    .line 72
    move-wide/from16 v22, v3

    .line 73
    .line 74
    if-nez v6, :cond_2

    .line 75
    .line 76
    move-object/from16 v15, v21

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_2
    invoke-static {v8, v7}, Lcz2;->a(II)J

    .line 80
    .line 81
    .line 82
    move-result-wide v2

    .line 83
    new-instance v4, Lcz2;

    .line 84
    .line 85
    invoke-direct {v4, v2, v3}, Lcz2;-><init>(J)V

    .line 86
    .line 87
    .line 88
    move-object v15, v4

    .line 89
    :goto_2
    const/16 v19, 0x0

    .line 90
    .line 91
    const/16 v20, 0x0

    .line 92
    .line 93
    const/4 v12, 0x0

    .line 94
    const/16 v16, 0x0

    .line 95
    .line 96
    const/16 v17, 0x0

    .line 97
    .line 98
    const/16 v18, 0x0

    .line 99
    .line 100
    invoke-virtual/range {v10 .. v20}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    iget-boolean v2, v2, Lv42;->c:Z

    .line 105
    .line 106
    if-eqz v2, :cond_3

    .line 107
    .line 108
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    move-wide/from16 v3, v22

    .line 112
    .line 113
    goto/16 :goto_b

    .line 114
    .line 115
    :cond_3
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    move v11, v1

    .line 120
    move/from16 v13, v16

    .line 121
    .line 122
    move/from16 v3, v18

    .line 123
    .line 124
    const/4 v4, 0x0

    .line 125
    const/4 v12, 0x0

    .line 126
    const/16 v22, 0x0

    .line 127
    .line 128
    :goto_3
    if-ge v4, v2, :cond_a

    .line 129
    .line 130
    sub-int v8, v11, v8

    .line 131
    .line 132
    add-int/lit8 v11, v4, 0x1

    .line 133
    .line 134
    invoke-static {v3, v7}, Ljava/lang/Math;->max(II)I

    .line 135
    .line 136
    .line 137
    move-result v18

    .line 138
    invoke-static {v11, v0}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v3

    .line 142
    check-cast v3, Liq3;

    .line 143
    .line 144
    if-eqz v3, :cond_4

    .line 145
    .line 146
    invoke-interface {v3, v1}, Liq3;->h0(I)I

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    invoke-interface {v3, v7}, Liq3;->S(I)I

    .line 151
    .line 152
    .line 153
    move-result v12

    .line 154
    add-int v12, v12, p2

    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_4
    const/4 v7, 0x0

    .line 158
    const/4 v12, 0x0

    .line 159
    :goto_4
    add-int/lit8 v4, v4, 0x2

    .line 160
    .line 161
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 162
    .line 163
    .line 164
    move-result v14

    .line 165
    if-ge v4, v14, :cond_5

    .line 166
    .line 167
    move v4, v11

    .line 168
    move v11, v9

    .line 169
    goto :goto_5

    .line 170
    :cond_5
    move v4, v11

    .line 171
    const/4 v11, 0x0

    .line 172
    :goto_5
    sub-int v16, v4, v22

    .line 173
    .line 174
    move/from16 v15, v16

    .line 175
    .line 176
    move/from16 v16, v13

    .line 177
    .line 178
    invoke-static {v8, v5}, Lcz2;->a(II)J

    .line 179
    .line 180
    .line 181
    move-result-wide v13

    .line 182
    if-nez v3, :cond_6

    .line 183
    .line 184
    move-object/from16 v9, v21

    .line 185
    .line 186
    goto :goto_6

    .line 187
    :cond_6
    invoke-static {v12, v7}, Lcz2;->a(II)J

    .line 188
    .line 189
    .line 190
    move-result-wide v5

    .line 191
    new-instance v9, Lcz2;

    .line 192
    .line 193
    invoke-direct {v9, v5, v6}, Lcz2;-><init>(J)V

    .line 194
    .line 195
    .line 196
    :goto_6
    const/16 v19, 0x0

    .line 197
    .line 198
    const/16 v20, 0x0

    .line 199
    .line 200
    move v6, v12

    .line 201
    move v12, v15

    .line 202
    move-object v15, v9

    .line 203
    invoke-virtual/range {v10 .. v20}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 204
    .line 205
    .line 206
    move-result-object v11

    .line 207
    iget-boolean v5, v11, Lv42;->b:Z

    .line 208
    .line 209
    if-eqz v5, :cond_9

    .line 210
    .line 211
    add-int v18, v18, p3

    .line 212
    .line 213
    add-int v14, v18, v17

    .line 214
    .line 215
    move/from16 v13, v16

    .line 216
    .line 217
    move/from16 v16, v12

    .line 218
    .line 219
    if-eqz v3, :cond_7

    .line 220
    .line 221
    const/4 v12, 0x1

    .line 222
    :goto_7
    move v15, v8

    .line 223
    goto :goto_8

    .line 224
    :cond_7
    const/4 v12, 0x0

    .line 225
    goto :goto_7

    .line 226
    :goto_8
    invoke-virtual/range {v10 .. v16}, Lw42;->a(Lv42;ZIIII)Loq;

    .line 227
    .line 228
    .line 229
    move/from16 v16, v13

    .line 230
    .line 231
    sub-int v12, v6, p2

    .line 232
    .line 233
    add-int/lit8 v13, v16, 0x1

    .line 234
    .line 235
    iget-boolean v3, v11, Lv42;->c:Z

    .line 236
    .line 237
    if-eqz v3, :cond_8

    .line 238
    .line 239
    move v12, v4

    .line 240
    move/from16 v17, v14

    .line 241
    .line 242
    goto :goto_a

    .line 243
    :cond_8
    move v11, v1

    .line 244
    move/from16 v22, v4

    .line 245
    .line 246
    move v8, v12

    .line 247
    move/from16 v17, v14

    .line 248
    .line 249
    const/4 v3, 0x0

    .line 250
    goto :goto_9

    .line 251
    :cond_9
    move v15, v8

    .line 252
    move v8, v6

    .line 253
    move v11, v15

    .line 254
    move/from16 v13, v16

    .line 255
    .line 256
    move/from16 v3, v18

    .line 257
    .line 258
    :goto_9
    move v12, v4

    .line 259
    const v5, 0x7fffffff

    .line 260
    .line 261
    .line 262
    const/4 v9, 0x1

    .line 263
    goto/16 :goto_3

    .line 264
    .line 265
    :cond_a
    :goto_a
    sub-int v0, v17, p3

    .line 266
    .line 267
    invoke-static {v0, v12}, Lcz2;->a(II)J

    .line 268
    .line 269
    .line 270
    move-result-wide v3

    .line 271
    :cond_b
    :goto_b
    const/16 v0, 0x20

    .line 272
    .line 273
    shr-long/2addr v3, v0

    .line 274
    long-to-int v0, v3

    .line 275
    return v0
.end method


# virtual methods
.method public final a(Lx03;Ljava/util/List;I)I
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Liq3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Liq3;

    .line 33
    .line 34
    :cond_1
    const/16 v2, 0xd

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-static {v3, p3, v3, v3, v2}, Lw71;->b(IIIII)J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    iget-object v4, p0, Lb52;->f:Lz42;

    .line 42
    .line 43
    invoke-virtual {v4, v0, v1, v2, v3}, Lz42;->a(Liq3;Liq3;J)V

    .line 44
    .line 45
    .line 46
    invoke-static {p2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    check-cast p2, Ljava/util/List;

    .line 51
    .line 52
    if-nez p2, :cond_2

    .line 53
    .line 54
    sget-object p2, Lbx1;->i:Lbx1;

    .line 55
    .line 56
    :cond_2
    iget v0, p0, Lb52;->c:F

    .line 57
    .line 58
    invoke-interface {p1, v0}, Llk1;->s0(F)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iget p0, p0, Lb52;->e:F

    .line 63
    .line 64
    invoke-interface {p1, p0}, Llk1;->s0(F)I

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    invoke-static {p2, p3, v0, p0, v4}, Lb52;->k(Ljava/util/List;IIILz42;)I

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    return p0
.end method

.method public final b(Lx03;Ljava/util/List;I)I
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Liq3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Liq3;

    .line 33
    .line 34
    :cond_1
    const/4 v2, 0x7

    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {v3, v3, v3, p3, v2}, Lw71;->b(IIIII)J

    .line 37
    .line 38
    .line 39
    move-result-wide v4

    .line 40
    iget-object v2, p0, Lb52;->f:Lz42;

    .line 41
    .line 42
    invoke-virtual {v2, v0, v1, v4, v5}, Lz42;->a(Liq3;Liq3;J)V

    .line 43
    .line 44
    .line 45
    invoke-static {p2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    check-cast p2, Ljava/util/List;

    .line 50
    .line 51
    if-nez p2, :cond_2

    .line 52
    .line 53
    sget-object p2, Lbx1;->i:Lbx1;

    .line 54
    .line 55
    :cond_2
    iget p0, p0, Lb52;->c:F

    .line 56
    .line 57
    invoke-interface {p1, p0}, Llk1;->s0(F)I

    .line 58
    .line 59
    .line 60
    move-result p0

    .line 61
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    move v0, v3

    .line 66
    move v1, v0

    .line 67
    move v2, v1

    .line 68
    move v4, v2

    .line 69
    :goto_1
    if-ge v0, p1, :cond_4

    .line 70
    .line 71
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    check-cast v5, Liq3;

    .line 76
    .line 77
    invoke-interface {v5, p3}, Liq3;->g0(I)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    add-int/2addr v5, p0

    .line 82
    add-int/lit8 v6, v0, 0x1

    .line 83
    .line 84
    sub-int v7, v6, v2

    .line 85
    .line 86
    const v8, 0x7fffffff

    .line 87
    .line 88
    .line 89
    if-eq v7, v8, :cond_3

    .line 90
    .line 91
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 92
    .line 93
    .line 94
    move-result v7

    .line 95
    if-eq v6, v7, :cond_3

    .line 96
    .line 97
    add-int/2addr v4, v5

    .line 98
    goto :goto_2

    .line 99
    :cond_3
    add-int/2addr v4, v5

    .line 100
    sub-int/2addr v4, p0

    .line 101
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    move v2, v0

    .line 106
    move v4, v3

    .line 107
    :goto_2
    move v0, v6

    .line 108
    goto :goto_1

    .line 109
    :cond_4
    return v1
.end method

.method public final c(Lpq3;Ljava/util/List;J)Loq3;
    .locals 56

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v6, p1

    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    move-wide/from16 v2, p3

    .line 8
    .line 9
    move-object v4, v1

    .line 10
    check-cast v4, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    sget-object v13, Lcx1;->i:Lcx1;

    .line 17
    .line 18
    const/4 v14, 0x0

    .line 19
    if-nez v4, :cond_0

    .line 20
    .line 21
    invoke-static {v2, v3}, Lv71;->h(J)I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    iget-object v5, v0, Lb52;->f:Lz42;

    .line 26
    .line 27
    if-nez v4, :cond_1

    .line 28
    .line 29
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    :cond_0
    move-object v1, v13

    .line 33
    goto/16 :goto_1d

    .line 34
    .line 35
    :cond_1
    invoke-static {v1}, Liv0;->L0(Ljava/util/List;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    check-cast v4, Ljava/util/List;

    .line 40
    .line 41
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    if-eqz v7, :cond_2

    .line 46
    .line 47
    new-instance v0, Lag1;

    .line 48
    .line 49
    const/16 v1, 0x16

    .line 50
    .line 51
    invoke-direct {v0, v1}, Lag1;-><init>(B)V

    .line 52
    .line 53
    .line 54
    invoke-interface {v6, v14, v14, v13, v0}, Lpq3;->P0(IILjava/util/Map;Lh92;)Loq3;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0

    .line 59
    :cond_2
    const/4 v15, 0x1

    .line 60
    invoke-static {v15, v1}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    check-cast v7, Ljava/util/List;

    .line 65
    .line 66
    if-eqz v7, :cond_3

    .line 67
    .line 68
    invoke-static {v7}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    check-cast v7, Liq3;

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    const/4 v7, 0x0

    .line 76
    :goto_0
    const/4 v9, 0x2

    .line 77
    invoke-static {v9, v1}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    check-cast v1, Ljava/util/List;

    .line 82
    .line 83
    if-eqz v1, :cond_4

    .line 84
    .line 85
    invoke-static {v1}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    check-cast v1, Liq3;

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_4
    const/4 v1, 0x0

    .line 93
    :goto_1
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    sget-object v5, Lf93;->i:Lf93;

    .line 100
    .line 101
    invoke-static {v2, v3, v5}, Lba3;->y(JLf93;)J

    .line 102
    .line 103
    .line 104
    move-result-wide v10

    .line 105
    const/16 v12, 0xa

    .line 106
    .line 107
    invoke-static {v12, v10, v11}, Lba3;->B(IJ)J

    .line 108
    .line 109
    .line 110
    move-result-wide v10

    .line 111
    invoke-static {v10, v11}, Lba3;->V(J)J

    .line 112
    .line 113
    .line 114
    move-result-wide v10

    .line 115
    const v12, 0x7fffffff

    .line 116
    .line 117
    .line 118
    const/16 v16, 0x0

    .line 119
    .line 120
    if-eqz v7, :cond_6

    .line 121
    .line 122
    invoke-static {v7}, Llc3;->E(Liq3;)Luo5;

    .line 123
    .line 124
    .line 125
    move-result-object v17

    .line 126
    invoke-static/range {v17 .. v17}, Llc3;->G(Luo5;)F

    .line 127
    .line 128
    .line 129
    move-result v17

    .line 130
    cmpg-float v17, v17, v16

    .line 131
    .line 132
    if-nez v17, :cond_5

    .line 133
    .line 134
    invoke-static {v7}, Llc3;->E(Liq3;)Luo5;

    .line 135
    .line 136
    .line 137
    invoke-interface {v7, v10, v11}, Liq3;->e(J)Lez4;

    .line 138
    .line 139
    .line 140
    move-result-object v7

    .line 141
    invoke-virtual {v7}, Lez4;->p0()I

    .line 142
    .line 143
    .line 144
    invoke-virtual {v7}, Lez4;->l0()I

    .line 145
    .line 146
    .line 147
    invoke-virtual {v7}, Lez4;->p0()I

    .line 148
    .line 149
    .line 150
    invoke-virtual {v7}, Lez4;->l0()I

    .line 151
    .line 152
    .line 153
    goto :goto_2

    .line 154
    :cond_5
    move/from16 v17, v9

    .line 155
    .line 156
    invoke-interface {v7, v12}, Liq3;->S(I)I

    .line 157
    .line 158
    .line 159
    move-result v9

    .line 160
    invoke-interface {v7, v9}, Liq3;->h0(I)I

    .line 161
    .line 162
    .line 163
    goto :goto_3

    .line 164
    :cond_6
    :goto_2
    move/from16 v17, v9

    .line 165
    .line 166
    :goto_3
    if-eqz v1, :cond_8

    .line 167
    .line 168
    invoke-static {v1}, Llc3;->E(Liq3;)Luo5;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    invoke-static {v7}, Llc3;->G(Luo5;)F

    .line 173
    .line 174
    .line 175
    move-result v7

    .line 176
    cmpg-float v7, v7, v16

    .line 177
    .line 178
    if-nez v7, :cond_7

    .line 179
    .line 180
    invoke-static {v1}, Llc3;->E(Liq3;)Luo5;

    .line 181
    .line 182
    .line 183
    invoke-interface {v1, v10, v11}, Liq3;->e(J)Lez4;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    invoke-virtual {v1}, Lez4;->p0()I

    .line 188
    .line 189
    .line 190
    invoke-virtual {v1}, Lez4;->l0()I

    .line 191
    .line 192
    .line 193
    invoke-virtual {v1}, Lez4;->p0()I

    .line 194
    .line 195
    .line 196
    invoke-virtual {v1}, Lez4;->l0()I

    .line 197
    .line 198
    .line 199
    goto :goto_4

    .line 200
    :cond_7
    invoke-interface {v1, v12}, Liq3;->S(I)I

    .line 201
    .line 202
    .line 203
    move-result v7

    .line 204
    invoke-interface {v1, v7}, Liq3;->h0(I)I

    .line 205
    .line 206
    .line 207
    :cond_8
    :goto_4
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    invoke-static {v2, v3, v5}, Lba3;->y(JLf93;)J

    .line 212
    .line 213
    .line 214
    move-result-wide v20

    .line 215
    new-instance v2, Ld34;

    .line 216
    .line 217
    const/16 v3, 0x10

    .line 218
    .line 219
    new-array v4, v3, [Loq3;

    .line 220
    .line 221
    invoke-direct {v2, v14, v4}, Ld34;-><init>(I[Ljava/lang/Object;)V

    .line 222
    .line 223
    .line 224
    invoke-static/range {v20 .. v21}, Lv71;->i(J)I

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    invoke-static/range {v20 .. v21}, Lv71;->k(J)I

    .line 229
    .line 230
    .line 231
    move-result v5

    .line 232
    invoke-static/range {v20 .. v21}, Lv71;->h(J)I

    .line 233
    .line 234
    .line 235
    move-result v7

    .line 236
    sget-object v9, Lhz2;->a:Lz14;

    .line 237
    .line 238
    new-instance v9, Lz14;

    .line 239
    .line 240
    invoke-direct {v9}, Lz14;-><init>()V

    .line 241
    .line 242
    .line 243
    new-instance v10, Ljava/util/ArrayList;

    .line 244
    .line 245
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 246
    .line 247
    .line 248
    iget v11, v0, Lb52;->c:F

    .line 249
    .line 250
    invoke-interface {v6, v11}, Llk1;->J(F)F

    .line 251
    .line 252
    .line 253
    move-result v11

    .line 254
    move-object/from16 p2, v9

    .line 255
    .line 256
    float-to-double v8, v11

    .line 257
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 258
    .line 259
    .line 260
    move-result-wide v8

    .line 261
    double-to-float v8, v8

    .line 262
    float-to-int v8, v8

    .line 263
    iget v9, v0, Lb52;->e:F

    .line 264
    .line 265
    invoke-interface {v6, v9}, Llk1;->J(F)F

    .line 266
    .line 267
    .line 268
    move-result v9

    .line 269
    move-object/from16 v30, v13

    .line 270
    .line 271
    float-to-double v12, v9

    .line 272
    invoke-static {v12, v13}, Ljava/lang/Math;->ceil(D)D

    .line 273
    .line 274
    .line 275
    move-result-wide v12

    .line 276
    double-to-float v9, v12

    .line 277
    float-to-int v9, v9

    .line 278
    invoke-static {v14, v4, v14, v7}, Lw71;->a(IIII)J

    .line 279
    .line 280
    .line 281
    move-result-wide v12

    .line 282
    const/16 v11, 0xe

    .line 283
    .line 284
    invoke-static {v11, v12, v13}, Lba3;->B(IJ)J

    .line 285
    .line 286
    .line 287
    move-result-wide v18

    .line 288
    move/from16 v32, v15

    .line 289
    .line 290
    invoke-static/range {v18 .. v19}, Lba3;->V(J)J

    .line 291
    .line 292
    .line 293
    move-result-wide v14

    .line 294
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 295
    .line 296
    .line 297
    move-result v11

    .line 298
    if-eqz v11, :cond_9

    .line 299
    .line 300
    :try_start_0
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v11

    .line 304
    check-cast v11, Liq3;
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    .line 305
    .line 306
    goto :goto_5

    .line 307
    :catch_0
    :cond_9
    const/4 v11, 0x0

    .line 308
    :goto_5
    if-eqz v11, :cond_b

    .line 309
    .line 310
    invoke-static {v11}, Llc3;->E(Liq3;)Luo5;

    .line 311
    .line 312
    .line 313
    move-result-object v18

    .line 314
    invoke-static/range {v18 .. v18}, Llc3;->G(Luo5;)F

    .line 315
    .line 316
    .line 317
    move-result v18

    .line 318
    cmpg-float v18, v18, v16

    .line 319
    .line 320
    if-nez v18, :cond_a

    .line 321
    .line 322
    invoke-static {v11}, Llc3;->E(Liq3;)Luo5;

    .line 323
    .line 324
    .line 325
    invoke-interface {v11, v14, v15}, Liq3;->e(J)Lez4;

    .line 326
    .line 327
    .line 328
    move-result-object v18

    .line 329
    invoke-virtual/range {v18 .. v18}, Lez4;->p0()I

    .line 330
    .line 331
    .line 332
    move-result v3

    .line 333
    move-object/from16 v33, v1

    .line 334
    .line 335
    invoke-virtual/range {v18 .. v18}, Lez4;->l0()I

    .line 336
    .line 337
    .line 338
    move-result v1

    .line 339
    invoke-static {v3, v1}, Lcz2;->a(II)J

    .line 340
    .line 341
    .line 342
    move-result-wide v22

    .line 343
    :goto_6
    move-object/from16 v34, v2

    .line 344
    .line 345
    move-wide/from16 v1, v22

    .line 346
    .line 347
    goto :goto_7

    .line 348
    :cond_a
    move-object/from16 v33, v1

    .line 349
    .line 350
    const v1, 0x7fffffff

    .line 351
    .line 352
    .line 353
    invoke-interface {v11, v1}, Liq3;->S(I)I

    .line 354
    .line 355
    .line 356
    move-result v3

    .line 357
    move-object v1, v11

    .line 358
    invoke-interface {v1, v3}, Liq3;->h0(I)I

    .line 359
    .line 360
    .line 361
    move-result v11

    .line 362
    invoke-static {v3, v11}, Lcz2;->a(II)J

    .line 363
    .line 364
    .line 365
    move-result-wide v22

    .line 366
    move-object v11, v1

    .line 367
    const/16 v18, 0x0

    .line 368
    .line 369
    goto :goto_6

    .line 370
    :goto_7
    new-instance v3, Lcz2;

    .line 371
    .line 372
    invoke-direct {v3, v1, v2}, Lcz2;-><init>(J)V

    .line 373
    .line 374
    .line 375
    move-object/from16 v1, v18

    .line 376
    .line 377
    goto :goto_8

    .line 378
    :cond_b
    move-object/from16 v33, v1

    .line 379
    .line 380
    move-object/from16 v34, v2

    .line 381
    .line 382
    const/4 v1, 0x0

    .line 383
    const/4 v3, 0x0

    .line 384
    :goto_8
    const-wide v46, 0xffffffffL

    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    move-object/from16 v48, v1

    .line 390
    .line 391
    const/16 v49, 0x20

    .line 392
    .line 393
    if-eqz v3, :cond_c

    .line 394
    .line 395
    iget-wide v1, v3, Lcz2;->a:J

    .line 396
    .line 397
    move-wide/from16 v18, v1

    .line 398
    .line 399
    shr-long v1, v18, v49

    .line 400
    .line 401
    long-to-int v1, v1

    .line 402
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 403
    .line 404
    .line 405
    move-result-object v1

    .line 406
    move-object/from16 v22, v1

    .line 407
    .line 408
    and-long v1, v18, v46

    .line 409
    .line 410
    long-to-int v1, v1

    .line 411
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 412
    .line 413
    .line 414
    move-result-object v1

    .line 415
    move-object/from16 p4, v1

    .line 416
    .line 417
    move-object/from16 v50, v22

    .line 418
    .line 419
    :goto_9
    const/16 v1, 0x10

    .line 420
    .line 421
    goto :goto_a

    .line 422
    :cond_c
    const/16 p4, 0x0

    .line 423
    .line 424
    const/16 v50, 0x0

    .line 425
    .line 426
    goto :goto_9

    .line 427
    :goto_a
    new-array v2, v1, [I

    .line 428
    .line 429
    new-array v1, v1, [I

    .line 430
    .line 431
    move-wide/from16 v51, v12

    .line 432
    .line 433
    new-instance v13, La24;

    .line 434
    .line 435
    const/4 v12, 0x0

    .line 436
    invoke-direct {v13, v12}, La24;-><init>(Ljava/lang/Object;)V

    .line 437
    .line 438
    .line 439
    new-instance v35, Lw42;

    .line 440
    .line 441
    iget-object v12, v0, Lb52;->f:Lz42;

    .line 442
    .line 443
    move/from16 v22, v8

    .line 444
    .line 445
    move/from16 v23, v9

    .line 446
    .line 447
    move-object/from16 v19, v12

    .line 448
    .line 449
    move-object/from16 v18, v35

    .line 450
    .line 451
    invoke-direct/range {v18 .. v23}, Lw42;-><init>(Lz42;JII)V

    .line 452
    .line 453
    .line 454
    move v8, v5

    .line 455
    move/from16 v5, v22

    .line 456
    .line 457
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 458
    .line 459
    .line 460
    move-result v36

    .line 461
    invoke-static {v4, v7}, Lcz2;->a(II)J

    .line 462
    .line 463
    .line 464
    move-result-wide v38

    .line 465
    const/16 v44, 0x0

    .line 466
    .line 467
    const/16 v45, 0x0

    .line 468
    .line 469
    const/16 v37, 0x0

    .line 470
    .line 471
    const/16 v41, 0x0

    .line 472
    .line 473
    const/16 v42, 0x0

    .line 474
    .line 475
    const/16 v43, 0x0

    .line 476
    .line 477
    move-object/from16 v40, v3

    .line 478
    .line 479
    invoke-virtual/range {v35 .. v45}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 480
    .line 481
    .line 482
    move-result-object v3

    .line 483
    iget-boolean v12, v3, Lv42;->c:Z

    .line 484
    .line 485
    if-eqz v12, :cond_e

    .line 486
    .line 487
    if-eqz v40, :cond_d

    .line 488
    .line 489
    move/from16 v24, v32

    .line 490
    .line 491
    goto :goto_b

    .line 492
    :cond_d
    const/16 v24, 0x0

    .line 493
    .line 494
    :goto_b
    const/16 v26, 0x0

    .line 495
    .line 496
    const/16 v28, 0x0

    .line 497
    .line 498
    const/16 v25, -0x1

    .line 499
    .line 500
    move-object/from16 v23, v3

    .line 501
    .line 502
    move/from16 v27, v4

    .line 503
    .line 504
    move-object/from16 v22, v35

    .line 505
    .line 506
    invoke-virtual/range {v22 .. v28}, Lw42;->a(Lv42;ZIIII)Loq;

    .line 507
    .line 508
    .line 509
    goto :goto_c

    .line 510
    :cond_e
    move-object/from16 v23, v3

    .line 511
    .line 512
    :goto_c
    move-object v3, v1

    .line 513
    move/from16 v53, v7

    .line 514
    .line 515
    move v0, v8

    .line 516
    move/from16 v54, v9

    .line 517
    .line 518
    move-object v1, v11

    .line 519
    move-object/from16 v11, v23

    .line 520
    .line 521
    const/4 v6, 0x0

    .line 522
    const/4 v9, 0x0

    .line 523
    const/4 v12, 0x0

    .line 524
    const/16 v18, 0x0

    .line 525
    .line 526
    const/16 v22, 0x0

    .line 527
    .line 528
    const/16 v41, 0x0

    .line 529
    .line 530
    const/16 v42, 0x0

    .line 531
    .line 532
    move-object v8, v2

    .line 533
    move/from16 v23, v4

    .line 534
    .line 535
    move-object/from16 v2, v48

    .line 536
    .line 537
    move/from16 v48, v5

    .line 538
    .line 539
    const/4 v5, 0x0

    .line 540
    :goto_d
    iget-boolean v11, v11, Lv42;->c:Z

    .line 541
    .line 542
    if-nez v11, :cond_19

    .line 543
    .line 544
    if-eqz v1, :cond_19

    .line 545
    .line 546
    invoke-virtual/range {v50 .. v50}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 547
    .line 548
    .line 549
    invoke-virtual/range {v50 .. v50}, Ljava/lang/Integer;->intValue()I

    .line 550
    .line 551
    .line 552
    move-result v11

    .line 553
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 554
    .line 555
    .line 556
    move/from16 v24, v11

    .line 557
    .line 558
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Integer;->intValue()I

    .line 559
    .line 560
    .line 561
    move-result v11

    .line 562
    move-object/from16 p4, v13

    .line 563
    .line 564
    add-int v13, v18, v24

    .line 565
    .line 566
    invoke-static {v5, v11}, Ljava/lang/Math;->max(II)I

    .line 567
    .line 568
    .line 569
    move-result v43

    .line 570
    sub-int v5, v23, v24

    .line 571
    .line 572
    add-int/lit8 v18, v6, 0x1

    .line 573
    .line 574
    invoke-virtual/range {v19 .. v19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 575
    .line 576
    .line 577
    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 578
    .line 579
    .line 580
    move-object/from16 v11, p2

    .line 581
    .line 582
    invoke-virtual {v11, v6, v2}, Lz14;->i(ILjava/lang/Object;)V

    .line 583
    .line 584
    .line 585
    invoke-interface {v1}, Liq3;->j()Ljava/lang/Object;

    .line 586
    .line 587
    .line 588
    sub-int v28, v18, v22

    .line 589
    .line 590
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 591
    .line 592
    .line 593
    move-result v1

    .line 594
    if-eqz v1, :cond_f

    .line 595
    .line 596
    :try_start_1
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 597
    .line 598
    .line 599
    move-result-object v1

    .line 600
    check-cast v1, Liq3;
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_1

    .line 601
    .line 602
    goto :goto_e

    .line 603
    :catch_1
    :cond_f
    const/4 v1, 0x0

    .line 604
    :goto_e
    if-eqz v1, :cond_11

    .line 605
    .line 606
    invoke-static {v1}, Llc3;->E(Liq3;)Luo5;

    .line 607
    .line 608
    .line 609
    move-result-object v2

    .line 610
    invoke-static {v2}, Llc3;->G(Luo5;)F

    .line 611
    .line 612
    .line 613
    move-result v2

    .line 614
    cmpg-float v2, v2, v16

    .line 615
    .line 616
    if-nez v2, :cond_10

    .line 617
    .line 618
    invoke-static {v1}, Llc3;->E(Liq3;)Luo5;

    .line 619
    .line 620
    .line 621
    invoke-interface {v1, v14, v15}, Liq3;->e(J)Lez4;

    .line 622
    .line 623
    .line 624
    move-result-object v2

    .line 625
    invoke-virtual {v2}, Lez4;->p0()I

    .line 626
    .line 627
    .line 628
    move-result v6

    .line 629
    move-object/from16 p2, v2

    .line 630
    .line 631
    invoke-virtual/range {p2 .. p2}, Lez4;->l0()I

    .line 632
    .line 633
    .line 634
    move-result v2

    .line 635
    invoke-static {v6, v2}, Lcz2;->a(II)J

    .line 636
    .line 637
    .line 638
    move-result-wide v23

    .line 639
    move-object/from16 v6, p2

    .line 640
    .line 641
    move-object v2, v11

    .line 642
    :goto_f
    move-object/from16 v50, v1

    .line 643
    .line 644
    move-object/from16 p2, v10

    .line 645
    .line 646
    move-wide/from16 v10, v23

    .line 647
    .line 648
    goto :goto_10

    .line 649
    :cond_10
    const v2, 0x7fffffff

    .line 650
    .line 651
    .line 652
    invoke-interface {v1, v2}, Liq3;->S(I)I

    .line 653
    .line 654
    .line 655
    move-result v6

    .line 656
    move-object v2, v11

    .line 657
    invoke-interface {v1, v6}, Liq3;->h0(I)I

    .line 658
    .line 659
    .line 660
    move-result v11

    .line 661
    invoke-static {v6, v11}, Lcz2;->a(II)J

    .line 662
    .line 663
    .line 664
    move-result-wide v23

    .line 665
    const/4 v6, 0x0

    .line 666
    goto :goto_f

    .line 667
    :goto_10
    new-instance v1, Lcz2;

    .line 668
    .line 669
    invoke-direct {v1, v10, v11}, Lcz2;-><init>(J)V

    .line 670
    .line 671
    .line 672
    goto :goto_11

    .line 673
    :cond_11
    move-object/from16 v50, v1

    .line 674
    .line 675
    move-object/from16 p2, v10

    .line 676
    .line 677
    move-object v2, v11

    .line 678
    const/4 v1, 0x0

    .line 679
    const/4 v6, 0x0

    .line 680
    :goto_11
    if-eqz v1, :cond_12

    .line 681
    .line 682
    iget-wide v10, v1, Lcz2;->a:J

    .line 683
    .line 684
    move-wide/from16 v23, v10

    .line 685
    .line 686
    shr-long v10, v23, v49

    .line 687
    .line 688
    long-to-int v10, v10

    .line 689
    add-int v10, v10, v48

    .line 690
    .line 691
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 692
    .line 693
    .line 694
    move-result-object v10

    .line 695
    move-object/from16 v25, v10

    .line 696
    .line 697
    and-long v10, v23, v46

    .line 698
    .line 699
    long-to-int v10, v10

    .line 700
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 701
    .line 702
    .line 703
    move-result-object v10

    .line 704
    move-object/from16 v11, v25

    .line 705
    .line 706
    goto :goto_12

    .line 707
    :cond_12
    const/4 v10, 0x0

    .line 708
    const/4 v11, 0x0

    .line 709
    :goto_12
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 710
    .line 711
    .line 712
    move-result v36

    .line 713
    invoke-static {v5, v7}, Lcz2;->a(II)J

    .line 714
    .line 715
    .line 716
    move-result-wide v38

    .line 717
    if-nez v1, :cond_13

    .line 718
    .line 719
    move-object/from16 v23, v1

    .line 720
    .line 721
    move/from16 v27, v5

    .line 722
    .line 723
    move-object/from16 v55, v6

    .line 724
    .line 725
    const/16 v40, 0x0

    .line 726
    .line 727
    goto :goto_13

    .line 728
    :cond_13
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 729
    .line 730
    .line 731
    move-object/from16 v23, v1

    .line 732
    .line 733
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 734
    .line 735
    .line 736
    move-result v1

    .line 737
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 738
    .line 739
    .line 740
    move/from16 v27, v5

    .line 741
    .line 742
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 743
    .line 744
    .line 745
    move-result v5

    .line 746
    move-object/from16 v55, v6

    .line 747
    .line 748
    invoke-static {v1, v5}, Lcz2;->a(II)J

    .line 749
    .line 750
    .line 751
    move-result-wide v5

    .line 752
    new-instance v1, Lcz2;

    .line 753
    .line 754
    invoke-direct {v1, v5, v6}, Lcz2;-><init>(J)V

    .line 755
    .line 756
    .line 757
    move-object/from16 v40, v1

    .line 758
    .line 759
    :goto_13
    const/16 v44, 0x0

    .line 760
    .line 761
    const/16 v45, 0x0

    .line 762
    .line 763
    move/from16 v37, v28

    .line 764
    .line 765
    invoke-virtual/range {v35 .. v45}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 766
    .line 767
    .line 768
    move-result-object v1

    .line 769
    iget-boolean v5, v1, Lv42;->b:Z

    .line 770
    .line 771
    if-eqz v5, :cond_18

    .line 772
    .line 773
    invoke-static {v0, v13}, Ljava/lang/Math;->max(II)I

    .line 774
    .line 775
    .line 776
    move-result v0

    .line 777
    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    .line 778
    .line 779
    .line 780
    move-result v0

    .line 781
    add-int v26, v42, v43

    .line 782
    .line 783
    if-eqz v23, :cond_14

    .line 784
    .line 785
    move/from16 v24, v32

    .line 786
    .line 787
    :goto_14
    move-object/from16 v23, v1

    .line 788
    .line 789
    move-object/from16 v22, v35

    .line 790
    .line 791
    move/from16 v25, v41

    .line 792
    .line 793
    goto :goto_15

    .line 794
    :cond_14
    const/16 v24, 0x0

    .line 795
    .line 796
    goto :goto_14

    .line 797
    :goto_15
    invoke-virtual/range {v22 .. v28}, Lw42;->a(Lv42;ZIIII)Loq;

    .line 798
    .line 799
    .line 800
    move-object/from16 v35, v22

    .line 801
    .line 802
    move/from16 v41, v25

    .line 803
    .line 804
    add-int/lit8 v1, v12, 0x1

    .line 805
    .line 806
    array-length v5, v3

    .line 807
    if-ge v5, v1, :cond_15

    .line 808
    .line 809
    array-length v5, v3

    .line 810
    mul-int/lit8 v5, v5, 0x3

    .line 811
    .line 812
    div-int/lit8 v5, v5, 0x2

    .line 813
    .line 814
    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    .line 815
    .line 816
    .line 817
    move-result v1

    .line 818
    invoke-static {v3, v1}, Ljava/util/Arrays;->copyOf([II)[I

    .line 819
    .line 820
    .line 821
    move-result-object v3

    .line 822
    :cond_15
    aput v43, v3, v12

    .line 823
    .line 824
    add-int/lit8 v12, v12, 0x1

    .line 825
    .line 826
    sub-int v7, v53, v26

    .line 827
    .line 828
    sub-int v7, v7, v54

    .line 829
    .line 830
    add-int/lit8 v1, v9, 0x1

    .line 831
    .line 832
    array-length v5, v8

    .line 833
    if-ge v5, v1, :cond_16

    .line 834
    .line 835
    array-length v5, v8

    .line 836
    mul-int/lit8 v5, v5, 0x3

    .line 837
    .line 838
    div-int/lit8 v5, v5, 0x2

    .line 839
    .line 840
    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    .line 841
    .line 842
    .line 843
    move-result v1

    .line 844
    invoke-static {v8, v1}, Ljava/util/Arrays;->copyOf([II)[I

    .line 845
    .line 846
    .line 847
    move-result-object v8

    .line 848
    :cond_16
    aput v18, v8, v9

    .line 849
    .line 850
    add-int/lit8 v9, v9, 0x1

    .line 851
    .line 852
    if-eqz v11, :cond_17

    .line 853
    .line 854
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 855
    .line 856
    .line 857
    move-result v1

    .line 858
    sub-int v1, v1, v48

    .line 859
    .line 860
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 861
    .line 862
    .line 863
    move-result-object v1

    .line 864
    goto :goto_16

    .line 865
    :cond_17
    const/4 v1, 0x0

    .line 866
    :goto_16
    add-int/lit8 v41, v41, 0x1

    .line 867
    .line 868
    add-int v42, v26, v54

    .line 869
    .line 870
    move-object v11, v1

    .line 871
    move/from16 v27, v4

    .line 872
    .line 873
    move/from16 v22, v18

    .line 874
    .line 875
    const/4 v5, 0x0

    .line 876
    const/4 v13, 0x0

    .line 877
    goto :goto_17

    .line 878
    :cond_18
    move-object/from16 v23, v1

    .line 879
    .line 880
    move/from16 v5, v43

    .line 881
    .line 882
    :goto_17
    move/from16 v6, v18

    .line 883
    .line 884
    move-object/from16 v1, v50

    .line 885
    .line 886
    move-object/from16 v50, v11

    .line 887
    .line 888
    move/from16 v18, v13

    .line 889
    .line 890
    move-object/from16 v11, v23

    .line 891
    .line 892
    move/from16 v23, v27

    .line 893
    .line 894
    move-object/from16 v13, p4

    .line 895
    .line 896
    move-object/from16 p4, v10

    .line 897
    .line 898
    move-object/from16 v10, p2

    .line 899
    .line 900
    move-object/from16 p2, v2

    .line 901
    .line 902
    move-object/from16 v2, v55

    .line 903
    .line 904
    goto/16 :goto_d

    .line 905
    .line 906
    :cond_19
    move-object/from16 v2, p2

    .line 907
    .line 908
    move-object/from16 p2, v10

    .line 909
    .line 910
    move-object/from16 p4, v13

    .line 911
    .line 912
    invoke-virtual/range {p2 .. p2}, Ljava/util/ArrayList;->size()I

    .line 913
    .line 914
    .line 915
    move-result v1

    .line 916
    move-object v4, v8

    .line 917
    new-array v8, v1, [Lez4;

    .line 918
    .line 919
    const/4 v5, 0x0

    .line 920
    :goto_18
    if-ge v5, v1, :cond_1a

    .line 921
    .line 922
    invoke-virtual {v2, v5}, Lgz2;->b(I)Ljava/lang/Object;

    .line 923
    .line 924
    .line 925
    move-result-object v6

    .line 926
    aput-object v6, v8, v5

    .line 927
    .line 928
    add-int/lit8 v5, v5, 0x1

    .line 929
    .line 930
    goto :goto_18

    .line 931
    :cond_1a
    new-array v11, v9, [I

    .line 932
    .line 933
    new-array v13, v9, [I

    .line 934
    .line 935
    move v1, v0

    .line 936
    const/4 v0, 0x0

    .line 937
    const/4 v2, 0x0

    .line 938
    const/4 v14, 0x0

    .line 939
    :goto_19
    if-ge v0, v9, :cond_1e

    .line 940
    .line 941
    aget v10, v4, v0

    .line 942
    .line 943
    if-ltz v0, :cond_1d

    .line 944
    .line 945
    if-ge v0, v12, :cond_1d

    .line 946
    .line 947
    aget v5, v3, v0

    .line 948
    .line 949
    move-object/from16 v15, p4

    .line 950
    .line 951
    invoke-virtual {v15, v0}, La24;->c(I)Z

    .line 952
    .line 953
    .line 954
    move-result v6

    .line 955
    if-eqz v6, :cond_1b

    .line 956
    .line 957
    :goto_1a
    move v7, v9

    .line 958
    move v9, v2

    .line 959
    goto :goto_1b

    .line 960
    :cond_1b
    invoke-static/range {v51 .. v52}, Lv71;->h(J)I

    .line 961
    .line 962
    .line 963
    move-result v5

    .line 964
    const v6, 0x7fffffff

    .line 965
    .line 966
    .line 967
    if-ne v5, v6, :cond_1c

    .line 968
    .line 969
    move v5, v6

    .line 970
    goto :goto_1a

    .line 971
    :cond_1c
    invoke-static/range {v51 .. v52}, Lv71;->h(J)I

    .line 972
    .line 973
    .line 974
    move-result v5

    .line 975
    sub-int/2addr v5, v14

    .line 976
    goto :goto_1a

    .line 977
    :goto_1b
    invoke-static/range {v51 .. v52}, Lv71;->j(J)I

    .line 978
    .line 979
    .line 980
    move-result v2

    .line 981
    move-object/from16 v16, v3

    .line 982
    .line 983
    invoke-static/range {v51 .. v52}, Lv71;->i(J)I

    .line 984
    .line 985
    .line 986
    move-result v3

    .line 987
    move-object/from16 v17, v4

    .line 988
    .line 989
    move v4, v5

    .line 990
    move/from16 v18, v12

    .line 991
    .line 992
    move/from16 p3, v14

    .line 993
    .line 994
    move-object/from16 v19, v16

    .line 995
    .line 996
    move-object/from16 v14, v34

    .line 997
    .line 998
    move/from16 v5, v48

    .line 999
    .line 1000
    move-object/from16 v6, p1

    .line 1001
    .line 1002
    move v12, v0

    .line 1003
    move/from16 v16, v7

    .line 1004
    .line 1005
    move-object/from16 v0, p0

    .line 1006
    .line 1007
    move-object/from16 v7, p2

    .line 1008
    .line 1009
    invoke-static/range {v0 .. v12}, Lt36;->J(Lto5;IIIIILpq3;Ljava/util/List;[Lez4;II[II)Loq3;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v2

    .line 1013
    invoke-interface {v2}, Loq3;->b()I

    .line 1014
    .line 1015
    .line 1016
    move-result v3

    .line 1017
    invoke-interface {v2}, Loq3;->a()I

    .line 1018
    .line 1019
    .line 1020
    move-result v4

    .line 1021
    aput v4, v13, v12

    .line 1022
    .line 1023
    add-int v4, p3, v4

    .line 1024
    .line 1025
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 1026
    .line 1027
    .line 1028
    move-result v1

    .line 1029
    invoke-virtual {v14, v2}, Ld34;->b(Ljava/lang/Object;)V

    .line 1030
    .line 1031
    .line 1032
    add-int/lit8 v2, v12, 0x1

    .line 1033
    .line 1034
    move v0, v2

    .line 1035
    move v2, v10

    .line 1036
    move-object/from16 p4, v15

    .line 1037
    .line 1038
    move/from16 v9, v16

    .line 1039
    .line 1040
    move/from16 v12, v18

    .line 1041
    .line 1042
    move-object/from16 v3, v19

    .line 1043
    .line 1044
    move v14, v4

    .line 1045
    move-object/from16 v4, v17

    .line 1046
    .line 1047
    goto :goto_19

    .line 1048
    :cond_1d
    const/16 v29, 0x0

    .line 1049
    .line 1050
    const-string v0, "Index must be between 0 and size"

    .line 1051
    .line 1052
    invoke-static {v0}, Lhh1;->m(Ljava/lang/String;)V

    .line 1053
    .line 1054
    .line 1055
    return-object v29

    .line 1056
    :cond_1e
    move-object/from16 v0, p0

    .line 1057
    .line 1058
    move-object/from16 v6, p1

    .line 1059
    .line 1060
    move/from16 p3, v14

    .line 1061
    .line 1062
    move-object/from16 v14, v34

    .line 1063
    .line 1064
    iget v2, v14, Ld34;->k:I

    .line 1065
    .line 1066
    if-nez v2, :cond_1f

    .line 1067
    .line 1068
    const/4 v1, 0x0

    .line 1069
    const/16 v31, 0x0

    .line 1070
    .line 1071
    goto :goto_1c

    .line 1072
    :cond_1f
    move/from16 v31, p3

    .line 1073
    .line 1074
    :goto_1c
    iget-object v0, v0, Lb52;->b:Lsv;

    .line 1075
    .line 1076
    invoke-interface {v0}, Lsv;->a()F

    .line 1077
    .line 1078
    .line 1079
    move-result v2

    .line 1080
    invoke-interface {v6, v2}, Llk1;->s0(F)I

    .line 1081
    .line 1082
    .line 1083
    move-result v2

    .line 1084
    iget v3, v14, Ld34;->k:I

    .line 1085
    .line 1086
    add-int/lit8 v3, v3, -0x1

    .line 1087
    .line 1088
    mul-int/2addr v3, v2

    .line 1089
    add-int v3, v3, v31

    .line 1090
    .line 1091
    invoke-static/range {v20 .. v21}, Lv71;->j(J)I

    .line 1092
    .line 1093
    .line 1094
    move-result v2

    .line 1095
    invoke-static/range {v20 .. v21}, Lv71;->h(J)I

    .line 1096
    .line 1097
    .line 1098
    move-result v4

    .line 1099
    if-ge v3, v2, :cond_20

    .line 1100
    .line 1101
    move v3, v2

    .line 1102
    :cond_20
    if-gt v3, v4, :cond_21

    .line 1103
    .line 1104
    move v4, v3

    .line 1105
    :cond_21
    invoke-interface {v0, v6, v4, v13, v11}, Lsv;->e(Llk1;I[I[I)V

    .line 1106
    .line 1107
    .line 1108
    invoke-static/range {v20 .. v21}, Lv71;->k(J)I

    .line 1109
    .line 1110
    .line 1111
    move-result v0

    .line 1112
    invoke-static/range {v20 .. v21}, Lv71;->i(J)I

    .line 1113
    .line 1114
    .line 1115
    move-result v2

    .line 1116
    if-ge v1, v0, :cond_22

    .line 1117
    .line 1118
    move v1, v0

    .line 1119
    :cond_22
    if-gt v1, v2, :cond_23

    .line 1120
    .line 1121
    move v2, v1

    .line 1122
    :cond_23
    new-instance v0, Ldb0;

    .line 1123
    .line 1124
    const/16 v1, 0xc

    .line 1125
    .line 1126
    invoke-direct {v0, v14, v1}, Ldb0;-><init>(Ljava/lang/Object;B)V

    .line 1127
    .line 1128
    .line 1129
    move-object/from16 v1, v30

    .line 1130
    .line 1131
    invoke-interface {v6, v2, v4, v1, v0}, Lpq3;->P0(IILjava/util/Map;Lh92;)Loq3;

    .line 1132
    .line 1133
    .line 1134
    move-result-object v0

    .line 1135
    return-object v0

    .line 1136
    :goto_1d
    new-instance v0, Lag1;

    .line 1137
    .line 1138
    const/16 v2, 0x15

    .line 1139
    .line 1140
    invoke-direct {v0, v2}, Lag1;-><init>(B)V

    .line 1141
    .line 1142
    .line 1143
    const/4 v2, 0x0

    .line 1144
    invoke-interface {v6, v2, v2, v1, v0}, Lpq3;->P0(IILjava/util/Map;Lh92;)Loq3;

    .line 1145
    .line 1146
    .line 1147
    move-result-object v0

    .line 1148
    return-object v0
.end method

.method public final d(Lx03;Ljava/util/List;I)I
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Liq3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Liq3;

    .line 33
    .line 34
    :cond_1
    const/16 v2, 0xd

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-static {v3, p3, v3, v3, v2}, Lw71;->b(IIIII)J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    iget-object v4, p0, Lb52;->f:Lz42;

    .line 42
    .line 43
    invoke-virtual {v4, v0, v1, v2, v3}, Lz42;->a(Liq3;Liq3;J)V

    .line 44
    .line 45
    .line 46
    invoke-static {p2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    check-cast p2, Ljava/util/List;

    .line 51
    .line 52
    if-nez p2, :cond_2

    .line 53
    .line 54
    sget-object p2, Lbx1;->i:Lbx1;

    .line 55
    .line 56
    :cond_2
    iget v0, p0, Lb52;->c:F

    .line 57
    .line 58
    invoke-interface {p1, v0}, Llk1;->s0(F)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iget p0, p0, Lb52;->e:F

    .line 63
    .line 64
    invoke-interface {p1, p0}, Llk1;->s0(F)I

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    invoke-static {p2, p3, v0, p0, v4}, Lb52;->k(Ljava/util/List;IIILz42;)I

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    return p0
.end method

.method public final e(Lx03;Ljava/util/List;I)I
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    invoke-static {v4, v2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    check-cast v5, Ljava/util/List;

    .line 15
    .line 16
    if-eqz v5, :cond_0

    .line 17
    .line 18
    invoke-static {v5}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    check-cast v5, Liq3;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v5, 0x0

    .line 26
    :goto_0
    const/4 v7, 0x2

    .line 27
    invoke-static {v7, v2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v8

    .line 31
    check-cast v8, Ljava/util/List;

    .line 32
    .line 33
    if-eqz v8, :cond_1

    .line 34
    .line 35
    invoke-static {v8}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    check-cast v8, Liq3;

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_1
    const/4 v8, 0x0

    .line 43
    :goto_1
    const/4 v9, 0x7

    .line 44
    const/4 v10, 0x0

    .line 45
    invoke-static {v10, v10, v10, v3, v9}, Lw71;->b(IIIII)J

    .line 46
    .line 47
    .line 48
    move-result-wide v11

    .line 49
    iget-object v9, v0, Lb52;->f:Lz42;

    .line 50
    .line 51
    invoke-virtual {v9, v5, v8, v11, v12}, Lz42;->a(Liq3;Liq3;J)V

    .line 52
    .line 53
    .line 54
    invoke-static {v2}, Liv0;->N0(Ljava/util/List;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    check-cast v2, Ljava/util/List;

    .line 59
    .line 60
    if-nez v2, :cond_2

    .line 61
    .line 62
    sget-object v2, Lbx1;->i:Lbx1;

    .line 63
    .line 64
    :cond_2
    iget v5, v0, Lb52;->c:F

    .line 65
    .line 66
    invoke-interface {v1, v5}, Llk1;->s0(F)I

    .line 67
    .line 68
    .line 69
    move-result v15

    .line 70
    iget v5, v0, Lb52;->e:F

    .line 71
    .line 72
    invoke-interface {v1, v5}, Llk1;->s0(F)I

    .line 73
    .line 74
    .line 75
    move-result v16

    .line 76
    invoke-static {v10, v10}, Lcz2;->a(II)J

    .line 77
    .line 78
    .line 79
    move-result-wide v8

    .line 80
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-eqz v1, :cond_3

    .line 85
    .line 86
    return v10

    .line 87
    :cond_3
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    new-array v5, v1, [I

    .line 92
    .line 93
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 94
    .line 95
    .line 96
    move-result v11

    .line 97
    new-array v12, v11, [I

    .line 98
    .line 99
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 100
    .line 101
    .line 102
    move-result v13

    .line 103
    move v14, v10

    .line 104
    :goto_2
    if-ge v14, v13, :cond_4

    .line 105
    .line 106
    invoke-interface {v2, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v17

    .line 110
    move-object/from16 v6, v17

    .line 111
    .line 112
    check-cast v6, Liq3;

    .line 113
    .line 114
    move/from16 v17, v7

    .line 115
    .line 116
    invoke-interface {v6, v3}, Liq3;->S(I)I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    aput v7, v5, v14

    .line 121
    .line 122
    invoke-interface {v6, v7}, Liq3;->h0(I)I

    .line 123
    .line 124
    .line 125
    move-result v6

    .line 126
    aput v6, v12, v14

    .line 127
    .line 128
    add-int/lit8 v14, v14, 0x1

    .line 129
    .line 130
    move/from16 v7, v17

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_4
    move/from16 v17, v7

    .line 134
    .line 135
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    iget-object v0, v0, Lb52;->f:Lz42;

    .line 140
    .line 141
    const v7, 0x7fffffff

    .line 142
    .line 143
    .line 144
    if-ge v7, v6, :cond_5

    .line 145
    .line 146
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    :cond_5
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    if-lt v7, v6, :cond_6

    .line 154
    .line 155
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    :cond_6
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 159
    .line 160
    .line 161
    move-result v6

    .line 162
    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    .line 163
    .line 164
    .line 165
    move-result v6

    .line 166
    move v13, v10

    .line 167
    move v14, v13

    .line 168
    :goto_3
    if-ge v13, v1, :cond_7

    .line 169
    .line 170
    aget v18, v5, v13

    .line 171
    .line 172
    add-int v14, v14, v18

    .line 173
    .line 174
    add-int/lit8 v13, v13, 0x1

    .line 175
    .line 176
    goto :goto_3

    .line 177
    :cond_7
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 178
    .line 179
    .line 180
    move-result v13

    .line 181
    sub-int/2addr v13, v4

    .line 182
    mul-int/2addr v13, v15

    .line 183
    add-int/2addr v13, v14

    .line 184
    if-eqz v11, :cond_1e

    .line 185
    .line 186
    aget v14, v12, v10

    .line 187
    .line 188
    sub-int/2addr v11, v4

    .line 189
    if-gt v4, v11, :cond_9

    .line 190
    .line 191
    move v7, v4

    .line 192
    move/from16 v18, v10

    .line 193
    .line 194
    :goto_4
    aget v10, v12, v7

    .line 195
    .line 196
    if-ge v14, v10, :cond_8

    .line 197
    .line 198
    move v14, v10

    .line 199
    :cond_8
    if-eq v7, v11, :cond_a

    .line 200
    .line 201
    add-int/lit8 v7, v7, 0x1

    .line 202
    .line 203
    goto :goto_4

    .line 204
    :cond_9
    move/from16 v18, v10

    .line 205
    .line 206
    :cond_a
    if-eqz v1, :cond_1d

    .line 207
    .line 208
    aget v7, v5, v18

    .line 209
    .line 210
    sub-int/2addr v1, v4

    .line 211
    if-gt v4, v1, :cond_c

    .line 212
    .line 213
    move v10, v4

    .line 214
    :goto_5
    aget v11, v5, v10

    .line 215
    .line 216
    if-ge v7, v11, :cond_b

    .line 217
    .line 218
    move v7, v11

    .line 219
    :cond_b
    if-eq v10, v1, :cond_c

    .line 220
    .line 221
    add-int/lit8 v10, v10, 0x1

    .line 222
    .line 223
    goto :goto_5

    .line 224
    :cond_c
    move v1, v13

    .line 225
    :goto_6
    if-gt v7, v1, :cond_1c

    .line 226
    .line 227
    if-eq v14, v3, :cond_1c

    .line 228
    .line 229
    add-int v10, v7, v1

    .line 230
    .line 231
    div-int/lit8 v10, v10, 0x2

    .line 232
    .line 233
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 234
    .line 235
    .line 236
    move-result v11

    .line 237
    if-eqz v11, :cond_d

    .line 238
    .line 239
    move v4, v1

    .line 240
    move-object v11, v2

    .line 241
    move-object/from16 p1, v12

    .line 242
    .line 243
    move-object v12, v0

    .line 244
    :goto_7
    move-wide v0, v8

    .line 245
    goto/16 :goto_15

    .line 246
    .line 247
    :cond_d
    move/from16 v11, v18

    .line 248
    .line 249
    const v13, 0x7fffffff

    .line 250
    .line 251
    .line 252
    invoke-static {v11, v10, v11, v13}, Lw71;->a(IIII)J

    .line 253
    .line 254
    .line 255
    move-result-wide v18

    .line 256
    new-instance v20, Lw42;

    .line 257
    .line 258
    move-object v4, v12

    .line 259
    move-object v12, v0

    .line 260
    move-object v0, v4

    .line 261
    move v4, v11

    .line 262
    move-wide/from16 v13, v18

    .line 263
    .line 264
    move-object/from16 v11, v20

    .line 265
    .line 266
    invoke-direct/range {v11 .. v16}, Lw42;-><init>(Lz42;JII)V

    .line 267
    .line 268
    .line 269
    invoke-static {v4, v2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v11

    .line 273
    check-cast v11, Liq3;

    .line 274
    .line 275
    if-eqz v11, :cond_e

    .line 276
    .line 277
    aget v13, v0, v4

    .line 278
    .line 279
    aget v14, v5, v4

    .line 280
    .line 281
    goto :goto_8

    .line 282
    :cond_e
    const/4 v13, 0x0

    .line 283
    const/4 v14, 0x0

    .line 284
    :goto_8
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 285
    .line 286
    .line 287
    move-result v4

    .line 288
    move-object/from16 p1, v0

    .line 289
    .line 290
    const/4 v0, 0x1

    .line 291
    if-le v4, v0, :cond_f

    .line 292
    .line 293
    move/from16 v21, v0

    .line 294
    .line 295
    :goto_9
    const v4, 0x7fffffff

    .line 296
    .line 297
    .line 298
    goto :goto_a

    .line 299
    :cond_f
    const/16 v21, 0x0

    .line 300
    .line 301
    goto :goto_9

    .line 302
    :goto_a
    invoke-static {v10, v4}, Lcz2;->a(II)J

    .line 303
    .line 304
    .line 305
    move-result-wide v23

    .line 306
    move v4, v1

    .line 307
    if-nez v11, :cond_10

    .line 308
    .line 309
    const/16 v25, 0x0

    .line 310
    .line 311
    goto :goto_b

    .line 312
    :cond_10
    invoke-static {v14, v13}, Lcz2;->a(II)J

    .line 313
    .line 314
    .line 315
    move-result-wide v0

    .line 316
    new-instance v11, Lcz2;

    .line 317
    .line 318
    invoke-direct {v11, v0, v1}, Lcz2;-><init>(J)V

    .line 319
    .line 320
    .line 321
    move-object/from16 v25, v11

    .line 322
    .line 323
    :goto_b
    const/16 v29, 0x0

    .line 324
    .line 325
    const/16 v30, 0x0

    .line 326
    .line 327
    const/16 v22, 0x0

    .line 328
    .line 329
    const/16 v26, 0x0

    .line 330
    .line 331
    const/16 v27, 0x0

    .line 332
    .line 333
    const/16 v28, 0x0

    .line 334
    .line 335
    invoke-virtual/range {v20 .. v30}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    iget-boolean v0, v0, Lv42;->c:Z

    .line 340
    .line 341
    if-eqz v0, :cond_11

    .line 342
    .line 343
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 344
    .line 345
    .line 346
    move-object v11, v2

    .line 347
    goto :goto_7

    .line 348
    :cond_11
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 349
    .line 350
    .line 351
    move-result v0

    .line 352
    move/from16 v22, v10

    .line 353
    .line 354
    move/from16 v21, v14

    .line 355
    .line 356
    move/from16 v23, v26

    .line 357
    .line 358
    move/from16 v1, v28

    .line 359
    .line 360
    const/16 p2, 0x0

    .line 361
    .line 362
    const/4 v11, 0x0

    .line 363
    move v14, v13

    .line 364
    const/4 v13, 0x0

    .line 365
    :goto_c
    if-ge v11, v0, :cond_18

    .line 366
    .line 367
    sub-int v13, v22, v21

    .line 368
    .line 369
    move/from16 v31, v0

    .line 370
    .line 371
    add-int/lit8 v0, v11, 0x1

    .line 372
    .line 373
    invoke-static {v1, v14}, Ljava/lang/Math;->max(II)I

    .line 374
    .line 375
    .line 376
    move-result v28

    .line 377
    invoke-static {v0, v2}, Liv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    check-cast v1, Liq3;

    .line 382
    .line 383
    if-eqz v1, :cond_12

    .line 384
    .line 385
    aget v14, p1, v0

    .line 386
    .line 387
    aget v21, v5, v0

    .line 388
    .line 389
    add-int v21, v21, v15

    .line 390
    .line 391
    move/from16 v32, v0

    .line 392
    .line 393
    move v0, v14

    .line 394
    move/from16 v14, v21

    .line 395
    .line 396
    goto :goto_d

    .line 397
    :cond_12
    move/from16 v32, v0

    .line 398
    .line 399
    const/4 v0, 0x0

    .line 400
    const/4 v14, 0x0

    .line 401
    :goto_d
    add-int/lit8 v11, v11, 0x2

    .line 402
    .line 403
    move-object/from16 v33, v1

    .line 404
    .line 405
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 406
    .line 407
    .line 408
    move-result v1

    .line 409
    if-ge v11, v1, :cond_13

    .line 410
    .line 411
    const/16 v21, 0x1

    .line 412
    .line 413
    goto :goto_e

    .line 414
    :cond_13
    const/16 v21, 0x0

    .line 415
    .line 416
    :goto_e
    sub-int v22, v32, p2

    .line 417
    .line 418
    move/from16 v26, v23

    .line 419
    .line 420
    const v1, 0x7fffffff

    .line 421
    .line 422
    .line 423
    invoke-static {v13, v1}, Lcz2;->a(II)J

    .line 424
    .line 425
    .line 426
    move-result-wide v23

    .line 427
    if-nez v33, :cond_14

    .line 428
    .line 429
    move/from16 v34, v0

    .line 430
    .line 431
    move-object v11, v2

    .line 432
    const/16 v25, 0x0

    .line 433
    .line 434
    goto :goto_f

    .line 435
    :cond_14
    move-object v11, v2

    .line 436
    invoke-static {v14, v0}, Lcz2;->a(II)J

    .line 437
    .line 438
    .line 439
    move-result-wide v1

    .line 440
    move/from16 v34, v0

    .line 441
    .line 442
    new-instance v0, Lcz2;

    .line 443
    .line 444
    invoke-direct {v0, v1, v2}, Lcz2;-><init>(J)V

    .line 445
    .line 446
    .line 447
    move-object/from16 v25, v0

    .line 448
    .line 449
    :goto_f
    const/16 v29, 0x0

    .line 450
    .line 451
    const/16 v30, 0x0

    .line 452
    .line 453
    invoke-virtual/range {v20 .. v30}, Lw42;->b(ZIJLcz2;IIIZZ)Lv42;

    .line 454
    .line 455
    .line 456
    move-result-object v0

    .line 457
    iget-boolean v1, v0, Lv42;->b:Z

    .line 458
    .line 459
    if-eqz v1, :cond_17

    .line 460
    .line 461
    add-int v28, v28, v16

    .line 462
    .line 463
    add-int v24, v28, v27

    .line 464
    .line 465
    move/from16 v23, v26

    .line 466
    .line 467
    move/from16 v26, v22

    .line 468
    .line 469
    if-eqz v33, :cond_15

    .line 470
    .line 471
    const/16 v22, 0x1

    .line 472
    .line 473
    :goto_10
    move-object/from16 v21, v0

    .line 474
    .line 475
    move/from16 v25, v13

    .line 476
    .line 477
    goto :goto_11

    .line 478
    :cond_15
    const/16 v22, 0x0

    .line 479
    .line 480
    goto :goto_10

    .line 481
    :goto_11
    invoke-virtual/range {v20 .. v26}, Lw42;->a(Lv42;ZIIII)Loq;

    .line 482
    .line 483
    .line 484
    move-object/from16 v0, v21

    .line 485
    .line 486
    move/from16 v26, v23

    .line 487
    .line 488
    sub-int/2addr v14, v15

    .line 489
    add-int/lit8 v23, v26, 0x1

    .line 490
    .line 491
    iget-boolean v0, v0, Lv42;->c:Z

    .line 492
    .line 493
    if-eqz v0, :cond_16

    .line 494
    .line 495
    move/from16 v27, v24

    .line 496
    .line 497
    move/from16 v13, v32

    .line 498
    .line 499
    goto :goto_14

    .line 500
    :cond_16
    move/from16 v22, v10

    .line 501
    .line 502
    move/from16 v27, v24

    .line 503
    .line 504
    move/from16 v0, v32

    .line 505
    .line 506
    const/4 v1, 0x0

    .line 507
    :goto_12
    move/from16 v21, v14

    .line 508
    .line 509
    goto :goto_13

    .line 510
    :cond_17
    move/from16 v25, v13

    .line 511
    .line 512
    move/from16 v0, p2

    .line 513
    .line 514
    move/from16 v22, v25

    .line 515
    .line 516
    move/from16 v23, v26

    .line 517
    .line 518
    move/from16 v1, v28

    .line 519
    .line 520
    goto :goto_12

    .line 521
    :goto_13
    move/from16 p2, v0

    .line 522
    .line 523
    move-object v2, v11

    .line 524
    move/from16 v0, v31

    .line 525
    .line 526
    move/from16 v11, v32

    .line 527
    .line 528
    move v13, v11

    .line 529
    move/from16 v14, v34

    .line 530
    .line 531
    goto/16 :goto_c

    .line 532
    .line 533
    :cond_18
    move-object v11, v2

    .line 534
    :goto_14
    sub-int v0, v27, v16

    .line 535
    .line 536
    invoke-static {v0, v13}, Lcz2;->a(II)J

    .line 537
    .line 538
    .line 539
    move-result-wide v0

    .line 540
    :goto_15
    const/16 v2, 0x20

    .line 541
    .line 542
    shr-long v13, v0, v2

    .line 543
    .line 544
    long-to-int v14, v13

    .line 545
    const-wide v20, 0xffffffffL

    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    and-long v0, v0, v20

    .line 551
    .line 552
    long-to-int v0, v0

    .line 553
    if-gt v14, v3, :cond_1a

    .line 554
    .line 555
    if-lt v0, v6, :cond_1a

    .line 556
    .line 557
    if-ge v14, v3, :cond_19

    .line 558
    .line 559
    add-int/lit8 v1, v10, -0x1

    .line 560
    .line 561
    :goto_16
    move v13, v10

    .line 562
    move-object v2, v11

    .line 563
    move-object v0, v12

    .line 564
    const/16 v18, 0x0

    .line 565
    .line 566
    move-object/from16 v12, p1

    .line 567
    .line 568
    goto/16 :goto_6

    .line 569
    .line 570
    :cond_19
    return v10

    .line 571
    :cond_1a
    add-int/lit8 v7, v10, 0x1

    .line 572
    .line 573
    if-le v7, v4, :cond_1b

    .line 574
    .line 575
    return v7

    .line 576
    :cond_1b
    move v1, v4

    .line 577
    goto :goto_16

    .line 578
    :cond_1c
    return v13

    .line 579
    :cond_1d
    invoke-static {}, Lhh1;->p()V

    .line 580
    .line 581
    .line 582
    const/16 v18, 0x0

    .line 583
    .line 584
    return v18

    .line 585
    :cond_1e
    move/from16 v18, v10

    .line 586
    .line 587
    invoke-static {}, Lhh1;->p()V

    .line 588
    .line 589
    .line 590
    return v18
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lb52;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lb52;

    .line 8
    .line 9
    iget-object v0, p0, Lb52;->a:Lqv;

    .line 10
    .line 11
    iget-object v1, p1, Lb52;->a:Lqv;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p0, Lb52;->b:Lsv;

    .line 20
    .line 21
    iget-object v1, p1, Lb52;->b:Lsv;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget v0, p0, Lb52;->c:F

    .line 30
    .line 31
    iget v1, p1, Lb52;->c:F

    .line 32
    .line 33
    invoke-static {v0, v1}, Lmo1;->b(FF)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    iget-object v0, p0, Lb52;->d:Lre1;

    .line 40
    .line 41
    iget-object v1, p1, Lb52;->d:Lre1;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Lre1;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    iget v0, p0, Lb52;->e:F

    .line 50
    .line 51
    iget v1, p1, Lb52;->e:F

    .line 52
    .line 53
    invoke-static {v0, v1}, Lmo1;->b(FF)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_0

    .line 58
    .line 59
    iget-object p0, p0, Lb52;->f:Lz42;

    .line 60
    .line 61
    iget-object p1, p1, Lb52;->f:Lz42;

    .line 62
    .line 63
    invoke-static {p0, p1}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-nez p0, :cond_1

    .line 68
    .line 69
    :cond_0
    const/4 p0, 0x0

    .line 70
    return p0

    .line 71
    :cond_1
    const/4 p0, 0x1

    .line 72
    return p0
.end method

.method public final f(I[I[ILpq3;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lb52;->a:Lqv;

    .line 2
    .line 3
    invoke-interface {p4}, Lx03;->getLayoutDirection()La83;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    move v2, p1

    .line 8
    move-object v3, p2

    .line 9
    move-object v5, p3

    .line 10
    move-object v1, p4

    .line 11
    invoke-interface/range {v0 .. v5}, Lqv;->d(Llk1;I[ILa83;[I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final g(IIIZ)J
    .locals 0

    .line 1
    sget-object p0, Lxo5;->a:Lyo5;

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    if-nez p4, :cond_0

    .line 5
    .line 6
    invoke-static {p1, p2, p0, p3}, Lw71;->a(IIII)J

    .line 7
    .line 8
    .line 9
    move-result-wide p0

    .line 10
    return-wide p0

    .line 11
    :cond_0
    invoke-static {p1, p2, p0, p3}, Llm;->R(IIII)J

    .line 12
    .line 13
    .line 14
    move-result-wide p0

    .line 15
    return-wide p0
.end method

.method public final h(Lez4;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lez4;->l0()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lb52;->a:Lqv;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const v1, 0x9511

    .line 8
    .line 9
    .line 10
    add-int/2addr v0, v1

    .line 11
    const/16 v1, 0x1f

    .line 12
    .line 13
    mul-int/2addr v0, v1

    .line 14
    iget-object v2, p0, Lb52;->b:Lsv;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    add-int/2addr v2, v0

    .line 21
    mul-int/2addr v2, v1

    .line 22
    iget v0, p0, Lb52;->c:F

    .line 23
    .line 24
    invoke-static {v0, v2, v1}, Lly1;->c(FII)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v2, p0, Lb52;->d:Lre1;

    .line 29
    .line 30
    invoke-virtual {v2}, Lre1;->hashCode()I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    add-int/2addr v2, v0

    .line 35
    mul-int/2addr v2, v1

    .line 36
    iget v0, p0, Lb52;->e:F

    .line 37
    .line 38
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v0, v2

    .line 43
    mul-int/2addr v0, v1

    .line 44
    const v2, 0x7fffffff

    .line 45
    .line 46
    .line 47
    add-int/2addr v0, v2

    .line 48
    mul-int/2addr v0, v1

    .line 49
    add-int/2addr v0, v2

    .line 50
    mul-int/2addr v0, v1

    .line 51
    iget-object p0, p0, Lb52;->f:Lz42;

    .line 52
    .line 53
    invoke-virtual {p0}, Lz42;->hashCode()I

    .line 54
    .line 55
    .line 56
    move-result p0

    .line 57
    add-int/2addr p0, v0

    .line 58
    return p0
.end method

.method public final i(Lez4;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lez4;->p0()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final j([Lez4;Lpq3;[III[IIII)Loq3;
    .locals 10

    .line 1
    new-instance v0, La52;

    .line 2
    .line 3
    sget-object v8, La83;->i:La83;

    .line 4
    .line 5
    move-object v6, p0

    .line 6
    move-object v5, p1

    .line 7
    move-object v9, p3

    .line 8
    move v7, p5

    .line 9
    move-object/from16 v1, p6

    .line 10
    .line 11
    move/from16 v2, p7

    .line 12
    .line 13
    move/from16 v3, p8

    .line 14
    .line 15
    move/from16 v4, p9

    .line 16
    .line 17
    invoke-direct/range {v0 .. v9}, La52;-><init>([IIII[Lez4;Lb52;ILa83;[I)V

    .line 18
    .line 19
    .line 20
    sget-object p0, Lcx1;->i:Lcx1;

    .line 21
    .line 22
    invoke-interface {p2, p4, p5, p0, v0}, Lpq3;->P0(IILjava/util/Map;Lh92;)Loq3;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, Lb52;->c:F

    .line 2
    .line 3
    invoke-static {v0}, Lmo1;->c(F)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget v1, p0, Lb52;->e:F

    .line 8
    .line 9
    invoke-static {v1}, Lmo1;->c(F)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    new-instance v2, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v3, "FlowMeasurePolicy(isHorizontal=true, horizontalArrangement="

    .line 16
    .line 17
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object v3, p0, Lb52;->a:Lqv;

    .line 21
    .line 22
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v3, ", verticalArrangement="

    .line 26
    .line 27
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget-object v3, p0, Lb52;->b:Lsv;

    .line 31
    .line 32
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string v3, ", mainAxisSpacing="

    .line 36
    .line 37
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v0, ", crossAxisAlignment="

    .line 44
    .line 45
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget-object v0, p0, Lb52;->d:Lre1;

    .line 49
    .line 50
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v0, ", crossAxisArrangementSpacing="

    .line 54
    .line 55
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v0, ", maxItemsInMainAxis=2147483647, maxLines=2147483647, overflow="

    .line 62
    .line 63
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    iget-object p0, p0, Lb52;->f:Lz42;

    .line 67
    .line 68
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string p0, ")"

    .line 72
    .line 73
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0
.end method
