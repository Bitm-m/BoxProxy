.class public final synthetic Lbb5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic A:I

.field public final synthetic B:Lh92;

.field public final synthetic C:Z

.field public final synthetic D:Lx46;

.field public final synthetic E:Lhe1;

.field public final synthetic F:Z

.field public final synthetic G:Ljava/lang/String;

.field public final synthetic H:Ljava/util/List;

.field public final synthetic I:Ljava/util/List;

.field public final synthetic i:Z

.field public final synthetic j:Lmz3;

.field public final synthetic k:Lk02;

.field public final synthetic l:Lzs4;

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:Lsc3;

.field public final synthetic p:Z

.field public final synthetic q:Lud5;

.field public final synthetic r:Ljava/util/List;

.field public final synthetic s:I

.field public final synthetic t:Ljava/util/Map;

.field public final synthetic u:Ljava/util/Map;

.field public final synthetic v:Ljava/util/Map;

.field public final synthetic w:Z

.field public final synthetic x:Lb34;

.field public final synthetic y:Z

.field public final synthetic z:Ljava/util/Set;


# direct methods
.method public synthetic constructor <init>(ZLmz3;Lk02;Lzs4;FFLsc3;ZLud5;Ljava/util/List;ILjava/util/Map;Ljava/util/Map;Ljava/util/Map;ZLb34;ZLjava/util/Set;ILh92;ZLx46;Lhe1;ZLjava/lang/String;Ljava/util/List;Ljava/util/List;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lbb5;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Lbb5;->j:Lmz3;

    .line 7
    .line 8
    iput-object p3, p0, Lbb5;->k:Lk02;

    .line 9
    .line 10
    iput-object p4, p0, Lbb5;->l:Lzs4;

    .line 11
    .line 12
    iput p5, p0, Lbb5;->m:F

    .line 13
    .line 14
    iput p6, p0, Lbb5;->n:F

    .line 15
    .line 16
    iput-object p7, p0, Lbb5;->o:Lsc3;

    .line 17
    .line 18
    iput-boolean p8, p0, Lbb5;->p:Z

    .line 19
    .line 20
    iput-object p9, p0, Lbb5;->q:Lud5;

    .line 21
    .line 22
    iput-object p10, p0, Lbb5;->r:Ljava/util/List;

    .line 23
    .line 24
    iput p11, p0, Lbb5;->s:I

    .line 25
    .line 26
    iput-object p12, p0, Lbb5;->t:Ljava/util/Map;

    .line 27
    .line 28
    iput-object p13, p0, Lbb5;->u:Ljava/util/Map;

    .line 29
    .line 30
    iput-object p14, p0, Lbb5;->v:Ljava/util/Map;

    .line 31
    .line 32
    iput-boolean p15, p0, Lbb5;->w:Z

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lbb5;->x:Lb34;

    .line 37
    .line 38
    move/from16 p1, p17

    .line 39
    .line 40
    iput-boolean p1, p0, Lbb5;->y:Z

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lbb5;->z:Ljava/util/Set;

    .line 45
    .line 46
    move/from16 p1, p19

    .line 47
    .line 48
    iput p1, p0, Lbb5;->A:I

    .line 49
    .line 50
    move-object/from16 p1, p20

    .line 51
    .line 52
    iput-object p1, p0, Lbb5;->B:Lh92;

    .line 53
    .line 54
    move/from16 p1, p21

    .line 55
    .line 56
    iput-boolean p1, p0, Lbb5;->C:Z

    .line 57
    .line 58
    move-object/from16 p1, p22

    .line 59
    .line 60
    iput-object p1, p0, Lbb5;->D:Lx46;

    .line 61
    .line 62
    move-object/from16 p1, p23

    .line 63
    .line 64
    iput-object p1, p0, Lbb5;->E:Lhe1;

    .line 65
    .line 66
    move/from16 p1, p24

    .line 67
    .line 68
    iput-boolean p1, p0, Lbb5;->F:Z

    .line 69
    .line 70
    move-object/from16 p1, p25

    .line 71
    .line 72
    iput-object p1, p0, Lbb5;->G:Ljava/lang/String;

    .line 73
    .line 74
    move-object/from16 p1, p26

    .line 75
    .line 76
    iput-object p1, p0, Lbb5;->H:Ljava/util/List;

    .line 77
    .line 78
    move-object/from16 p1, p27

    .line 79
    .line 80
    iput-object p1, p0, Lbb5;->I:Ljava/util/List;

    .line 81
    .line 82
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lrc0;

    .line 6
    .line 7
    move-object/from16 v12, p2

    .line 8
    .line 9
    check-cast v12, Lla2;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 23
    .line 24
    const/4 v14, 0x2

    .line 25
    if-nez v3, :cond_1

    .line 26
    .line 27
    invoke-virtual {v12, v1}, Lla2;->g(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    const/4 v3, 0x4

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    move v3, v14

    .line 36
    :goto_0
    or-int/2addr v2, v3

    .line 37
    :cond_1
    and-int/lit8 v3, v2, 0x13

    .line 38
    .line 39
    const/16 v4, 0x12

    .line 40
    .line 41
    const/4 v15, 0x1

    .line 42
    const/4 v5, 0x0

    .line 43
    if-eq v3, v4, :cond_2

    .line 44
    .line 45
    move v3, v15

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    move v3, v5

    .line 48
    :goto_1
    and-int/2addr v2, v15

    .line 49
    invoke-virtual {v12, v2, v3}, Lla2;->S(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_20

    .line 54
    .line 55
    sget-object v2, Lef6;->c:Lz12;

    .line 56
    .line 57
    iget-boolean v3, v0, Lbb5;->i:Z

    .line 58
    .line 59
    const/4 v4, 0x0

    .line 60
    sget-object v6, Ljz3;->i:Ljz3;

    .line 61
    .line 62
    if-eqz v3, :cond_3

    .line 63
    .line 64
    iget-object v7, v0, Lbb5;->j:Lmz3;

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_3
    iget-object v7, v0, Lbb5;->k:Lk02;

    .line 68
    .line 69
    iget-object v7, v7, Lk02;->e:Li02;

    .line 70
    .line 71
    invoke-static {v6, v7, v4}, Lf13;->L(Lmz3;Lq84;Lt84;)Lmz3;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    :goto_2
    invoke-interface {v2, v7}, Lmz3;->a0(Lmz3;)Lmz3;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    const/high16 v7, 0x41800000    # 16.0f

    .line 80
    .line 81
    const/4 v8, 0x0

    .line 82
    invoke-static {v2, v7, v8, v14}, Lif0;->R(Lmz3;FFI)Lmz3;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    iget-object v9, v0, Lbb5;->l:Lzs4;

    .line 87
    .line 88
    invoke-interface {v9}, Lzs4;->d()F

    .line 89
    .line 90
    .line 91
    move-result v10

    .line 92
    if-eqz v3, :cond_4

    .line 93
    .line 94
    iget v11, v0, Lbb5;->m:F

    .line 95
    .line 96
    goto :goto_3

    .line 97
    :cond_4
    move v11, v8

    .line 98
    :goto_3
    add-float/2addr v10, v11

    .line 99
    invoke-interface {v9}, Lzs4;->c()F

    .line 100
    .line 101
    .line 102
    move-result v9

    .line 103
    iget v11, v0, Lbb5;->n:F

    .line 104
    .line 105
    if-eqz v3, :cond_5

    .line 106
    .line 107
    move v7, v11

    .line 108
    goto :goto_4

    .line 109
    :cond_5
    add-float/2addr v7, v11

    .line 110
    :goto_4
    add-float/2addr v9, v7

    .line 111
    const/4 v3, 0x5

    .line 112
    invoke-static {v8, v10, v8, v9, v3}, Lif0;->q(FFFFI)Lbt4;

    .line 113
    .line 114
    .line 115
    move-result-object v7

    .line 116
    new-instance v5, Lrv;

    .line 117
    .line 118
    new-instance v10, Lzy1;

    .line 119
    .line 120
    const/4 v13, 0x3

    .line 121
    invoke-direct {v10, v13}, Lzy1;-><init>(B)V

    .line 122
    .line 123
    .line 124
    invoke-direct {v5, v8, v15, v10}, Lrv;-><init>(FZLzy1;)V

    .line 125
    .line 126
    .line 127
    iget-boolean v8, v0, Lbb5;->p:Z

    .line 128
    .line 129
    invoke-virtual {v12, v8}, Lla2;->h(Z)Z

    .line 130
    .line 131
    .line 132
    move-result v10

    .line 133
    iget-object v3, v0, Lbb5;->q:Lud5;

    .line 134
    .line 135
    invoke-virtual {v12, v3}, Lla2;->g(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v16

    .line 139
    or-int v10, v10, v16

    .line 140
    .line 141
    iget-object v4, v0, Lbb5;->r:Ljava/util/List;

    .line 142
    .line 143
    invoke-virtual {v12, v4}, Lla2;->i(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v16

    .line 147
    or-int v10, v10, v16

    .line 148
    .line 149
    iget v9, v0, Lbb5;->s:I

    .line 150
    .line 151
    invoke-virtual {v12, v9}, Lla2;->e(I)Z

    .line 152
    .line 153
    .line 154
    move-result v16

    .line 155
    or-int v10, v10, v16

    .line 156
    .line 157
    iget-object v13, v0, Lbb5;->t:Ljava/util/Map;

    .line 158
    .line 159
    invoke-virtual {v12, v13}, Lla2;->i(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v16

    .line 163
    or-int v10, v10, v16

    .line 164
    .line 165
    iget-object v14, v0, Lbb5;->u:Ljava/util/Map;

    .line 166
    .line 167
    invoke-virtual {v12, v14}, Lla2;->i(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v16

    .line 171
    or-int v10, v10, v16

    .line 172
    .line 173
    iget-object v15, v0, Lbb5;->v:Ljava/util/Map;

    .line 174
    .line 175
    invoke-virtual {v12, v15}, Lla2;->i(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    move-result v16

    .line 179
    or-int v10, v10, v16

    .line 180
    .line 181
    move-object/from16 v30, v2

    .line 182
    .line 183
    iget-boolean v2, v0, Lbb5;->w:Z

    .line 184
    .line 185
    invoke-virtual {v12, v2}, Lla2;->h(Z)Z

    .line 186
    .line 187
    .line 188
    move-result v16

    .line 189
    or-int v10, v10, v16

    .line 190
    .line 191
    move/from16 v26, v2

    .line 192
    .line 193
    iget-object v2, v0, Lbb5;->x:Lb34;

    .line 194
    .line 195
    invoke-virtual {v12, v2}, Lla2;->g(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    move-result v16

    .line 199
    or-int v10, v10, v16

    .line 200
    .line 201
    move-object/from16 v27, v2

    .line 202
    .line 203
    iget-boolean v2, v0, Lbb5;->y:Z

    .line 204
    .line 205
    invoke-virtual {v12, v2}, Lla2;->h(Z)Z

    .line 206
    .line 207
    .line 208
    move-result v16

    .line 209
    or-int v10, v10, v16

    .line 210
    .line 211
    move/from16 v28, v2

    .line 212
    .line 213
    iget-object v2, v0, Lbb5;->z:Ljava/util/Set;

    .line 214
    .line 215
    invoke-virtual {v12, v2}, Lla2;->i(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    move-result v16

    .line 219
    or-int v10, v10, v16

    .line 220
    .line 221
    move-object/from16 v21, v2

    .line 222
    .line 223
    iget v2, v0, Lbb5;->A:I

    .line 224
    .line 225
    invoke-virtual {v12, v2}, Lla2;->e(I)Z

    .line 226
    .line 227
    .line 228
    move-result v16

    .line 229
    or-int v10, v10, v16

    .line 230
    .line 231
    move/from16 v22, v2

    .line 232
    .line 233
    iget-object v2, v0, Lbb5;->B:Lh92;

    .line 234
    .line 235
    invoke-virtual {v12, v2}, Lla2;->g(Ljava/lang/Object;)Z

    .line 236
    .line 237
    .line 238
    move-result v16

    .line 239
    or-int v10, v10, v16

    .line 240
    .line 241
    move-object/from16 v29, v2

    .line 242
    .line 243
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v2

    .line 247
    move-object/from16 v31, v6

    .line 248
    .line 249
    sget-object v6, Ld21;->a:Lq9;

    .line 250
    .line 251
    if-nez v10, :cond_6

    .line 252
    .line 253
    if-eq v2, v6, :cond_6

    .line 254
    .line 255
    move-object v14, v3

    .line 256
    move-object/from16 v24, v15

    .line 257
    .line 258
    move-object/from16 v25, v21

    .line 259
    .line 260
    move/from16 v28, v22

    .line 261
    .line 262
    move-object v15, v13

    .line 263
    goto :goto_5

    .line 264
    :cond_6
    new-instance v16, Lfb5;

    .line 265
    .line 266
    move-object/from16 v18, v3

    .line 267
    .line 268
    move-object/from16 v19, v4

    .line 269
    .line 270
    move/from16 v17, v8

    .line 271
    .line 272
    move/from16 v20, v9

    .line 273
    .line 274
    move-object/from16 v23, v13

    .line 275
    .line 276
    move-object/from16 v25, v14

    .line 277
    .line 278
    move-object/from16 v24, v15

    .line 279
    .line 280
    invoke-direct/range {v16 .. v29}, Lfb5;-><init>(ZLud5;Ljava/util/List;ILjava/util/Set;ILjava/util/Map;Ljava/util/Map;Ljava/util/Map;ZLb34;ZLh92;)V

    .line 281
    .line 282
    .line 283
    move-object/from16 v2, v16

    .line 284
    .line 285
    move-object/from16 v14, v18

    .line 286
    .line 287
    move-object/from16 v25, v21

    .line 288
    .line 289
    move/from16 v28, v22

    .line 290
    .line 291
    move-object/from16 v15, v23

    .line 292
    .line 293
    invoke-virtual {v12, v2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    :goto_5
    move-object v10, v2

    .line 297
    check-cast v10, Lh92;

    .line 298
    .line 299
    move-object/from16 v21, v12

    .line 300
    .line 301
    const/16 v12, 0x6000

    .line 302
    .line 303
    const/16 v13, 0x1e8

    .line 304
    .line 305
    iget-object v3, v0, Lbb5;->o:Lsc3;

    .line 306
    .line 307
    move-object v2, v6

    .line 308
    const/4 v6, 0x0

    .line 309
    move-object v4, v7

    .line 310
    const/4 v7, 0x0

    .line 311
    const/4 v8, 0x0

    .line 312
    const/4 v9, 0x0

    .line 313
    move-object/from16 p1, v29

    .line 314
    .line 315
    move-object/from16 v29, v15

    .line 316
    .line 317
    move-object/from16 v15, p1

    .line 318
    .line 319
    move-object/from16 p1, v1

    .line 320
    .line 321
    move-object v1, v2

    .line 322
    move/from16 v17, v11

    .line 323
    .line 324
    move-object/from16 v11, v21

    .line 325
    .line 326
    move-object/from16 v2, v30

    .line 327
    .line 328
    move-object/from16 v32, v31

    .line 329
    .line 330
    const/16 v16, 0x0

    .line 331
    .line 332
    invoke-static/range {v2 .. v13}, Lln;->i(Lmz3;Lsc3;Lzs4;Lsv;Ll20;Lni1;ZLgq4;Lh92;Lla2;II)V

    .line 333
    .line 334
    .line 335
    move-object v12, v11

    .line 336
    iget-object v2, v0, Lbb5;->D:Lx46;

    .line 337
    .line 338
    invoke-virtual {v12, v2}, Lla2;->i(Ljava/lang/Object;)Z

    .line 339
    .line 340
    .line 341
    move-result v4

    .line 342
    iget-object v5, v0, Lbb5;->E:Lhe1;

    .line 343
    .line 344
    invoke-virtual {v12, v5}, Lla2;->i(Ljava/lang/Object;)Z

    .line 345
    .line 346
    .line 347
    move-result v6

    .line 348
    or-int/2addr v4, v6

    .line 349
    invoke-virtual {v12, v3}, Lla2;->g(Ljava/lang/Object;)Z

    .line 350
    .line 351
    .line 352
    move-result v6

    .line 353
    or-int/2addr v4, v6

    .line 354
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v6

    .line 358
    if-nez v4, :cond_7

    .line 359
    .line 360
    if-ne v6, v1, :cond_8

    .line 361
    .line 362
    :cond_7
    new-instance v6, Lgb5;

    .line 363
    .line 364
    const/4 v9, 0x0

    .line 365
    invoke-direct {v6, v2, v5, v3, v9}, Lgb5;-><init>(Lx46;Lhe1;Lsc3;B)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v12, v6}, Lla2;->k0(Ljava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    :cond_8
    move-object v3, v6

    .line 372
    check-cast v3, Lw82;

    .line 373
    .line 374
    iget-object v2, v0, Lbb5;->G:Ljava/lang/String;

    .line 375
    .line 376
    if-nez v2, :cond_9

    .line 377
    .line 378
    const-string v2, ""

    .line 379
    .line 380
    :cond_9
    move-object v5, v2

    .line 381
    iget-object v2, v14, Lud5;->f:Lb34;

    .line 382
    .line 383
    invoke-interface {v2}, Lok6;->getValue()Ljava/lang/Object;

    .line 384
    .line 385
    .line 386
    move-result-object v2

    .line 387
    check-cast v2, Ljava/lang/Boolean;

    .line 388
    .line 389
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 390
    .line 391
    .line 392
    move-result v7

    .line 393
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 394
    .line 395
    .line 396
    move-result v2

    .line 397
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v4

    .line 401
    if-nez v2, :cond_a

    .line 402
    .line 403
    if-ne v4, v1, :cond_b

    .line 404
    .line 405
    :cond_a
    new-instance v4, Lcb5;

    .line 406
    .line 407
    const/4 v2, 0x1

    .line 408
    invoke-direct {v4, v14, v2}, Lcb5;-><init>(Lud5;B)V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v12, v4}, Lla2;->k0(Ljava/lang/Object;)V

    .line 412
    .line 413
    .line 414
    :cond_b
    move-object v8, v4

    .line 415
    check-cast v8, Lh92;

    .line 416
    .line 417
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    invoke-virtual {v12, v15}, Lla2;->g(Ljava/lang/Object;)Z

    .line 422
    .line 423
    .line 424
    move-result v4

    .line 425
    or-int/2addr v2, v4

    .line 426
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    move-result-object v4

    .line 430
    if-nez v2, :cond_c

    .line 431
    .line 432
    if-ne v4, v1, :cond_d

    .line 433
    .line 434
    :cond_c
    new-instance v4, Lhb5;

    .line 435
    .line 436
    const/4 v9, 0x0

    .line 437
    invoke-direct {v4, v14, v15, v9}, Lhb5;-><init>(Lud5;Lh92;B)V

    .line 438
    .line 439
    .line 440
    invoke-virtual {v12, v4}, Lla2;->k0(Ljava/lang/Object;)V

    .line 441
    .line 442
    .line 443
    :cond_d
    move-object v9, v4

    .line 444
    check-cast v9, Lh92;

    .line 445
    .line 446
    sget-object v2, Lr6;->s:Ln20;

    .line 447
    .line 448
    move-object/from16 v4, p1

    .line 449
    .line 450
    move-object/from16 v6, v32

    .line 451
    .line 452
    invoke-interface {v4, v6, v2}, Lrc0;->a(Lmz3;Le8;)Lmz3;

    .line 453
    .line 454
    .line 455
    move-result-object v11

    .line 456
    const/4 v13, 0x0

    .line 457
    iget-boolean v2, v0, Lbb5;->C:Z

    .line 458
    .line 459
    iget-boolean v4, v0, Lbb5;->F:Z

    .line 460
    .line 461
    iget-object v6, v0, Lbb5;->H:Ljava/util/List;

    .line 462
    .line 463
    move/from16 v10, v17

    .line 464
    .line 465
    invoke-static/range {v2 .. v13}, Llc3;->j(ZLw82;ZLjava/lang/String;Ljava/util/List;ZLh92;Lh92;FLmz3;Lla2;I)V

    .line 466
    .line 467
    .line 468
    if-eqz v26, :cond_1f

    .line 469
    .line 470
    invoke-interface/range {v27 .. v27}, Lok6;->getValue()Ljava/lang/Object;

    .line 471
    .line 472
    .line 473
    move-result-object v2

    .line 474
    check-cast v2, Ljava/lang/String;

    .line 475
    .line 476
    if-eqz v2, :cond_1f

    .line 477
    .line 478
    const v2, -0x1b2c21bd

    .line 479
    .line 480
    .line 481
    invoke-virtual {v12, v2}, Lla2;->b0(I)V

    .line 482
    .line 483
    .line 484
    iget-object v0, v0, Lbb5;->I:Ljava/util/List;

    .line 485
    .line 486
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 487
    .line 488
    .line 489
    move-result-object v0

    .line 490
    :cond_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 491
    .line 492
    .line 493
    move-result v2

    .line 494
    if-eqz v2, :cond_f

    .line 495
    .line 496
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 497
    .line 498
    .line 499
    move-result-object v4

    .line 500
    move-object v2, v4

    .line 501
    check-cast v2, Ljd5;

    .line 502
    .line 503
    iget-object v2, v2, Ljd5;->a:Ljava/lang/String;

    .line 504
    .line 505
    invoke-interface/range {v27 .. v27}, Lok6;->getValue()Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v3

    .line 509
    check-cast v3, Ljava/lang/String;

    .line 510
    .line 511
    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 512
    .line 513
    .line 514
    move-result v2

    .line 515
    if-eqz v2, :cond_e

    .line 516
    .line 517
    goto :goto_6

    .line 518
    :cond_f
    move-object/from16 v4, v16

    .line 519
    .line 520
    :goto_6
    check-cast v4, Ljd5;

    .line 521
    .line 522
    if-nez v4, :cond_10

    .line 523
    .line 524
    invoke-interface/range {v27 .. v27}, Lok6;->getValue()Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v0

    .line 528
    check-cast v0, Ljava/lang/String;

    .line 529
    .line 530
    move-object/from16 v15, v29

    .line 531
    .line 532
    invoke-interface {v15, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 533
    .line 534
    .line 535
    move-result-object v0

    .line 536
    move-object v4, v0

    .line 537
    check-cast v4, Ljd5;

    .line 538
    .line 539
    :goto_7
    move-object v2, v4

    .line 540
    goto :goto_8

    .line 541
    :cond_10
    move-object/from16 v15, v29

    .line 542
    .line 543
    goto :goto_7

    .line 544
    :goto_8
    if-eqz v2, :cond_1e

    .line 545
    .line 546
    const v0, -0x1b253243

    .line 547
    .line 548
    .line 549
    invoke-virtual {v12, v0}, Lla2;->b0(I)V

    .line 550
    .line 551
    .line 552
    invoke-virtual {v14}, Lud5;->l()Ln85;

    .line 553
    .line 554
    .line 555
    move-result-object v4

    .line 556
    invoke-virtual {v14}, Lud5;->f()Z

    .line 557
    .line 558
    .line 559
    move-result v5

    .line 560
    invoke-virtual {v14}, Lud5;->j()Lxc5;

    .line 561
    .line 562
    .line 563
    move-result-object v6

    .line 564
    invoke-virtual {v14}, Lud5;->m()Lbd5;

    .line 565
    .line 566
    .line 567
    move-result-object v7

    .line 568
    invoke-virtual {v14}, Lud5;->i()Ljava/util/Map;

    .line 569
    .line 570
    .line 571
    move-result-object v10

    .line 572
    invoke-virtual {v14}, Lud5;->a()Ljava/util/Set;

    .line 573
    .line 574
    .line 575
    move-result-object v11

    .line 576
    iget-object v0, v14, Lud5;->y:Lb34;

    .line 577
    .line 578
    invoke-interface {v0}, Lok6;->getValue()Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v0

    .line 582
    check-cast v0, Ljava/util/Map;

    .line 583
    .line 584
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 585
    .line 586
    .line 587
    move-result v3

    .line 588
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 589
    .line 590
    .line 591
    move-result-object v8

    .line 592
    if-nez v3, :cond_11

    .line 593
    .line 594
    if-ne v8, v1, :cond_12

    .line 595
    .line 596
    :cond_11
    new-instance v16, Li62;

    .line 597
    .line 598
    const/16 v22, 0x0

    .line 599
    .line 600
    const/16 v23, 0x12

    .line 601
    .line 602
    const/16 v17, 0x2

    .line 603
    .line 604
    const-class v19, Lud5;

    .line 605
    .line 606
    const-string v20, "testProvider"

    .line 607
    .line 608
    const-string v21, "testProvider(Ljava/lang/String;Ljava/util/List;)V"

    .line 609
    .line 610
    move-object/from16 v18, v14

    .line 611
    .line 612
    invoke-direct/range {v16 .. v23}, Li62;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 613
    .line 614
    .line 615
    move-object/from16 v8, v16

    .line 616
    .line 617
    invoke-virtual {v12, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 618
    .line 619
    .line 620
    :cond_12
    check-cast v8, Ln53;

    .line 621
    .line 622
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 623
    .line 624
    .line 625
    move-result v3

    .line 626
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 627
    .line 628
    .line 629
    move-result-object v9

    .line 630
    if-nez v3, :cond_13

    .line 631
    .line 632
    if-ne v9, v1, :cond_14

    .line 633
    .line 634
    :cond_13
    new-instance v9, Lcb5;

    .line 635
    .line 636
    const/4 v3, 0x2

    .line 637
    invoke-direct {v9, v14, v3}, Lcb5;-><init>(Lud5;B)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {v12, v9}, Lla2;->k0(Ljava/lang/Object;)V

    .line 641
    .line 642
    .line 643
    :cond_14
    check-cast v9, Lh92;

    .line 644
    .line 645
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 646
    .line 647
    .line 648
    move-result v3

    .line 649
    invoke-virtual {v12, v2}, Lla2;->i(Ljava/lang/Object;)Z

    .line 650
    .line 651
    .line 652
    move-result v13

    .line 653
    or-int/2addr v3, v13

    .line 654
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 655
    .line 656
    .line 657
    move-result-object v13

    .line 658
    if-nez v3, :cond_15

    .line 659
    .line 660
    if-ne v13, v1, :cond_16

    .line 661
    .line 662
    :cond_15
    new-instance v13, Lib5;

    .line 663
    .line 664
    const/4 v3, 0x0

    .line 665
    invoke-direct {v13, v14, v2, v3}, Lib5;-><init>(Lud5;Ljd5;B)V

    .line 666
    .line 667
    .line 668
    invoke-virtual {v12, v13}, Lla2;->k0(Ljava/lang/Object;)V

    .line 669
    .line 670
    .line 671
    :cond_16
    check-cast v13, Lh92;

    .line 672
    .line 673
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 674
    .line 675
    .line 676
    move-result v3

    .line 677
    move-object/from16 p0, v0

    .line 678
    .line 679
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    if-nez v3, :cond_17

    .line 684
    .line 685
    if-ne v0, v1, :cond_18

    .line 686
    .line 687
    :cond_17
    new-instance v0, Lcb5;

    .line 688
    .line 689
    const/4 v3, 0x3

    .line 690
    invoke-direct {v0, v14, v3}, Lcb5;-><init>(Lud5;B)V

    .line 691
    .line 692
    .line 693
    invoke-virtual {v12, v0}, Lla2;->k0(Ljava/lang/Object;)V

    .line 694
    .line 695
    .line 696
    :cond_18
    move-object/from16 v16, v0

    .line 697
    .line 698
    check-cast v16, Lh92;

    .line 699
    .line 700
    move-object/from16 v17, v8

    .line 701
    .line 702
    check-cast v17, Ll92;

    .line 703
    .line 704
    invoke-virtual {v12, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 705
    .line 706
    .line 707
    move-result v0

    .line 708
    invoke-virtual {v12, v2}, Lla2;->i(Ljava/lang/Object;)Z

    .line 709
    .line 710
    .line 711
    move-result v3

    .line 712
    or-int/2addr v0, v3

    .line 713
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 714
    .line 715
    .line 716
    move-result-object v3

    .line 717
    if-nez v0, :cond_19

    .line 718
    .line 719
    if-ne v3, v1, :cond_1a

    .line 720
    .line 721
    :cond_19
    new-instance v3, Ljb5;

    .line 722
    .line 723
    const/4 v0, 0x0

    .line 724
    invoke-direct {v3, v14, v2, v0}, Ljb5;-><init>(Lud5;Ljd5;B)V

    .line 725
    .line 726
    .line 727
    invoke-virtual {v12, v3}, Lla2;->k0(Ljava/lang/Object;)V

    .line 728
    .line 729
    .line 730
    :cond_1a
    move-object/from16 v18, v3

    .line 731
    .line 732
    check-cast v18, Lw82;

    .line 733
    .line 734
    move-object/from16 v0, v27

    .line 735
    .line 736
    invoke-virtual {v12, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 737
    .line 738
    .line 739
    move-result v3

    .line 740
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 741
    .line 742
    .line 743
    move-result-object v8

    .line 744
    if-nez v3, :cond_1b

    .line 745
    .line 746
    if-eq v8, v1, :cond_1b

    .line 747
    .line 748
    const/4 v3, 0x5

    .line 749
    goto :goto_9

    .line 750
    :cond_1b
    new-instance v8, Ll85;

    .line 751
    .line 752
    const/4 v3, 0x5

    .line 753
    invoke-direct {v8, v0, v3}, Ll85;-><init>(Lb34;B)V

    .line 754
    .line 755
    .line 756
    invoke-virtual {v12, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 757
    .line 758
    .line 759
    :goto_9
    move-object/from16 v19, v8

    .line 760
    .line 761
    check-cast v19, Lw82;

    .line 762
    .line 763
    invoke-virtual {v12, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 764
    .line 765
    .line 766
    move-result v8

    .line 767
    invoke-virtual {v12}, Lla2;->N()Ljava/lang/Object;

    .line 768
    .line 769
    .line 770
    move-result-object v14

    .line 771
    if-nez v8, :cond_1c

    .line 772
    .line 773
    if-ne v14, v1, :cond_1d

    .line 774
    .line 775
    :cond_1c
    new-instance v14, Lk85;

    .line 776
    .line 777
    invoke-direct {v14, v0, v3}, Lk85;-><init>(Lb34;B)V

    .line 778
    .line 779
    .line 780
    invoke-virtual {v12, v14}, Lla2;->k0(Ljava/lang/Object;)V

    .line 781
    .line 782
    .line 783
    :cond_1d
    move-object/from16 v20, v14

    .line 784
    .line 785
    check-cast v20, Lh92;

    .line 786
    .line 787
    const/16 v22, 0x0

    .line 788
    .line 789
    const/16 v23, 0x0

    .line 790
    .line 791
    move-object v14, v9

    .line 792
    move-object/from16 v21, v12

    .line 793
    .line 794
    move-object v8, v15

    .line 795
    move-object/from16 v9, v24

    .line 796
    .line 797
    move/from16 v3, v28

    .line 798
    .line 799
    move-object/from16 v12, p0

    .line 800
    .line 801
    move-object v15, v13

    .line 802
    move-object/from16 v13, v25

    .line 803
    .line 804
    invoke-static/range {v2 .. v23}, Lcc3;->h(Ljd5;ILn85;ZLxc5;Lbd5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Set;Lh92;Lh92;Lh92;Ll92;Lw82;Lw82;Lh92;Lla2;II)V

    .line 805
    .line 806
    .line 807
    move-object/from16 v12, v21

    .line 808
    .line 809
    const/4 v9, 0x0

    .line 810
    invoke-virtual {v12, v9}, Lla2;->r(Z)V

    .line 811
    .line 812
    .line 813
    goto :goto_a

    .line 814
    :cond_1e
    const/4 v9, 0x0

    .line 815
    const v0, -0x1b11af63

    .line 816
    .line 817
    .line 818
    invoke-virtual {v12, v0}, Lla2;->b0(I)V

    .line 819
    .line 820
    .line 821
    invoke-virtual {v12, v9}, Lla2;->r(Z)V

    .line 822
    .line 823
    .line 824
    :goto_a
    invoke-virtual {v12, v9}, Lla2;->r(Z)V

    .line 825
    .line 826
    .line 827
    goto :goto_b

    .line 828
    :cond_1f
    const/4 v9, 0x0

    .line 829
    const v0, -0x1b117923

    .line 830
    .line 831
    .line 832
    invoke-virtual {v12, v0}, Lla2;->b0(I)V

    .line 833
    .line 834
    .line 835
    invoke-virtual {v12, v9}, Lla2;->r(Z)V

    .line 836
    .line 837
    .line 838
    goto :goto_b

    .line 839
    :cond_20
    invoke-virtual {v12}, Lla2;->V()V

    .line 840
    .line 841
    .line 842
    :goto_b
    sget-object v0, Loc7;->a:Loc7;

    .line 843
    .line 844
    return-object v0
.end method
