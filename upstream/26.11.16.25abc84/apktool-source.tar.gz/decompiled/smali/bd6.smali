.class public final synthetic Lbd6;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Z

.field public final synthetic l:Lw82;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Z

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;

.field public final synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;

.field public final synthetic t:Lt92;

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc61;ZLb34;Lb34;Lb34;Lb34;Lb34;Lb34;Lw82;ZLh92;Lh41;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lbd6;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lbd6;->j:Ljava/lang/Object;

    .line 8
    .line 9
    iput-boolean p2, p0, Lbd6;->k:Z

    .line 10
    .line 11
    iput-object p3, p0, Lbd6;->m:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lbd6;->o:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lbd6;->p:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lbd6;->q:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p7, p0, Lbd6;->r:Ljava/lang/Object;

    .line 20
    .line 21
    iput-object p8, p0, Lbd6;->s:Ljava/lang/Object;

    .line 22
    .line 23
    iput-object p9, p0, Lbd6;->l:Lw82;

    .line 24
    .line 25
    iput-boolean p10, p0, Lbd6;->n:Z

    .line 26
    .line 27
    iput-object p11, p0, Lbd6;->t:Lt92;

    .line 28
    .line 29
    iput-object p12, p0, Lbd6;->u:Ljava/lang/Object;

    .line 30
    .line 31
    return-void
.end method

.method public synthetic constructor <init>(Lmd6;ZLw82;Lw82;ZLw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;IB)V
    .locals 0

    .line 32
    iput-byte p14, p0, Lbd6;->i:B

    iput-object p1, p0, Lbd6;->j:Ljava/lang/Object;

    iput-boolean p2, p0, Lbd6;->k:Z

    iput-object p3, p0, Lbd6;->l:Lw82;

    iput-object p4, p0, Lbd6;->m:Ljava/lang/Object;

    iput-boolean p5, p0, Lbd6;->n:Z

    iput-object p6, p0, Lbd6;->o:Ljava/lang/Object;

    iput-object p7, p0, Lbd6;->p:Ljava/lang/Object;

    iput-object p8, p0, Lbd6;->q:Ljava/lang/Object;

    iput-object p9, p0, Lbd6;->r:Ljava/lang/Object;

    iput-object p10, p0, Lbd6;->s:Ljava/lang/Object;

    iput-object p11, p0, Lbd6;->t:Lt92;

    iput-object p12, p0, Lbd6;->u:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbd6;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, v0, Lbd6;->u:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v5, v0, Lbd6;->t:Lt92;

    .line 11
    .line 12
    iget-object v6, v0, Lbd6;->s:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v7, v0, Lbd6;->r:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object v8, v0, Lbd6;->q:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v9, v0, Lbd6;->p:Ljava/lang/Object;

    .line 19
    .line 20
    iget-object v10, v0, Lbd6;->o:Ljava/lang/Object;

    .line 21
    .line 22
    iget-object v11, v0, Lbd6;->m:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v12, v0, Lbd6;->j:Ljava/lang/Object;

    .line 25
    .line 26
    packed-switch v1, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    move-object v14, v12

    .line 30
    check-cast v14, Lc61;

    .line 31
    .line 32
    move-object/from16 v16, v11

    .line 33
    .line 34
    check-cast v16, Lb34;

    .line 35
    .line 36
    move-object/from16 v17, v10

    .line 37
    .line 38
    check-cast v17, Lb34;

    .line 39
    .line 40
    move-object/from16 v18, v9

    .line 41
    .line 42
    check-cast v18, Lb34;

    .line 43
    .line 44
    move-object/from16 v19, v8

    .line 45
    .line 46
    check-cast v19, Lb34;

    .line 47
    .line 48
    move-object/from16 v20, v7

    .line 49
    .line 50
    check-cast v20, Lb34;

    .line 51
    .line 52
    move-object/from16 v21, v6

    .line 53
    .line 54
    check-cast v21, Lb34;

    .line 55
    .line 56
    check-cast v5, Lh92;

    .line 57
    .line 58
    check-cast v4, Lh41;

    .line 59
    .line 60
    move-object/from16 v1, p1

    .line 61
    .line 62
    check-cast v1, Lla2;

    .line 63
    .line 64
    move-object/from16 v6, p2

    .line 65
    .line 66
    check-cast v6, Ljava/lang/Integer;

    .line 67
    .line 68
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    and-int/lit8 v7, v6, 0x3

    .line 73
    .line 74
    const/4 v8, 0x2

    .line 75
    if-eq v7, v8, :cond_0

    .line 76
    .line 77
    move v7, v3

    .line 78
    goto :goto_0

    .line 79
    :cond_0
    const/4 v7, 0x0

    .line 80
    :goto_0
    and-int/2addr v6, v3

    .line 81
    invoke-virtual {v1, v6, v7}, Lla2;->S(IZ)Z

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    if-eqz v3, :cond_1

    .line 86
    .line 87
    new-instance v13, Lug0;

    .line 88
    .line 89
    iget-boolean v15, v0, Lbd6;->k:Z

    .line 90
    .line 91
    invoke-direct/range {v13 .. v21}, Lug0;-><init>(Lc61;ZLb34;Lb34;Lb34;Lb34;Lb34;Lb34;)V

    .line 92
    .line 93
    .line 94
    const v3, 0x4ec60831    # 1.6612128E9f

    .line 95
    .line 96
    .line 97
    invoke-static {v3, v13, v1}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 98
    .line 99
    .line 100
    move-result-object v26

    .line 101
    new-instance v3, Lah0;

    .line 102
    .line 103
    iget-object v6, v0, Lbd6;->l:Lw82;

    .line 104
    .line 105
    iget-boolean v0, v0, Lbd6;->n:Z

    .line 106
    .line 107
    invoke-direct {v3, v6, v0, v5, v4}, Lah0;-><init>(Lw82;ZLh92;Lh41;)V

    .line 108
    .line 109
    .line 110
    const v0, -0x7d6ccf9e

    .line 111
    .line 112
    .line 113
    invoke-static {v0, v3, v1}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 114
    .line 115
    .line 116
    move-result-object v27

    .line 117
    const v29, 0x36000

    .line 118
    .line 119
    .line 120
    const/16 v30, 0xf

    .line 121
    .line 122
    const/16 v22, 0x0

    .line 123
    .line 124
    const/16 v23, 0x0

    .line 125
    .line 126
    const/16 v24, 0x0

    .line 127
    .line 128
    const/16 v25, 0x0

    .line 129
    .line 130
    move-object/from16 v28, v1

    .line 131
    .line 132
    invoke-static/range {v22 .. v30}, Llc3;->d(Lmz3;FLrv;Lx26;Lyz0;Lyz0;Lla2;II)V

    .line 133
    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_1
    move-object/from16 v28, v1

    .line 137
    .line 138
    invoke-virtual/range {v28 .. v28}, Lla2;->V()V

    .line 139
    .line 140
    .line 141
    :goto_1
    return-object v2

    .line 142
    :pswitch_0
    check-cast v12, Lmd6;

    .line 143
    .line 144
    check-cast v11, Lw82;

    .line 145
    .line 146
    check-cast v10, Lw82;

    .line 147
    .line 148
    check-cast v9, Lw82;

    .line 149
    .line 150
    check-cast v8, Lw82;

    .line 151
    .line 152
    check-cast v7, Lw82;

    .line 153
    .line 154
    check-cast v6, Lw82;

    .line 155
    .line 156
    move-object v13, v5

    .line 157
    check-cast v13, Lw82;

    .line 158
    .line 159
    move-object v14, v4

    .line 160
    check-cast v14, Lw82;

    .line 161
    .line 162
    move-object/from16 v15, p1

    .line 163
    .line 164
    check-cast v15, Lla2;

    .line 165
    .line 166
    move-object/from16 v1, p2

    .line 167
    .line 168
    check-cast v1, Ljava/lang/Integer;

    .line 169
    .line 170
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 171
    .line 172
    .line 173
    invoke-static {v3}, Lt36;->a0(I)I

    .line 174
    .line 175
    .line 176
    move-result v16

    .line 177
    iget-boolean v4, v0, Lbd6;->k:Z

    .line 178
    .line 179
    iget-object v5, v0, Lbd6;->l:Lw82;

    .line 180
    .line 181
    move-object v3, v12

    .line 182
    move-object v12, v6

    .line 183
    move-object v6, v11

    .line 184
    move-object v11, v7

    .line 185
    iget-boolean v7, v0, Lbd6;->n:Z

    .line 186
    .line 187
    move-object/from16 v31, v10

    .line 188
    .line 189
    move-object v10, v8

    .line 190
    move-object/from16 v8, v31

    .line 191
    .line 192
    invoke-static/range {v3 .. v16}, Leb;->q(Lmd6;ZLw82;Lw82;ZLw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lla2;I)V

    .line 193
    .line 194
    .line 195
    return-object v2

    .line 196
    :pswitch_1
    move-object/from16 v17, v12

    .line 197
    .line 198
    check-cast v17, Lmd6;

    .line 199
    .line 200
    move-object/from16 v20, v11

    .line 201
    .line 202
    check-cast v20, Lw82;

    .line 203
    .line 204
    move-object/from16 v22, v10

    .line 205
    .line 206
    check-cast v22, Lw82;

    .line 207
    .line 208
    move-object/from16 v23, v9

    .line 209
    .line 210
    check-cast v23, Lw82;

    .line 211
    .line 212
    move-object/from16 v24, v8

    .line 213
    .line 214
    check-cast v24, Lw82;

    .line 215
    .line 216
    move-object/from16 v25, v7

    .line 217
    .line 218
    check-cast v25, Lw82;

    .line 219
    .line 220
    move-object/from16 v26, v6

    .line 221
    .line 222
    check-cast v26, Lw82;

    .line 223
    .line 224
    move-object/from16 v27, v5

    .line 225
    .line 226
    check-cast v27, Lw82;

    .line 227
    .line 228
    move-object/from16 v28, v4

    .line 229
    .line 230
    check-cast v28, Lw82;

    .line 231
    .line 232
    move-object/from16 v29, p1

    .line 233
    .line 234
    check-cast v29, Lla2;

    .line 235
    .line 236
    move-object/from16 v1, p2

    .line 237
    .line 238
    check-cast v1, Ljava/lang/Integer;

    .line 239
    .line 240
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 241
    .line 242
    .line 243
    invoke-static {v3}, Lt36;->a0(I)I

    .line 244
    .line 245
    .line 246
    move-result v30

    .line 247
    iget-boolean v1, v0, Lbd6;->k:Z

    .line 248
    .line 249
    iget-object v3, v0, Lbd6;->l:Lw82;

    .line 250
    .line 251
    iget-boolean v0, v0, Lbd6;->n:Z

    .line 252
    .line 253
    move/from16 v21, v0

    .line 254
    .line 255
    move/from16 v18, v1

    .line 256
    .line 257
    move-object/from16 v19, v3

    .line 258
    .line 259
    invoke-static/range {v17 .. v30}, Lpn7;->B(Lmd6;ZLw82;Lw82;ZLw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lla2;I)V

    .line 260
    .line 261
    .line 262
    return-object v2

    .line 263
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
