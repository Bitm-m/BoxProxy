.class public final Lai2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:J

.field public final d:F

.field public final e:F

.field public f:Ljava/lang/Long;

.field public g:J

.field public h:J

.field public i:J

.field public j:Z

.field public k:Z


# direct methods
.method public constructor <init>(JJJFF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lai2;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Lai2;->b:J

    .line 7
    .line 8
    iput-wide p5, p0, Lai2;->c:J

    .line 9
    .line 10
    iput p7, p0, Lai2;->d:F

    .line 11
    .line 12
    iput p8, p0, Lai2;->e:F

    .line 13
    .line 14
    const-wide/16 p1, 0x0

    .line 15
    .line 16
    iput-wide p1, p0, Lai2;->g:J

    .line 17
    .line 18
    iput-wide p1, p0, Lai2;->i:J

    .line 19
    .line 20
    return-void
.end method
