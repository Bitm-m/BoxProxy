.class public final Lat5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw82;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lwt5;

.field public final synthetic k:Ljq5;


# direct methods
.method public synthetic constructor <init>(Lwt5;Ljq5;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lat5;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lat5;->j:Lwt5;

    .line 4
    .line 5
    iput-object p2, p0, Lat5;->k:Ljq5;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lat5;->i:B

    .line 2
    .line 3
    sget-object v1, Loc7;->a:Loc7;

    .line 4
    .line 5
    iget-object v2, p0, Lat5;->k:Ljq5;

    .line 6
    .line 7
    iget-object p0, p0, Lat5;->j:Lwt5;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v2}, Lwt5;->m(Ljq5;)V

    .line 13
    .line 14
    .line 15
    return-object v1

    .line 16
    :pswitch_0
    invoke-virtual {p0, v2}, Lwt5;->m(Ljq5;)V

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
