.class public final synthetic Lan6;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/ArrayList;

.field public final synthetic k:Lrh7;

.field public final synthetic l:Lb34;


# direct methods
.method public synthetic constructor <init>(Ljava/util/ArrayList;Lrh7;Lb34;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lan6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lan6;->j:Ljava/util/ArrayList;

    .line 4
    .line 5
    iput-object p2, p0, Lan6;->k:Lrh7;

    .line 6
    .line 7
    iput-object p3, p0, Lan6;->l:Lb34;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lan6;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    sget-object v5, Ljz3;->i:Ljz3;

    .line 8
    .line 9
    const/4 v7, 0x0

    .line 10
    sget-object v8, Ld21;->a:Lq9;

    .line 11
    .line 12
    iget-object v9, v0, Lan6;->l:Lb34;

    .line 13
    .line 14
    iget-object v10, v0, Lan6;->k:Lrh7;

    .line 15
    .line 16
    iget-object v0, v0, Lan6;->j:Ljava/util/ArrayList;

    .line 17
    .line 18
    const/4 v11, 0x2

    .line 19
    const/4 v12, 0x1

    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    move-object/from16 v1, p1

    .line 24
    .line 25
    check-cast v1, Lla2;

    .line 26
    .line 27
    move-object/from16 v13, p2

    .line 28
    .line 29
    check-cast v13, Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v13

    .line 35
    and-int/lit8 v14, v13, 0x3

    .line 36
    .line 37
    if-eq v14, v11, :cond_0

    .line 38
    .line 39
    move v11, v12

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move v11, v7

    .line 42
    :goto_0
    and-int/2addr v13, v12

    .line 43
    invoke-virtual {v1, v13, v11}, Lla2;->S(IZ)Z

    .line 44
    .line 45
    .line 46
    move-result v11

    .line 47
    if-eqz v11, :cond_7

    .line 48
    .line 49
    const v11, -0x1ad7bb12

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1, v11}, Lla2;->b0(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object v11

    .line 59
    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v13

    .line 63
    if-eqz v13, :cond_5

    .line 64
    .line 65
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v13

    .line 69
    check-cast v13, Lyh7;

    .line 70
    .line 71
    new-instance v14, Lji7;

    .line 72
    .line 73
    iget-object v15, v13, Lyh7;->a:Ljava/lang/String;

    .line 74
    .line 75
    iget-object v3, v13, Lyh7;->b:Ljava/lang/String;

    .line 76
    .line 77
    iget-object v4, v13, Lyh7;->c:Ljava/lang/String;

    .line 78
    .line 79
    sget-object v6, Lfv3;->b:Ldv2;

    .line 80
    .line 81
    invoke-direct {v14, v15, v3, v4, v6}, Lji7;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldv2;)V

    .line 82
    .line 83
    .line 84
    iget-object v3, v13, Lyh7;->a:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {v10}, Lrh7;->i()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v4

    .line 90
    invoke-static {v3, v4}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    invoke-virtual {v1, v10}, Lla2;->g(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    invoke-virtual {v1, v13}, Lla2;->i(Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v6

    .line 102
    or-int/2addr v4, v6

    .line 103
    invoke-virtual {v1, v9}, Lla2;->g(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    or-int/2addr v4, v6

    .line 108
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v6

    .line 112
    if-nez v4, :cond_1

    .line 113
    .line 114
    if-ne v6, v8, :cond_2

    .line 115
    .line 116
    :cond_1
    new-instance v6, Lc96;

    .line 117
    .line 118
    const/16 v4, 0xa

    .line 119
    .line 120
    invoke-direct {v6, v10, v13, v9, v4}, Lc96;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v1, v6}, Lla2;->k0(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_2
    move-object v15, v6

    .line 127
    check-cast v15, Lw82;

    .line 128
    .line 129
    invoke-virtual {v1, v10}, Lla2;->g(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v4

    .line 133
    invoke-virtual {v1, v13}, Lla2;->i(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    move-result v6

    .line 137
    or-int/2addr v4, v6

    .line 138
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v6

    .line 142
    if-nez v4, :cond_3

    .line 143
    .line 144
    if-ne v6, v8, :cond_4

    .line 145
    .line 146
    :cond_3
    new-instance v6, Lbi7;

    .line 147
    .line 148
    invoke-direct {v6, v10, v13, v12}, Lbi7;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v1, v6}, Lla2;->k0(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    :cond_4
    move-object/from16 v16, v6

    .line 155
    .line 156
    check-cast v16, Lw82;

    .line 157
    .line 158
    const/16 v20, 0x0

    .line 159
    .line 160
    const/16 v21, 0x30

    .line 161
    .line 162
    const/16 v17, 0x0

    .line 163
    .line 164
    const/16 v18, 0x0

    .line 165
    .line 166
    move-object/from16 v19, v1

    .line 167
    .line 168
    move-object v13, v14

    .line 169
    move v14, v3

    .line 170
    invoke-static/range {v13 .. v21}, Lru6;->e(Lji7;ZLw82;Lw82;Lli7;Lh92;Lla2;II)V

    .line 171
    .line 172
    .line 173
    goto :goto_1

    .line 174
    :cond_5
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-eqz v0, :cond_6

    .line 182
    .line 183
    const v0, -0x40171c76

    .line 184
    .line 185
    .line 186
    invoke-virtual {v1, v0}, Lla2;->b0(I)V

    .line 187
    .line 188
    .line 189
    const v0, 0x7f0f0533

    .line 190
    .line 191
    .line 192
    invoke-static {v0, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object v13

    .line 196
    const/high16 v0, 0x41800000    # 16.0f

    .line 197
    .line 198
    const/high16 v3, 0x41900000    # 18.0f

    .line 199
    .line 200
    invoke-static {v5, v3, v0}, Lif0;->Q(Lmz3;FF)Lmz3;

    .line 201
    .line 202
    .line 203
    move-result-object v14

    .line 204
    sget-object v0, Lbx0;->a:Lps1;

    .line 205
    .line 206
    invoke-virtual {v1, v0}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Lax0;

    .line 211
    .line 212
    invoke-virtual {v0}, Lax0;->n()J

    .line 213
    .line 214
    .line 215
    move-result-wide v15

    .line 216
    const/16 v33, 0x0

    .line 217
    .line 218
    const v34, 0x3fff8

    .line 219
    .line 220
    .line 221
    const-wide/16 v17, 0x0

    .line 222
    .line 223
    const/16 v19, 0x0

    .line 224
    .line 225
    const/16 v20, 0x0

    .line 226
    .line 227
    const-wide/16 v21, 0x0

    .line 228
    .line 229
    const/16 v23, 0x0

    .line 230
    .line 231
    const-wide/16 v24, 0x0

    .line 232
    .line 233
    const/16 v26, 0x0

    .line 234
    .line 235
    const/16 v27, 0x0

    .line 236
    .line 237
    const/16 v28, 0x0

    .line 238
    .line 239
    const/16 v29, 0x0

    .line 240
    .line 241
    const/16 v30, 0x0

    .line 242
    .line 243
    const/16 v32, 0x30

    .line 244
    .line 245
    move-object/from16 v31, v1

    .line 246
    .line 247
    invoke-static/range {v13 .. v34}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 251
    .line 252
    .line 253
    goto :goto_2

    .line 254
    :cond_6
    const v0, -0x401223e3

    .line 255
    .line 256
    .line 257
    invoke-virtual {v1, v0}, Lla2;->b0(I)V

    .line 258
    .line 259
    .line 260
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 261
    .line 262
    .line 263
    goto :goto_2

    .line 264
    :cond_7
    invoke-virtual {v1}, Lla2;->V()V

    .line 265
    .line 266
    .line 267
    :goto_2
    return-object v2

    .line 268
    :pswitch_0
    move-object/from16 v1, p1

    .line 269
    .line 270
    check-cast v1, Lla2;

    .line 271
    .line 272
    move-object/from16 v3, p2

    .line 273
    .line 274
    check-cast v3, Ljava/lang/Integer;

    .line 275
    .line 276
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 277
    .line 278
    .line 279
    move-result v3

    .line 280
    and-int/lit8 v4, v3, 0x3

    .line 281
    .line 282
    if-eq v4, v11, :cond_8

    .line 283
    .line 284
    move v4, v12

    .line 285
    goto :goto_3

    .line 286
    :cond_8
    move v4, v7

    .line 287
    :goto_3
    and-int/2addr v3, v12

    .line 288
    invoke-virtual {v1, v3, v4}, Lla2;->S(IZ)Z

    .line 289
    .line 290
    .line 291
    move-result v3

    .line 292
    if-eqz v3, :cond_f

    .line 293
    .line 294
    const v3, -0x710def55

    .line 295
    .line 296
    .line 297
    invoke-virtual {v1, v3}, Lla2;->b0(I)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    :goto_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 305
    .line 306
    .line 307
    move-result v4

    .line 308
    if-eqz v4, :cond_d

    .line 309
    .line 310
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 311
    .line 312
    .line 313
    move-result-object v4

    .line 314
    check-cast v4, Lum6;

    .line 315
    .line 316
    new-instance v12, Lnn6;

    .line 317
    .line 318
    iget-object v6, v4, Lum6;->a:Ljava/lang/String;

    .line 319
    .line 320
    iget-object v13, v4, Lum6;->b:Ljava/lang/String;

    .line 321
    .line 322
    iget-object v14, v4, Lum6;->c:Ljava/lang/String;

    .line 323
    .line 324
    sget-object v15, Lfv3;->b:Ldv2;

    .line 325
    .line 326
    invoke-direct {v12, v6, v13, v14, v15}, Lnn6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldv2;)V

    .line 327
    .line 328
    .line 329
    iget-object v6, v4, Lum6;->a:Ljava/lang/String;

    .line 330
    .line 331
    invoke-virtual {v10}, Lrh7;->i()Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v13

    .line 335
    invoke-static {v6, v13}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    move-result v13

    .line 339
    invoke-virtual {v1, v10}, Lla2;->g(Ljava/lang/Object;)Z

    .line 340
    .line 341
    .line 342
    move-result v6

    .line 343
    invoke-virtual {v1, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 344
    .line 345
    .line 346
    move-result v14

    .line 347
    or-int/2addr v6, v14

    .line 348
    invoke-virtual {v1, v9}, Lla2;->g(Ljava/lang/Object;)Z

    .line 349
    .line 350
    .line 351
    move-result v14

    .line 352
    or-int/2addr v6, v14

    .line 353
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 354
    .line 355
    .line 356
    move-result-object v14

    .line 357
    if-nez v6, :cond_9

    .line 358
    .line 359
    if-ne v14, v8, :cond_a

    .line 360
    .line 361
    :cond_9
    new-instance v14, Lc96;

    .line 362
    .line 363
    invoke-direct {v14, v10, v4, v9, v11}, Lc96;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 364
    .line 365
    .line 366
    invoke-virtual {v1, v14}, Lla2;->k0(Ljava/lang/Object;)V

    .line 367
    .line 368
    .line 369
    :cond_a
    check-cast v14, Lw82;

    .line 370
    .line 371
    invoke-virtual {v1, v10}, Lla2;->g(Ljava/lang/Object;)Z

    .line 372
    .line 373
    .line 374
    move-result v6

    .line 375
    invoke-virtual {v1, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 376
    .line 377
    .line 378
    move-result v15

    .line 379
    or-int/2addr v6, v15

    .line 380
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    move-result-object v15

    .line 384
    if-nez v6, :cond_b

    .line 385
    .line 386
    if-ne v15, v8, :cond_c

    .line 387
    .line 388
    :cond_b
    new-instance v15, Lb35;

    .line 389
    .line 390
    const/16 v6, 0x12

    .line 391
    .line 392
    invoke-direct {v15, v10, v4, v6}, Lb35;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 393
    .line 394
    .line 395
    invoke-virtual {v1, v15}, Lla2;->k0(Ljava/lang/Object;)V

    .line 396
    .line 397
    .line 398
    :cond_c
    check-cast v15, Lw82;

    .line 399
    .line 400
    const/16 v17, 0x0

    .line 401
    .line 402
    const/16 v18, 0x0

    .line 403
    .line 404
    move-object/from16 v16, v1

    .line 405
    .line 406
    invoke-static/range {v12 .. v18}, Lgq3;->r(Lnn6;ZLw82;Lw82;Lla2;II)V

    .line 407
    .line 408
    .line 409
    goto :goto_4

    .line 410
    :cond_d
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 411
    .line 412
    .line 413
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 414
    .line 415
    .line 416
    move-result v0

    .line 417
    if-eqz v0, :cond_e

    .line 418
    .line 419
    const v0, 0x4f589ab0

    .line 420
    .line 421
    .line 422
    invoke-virtual {v1, v0}, Lla2;->b0(I)V

    .line 423
    .line 424
    .line 425
    const v0, 0x7f0f0533

    .line 426
    .line 427
    .line 428
    invoke-static {v0, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object v8

    .line 432
    const/high16 v0, 0x41800000    # 16.0f

    .line 433
    .line 434
    const/high16 v3, 0x41900000    # 18.0f

    .line 435
    .line 436
    invoke-static {v5, v3, v0}, Lif0;->Q(Lmz3;FF)Lmz3;

    .line 437
    .line 438
    .line 439
    move-result-object v9

    .line 440
    sget-object v0, Lbx0;->a:Lps1;

    .line 441
    .line 442
    invoke-virtual {v1, v0}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    check-cast v0, Lax0;

    .line 447
    .line 448
    invoke-virtual {v0}, Lax0;->n()J

    .line 449
    .line 450
    .line 451
    move-result-wide v10

    .line 452
    const/16 v28, 0x0

    .line 453
    .line 454
    const v29, 0x3fff8

    .line 455
    .line 456
    .line 457
    const-wide/16 v12, 0x0

    .line 458
    .line 459
    const/4 v14, 0x0

    .line 460
    const/4 v15, 0x0

    .line 461
    const-wide/16 v16, 0x0

    .line 462
    .line 463
    const/16 v18, 0x0

    .line 464
    .line 465
    const-wide/16 v19, 0x0

    .line 466
    .line 467
    const/16 v21, 0x0

    .line 468
    .line 469
    const/16 v22, 0x0

    .line 470
    .line 471
    const/16 v23, 0x0

    .line 472
    .line 473
    const/16 v24, 0x0

    .line 474
    .line 475
    const/16 v25, 0x0

    .line 476
    .line 477
    const/16 v27, 0x30

    .line 478
    .line 479
    move-object/from16 v26, v1

    .line 480
    .line 481
    invoke-static/range {v8 .. v29}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 485
    .line 486
    .line 487
    goto :goto_5

    .line 488
    :cond_e
    const v0, 0x4f5d9343    # 3.71741568E9f

    .line 489
    .line 490
    .line 491
    invoke-virtual {v1, v0}, Lla2;->b0(I)V

    .line 492
    .line 493
    .line 494
    invoke-virtual {v1, v7}, Lla2;->r(Z)V

    .line 495
    .line 496
    .line 497
    goto :goto_5

    .line 498
    :cond_f
    invoke-virtual {v1}, Lla2;->V()V

    .line 499
    .line 500
    .line 501
    :goto_5
    return-object v2

    .line 502
    nop

    .line 503
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
