.class public final synthetic Lak0;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lwj0;

.field public final synthetic j:Lel0;

.field public final synthetic k:Lmz3;

.field public final synthetic l:Lif7;

.field public final synthetic m:Lof7;

.field public final synthetic n:Lr87;

.field public final synthetic o:Lr87;

.field public final synthetic p:F

.field public final synthetic q:Lyz0;

.field public final synthetic r:I

.field public final synthetic s:S


# direct methods
.method public synthetic constructor <init>(Lwj0;Lel0;Lmz3;Lif7;Lof7;Lr87;Lr87;FLyz0;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lak0;->i:Lwj0;

    .line 5
    .line 6
    iput-object p2, p0, Lak0;->j:Lel0;

    .line 7
    .line 8
    iput-object p3, p0, Lak0;->k:Lmz3;

    .line 9
    .line 10
    iput-object p4, p0, Lak0;->l:Lif7;

    .line 11
    .line 12
    iput-object p5, p0, Lak0;->m:Lof7;

    .line 13
    .line 14
    iput-object p6, p0, Lak0;->n:Lr87;

    .line 15
    .line 16
    iput-object p7, p0, Lak0;->o:Lr87;

    .line 17
    .line 18
    iput p8, p0, Lak0;->p:F

    .line 19
    .line 20
    iput-object p9, p0, Lak0;->q:Lyz0;

    .line 21
    .line 22
    iput p10, p0, Lak0;->r:I

    .line 23
    .line 24
    iput-short p11, p0, Lak0;->s:S

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    move-object v9, p1

    .line 2
    check-cast v9, Lla2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lak0;->r:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lt36;->a0(I)I

    .line 14
    .line 15
    .line 16
    move-result v10

    .line 17
    iget-object v0, p0, Lak0;->i:Lwj0;

    .line 18
    .line 19
    iget-object v1, p0, Lak0;->j:Lel0;

    .line 20
    .line 21
    iget-object v2, p0, Lak0;->k:Lmz3;

    .line 22
    .line 23
    iget-object v3, p0, Lak0;->l:Lif7;

    .line 24
    .line 25
    iget-object v4, p0, Lak0;->m:Lof7;

    .line 26
    .line 27
    iget-object v5, p0, Lak0;->n:Lr87;

    .line 28
    .line 29
    iget-object v6, p0, Lak0;->o:Lr87;

    .line 30
    .line 31
    iget v7, p0, Lak0;->p:F

    .line 32
    .line 33
    iget-object v8, p0, Lak0;->q:Lyz0;

    .line 34
    .line 35
    iget-short v11, p0, Lak0;->s:S

    .line 36
    .line 37
    invoke-static/range {v0 .. v11}, Ljk0;->a(Lwj0;Lel0;Lmz3;Lif7;Lof7;Lr87;Lr87;FLyz0;Lla2;II)V

    .line 38
    .line 39
    .line 40
    sget-object p0, Loc7;->a:Loc7;

    .line 41
    .line 42
    return-object p0
.end method
