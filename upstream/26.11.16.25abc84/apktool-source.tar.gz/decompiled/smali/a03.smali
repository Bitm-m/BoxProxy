.class public abstract La03;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Le06;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, La51;

    .line 2
    .line 3
    const/16 v1, 0x15

    .line 4
    .line 5
    invoke-direct {v0, v1}, La51;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lrr2;

    .line 9
    .line 10
    const/16 v2, 0xa

    .line 11
    .line 12
    invoke-direct {v1, v2}, Lrr2;-><init>(B)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1}, Lho3;->N(Ll92;Lh92;)Le06;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, La03;->a:Le06;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public abstract a()J
.end method
