.class public abstract Lb00;
.super Lic7;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final u:[[I

.field public static final v:Loh0;

.field public static final w:[I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    .line 1
    const v0, 0xa4a1

    .line 2
    .line 3
    .line 4
    const v1, 0xa4f3

    .line 5
    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    filled-new-array {v2, v0, v1}, [I

    .line 9
    .line 10
    .line 11
    move-result-object v3

    .line 12
    const/4 v0, 0x7

    .line 13
    new-array v4, v0, [I

    .line 14
    .line 15
    fill-array-data v4, :array_0

    .line 16
    .line 17
    .line 18
    const/16 v0, 0x9

    .line 19
    .line 20
    new-array v5, v0, [I

    .line 21
    .line 22
    fill-array-data v5, :array_1

    .line 23
    .line 24
    .line 25
    new-array v6, v0, [I

    .line 26
    .line 27
    fill-array-data v6, :array_2

    .line 28
    .line 29
    .line 30
    const v0, 0xa6c1

    .line 31
    .line 32
    .line 33
    const v1, 0xa6d8

    .line 34
    .line 35
    .line 36
    const/4 v7, 0x2

    .line 37
    const v8, 0xa6a1

    .line 38
    .line 39
    .line 40
    const v9, 0xa6b8

    .line 41
    .line 42
    .line 43
    filled-new-array {v7, v8, v9, v0, v1}, [I

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const v1, 0xa7d1

    .line 48
    .line 49
    .line 50
    const v8, 0xa7f1

    .line 51
    .line 52
    .line 53
    const v9, 0xa7a1

    .line 54
    .line 55
    .line 56
    const v10, 0xa7c1

    .line 57
    .line 58
    .line 59
    filled-new-array {v7, v9, v10, v1, v8}, [I

    .line 60
    .line 61
    .line 62
    move-result-object v8

    .line 63
    move-object v7, v0

    .line 64
    filled-new-array/range {v3 .. v8}, [[I

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    sput-object v0, Lb00;->u:[[I

    .line 69
    .line 70
    new-instance v0, Loh0;

    .line 71
    .line 72
    invoke-direct {v0, v2}, Loh0;-><init>(B)V

    .line 73
    .line 74
    .line 75
    sput-object v0, Lb00;->v:Loh0;

    .line 76
    .line 77
    const-string v7, "Greek"

    .line 78
    .line 79
    const-string v8, "Cyrillic"

    .line 80
    .line 81
    const-string v3, "Hiragana"

    .line 82
    .line 83
    const-string v4, "Katakana"

    .line 84
    .line 85
    const-string v5, "Han"

    .line 86
    .line 87
    const-string v6, "Latin"

    .line 88
    .line 89
    filled-new-array/range {v3 .. v8}, [Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    const/4 v1, 0x0

    .line 94
    :goto_0
    const/4 v2, 0x6

    .line 95
    if-ge v1, v2, :cond_0

    .line 96
    .line 97
    sget-object v2, Lb00;->v:Loh0;

    .line 98
    .line 99
    aget-object v3, v0, v1

    .line 100
    .line 101
    invoke-virtual {v3}, Ljava/lang/String;->getBytes()[B

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    add-int/lit8 v4, v1, 0x1

    .line 106
    .line 107
    add-int/lit8 v1, v1, 0xf

    .line 108
    .line 109
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-virtual {v2, v3, v1}, Loh0;->h([BLjava/lang/Integer;)V

    .line 114
    .line 115
    .line 116
    move v1, v4

    .line 117
    goto :goto_0

    .line 118
    :cond_0
    const/16 v0, 0x100

    .line 119
    .line 120
    new-array v0, v0, [I

    .line 121
    .line 122
    fill-array-data v0, :array_3

    .line 123
    .line 124
    .line 125
    sput-object v0, Lb00;->w:[I

    .line 126
    .line 127
    return-void

    .line 128
    nop

    .line 129
    :array_0
    .array-data 4
        0x3
        0x8ea6
        0x8eaf
        0x8eb1
        0x8edd
        0xa5a1
        0xa5f6
    .end array-data

    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    :array_1
    .array-data 4
        0x4
        0xa1b8
        0xa1b8
        0xb0a1
        0xcfd3
        0xd0a1
        0xf4a6
        0x8fb0a1
        0x8fedf3
    .end array-data

    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    :array_2
    .array-data 4
        0x4
        0x41
        0x5a
        0x61
        0x7a
        0xa3c1
        0xa3da
        0xa3e1
        0xa3fa
    .end array-data

    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    :array_3
    .array-data 4
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x2
        0x3
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x2
        0x1
    .end array-data
.end method


# virtual methods
.method public final a(II[B)I
    .locals 3

    .line 1
    const/high16 v0, 0xff0000

    .line 2
    .line 3
    and-int/2addr v0, p1

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    add-int/lit8 v0, p2, 0x1

    .line 7
    .line 8
    shr-int/lit8 v1, p1, 0x10

    .line 9
    .line 10
    and-int/lit16 v1, v1, 0xff

    .line 11
    .line 12
    int-to-byte v1, v1

    .line 13
    aput-byte v1, p3, p2

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move v0, p2

    .line 17
    :goto_0
    const v1, 0xff00

    .line 18
    .line 19
    .line 20
    and-int/2addr v1, p1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    add-int/lit8 v1, v0, 0x1

    .line 24
    .line 25
    shr-int/lit8 v2, p1, 0x8

    .line 26
    .line 27
    and-int/lit16 v2, v2, 0xff

    .line 28
    .line 29
    int-to-byte v2, v2

    .line 30
    aput-byte v2, p3, v0

    .line 31
    .line 32
    move v0, v1

    .line 33
    :cond_1
    add-int/lit8 v1, v0, 0x1

    .line 34
    .line 35
    and-int/lit16 p1, p1, 0xff

    .line 36
    .line 37
    int-to-byte p1, p1

    .line 38
    aput-byte p1, p3, v0

    .line 39
    .line 40
    invoke-virtual {p0, p2, v1, p3}, Lc3;->j(II[B)I

    .line 41
    .line 42
    .line 43
    move-result p0

    .line 44
    sub-int/2addr v1, p2

    .line 45
    if-eq p0, v1, :cond_2

    .line 46
    .line 47
    const/16 p0, -0x190

    .line 48
    .line 49
    return p0

    .line 50
    :cond_2
    return v1
.end method

.method public final b(I)I
    .locals 1

    .line 1
    invoke-static {p1}, Lc3;->c(I)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    const p0, 0xffffff

    .line 10
    .line 11
    .line 12
    if-le p1, p0, :cond_1

    .line 13
    .line 14
    const/16 p0, -0x191

    .line 15
    .line 16
    return p0

    .line 17
    :cond_1
    const p0, -0x7f7f80

    .line 18
    .line 19
    .line 20
    and-int/2addr p0, p1

    .line 21
    const v0, 0x808080

    .line 22
    .line 23
    .line 24
    if-ne p0, v0, :cond_2

    .line 25
    .line 26
    const/4 p0, 0x3

    .line 27
    return p0

    .line 28
    :cond_2
    and-int/lit16 p1, p1, -0x7f80

    .line 29
    .line 30
    const p0, 0x8080

    .line 31
    .line 32
    .line 33
    if-ne p1, p0, :cond_3

    .line 34
    .line 35
    const/4 p0, 0x2

    .line 36
    return p0

    .line 37
    :cond_3
    const/16 p0, -0x190

    .line 38
    .line 39
    return p0
.end method

.method public final d(II)Z
    .locals 2

    .line 1
    const/16 v0, 0xe

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-gt p2, v0, :cond_2

    .line 5
    .line 6
    const/16 v0, 0x80

    .line 7
    .line 8
    if-ge p1, v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lc3;->e(II)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0

    .line 15
    :cond_0
    invoke-static {p2}, Lc3;->h(I)Z

    .line 16
    .line 17
    .line 18
    move-result p2

    .line 19
    if-eqz p2, :cond_1

    .line 20
    .line 21
    invoke-virtual {p0, p1}, Lb00;->b(I)I

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    const/4 p1, 0x1

    .line 26
    if-le p0, p1, :cond_1

    .line 27
    .line 28
    return p1

    .line 29
    :cond_1
    return v1

    .line 30
    :cond_2
    add-int/lit8 p2, p2, -0xf

    .line 31
    .line 32
    const/4 p0, 0x6

    .line 33
    if-ge p2, p0, :cond_3

    .line 34
    .line 35
    sget-object p0, Lb00;->u:[[I

    .line 36
    .line 37
    aget-object p0, p0, p2

    .line 38
    .line 39
    invoke-static {v1, p1, p0}, Ldj;->U(II[I)Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    return p0

    .line 44
    :cond_3
    new-instance p0, Lmx1;

    .line 45
    .line 46
    const-string p1, "undefined type (bug)"

    .line 47
    .line 48
    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p0
.end method
