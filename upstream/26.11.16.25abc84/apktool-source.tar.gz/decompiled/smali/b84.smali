.class public final synthetic Lb84;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lv74;

.field public final synthetic j:Z

.field public final synthetic k:Lw82;

.field public final synthetic l:Ldv2;

.field public final synthetic m:Ljava/lang/String;

.field public final synthetic n:J

.field public final synthetic o:Lt72;

.field public final synthetic p:Lpv0;

.field public final synthetic q:Lb24;

.field public final synthetic r:Lmz3;

.field public final synthetic s:I

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lv74;ZLw82;Ldv2;Ljava/lang/String;JLt72;Lpv0;Lb24;Lmz3;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb84;->i:Lv74;

    .line 5
    .line 6
    iput-boolean p2, p0, Lb84;->j:Z

    .line 7
    .line 8
    iput-object p3, p0, Lb84;->k:Lw82;

    .line 9
    .line 10
    iput-object p4, p0, Lb84;->l:Ldv2;

    .line 11
    .line 12
    iput-object p5, p0, Lb84;->m:Ljava/lang/String;

    .line 13
    .line 14
    iput-wide p6, p0, Lb84;->n:J

    .line 15
    .line 16
    iput-object p8, p0, Lb84;->o:Lt72;

    .line 17
    .line 18
    iput-object p9, p0, Lb84;->p:Lpv0;

    .line 19
    .line 20
    iput-object p10, p0, Lb84;->q:Lb24;

    .line 21
    .line 22
    iput-object p11, p0, Lb84;->r:Lmz3;

    .line 23
    .line 24
    iput p12, p0, Lb84;->s:I

    .line 25
    .line 26
    iput p13, p0, Lb84;->t:I

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    move-object v11, p1

    .line 2
    check-cast v11, Lla2;

    .line 3
    .line 4
    move-object/from16 v0, p2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    iget v0, p0, Lb84;->s:I

    .line 12
    .line 13
    or-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    invoke-static {v0}, Lt36;->a0(I)I

    .line 16
    .line 17
    .line 18
    move-result v12

    .line 19
    iget v0, p0, Lb84;->t:I

    .line 20
    .line 21
    invoke-static {v0}, Lt36;->a0(I)I

    .line 22
    .line 23
    .line 24
    move-result v13

    .line 25
    iget-object v0, p0, Lb84;->i:Lv74;

    .line 26
    .line 27
    iget-boolean v1, p0, Lb84;->j:Z

    .line 28
    .line 29
    iget-object v2, p0, Lb84;->k:Lw82;

    .line 30
    .line 31
    iget-object v3, p0, Lb84;->l:Ldv2;

    .line 32
    .line 33
    iget-object v4, p0, Lb84;->m:Ljava/lang/String;

    .line 34
    .line 35
    iget-wide v5, p0, Lb84;->n:J

    .line 36
    .line 37
    iget-object v7, p0, Lb84;->o:Lt72;

    .line 38
    .line 39
    iget-object v8, p0, Lb84;->p:Lpv0;

    .line 40
    .line 41
    iget-object v9, p0, Lb84;->q:Lb24;

    .line 42
    .line 43
    iget-object v10, p0, Lb84;->r:Lmz3;

    .line 44
    .line 45
    invoke-static/range {v0 .. v13}, Lh84;->e(Lv74;ZLw82;Ldv2;Ljava/lang/String;JLt72;Lpv0;Lb24;Lmz3;Lla2;II)V

    .line 46
    .line 47
    .line 48
    sget-object p0, Loc7;->a:Loc7;

    .line 49
    .line 50
    return-object p0
.end method
