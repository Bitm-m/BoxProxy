.class public abstract Lam5;
.super La00;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# direct methods
.method public constructor <init>(Lca1;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, La00;-><init>(Lca1;)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    invoke-interface {p1}, Lca1;->getContext()Lyd1;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    sget-object p1, Lxw1;->i:Lxw1;

    .line 11
    .line 12
    if-eq p0, p1, :cond_0

    .line 13
    .line 14
    const-string p0, "Coroutines with restricted suspension must have EmptyCoroutineContext"

    .line 15
    .line 16
    invoke-static {p0}, Lzy1;->h(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    throw p0

    .line 21
    :cond_0
    return-void
.end method


# virtual methods
.method public final getContext()Lyd1;
    .locals 0

    .line 1
    sget-object p0, Lxw1;->i:Lxw1;

    .line 2
    .line 3
    return-object p0
.end method
