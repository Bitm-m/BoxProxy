.class public final synthetic Laf5;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lef5;

.field public final synthetic j:Lfg5;

.field public final synthetic k:Z

.field public final synthetic l:Lmz3;

.field public final synthetic m:F

.field public final synthetic n:Lko5;

.field public final synthetic o:J

.field public final synthetic p:F

.field public final synthetic q:Lyz0;

.field public final synthetic r:I

.field public final synthetic s:B


# direct methods
.method public synthetic constructor <init>(Lef5;Lfg5;ZLmz3;FLko5;JFLyz0;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laf5;->i:Lef5;

    .line 5
    .line 6
    iput-object p2, p0, Laf5;->j:Lfg5;

    .line 7
    .line 8
    iput-boolean p3, p0, Laf5;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Laf5;->l:Lmz3;

    .line 11
    .line 12
    iput p5, p0, Laf5;->m:F

    .line 13
    .line 14
    iput-object p6, p0, Laf5;->n:Lko5;

    .line 15
    .line 16
    iput-wide p7, p0, Laf5;->o:J

    .line 17
    .line 18
    iput p9, p0, Laf5;->p:F

    .line 19
    .line 20
    iput-object p10, p0, Laf5;->q:Lyz0;

    .line 21
    .line 22
    iput p11, p0, Laf5;->r:I

    .line 23
    .line 24
    iput-byte p12, p0, Laf5;->s:B

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    move-object v10, p1

    .line 2
    check-cast v10, Lla2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Laf5;->r:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lt36;->a0(I)I

    .line 14
    .line 15
    .line 16
    move-result v11

    .line 17
    iget-object v0, p0, Laf5;->i:Lef5;

    .line 18
    .line 19
    iget-object v1, p0, Laf5;->j:Lfg5;

    .line 20
    .line 21
    iget-boolean v2, p0, Laf5;->k:Z

    .line 22
    .line 23
    iget-object v3, p0, Laf5;->l:Lmz3;

    .line 24
    .line 25
    iget v4, p0, Laf5;->m:F

    .line 26
    .line 27
    iget-object v5, p0, Laf5;->n:Lko5;

    .line 28
    .line 29
    iget-wide v6, p0, Laf5;->o:J

    .line 30
    .line 31
    iget v8, p0, Laf5;->p:F

    .line 32
    .line 33
    iget-object v9, p0, Laf5;->q:Lyz0;

    .line 34
    .line 35
    iget-byte v12, p0, Laf5;->s:B

    .line 36
    .line 37
    invoke-virtual/range {v0 .. v12}, Lef5;->a(Lfg5;ZLmz3;FLko5;JFLyz0;Lla2;II)V

    .line 38
    .line 39
    .line 40
    sget-object p0, Loc7;->a:Loc7;

    .line 41
    .line 42
    return-object p0
.end method
