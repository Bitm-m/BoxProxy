.class public final synthetic Lad6;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lw82;

.field public final synthetic k:Lw82;

.field public final synthetic l:Lw82;

.field public final synthetic m:Lw82;

.field public final synthetic n:Lw82;

.field public final synthetic o:Lw82;

.field public final synthetic p:Lw82;


# direct methods
.method public synthetic constructor <init>(Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;B)V
    .locals 0

    .line 1
    iput-byte p8, p0, Lad6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lad6;->j:Lw82;

    .line 4
    .line 5
    iput-object p2, p0, Lad6;->k:Lw82;

    .line 6
    .line 7
    iput-object p3, p0, Lad6;->l:Lw82;

    .line 8
    .line 9
    iput-object p4, p0, Lad6;->m:Lw82;

    .line 10
    .line 11
    iput-object p5, p0, Lad6;->n:Lw82;

    .line 12
    .line 13
    iput-object p6, p0, Lad6;->o:Lw82;

    .line 14
    .line 15
    iput-object p7, p0, Lad6;->p:Lw82;

    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lad6;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v5, 0x1

    .line 11
    packed-switch v1, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    move-object/from16 v1, p1

    .line 15
    .line 16
    check-cast v1, Lvx0;

    .line 17
    .line 18
    move-object/from16 v15, p2

    .line 19
    .line 20
    check-cast v15, Lla2;

    .line 21
    .line 22
    move-object/from16 v6, p3

    .line 23
    .line 24
    check-cast v6, Ljava/lang/Integer;

    .line 25
    .line 26
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 27
    .line 28
    .line 29
    move-result v6

    .line 30
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    and-int/lit8 v1, v6, 0x11

    .line 34
    .line 35
    if-eq v1, v3, :cond_0

    .line 36
    .line 37
    move v1, v5

    .line 38
    goto :goto_0

    .line 39
    :cond_0
    move v1, v4

    .line 40
    :goto_0
    and-int/2addr v6, v5

    .line 41
    invoke-virtual {v15, v6, v1}, Lla2;->S(IZ)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_4

    .line 46
    .line 47
    const v1, 0x7f0f048e

    .line 48
    .line 49
    .line 50
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    new-instance v5, Lpv4;

    .line 55
    .line 56
    iget-object v3, v0, Lad6;->j:Lw82;

    .line 57
    .line 58
    invoke-direct {v5, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    const v1, 0x7f0f0490

    .line 62
    .line 63
    .line 64
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    new-instance v6, Lpv4;

    .line 69
    .line 70
    iget-object v3, v0, Lad6;->k:Lw82;

    .line 71
    .line 72
    invoke-direct {v6, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    const v1, 0x7f0f048f

    .line 76
    .line 77
    .line 78
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    new-instance v7, Lpv4;

    .line 83
    .line 84
    iget-object v3, v0, Lad6;->l:Lw82;

    .line 85
    .line 86
    invoke-direct {v7, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    const v1, 0x7f0f00ca

    .line 90
    .line 91
    .line 92
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    new-instance v8, Lpv4;

    .line 97
    .line 98
    iget-object v3, v0, Lad6;->m:Lw82;

    .line 99
    .line 100
    invoke-direct {v8, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    const v1, 0x7f0f041f

    .line 104
    .line 105
    .line 106
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    new-instance v9, Lpv4;

    .line 111
    .line 112
    iget-object v3, v0, Lad6;->n:Lw82;

    .line 113
    .line 114
    invoke-direct {v9, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    const v1, 0x7f0f00b6

    .line 118
    .line 119
    .line 120
    invoke-static {v1, v15}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    new-instance v10, Lpv4;

    .line 125
    .line 126
    iget-object v3, v0, Lad6;->o:Lw82;

    .line 127
    .line 128
    invoke-direct {v10, v1, v3}, Lpv4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    filled-new-array/range {v5 .. v10}, [Lpv4;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-static {v1}, Lkm;->e0([Ljava/lang/Object;)Ljava/util/List;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 140
    .line 141
    .line 142
    move-result-object v3

    .line 143
    move v8, v4

    .line 144
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    .line 146
    .line 147
    move-result v4

    .line 148
    if-eqz v4, :cond_5

    .line 149
    .line 150
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    add-int/lit8 v5, v8, 0x1

    .line 155
    .line 156
    if-ltz v8, :cond_3

    .line 157
    .line 158
    check-cast v4, Lpv4;

    .line 159
    .line 160
    iget-object v6, v4, Lpv4;->i:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v6, Ljava/lang/String;

    .line 163
    .line 164
    iget-object v4, v4, Lpv4;->j:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast v4, Lw82;

    .line 167
    .line 168
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 169
    .line 170
    .line 171
    move-result v9

    .line 172
    new-instance v7, Ltc6;

    .line 173
    .line 174
    const/4 v10, 0x2

    .line 175
    invoke-direct {v7, v6, v10}, Ltc6;-><init>(Ljava/lang/String;B)V

    .line 176
    .line 177
    .line 178
    const v6, 0x436dbd5c

    .line 179
    .line 180
    .line 181
    invoke-static {v6, v7, v15}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 182
    .line 183
    .line 184
    move-result-object v6

    .line 185
    iget-object v7, v0, Lad6;->p:Lw82;

    .line 186
    .line 187
    invoke-virtual {v15, v7}, Lla2;->g(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v10

    .line 191
    invoke-virtual {v15, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v11

    .line 195
    or-int/2addr v10, v11

    .line 196
    invoke-virtual {v15}, Lla2;->N()Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v11

    .line 200
    if-nez v10, :cond_1

    .line 201
    .line 202
    sget-object v10, Ld21;->a:Lq9;

    .line 203
    .line 204
    if-ne v11, v10, :cond_2

    .line 205
    .line 206
    :cond_1
    new-instance v11, Lb35;

    .line 207
    .line 208
    const/16 v10, 0x11

    .line 209
    .line 210
    invoke-direct {v11, v7, v4, v10}, Lb35;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v15, v11}, Lla2;->k0(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_2
    move-object v7, v11

    .line 217
    check-cast v7, Lw82;

    .line 218
    .line 219
    const/16 v16, 0x6

    .line 220
    .line 221
    const/16 v17, 0x3f0

    .line 222
    .line 223
    const/4 v10, 0x0

    .line 224
    const/4 v11, 0x0

    .line 225
    const/4 v12, 0x0

    .line 226
    const/4 v13, 0x0

    .line 227
    const/4 v14, 0x0

    .line 228
    invoke-static/range {v6 .. v17}, Lop3;->a(Lyz0;Lw82;IILmz3;Lyz0;ZLkr3;Lbt4;Lla2;II)V

    .line 229
    .line 230
    .line 231
    move v8, v5

    .line 232
    goto :goto_1

    .line 233
    :cond_3
    invoke-static {}, Lkm;->s0()V

    .line 234
    .line 235
    .line 236
    const/4 v0, 0x0

    .line 237
    throw v0

    .line 238
    :cond_4
    invoke-virtual {v15}, Lla2;->V()V

    .line 239
    .line 240
    .line 241
    :cond_5
    return-object v2

    .line 242
    :pswitch_0
    move-object/from16 v1, p1

    .line 243
    .line 244
    check-cast v1, Lvx0;

    .line 245
    .line 246
    move-object/from16 v13, p2

    .line 247
    .line 248
    check-cast v13, Lla2;

    .line 249
    .line 250
    move-object/from16 v6, p3

    .line 251
    .line 252
    check-cast v6, Ljava/lang/Integer;

    .line 253
    .line 254
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 255
    .line 256
    .line 257
    move-result v6

    .line 258
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 259
    .line 260
    .line 261
    and-int/lit8 v1, v6, 0x11

    .line 262
    .line 263
    if-eq v1, v3, :cond_6

    .line 264
    .line 265
    move v4, v5

    .line 266
    :cond_6
    and-int/2addr v6, v5

    .line 267
    invoke-virtual {v13, v6, v4}, Lla2;->S(IZ)Z

    .line 268
    .line 269
    .line 270
    move-result v1

    .line 271
    if-eqz v1, :cond_7

    .line 272
    .line 273
    new-instance v3, Lad6;

    .line 274
    .line 275
    const/4 v11, 0x1

    .line 276
    iget-object v4, v0, Lad6;->j:Lw82;

    .line 277
    .line 278
    iget-object v5, v0, Lad6;->k:Lw82;

    .line 279
    .line 280
    iget-object v6, v0, Lad6;->l:Lw82;

    .line 281
    .line 282
    iget-object v7, v0, Lad6;->m:Lw82;

    .line 283
    .line 284
    iget-object v8, v0, Lad6;->n:Lw82;

    .line 285
    .line 286
    iget-object v9, v0, Lad6;->o:Lw82;

    .line 287
    .line 288
    iget-object v10, v0, Lad6;->p:Lw82;

    .line 289
    .line 290
    invoke-direct/range {v3 .. v11}, Lad6;-><init>(Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;Lw82;B)V

    .line 291
    .line 292
    .line 293
    const v0, 0x636666ea

    .line 294
    .line 295
    .line 296
    invoke-static {v0, v3, v13}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 297
    .line 298
    .line 299
    move-result-object v12

    .line 300
    const/high16 v14, 0x30000

    .line 301
    .line 302
    const/16 v15, 0x1f

    .line 303
    .line 304
    const/4 v6, 0x0

    .line 305
    const/4 v7, 0x0

    .line 306
    const/4 v8, 0x0

    .line 307
    const/4 v9, 0x0

    .line 308
    const-wide/16 v10, 0x0

    .line 309
    .line 310
    invoke-static/range {v6 .. v15}, Lop3;->c(IILmz3;Ljr3;JLyz0;Lla2;II)V

    .line 311
    .line 312
    .line 313
    goto :goto_2

    .line 314
    :cond_7
    invoke-virtual {v13}, Lla2;->V()V

    .line 315
    .line 316
    .line 317
    :goto_2
    return-object v2

    .line 318
    nop

    .line 319
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
