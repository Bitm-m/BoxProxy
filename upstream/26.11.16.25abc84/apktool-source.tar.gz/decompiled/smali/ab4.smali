.class public final synthetic Lab4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lgc4;

.field public final synthetic k:Lh92;

.field public final synthetic l:Ljc4;

.field public final synthetic m:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lgc4;Lh92;Ljc4;Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lab4;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lab4;->j:Lgc4;

    .line 4
    .line 5
    iput-object p2, p0, Lab4;->k:Lh92;

    .line 6
    .line 7
    iput-object p3, p0, Lab4;->l:Ljc4;

    .line 8
    .line 9
    iput-object p4, p0, Lab4;->m:Ljava/util/List;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-byte v0, p0, Lab4;->i:B

    .line 2
    .line 3
    sget-object v1, Loc7;->a:Loc7;

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x0

    .line 7
    iget-object v4, p0, Lab4;->m:Ljava/util/List;

    .line 8
    .line 9
    iget-object v5, p0, Lab4;->l:Ljc4;

    .line 10
    .line 11
    iget-object v6, p0, Lab4;->k:Lh92;

    .line 12
    .line 13
    iget-object p0, p0, Lab4;->j:Lgc4;

    .line 14
    .line 15
    check-cast p1, Ljava/lang/Boolean;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    xor-int/lit8 p1, p1, 0x1

    .line 22
    .line 23
    packed-switch v0, :pswitch_data_0

    .line 24
    .line 25
    .line 26
    invoke-static {p0, v3, p1, v2}, Lgc4;->b(Lgc4;Ljava/lang/String;ZI)Lgc4;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-static {v5, v4, p0}, Ls36;->Z(Ljc4;Ljava/util/List;Lgc4;)Ljc4;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    invoke-interface {v6, p0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    return-object v1

    .line 38
    :pswitch_0
    invoke-static {p0, v3, p1, v2}, Lgc4;->b(Lgc4;Ljava/lang/String;ZI)Lgc4;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-static {v5, v4, p0}, Ls36;->Z(Ljc4;Ljava/util/List;Lgc4;)Ljc4;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    invoke-interface {v6, p0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    return-object v1

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
