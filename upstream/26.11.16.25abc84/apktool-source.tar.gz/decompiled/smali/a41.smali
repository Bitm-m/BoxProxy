.class public final synthetic La41;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lj41;

.field public final synthetic k:Ll41;


# direct methods
.method public synthetic constructor <init>(Lj41;Ll41;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, La41;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La41;->j:Lj41;

    .line 4
    .line 5
    iput-object p2, p0, La41;->k:Ll41;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La41;->i:B

    .line 4
    .line 5
    sget-object v2, Loc7;->a:Loc7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    iget-object v4, v0, La41;->k:Ll41;

    .line 10
    .line 11
    iget-object v0, v0, La41;->j:Lj41;

    .line 12
    .line 13
    const/4 v5, 0x1

    .line 14
    const/4 v6, 0x0

    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v1, p1

    .line 19
    .line 20
    check-cast v1, Lla3;

    .line 21
    .line 22
    move-object/from16 v7, p2

    .line 23
    .line 24
    check-cast v7, Lla2;

    .line 25
    .line 26
    move-object/from16 v8, p3

    .line 27
    .line 28
    check-cast v8, Ljava/lang/Integer;

    .line 29
    .line 30
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v8

    .line 34
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    and-int/lit8 v1, v8, 0x11

    .line 38
    .line 39
    if-eq v1, v3, :cond_0

    .line 40
    .line 41
    move v1, v5

    .line 42
    goto :goto_0

    .line 43
    :cond_0
    move v1, v6

    .line 44
    :goto_0
    and-int/2addr v8, v5

    .line 45
    invoke-virtual {v7, v8, v1}, Lla2;->S(IZ)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    invoke-static {v7}, Llc3;->t(Lla2;)Llj0;

    .line 52
    .line 53
    .line 54
    move-result-object v10

    .line 55
    new-instance v1, La41;

    .line 56
    .line 57
    invoke-direct {v1, v0, v4, v6}, La41;-><init>(Lj41;Ll41;B)V

    .line 58
    .line 59
    .line 60
    const v0, 0x72f1b5f6

    .line 61
    .line 62
    .line 63
    invoke-static {v0, v1, v7}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 64
    .line 65
    .line 66
    move-result-object v16

    .line 67
    const/16 v18, 0x0

    .line 68
    .line 69
    const/16 v19, 0x3f7

    .line 70
    .line 71
    move-object/from16 v17, v7

    .line 72
    .line 73
    const/4 v7, 0x0

    .line 74
    const/4 v8, 0x0

    .line 75
    const/4 v9, 0x0

    .line 76
    const/4 v11, 0x0

    .line 77
    const/4 v12, 0x0

    .line 78
    const/4 v13, 0x0

    .line 79
    const/4 v14, 0x0

    .line 80
    const/4 v15, 0x0

    .line 81
    invoke-static/range {v7 .. v19}, Lpv3;->a(Lmz3;FLbt4;Llj0;Lh35;ZLw82;Lw82;ZLyz0;Lla2;II)V

    .line 82
    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_1
    move-object/from16 v17, v7

    .line 86
    .line 87
    invoke-virtual/range {v17 .. v17}, Lla2;->V()V

    .line 88
    .line 89
    .line 90
    :goto_1
    return-object v2

    .line 91
    :pswitch_0
    move-object/from16 v1, p1

    .line 92
    .line 93
    check-cast v1, Lvx0;

    .line 94
    .line 95
    move-object/from16 v13, p2

    .line 96
    .line 97
    check-cast v13, Lla2;

    .line 98
    .line 99
    move-object/from16 v7, p3

    .line 100
    .line 101
    check-cast v7, Ljava/lang/Integer;

    .line 102
    .line 103
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 104
    .line 105
    .line 106
    move-result v7

    .line 107
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    and-int/lit8 v1, v7, 0x11

    .line 111
    .line 112
    if-eq v1, v3, :cond_2

    .line 113
    .line 114
    move v1, v5

    .line 115
    goto :goto_2

    .line 116
    :cond_2
    move v1, v6

    .line 117
    :goto_2
    and-int/2addr v7, v5

    .line 118
    invoke-virtual {v13, v7, v1}, Lla2;->S(IZ)Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-eqz v1, :cond_d

    .line 123
    .line 124
    const v1, 0x7f0f010a

    .line 125
    .line 126
    .line 127
    invoke-static {v1, v13}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    iget-object v0, v0, Lj41;->b:Ljava/util/List;

    .line 132
    .line 133
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    const/16 v3, 0x20

    .line 138
    .line 139
    if-ge v1, v3, :cond_3

    .line 140
    .line 141
    move v10, v5

    .line 142
    goto :goto_3

    .line 143
    :cond_3
    move v10, v6

    .line 144
    :goto_3
    invoke-virtual {v13, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    invoke-virtual {v13}, Lla2;->N()Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v8

    .line 152
    sget-object v9, Ld21;->a:Lq9;

    .line 153
    .line 154
    if-nez v1, :cond_4

    .line 155
    .line 156
    if-ne v8, v9, :cond_5

    .line 157
    .line 158
    :cond_4
    new-instance v8, Lx31;

    .line 159
    .line 160
    invoke-direct {v8, v4, v5}, Lx31;-><init>(Ll41;B)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v13, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    :cond_5
    check-cast v8, Lw82;

    .line 167
    .line 168
    const/4 v14, 0x0

    .line 169
    const/16 v15, 0x34

    .line 170
    .line 171
    move-object v1, v9

    .line 172
    const/4 v9, 0x0

    .line 173
    const/4 v11, 0x0

    .line 174
    const/4 v12, 0x0

    .line 175
    invoke-static/range {v7 .. v15}, Lt36;->b(Ljava/lang/String;Lw82;Lmz3;ZLjava/lang/String;Ll92;Lla2;II)V

    .line 176
    .line 177
    .line 178
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 179
    .line 180
    .line 181
    move-result v5

    .line 182
    sget-object v7, Ljz3;->i:Ljz3;

    .line 183
    .line 184
    const/high16 v8, 0x41400000    # 12.0f

    .line 185
    .line 186
    const/high16 v9, 0x41900000    # 18.0f

    .line 187
    .line 188
    if-eqz v5, :cond_6

    .line 189
    .line 190
    const v5, 0x2e2c6d0d

    .line 191
    .line 192
    .line 193
    invoke-virtual {v13, v5}, Lla2;->b0(I)V

    .line 194
    .line 195
    .line 196
    const v5, 0x7f0f010b

    .line 197
    .line 198
    .line 199
    invoke-static {v5, v13}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v5

    .line 203
    move v10, v8

    .line 204
    invoke-static {v7, v9, v10}, Lif0;->Q(Lmz3;FF)Lmz3;

    .line 205
    .line 206
    .line 207
    move-result-object v8

    .line 208
    sget-object v11, Lbx0;->a:Lps1;

    .line 209
    .line 210
    invoke-virtual {v13, v11}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    move-result-object v11

    .line 214
    check-cast v11, Lax0;

    .line 215
    .line 216
    invoke-virtual {v11}, Lax0;->n()J

    .line 217
    .line 218
    .line 219
    move-result-wide v11

    .line 220
    const/16 v27, 0x0

    .line 221
    .line 222
    const v28, 0x3fff8

    .line 223
    .line 224
    .line 225
    move-wide v9, v11

    .line 226
    const-wide/16 v11, 0x0

    .line 227
    .line 228
    move-object/from16 v25, v13

    .line 229
    .line 230
    const/4 v13, 0x0

    .line 231
    const/4 v14, 0x0

    .line 232
    const-wide/16 v15, 0x0

    .line 233
    .line 234
    const/16 v17, 0x0

    .line 235
    .line 236
    const-wide/16 v18, 0x0

    .line 237
    .line 238
    const/16 v20, 0x0

    .line 239
    .line 240
    const/16 v21, 0x0

    .line 241
    .line 242
    const/16 v22, 0x0

    .line 243
    .line 244
    const/16 v23, 0x0

    .line 245
    .line 246
    const/16 v24, 0x0

    .line 247
    .line 248
    const/16 v26, 0x30

    .line 249
    .line 250
    move-object/from16 v31, v7

    .line 251
    .line 252
    move-object v7, v5

    .line 253
    move-object/from16 v5, v31

    .line 254
    .line 255
    invoke-static/range {v7 .. v28}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 256
    .line 257
    .line 258
    move-object/from16 v13, v25

    .line 259
    .line 260
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 261
    .line 262
    .line 263
    goto :goto_4

    .line 264
    :cond_6
    move-object v5, v7

    .line 265
    const v7, 0x2e311a8c

    .line 266
    .line 267
    .line 268
    invoke-virtual {v13, v7}, Lla2;->b0(I)V

    .line 269
    .line 270
    .line 271
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 272
    .line 273
    .line 274
    :goto_4
    const v7, 0x7d5c718d

    .line 275
    .line 276
    .line 277
    invoke-virtual {v13, v7}, Lla2;->b0(I)V

    .line 278
    .line 279
    .line 280
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 281
    .line 282
    .line 283
    move-result-object v7

    .line 284
    :goto_5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 285
    .line 286
    .line 287
    move-result v8

    .line 288
    if-eqz v8, :cond_b

    .line 289
    .line 290
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v8

    .line 294
    check-cast v8, Lh41;

    .line 295
    .line 296
    const v9, -0x2f247dda

    .line 297
    .line 298
    .line 299
    iget-object v10, v8, Lh41;->a:Ljava/lang/String;

    .line 300
    .line 301
    invoke-virtual {v13, v9, v10}, Lla2;->Z(ILjava/lang/Object;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v13, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 305
    .line 306
    .line 307
    move-result v9

    .line 308
    invoke-virtual {v13, v8}, Lla2;->i(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v10

    .line 312
    or-int/2addr v9, v10

    .line 313
    invoke-virtual {v13}, Lla2;->N()Ljava/lang/Object;

    .line 314
    .line 315
    .line 316
    move-result-object v10

    .line 317
    if-nez v9, :cond_7

    .line 318
    .line 319
    if-ne v10, v1, :cond_8

    .line 320
    .line 321
    :cond_7
    new-instance v10, Ld41;

    .line 322
    .line 323
    invoke-direct {v10, v4, v8, v6}, Ld41;-><init>(Ll41;Lh41;B)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v13, v10}, Lla2;->k0(Ljava/lang/Object;)V

    .line 327
    .line 328
    .line 329
    :cond_8
    check-cast v10, Lw82;

    .line 330
    .line 331
    invoke-virtual {v13, v4}, Lla2;->g(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    move-result v9

    .line 335
    invoke-virtual {v13, v8}, Lla2;->i(Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    move-result v11

    .line 339
    or-int/2addr v9, v11

    .line 340
    invoke-virtual {v13}, Lla2;->N()Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    move-result-object v11

    .line 344
    if-nez v9, :cond_9

    .line 345
    .line 346
    if-ne v11, v1, :cond_a

    .line 347
    .line 348
    :cond_9
    new-instance v11, Lk2;

    .line 349
    .line 350
    const/16 v9, 0x15

    .line 351
    .line 352
    invoke-direct {v11, v4, v8, v9}, Lk2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v13, v11}, Lla2;->k0(Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    :cond_a
    check-cast v11, Lh92;

    .line 359
    .line 360
    const/16 v9, 0x8

    .line 361
    .line 362
    invoke-static {v8, v10, v11, v13, v9}, Lcj;->h(Lh41;Lw82;Lh92;Lla2;I)V

    .line 363
    .line 364
    .line 365
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 366
    .line 367
    .line 368
    goto :goto_5

    .line 369
    :cond_b
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 370
    .line 371
    .line 372
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 373
    .line 374
    .line 375
    move-result v0

    .line 376
    if-lt v0, v3, :cond_c

    .line 377
    .line 378
    const v0, 0x2e381948

    .line 379
    .line 380
    .line 381
    invoke-virtual {v13, v0}, Lla2;->b0(I)V

    .line 382
    .line 383
    .line 384
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 385
    .line 386
    .line 387
    move-result-object v0

    .line 388
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 389
    .line 390
    .line 391
    move-result-object v0

    .line 392
    const v1, 0x7f0f0109

    .line 393
    .line 394
    .line 395
    invoke-static {v1, v0, v13}, Lub3;->b0(I[Ljava/lang/Object;Lla2;)Ljava/lang/String;

    .line 396
    .line 397
    .line 398
    move-result-object v7

    .line 399
    const/high16 v14, 0x41400000    # 12.0f

    .line 400
    .line 401
    const/high16 v15, 0x41900000    # 18.0f

    .line 402
    .line 403
    invoke-static {v5, v15, v14}, Lif0;->Q(Lmz3;FF)Lmz3;

    .line 404
    .line 405
    .line 406
    move-result-object v8

    .line 407
    sget-object v0, Lbx0;->a:Lps1;

    .line 408
    .line 409
    invoke-virtual {v13, v0}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    check-cast v0, Lax0;

    .line 414
    .line 415
    invoke-virtual {v0}, Lax0;->n()J

    .line 416
    .line 417
    .line 418
    move-result-wide v9

    .line 419
    const/16 v27, 0x0

    .line 420
    .line 421
    const v28, 0x3fff8

    .line 422
    .line 423
    .line 424
    const-wide/16 v11, 0x0

    .line 425
    .line 426
    move-object/from16 v25, v13

    .line 427
    .line 428
    const/4 v13, 0x0

    .line 429
    const/4 v14, 0x0

    .line 430
    const-wide/16 v15, 0x0

    .line 431
    .line 432
    const/16 v17, 0x0

    .line 433
    .line 434
    const-wide/16 v18, 0x0

    .line 435
    .line 436
    const/16 v20, 0x0

    .line 437
    .line 438
    const/16 v21, 0x0

    .line 439
    .line 440
    const/16 v22, 0x0

    .line 441
    .line 442
    const/16 v23, 0x0

    .line 443
    .line 444
    const/16 v24, 0x0

    .line 445
    .line 446
    const/16 v26, 0x30

    .line 447
    .line 448
    invoke-static/range {v7 .. v28}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 449
    .line 450
    .line 451
    move-object/from16 v13, v25

    .line 452
    .line 453
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 454
    .line 455
    .line 456
    goto :goto_6

    .line 457
    :cond_c
    const v0, 0x2e3e41ec

    .line 458
    .line 459
    .line 460
    invoke-virtual {v13, v0}, Lla2;->b0(I)V

    .line 461
    .line 462
    .line 463
    invoke-virtual {v13, v6}, Lla2;->r(Z)V

    .line 464
    .line 465
    .line 466
    goto :goto_6

    .line 467
    :cond_d
    invoke-virtual {v13}, Lla2;->V()V

    .line 468
    .line 469
    .line 470
    :goto_6
    return-object v2

    .line 471
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
