.class public abstract Lat2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lmh0;->l:Lmh0;

    .line 2
    .line 3
    const-string v0, "\"\\"

    .line 4
    .line 5
    invoke-static {v0}, Lq9;->l(Ljava/lang/String;)Lmh0;

    .line 6
    .line 7
    .line 8
    const-string v0, "\t ,="

    .line 9
    .line 10
    invoke-static {v0}, Lq9;->l(Ljava/lang/String;)Lmh0;

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static final a(Lxl5;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Lxl5;->i:Lal5;

    .line 2
    .line 3
    iget-object v0, v0, Lal5;->b:Ljava/lang/String;

    .line 4
    .line 5
    const-string v1, "HEAD"

    .line 6
    .line 7
    invoke-static {v0, v1}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_2

    .line 12
    .line 13
    iget v0, p0, Lxl5;->l:I

    .line 14
    .line 15
    const/16 v1, 0x64

    .line 16
    .line 17
    if-lt v0, v1, :cond_0

    .line 18
    .line 19
    const/16 v1, 0xc8

    .line 20
    .line 21
    if-lt v0, v1, :cond_1

    .line 22
    .line 23
    :cond_0
    const/16 v1, 0xcc

    .line 24
    .line 25
    if-eq v0, v1, :cond_1

    .line 26
    .line 27
    const/16 v1, 0x130

    .line 28
    .line 29
    if-ne v0, v1, :cond_3

    .line 30
    .line 31
    :cond_1
    invoke-static {p0}, Lun7;->e(Lxl5;)J

    .line 32
    .line 33
    .line 34
    move-result-wide v0

    .line 35
    const-wide/16 v2, -0x1

    .line 36
    .line 37
    cmp-long v0, v0, v2

    .line 38
    .line 39
    if-nez v0, :cond_3

    .line 40
    .line 41
    const-string v0, "Transfer-Encoding"

    .line 42
    .line 43
    invoke-static {p0, v0}, Lxl5;->b(Lxl5;Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    const-string v0, "chunked"

    .line 48
    .line 49
    invoke-virtual {v0, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    if-nez p0, :cond_3

    .line 54
    .line 55
    :cond_2
    const/4 p0, 0x0

    .line 56
    return p0

    .line 57
    :cond_3
    const/4 p0, 0x1

    .line 58
    return p0
.end method

.method public static final b(Lr6;Lct2;Lii2;)V
    .locals 36

    .line 1
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    sget-object v0, Lr6;->a0:Lr6;

    .line 11
    .line 12
    move-object/from16 v1, p0

    .line 13
    .line 14
    if-ne v1, v0, :cond_0

    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    sget-object v0, Lfa1;->k:Ljava/util/regex/Pattern;

    .line 18
    .line 19
    const-string v0, "Set-Cookie"

    .line 20
    .line 21
    move-object/from16 v1, p2

    .line 22
    .line 23
    invoke-virtual {v1, v0}, Lii2;->b(Ljava/lang/String;)Ljava/util/List;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    const/4 v3, 0x0

    .line 32
    move v5, v3

    .line 33
    const/4 v6, 0x0

    .line 34
    :goto_0
    if-ge v5, v2, :cond_1e

    .line 35
    .line 36
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    move-object v7, v0

    .line 41
    check-cast v7, Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 47
    .line 48
    .line 49
    move-result-wide v8

    .line 50
    const/16 v10, 0x3b

    .line 51
    .line 52
    const/4 v11, 0x6

    .line 53
    invoke-static {v7, v10, v3, v3, v11}, Lsn7;->e(Ljava/lang/String;CIII)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    const/4 v12, 0x2

    .line 58
    const/16 v13, 0x3d

    .line 59
    .line 60
    invoke-static {v7, v13, v3, v0, v12}, Lsn7;->e(Ljava/lang/String;CIII)I

    .line 61
    .line 62
    .line 63
    move-result v12

    .line 64
    if-eq v12, v0, :cond_1

    .line 65
    .line 66
    invoke-static {v3, v7, v12}, Lsn7;->h(ILjava/lang/String;I)I

    .line 67
    .line 68
    .line 69
    move-result v14

    .line 70
    invoke-static {v14, v7, v12}, Lsn7;->i(ILjava/lang/String;I)I

    .line 71
    .line 72
    .line 73
    move-result v15

    .line 74
    invoke-virtual {v7, v14, v15}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v17

    .line 78
    invoke-virtual/range {v17 .. v17}, Ljava/lang/String;->length()I

    .line 79
    .line 80
    .line 81
    move-result v14

    .line 82
    if-eqz v14, :cond_1

    .line 83
    .line 84
    invoke-static/range {v17 .. v17}, Lsn7;->g(Ljava/lang/String;)I

    .line 85
    .line 86
    .line 87
    move-result v14

    .line 88
    const/4 v15, -0x1

    .line 89
    if-ne v14, v15, :cond_1

    .line 90
    .line 91
    add-int/lit8 v12, v12, 0x1

    .line 92
    .line 93
    invoke-static {v12, v7, v0}, Lsn7;->h(ILjava/lang/String;I)I

    .line 94
    .line 95
    .line 96
    move-result v12

    .line 97
    invoke-static {v12, v7, v0}, Lsn7;->i(ILjava/lang/String;I)I

    .line 98
    .line 99
    .line 100
    move-result v14

    .line 101
    invoke-virtual {v7, v12, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v18

    .line 105
    invoke-static/range {v18 .. v18}, Lsn7;->g(Ljava/lang/String;)I

    .line 106
    .line 107
    .line 108
    move-result v12

    .line 109
    if-eq v12, v15, :cond_2

    .line 110
    .line 111
    :cond_1
    const/4 v4, 0x0

    .line 112
    goto/16 :goto_8

    .line 113
    .line 114
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 115
    .line 116
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 117
    .line 118
    .line 119
    move-result v12

    .line 120
    const-wide v19, 0xe677d21fdbffL

    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    move/from16 v23, v3

    .line 126
    .line 127
    move/from16 v24, v23

    .line 128
    .line 129
    move/from16 v25, v24

    .line 130
    .line 131
    move-wide/from16 v28, v19

    .line 132
    .line 133
    const/16 p2, 0x1

    .line 134
    .line 135
    const/4 v4, 0x0

    .line 136
    const/4 v14, 0x0

    .line 137
    const-wide/16 v21, -0x1

    .line 138
    .line 139
    const/16 v26, 0x1

    .line 140
    .line 141
    const/16 v27, 0x0

    .line 142
    .line 143
    :goto_1
    const-wide v30, 0x7fffffffffffffffL

    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    const-wide/high16 v32, -0x8000000000000000L

    .line 149
    .line 150
    if-ge v0, v12, :cond_10

    .line 151
    .line 152
    invoke-static {v7, v10, v0, v12}, Lsn7;->d(Ljava/lang/String;CII)I

    .line 153
    .line 154
    .line 155
    move-result v15

    .line 156
    invoke-static {v7, v13, v0, v15}, Lsn7;->d(Ljava/lang/String;CII)I

    .line 157
    .line 158
    .line 159
    move-result v10

    .line 160
    invoke-static {v0, v7, v10}, Lsn7;->h(ILjava/lang/String;I)I

    .line 161
    .line 162
    .line 163
    move-result v0

    .line 164
    invoke-static {v0, v7, v10}, Lsn7;->i(ILjava/lang/String;I)I

    .line 165
    .line 166
    .line 167
    move-result v13

    .line 168
    invoke-virtual {v7, v0, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    if-ge v10, v15, :cond_3

    .line 173
    .line 174
    add-int/lit8 v10, v10, 0x1

    .line 175
    .line 176
    invoke-static {v10, v7, v15}, Lsn7;->h(ILjava/lang/String;I)I

    .line 177
    .line 178
    .line 179
    move-result v10

    .line 180
    invoke-static {v10, v7, v15}, Lsn7;->i(ILjava/lang/String;I)I

    .line 181
    .line 182
    .line 183
    move-result v13

    .line 184
    invoke-virtual {v7, v10, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v10

    .line 188
    goto :goto_2

    .line 189
    :cond_3
    const-string v10, ""

    .line 190
    .line 191
    :goto_2
    const-string v13, "expires"

    .line 192
    .line 193
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 194
    .line 195
    .line 196
    move-result v13

    .line 197
    if-eqz v13, :cond_4

    .line 198
    .line 199
    :try_start_0
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 200
    .line 201
    .line 202
    move-result v0

    .line 203
    invoke-static {v0, v10}, Lcj;->K(ILjava/lang/String;)J

    .line 204
    .line 205
    .line 206
    move-result-wide v28
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    .line 207
    goto :goto_3

    .line 208
    :cond_4
    const-string v13, "max-age"

    .line 209
    .line 210
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 211
    .line 212
    .line 213
    move-result v13

    .line 214
    if-eqz v13, :cond_8

    .line 215
    .line 216
    :try_start_1
    invoke-static {v10}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 217
    .line 218
    .line 219
    move-result-wide v21
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    .line 220
    const-wide/16 v30, 0x0

    .line 221
    .line 222
    cmp-long v0, v21, v30

    .line 223
    .line 224
    if-gtz v0, :cond_6

    .line 225
    .line 226
    move-wide/from16 v21, v32

    .line 227
    .line 228
    goto :goto_3

    .line 229
    :catch_0
    move-exception v0

    .line 230
    :try_start_2
    const-string v13, "-?\\d+"

    .line 231
    .line 232
    invoke-static {v13}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 233
    .line 234
    .line 235
    move-result-object v13

    .line 236
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 237
    .line 238
    .line 239
    invoke-virtual {v13, v10}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 240
    .line 241
    .line 242
    move-result-object v13

    .line 243
    invoke-virtual {v13}, Ljava/util/regex/Matcher;->matches()Z

    .line 244
    .line 245
    .line 246
    move-result v13

    .line 247
    if-eqz v13, :cond_7

    .line 248
    .line 249
    const-string v0, "-"

    .line 250
    .line 251
    invoke-static {v10, v0, v3}, Lhm6;->y0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 252
    .line 253
    .line 254
    move-result v0

    .line 255
    if-eqz v0, :cond_5

    .line 256
    .line 257
    move-wide/from16 v30, v32

    .line 258
    .line 259
    :cond_5
    move-wide/from16 v21, v30

    .line 260
    .line 261
    :cond_6
    :goto_3
    move/from16 v25, p2

    .line 262
    .line 263
    goto :goto_4

    .line 264
    :cond_7
    throw v0
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    .line 265
    :cond_8
    const-string v13, "domain"

    .line 266
    .line 267
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 268
    .line 269
    .line 270
    move-result v13

    .line 271
    if-eqz v13, :cond_b

    .line 272
    .line 273
    :try_start_3
    const-string v0, "."

    .line 274
    .line 275
    invoke-static {v10, v0, v3}, Lhm6;->q0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 276
    .line 277
    .line 278
    move-result v13

    .line 279
    if-nez v13, :cond_a

    .line 280
    .line 281
    invoke-static {v10, v0}, Lam6;->X0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    invoke-static {v0}, Lqn7;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 286
    .line 287
    .line 288
    move-result-object v0

    .line 289
    if-eqz v0, :cond_9

    .line 290
    .line 291
    move-object v4, v0

    .line 292
    move/from16 v26, v3

    .line 293
    .line 294
    goto :goto_4

    .line 295
    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 296
    .line 297
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 298
    .line 299
    .line 300
    throw v0

    .line 301
    :cond_a
    const-string v0, "Failed requirement."

    .line 302
    .line 303
    new-instance v10, Ljava/lang/IllegalArgumentException;

    .line 304
    .line 305
    invoke-direct {v10, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    throw v10
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_1

    .line 309
    :cond_b
    const-string v13, "path"

    .line 310
    .line 311
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 312
    .line 313
    .line 314
    move-result v13

    .line 315
    if-eqz v13, :cond_c

    .line 316
    .line 317
    move-object v14, v10

    .line 318
    goto :goto_4

    .line 319
    :cond_c
    const-string v13, "secure"

    .line 320
    .line 321
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 322
    .line 323
    .line 324
    move-result v13

    .line 325
    if-eqz v13, :cond_d

    .line 326
    .line 327
    move/from16 v23, p2

    .line 328
    .line 329
    goto :goto_4

    .line 330
    :cond_d
    const-string v13, "httponly"

    .line 331
    .line 332
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 333
    .line 334
    .line 335
    move-result v13

    .line 336
    if-eqz v13, :cond_e

    .line 337
    .line 338
    move/from16 v24, p2

    .line 339
    .line 340
    goto :goto_4

    .line 341
    :cond_e
    const-string v13, "samesite"

    .line 342
    .line 343
    invoke-virtual {v0, v13}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 344
    .line 345
    .line 346
    move-result v0

    .line 347
    if-eqz v0, :cond_f

    .line 348
    .line 349
    move-object/from16 v27, v10

    .line 350
    .line 351
    :catch_1
    :cond_f
    :goto_4
    add-int/lit8 v0, v15, 0x1

    .line 352
    .line 353
    const/16 v10, 0x3b

    .line 354
    .line 355
    const/16 v13, 0x3d

    .line 356
    .line 357
    goto/16 :goto_1

    .line 358
    .line 359
    :cond_10
    const-wide/16 v34, -0x1

    .line 360
    .line 361
    cmp-long v0, v21, v32

    .line 362
    .line 363
    if-nez v0, :cond_11

    .line 364
    .line 365
    move-object/from16 v7, p1

    .line 366
    .line 367
    move-wide/from16 v19, v32

    .line 368
    .line 369
    goto :goto_5

    .line 370
    :cond_11
    cmp-long v0, v21, v34

    .line 371
    .line 372
    if-eqz v0, :cond_14

    .line 373
    .line 374
    const-wide v12, 0x20c49ba5e353f7L

    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    cmp-long v0, v21, v12

    .line 380
    .line 381
    if-gtz v0, :cond_12

    .line 382
    .line 383
    const-wide/16 v12, 0x3e8

    .line 384
    .line 385
    mul-long v30, v21, v12

    .line 386
    .line 387
    :cond_12
    add-long v30, v8, v30

    .line 388
    .line 389
    cmp-long v0, v30, v8

    .line 390
    .line 391
    if-ltz v0, :cond_13

    .line 392
    .line 393
    cmp-long v0, v30, v19

    .line 394
    .line 395
    if-gtz v0, :cond_13

    .line 396
    .line 397
    move-object/from16 v7, p1

    .line 398
    .line 399
    move-wide/from16 v19, v30

    .line 400
    .line 401
    goto :goto_5

    .line 402
    :cond_13
    move-object/from16 v7, p1

    .line 403
    .line 404
    goto :goto_5

    .line 405
    :cond_14
    move-object/from16 v7, p1

    .line 406
    .line 407
    move-wide/from16 v19, v28

    .line 408
    .line 409
    :goto_5
    iget-object v0, v7, Lct2;->d:Ljava/lang/String;

    .line 410
    .line 411
    if-nez v4, :cond_15

    .line 412
    .line 413
    move-object v4, v0

    .line 414
    goto :goto_6

    .line 415
    :cond_15
    invoke-static {v0, v4}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 416
    .line 417
    .line 418
    move-result v8

    .line 419
    if-nez v8, :cond_16

    .line 420
    .line 421
    invoke-static {v0, v4, v3}, Lhm6;->q0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 422
    .line 423
    .line 424
    move-result v8

    .line 425
    if-eqz v8, :cond_1b

    .line 426
    .line 427
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 428
    .line 429
    .line 430
    move-result v8

    .line 431
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 432
    .line 433
    .line 434
    move-result v9

    .line 435
    sub-int/2addr v8, v9

    .line 436
    add-int/lit8 v8, v8, -0x1

    .line 437
    .line 438
    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    .line 439
    .line 440
    .line 441
    move-result v8

    .line 442
    const/16 v9, 0x2e

    .line 443
    .line 444
    if-ne v8, v9, :cond_1b

    .line 445
    .line 446
    sget-object v8, Lqn7;->a:Ldk5;

    .line 447
    .line 448
    invoke-virtual {v8, v0}, Ldk5;->d(Ljava/lang/CharSequence;)Z

    .line 449
    .line 450
    .line 451
    move-result v8

    .line 452
    if-nez v8, :cond_1b

    .line 453
    .line 454
    :cond_16
    :goto_6
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 455
    .line 456
    .line 457
    move-result v0

    .line 458
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 459
    .line 460
    .line 461
    move-result v8

    .line 462
    if-eq v0, v8, :cond_17

    .line 463
    .line 464
    sget-object v0, Lse5;->d:Lse5;

    .line 465
    .line 466
    invoke-virtual {v0, v4}, Lse5;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 467
    .line 468
    .line 469
    move-result-object v0

    .line 470
    if-eqz v0, :cond_1b

    .line 471
    .line 472
    :cond_17
    const-string v0, "/"

    .line 473
    .line 474
    if-eqz v14, :cond_18

    .line 475
    .line 476
    invoke-static {v14, v0, v3}, Lhm6;->y0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 477
    .line 478
    .line 479
    move-result v8

    .line 480
    if-nez v8, :cond_1a

    .line 481
    .line 482
    :cond_18
    invoke-virtual {v7}, Lct2;->b()Ljava/lang/String;

    .line 483
    .line 484
    .line 485
    move-result-object v8

    .line 486
    const/16 v9, 0x2f

    .line 487
    .line 488
    invoke-static {v8, v9, v3, v11}, Lam6;->R0(Ljava/lang/CharSequence;CII)I

    .line 489
    .line 490
    .line 491
    move-result v9

    .line 492
    if-eqz v9, :cond_19

    .line 493
    .line 494
    invoke-virtual {v8, v3, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object v0

    .line 498
    :cond_19
    move-object v14, v0

    .line 499
    :cond_1a
    move-object/from16 v22, v14

    .line 500
    .line 501
    new-instance v16, Lfa1;

    .line 502
    .line 503
    move-object/from16 v21, v4

    .line 504
    .line 505
    invoke-direct/range {v16 .. v27}, Lfa1;-><init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;ZZZZLjava/lang/String;)V

    .line 506
    .line 507
    .line 508
    goto :goto_7

    .line 509
    :cond_1b
    const/16 v16, 0x0

    .line 510
    .line 511
    :goto_7
    move-object/from16 v4, v16

    .line 512
    .line 513
    :goto_8
    if-eqz v4, :cond_1d

    .line 514
    .line 515
    if-nez v6, :cond_1c

    .line 516
    .line 517
    new-instance v0, Ljava/util/ArrayList;

    .line 518
    .line 519
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 520
    .line 521
    .line 522
    move-object v6, v0

    .line 523
    :cond_1c
    invoke-interface {v6, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 524
    .line 525
    .line 526
    :cond_1d
    add-int/lit8 v5, v5, 0x1

    .line 527
    .line 528
    goto/16 :goto_0

    .line 529
    .line 530
    :cond_1e
    if-eqz v6, :cond_1f

    .line 531
    .line 532
    invoke-static {v6}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 533
    .line 534
    .line 535
    move-result-object v4

    .line 536
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 537
    .line 538
    .line 539
    goto :goto_9

    .line 540
    :cond_1f
    const/4 v4, 0x0

    .line 541
    :goto_9
    if-nez v4, :cond_20

    .line 542
    .line 543
    sget-object v4, Lbx1;->i:Lbx1;

    .line 544
    .line 545
    :cond_20
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 546
    .line 547
    .line 548
    return-void
.end method
