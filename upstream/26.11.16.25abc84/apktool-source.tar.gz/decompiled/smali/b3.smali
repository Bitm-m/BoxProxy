.class public abstract Lb3;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lwd1;


# instance fields
.field public final i:Lxd1;


# direct methods
.method public constructor <init>(Lxd1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb3;->i:Lxd1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge A(Lxd1;)Lyd1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lhn;->M(Lwd1;Lxd1;)Lyd1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getKey()Lxd1;
    .locals 0

    .line 1
    iget-object p0, p0, Lb3;->i:Lxd1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final bridge k(Lyd1;)Lyd1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lhn;->N(Lwd1;Lyd1;)Lyd1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge p(Lxd1;)Lwd1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Lhn;->D(Lwd1;Lxd1;)Lwd1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final v(Ll92;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, Ll92;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
