.class public interface abstract Landroidx/window/area/reflectionguard/ExtensionWindowAreaPresentationRequirements;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# virtual methods
.method public abstract getPresentationContext()Landroid/content/Context;
.end method

.method public abstract setPresentationView(Landroid/view/View;)V
.end method
