.class public interface abstract Lb04;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lwd1;


# virtual methods
.method public abstract B()F
.end method

.method public getKey()Lxd1;
    .locals 0

    .line 1
    sget-object p0, Lox1;->w:Lox1;

    .line 2
    .line 3
    return-object p0
.end method
