.class public final synthetic Lb35;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lw82;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(La07;Lki;Lpf;)V
    .locals 0

    .line 1
    const/16 p1, 0x17

    .line 2
    .line 3
    iput-byte p1, p0, Lb35;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, Lb35;->j:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p3, p0, Lb35;->k:Ljava/lang/Object;

    .line 11
    .line 12
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 13
    iput-byte p3, p0, Lb35;->i:B

    iput-object p1, p0, Lb35;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb35;->k:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb35;->i:B

    .line 4
    .line 5
    const-string v2, "*/*"

    .line 6
    .line 7
    const-wide v3, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    const/16 v5, 0x20

    .line 13
    .line 14
    const/4 v6, -0x1

    .line 15
    const/4 v7, 0x3

    .line 16
    const/4 v8, 0x2

    .line 17
    const/4 v9, 0x0

    .line 18
    const/4 v10, 0x1

    .line 19
    const/4 v11, 0x0

    .line 20
    sget-object v12, Loc7;->a:Loc7;

    .line 21
    .line 22
    iget-object v13, v0, Lb35;->k:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v0, v0, Lb35;->j:Ljava/lang/Object;

    .line 25
    .line 26
    packed-switch v1, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    check-cast v0, Landroid/content/Context;

    .line 30
    .line 31
    check-cast v13, Lth7;

    .line 32
    .line 33
    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    const-string v2, "local"

    .line 38
    .line 39
    const-string v3, "web_panel_preferences"

    .line 40
    .line 41
    if-eqz v1, :cond_1

    .line 42
    .line 43
    if-ne v1, v10, :cond_0

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {v0, v3, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    const-string v1, "substore_selected_panel"

    .line 57
    .line 58
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-nez v0, :cond_2

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    invoke-static {}, Lhh1;->a()V

    .line 66
    .line 67
    .line 68
    goto :goto_1

    .line 69
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-virtual {v0, v3, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    const-string v1, "webui_selected_panel"

    .line 81
    .line 82
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    if-eqz v0, :cond_3

    .line 87
    .line 88
    :cond_2
    move-object v2, v0

    .line 89
    :cond_3
    :goto_0
    invoke-static {v2}, Lmb3;->L(Ljava/lang/Object;)Liw4;

    .line 90
    .line 91
    .line 92
    move-result-object v9

    .line 93
    :goto_1
    return-object v9

    .line 94
    :pswitch_0
    check-cast v0, Lnn7;

    .line 95
    .line 96
    check-cast v13, Lz6;

    .line 97
    .line 98
    new-instance v1, Lof7;

    .line 99
    .line 100
    invoke-direct {v1, v10, v0, v13}, Lof7;-><init>(ZLnn7;Lnn7;)V

    .line 101
    .line 102
    .line 103
    return-object v1

    .line 104
    :pswitch_1
    check-cast v0, Lnn7;

    .line 105
    .line 106
    check-cast v13, Lnn7;

    .line 107
    .line 108
    new-instance v1, Lof7;

    .line 109
    .line 110
    invoke-direct {v1, v11, v0, v13}, Lof7;-><init>(ZLnn7;Lnn7;)V

    .line 111
    .line 112
    .line 113
    return-object v1

    .line 114
    :pswitch_2
    check-cast v0, Lm77;

    .line 115
    .line 116
    check-cast v13, Lbn5;

    .line 117
    .line 118
    iget-object v1, v0, Lm77;->a:Lzy6;

    .line 119
    .line 120
    invoke-virtual {v1}, Lzy6;->c()Ljv6;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    iget-object v0, v0, Lm77;->d:Liw4;

    .line 125
    .line 126
    invoke-virtual {v0}, Liw4;->getValue()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    check-cast v0, Lu66;

    .line 131
    .line 132
    new-instance v2, Lgn0;

    .line 133
    .line 134
    const/4 v3, 0x6

    .line 135
    invoke-direct {v2, v3}, Lgn0;-><init>(B)V

    .line 136
    .line 137
    .line 138
    new-instance v3, Ljava/lang/StringBuilder;

    .line 139
    .line 140
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 141
    .line 142
    .line 143
    move v4, v11

    .line 144
    :goto_2
    iget-object v6, v1, Ljv6;->k:Ljava/lang/CharSequence;

    .line 145
    .line 146
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 147
    .line 148
    .line 149
    move-result v6

    .line 150
    if-ge v11, v6, :cond_7

    .line 151
    .line 152
    invoke-static {v1, v11}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    .line 153
    .line 154
    .line 155
    move-result v6

    .line 156
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    const/16 v7, 0xa

    .line 160
    .line 161
    if-ne v6, v7, :cond_4

    .line 162
    .line 163
    move v7, v5

    .line 164
    goto :goto_3

    .line 165
    :cond_4
    const/16 v7, 0xd

    .line 166
    .line 167
    if-ne v6, v7, :cond_5

    .line 168
    .line 169
    const v7, 0xfeff

    .line 170
    .line 171
    .line 172
    goto :goto_3

    .line 173
    :cond_5
    move v7, v6

    .line 174
    :goto_3
    invoke-static {v6}, Ljava/lang/Character;->charCount(I)I

    .line 175
    .line 176
    .line 177
    move-result v8

    .line 178
    if-eq v7, v6, :cond_6

    .line 179
    .line 180
    invoke-static {v7}, Ljava/lang/Character;->charCount(I)I

    .line 181
    .line 182
    .line 183
    move-result v4

    .line 184
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 185
    .line 186
    .line 187
    move-result v6

    .line 188
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    .line 189
    .line 190
    .line 191
    move-result v12

    .line 192
    add-int/2addr v12, v8

    .line 193
    invoke-virtual {v2, v6, v12, v4}, Lgn0;->y(III)V

    .line 194
    .line 195
    .line 196
    move v4, v10

    .line 197
    :cond_6
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->appendCodePoint(I)Ljava/lang/StringBuilder;

    .line 198
    .line 199
    .line 200
    add-int/2addr v11, v8

    .line 201
    goto :goto_2

    .line 202
    :cond_7
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v3

    .line 206
    if-eqz v4, :cond_8

    .line 207
    .line 208
    move-object v11, v3

    .line 209
    goto :goto_4

    .line 210
    :cond_8
    move-object v11, v1

    .line 211
    :goto_4
    if-eq v11, v1, :cond_a

    .line 212
    .line 213
    iget-wide v3, v1, Ljv6;->l:J

    .line 214
    .line 215
    invoke-static {v3, v4, v2, v0}, Lir6;->n(JLgn0;Lu66;)J

    .line 216
    .line 217
    .line 218
    move-result-wide v12

    .line 219
    iget-object v1, v1, Ljv6;->m:Lp07;

    .line 220
    .line 221
    if-eqz v1, :cond_9

    .line 222
    .line 223
    iget-wide v3, v1, Lp07;->a:J

    .line 224
    .line 225
    invoke-static {v3, v4, v2, v0}, Lir6;->n(JLgn0;Lu66;)J

    .line 226
    .line 227
    .line 228
    move-result-wide v0

    .line 229
    new-instance v9, Lp07;

    .line 230
    .line 231
    invoke-direct {v9, v0, v1}, Lp07;-><init>(J)V

    .line 232
    .line 233
    .line 234
    :cond_9
    move-object v14, v9

    .line 235
    new-instance v10, Ljv6;

    .line 236
    .line 237
    const/4 v15, 0x0

    .line 238
    const/16 v16, 0x0

    .line 239
    .line 240
    const/16 v17, 0x0

    .line 241
    .line 242
    const/16 v18, 0x0

    .line 243
    .line 244
    const/16 v19, 0x78

    .line 245
    .line 246
    invoke-direct/range {v10 .. v19}, Ljv6;-><init>(Ljava/lang/CharSequence;JLp07;Lpv4;Ljava/util/List;Ljava/util/List;Lcz6;I)V

    .line 247
    .line 248
    .line 249
    new-instance v9, Lk77;

    .line 250
    .line 251
    invoke-direct {v9, v10, v2}, Lk77;-><init>(Ljv6;Lgn0;)V

    .line 252
    .line 253
    .line 254
    :cond_a
    return-object v9

    .line 255
    :pswitch_3
    check-cast v0, Lh92;

    .line 256
    .line 257
    check-cast v13, Lx17;

    .line 258
    .line 259
    invoke-interface {v0, v13}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    return-object v12

    .line 263
    :pswitch_4
    check-cast v0, Lh92;

    .line 264
    .line 265
    check-cast v13, Lf27;

    .line 266
    .line 267
    invoke-interface {v0, v13}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    return-object v12

    .line 271
    :pswitch_5
    check-cast v0, Lki;

    .line 272
    .line 273
    check-cast v13, Lpf;

    .line 274
    .line 275
    iget-object v0, v0, Lki;->a:Ljava/lang/Object;

    .line 276
    .line 277
    check-cast v0, Lrg3;

    .line 278
    .line 279
    instance-of v1, v0, Lqg3;

    .line 280
    .line 281
    if-eqz v1, :cond_b

    .line 282
    .line 283
    :try_start_0
    check-cast v0, Lqg3;

    .line 284
    .line 285
    iget-object v0, v0, Lqg3;->a:Ljava/lang/String;

    .line 286
    .line 287
    invoke-virtual {v13, v0}, Lpf;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 288
    .line 289
    .line 290
    :catch_0
    :cond_b
    return-object v12

    .line 291
    :pswitch_6
    check-cast v0, Ldy6;

    .line 292
    .line 293
    check-cast v13, Lb34;

    .line 294
    .line 295
    invoke-interface {v13}, Lok6;->getValue()Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object v1

    .line 299
    check-cast v1, Lqz2;

    .line 300
    .line 301
    iget-wide v1, v1, Lqz2;->a:J

    .line 302
    .line 303
    invoke-virtual {v0}, Ldy6;->g()Lkk4;

    .line 304
    .line 305
    .line 306
    move-result-object v12

    .line 307
    if-eqz v12, :cond_10

    .line 308
    .line 309
    iget-wide v12, v12, Lkk4;->a:J

    .line 310
    .line 311
    invoke-virtual {v0}, Ldy6;->k()Lli;

    .line 312
    .line 313
    .line 314
    move-result-object v14

    .line 315
    if-eqz v14, :cond_10

    .line 316
    .line 317
    iget-object v14, v14, Lli;->j:Ljava/lang/String;

    .line 318
    .line 319
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    .line 320
    .line 321
    .line 322
    move-result v14

    .line 323
    if-eqz v14, :cond_10

    .line 324
    .line 325
    iget-object v14, v0, Ldy6;->q:Liw4;

    .line 326
    .line 327
    invoke-virtual {v14}, Liw4;->getValue()Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    move-result-object v14

    .line 331
    check-cast v14, Lhh2;

    .line 332
    .line 333
    if-nez v14, :cond_c

    .line 334
    .line 335
    move v14, v6

    .line 336
    goto :goto_5

    .line 337
    :cond_c
    sget-object v15, Lfy6;->a:[I

    .line 338
    .line 339
    invoke-virtual {v14}, Ljava/lang/Enum;->ordinal()I

    .line 340
    .line 341
    .line 342
    move-result v14

    .line 343
    aget v14, v15, v14

    .line 344
    .line 345
    :goto_5
    if-eq v14, v6, :cond_10

    .line 346
    .line 347
    const-wide v15, 0xffffffffL

    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    if-eq v14, v10, :cond_e

    .line 353
    .line 354
    if-eq v14, v8, :cond_e

    .line 355
    .line 356
    if-ne v14, v7, :cond_d

    .line 357
    .line 358
    invoke-virtual {v0}, Ldy6;->l()Ldz6;

    .line 359
    .line 360
    .line 361
    move-result-object v6

    .line 362
    iget-wide v6, v6, Ldz6;->b:J

    .line 363
    .line 364
    sget v9, Lp07;->c:I

    .line 365
    .line 366
    and-long/2addr v6, v15

    .line 367
    :goto_6
    long-to-int v6, v6

    .line 368
    goto :goto_7

    .line 369
    :cond_d
    invoke-static {}, Lhh1;->a()V

    .line 370
    .line 371
    .line 372
    goto/16 :goto_8

    .line 373
    .line 374
    :cond_e
    invoke-virtual {v0}, Ldy6;->l()Ldz6;

    .line 375
    .line 376
    .line 377
    move-result-object v6

    .line 378
    iget-wide v6, v6, Ldz6;->b:J

    .line 379
    .line 380
    sget v9, Lp07;->c:I

    .line 381
    .line 382
    shr-long/2addr v6, v5

    .line 383
    goto :goto_6

    .line 384
    :goto_7
    iget-object v7, v0, Ldy6;->d:Lhd3;

    .line 385
    .line 386
    if-eqz v7, :cond_10

    .line 387
    .line 388
    invoke-virtual {v7}, Lhd3;->d()Lwz6;

    .line 389
    .line 390
    .line 391
    move-result-object v7

    .line 392
    if-eqz v7, :cond_10

    .line 393
    .line 394
    iget-object v9, v0, Ldy6;->d:Lhd3;

    .line 395
    .line 396
    if-eqz v9, :cond_10

    .line 397
    .line 398
    iget-object v9, v9, Lhd3;->a:Luu4;

    .line 399
    .line 400
    iget-object v9, v9, Luu4;->b:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast v9, Lli;

    .line 403
    .line 404
    if-eqz v9, :cond_10

    .line 405
    .line 406
    iget-object v0, v0, Ldy6;->b:Lnk4;

    .line 407
    .line 408
    invoke-interface {v0, v6}, Lnk4;->i(I)I

    .line 409
    .line 410
    .line 411
    move-result v0

    .line 412
    iget-object v6, v9, Lli;->j:Ljava/lang/String;

    .line 413
    .line 414
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 415
    .line 416
    .line 417
    move-result v6

    .line 418
    invoke-static {v0, v11, v6}, Lub3;->z(III)I

    .line 419
    .line 420
    .line 421
    move-result v0

    .line 422
    invoke-virtual {v7, v12, v13}, Lwz6;->d(J)J

    .line 423
    .line 424
    .line 425
    move-result-wide v9

    .line 426
    shr-long/2addr v9, v5

    .line 427
    long-to-int v6, v9

    .line 428
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 429
    .line 430
    .line 431
    move-result v6

    .line 432
    iget-object v7, v7, Lwz6;->a:Lvz6;

    .line 433
    .line 434
    iget-object v9, v7, Lvz6;->b:Ly04;

    .line 435
    .line 436
    invoke-virtual {v9, v0}, Ly04;->d(I)I

    .line 437
    .line 438
    .line 439
    move-result v0

    .line 440
    invoke-virtual {v7, v0}, Lvz6;->f(I)F

    .line 441
    .line 442
    .line 443
    move-result v10

    .line 444
    invoke-virtual {v7, v0}, Lvz6;->g(I)F

    .line 445
    .line 446
    .line 447
    move-result v7

    .line 448
    invoke-static {v10, v7}, Ljava/lang/Math;->min(FF)F

    .line 449
    .line 450
    .line 451
    move-result v11

    .line 452
    invoke-static {v10, v7}, Ljava/lang/Math;->max(FF)F

    .line 453
    .line 454
    .line 455
    move-result v7

    .line 456
    invoke-static {v6, v11, v7}, Lub3;->y(FFF)F

    .line 457
    .line 458
    .line 459
    move-result v7

    .line 460
    const-wide/16 v10, 0x0

    .line 461
    .line 462
    invoke-static {v1, v2, v10, v11}, Lqz2;->a(JJ)Z

    .line 463
    .line 464
    .line 465
    move-result v10

    .line 466
    if-nez v10, :cond_f

    .line 467
    .line 468
    sub-float/2addr v6, v7

    .line 469
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 470
    .line 471
    .line 472
    move-result v6

    .line 473
    shr-long/2addr v1, v5

    .line 474
    long-to-int v1, v1

    .line 475
    div-int/2addr v1, v8

    .line 476
    int-to-float v1, v1

    .line 477
    cmpl-float v1, v6, v1

    .line 478
    .line 479
    if-gtz v1, :cond_10

    .line 480
    .line 481
    :cond_f
    invoke-virtual {v9, v0}, Ly04;->f(I)F

    .line 482
    .line 483
    .line 484
    move-result v1

    .line 485
    invoke-virtual {v9, v0}, Ly04;->b(I)F

    .line 486
    .line 487
    .line 488
    move-result v0

    .line 489
    sub-float/2addr v0, v1

    .line 490
    const/high16 v2, 0x40000000    # 2.0f

    .line 491
    .line 492
    div-float/2addr v0, v2

    .line 493
    add-float/2addr v0, v1

    .line 494
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 495
    .line 496
    .line 497
    move-result v1

    .line 498
    int-to-long v1, v1

    .line 499
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 500
    .line 501
    .line 502
    move-result v0

    .line 503
    int-to-long v3, v0

    .line 504
    shl-long/2addr v1, v5

    .line 505
    and-long/2addr v3, v15

    .line 506
    or-long/2addr v3, v1

    .line 507
    :cond_10
    new-instance v9, Lkk4;

    .line 508
    .line 509
    invoke-direct {v9, v3, v4}, Lkk4;-><init>(J)V

    .line 510
    .line 511
    .line 512
    :goto_8
    return-object v9

    .line 513
    :pswitch_7
    check-cast v0, Lty6;

    .line 514
    .line 515
    check-cast v13, Law6;

    .line 516
    .line 517
    iget-boolean v0, v0, Lty6;->h:Z

    .line 518
    .line 519
    if-nez v0, :cond_11

    .line 520
    .line 521
    iget-object v0, v13, Law6;->G:Lr62;

    .line 522
    .line 523
    iget-boolean v1, v0, Llz3;->v:Z

    .line 524
    .line 525
    if-eqz v1, :cond_11

    .line 526
    .line 527
    iget-object v0, v0, Lr62;->D:Lm62;

    .line 528
    .line 529
    invoke-static {v0}, Lm62;->O1(Lm62;)Z

    .line 530
    .line 531
    .line 532
    :cond_11
    return-object v12

    .line 533
    :pswitch_8
    check-cast v0, Lpv6;

    .line 534
    .line 535
    check-cast v13, Lej5;

    .line 536
    .line 537
    iget-object v1, v0, Lpv6;->B:Lm77;

    .line 538
    .line 539
    invoke-virtual {v1}, Lm77;->d()Ljv6;

    .line 540
    .line 541
    .line 542
    iget-boolean v1, v0, Llz3;->v:Z

    .line 543
    .line 544
    if-eqz v1, :cond_12

    .line 545
    .line 546
    sget-object v1, La31;->v:Lps1;

    .line 547
    .line 548
    invoke-static {v0, v1}, Lkn0;->G(Lu21;Ln55;)Ljava/lang/Object;

    .line 549
    .line 550
    .line 551
    move-result-object v0

    .line 552
    check-cast v0, Lgk7;

    .line 553
    .line 554
    check-cast v0, Lad3;

    .line 555
    .line 556
    invoke-virtual {v0}, Lad3;->c()Z

    .line 557
    .line 558
    .line 559
    move-result v0

    .line 560
    if-eqz v0, :cond_12

    .line 561
    .line 562
    move v8, v10

    .line 563
    :cond_12
    iget v0, v13, Lej5;->i:I

    .line 564
    .line 565
    mul-int/2addr v8, v0

    .line 566
    mul-int/2addr v0, v6

    .line 567
    iput v0, v13, Lej5;->i:I

    .line 568
    .line 569
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 570
    .line 571
    .line 572
    move-result-object v0

    .line 573
    return-object v0

    .line 574
    :pswitch_9
    check-cast v0, Landroid/content/Context;

    .line 575
    .line 576
    check-cast v13, Landroid/view/textclassifier/TextClassification;

    .line 577
    .line 578
    invoke-virtual {v13}, Landroid/view/textclassifier/TextClassification;->getText()Ljava/lang/String;

    .line 579
    .line 580
    .line 581
    move-result-object v1

    .line 582
    if-eqz v1, :cond_13

    .line 583
    .line 584
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 585
    .line 586
    .line 587
    move-result v11

    .line 588
    :cond_13
    invoke-virtual {v13}, Landroid/view/textclassifier/TextClassification;->getIntent()Landroid/content/Intent;

    .line 589
    .line 590
    .line 591
    move-result-object v1

    .line 592
    const/high16 v2, 0xc000000

    .line 593
    .line 594
    invoke-static {v0, v11, v1, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 595
    .line 596
    .line 597
    move-result-object v0

    .line 598
    invoke-static {v0}, Lcu6;->m(Landroid/app/PendingIntent;)V

    .line 599
    .line 600
    .line 601
    return-object v12

    .line 602
    :pswitch_a
    check-cast v0, Lrh7;

    .line 603
    .line 604
    check-cast v13, Lum6;

    .line 605
    .line 606
    iget-object v1, v13, Lum6;->a:Ljava/lang/String;

    .line 607
    .line 608
    invoke-virtual {v0, v1}, Lrh7;->m(Ljava/lang/String;)V

    .line 609
    .line 610
    .line 611
    return-object v12

    .line 612
    :pswitch_b
    check-cast v0, Lw82;

    .line 613
    .line 614
    check-cast v13, Lw82;

    .line 615
    .line 616
    invoke-interface {v0}, Lw82;->invoke()Ljava/lang/Object;

    .line 617
    .line 618
    .line 619
    invoke-interface {v13}, Lw82;->invoke()Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    return-object v12

    .line 623
    :pswitch_c
    check-cast v0, Lpd6;

    .line 624
    .line 625
    check-cast v13, Lqn3;

    .line 626
    .line 627
    iget-object v0, v0, Lpd6;->a:Lb34;

    .line 628
    .line 629
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 630
    .line 631
    invoke-interface {v0, v1}, Lb34;->setValue(Ljava/lang/Object;)V

    .line 632
    .line 633
    .line 634
    const-string v0, "text/x-shellscript"

    .line 635
    .line 636
    const-string v1, "text/plain"

    .line 637
    .line 638
    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    .line 639
    .line 640
    .line 641
    move-result-object v0

    .line 642
    invoke-virtual {v13, v0}, Lqn3;->S(Ljava/lang/Object;)V

    .line 643
    .line 644
    .line 645
    return-object v12

    .line 646
    :pswitch_d
    check-cast v0, Le66;

    .line 647
    .line 648
    check-cast v13, Lb34;

    .line 649
    .line 650
    invoke-interface {v13}, Lok6;->getValue()Ljava/lang/Object;

    .line 651
    .line 652
    .line 653
    move-result-object v1

    .line 654
    check-cast v1, Lqz2;

    .line 655
    .line 656
    iget-wide v1, v1, Lqz2;->a:J

    .line 657
    .line 658
    invoke-virtual {v0}, Le66;->i()La56;

    .line 659
    .line 660
    .line 661
    move-result-object v5

    .line 662
    if-eqz v5, :cond_18

    .line 663
    .line 664
    invoke-virtual {v0}, Le66;->h()Lhh2;

    .line 665
    .line 666
    .line 667
    move-result-object v11

    .line 668
    if-nez v11, :cond_14

    .line 669
    .line 670
    move v11, v6

    .line 671
    goto :goto_9

    .line 672
    :cond_14
    sget-object v12, Lf66;->a:[I

    .line 673
    .line 674
    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    .line 675
    .line 676
    .line 677
    move-result v11

    .line 678
    aget v11, v12, v11

    .line 679
    .line 680
    :goto_9
    if-eq v11, v6, :cond_18

    .line 681
    .line 682
    if-eq v11, v10, :cond_17

    .line 683
    .line 684
    if-eq v11, v8, :cond_16

    .line 685
    .line 686
    if-eq v11, v7, :cond_15

    .line 687
    .line 688
    invoke-static {}, Lhh1;->a()V

    .line 689
    .line 690
    .line 691
    goto :goto_b

    .line 692
    :cond_15
    const-string v0, "SelectionContainer does not support cursor"

    .line 693
    .line 694
    invoke-static {v0}, Lzy1;->d(Ljava/lang/String;)V

    .line 695
    .line 696
    .line 697
    goto :goto_b

    .line 698
    :cond_16
    iget-object v3, v5, La56;->b:Lz46;

    .line 699
    .line 700
    invoke-static {v0, v1, v2, v3}, Lif0;->M(Le66;JLz46;)J

    .line 701
    .line 702
    .line 703
    move-result-wide v3

    .line 704
    goto :goto_a

    .line 705
    :cond_17
    iget-object v3, v5, La56;->a:Lz46;

    .line 706
    .line 707
    invoke-static {v0, v1, v2, v3}, Lif0;->M(Le66;JLz46;)J

    .line 708
    .line 709
    .line 710
    move-result-wide v3

    .line 711
    :cond_18
    :goto_a
    new-instance v9, Lkk4;

    .line 712
    .line 713
    invoke-direct {v9, v3, v4}, Lkk4;-><init>(J)V

    .line 714
    .line 715
    .line 716
    :goto_b
    return-object v9

    .line 717
    :pswitch_e
    check-cast v0, Lgj5;

    .line 718
    .line 719
    check-cast v13, Lw46;

    .line 720
    .line 721
    sget-object v1, Lcz4;->a:Lps1;

    .line 722
    .line 723
    invoke-static {v13, v1}, Lkn0;->G(Lu21;Ln55;)Ljava/lang/Object;

    .line 724
    .line 725
    .line 726
    move-result-object v1

    .line 727
    iput-object v1, v0, Lgj5;->i:Ljava/lang/Object;

    .line 728
    .line 729
    return-object v12

    .line 730
    :pswitch_f
    check-cast v0, Lzy5;

    .line 731
    .line 732
    check-cast v13, Lqn3;

    .line 733
    .line 734
    invoke-virtual {v0, v11}, Lzy5;->j(Z)V

    .line 735
    .line 736
    .line 737
    filled-new-array {v2}, [Ljava/lang/String;

    .line 738
    .line 739
    .line 740
    move-result-object v0

    .line 741
    invoke-virtual {v13, v0}, Lqn3;->S(Ljava/lang/Object;)V

    .line 742
    .line 743
    .line 744
    return-object v12

    .line 745
    :pswitch_10
    check-cast v0, Lth2;

    .line 746
    .line 747
    check-cast v13, Lgw5;

    .line 748
    .line 749
    check-cast v0, Lkz4;

    .line 750
    .line 751
    invoke-virtual {v0, v10}, Lkz4;->a(I)V

    .line 752
    .line 753
    .line 754
    invoke-virtual {v13}, Lgw5;->e()Ljava/lang/String;

    .line 755
    .line 756
    .line 757
    move-result-object v0

    .line 758
    invoke-virtual {v13}, Lgw5;->f()Ljava/util/List;

    .line 759
    .line 760
    .line 761
    move-result-object v1

    .line 762
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 763
    .line 764
    .line 765
    move-result v1

    .line 766
    invoke-virtual {v13}, Lgw5;->f()Ljava/util/List;

    .line 767
    .line 768
    .line 769
    move-result-object v2

    .line 770
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 771
    .line 772
    .line 773
    move-result v2

    .line 774
    xor-int/2addr v2, v10

    .line 775
    invoke-virtual {v13, v1, v2, v0}, Lgw5;->l(ZZLjava/lang/String;)V

    .line 776
    .line 777
    .line 778
    return-object v12

    .line 779
    :pswitch_11
    check-cast v0, Llu5;

    .line 780
    .line 781
    check-cast v13, Lzu0;

    .line 782
    .line 783
    invoke-virtual {v0, v13}, Llu5;->b(Lzu0;)V

    .line 784
    .line 785
    .line 786
    return-object v12

    .line 787
    :pswitch_12
    check-cast v0, Lh92;

    .line 788
    .line 789
    check-cast v13, Lhe6;

    .line 790
    .line 791
    invoke-interface {v0, v13}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 792
    .line 793
    .line 794
    return-object v12

    .line 795
    :pswitch_13
    check-cast v0, Lhe1;

    .line 796
    .line 797
    check-cast v13, Ljava/lang/String;

    .line 798
    .line 799
    new-instance v1, Lpv5;

    .line 800
    .line 801
    const/16 v2, 0x7fc

    .line 802
    .line 803
    invoke-direct {v1, v0, v13, v9, v2}, Lpv5;-><init>(Lhe1;Ljava/lang/String;Ljava/lang/String;I)V

    .line 804
    .line 805
    .line 806
    return-object v1

    .line 807
    :pswitch_14
    check-cast v0, Lup5;

    .line 808
    .line 809
    check-cast v13, Lh92;

    .line 810
    .line 811
    iget-object v0, v0, Lup5;->d:Ljd5;

    .line 812
    .line 813
    if-eqz v0, :cond_19

    .line 814
    .line 815
    invoke-interface {v13, v0}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 816
    .line 817
    .line 818
    :cond_19
    return-object v12

    .line 819
    :pswitch_15
    check-cast v0, Lgj5;

    .line 820
    .line 821
    check-cast v13, Lbe;

    .line 822
    .line 823
    iget-object v1, v13, Lbe;->x:Lbk1;

    .line 824
    .line 825
    invoke-virtual {v1}, Lbk1;->invoke()Ljava/lang/Object;

    .line 826
    .line 827
    .line 828
    move-result-object v1

    .line 829
    iput-object v1, v0, Lgj5;->i:Ljava/lang/Object;

    .line 830
    .line 831
    return-object v12

    .line 832
    :pswitch_16
    check-cast v0, Ldk5;

    .line 833
    .line 834
    check-cast v13, Ljava/lang/String;

    .line 835
    .line 836
    iget-object v0, v0, Ldk5;->i:Ljava/util/regex/Pattern;

    .line 837
    .line 838
    invoke-virtual {v0, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 839
    .line 840
    .line 841
    move-result-object v0

    .line 842
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 843
    .line 844
    .line 845
    invoke-static {v0, v11, v13}, Llc3;->A(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lxo3;

    .line 846
    .line 847
    .line 848
    move-result-object v0

    .line 849
    return-object v0

    .line 850
    :pswitch_17
    check-cast v0, Lw24;

    .line 851
    .line 852
    check-cast v13, Lt21;

    .line 853
    .line 854
    iget-object v1, v0, Lw24;->b:[Ljava/lang/Object;

    .line 855
    .line 856
    iget-object v0, v0, Lw24;->a:[J

    .line 857
    .line 858
    array-length v2, v0

    .line 859
    sub-int/2addr v2, v8

    .line 860
    if-ltz v2, :cond_1d

    .line 861
    .line 862
    move v3, v11

    .line 863
    :goto_c
    aget-wide v4, v0, v3

    .line 864
    .line 865
    not-long v6, v4

    .line 866
    const/4 v8, 0x7

    .line 867
    shl-long/2addr v6, v8

    .line 868
    and-long/2addr v6, v4

    .line 869
    const-wide v8, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    and-long/2addr v6, v8

    .line 875
    cmp-long v6, v6, v8

    .line 876
    .line 877
    if-eqz v6, :cond_1c

    .line 878
    .line 879
    sub-int v6, v3, v2

    .line 880
    .line 881
    not-int v6, v6

    .line 882
    ushr-int/lit8 v6, v6, 0x1f

    .line 883
    .line 884
    const/16 v7, 0x8

    .line 885
    .line 886
    rsub-int/lit8 v6, v6, 0x8

    .line 887
    .line 888
    move v8, v11

    .line 889
    :goto_d
    if-ge v8, v6, :cond_1b

    .line 890
    .line 891
    const-wide/16 v9, 0xff

    .line 892
    .line 893
    and-long/2addr v9, v4

    .line 894
    const-wide/16 v14, 0x80

    .line 895
    .line 896
    cmp-long v9, v9, v14

    .line 897
    .line 898
    if-gez v9, :cond_1a

    .line 899
    .line 900
    shl-int/lit8 v9, v3, 0x3

    .line 901
    .line 902
    add-int/2addr v9, v8

    .line 903
    aget-object v9, v1, v9

    .line 904
    .line 905
    invoke-virtual {v13, v9}, Lt21;->A(Ljava/lang/Object;)V

    .line 906
    .line 907
    .line 908
    :cond_1a
    shr-long/2addr v4, v7

    .line 909
    add-int/lit8 v8, v8, 0x1

    .line 910
    .line 911
    goto :goto_d

    .line 912
    :cond_1b
    if-ne v6, v7, :cond_1d

    .line 913
    .line 914
    :cond_1c
    if-eq v3, v2, :cond_1d

    .line 915
    .line 916
    add-int/lit8 v3, v3, 0x1

    .line 917
    .line 918
    goto :goto_c

    .line 919
    :cond_1d
    return-object v12

    .line 920
    :pswitch_18
    check-cast v0, Llk1;

    .line 921
    .line 922
    check-cast v13, Lcg5;

    .line 923
    .line 924
    iget-object v1, v13, Lcg5;->e:Lew4;

    .line 925
    .line 926
    invoke-virtual {v1}, Lew4;->g()F

    .line 927
    .line 928
    .line 929
    move-result v1

    .line 930
    iget v2, v13, Lcg5;->c:F

    .line 931
    .line 932
    sub-float/2addr v1, v2

    .line 933
    invoke-interface {v0, v1}, Llk1;->p1(F)F

    .line 934
    .line 935
    .line 936
    move-result v0

    .line 937
    new-instance v1, Lmo1;

    .line 938
    .line 939
    invoke-direct {v1, v0}, Lmo1;-><init>(F)V

    .line 940
    .line 941
    .line 942
    return-object v1

    .line 943
    :pswitch_19
    check-cast v0, Lcg5;

    .line 944
    .line 945
    check-cast v13, Ljava/util/List;

    .line 946
    .line 947
    invoke-virtual {v0}, Lcg5;->b()Lxj5;

    .line 948
    .line 949
    .line 950
    move-result-object v1

    .line 951
    sget-object v2, Lsj5;->a:Lsj5;

    .line 952
    .line 953
    invoke-static {v1, v2}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 954
    .line 955
    .line 956
    move-result v2

    .line 957
    const-string v3, ""

    .line 958
    .line 959
    if-nez v2, :cond_1f

    .line 960
    .line 961
    sget-object v2, Ltj5;->a:Ltj5;

    .line 962
    .line 963
    invoke-static {v1, v2}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 964
    .line 965
    .line 966
    move-result v2

    .line 967
    if-eqz v2, :cond_20

    .line 968
    .line 969
    invoke-virtual {v0}, Lcg5;->c()F

    .line 970
    .line 971
    .line 972
    move-result v0

    .line 973
    float-to-double v0, v0

    .line 974
    const-wide/high16 v4, 0x3fe0000000000000L    # 0.5

    .line 975
    .line 976
    cmpl-double v0, v0, v4

    .line 977
    .line 978
    if-lez v0, :cond_1f

    .line 979
    .line 980
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 981
    .line 982
    .line 983
    move-result v0

    .line 984
    if-lez v0, :cond_1e

    .line 985
    .line 986
    invoke-interface {v13, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 987
    .line 988
    .line 989
    move-result-object v3

    .line 990
    :cond_1e
    move-object v9, v3

    .line 991
    check-cast v9, Ljava/lang/String;

    .line 992
    .line 993
    goto :goto_e

    .line 994
    :cond_1f
    move-object v9, v3

    .line 995
    goto :goto_e

    .line 996
    :cond_20
    sget-object v0, Lwj5;->a:Lwj5;

    .line 997
    .line 998
    invoke-static {v1, v0}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 999
    .line 1000
    .line 1001
    move-result v0

    .line 1002
    if-eqz v0, :cond_22

    .line 1003
    .line 1004
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 1005
    .line 1006
    .line 1007
    move-result v0

    .line 1008
    if-ge v10, v0, :cond_21

    .line 1009
    .line 1010
    invoke-interface {v13, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1011
    .line 1012
    .line 1013
    move-result-object v3

    .line 1014
    :cond_21
    move-object v9, v3

    .line 1015
    check-cast v9, Ljava/lang/String;

    .line 1016
    .line 1017
    goto :goto_e

    .line 1018
    :cond_22
    sget-object v0, Lvj5;->a:Lvj5;

    .line 1019
    .line 1020
    invoke-static {v1, v0}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1021
    .line 1022
    .line 1023
    move-result v0

    .line 1024
    if-eqz v0, :cond_24

    .line 1025
    .line 1026
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 1027
    .line 1028
    .line 1029
    move-result v0

    .line 1030
    if-ge v8, v0, :cond_23

    .line 1031
    .line 1032
    invoke-interface {v13, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1033
    .line 1034
    .line 1035
    move-result-object v3

    .line 1036
    :cond_23
    move-object v9, v3

    .line 1037
    check-cast v9, Ljava/lang/String;

    .line 1038
    .line 1039
    goto :goto_e

    .line 1040
    :cond_24
    sget-object v0, Luj5;->a:Luj5;

    .line 1041
    .line 1042
    invoke-static {v1, v0}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1043
    .line 1044
    .line 1045
    move-result v0

    .line 1046
    if-eqz v0, :cond_26

    .line 1047
    .line 1048
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 1049
    .line 1050
    .line 1051
    move-result v0

    .line 1052
    if-ge v7, v0, :cond_25

    .line 1053
    .line 1054
    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v3

    .line 1058
    :cond_25
    move-object v9, v3

    .line 1059
    check-cast v9, Ljava/lang/String;

    .line 1060
    .line 1061
    goto :goto_e

    .line 1062
    :cond_26
    invoke-static {}, Lhh1;->a()V

    .line 1063
    .line 1064
    .line 1065
    :goto_e
    return-object v9

    .line 1066
    :pswitch_1a
    check-cast v0, Lh92;

    .line 1067
    .line 1068
    check-cast v13, Lxc5;

    .line 1069
    .line 1070
    invoke-interface {v0, v13}, Lh92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1071
    .line 1072
    .line 1073
    return-object v12

    .line 1074
    :pswitch_1b
    check-cast v0, Lx46;

    .line 1075
    .line 1076
    check-cast v13, Lsc3;

    .line 1077
    .line 1078
    if-eqz v0, :cond_2a

    .line 1079
    .line 1080
    invoke-virtual {v13}, Lsc3;->j()Lmc3;

    .line 1081
    .line 1082
    .line 1083
    move-result-object v1

    .line 1084
    iget v2, v0, Lx46;->c:I

    .line 1085
    .line 1086
    iget-object v3, v0, Lx46;->d:Ljava/lang/String;

    .line 1087
    .line 1088
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1089
    .line 1090
    .line 1091
    iget-object v4, v1, Lmc3;->l:Ljava/util/List;

    .line 1092
    .line 1093
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v4

    .line 1097
    :cond_27
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1098
    .line 1099
    .line 1100
    move-result v5

    .line 1101
    if-eqz v5, :cond_28

    .line 1102
    .line 1103
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1104
    .line 1105
    .line 1106
    move-result-object v5

    .line 1107
    move-object v6, v5

    .line 1108
    check-cast v6, Lnc3;

    .line 1109
    .line 1110
    iget v7, v6, Lnc3;->a:I

    .line 1111
    .line 1112
    if-ne v7, v2, :cond_27

    .line 1113
    .line 1114
    iget-object v6, v6, Lnc3;->i:Ljava/lang/Object;

    .line 1115
    .line 1116
    invoke-virtual {v6, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1117
    .line 1118
    .line 1119
    move-result v6

    .line 1120
    if-eqz v6, :cond_27

    .line 1121
    .line 1122
    goto :goto_f

    .line 1123
    :cond_28
    move-object v5, v9

    .line 1124
    :goto_f
    check-cast v5, Lnc3;

    .line 1125
    .line 1126
    if-eqz v5, :cond_29

    .line 1127
    .line 1128
    iget v2, v5, Lnc3;->l:I

    .line 1129
    .line 1130
    iget v3, v5, Lnc3;->m:I

    .line 1131
    .line 1132
    add-int/2addr v2, v3

    .line 1133
    iget v3, v1, Lmc3;->m:I

    .line 1134
    .line 1135
    invoke-static {v3, v11}, Ljava/lang/Math;->max(II)I

    .line 1136
    .line 1137
    .line 1138
    move-result v3

    .line 1139
    if-le v2, v3, :cond_29

    .line 1140
    .line 1141
    iget v2, v5, Lnc3;->l:I

    .line 1142
    .line 1143
    iget v1, v1, Lmc3;->n:I

    .line 1144
    .line 1145
    if-lt v2, v1, :cond_2a

    .line 1146
    .line 1147
    :cond_29
    move-object v9, v0

    .line 1148
    :cond_2a
    return-object v9

    .line 1149
    :pswitch_1c
    check-cast v0, Ll11;

    .line 1150
    .line 1151
    check-cast v13, Ll92;

    .line 1152
    .line 1153
    iput-object v13, v0, Ll11;->d:Ll92;

    .line 1154
    .line 1155
    return-object v12

    .line 1156
    nop

    .line 1157
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
