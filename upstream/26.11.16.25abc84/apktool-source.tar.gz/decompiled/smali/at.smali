.class public final synthetic Lat;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lnu;


# direct methods
.method public synthetic constructor <init>(Lnu;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lat;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lat;->j:Lnu;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lat;->i:B

    .line 4
    .line 5
    sget-object v2, Ld21;->a:Lq9;

    .line 6
    .line 7
    sget-object v3, Loc7;->a:Loc7;

    .line 8
    .line 9
    const/4 v4, 0x2

    .line 10
    iget-object v0, v0, Lat;->j:Lnu;

    .line 11
    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v6, 0x0

    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    move-object/from16 v1, p1

    .line 18
    .line 19
    check-cast v1, Lla2;

    .line 20
    .line 21
    move-object/from16 v7, p2

    .line 22
    .line 23
    check-cast v7, Ljava/lang/Integer;

    .line 24
    .line 25
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v7

    .line 29
    and-int/lit8 v8, v7, 0x3

    .line 30
    .line 31
    if-eq v8, v4, :cond_0

    .line 32
    .line 33
    move v6, v5

    .line 34
    :cond_0
    and-int/2addr v7, v5

    .line 35
    invoke-virtual {v1, v7, v6}, Lla2;->S(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eqz v4, :cond_9

    .line 40
    .line 41
    sget-object v4, Ljz3;->i:Ljz3;

    .line 42
    .line 43
    const/high16 v6, 0x3f800000    # 1.0f

    .line 44
    .line 45
    invoke-static {v4, v6}, Lef6;->d(Lmz3;F)Lmz3;

    .line 46
    .line 47
    .line 48
    move-result-object v7

    .line 49
    sget-object v8, Lr6;->x:Ll20;

    .line 50
    .line 51
    sget-object v9, Lba7;->d:Lpv;

    .line 52
    .line 53
    const/16 v10, 0x30

    .line 54
    .line 55
    invoke-static {v9, v8, v1, v10}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 56
    .line 57
    .line 58
    move-result-object v8

    .line 59
    iget-wide v9, v1, Lla2;->T:J

    .line 60
    .line 61
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 62
    .line 63
    .line 64
    move-result v9

    .line 65
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    invoke-static {v1, v7}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    sget-object v11, Lv11;->d:Lr6;

    .line 74
    .line 75
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v1}, Lla2;->e0()V

    .line 79
    .line 80
    .line 81
    iget-boolean v11, v1, Lla2;->S:Z

    .line 82
    .line 83
    sget-object v12, Lq83;->a0:Lif2;

    .line 84
    .line 85
    if-eqz v11, :cond_1

    .line 86
    .line 87
    invoke-virtual {v1, v12}, Lla2;->l(Lw82;)V

    .line 88
    .line 89
    .line 90
    goto :goto_0

    .line 91
    :cond_1
    invoke-virtual {v1}, Lla2;->n0()V

    .line 92
    .line 93
    .line 94
    :goto_0
    sget-object v11, Lr6;->S:La11;

    .line 95
    .line 96
    invoke-static {v11, v1, v8}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    sget-object v8, Lr6;->R:La11;

    .line 100
    .line 101
    invoke-static {v8, v1, v10}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v9

    .line 108
    sget-object v10, Lr6;->T:La11;

    .line 109
    .line 110
    invoke-static {v10, v1, v9}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {v1}, Lxt6;->k(Lla2;)V

    .line 114
    .line 115
    .line 116
    sget-object v9, Lr6;->Q:La11;

    .line 117
    .line 118
    invoke-static {v9, v1, v7}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    invoke-static {v4, v6}, Lef6;->d(Lmz3;F)Lmz3;

    .line 122
    .line 123
    .line 124
    move-result-object v13

    .line 125
    const/high16 v17, 0x41000000    # 8.0f

    .line 126
    .line 127
    const/16 v18, 0x7

    .line 128
    .line 129
    const/4 v14, 0x0

    .line 130
    const/4 v15, 0x0

    .line 131
    const/16 v16, 0x0

    .line 132
    .line 133
    invoke-static/range {v13 .. v18}, Lif0;->T(Lmz3;FFFFI)Lmz3;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    sget-object v13, Lba7;->h:Lq9;

    .line 138
    .line 139
    sget-object v14, Lr6;->t:Lm20;

    .line 140
    .line 141
    const/4 v15, 0x6

    .line 142
    invoke-static {v13, v14, v1, v15}, Lxo5;->a(Lqv;Lm20;Lla2;I)Lyo5;

    .line 143
    .line 144
    .line 145
    move-result-object v13

    .line 146
    iget-wide v14, v1, Lla2;->T:J

    .line 147
    .line 148
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 149
    .line 150
    .line 151
    move-result v14

    .line 152
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 153
    .line 154
    .line 155
    move-result-object v15

    .line 156
    invoke-static {v1, v7}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 157
    .line 158
    .line 159
    move-result-object v7

    .line 160
    invoke-virtual {v1}, Lla2;->e0()V

    .line 161
    .line 162
    .line 163
    iget-boolean v5, v1, Lla2;->S:Z

    .line 164
    .line 165
    if-eqz v5, :cond_2

    .line 166
    .line 167
    invoke-virtual {v1, v12}, Lla2;->l(Lw82;)V

    .line 168
    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_2
    invoke-virtual {v1}, Lla2;->n0()V

    .line 172
    .line 173
    .line 174
    :goto_1
    invoke-static {v11, v1, v13}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v8, v1, v15}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    invoke-static {v14, v1, v10, v1}, Lzi6;->y(ILla2;La11;Lla2;)V

    .line 181
    .line 182
    .line 183
    invoke-static {v9, v1, v7}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    const v5, 0x7f0f0051

    .line 187
    .line 188
    .line 189
    invoke-static {v5, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v7

    .line 193
    invoke-virtual {v1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v5

    .line 197
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v8

    .line 201
    if-nez v5, :cond_3

    .line 202
    .line 203
    if-ne v8, v2, :cond_4

    .line 204
    .line 205
    :cond_3
    new-instance v8, Lct;

    .line 206
    .line 207
    const/4 v5, 0x7

    .line 208
    invoke-direct {v8, v0, v5}, Lct;-><init>(Lnu;B)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v1, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    :cond_4
    check-cast v8, Lw82;

    .line 215
    .line 216
    new-instance v9, Lg93;

    .line 217
    .line 218
    const/4 v5, 0x1

    .line 219
    invoke-direct {v9, v6, v5}, Lg93;-><init>(FZ)V

    .line 220
    .line 221
    .line 222
    const/high16 v18, 0xc00000

    .line 223
    .line 224
    const/16 v19, 0xf78

    .line 225
    .line 226
    const/4 v10, 0x0

    .line 227
    const/4 v11, 0x0

    .line 228
    const/4 v12, 0x0

    .line 229
    const/4 v13, 0x0

    .line 230
    sget-object v14, Lqv3;->k:Lqv3;

    .line 231
    .line 232
    const/4 v15, 0x0

    .line 233
    const/16 v16, 0x0

    .line 234
    .line 235
    move-object/from16 v17, v1

    .line 236
    .line 237
    invoke-static/range {v7 .. v19}, Lta3;->c(Ljava/lang/String;Lw82;Lmz3;ZFFFLqv3;Lbt4;Ldw2;Lla2;II)V

    .line 238
    .line 239
    .line 240
    const/high16 v5, 0x41a00000    # 20.0f

    .line 241
    .line 242
    const v7, 0x7f0f0050

    .line 243
    .line 244
    .line 245
    invoke-static {v4, v5, v1, v7, v1}, Lzi6;->o(Ljz3;FLla2;ILla2;)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v7

    .line 249
    invoke-virtual {v1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 250
    .line 251
    .line 252
    move-result v5

    .line 253
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v8

    .line 257
    if-nez v5, :cond_5

    .line 258
    .line 259
    if-ne v8, v2, :cond_6

    .line 260
    .line 261
    :cond_5
    new-instance v8, Lct;

    .line 262
    .line 263
    const/16 v5, 0x8

    .line 264
    .line 265
    invoke-direct {v8, v0, v5}, Lct;-><init>(Lnu;B)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {v1, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 269
    .line 270
    .line 271
    :cond_6
    check-cast v8, Lw82;

    .line 272
    .line 273
    new-instance v9, Lg93;

    .line 274
    .line 275
    const/4 v5, 0x1

    .line 276
    invoke-direct {v9, v6, v5}, Lg93;-><init>(FZ)V

    .line 277
    .line 278
    .line 279
    const/high16 v18, 0xc00000

    .line 280
    .line 281
    const/16 v19, 0xf78

    .line 282
    .line 283
    const/4 v10, 0x0

    .line 284
    const/4 v11, 0x0

    .line 285
    const/4 v12, 0x0

    .line 286
    const/4 v13, 0x0

    .line 287
    sget-object v14, Lqv3;->j:Lqv3;

    .line 288
    .line 289
    const/4 v15, 0x0

    .line 290
    const/16 v16, 0x0

    .line 291
    .line 292
    move-object/from16 v17, v1

    .line 293
    .line 294
    invoke-static/range {v7 .. v19}, Lta3;->c(Ljava/lang/String;Lw82;Lmz3;ZFFFLqv3;Lbt4;Ldw2;Lla2;II)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v1, v5}, Lla2;->r(Z)V

    .line 298
    .line 299
    .line 300
    const/high16 v5, 0x41400000    # 12.0f

    .line 301
    .line 302
    invoke-static {v4, v5}, Lef6;->e(Lmz3;F)Lmz3;

    .line 303
    .line 304
    .line 305
    move-result-object v5

    .line 306
    invoke-static {v1, v5}, Llc3;->p(Lla2;Lmz3;)V

    .line 307
    .line 308
    .line 309
    const v5, 0x7f0f0033

    .line 310
    .line 311
    .line 312
    invoke-static {v5, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v7

    .line 316
    invoke-virtual {v1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 317
    .line 318
    .line 319
    move-result v5

    .line 320
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v8

    .line 324
    if-nez v5, :cond_7

    .line 325
    .line 326
    if-ne v8, v2, :cond_8

    .line 327
    .line 328
    :cond_7
    new-instance v8, Lct;

    .line 329
    .line 330
    const/16 v2, 0x9

    .line 331
    .line 332
    invoke-direct {v8, v0, v2}, Lct;-><init>(Lnu;B)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v1, v8}, Lla2;->k0(Ljava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    :cond_8
    check-cast v8, Lw82;

    .line 339
    .line 340
    invoke-static {v4, v6}, Lef6;->d(Lmz3;F)Lmz3;

    .line 341
    .line 342
    .line 343
    move-result-object v9

    .line 344
    const/16 v18, 0x180

    .line 345
    .line 346
    const/16 v19, 0xff8

    .line 347
    .line 348
    const/4 v10, 0x0

    .line 349
    const/4 v11, 0x0

    .line 350
    const/4 v12, 0x0

    .line 351
    const/4 v13, 0x0

    .line 352
    const/4 v14, 0x0

    .line 353
    const/4 v15, 0x0

    .line 354
    const/16 v16, 0x0

    .line 355
    .line 356
    move-object/from16 v17, v1

    .line 357
    .line 358
    invoke-static/range {v7 .. v19}, Lta3;->c(Ljava/lang/String;Lw82;Lmz3;ZFFFLqv3;Lbt4;Ldw2;Lla2;II)V

    .line 359
    .line 360
    .line 361
    const/4 v5, 0x1

    .line 362
    invoke-virtual {v1, v5}, Lla2;->r(Z)V

    .line 363
    .line 364
    .line 365
    goto :goto_2

    .line 366
    :cond_9
    invoke-virtual {v1}, Lla2;->V()V

    .line 367
    .line 368
    .line 369
    :goto_2
    return-object v3

    .line 370
    :pswitch_0
    move-object/from16 v11, p1

    .line 371
    .line 372
    check-cast v11, Lla2;

    .line 373
    .line 374
    move-object/from16 v1, p2

    .line 375
    .line 376
    check-cast v1, Ljava/lang/Integer;

    .line 377
    .line 378
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 379
    .line 380
    .line 381
    move-result v1

    .line 382
    and-int/lit8 v2, v1, 0x3

    .line 383
    .line 384
    if-eq v2, v4, :cond_a

    .line 385
    .line 386
    const/4 v2, 0x1

    .line 387
    :goto_3
    const/4 v5, 0x1

    .line 388
    goto :goto_4

    .line 389
    :cond_a
    move v2, v6

    .line 390
    goto :goto_3

    .line 391
    :goto_4
    and-int/2addr v1, v5

    .line 392
    invoke-virtual {v11, v1, v2}, Lla2;->S(IZ)Z

    .line 393
    .line 394
    .line 395
    move-result v1

    .line 396
    if-eqz v1, :cond_c

    .line 397
    .line 398
    invoke-static {}, Lta3;->s()Ldv2;

    .line 399
    .line 400
    .line 401
    move-result-object v1

    .line 402
    const v2, 0x7f0f00ce

    .line 403
    .line 404
    .line 405
    invoke-static {v2, v11}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v7

    .line 409
    invoke-virtual {v0}, Lnu;->f()Z

    .line 410
    .line 411
    .line 412
    move-result v0

    .line 413
    if-eqz v0, :cond_b

    .line 414
    .line 415
    const v0, -0x48fa26e2

    .line 416
    .line 417
    .line 418
    invoke-virtual {v11, v0}, Lla2;->b0(I)V

    .line 419
    .line 420
    .line 421
    sget-object v0, Lbx0;->a:Lps1;

    .line 422
    .line 423
    invoke-virtual {v11, v0}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    check-cast v0, Lax0;

    .line 428
    .line 429
    invoke-virtual {v0}, Lax0;->o()J

    .line 430
    .line 431
    .line 432
    move-result-wide v4

    .line 433
    invoke-virtual {v11, v6}, Lla2;->r(Z)V

    .line 434
    .line 435
    .line 436
    :goto_5
    move-wide v9, v4

    .line 437
    goto :goto_6

    .line 438
    :cond_b
    const v0, -0x48fa1ce0

    .line 439
    .line 440
    .line 441
    invoke-virtual {v11, v0}, Lla2;->b0(I)V

    .line 442
    .line 443
    .line 444
    sget-object v0, Lbx0;->a:Lps1;

    .line 445
    .line 446
    invoke-virtual {v11, v0}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 447
    .line 448
    .line 449
    move-result-object v0

    .line 450
    check-cast v0, Lax0;

    .line 451
    .line 452
    invoke-virtual {v0}, Lax0;->i()J

    .line 453
    .line 454
    .line 455
    move-result-wide v4

    .line 456
    invoke-virtual {v11, v6}, Lla2;->r(Z)V

    .line 457
    .line 458
    .line 459
    goto :goto_5

    .line 460
    :goto_6
    const/4 v12, 0x0

    .line 461
    const/4 v13, 0x4

    .line 462
    const/4 v8, 0x0

    .line 463
    move-object v6, v1

    .line 464
    invoke-static/range {v6 .. v13}, Lyy3;->a(Ldv2;Ljava/lang/String;Lmz3;JLla2;II)V

    .line 465
    .line 466
    .line 467
    goto :goto_7

    .line 468
    :cond_c
    invoke-virtual {v11}, Lla2;->V()V

    .line 469
    .line 470
    .line 471
    :goto_7
    return-object v3

    .line 472
    :pswitch_1
    move-object/from16 v1, p1

    .line 473
    .line 474
    check-cast v1, Lla2;

    .line 475
    .line 476
    move-object/from16 v5, p2

    .line 477
    .line 478
    check-cast v5, Ljava/lang/Integer;

    .line 479
    .line 480
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 481
    .line 482
    .line 483
    move-result v5

    .line 484
    and-int/lit8 v7, v5, 0x3

    .line 485
    .line 486
    if-eq v7, v4, :cond_d

    .line 487
    .line 488
    const/4 v4, 0x1

    .line 489
    :goto_8
    const/4 v7, 0x1

    .line 490
    goto :goto_9

    .line 491
    :cond_d
    move v4, v6

    .line 492
    goto :goto_8

    .line 493
    :goto_9
    and-int/2addr v5, v7

    .line 494
    invoke-virtual {v1, v5, v4}, Lla2;->S(IZ)Z

    .line 495
    .line 496
    .line 497
    move-result v4

    .line 498
    if-eqz v4, :cond_10

    .line 499
    .line 500
    invoke-virtual {v1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 501
    .line 502
    .line 503
    move-result v4

    .line 504
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    move-result-object v5

    .line 508
    if-nez v4, :cond_e

    .line 509
    .line 510
    if-ne v5, v2, :cond_f

    .line 511
    .line 512
    :cond_e
    new-instance v5, Lct;

    .line 513
    .line 514
    invoke-direct {v5, v0, v6}, Lct;-><init>(Lnu;B)V

    .line 515
    .line 516
    .line 517
    invoke-virtual {v1, v5}, Lla2;->k0(Ljava/lang/Object;)V

    .line 518
    .line 519
    .line 520
    :cond_f
    move-object v12, v5

    .line 521
    check-cast v12, Lw82;

    .line 522
    .line 523
    sget-object v18, Lf13;->o:Lyz0;

    .line 524
    .line 525
    const/high16 v20, 0x30000000

    .line 526
    .line 527
    const/16 v21, 0x1fe

    .line 528
    .line 529
    const/4 v13, 0x0

    .line 530
    const/4 v14, 0x0

    .line 531
    const/4 v15, 0x0

    .line 532
    const/16 v16, 0x0

    .line 533
    .line 534
    const/16 v17, 0x0

    .line 535
    .line 536
    move-object/from16 v19, v1

    .line 537
    .line 538
    invoke-static/range {v12 .. v21}, Lln;->l(Lw82;Lmz3;ZLw96;Lkf0;Lbt4;Lm92;Lla2;II)V

    .line 539
    .line 540
    .line 541
    goto :goto_a

    .line 542
    :cond_10
    move-object/from16 v19, v1

    .line 543
    .line 544
    invoke-virtual/range {v19 .. v19}, Lla2;->V()V

    .line 545
    .line 546
    .line 547
    :goto_a
    return-object v3

    .line 548
    :pswitch_2
    move-object/from16 v11, p1

    .line 549
    .line 550
    check-cast v11, Lla2;

    .line 551
    .line 552
    move-object/from16 v1, p2

    .line 553
    .line 554
    check-cast v1, Ljava/lang/Integer;

    .line 555
    .line 556
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 557
    .line 558
    .line 559
    move-result v1

    .line 560
    and-int/lit8 v5, v1, 0x3

    .line 561
    .line 562
    if-eq v5, v4, :cond_11

    .line 563
    .line 564
    const/4 v6, 0x1

    .line 565
    :cond_11
    const/4 v5, 0x1

    .line 566
    and-int/2addr v1, v5

    .line 567
    invoke-virtual {v11, v1, v6}, Lla2;->S(IZ)Z

    .line 568
    .line 569
    .line 570
    move-result v1

    .line 571
    if-eqz v1, :cond_14

    .line 572
    .line 573
    invoke-virtual {v11, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 574
    .line 575
    .line 576
    move-result v1

    .line 577
    invoke-virtual {v11}, Lla2;->N()Ljava/lang/Object;

    .line 578
    .line 579
    .line 580
    move-result-object v4

    .line 581
    if-nez v1, :cond_12

    .line 582
    .line 583
    if-ne v4, v2, :cond_13

    .line 584
    .line 585
    :cond_12
    new-instance v4, Lct;

    .line 586
    .line 587
    invoke-direct {v4, v0, v5}, Lct;-><init>(Lnu;B)V

    .line 588
    .line 589
    .line 590
    invoke-virtual {v11, v4}, Lla2;->k0(Ljava/lang/Object;)V

    .line 591
    .line 592
    .line 593
    :cond_13
    check-cast v4, Lw82;

    .line 594
    .line 595
    sget-object v10, Lf13;->n:Lyz0;

    .line 596
    .line 597
    const/high16 v12, 0x30000000

    .line 598
    .line 599
    const/16 v13, 0x1fe

    .line 600
    .line 601
    const/4 v5, 0x0

    .line 602
    const/4 v6, 0x0

    .line 603
    const/4 v7, 0x0

    .line 604
    const/4 v8, 0x0

    .line 605
    const/4 v9, 0x0

    .line 606
    invoke-static/range {v4 .. v13}, Lln;->l(Lw82;Lmz3;ZLw96;Lkf0;Lbt4;Lm92;Lla2;II)V

    .line 607
    .line 608
    .line 609
    goto :goto_b

    .line 610
    :cond_14
    invoke-virtual {v11}, Lla2;->V()V

    .line 611
    .line 612
    .line 613
    :goto_b
    return-object v3

    .line 614
    :pswitch_3
    move-object/from16 v1, p1

    .line 615
    .line 616
    check-cast v1, Lla2;

    .line 617
    .line 618
    move-object/from16 v5, p2

    .line 619
    .line 620
    check-cast v5, Ljava/lang/Integer;

    .line 621
    .line 622
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 623
    .line 624
    .line 625
    move-result v5

    .line 626
    and-int/lit8 v7, v5, 0x3

    .line 627
    .line 628
    if-eq v7, v4, :cond_15

    .line 629
    .line 630
    const/4 v4, 0x1

    .line 631
    :goto_c
    const/4 v7, 0x1

    .line 632
    goto :goto_d

    .line 633
    :cond_15
    move v4, v6

    .line 634
    goto :goto_c

    .line 635
    :goto_d
    and-int/2addr v5, v7

    .line 636
    invoke-virtual {v1, v5, v4}, Lla2;->S(IZ)Z

    .line 637
    .line 638
    .line 639
    move-result v4

    .line 640
    if-eqz v4, :cond_19

    .line 641
    .line 642
    iget-object v4, v0, Lnu;->b:Lb34;

    .line 643
    .line 644
    invoke-interface {v4}, Lok6;->getValue()Ljava/lang/Object;

    .line 645
    .line 646
    .line 647
    move-result-object v4

    .line 648
    check-cast v4, Ljava/lang/String;

    .line 649
    .line 650
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 651
    .line 652
    .line 653
    move-result v4

    .line 654
    if-lez v4, :cond_18

    .line 655
    .line 656
    const v4, 0x3c9ab739

    .line 657
    .line 658
    .line 659
    invoke-virtual {v1, v4}, Lla2;->b0(I)V

    .line 660
    .line 661
    .line 662
    invoke-virtual {v1, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 663
    .line 664
    .line 665
    move-result v4

    .line 666
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v5

    .line 670
    if-nez v4, :cond_16

    .line 671
    .line 672
    if-ne v5, v2, :cond_17

    .line 673
    .line 674
    :cond_16
    new-instance v5, Lct;

    .line 675
    .line 676
    const/4 v2, 0x4

    .line 677
    invoke-direct {v5, v0, v2}, Lct;-><init>(Lnu;B)V

    .line 678
    .line 679
    .line 680
    invoke-virtual {v1, v5}, Lla2;->k0(Ljava/lang/Object;)V

    .line 681
    .line 682
    .line 683
    :cond_17
    move-object v12, v5

    .line 684
    check-cast v12, Lw82;

    .line 685
    .line 686
    sget-object v17, Lf13;->k:Lyz0;

    .line 687
    .line 688
    const/high16 v19, 0x180000

    .line 689
    .line 690
    const/16 v20, 0x3e

    .line 691
    .line 692
    const/4 v13, 0x0

    .line 693
    const/4 v14, 0x0

    .line 694
    const/4 v15, 0x0

    .line 695
    const/16 v16, 0x0

    .line 696
    .line 697
    move-object/from16 v18, v1

    .line 698
    .line 699
    invoke-static/range {v12 .. v20}, Loq;->p(Lw82;Lmz3;ZLdu2;Lw96;Ll92;Lla2;II)V

    .line 700
    .line 701
    .line 702
    move-object/from16 v0, v18

    .line 703
    .line 704
    invoke-virtual {v0, v6}, Lla2;->r(Z)V

    .line 705
    .line 706
    .line 707
    goto :goto_e

    .line 708
    :cond_18
    move-object v0, v1

    .line 709
    const v1, 0x3ca0dfdd

    .line 710
    .line 711
    .line 712
    invoke-virtual {v0, v1}, Lla2;->b0(I)V

    .line 713
    .line 714
    .line 715
    invoke-virtual {v0, v6}, Lla2;->r(Z)V

    .line 716
    .line 717
    .line 718
    goto :goto_e

    .line 719
    :cond_19
    move-object v0, v1

    .line 720
    invoke-virtual {v0}, Lla2;->V()V

    .line 721
    .line 722
    .line 723
    :goto_e
    return-object v3

    .line 724
    :pswitch_4
    move-object/from16 v13, p1

    .line 725
    .line 726
    check-cast v13, Lla2;

    .line 727
    .line 728
    move-object/from16 v1, p2

    .line 729
    .line 730
    check-cast v1, Ljava/lang/Integer;

    .line 731
    .line 732
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 733
    .line 734
    .line 735
    move-result v1

    .line 736
    and-int/lit8 v5, v1, 0x3

    .line 737
    .line 738
    if-eq v5, v4, :cond_1a

    .line 739
    .line 740
    const/4 v5, 0x1

    .line 741
    :goto_f
    const/4 v7, 0x1

    .line 742
    goto :goto_10

    .line 743
    :cond_1a
    move v5, v6

    .line 744
    goto :goto_f

    .line 745
    :goto_10
    and-int/2addr v1, v7

    .line 746
    invoke-virtual {v13, v1, v5}, Lla2;->S(IZ)Z

    .line 747
    .line 748
    .line 749
    move-result v1

    .line 750
    if-eqz v1, :cond_1d

    .line 751
    .line 752
    const v1, 0x7f0f004b

    .line 753
    .line 754
    .line 755
    invoke-static {v1, v13}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 756
    .line 757
    .line 758
    move-result-object v7

    .line 759
    iget-object v1, v0, Lnu;->d:Lb34;

    .line 760
    .line 761
    invoke-interface {v1}, Lok6;->getValue()Ljava/lang/Object;

    .line 762
    .line 763
    .line 764
    move-result-object v1

    .line 765
    check-cast v1, Ljava/lang/Boolean;

    .line 766
    .line 767
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 768
    .line 769
    .line 770
    move-result v10

    .line 771
    invoke-virtual {v13, v0}, Lla2;->g(Ljava/lang/Object;)Z

    .line 772
    .line 773
    .line 774
    move-result v1

    .line 775
    invoke-virtual {v13}, Lla2;->N()Ljava/lang/Object;

    .line 776
    .line 777
    .line 778
    move-result-object v4

    .line 779
    if-nez v1, :cond_1b

    .line 780
    .line 781
    if-ne v4, v2, :cond_1c

    .line 782
    .line 783
    :cond_1b
    new-instance v4, Lht;

    .line 784
    .line 785
    invoke-direct {v4, v0, v6}, Lht;-><init>(Lnu;B)V

    .line 786
    .line 787
    .line 788
    invoke-virtual {v13, v4}, Lla2;->k0(Ljava/lang/Object;)V

    .line 789
    .line 790
    .line 791
    :cond_1c
    move-object v12, v4

    .line 792
    check-cast v12, Lh92;

    .line 793
    .line 794
    const/4 v14, 0x0

    .line 795
    const/16 v15, 0x2e

    .line 796
    .line 797
    const/4 v8, 0x0

    .line 798
    const/4 v9, 0x0

    .line 799
    const/4 v11, 0x0

    .line 800
    invoke-static/range {v7 .. v15}, Lvp3;->h(Ljava/lang/String;Ljava/lang/String;Ldv2;ZZLh92;Lla2;II)V

    .line 801
    .line 802
    .line 803
    goto :goto_11

    .line 804
    :cond_1d
    invoke-virtual {v13}, Lla2;->V()V

    .line 805
    .line 806
    .line 807
    :goto_11
    return-object v3

    .line 808
    nop

    .line 809
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
