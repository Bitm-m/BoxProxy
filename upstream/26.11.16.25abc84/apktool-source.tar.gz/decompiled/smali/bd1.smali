.class public final synthetic Lbd1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lb34;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Lt92;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lb34;Lh92;Lb34;Lh92;Ljava/util/ArrayList;Ljava/util/ArrayList;Lfw4;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lbd1;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lbd1;->j:Lb34;

    .line 8
    .line 9
    iput-object p2, p0, Lbd1;->k:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lbd1;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lbd1;->m:Lt92;

    .line 14
    .line 15
    iput-object p5, p0, Lbd1;->n:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lbd1;->o:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p7, p0, Lbd1;->p:Ljava/lang/Object;

    .line 20
    .line 21
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Lw82;Lb34;Ljava/util/List;Ljava/util/List;Ll92;Lh92;)V
    .locals 1

    .line 23
    const/4 v0, 0x1

    iput-byte v0, p0, Lbd1;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbd1;->l:Ljava/lang/Object;

    iput-object p2, p0, Lbd1;->m:Lt92;

    iput-object p3, p0, Lbd1;->j:Lb34;

    iput-object p4, p0, Lbd1;->n:Ljava/lang/Object;

    iput-object p5, p0, Lbd1;->o:Ljava/lang/Object;

    iput-object p6, p0, Lbd1;->p:Ljava/lang/Object;

    iput-object p7, p0, Lbd1;->k:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lsv5;Lw82;Lc62;Lb34;Lb34;Lb34;Lb34;)V
    .locals 1

    .line 22
    const/4 v0, 0x2

    iput-byte v0, p0, Lbd1;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbd1;->k:Ljava/lang/Object;

    iput-object p2, p0, Lbd1;->m:Lt92;

    iput-object p3, p0, Lbd1;->n:Ljava/lang/Object;

    iput-object p4, p0, Lbd1;->j:Lb34;

    iput-object p5, p0, Lbd1;->l:Ljava/lang/Object;

    iput-object p6, p0, Lbd1;->o:Ljava/lang/Object;

    iput-object p7, p0, Lbd1;->p:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 40

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbd1;->i:B

    .line 4
    .line 5
    sget-object v3, Lq83;->a0:Lif2;

    .line 6
    .line 7
    sget-object v4, Ld21;->a:Lq9;

    .line 8
    .line 9
    iget-object v5, v0, Lbd1;->j:Lb34;

    .line 10
    .line 11
    const/high16 v6, 0x3f800000    # 1.0f

    .line 12
    .line 13
    sget-object v7, Loc7;->a:Loc7;

    .line 14
    .line 15
    sget-object v8, Ljz3;->i:Ljz3;

    .line 16
    .line 17
    iget-object v9, v0, Lbd1;->p:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v10, v0, Lbd1;->o:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v11, v0, Lbd1;->l:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v12, v0, Lbd1;->n:Ljava/lang/Object;

    .line 24
    .line 25
    iget-object v13, v0, Lbd1;->m:Lt92;

    .line 26
    .line 27
    iget-object v14, v0, Lbd1;->k:Ljava/lang/Object;

    .line 28
    .line 29
    const/16 v15, 0x10

    .line 30
    .line 31
    const/16 v16, 0x1

    .line 32
    .line 33
    packed-switch v1, :pswitch_data_0

    .line 34
    .line 35
    .line 36
    check-cast v14, Lsv5;

    .line 37
    .line 38
    check-cast v13, Lw82;

    .line 39
    .line 40
    check-cast v12, Lc62;

    .line 41
    .line 42
    check-cast v11, Lb34;

    .line 43
    .line 44
    check-cast v10, Lb34;

    .line 45
    .line 46
    check-cast v9, Lb34;

    .line 47
    .line 48
    move-object/from16 v0, p1

    .line 49
    .line 50
    check-cast v0, Lsh;

    .line 51
    .line 52
    move-object/from16 v1, p2

    .line 53
    .line 54
    check-cast v1, Lla2;

    .line 55
    .line 56
    move-object/from16 v17, p3

    .line 57
    .line 58
    check-cast v17, Ljava/lang/Integer;

    .line 59
    .line 60
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Integer;->intValue()I

    .line 61
    .line 62
    .line 63
    move-result v17

    .line 64
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    and-int/lit8 v0, v17, 0x11

    .line 68
    .line 69
    if-eq v0, v15, :cond_0

    .line 70
    .line 71
    move/from16 v0, v16

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_0
    const/4 v0, 0x0

    .line 75
    :goto_0
    and-int/lit8 v15, v17, 0x1

    .line 76
    .line 77
    invoke-virtual {v1, v15, v0}, Lla2;->S(IZ)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-eqz v0, :cond_11

    .line 82
    .line 83
    invoke-static {v8, v6}, Lef6;->d(Lmz3;F)Lmz3;

    .line 84
    .line 85
    .line 86
    move-result-object v17

    .line 87
    const/16 v22, 0x2

    .line 88
    .line 89
    const/high16 v18, 0x41400000    # 12.0f

    .line 90
    .line 91
    const/16 v19, 0x0

    .line 92
    .line 93
    const/high16 v21, 0x41000000    # 8.0f

    .line 94
    .line 95
    move/from16 v20, v18

    .line 96
    .line 97
    invoke-static/range {v17 .. v22}, Lif0;->T(Lmz3;FFFFI)Lmz3;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    move/from16 v15, v21

    .line 102
    .line 103
    new-instance v2, Lrv;

    .line 104
    .line 105
    new-instance v6, Lzy1;

    .line 106
    .line 107
    move-object/from16 v39, v7

    .line 108
    .line 109
    const/4 v7, 0x3

    .line 110
    invoke-direct {v6, v7}, Lzy1;-><init>(B)V

    .line 111
    .line 112
    .line 113
    move/from16 v7, v16

    .line 114
    .line 115
    invoke-direct {v2, v15, v7, v6}, Lrv;-><init>(FZLzy1;)V

    .line 116
    .line 117
    .line 118
    sget-object v6, Lr6;->w:Ll20;

    .line 119
    .line 120
    const/4 v7, 0x6

    .line 121
    invoke-static {v2, v6, v1, v7}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    iget-wide v6, v1, Lla2;->T:J

    .line 126
    .line 127
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 128
    .line 129
    .line 130
    move-result v6

    .line 131
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 132
    .line 133
    .line 134
    move-result-object v7

    .line 135
    invoke-static {v1, v0}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    sget-object v18, Lv11;->d:Lr6;

    .line 140
    .line 141
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v1}, Lla2;->e0()V

    .line 145
    .line 146
    .line 147
    iget-boolean v15, v1, Lla2;->S:Z

    .line 148
    .line 149
    if-eqz v15, :cond_1

    .line 150
    .line 151
    invoke-virtual {v1, v3}, Lla2;->l(Lw82;)V

    .line 152
    .line 153
    .line 154
    goto :goto_1

    .line 155
    :cond_1
    invoke-virtual {v1}, Lla2;->n0()V

    .line 156
    .line 157
    .line 158
    :goto_1
    sget-object v15, Lr6;->S:La11;

    .line 159
    .line 160
    invoke-static {v15, v1, v2}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    sget-object v2, Lr6;->R:La11;

    .line 164
    .line 165
    invoke-static {v2, v1, v7}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 169
    .line 170
    .line 171
    move-result-object v6

    .line 172
    sget-object v7, Lr6;->T:La11;

    .line 173
    .line 174
    invoke-static {v7, v1, v6}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    invoke-static {v1}, Lxt6;->k(Lla2;)V

    .line 178
    .line 179
    .line 180
    sget-object v6, Lr6;->Q:La11;

    .line 181
    .line 182
    invoke-static {v6, v1, v0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    const/high16 v0, 0x3f800000    # 1.0f

    .line 186
    .line 187
    invoke-static {v8, v0}, Lef6;->d(Lmz3;F)Lmz3;

    .line 188
    .line 189
    .line 190
    move-result-object v8

    .line 191
    new-instance v0, Lrv;

    .line 192
    .line 193
    move-object/from16 v32, v9

    .line 194
    .line 195
    new-instance v9, Lzy1;

    .line 196
    .line 197
    move-object/from16 v18, v11

    .line 198
    .line 199
    const/4 v11, 0x3

    .line 200
    invoke-direct {v9, v11}, Lzy1;-><init>(B)V

    .line 201
    .line 202
    .line 203
    move-object/from16 v33, v5

    .line 204
    .line 205
    const/high16 v5, 0x41000000    # 8.0f

    .line 206
    .line 207
    const/4 v11, 0x1

    .line 208
    invoke-direct {v0, v5, v11, v9}, Lrv;-><init>(FZLzy1;)V

    .line 209
    .line 210
    .line 211
    sget-object v5, Lr6;->u:Lm20;

    .line 212
    .line 213
    const/16 v9, 0x36

    .line 214
    .line 215
    invoke-static {v0, v5, v1, v9}, Lxo5;->a(Lqv;Lm20;Lla2;I)Lyo5;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    move-object/from16 p0, v10

    .line 220
    .line 221
    iget-wide v9, v1, Lla2;->T:J

    .line 222
    .line 223
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 224
    .line 225
    .line 226
    move-result v5

    .line 227
    invoke-virtual {v1}, Lla2;->m()Lky4;

    .line 228
    .line 229
    .line 230
    move-result-object v9

    .line 231
    invoke-static {v1, v8}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 232
    .line 233
    .line 234
    move-result-object v8

    .line 235
    invoke-virtual {v1}, Lla2;->e0()V

    .line 236
    .line 237
    .line 238
    iget-boolean v10, v1, Lla2;->S:Z

    .line 239
    .line 240
    if-eqz v10, :cond_2

    .line 241
    .line 242
    invoke-virtual {v1, v3}, Lla2;->l(Lw82;)V

    .line 243
    .line 244
    .line 245
    goto :goto_2

    .line 246
    :cond_2
    invoke-virtual {v1}, Lla2;->n0()V

    .line 247
    .line 248
    .line 249
    :goto_2
    invoke-static {v15, v1, v0}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    invoke-static {v2, v1, v9}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    invoke-static {v5, v1, v7, v1}, Lzi6;->y(ILla2;La11;Lla2;)V

    .line 256
    .line 257
    .line 258
    invoke-static {v6, v1, v8}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    invoke-interface/range {v33 .. v33}, Lok6;->getValue()Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v0

    .line 265
    check-cast v0, Ljava/lang/String;

    .line 266
    .line 267
    invoke-virtual {v1, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    move-result v2

    .line 271
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    move-result-object v3

    .line 275
    if-nez v2, :cond_3

    .line 276
    .line 277
    if-ne v3, v4, :cond_4

    .line 278
    .line 279
    :cond_3
    new-instance v3, Lyu5;

    .line 280
    .line 281
    const/4 v7, 0x1

    .line 282
    invoke-direct {v3, v14, v7}, Lyu5;-><init>(Lsv5;B)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v1, v3}, Lla2;->k0(Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    :cond_4
    check-cast v3, Lh92;

    .line 289
    .line 290
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v2

    .line 294
    if-ne v2, v4, :cond_5

    .line 295
    .line 296
    new-instance v2, Liv5;

    .line 297
    .line 298
    const/4 v5, 0x0

    .line 299
    invoke-direct {v2, v5}, Liv5;-><init>(B)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v1, v2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 303
    .line 304
    .line 305
    :cond_5
    move-object/from16 v19, v2

    .line 306
    .line 307
    check-cast v19, Lh92;

    .line 308
    .line 309
    invoke-interface/range {v18 .. v18}, Lok6;->getValue()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v2

    .line 313
    check-cast v2, Ljava/lang/Boolean;

    .line 314
    .line 315
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 316
    .line 317
    .line 318
    move-result v20

    .line 319
    invoke-virtual {v1, v13}, Lla2;->g(Ljava/lang/Object;)Z

    .line 320
    .line 321
    .line 322
    move-result v2

    .line 323
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v5

    .line 327
    if-nez v2, :cond_6

    .line 328
    .line 329
    if-ne v5, v4, :cond_7

    .line 330
    .line 331
    :cond_6
    new-instance v5, Lr75;

    .line 332
    .line 333
    const/4 v2, 0x4

    .line 334
    invoke-direct {v5, v13, v2}, Lr75;-><init>(Lw82;B)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v1, v5}, Lla2;->k0(Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    :cond_7
    move-object/from16 v21, v5

    .line 341
    .line 342
    check-cast v21, Lh92;

    .line 343
    .line 344
    new-instance v2, Lg93;

    .line 345
    .line 346
    const/high16 v5, 0x3f800000    # 1.0f

    .line 347
    .line 348
    const/4 v7, 0x1

    .line 349
    invoke-direct {v2, v5, v7}, Lg93;-><init>(FZ)V

    .line 350
    .line 351
    .line 352
    invoke-static {v2, v12}, Lfw;->G(Lmz3;Lc62;)Lmz3;

    .line 353
    .line 354
    .line 355
    move-result-object v22

    .line 356
    const v2, 0x7f0f040e

    .line 357
    .line 358
    .line 359
    invoke-static {v2, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v23

    .line 363
    const/16 v30, 0x0

    .line 364
    .line 365
    const/16 v31, 0x1f80

    .line 366
    .line 367
    const/16 v24, 0x0

    .line 368
    .line 369
    const-wide/16 v25, 0x0

    .line 370
    .line 371
    const/16 v27, 0x0

    .line 372
    .line 373
    const/16 v29, 0x180

    .line 374
    .line 375
    move-object/from16 v17, v0

    .line 376
    .line 377
    move-object/from16 v28, v1

    .line 378
    .line 379
    move-object/from16 v18, v3

    .line 380
    .line 381
    invoke-static/range {v17 .. v31}, Lho3;->b(Ljava/lang/String;Lh92;Lh92;ZLh92;Lmz3;Ljava/lang/String;ZJLb24;Lla2;III)V

    .line 382
    .line 383
    .line 384
    move-object/from16 v0, v28

    .line 385
    .line 386
    invoke-virtual {v0, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 387
    .line 388
    .line 389
    move-result v1

    .line 390
    invoke-virtual {v0}, Lla2;->N()Ljava/lang/Object;

    .line 391
    .line 392
    .line 393
    move-result-object v2

    .line 394
    if-nez v1, :cond_8

    .line 395
    .line 396
    if-ne v2, v4, :cond_9

    .line 397
    .line 398
    :cond_8
    new-instance v17, Lev5;

    .line 399
    .line 400
    const/16 v23, 0x0

    .line 401
    .line 402
    const/16 v24, 0x4

    .line 403
    .line 404
    const/16 v18, 0x0

    .line 405
    .line 406
    const-class v20, Lsv5;

    .line 407
    .line 408
    const-string v21, "goToPreviousMatch"

    .line 409
    .line 410
    const-string v22, "goToPreviousMatch()V"

    .line 411
    .line 412
    move-object/from16 v19, v14

    .line 413
    .line 414
    invoke-direct/range {v17 .. v24}, Lev5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 415
    .line 416
    .line 417
    move-object/from16 v2, v17

    .line 418
    .line 419
    invoke-virtual {v0, v2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 420
    .line 421
    .line 422
    :cond_9
    check-cast v2, Ln53;

    .line 423
    .line 424
    move-object/from16 v17, v2

    .line 425
    .line 426
    check-cast v17, Lw82;

    .line 427
    .line 428
    invoke-interface/range {p0 .. p0}, Lok6;->getValue()Ljava/lang/Object;

    .line 429
    .line 430
    .line 431
    move-result-object v1

    .line 432
    check-cast v1, Ljava/lang/Number;

    .line 433
    .line 434
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 435
    .line 436
    .line 437
    move-result v1

    .line 438
    if-lez v1, :cond_a

    .line 439
    .line 440
    const/16 v19, 0x1

    .line 441
    .line 442
    goto :goto_3

    .line 443
    :cond_a
    const/16 v19, 0x0

    .line 444
    .line 445
    :goto_3
    new-instance v1, Ltb;

    .line 446
    .line 447
    const/16 v2, 0x14

    .line 448
    .line 449
    move-object/from16 v10, p0

    .line 450
    .line 451
    invoke-direct {v1, v10, v2}, Ltb;-><init>(Lb34;B)V

    .line 452
    .line 453
    .line 454
    const v2, -0x31c9e40a    # -7.6382144E8f

    .line 455
    .line 456
    .line 457
    invoke-static {v2, v1, v0}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 458
    .line 459
    .line 460
    move-result-object v26

    .line 461
    const/high16 v28, 0x6000000

    .line 462
    .line 463
    const/16 v29, 0xfa

    .line 464
    .line 465
    const/16 v18, 0x0

    .line 466
    .line 467
    const/16 v20, 0x0

    .line 468
    .line 469
    const-wide/16 v21, 0x0

    .line 470
    .line 471
    const/16 v23, 0x0

    .line 472
    .line 473
    const/16 v24, 0x0

    .line 474
    .line 475
    const/16 v25, 0x0

    .line 476
    .line 477
    move-object/from16 v27, v0

    .line 478
    .line 479
    invoke-static/range {v17 .. v29}, Lyy3;->b(Lw82;Lmz3;ZZJFFFLl92;Lla2;II)V

    .line 480
    .line 481
    .line 482
    invoke-virtual {v0, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    move-result v1

    .line 486
    invoke-virtual {v0}, Lla2;->N()Ljava/lang/Object;

    .line 487
    .line 488
    .line 489
    move-result-object v2

    .line 490
    if-nez v1, :cond_b

    .line 491
    .line 492
    if-ne v2, v4, :cond_c

    .line 493
    .line 494
    :cond_b
    new-instance v17, Lev5;

    .line 495
    .line 496
    const/16 v23, 0x0

    .line 497
    .line 498
    const/16 v24, 0x5

    .line 499
    .line 500
    const/16 v18, 0x0

    .line 501
    .line 502
    const-class v20, Lsv5;

    .line 503
    .line 504
    const-string v21, "goToNextMatch"

    .line 505
    .line 506
    const-string v22, "goToNextMatch()V"

    .line 507
    .line 508
    move-object/from16 v19, v14

    .line 509
    .line 510
    invoke-direct/range {v17 .. v24}, Lev5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 511
    .line 512
    .line 513
    move-object/from16 v2, v17

    .line 514
    .line 515
    invoke-virtual {v0, v2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    :cond_c
    check-cast v2, Ln53;

    .line 519
    .line 520
    move-object/from16 v17, v2

    .line 521
    .line 522
    check-cast v17, Lw82;

    .line 523
    .line 524
    invoke-interface {v10}, Lok6;->getValue()Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    move-result-object v1

    .line 528
    check-cast v1, Ljava/lang/Number;

    .line 529
    .line 530
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 531
    .line 532
    .line 533
    move-result v1

    .line 534
    if-lez v1, :cond_d

    .line 535
    .line 536
    const/16 v19, 0x1

    .line 537
    .line 538
    goto :goto_4

    .line 539
    :cond_d
    const/16 v19, 0x0

    .line 540
    .line 541
    :goto_4
    new-instance v1, Ltb;

    .line 542
    .line 543
    const/16 v2, 0x15

    .line 544
    .line 545
    invoke-direct {v1, v10, v2}, Ltb;-><init>(Lb34;B)V

    .line 546
    .line 547
    .line 548
    const v2, 0x11d1cced

    .line 549
    .line 550
    .line 551
    invoke-static {v2, v1, v0}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 552
    .line 553
    .line 554
    move-result-object v26

    .line 555
    const/high16 v28, 0x6000000

    .line 556
    .line 557
    const/16 v29, 0xfa

    .line 558
    .line 559
    const/16 v18, 0x0

    .line 560
    .line 561
    const/16 v20, 0x0

    .line 562
    .line 563
    const-wide/16 v21, 0x0

    .line 564
    .line 565
    const/16 v23, 0x0

    .line 566
    .line 567
    const/16 v24, 0x0

    .line 568
    .line 569
    const/16 v25, 0x0

    .line 570
    .line 571
    move-object/from16 v27, v0

    .line 572
    .line 573
    invoke-static/range {v17 .. v29}, Lyy3;->b(Lw82;Lmz3;ZZJFFFLl92;Lla2;II)V

    .line 574
    .line 575
    .line 576
    const/4 v7, 0x1

    .line 577
    invoke-virtual {v0, v7}, Lla2;->r(Z)V

    .line 578
    .line 579
    .line 580
    invoke-interface/range {v33 .. v33}, Lok6;->getValue()Ljava/lang/Object;

    .line 581
    .line 582
    .line 583
    move-result-object v1

    .line 584
    check-cast v1, Ljava/lang/String;

    .line 585
    .line 586
    invoke-static {v1}, Lam6;->O0(Ljava/lang/CharSequence;)Z

    .line 587
    .line 588
    .line 589
    move-result v1

    .line 590
    if-nez v1, :cond_10

    .line 591
    .line 592
    const v1, -0x23b9cf8e

    .line 593
    .line 594
    .line 595
    invoke-virtual {v0, v1}, Lla2;->b0(I)V

    .line 596
    .line 597
    .line 598
    invoke-interface {v10}, Lok6;->getValue()Ljava/lang/Object;

    .line 599
    .line 600
    .line 601
    move-result-object v1

    .line 602
    check-cast v1, Ljava/lang/Number;

    .line 603
    .line 604
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 605
    .line 606
    .line 607
    move-result v1

    .line 608
    if-gtz v1, :cond_e

    .line 609
    .line 610
    const-string v1, "0/0"

    .line 611
    .line 612
    :goto_5
    move-object/from16 v17, v1

    .line 613
    .line 614
    goto :goto_7

    .line 615
    :cond_e
    invoke-interface/range {v32 .. v32}, Lok6;->getValue()Ljava/lang/Object;

    .line 616
    .line 617
    .line 618
    move-result-object v1

    .line 619
    check-cast v1, Ljava/lang/Number;

    .line 620
    .line 621
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 622
    .line 623
    .line 624
    move-result v1

    .line 625
    if-ltz v1, :cond_f

    .line 626
    .line 627
    invoke-interface/range {v32 .. v32}, Lok6;->getValue()Ljava/lang/Object;

    .line 628
    .line 629
    .line 630
    move-result-object v1

    .line 631
    check-cast v1, Ljava/lang/Number;

    .line 632
    .line 633
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 634
    .line 635
    .line 636
    move-result v1

    .line 637
    const/16 v16, 0x1

    .line 638
    .line 639
    add-int/lit8 v1, v1, 0x1

    .line 640
    .line 641
    goto :goto_6

    .line 642
    :cond_f
    const/4 v1, 0x0

    .line 643
    :goto_6
    invoke-interface {v10}, Lok6;->getValue()Ljava/lang/Object;

    .line 644
    .line 645
    .line 646
    move-result-object v2

    .line 647
    check-cast v2, Ljava/lang/Number;

    .line 648
    .line 649
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 650
    .line 651
    .line 652
    move-result v2

    .line 653
    new-instance v3, Ljava/lang/StringBuilder;

    .line 654
    .line 655
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 656
    .line 657
    .line 658
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 659
    .line 660
    .line 661
    const-string v1, "/"

    .line 662
    .line 663
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 664
    .line 665
    .line 666
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 667
    .line 668
    .line 669
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 670
    .line 671
    .line 672
    move-result-object v1

    .line 673
    goto :goto_5

    .line 674
    :goto_7
    sget-object v1, Lbx0;->a:Lps1;

    .line 675
    .line 676
    invoke-virtual {v0, v1}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 677
    .line 678
    .line 679
    move-result-object v1

    .line 680
    check-cast v1, Lax0;

    .line 681
    .line 682
    invoke-virtual {v1}, Lax0;->n()J

    .line 683
    .line 684
    .line 685
    move-result-wide v19

    .line 686
    const/16 v1, 0xd

    .line 687
    .line 688
    invoke-static {v1}, Lcu6;->f(I)J

    .line 689
    .line 690
    .line 691
    move-result-wide v21

    .line 692
    const/16 v37, 0x0

    .line 693
    .line 694
    const v38, 0x3ffea

    .line 695
    .line 696
    .line 697
    const/16 v18, 0x0

    .line 698
    .line 699
    const/16 v23, 0x0

    .line 700
    .line 701
    const/16 v24, 0x0

    .line 702
    .line 703
    const-wide/16 v25, 0x0

    .line 704
    .line 705
    const/16 v27, 0x0

    .line 706
    .line 707
    const-wide/16 v28, 0x0

    .line 708
    .line 709
    const/16 v30, 0x0

    .line 710
    .line 711
    const/16 v31, 0x0

    .line 712
    .line 713
    const/16 v32, 0x0

    .line 714
    .line 715
    const/16 v33, 0x0

    .line 716
    .line 717
    const/16 v34, 0x0

    .line 718
    .line 719
    const/16 v36, 0x6000

    .line 720
    .line 721
    move-object/from16 v35, v0

    .line 722
    .line 723
    invoke-static/range {v17 .. v38}, Lru6;->b(Ljava/lang/String;Lmz3;JJLt72;Lv62;JLqt6;JIZIILk17;Lla2;III)V

    .line 724
    .line 725
    .line 726
    const/4 v5, 0x0

    .line 727
    invoke-virtual {v0, v5}, Lla2;->r(Z)V

    .line 728
    .line 729
    .line 730
    :goto_8
    const/4 v7, 0x1

    .line 731
    goto :goto_9

    .line 732
    :cond_10
    const/4 v5, 0x0

    .line 733
    const v1, -0x23afa9da

    .line 734
    .line 735
    .line 736
    invoke-virtual {v0, v1}, Lla2;->b0(I)V

    .line 737
    .line 738
    .line 739
    invoke-virtual {v0, v5}, Lla2;->r(Z)V

    .line 740
    .line 741
    .line 742
    goto :goto_8

    .line 743
    :goto_9
    invoke-virtual {v0, v7}, Lla2;->r(Z)V

    .line 744
    .line 745
    .line 746
    goto :goto_a

    .line 747
    :cond_11
    move-object v0, v1

    .line 748
    move-object/from16 v39, v7

    .line 749
    .line 750
    invoke-virtual {v0}, Lla2;->V()V

    .line 751
    .line 752
    .line 753
    :goto_a
    return-object v39

    .line 754
    :pswitch_0
    move-object/from16 v33, v5

    .line 755
    .line 756
    move-object/from16 v39, v7

    .line 757
    .line 758
    check-cast v11, Ljava/util/List;

    .line 759
    .line 760
    check-cast v13, Lw82;

    .line 761
    .line 762
    move-object/from16 v19, v12

    .line 763
    .line 764
    check-cast v19, Ljava/util/List;

    .line 765
    .line 766
    move-object/from16 v20, v10

    .line 767
    .line 768
    check-cast v20, Ljava/util/List;

    .line 769
    .line 770
    check-cast v9, Ll92;

    .line 771
    .line 772
    check-cast v14, Lh92;

    .line 773
    .line 774
    move-object/from16 v0, p1

    .line 775
    .line 776
    check-cast v0, Lvx0;

    .line 777
    .line 778
    move-object/from16 v1, p2

    .line 779
    .line 780
    check-cast v1, Lla2;

    .line 781
    .line 782
    move-object/from16 v2, p3

    .line 783
    .line 784
    check-cast v2, Ljava/lang/Integer;

    .line 785
    .line 786
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 787
    .line 788
    .line 789
    move-result v2

    .line 790
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 791
    .line 792
    .line 793
    and-int/lit8 v0, v2, 0x11

    .line 794
    .line 795
    if-eq v0, v15, :cond_12

    .line 796
    .line 797
    const/4 v0, 0x1

    .line 798
    :goto_b
    const/16 v16, 0x1

    .line 799
    .line 800
    goto :goto_c

    .line 801
    :cond_12
    const/4 v0, 0x0

    .line 802
    goto :goto_b

    .line 803
    :goto_c
    and-int/lit8 v2, v2, 0x1

    .line 804
    .line 805
    invoke-virtual {v1, v2, v0}, Lla2;->S(IZ)Z

    .line 806
    .line 807
    .line 808
    move-result v0

    .line 809
    if-eqz v0, :cond_1b

    .line 810
    .line 811
    const v0, 0x7f0f0279

    .line 812
    .line 813
    .line 814
    invoke-static {v0, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 815
    .line 816
    .line 817
    move-result-object v21

    .line 818
    invoke-virtual {v1, v11}, Lla2;->i(Ljava/lang/Object;)Z

    .line 819
    .line 820
    .line 821
    move-result v0

    .line 822
    invoke-virtual {v1, v13}, Lla2;->g(Ljava/lang/Object;)Z

    .line 823
    .line 824
    .line 825
    move-result v2

    .line 826
    or-int/2addr v0, v2

    .line 827
    invoke-virtual {v1}, Lla2;->N()Ljava/lang/Object;

    .line 828
    .line 829
    .line 830
    move-result-object v2

    .line 831
    if-nez v0, :cond_13

    .line 832
    .line 833
    if-eq v2, v4, :cond_13

    .line 834
    .line 835
    move-object/from16 v5, v33

    .line 836
    .line 837
    goto :goto_d

    .line 838
    :cond_13
    new-instance v2, Lol;

    .line 839
    .line 840
    move-object/from16 v5, v33

    .line 841
    .line 842
    const/16 v0, 0x15

    .line 843
    .line 844
    invoke-direct {v2, v11, v13, v5, v0}, Lol;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 845
    .line 846
    .line 847
    invoke-virtual {v1, v2}, Lla2;->k0(Ljava/lang/Object;)V

    .line 848
    .line 849
    .line 850
    :goto_d
    move-object/from16 v22, v2

    .line 851
    .line 852
    check-cast v22, Lw82;

    .line 853
    .line 854
    const v0, 0x7f0f027b

    .line 855
    .line 856
    .line 857
    invoke-static {v0, v1}, Lub3;->a0(ILla2;)Ljava/lang/String;

    .line 858
    .line 859
    .line 860
    move-result-object v25

    .line 861
    const/16 v28, 0x0

    .line 862
    .line 863
    const/16 v29, 0x2c

    .line 864
    .line 865
    const/16 v23, 0x0

    .line 866
    .line 867
    const/16 v24, 0x0

    .line 868
    .line 869
    const/16 v26, 0x0

    .line 870
    .line 871
    move-object/from16 v27, v1

    .line 872
    .line 873
    invoke-static/range {v21 .. v29}, Lt36;->b(Ljava/lang/String;Lw82;Lmz3;ZLjava/lang/String;Ll92;Lla2;II)V

    .line 874
    .line 875
    .line 876
    move-object/from16 v0, v27

    .line 877
    .line 878
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 879
    .line 880
    .line 881
    move-result-object v1

    .line 882
    const/4 v2, 0x0

    .line 883
    :goto_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 884
    .line 885
    .line 886
    move-result v6

    .line 887
    if-eqz v6, :cond_1c

    .line 888
    .line 889
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 890
    .line 891
    .line 892
    move-result-object v6

    .line 893
    add-int/lit8 v7, v2, 0x1

    .line 894
    .line 895
    if-ltz v2, :cond_1a

    .line 896
    .line 897
    move-object/from16 v17, v6

    .line 898
    .line 899
    check-cast v17, Lyd4;

    .line 900
    .line 901
    const v6, -0x6426bd0

    .line 902
    .line 903
    .line 904
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 905
    .line 906
    .line 907
    move-result-object v10

    .line 908
    invoke-virtual {v0, v6, v10}, Lla2;->Z(ILjava/lang/Object;)V

    .line 909
    .line 910
    .line 911
    invoke-interface {v5}, Lok6;->getValue()Ljava/lang/Object;

    .line 912
    .line 913
    .line 914
    move-result-object v6

    .line 915
    check-cast v6, Ljava/lang/Integer;

    .line 916
    .line 917
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 918
    .line 919
    .line 920
    move-result-object v10

    .line 921
    invoke-virtual {v0}, Lla2;->N()Ljava/lang/Object;

    .line 922
    .line 923
    .line 924
    move-result-object v11

    .line 925
    if-ne v11, v4, :cond_14

    .line 926
    .line 927
    new-instance v11, Lzz3;

    .line 928
    .line 929
    const/16 v12, 0xa

    .line 930
    .line 931
    invoke-direct {v11, v5, v12}, Lzz3;-><init>(Lb34;B)V

    .line 932
    .line 933
    .line 934
    invoke-virtual {v0, v11}, Lla2;->k0(Ljava/lang/Object;)V

    .line 935
    .line 936
    .line 937
    :cond_14
    check-cast v11, Lw82;

    .line 938
    .line 939
    invoke-static {v8, v6, v10, v11, v0}, Lba3;->J(Lmz3;Ljava/lang/Number;Ljava/lang/Number;Lw82;Lla2;)Lmz3;

    .line 940
    .line 941
    .line 942
    move-result-object v6

    .line 943
    sget-object v10, Lba7;->d:Lpv;

    .line 944
    .line 945
    sget-object v11, Lr6;->w:Ll20;

    .line 946
    .line 947
    const/4 v12, 0x0

    .line 948
    invoke-static {v10, v11, v0, v12}, Lsx0;->a(Lsv;Ll20;Lla2;I)Lux0;

    .line 949
    .line 950
    .line 951
    move-result-object v10

    .line 952
    iget-wide v11, v0, Lla2;->T:J

    .line 953
    .line 954
    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    .line 955
    .line 956
    .line 957
    move-result v11

    .line 958
    invoke-virtual {v0}, Lla2;->m()Lky4;

    .line 959
    .line 960
    .line 961
    move-result-object v12

    .line 962
    invoke-static {v0, v6}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 963
    .line 964
    .line 965
    move-result-object v6

    .line 966
    sget-object v13, Lv11;->d:Lr6;

    .line 967
    .line 968
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 969
    .line 970
    .line 971
    invoke-virtual {v0}, Lla2;->e0()V

    .line 972
    .line 973
    .line 974
    iget-boolean v13, v0, Lla2;->S:Z

    .line 975
    .line 976
    if-eqz v13, :cond_15

    .line 977
    .line 978
    invoke-virtual {v0, v3}, Lla2;->l(Lw82;)V

    .line 979
    .line 980
    .line 981
    goto :goto_f

    .line 982
    :cond_15
    invoke-virtual {v0}, Lla2;->n0()V

    .line 983
    .line 984
    .line 985
    :goto_f
    sget-object v13, Lr6;->S:La11;

    .line 986
    .line 987
    invoke-static {v13, v0, v10}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 988
    .line 989
    .line 990
    sget-object v10, Lr6;->R:La11;

    .line 991
    .line 992
    invoke-static {v10, v0, v12}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 993
    .line 994
    .line 995
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 996
    .line 997
    .line 998
    move-result-object v10

    .line 999
    sget-object v11, Lr6;->T:La11;

    .line 1000
    .line 1001
    invoke-static {v11, v0, v10}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 1002
    .line 1003
    .line 1004
    invoke-static {v0}, Lxt6;->k(Lla2;)V

    .line 1005
    .line 1006
    .line 1007
    sget-object v10, Lr6;->Q:La11;

    .line 1008
    .line 1009
    invoke-static {v10, v0, v6}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 1010
    .line 1011
    .line 1012
    invoke-virtual {v0, v9}, Lla2;->g(Ljava/lang/Object;)Z

    .line 1013
    .line 1014
    .line 1015
    move-result v6

    .line 1016
    invoke-virtual {v0, v2}, Lla2;->e(I)Z

    .line 1017
    .line 1018
    .line 1019
    move-result v10

    .line 1020
    or-int/2addr v6, v10

    .line 1021
    invoke-virtual {v0}, Lla2;->N()Ljava/lang/Object;

    .line 1022
    .line 1023
    .line 1024
    move-result-object v10

    .line 1025
    if-nez v6, :cond_16

    .line 1026
    .line 1027
    if-ne v10, v4, :cond_17

    .line 1028
    .line 1029
    :cond_16
    new-instance v10, Lvr1;

    .line 1030
    .line 1031
    const/4 v6, 0x2

    .line 1032
    invoke-direct {v10, v9, v2, v6}, Lvr1;-><init>(Ll92;IB)V

    .line 1033
    .line 1034
    .line 1035
    invoke-virtual {v0, v10}, Lla2;->k0(Ljava/lang/Object;)V

    .line 1036
    .line 1037
    .line 1038
    :cond_17
    move-object/from16 v21, v10

    .line 1039
    .line 1040
    check-cast v21, Lh92;

    .line 1041
    .line 1042
    invoke-virtual {v0, v14}, Lla2;->g(Ljava/lang/Object;)Z

    .line 1043
    .line 1044
    .line 1045
    move-result v6

    .line 1046
    invoke-virtual {v0, v2}, Lla2;->e(I)Z

    .line 1047
    .line 1048
    .line 1049
    move-result v10

    .line 1050
    or-int/2addr v6, v10

    .line 1051
    invoke-virtual {v0}, Lla2;->N()Ljava/lang/Object;

    .line 1052
    .line 1053
    .line 1054
    move-result-object v10

    .line 1055
    if-nez v6, :cond_18

    .line 1056
    .line 1057
    if-ne v10, v4, :cond_19

    .line 1058
    .line 1059
    :cond_18
    new-instance v10, Lkj;

    .line 1060
    .line 1061
    invoke-direct {v10, v14, v2, v15}, Lkj;-><init>(Lh92;IB)V

    .line 1062
    .line 1063
    .line 1064
    invoke-virtual {v0, v10}, Lla2;->k0(Ljava/lang/Object;)V

    .line 1065
    .line 1066
    .line 1067
    :cond_19
    move-object/from16 v22, v10

    .line 1068
    .line 1069
    check-cast v22, Lw82;

    .line 1070
    .line 1071
    sget-object v2, Lyd4;->d:Ljava/util/List;

    .line 1072
    .line 1073
    const/16 v24, 0x0

    .line 1074
    .line 1075
    const/16 v18, 0x0

    .line 1076
    .line 1077
    move-object/from16 v23, v0

    .line 1078
    .line 1079
    invoke-static/range {v17 .. v24}, Lpn7;->w(Lyd4;ZLjava/util/List;Ljava/util/List;Lh92;Lw82;Lla2;I)V

    .line 1080
    .line 1081
    .line 1082
    const/4 v11, 0x1

    .line 1083
    invoke-virtual {v0, v11}, Lla2;->r(Z)V

    .line 1084
    .line 1085
    .line 1086
    const/4 v2, 0x0

    .line 1087
    invoke-virtual {v0, v2}, Lla2;->r(Z)V

    .line 1088
    .line 1089
    .line 1090
    move v2, v7

    .line 1091
    goto/16 :goto_e

    .line 1092
    .line 1093
    :cond_1a
    invoke-static {}, Lkm;->s0()V

    .line 1094
    .line 1095
    .line 1096
    const/4 v0, 0x0

    .line 1097
    throw v0

    .line 1098
    :cond_1b
    move-object v0, v1

    .line 1099
    invoke-virtual {v0}, Lla2;->V()V

    .line 1100
    .line 1101
    .line 1102
    :cond_1c
    return-object v39

    .line 1103
    :pswitch_1
    move-object/from16 v39, v7

    .line 1104
    .line 1105
    const/4 v2, 0x0

    .line 1106
    move-object v3, v14

    .line 1107
    check-cast v3, Lh92;

    .line 1108
    .line 1109
    move-object v4, v11

    .line 1110
    check-cast v4, Lb34;

    .line 1111
    .line 1112
    move-object v5, v13

    .line 1113
    check-cast v5, Lh92;

    .line 1114
    .line 1115
    check-cast v12, Ljava/util/ArrayList;

    .line 1116
    .line 1117
    check-cast v10, Ljava/util/ArrayList;

    .line 1118
    .line 1119
    check-cast v9, Lfw4;

    .line 1120
    .line 1121
    move-object/from16 v1, p1

    .line 1122
    .line 1123
    check-cast v1, Lvx0;

    .line 1124
    .line 1125
    move-object/from16 v7, p2

    .line 1126
    .line 1127
    check-cast v7, Lla2;

    .line 1128
    .line 1129
    move-object/from16 v6, p3

    .line 1130
    .line 1131
    check-cast v6, Ljava/lang/Integer;

    .line 1132
    .line 1133
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 1134
    .line 1135
    .line 1136
    move-result v6

    .line 1137
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1138
    .line 1139
    .line 1140
    and-int/lit8 v1, v6, 0x11

    .line 1141
    .line 1142
    if-eq v1, v15, :cond_1d

    .line 1143
    .line 1144
    const/4 v2, 0x1

    .line 1145
    :cond_1d
    const/16 v16, 0x1

    .line 1146
    .line 1147
    and-int/lit8 v6, v6, 0x1

    .line 1148
    .line 1149
    invoke-virtual {v7, v6, v2}, Lla2;->S(IZ)Z

    .line 1150
    .line 1151
    .line 1152
    move-result v1

    .line 1153
    if-eqz v1, :cond_1e

    .line 1154
    .line 1155
    const/high16 v1, 0x3f800000    # 1.0f

    .line 1156
    .line 1157
    invoke-static {v8, v1}, Lef6;->d(Lmz3;F)Lmz3;

    .line 1158
    .line 1159
    .line 1160
    move-result-object v18

    .line 1161
    invoke-static {v7}, Llc3;->t(Lla2;)Llj0;

    .line 1162
    .line 1163
    .line 1164
    move-result-object v21

    .line 1165
    new-instance v1, Lil;

    .line 1166
    .line 1167
    const/16 v6, 0xb

    .line 1168
    .line 1169
    iget-object v2, v0, Lbd1;->j:Lb34;

    .line 1170
    .line 1171
    invoke-direct/range {v1 .. v6}, Lil;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1172
    .line 1173
    .line 1174
    const v0, -0x6558e05a

    .line 1175
    .line 1176
    .line 1177
    invoke-static {v0, v1, v7}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v27

    .line 1181
    const/16 v29, 0x6

    .line 1182
    .line 1183
    const/16 v30, 0x3f6

    .line 1184
    .line 1185
    const/16 v19, 0x0

    .line 1186
    .line 1187
    const/16 v20, 0x0

    .line 1188
    .line 1189
    const/16 v22, 0x0

    .line 1190
    .line 1191
    const/16 v23, 0x0

    .line 1192
    .line 1193
    const/16 v24, 0x0

    .line 1194
    .line 1195
    const/16 v25, 0x0

    .line 1196
    .line 1197
    const/16 v26, 0x0

    .line 1198
    .line 1199
    move-object/from16 v28, v7

    .line 1200
    .line 1201
    invoke-static/range {v18 .. v30}, Lpv3;->a(Lmz3;FLbt4;Llj0;Lh35;ZLw82;Lw82;ZLyz0;Lla2;II)V

    .line 1202
    .line 1203
    .line 1204
    move-object/from16 v0, v28

    .line 1205
    .line 1206
    const/high16 v1, 0x3f800000    # 1.0f

    .line 1207
    .line 1208
    invoke-static {v8, v1}, Lef6;->d(Lmz3;F)Lmz3;

    .line 1209
    .line 1210
    .line 1211
    move-result-object v18

    .line 1212
    invoke-static {v0}, Llc3;->t(Lla2;)Llj0;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v21

    .line 1216
    new-instance v1, Lk;

    .line 1217
    .line 1218
    const/4 v2, 0x7

    .line 1219
    invoke-direct {v1, v12, v10, v9, v2}, Lk;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1220
    .line 1221
    .line 1222
    const v2, 0x4a95ce4f    # 4908839.5f

    .line 1223
    .line 1224
    .line 1225
    invoke-static {v2, v1, v0}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v27

    .line 1229
    invoke-static/range {v18 .. v30}, Lpv3;->a(Lmz3;FLbt4;Llj0;Lh35;ZLw82;Lw82;ZLyz0;Lla2;II)V

    .line 1230
    .line 1231
    .line 1232
    goto :goto_10

    .line 1233
    :cond_1e
    move-object/from16 v28, v7

    .line 1234
    .line 1235
    invoke-virtual/range {v28 .. v28}, Lla2;->V()V

    .line 1236
    .line 1237
    .line 1238
    :goto_10
    return-object v39

    .line 1239
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
