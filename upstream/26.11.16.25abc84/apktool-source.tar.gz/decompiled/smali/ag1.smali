.class public final synthetic Lag1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lag1;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-byte p0, p0, Lag1;->i:B

    .line 2
    .line 3
    const/high16 v0, 0x41c00000    # 24.0f

    .line 4
    .line 5
    const/high16 v1, 0x40800000    # 4.0f

    .line 6
    .line 7
    const/high16 v2, 0x3fc00000    # 1.5f

    .line 8
    .line 9
    const/high16 v3, 0x3f800000    # 1.0f

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v6, 0x0

    .line 14
    sget-object v7, Loc7;->a:Loc7;

    .line 15
    .line 16
    packed-switch p0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    check-cast p1, Lpg2;

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-interface {p1, v5}, Lpg2;->J0(I)V

    .line 25
    .line 26
    .line 27
    return-object v7

    .line 28
    :pswitch_0
    check-cast p1, Lyq1;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    return-object v7

    .line 34
    :pswitch_1
    check-cast p1, Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    return-object p0

    .line 48
    :pswitch_2
    check-cast p1, Ljava/lang/Integer;

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    return-object p0

    .line 62
    :pswitch_3
    check-cast p1, Ljava/lang/Integer;

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    return-object p0

    .line 76
    :pswitch_4
    check-cast p1, Lyi0;

    .line 77
    .line 78
    return-object v7

    .line 79
    :pswitch_5
    const-wide/16 p0, 0x1f4

    .line 80
    .line 81
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0

    .line 86
    :pswitch_6
    check-cast p1, Lpq1;

    .line 87
    .line 88
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-static {p1, v4, v3, v2}, Loq;->A(Lpq1;FFF)V

    .line 92
    .line 93
    .line 94
    iget p0, p1, Lpq1;->i:F

    .line 95
    .line 96
    mul-float/2addr p0, v1

    .line 97
    invoke-static {p1, p0, p0}, Lzi;->p(Lpq1;FF)V

    .line 98
    .line 99
    .line 100
    iget p0, p1, Lpq1;->i:F

    .line 101
    .line 102
    mul-float v1, p0, v0

    .line 103
    .line 104
    mul-float/2addr p0, v0

    .line 105
    invoke-static {p1, v1, p0, v6, v4}, Lsa3;->K(Lpq1;FFZF)V

    .line 106
    .line 107
    .line 108
    return-object v7

    .line 109
    :pswitch_7
    check-cast p1, Li76;

    .line 110
    .line 111
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    .line 113
    .line 114
    return-object v7

    .line 115
    :pswitch_8
    check-cast p1, Li76;

    .line 116
    .line 117
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    .line 119
    .line 120
    return-object v7

    .line 121
    :pswitch_9
    check-cast p1, Lpq1;

    .line 122
    .line 123
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 124
    .line 125
    .line 126
    iget p0, p1, Lpq1;->m:F

    .line 127
    .line 128
    const/high16 v5, 0x42200000    # 40.0f

    .line 129
    .line 130
    iget v8, p1, Lpq1;->i:F

    .line 131
    .line 132
    mul-float/2addr v8, v5

    .line 133
    invoke-static {p0, v8}, Ljava/lang/Math;->max(FF)F

    .line 134
    .line 135
    .line 136
    move-result p0

    .line 137
    iput p0, p1, Lpq1;->m:F

    .line 138
    .line 139
    invoke-static {p1, v4, v3, v2}, Loq;->A(Lpq1;FFF)V

    .line 140
    .line 141
    .line 142
    iget p0, p1, Lpq1;->i:F

    .line 143
    .line 144
    mul-float/2addr p0, v1

    .line 145
    invoke-static {p1, p0, p0}, Lzi;->p(Lpq1;FF)V

    .line 146
    .line 147
    .line 148
    iget p0, p1, Lpq1;->i:F

    .line 149
    .line 150
    mul-float v1, p0, v0

    .line 151
    .line 152
    mul-float/2addr p0, v0

    .line 153
    invoke-static {p1, v1, p0, v6, v4}, Lsa3;->K(Lpq1;FFZF)V

    .line 154
    .line 155
    .line 156
    return-object v7

    .line 157
    :pswitch_a
    check-cast p1, Li76;

    .line 158
    .line 159
    invoke-static {p1, v6}, Lg76;->l(Li76;I)V

    .line 160
    .line 161
    .line 162
    return-object v7

    .line 163
    :pswitch_b
    check-cast p1, Li76;

    .line 164
    .line 165
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    invoke-static {p1, v6}, Lg76;->l(Li76;I)V

    .line 169
    .line 170
    .line 171
    return-object v7

    .line 172
    :pswitch_c
    check-cast p1, Laf1;

    .line 173
    .line 174
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 175
    .line 176
    .line 177
    new-instance p0, Ljava/lang/StringBuilder;

    .line 178
    .line 179
    const-string v0, "["

    .line 180
    .line 181
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 185
    .line 186
    .line 187
    const/16 p1, 0x5d

    .line 188
    .line 189
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 190
    .line 191
    .line 192
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    return-object p0

    .line 197
    :pswitch_d
    check-cast p1, Ldz4;

    .line 198
    .line 199
    return-object v7

    .line 200
    :pswitch_e
    check-cast p1, Lai6;

    .line 201
    .line 202
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 203
    .line 204
    .line 205
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    return-object p0

    .line 210
    :pswitch_f
    check-cast p1, Lju1;

    .line 211
    .line 212
    iget-boolean p0, p1, Lju1;->c:Z

    .line 213
    .line 214
    xor-int/2addr p0, v5

    .line 215
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 216
    .line 217
    .line 218
    move-result-object p0

    .line 219
    return-object p0

    .line 220
    :pswitch_10
    invoke-static {p1}, Lvh6;->h(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    .line 221
    .line 222
    .line 223
    move-result-object p0

    .line 224
    throw p0

    .line 225
    :pswitch_11
    check-cast p1, Lyh2;

    .line 226
    .line 227
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 228
    .line 229
    .line 230
    invoke-virtual {p1}, Lyh2;->toString()Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    move-result-object p0

    .line 234
    return-object p0

    .line 235
    :pswitch_12
    check-cast p1, Lrs1;

    .line 236
    .line 237
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 238
    .line 239
    .line 240
    const-wide/high16 p0, 0x4049000000000000L    # 50.0

    .line 241
    .line 242
    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    return-object p0

    .line 247
    :pswitch_13
    check-cast p1, Lz05;

    .line 248
    .line 249
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 250
    .line 251
    return-object p0

    .line 252
    :pswitch_14
    invoke-static {p1}, Lif0;->C(Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result p0

    .line 256
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 257
    .line 258
    .line 259
    move-result-object p0

    .line 260
    return-object p0

    .line 261
    :pswitch_15
    check-cast p1, Lkk4;

    .line 262
    .line 263
    return-object v7

    .line 264
    :pswitch_16
    check-cast p1, Ljava/lang/Long;

    .line 265
    .line 266
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 267
    .line 268
    .line 269
    return-object v7

    .line 270
    :pswitch_17
    check-cast p1, Ljava/util/List;

    .line 271
    .line 272
    new-instance p0, Lyi1;

    .line 273
    .line 274
    invoke-interface {p1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 279
    .line 280
    .line 281
    check-cast v0, Ljava/lang/Integer;

    .line 282
    .line 283
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 284
    .line 285
    .line 286
    move-result v0

    .line 287
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 292
    .line 293
    .line 294
    check-cast v1, Ljava/lang/Float;

    .line 295
    .line 296
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 297
    .line 298
    .line 299
    move-result v1

    .line 300
    new-instance v2, Lvm;

    .line 301
    .line 302
    const/4 v3, 0x2

    .line 303
    invoke-direct {v2, p1, v3}, Lvm;-><init>(Ljava/util/List;B)V

    .line 304
    .line 305
    .line 306
    invoke-direct {p0, v0, v1, v2}, Lyi1;-><init>(IFLw82;)V

    .line 307
    .line 308
    .line 309
    return-object p0

    .line 310
    :pswitch_18
    check-cast p1, Ljd5;

    .line 311
    .line 312
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 313
    .line 314
    .line 315
    iget-object p0, p1, Ljd5;->a:Ljava/lang/String;

    .line 316
    .line 317
    return-object p0

    .line 318
    :pswitch_19
    check-cast p1, Ljd5;

    .line 319
    .line 320
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 321
    .line 322
    .line 323
    iget-object p0, p1, Ljd5;->a:Ljava/lang/String;

    .line 324
    .line 325
    return-object p0

    .line 326
    nop

    .line 327
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_d
        :pswitch_d
        :pswitch_4
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
