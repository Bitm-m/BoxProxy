.class public final Lau4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lq84;


# static fields
.field public static final i:Lau4;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lau4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lau4;->i:Lau4;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final K0(JJI)J
    .locals 0

    .line 1
    const-wide/16 p0, 0x0

    .line 2
    .line 3
    return-wide p0
.end method

.method public final Q0(JJLca1;)Ljava/lang/Object;
    .locals 0

    .line 1
    new-instance p0, Lre7;

    .line 2
    .line 3
    const-wide/16 p1, 0x0

    .line 4
    .line 5
    invoke-direct {p0, p1, p2}, Lre7;-><init>(J)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method
