.class public final Lai4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lr77;


# virtual methods
.method public final a(Lzu2;)Lv77;
    .locals 0

    .line 1
    new-instance p0, Lbi4;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lbi4;-><init>(Lzu2;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method
