.class public final Laq5;
.super Lda1;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public i:Lhq5;

.field public j:Ljava/lang/String;

.field public k:Leg2;

.field public l:Ljava/util/ArrayList;

.field public m:Ljava/lang/String;

.field public n:Ljava/util/ArrayList;

.field public o:Ljava/util/Iterator;

.field public p:Lzp5;

.field public q:Ljava/util/ArrayList;

.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:Lbq5;

.field public t:I


# direct methods
.method public constructor <init>(Lbq5;Lda1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laq5;->s:Lbq5;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lda1;-><init>(Lca1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Laq5;->r:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Laq5;->t:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Laq5;->t:I

    .line 9
    .line 10
    iget-object p1, p0, Laq5;->s:Lbq5;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Lbq5;->j(Lhq5;Ljava/lang/String;Leg2;Lda1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
