.class public final synthetic Lae2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lm92;


# instance fields
.field public final synthetic i:Lmz3;

.field public final synthetic j:Lq73;

.field public final synthetic k:J

.field public final synthetic l:Lrw3;

.field public final synthetic m:Lce2;

.field public final synthetic n:Llc7;

.field public final synthetic o:Lbe2;

.field public final synthetic p:Lyz0;

.field public final synthetic q:Ljava/util/List;

.field public final synthetic r:Lmn3;


# direct methods
.method public synthetic constructor <init>(Lmz3;Lq73;JLrw3;Lce2;Llc7;Lbe2;Lyz0;Ljava/util/List;Lmn3;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae2;->i:Lmz3;

    .line 5
    .line 6
    iput-object p2, p0, Lae2;->j:Lq73;

    .line 7
    .line 8
    iput-wide p3, p0, Lae2;->k:J

    .line 9
    .line 10
    iput-object p5, p0, Lae2;->l:Lrw3;

    .line 11
    .line 12
    iput-object p6, p0, Lae2;->m:Lce2;

    .line 13
    .line 14
    iput-object p7, p0, Lae2;->n:Llc7;

    .line 15
    .line 16
    iput-object p8, p0, Lae2;->o:Lbe2;

    .line 17
    .line 18
    iput-object p9, p0, Lae2;->p:Lyz0;

    .line 19
    .line 20
    iput-object p10, p0, Lae2;->q:Ljava/util/List;

    .line 21
    .line 22
    iput-object p11, p0, Lae2;->r:Lmn3;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 70

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lzs4;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Lla2;

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v1, v3, 0x11

    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    const/4 v5, 0x1

    .line 26
    const/16 v6, 0x10

    .line 27
    .line 28
    if-eq v1, v6, :cond_0

    .line 29
    .line 30
    move v1, v5

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    move v1, v4

    .line 33
    :goto_0
    and-int/2addr v3, v5

    .line 34
    invoke-virtual {v2, v3, v1}, Lla2;->S(IZ)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_6

    .line 39
    .line 40
    sget-object v1, Lef6;->c:Lz12;

    .line 41
    .line 42
    sget-object v3, Lr6;->k:Ln20;

    .line 43
    .line 44
    invoke-static {v3, v4}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 45
    .line 46
    .line 47
    move-result-object v7

    .line 48
    iget-wide v8, v2, Lla2;->T:J

    .line 49
    .line 50
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 51
    .line 52
    .line 53
    move-result v8

    .line 54
    invoke-virtual {v2}, Lla2;->m()Lky4;

    .line 55
    .line 56
    .line 57
    move-result-object v9

    .line 58
    invoke-static {v2, v1}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 59
    .line 60
    .line 61
    move-result-object v10

    .line 62
    sget-object v11, Lv11;->d:Lr6;

    .line 63
    .line 64
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    invoke-virtual {v2}, Lla2;->e0()V

    .line 68
    .line 69
    .line 70
    iget-boolean v11, v2, Lla2;->S:Z

    .line 71
    .line 72
    sget-object v12, Lq83;->a0:Lif2;

    .line 73
    .line 74
    if-eqz v11, :cond_1

    .line 75
    .line 76
    invoke-virtual {v2, v12}, Lla2;->l(Lw82;)V

    .line 77
    .line 78
    .line 79
    goto :goto_1

    .line 80
    :cond_1
    invoke-virtual {v2}, Lla2;->n0()V

    .line 81
    .line 82
    .line 83
    :goto_1
    sget-object v11, Lr6;->S:La11;

    .line 84
    .line 85
    invoke-static {v11, v2, v7}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    sget-object v7, Lr6;->R:La11;

    .line 89
    .line 90
    invoke-static {v7, v2, v9}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object v8

    .line 97
    sget-object v9, Lr6;->T:La11;

    .line 98
    .line 99
    invoke-static {v9, v2, v8}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    invoke-static {v2}, Lxt6;->k(Lla2;)V

    .line 103
    .line 104
    .line 105
    sget-object v8, Lr6;->Q:La11;

    .line 106
    .line 107
    invoke-static {v8, v2, v10}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    iget-object v10, v0, Lae2;->i:Lmz3;

    .line 111
    .line 112
    invoke-interface {v10, v1}, Lmz3;->a0(Lmz3;)Lmz3;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    iget-object v10, v0, Lae2;->j:Lq73;

    .line 117
    .line 118
    sget-object v13, Ljz3;->i:Ljz3;

    .line 119
    .line 120
    if-eqz v10, :cond_2

    .line 121
    .line 122
    invoke-static {v13, v10}, Lu60;->Q(Lmz3;Lq73;)Lmz3;

    .line 123
    .line 124
    .line 125
    move-result-object v13

    .line 126
    :cond_2
    invoke-interface {v1, v13}, Lmz3;->a0(Lmz3;)Lmz3;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    sget-object v13, Lu60;->a0:Lor2;

    .line 131
    .line 132
    iget-wide v14, v0, Lae2;->k:J

    .line 133
    .line 134
    invoke-static {v1, v14, v15, v13}, Leb;->z(Lmz3;JLw96;)Lmz3;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-static {v3, v4}, Ljb0;->c(Ln20;Z)Lnq3;

    .line 139
    .line 140
    .line 141
    move-result-object v3

    .line 142
    iget-wide v13, v2, Lla2;->T:J

    .line 143
    .line 144
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 145
    .line 146
    .line 147
    move-result v13

    .line 148
    invoke-virtual {v2}, Lla2;->m()Lky4;

    .line 149
    .line 150
    .line 151
    move-result-object v14

    .line 152
    invoke-static {v2, v1}, Lom;->V(Lla2;Lmz3;)Lmz3;

    .line 153
    .line 154
    .line 155
    move-result-object v1

    .line 156
    invoke-virtual {v2}, Lla2;->e0()V

    .line 157
    .line 158
    .line 159
    iget-boolean v15, v2, Lla2;->S:Z

    .line 160
    .line 161
    if-eqz v15, :cond_3

    .line 162
    .line 163
    invoke-virtual {v2, v12}, Lla2;->l(Lw82;)V

    .line 164
    .line 165
    .line 166
    goto :goto_2

    .line 167
    :cond_3
    invoke-virtual {v2}, Lla2;->n0()V

    .line 168
    .line 169
    .line 170
    :goto_2
    invoke-static {v11, v2, v3}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    invoke-static {v7, v2, v14}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    invoke-static {v13, v2, v9, v2}, Lzi6;->y(ILla2;La11;Lla2;)V

    .line 177
    .line 178
    .line 179
    invoke-static {v8, v2, v1}, Lxt6;->n(Ll92;Lla2;Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    sget-object v1, Lyy3;->o:Lps1;

    .line 183
    .line 184
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 185
    .line 186
    invoke-virtual {v1, v3}, Lps1;->a(Ljava/lang/Object;)Lr55;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    sget-object v3, Lyy3;->p:Lps1;

    .line 191
    .line 192
    iget-object v7, v0, Lae2;->m:Lce2;

    .line 193
    .line 194
    invoke-virtual {v2, v7}, Lla2;->g(Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v8

    .line 198
    invoke-virtual {v2}, Lla2;->N()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v9

    .line 202
    if-nez v8, :cond_4

    .line 203
    .line 204
    sget-object v8, Ld21;->a:Lq9;

    .line 205
    .line 206
    if-ne v9, v8, :cond_5

    .line 207
    .line 208
    :cond_4
    new-instance v9, Lvd2;

    .line 209
    .line 210
    invoke-direct {v9, v7, v5}, Lvd2;-><init>(Lce2;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v2, v9}, Lla2;->k0(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_5
    check-cast v9, Lw82;

    .line 217
    .line 218
    invoke-virtual {v3, v9}, Lps1;->a(Ljava/lang/Object;)Lr55;

    .line 219
    .line 220
    .line 221
    move-result-object v3

    .line 222
    sget-object v8, Lyy3;->q:Lps1;

    .line 223
    .line 224
    new-instance v9, Lue3;

    .line 225
    .line 226
    iget-object v11, v0, Lae2;->n:Llc7;

    .line 227
    .line 228
    invoke-direct {v9, v11, v6}, Lue3;-><init>(Lik7;I)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v8, v9}, Lps1;->a(Ljava/lang/Object;)Lr55;

    .line 232
    .line 233
    .line 234
    move-result-object v6

    .line 235
    sget-object v8, Lyy3;->r:Lps1;

    .line 236
    .line 237
    iget-object v9, v0, Lae2;->o:Lbe2;

    .line 238
    .line 239
    invoke-virtual {v8, v9}, Lps1;->a(Ljava/lang/Object;)Lr55;

    .line 240
    .line 241
    .line 242
    move-result-object v8

    .line 243
    filled-new-array {v1, v3, v6, v8}, [Lr55;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    iget-object v3, v0, Lae2;->p:Lyz0;

    .line 248
    .line 249
    invoke-static {v1, v3, v2, v4}, Lhn;->d([Lr55;Ll92;Lla2;I)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v2, v5}, Lla2;->r(Z)V

    .line 253
    .line 254
    .line 255
    sget-object v1, Lbx0;->a:Lps1;

    .line 256
    .line 257
    invoke-virtual {v2, v1}, Lla2;->k(Ln55;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    move-object v11, v1

    .line 262
    check-cast v11, Lax0;

    .line 263
    .line 264
    iget-object v1, v0, Lae2;->l:Lrw3;

    .line 265
    .line 266
    iget-wide v3, v1, Lrw3;->b:J

    .line 267
    .line 268
    const/16 v68, -0x1

    .line 269
    .line 270
    const v69, 0x1ffeff

    .line 271
    .line 272
    .line 273
    const-wide/16 v12, 0x0

    .line 274
    .line 275
    const-wide/16 v14, 0x0

    .line 276
    .line 277
    const-wide/16 v16, 0x0

    .line 278
    .line 279
    const-wide/16 v18, 0x0

    .line 280
    .line 281
    const-wide/16 v20, 0x0

    .line 282
    .line 283
    const-wide/16 v22, 0x0

    .line 284
    .line 285
    const-wide/16 v24, 0x0

    .line 286
    .line 287
    const-wide/16 v26, 0x0

    .line 288
    .line 289
    const-wide/16 v28, 0x0

    .line 290
    .line 291
    const-wide/16 v30, 0x0

    .line 292
    .line 293
    const-wide/16 v32, 0x0

    .line 294
    .line 295
    const-wide/16 v34, 0x0

    .line 296
    .line 297
    const-wide/16 v36, 0x0

    .line 298
    .line 299
    const-wide/16 v38, 0x0

    .line 300
    .line 301
    const-wide/16 v40, 0x0

    .line 302
    .line 303
    const-wide/16 v42, 0x0

    .line 304
    .line 305
    const-wide/16 v44, 0x0

    .line 306
    .line 307
    const-wide/16 v48, 0x0

    .line 308
    .line 309
    const-wide/16 v50, 0x0

    .line 310
    .line 311
    const-wide/16 v52, 0x0

    .line 312
    .line 313
    const-wide/16 v54, 0x0

    .line 314
    .line 315
    const-wide/16 v56, 0x0

    .line 316
    .line 317
    const-wide/16 v58, 0x0

    .line 318
    .line 319
    const-wide/16 v60, 0x0

    .line 320
    .line 321
    const-wide/16 v62, 0x0

    .line 322
    .line 323
    const-wide/16 v64, 0x0

    .line 324
    .line 325
    const-wide/16 v66, 0x0

    .line 326
    .line 327
    move-wide/from16 v46, v3

    .line 328
    .line 329
    invoke-static/range {v11 .. v69}, Lax0;->a(Lax0;JJJJJJJJJJJJJJJJJJJJJJJJJJJJII)Lax0;

    .line 330
    .line 331
    .line 332
    move-result-object v3

    .line 333
    new-instance v13, Lo0;

    .line 334
    .line 335
    iget-object v14, v0, Lae2;->q:Ljava/util/List;

    .line 336
    .line 337
    iget-object v15, v0, Lae2;->r:Lmn3;

    .line 338
    .line 339
    move-object/from16 v18, v1

    .line 340
    .line 341
    move-object/from16 v17, v7

    .line 342
    .line 343
    move-object/from16 v16, v10

    .line 344
    .line 345
    invoke-direct/range {v13 .. v18}, Lo0;-><init>(Ljava/util/List;Lmn3;Lq73;Lce2;Lrw3;)V

    .line 346
    .line 347
    .line 348
    const v0, 0x4f324906

    .line 349
    .line 350
    .line 351
    invoke-static {v0, v13, v2}, Ltj;->J(ILt92;Lla2;)Lyz0;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    const/16 v1, 0x180

    .line 356
    .line 357
    const/4 v4, 0x0

    .line 358
    invoke-static {v3, v4, v0, v2, v1}, Lva3;->c(Lax0;Lm17;Lyz0;Lla2;I)V

    .line 359
    .line 360
    .line 361
    invoke-virtual {v2, v5}, Lla2;->r(Z)V

    .line 362
    .line 363
    .line 364
    goto :goto_3

    .line 365
    :cond_6
    invoke-virtual {v2}, Lla2;->V()V

    .line 366
    .line 367
    .line 368
    :goto_3
    sget-object v0, Loc7;->a:Loc7;

    .line 369
    .line 370
    return-object v0
.end method
