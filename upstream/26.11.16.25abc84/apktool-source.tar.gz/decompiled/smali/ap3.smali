.class public final synthetic Lap3;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Ll92;

.field public final synthetic j:Lmz3;

.field public final synthetic k:Lyz0;

.field public final synthetic l:Lyz0;

.field public final synthetic m:Lz57;

.field public final synthetic n:Lue3;

.field public final synthetic o:Lk02;

.field public final synthetic p:Lh92;

.field public final synthetic q:S

.field public final synthetic r:B


# direct methods
.method public synthetic constructor <init>(Ll92;Lmz3;Lyz0;Lyz0;Lz57;Lue3;Lk02;Lh92;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lap3;->i:Ll92;

    .line 5
    .line 6
    iput-object p2, p0, Lap3;->j:Lmz3;

    .line 7
    .line 8
    iput-object p3, p0, Lap3;->k:Lyz0;

    .line 9
    .line 10
    iput-object p4, p0, Lap3;->l:Lyz0;

    .line 11
    .line 12
    iput-object p5, p0, Lap3;->m:Lz57;

    .line 13
    .line 14
    iput-object p6, p0, Lap3;->n:Lue3;

    .line 15
    .line 16
    iput-object p7, p0, Lap3;->o:Lk02;

    .line 17
    .line 18
    iput-object p8, p0, Lap3;->p:Lh92;

    .line 19
    .line 20
    iput-short p9, p0, Lap3;->q:S

    .line 21
    .line 22
    iput-byte p10, p0, Lap3;->r:B

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    move-object v8, p1

    .line 2
    check-cast v8, Lla2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-short p1, p0, Lap3;->q:S

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lt36;->a0(I)I

    .line 14
    .line 15
    .line 16
    move-result v9

    .line 17
    iget-object v0, p0, Lap3;->i:Ll92;

    .line 18
    .line 19
    iget-object v1, p0, Lap3;->j:Lmz3;

    .line 20
    .line 21
    iget-object v2, p0, Lap3;->k:Lyz0;

    .line 22
    .line 23
    iget-object v3, p0, Lap3;->l:Lyz0;

    .line 24
    .line 25
    iget-object v4, p0, Lap3;->m:Lz57;

    .line 26
    .line 27
    iget-object v5, p0, Lap3;->n:Lue3;

    .line 28
    .line 29
    iget-object v6, p0, Lap3;->o:Lk02;

    .line 30
    .line 31
    iget-object v7, p0, Lap3;->p:Lh92;

    .line 32
    .line 33
    iget-byte v10, p0, Lap3;->r:B

    .line 34
    .line 35
    invoke-static/range {v0 .. v10}, Lsa3;->a(Ll92;Lmz3;Lyz0;Lyz0;Lz57;Lue3;Lk02;Lh92;Lla2;II)V

    .line 36
    .line 37
    .line 38
    sget-object p0, Loc7;->a:Loc7;

    .line 39
    .line 40
    return-object p0
.end method
