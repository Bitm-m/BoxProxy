.class public final synthetic La60;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Lh92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:F

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(FLjava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, La60;->i:B

    .line 2
    .line 3
    iput p1, p0, La60;->j:F

    .line 4
    .line 5
    iput-object p2, p0, La60;->k:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;FB)V
    .locals 0

    .line 11
    iput-byte p3, p0, La60;->i:B

    iput-object p1, p0, La60;->k:Ljava/lang/Object;

    iput p2, p0, La60;->j:F

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-byte v0, p0, La60;->i:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    sget-object v4, Loc7;->a:Loc7;

    .line 7
    .line 8
    iget v5, p0, La60;->j:F

    .line 9
    .line 10
    iget-object v6, p0, La60;->k:Ljava/lang/Object;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast v6, Lx77;

    .line 16
    .line 17
    check-cast p1, Ljava/lang/Long;

    .line 18
    .line 19
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 20
    .line 21
    .line 22
    move-result-wide p0

    .line 23
    invoke-virtual {v6}, Lx77;->h()Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    iget-object v7, v6, Lx77;->h:Lgw4;

    .line 28
    .line 29
    if-nez v0, :cond_4

    .line 30
    .line 31
    invoke-virtual {v7}, Lgw4;->g()J

    .line 32
    .line 33
    .line 34
    move-result-wide v8

    .line 35
    const-wide/high16 v10, -0x8000000000000000L

    .line 36
    .line 37
    cmp-long v0, v8, v10

    .line 38
    .line 39
    if-nez v0, :cond_0

    .line 40
    .line 41
    invoke-virtual {v7, p0, p1}, Lgw4;->h(J)V

    .line 42
    .line 43
    .line 44
    iget-object v0, v6, Lx77;->a:Lc34;

    .line 45
    .line 46
    iget-object v0, v0, Lc34;->a:Liw4;

    .line 47
    .line 48
    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 49
    .line 50
    invoke-virtual {v0, v8}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_0
    invoke-virtual {v7}, Lgw4;->g()J

    .line 54
    .line 55
    .line 56
    move-result-wide v7

    .line 57
    sub-long/2addr p0, v7

    .line 58
    cmpg-float v0, v5, v3

    .line 59
    .line 60
    if-eqz v0, :cond_1

    .line 61
    .line 62
    long-to-double p0, p0

    .line 63
    float-to-double v7, v5

    .line 64
    div-double/2addr p0, v7

    .line 65
    invoke-static {p0, p1}, Lgq3;->M(D)J

    .line 66
    .line 67
    .line 68
    move-result-wide p0

    .line 69
    :cond_1
    iget-object v3, v6, Lx77;->b:Lx77;

    .line 70
    .line 71
    if-nez v3, :cond_2

    .line 72
    .line 73
    iget-object v3, v6, Lx77;->g:Lgw4;

    .line 74
    .line 75
    invoke-virtual {v3, p0, p1}, Lgw4;->h(J)V

    .line 76
    .line 77
    .line 78
    :cond_2
    if-nez v0, :cond_3

    .line 79
    .line 80
    move v1, v2

    .line 81
    :cond_3
    invoke-virtual {v6, p0, p1, v1}, Lx77;->i(JZ)V

    .line 82
    .line 83
    .line 84
    :cond_4
    return-object v4

    .line 85
    :pswitch_0
    check-cast v6, Lez4;

    .line 86
    .line 87
    check-cast p1, Ldz4;

    .line 88
    .line 89
    invoke-interface {p1, v5}, Llk1;->s0(F)I

    .line 90
    .line 91
    .line 92
    move-result p0

    .line 93
    invoke-virtual {p1, v6, p0, v1, v3}, Ldz4;->g(Lez4;IIF)V

    .line 94
    .line 95
    .line 96
    return-object v4

    .line 97
    :pswitch_1
    check-cast v6, Lts0;

    .line 98
    .line 99
    check-cast p1, Li76;

    .line 100
    .line 101
    new-instance p0, Ls45;

    .line 102
    .line 103
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-static {v0, v6}, Lub3;->D(Ljava/lang/Comparable;Lus0;)Ljava/lang/Comparable;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    check-cast v0, Ljava/lang/Number;

    .line 112
    .line 113
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    invoke-direct {p0, v0, v6}, Ls45;-><init>(FLts0;)V

    .line 118
    .line 119
    .line 120
    invoke-static {p1, p0}, Lg76;->k(Li76;Ls45;)V

    .line 121
    .line 122
    .line 123
    return-object v4

    .line 124
    :pswitch_2
    check-cast v6, Lw26;

    .line 125
    .line 126
    check-cast p1, Lgp1;

    .line 127
    .line 128
    iget-wide p0, p1, Lgp1;->a:J

    .line 129
    .line 130
    const/16 v0, 0x20

    .line 131
    .line 132
    shr-long/2addr p0, v0

    .line 133
    long-to-int p0, p0

    .line 134
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 135
    .line 136
    .line 137
    move-result p0

    .line 138
    mul-float/2addr p0, v5

    .line 139
    invoke-interface {v6, p0}, Lw26;->a(F)F

    .line 140
    .line 141
    .line 142
    return-object v4

    .line 143
    :pswitch_3
    check-cast v6, Lee2;

    .line 144
    .line 145
    check-cast p1, Lz73;

    .line 146
    .line 147
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 148
    .line 149
    .line 150
    invoke-static {p1, v2}, Luj;->L(Lz73;Z)Laj5;

    .line 151
    .line 152
    .line 153
    move-result-object p0

    .line 154
    iget-object p1, v6, Lee2;->i:Liw4;

    .line 155
    .line 156
    invoke-virtual {p1, p0}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    iget-object p0, v6, Lee2;->l:Liw4;

    .line 160
    .line 161
    new-instance p1, Lmo1;

    .line 162
    .line 163
    invoke-direct {p1, v5}, Lmo1;-><init>(F)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p0, p1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    iget-object p0, v6, Lee2;->m:Liw4;

    .line 170
    .line 171
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 172
    .line 173
    invoke-virtual {p0, p1}, Liw4;->setValue(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    return-object v4

    .line 177
    :pswitch_4
    check-cast v6, Lrq1;

    .line 178
    .line 179
    move-object v8, p1

    .line 180
    check-cast v8, Lyq1;

    .line 181
    .line 182
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 183
    .line 184
    .line 185
    iget-object v7, v6, Lrq1;->w:Lcz;

    .line 186
    .line 187
    iget-object v9, v6, Lrq1;->G:Lpq1;

    .line 188
    .line 189
    iget-object p1, v6, Lrq1;->J:Liw4;

    .line 190
    .line 191
    invoke-virtual {p1}, Liw4;->getValue()Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    move-object v10, p1

    .line 196
    check-cast v10, Lz73;

    .line 197
    .line 198
    iget-object v11, v6, Lrq1;->y:Lh92;

    .line 199
    .line 200
    iget v12, p0, La60;->j:F

    .line 201
    .line 202
    invoke-interface/range {v7 .. v12}, Lcz;->b(Lyq1;Llk1;Lz73;Lh92;F)V

    .line 203
    .line 204
    .line 205
    return-object v4

    .line 206
    :pswitch_5
    check-cast v6, Lcj5;

    .line 207
    .line 208
    check-cast p1, Lfq1;

    .line 209
    .line 210
    invoke-interface {p1}, Lza2;->j1()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object p0

    .line 214
    const-string v0, "waiting"

    .line 215
    .line 216
    invoke-static {p0, v0}, Lf13;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result p0

    .line 220
    invoke-interface {p1}, Lfq1;->t()Lio4;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    if-eqz v0, :cond_6

    .line 225
    .line 226
    invoke-interface {p1}, Lfq1;->t()Lio4;

    .line 227
    .line 228
    .line 229
    move-result-object p1

    .line 230
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 231
    .line 232
    .line 233
    sget-object v0, Lhq1;->a:Lgq1;

    .line 234
    .line 235
    sget-object v0, Lio4;->j:Lio4;

    .line 236
    .line 237
    const/high16 v3, 0x41f00000    # 30.0f

    .line 238
    .line 239
    if-ne p1, v0, :cond_5

    .line 240
    .line 241
    cmpg-float p1, v5, v3

    .line 242
    .line 243
    if-gtz p1, :cond_6

    .line 244
    .line 245
    goto :goto_0

    .line 246
    :cond_5
    cmpl-float p1, v5, v3

    .line 247
    .line 248
    if-lez p1, :cond_6

    .line 249
    .line 250
    const/high16 p1, 0x42b40000    # 90.0f

    .line 251
    .line 252
    cmpg-float p1, v5, p1

    .line 253
    .line 254
    if-gtz p1, :cond_6

    .line 255
    .line 256
    :goto_0
    move p1, v2

    .line 257
    goto :goto_1

    .line 258
    :cond_6
    move p1, v1

    .line 259
    :goto_1
    iget-boolean v0, v6, Lcj5;->i:Z

    .line 260
    .line 261
    if-nez v0, :cond_7

    .line 262
    .line 263
    if-eqz p0, :cond_8

    .line 264
    .line 265
    if-eqz p1, :cond_8

    .line 266
    .line 267
    :cond_7
    move v1, v2

    .line 268
    :cond_8
    iput-boolean v1, v6, Lcj5;->i:Z

    .line 269
    .line 270
    xor-int/2addr v1, v2

    .line 271
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 272
    .line 273
    .line 274
    move-result-object p0

    .line 275
    return-object p0

    .line 276
    :pswitch_6
    check-cast v6, Lwb6;

    .line 277
    .line 278
    check-cast p1, Lpg2;

    .line 279
    .line 280
    iget-object p0, v6, Lwb6;->d:Lj9;

    .line 281
    .line 282
    iget-object p0, p0, Lj9;->i:Ljava/lang/Object;

    .line 283
    .line 284
    check-cast p0, Lew4;

    .line 285
    .line 286
    invoke-virtual {p0}, Lew4;->g()F

    .line 287
    .line 288
    .line 289
    move-result p0

    .line 290
    invoke-interface {p1}, Lpg2;->b()J

    .line 291
    .line 292
    .line 293
    move-result-wide v0

    .line 294
    const-wide v6, 0xffffffffL

    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    and-long/2addr v0, v6

    .line 300
    long-to-int v0, v0

    .line 301
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 302
    .line 303
    .line 304
    move-result v0

    .line 305
    invoke-static {p0}, Ljava/lang/Float;->isNaN(F)Z

    .line 306
    .line 307
    .line 308
    move-result v1

    .line 309
    if-nez v1, :cond_9

    .line 310
    .line 311
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    .line 312
    .line 313
    .line 314
    move-result v1

    .line 315
    if-nez v1, :cond_9

    .line 316
    .line 317
    cmpg-float v1, v0, v3

    .line 318
    .line 319
    if-eqz v1, :cond_9

    .line 320
    .line 321
    invoke-static {p1, v5}, Llm;->G(Lpg2;F)F

    .line 322
    .line 323
    .line 324
    move-result v1

    .line 325
    invoke-interface {p1, v1}, Lpg2;->X(F)V

    .line 326
    .line 327
    .line 328
    invoke-static {p1, v5}, Llm;->H(Lpg2;F)F

    .line 329
    .line 330
    .line 331
    move-result v1

    .line 332
    invoke-interface {p1, v1}, Lpg2;->y0(F)V

    .line 333
    .line 334
    .line 335
    add-float/2addr p0, v0

    .line 336
    div-float/2addr p0, v0

    .line 337
    const/high16 v0, 0x3f000000    # 0.5f

    .line 338
    .line 339
    invoke-static {v0, p0}, Lhw6;->a(FF)J

    .line 340
    .line 341
    .line 342
    move-result-wide v0

    .line 343
    invoke-interface {p1, v0, v1}, Lpg2;->t0(J)V

    .line 344
    .line 345
    .line 346
    :cond_9
    return-object v4

    .line 347
    :pswitch_7
    check-cast v6, Lew4;

    .line 348
    .line 349
    check-cast p1, Lkg;

    .line 350
    .line 351
    invoke-virtual {p1}, Lkg;->e()Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object p0

    .line 355
    check-cast p0, Ljava/lang/Number;

    .line 356
    .line 357
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 358
    .line 359
    .line 360
    move-result p0

    .line 361
    div-float/2addr p0, v5

    .line 362
    const/high16 p1, 0x3f800000    # 1.0f

    .line 363
    .line 364
    invoke-static {p0, v3, p1}, Lub3;->y(FFF)F

    .line 365
    .line 366
    .line 367
    move-result p0

    .line 368
    sub-float/2addr p1, p0

    .line 369
    invoke-virtual {v6, p1}, Lew4;->h(F)V

    .line 370
    .line 371
    .line 372
    return-object v4

    .line 373
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
