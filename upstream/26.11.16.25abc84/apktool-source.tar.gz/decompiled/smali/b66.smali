.class public abstract Lb66;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lci;

.field public static final b:Lt87;

.field public static final c:Lnj6;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Lci;

    .line 2
    .line 3
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 4
    .line 5
    invoke-direct {v0, v1, v1}, Lci;-><init>(FF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lb66;->a:Lci;

    .line 9
    .line 10
    new-instance v0, Lf06;

    .line 11
    .line 12
    const/16 v1, 0x1b

    .line 13
    .line 14
    invoke-direct {v0, v1}, Lf06;-><init>(B)V

    .line 15
    .line 16
    .line 17
    new-instance v1, Lf06;

    .line 18
    .line 19
    const/16 v2, 0x1c

    .line 20
    .line 21
    invoke-direct {v1, v2}, Lf06;-><init>(B)V

    .line 22
    .line 23
    .line 24
    new-instance v2, Lt87;

    .line 25
    .line 26
    invoke-direct {v2, v0, v1}, Lt87;-><init>(Lh92;Lh92;)V

    .line 27
    .line 28
    .line 29
    sput-object v2, Lb66;->b:Lt87;

    .line 30
    .line 31
    new-instance v0, Lnj6;

    .line 32
    .line 33
    new-instance v1, Lkk4;

    .line 34
    .line 35
    const-wide v2, 0x3c23d70a3c23d70aL    # 5.377642754525469E-19

    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    invoke-direct {v1, v2, v3}, Lkk4;-><init>(J)V

    .line 41
    .line 42
    .line 43
    const/4 v2, 0x3

    .line 44
    invoke-direct {v0, v2, v1}, Lnj6;-><init>(ILjava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lb66;->c:Lnj6;

    .line 48
    .line 49
    return-void
.end method
