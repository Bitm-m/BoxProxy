.class public abstract Lan1;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lnh2;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lbn1;->a:Laj1;

    .line 2
    .line 3
    sget-object v0, Lkn3;->a:Lnh2;

    .line 4
    .line 5
    sput-object v0, Lan1;->a:Lnh2;

    .line 6
    .line 7
    return-void
.end method
