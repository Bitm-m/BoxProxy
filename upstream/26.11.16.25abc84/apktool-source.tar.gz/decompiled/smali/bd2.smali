.class public final synthetic Lbd2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Lmz3;

.field public final synthetic k:F

.field public final synthetic l:J

.field public final synthetic m:J

.field public final synthetic n:Z

.field public final synthetic o:S


# direct methods
.method public synthetic constructor <init>(ZLmz3;FJJZI)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lbd2;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Lbd2;->j:Lmz3;

    .line 7
    .line 8
    iput p3, p0, Lbd2;->k:F

    .line 9
    .line 10
    iput-wide p4, p0, Lbd2;->l:J

    .line 11
    .line 12
    iput-wide p6, p0, Lbd2;->m:J

    .line 13
    .line 14
    iput-boolean p8, p0, Lbd2;->n:Z

    .line 15
    .line 16
    iput-short p9, p0, Lbd2;->o:S

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    move-object v8, p1

    .line 2
    check-cast v8, Lla2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-short p1, p0, Lbd2;->o:S

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lt36;->a0(I)I

    .line 14
    .line 15
    .line 16
    move-result v9

    .line 17
    iget-boolean v0, p0, Lbd2;->i:Z

    .line 18
    .line 19
    iget-object v1, p0, Lbd2;->j:Lmz3;

    .line 20
    .line 21
    iget v2, p0, Lbd2;->k:F

    .line 22
    .line 23
    iget-wide v3, p0, Lbd2;->l:J

    .line 24
    .line 25
    iget-wide v5, p0, Lbd2;->m:J

    .line 26
    .line 27
    iget-boolean v7, p0, Lbd2;->n:Z

    .line 28
    .line 29
    invoke-static/range {v0 .. v9}, Lhn;->i(ZLmz3;FJJZLla2;I)V

    .line 30
    .line 31
    .line 32
    sget-object p0, Loc7;->a:Loc7;

    .line 33
    .line 34
    return-object p0
.end method
