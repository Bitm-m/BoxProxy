.class public final La95;
.super Lhq6;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public i:B

.field public j:I

.field public k:I

.field public l:Lw82;

.field public m:Ljava/lang/Integer;

.field public n:Ljava/lang/String;

.field public o:Lcj5;

.field public p:Z

.field public final synthetic q:Ll1;

.field public final synthetic r:I

.field public final synthetic s:Ljava/lang/Integer;

.field public final synthetic t:Ljava/lang/String;

.field public final synthetic u:Lcj5;


# direct methods
.method public constructor <init>(Ll1;ILjava/lang/Integer;Ljava/lang/String;Lcj5;Lca1;)V
    .locals 0

    .line 1
    iput-object p1, p0, La95;->q:Ll1;

    .line 2
    .line 3
    iput p2, p0, La95;->r:I

    .line 4
    .line 5
    iput-object p3, p0, La95;->s:Ljava/lang/Integer;

    .line 6
    .line 7
    iput-object p4, p0, La95;->t:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p5, p0, La95;->u:Lcj5;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p6}, Lhq6;-><init>(ILca1;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lca1;)Lca1;
    .locals 7

    .line 1
    new-instance v0, La95;

    .line 2
    .line 3
    iget-object v4, p0, La95;->t:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v5, p0, La95;->u:Lcj5;

    .line 6
    .line 7
    iget-object v1, p0, La95;->q:Ll1;

    .line 8
    .line 9
    iget v2, p0, La95;->r:I

    .line 10
    .line 11
    iget-object v3, p0, La95;->s:Ljava/lang/Integer;

    .line 12
    .line 13
    move-object v6, p2

    .line 14
    invoke-direct/range {v0 .. v6}, La95;-><init>(Ll1;ILjava/lang/Integer;Ljava/lang/String;Lcj5;Lca1;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lw26;

    .line 2
    .line 3
    check-cast p2, Lca1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La95;->create(Ljava/lang/Object;Lca1;)Lca1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, La95;

    .line 10
    .line 11
    sget-object p1, Loc7;->a:Loc7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, La95;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    iget-boolean v0, p0, La95;->p:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-ne v0, v2, :cond_0

    .line 8
    .line 9
    iget v0, p0, La95;->k:I

    .line 10
    .line 11
    iget v3, p0, La95;->j:I

    .line 12
    .line 13
    iget-byte v4, p0, La95;->i:B

    .line 14
    .line 15
    iget-object v5, p0, La95;->o:Lcj5;

    .line 16
    .line 17
    iget-object v6, p0, La95;->n:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v7, p0, La95;->m:Ljava/lang/Integer;

    .line 20
    .line 21
    iget-object v8, p0, La95;->l:Lw82;

    .line 22
    .line 23
    invoke-static {p1}, Lcb3;->L(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    goto/16 :goto_2

    .line 27
    .line 28
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 29
    .line 30
    invoke-static {p0}, Lzy1;->d(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return-object v1

    .line 34
    :cond_1
    invoke-static {p1}, Lcb3;->L(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    const/16 p1, 0x5a

    .line 38
    .line 39
    iget-object v0, p0, La95;->q:Ll1;

    .line 40
    .line 41
    iget v3, p0, La95;->r:I

    .line 42
    .line 43
    iget-object v4, p0, La95;->s:Ljava/lang/Integer;

    .line 44
    .line 45
    iget-object v5, p0, La95;->t:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v6, p0, La95;->u:Lcj5;

    .line 48
    .line 49
    const/4 v7, 0x0

    .line 50
    move-object v8, v6

    .line 51
    move-object v6, v5

    .line 52
    move-object v5, v8

    .line 53
    move-object v8, v0

    .line 54
    move v0, v7

    .line 55
    move-object v7, v4

    .line 56
    move v4, p1

    .line 57
    :goto_0
    sget-object p1, Loc7;->a:Loc7;

    .line 58
    .line 59
    if-ge v0, v4, :cond_8

    .line 60
    .line 61
    invoke-interface {v8}, Lw82;->invoke()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    check-cast v9, Lmc3;

    .line 66
    .line 67
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget v10, v9, Lmc3;->o:I

    .line 71
    .line 72
    iget-object v9, v9, Lmc3;->l:Ljava/util/List;

    .line 73
    .line 74
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 75
    .line 76
    .line 77
    move-result-object v9

    .line 78
    :cond_2
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    if-eqz v11, :cond_3

    .line 83
    .line 84
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v11

    .line 88
    move-object v12, v11

    .line 89
    check-cast v12, Lnc3;

    .line 90
    .line 91
    iget v12, v12, Lnc3;->a:I

    .line 92
    .line 93
    if-ne v12, v3, :cond_2

    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_3
    move-object v11, v1

    .line 97
    :goto_1
    check-cast v11, Lnc3;

    .line 98
    .line 99
    if-lez v10, :cond_6

    .line 100
    .line 101
    if-ltz v3, :cond_6

    .line 102
    .line 103
    if-ge v3, v10, :cond_6

    .line 104
    .line 105
    if-eqz v7, :cond_4

    .line 106
    .line 107
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 108
    .line 109
    .line 110
    move-result v9

    .line 111
    if-ne v10, v9, :cond_6

    .line 112
    .line 113
    :cond_4
    if-eqz v6, :cond_5

    .line 114
    .line 115
    if-eqz v11, :cond_5

    .line 116
    .line 117
    iget-object v9, v11, Lnc3;->i:Ljava/lang/Object;

    .line 118
    .line 119
    invoke-virtual {v9, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move-result v9

    .line 123
    if-eqz v9, :cond_6

    .line 124
    .line 125
    :cond_5
    iput-boolean v2, v5, Lcj5;->i:Z

    .line 126
    .line 127
    return-object p1

    .line 128
    :cond_6
    new-instance p1, Lst4;

    .line 129
    .line 130
    const/16 v9, 0xd

    .line 131
    .line 132
    invoke-direct {p1, v9}, Lst4;-><init>(B)V

    .line 133
    .line 134
    .line 135
    iput-object v8, p0, La95;->l:Lw82;

    .line 136
    .line 137
    iput-object v7, p0, La95;->m:Ljava/lang/Integer;

    .line 138
    .line 139
    iput-object v6, p0, La95;->n:Ljava/lang/String;

    .line 140
    .line 141
    iput-object v5, p0, La95;->o:Lcj5;

    .line 142
    .line 143
    iput-byte v4, p0, La95;->i:B

    .line 144
    .line 145
    iput v3, p0, La95;->j:I

    .line 146
    .line 147
    iput v0, p0, La95;->k:I

    .line 148
    .line 149
    iput-boolean v2, p0, La95;->p:Z

    .line 150
    .line 151
    invoke-interface {p0}, Lca1;->getContext()Lyd1;

    .line 152
    .line 153
    .line 154
    move-result-object v9

    .line 155
    invoke-static {v9}, Lt36;->x(Lyd1;)Lof;

    .line 156
    .line 157
    .line 158
    move-result-object v9

    .line 159
    invoke-virtual {v9, p1, p0}, Lof;->a(Lh92;Lca1;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    sget-object v9, Lie1;->i:Lie1;

    .line 164
    .line 165
    if-ne p1, v9, :cond_7

    .line 166
    .line 167
    return-object v9

    .line 168
    :cond_7
    :goto_2
    add-int/2addr v0, v2

    .line 169
    goto :goto_0

    .line 170
    :cond_8
    return-object p1
.end method
