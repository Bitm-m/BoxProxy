.class public final Lb4;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic a:B

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lb4;->a:B

    .line 2
    .line 3
    iput-object p1, p0, Lb4;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Lu05;Lca1;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    iget-byte v2, v0, Lb4;->a:B

    .line 8
    .line 9
    const/4 v3, 0x3

    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v5, 0x1

    .line 12
    const/4 v7, 0x0

    .line 13
    sget-object v8, Loc7;->a:Loc7;

    .line 14
    .line 15
    sget-object v9, Lie1;->i:Lie1;

    .line 16
    .line 17
    iget-object v0, v0, Lb4;->b:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v2, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    check-cast v0, Ldy6;

    .line 23
    .line 24
    iget-object v2, v0, Ldy6;->z:Lay6;

    .line 25
    .line 26
    iget-object v0, v0, Ldy6;->y:Lby6;

    .line 27
    .line 28
    invoke-static {v1, v2, v0, v6}, Lcc3;->p(Lu05;Lk04;Lev6;Lca1;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-ne v0, v9, :cond_0

    .line 33
    .line 34
    move-object v8, v0

    .line 35
    :cond_0
    return-object v8

    .line 36
    :pswitch_0
    new-instance v2, Lku;

    .line 37
    .line 38
    check-cast v0, Law6;

    .line 39
    .line 40
    const/16 v3, 0xf

    .line 41
    .line 42
    invoke-direct {v2, v0, v1, v7, v3}, Lku;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lca1;B)V

    .line 43
    .line 44
    .line 45
    invoke-static {v2, v6}, Loq;->E(Ll92;Lca1;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-ne v0, v9, :cond_1

    .line 50
    .line 51
    move-object v8, v0

    .line 52
    :cond_1
    return-object v8

    .line 53
    :pswitch_1
    new-instance v10, Ldd6;

    .line 54
    .line 55
    move-object v12, v0

    .line 56
    check-cast v12, Lnu6;

    .line 57
    .line 58
    const/16 v16, 0x0

    .line 59
    .line 60
    const/16 v17, 0x4

    .line 61
    .line 62
    const/4 v11, 0x1

    .line 63
    const-class v13, Lnu6;

    .line 64
    .line 65
    const-string v14, "tryShowContextMenu"

    .line 66
    .line 67
    const-string v15, "tryShowContextMenu-k-4lQ0M(J)V"

    .line 68
    .line 69
    invoke-direct/range {v10 .. v17}, Ldd6;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 70
    .line 71
    .line 72
    new-instance v0, Ldc;

    .line 73
    .line 74
    invoke-direct {v0, v10, v7, v5}, Ldc;-><init>(Ljava/lang/Object;Lca1;B)V

    .line 75
    .line 76
    .line 77
    invoke-static {v1, v0, v6}, Ljn;->s(Lu05;Ll92;Lca1;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-eq v0, v9, :cond_2

    .line 82
    .line 83
    move-object v0, v8

    .line 84
    :cond_2
    if-ne v0, v9, :cond_3

    .line 85
    .line 86
    move-object v8, v0

    .line 87
    :cond_3
    return-object v8

    .line 88
    :pswitch_2
    new-instance v2, Ljb3;

    .line 89
    .line 90
    check-cast v0, Lom6;

    .line 91
    .line 92
    invoke-direct {v2, v0, v7, v3}, Ljb3;-><init>(Ljava/lang/Object;Lca1;B)V

    .line 93
    .line 94
    .line 95
    invoke-static {v1, v2, v6}, Ljn;->s(Lu05;Ll92;Lca1;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-ne v0, v9, :cond_4

    .line 100
    .line 101
    move-object v8, v0

    .line 102
    :cond_4
    return-object v8

    .line 103
    :pswitch_3
    check-cast v0, Lj66;

    .line 104
    .line 105
    iget-object v2, v0, Lj66;->D:Ll66;

    .line 106
    .line 107
    iget-object v0, v0, Lj66;->C:Lk66;

    .line 108
    .line 109
    invoke-static {v1, v2, v0, v6}, Lcc3;->p(Lu05;Lk04;Lev6;Lca1;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    if-ne v0, v9, :cond_5

    .line 114
    .line 115
    move-object v8, v0

    .line 116
    :cond_5
    return-object v8

    .line 117
    :pswitch_4
    check-cast v0, Le66;

    .line 118
    .line 119
    iget-object v0, v0, Le66;->E:Lj93;

    .line 120
    .line 121
    invoke-interface {v0}, Lj93;->getValue()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    check-cast v0, Lk04;

    .line 126
    .line 127
    invoke-static {v1, v0, v7, v6}, Lcc3;->p(Lu05;Lk04;Lev6;Lca1;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    if-ne v0, v9, :cond_6

    .line 132
    .line 133
    move-object v8, v0

    .line 134
    :cond_6
    return-object v8

    .line 135
    :pswitch_5
    new-instance v2, Lr10;

    .line 136
    .line 137
    check-cast v0, Lpq4;

    .line 138
    .line 139
    invoke-direct {v2, v0, v7, v5}, Lr10;-><init>(Ljava/lang/Object;Lca1;B)V

    .line 140
    .line 141
    .line 142
    move-object v0, v1

    .line 143
    check-cast v0, Loq6;

    .line 144
    .line 145
    invoke-virtual {v0, v2, v6}, Loq6;->G1(Ll92;Lca1;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    if-ne v0, v9, :cond_7

    .line 150
    .line 151
    move-object v8, v0

    .line 152
    :cond_7
    return-object v8

    .line 153
    :pswitch_6
    new-instance v2, Ls32;

    .line 154
    .line 155
    check-cast v0, Lyi1;

    .line 156
    .line 157
    const/16 v3, 0x8

    .line 158
    .line 159
    invoke-direct {v2, v1, v0, v7, v3}, Ls32;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lca1;B)V

    .line 160
    .line 161
    .line 162
    invoke-static {v2, v6}, Loq;->E(Ll92;Lca1;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    if-ne v0, v9, :cond_8

    .line 167
    .line 168
    move-object v8, v0

    .line 169
    :cond_8
    return-object v8

    .line 170
    :pswitch_7
    check-cast v0, Lk03;

    .line 171
    .line 172
    new-instance v11, Lh03;

    .line 173
    .line 174
    invoke-direct {v11, v0, v5}, Lh03;-><init>(Lk03;B)V

    .line 175
    .line 176
    .line 177
    new-instance v14, Lh03;

    .line 178
    .line 179
    const/4 v2, 0x2

    .line 180
    invoke-direct {v14, v0, v2}, Lh03;-><init>(Lk03;B)V

    .line 181
    .line 182
    .line 183
    new-instance v13, Lou2;

    .line 184
    .line 185
    invoke-direct {v13, v0, v3}, Lou2;-><init>(Ljava/lang/Object;B)V

    .line 186
    .line 187
    .line 188
    new-instance v12, Lt;

    .line 189
    .line 190
    const/16 v2, 0x15

    .line 191
    .line 192
    invoke-direct {v12, v0, v2}, Lt;-><init>(Ljava/lang/Object;B)V

    .line 193
    .line 194
    .line 195
    new-instance v10, Lrp1;

    .line 196
    .line 197
    const/4 v15, 0x0

    .line 198
    invoke-direct/range {v10 .. v15}, Lrp1;-><init>(Lh92;Ll92;Lw82;Lh92;Lca1;)V

    .line 199
    .line 200
    .line 201
    invoke-static {v1, v10, v6}, Ljn;->s(Lu05;Ll92;Lca1;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    if-eq v0, v9, :cond_9

    .line 206
    .line 207
    move-object v0, v8

    .line 208
    :cond_9
    if-ne v0, v9, :cond_a

    .line 209
    .line 210
    move-object v8, v0

    .line 211
    :cond_a
    return-object v8

    .line 212
    :pswitch_8
    check-cast v0, Lvg1;

    .line 213
    .line 214
    new-instance v11, Log1;

    .line 215
    .line 216
    invoke-direct {v11, v0, v4}, Log1;-><init>(Lvg1;B)V

    .line 217
    .line 218
    .line 219
    new-instance v14, Log1;

    .line 220
    .line 221
    invoke-direct {v14, v0, v5}, Log1;-><init>(Lvg1;B)V

    .line 222
    .line 223
    .line 224
    new-instance v13, Lpg1;

    .line 225
    .line 226
    invoke-direct {v13, v0, v4}, Lpg1;-><init>(Lvg1;B)V

    .line 227
    .line 228
    .line 229
    new-instance v12, Lzb1;

    .line 230
    .line 231
    invoke-direct {v12, v0, v1, v5}, Lzb1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 232
    .line 233
    .line 234
    new-instance v10, Lrp1;

    .line 235
    .line 236
    const/4 v15, 0x0

    .line 237
    invoke-direct/range {v10 .. v15}, Lrp1;-><init>(Lh92;Ll92;Lw82;Lh92;Lca1;)V

    .line 238
    .line 239
    .line 240
    invoke-static {v1, v10, v6}, Ljn;->s(Lu05;Ll92;Lca1;)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    if-eq v0, v9, :cond_b

    .line 245
    .line 246
    move-object v0, v8

    .line 247
    :cond_b
    if-ne v0, v9, :cond_c

    .line 248
    .line 249
    move-object v8, v0

    .line 250
    :cond_c
    return-object v8

    .line 251
    :pswitch_9
    new-instance v2, Ldc;

    .line 252
    .line 253
    check-cast v0, Lec;

    .line 254
    .line 255
    invoke-direct {v2, v0, v7, v4}, Ldc;-><init>(Ljava/lang/Object;Lca1;B)V

    .line 256
    .line 257
    .line 258
    invoke-static {v1, v2, v6}, Ljn;->s(Lu05;Ll92;Lca1;)Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    if-ne v0, v9, :cond_d

    .line 263
    .line 264
    move-object v8, v0

    .line 265
    :cond_d
    return-object v8

    .line 266
    :pswitch_a
    move-object v2, v0

    .line 267
    check-cast v2, Lv35;

    .line 268
    .line 269
    new-instance v3, Ly3;

    .line 270
    .line 271
    const/4 v4, 0x0

    .line 272
    invoke-direct {v3, v2, v4}, Ly3;-><init>(Lv35;Lca1;)V

    .line 273
    .line 274
    .line 275
    new-instance v0, Lx3;

    .line 276
    .line 277
    const/4 v5, 0x0

    .line 278
    invoke-direct/range {v0 .. v5}, Lx3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lca1;B)V

    .line 279
    .line 280
    .line 281
    invoke-static {v0, v6}, Loq;->E(Ll92;Lca1;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    if-eq v0, v9, :cond_e

    .line 286
    .line 287
    move-object v0, v8

    .line 288
    :cond_e
    if-ne v0, v9, :cond_f

    .line 289
    .line 290
    move-object v8, v0

    .line 291
    :cond_f
    return-object v8

    .line 292
    nop

    .line 293
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
