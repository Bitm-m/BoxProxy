.class public abstract Lay3;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# static fields
.field public static final a:Lox1;

.field public static b:F = 1.0f

.field public static final c:Lmy1;

.field public static final d:Lf02;

.field public static final e:Lmy1;

.field public static final f:Lf02;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lox1;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lox1;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lay3;->a:Lox1;

    .line 9
    .line 10
    new-instance v0, Lq21;

    .line 11
    .line 12
    const/4 v1, 0x5

    .line 13
    invoke-direct {v0, v1}, Lq21;-><init>(B)V

    .line 14
    .line 15
    .line 16
    const/16 v2, 0x12c

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    const/4 v4, 0x2

    .line 20
    invoke-static {v2, v3, v0, v4}, Lba7;->j0(IILws1;I)Lr87;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-static {v0, v4}, Lgy1;->e(Lg22;I)Lmy1;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    sput-object v0, Lay3;->c:Lmy1;

    .line 29
    .line 30
    new-instance v0, Lq21;

    .line 31
    .line 32
    invoke-direct {v0, v1}, Lq21;-><init>(B)V

    .line 33
    .line 34
    .line 35
    const/16 v1, 0xfa

    .line 36
    .line 37
    invoke-static {v1, v3, v0, v4}, Lba7;->j0(IILws1;I)Lr87;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-static {v0, v4}, Lgy1;->f(Lg22;I)Lf02;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    sput-object v0, Lay3;->d:Lf02;

    .line 46
    .line 47
    sget-object v0, Lfw;->D0:Lww4;

    .line 48
    .line 49
    invoke-static {v2, v3, v0, v4}, Lba7;->j0(IILws1;I)Lr87;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-static {v1, v4}, Lgy1;->e(Lg22;I)Lmy1;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    sput-object v1, Lay3;->e:Lmy1;

    .line 58
    .line 59
    const/16 v1, 0x96

    .line 60
    .line 61
    invoke-static {v1, v3, v0, v4}, Lba7;->j0(IILws1;I)Lr87;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {v0, v4}, Lgy1;->f(Lg22;I)Lf02;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    sput-object v0, Lay3;->f:Lf02;

    .line 70
    .line 71
    return-void
.end method
