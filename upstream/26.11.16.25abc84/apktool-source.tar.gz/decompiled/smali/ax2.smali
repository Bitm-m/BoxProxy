.class public final Lax2;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lro3;

.field public final c:I

.field public final d:Lgp5;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lro3;Lgp5;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lax2;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lax2;->b:Lro3;

    .line 7
    .line 8
    iput-object p3, p0, Lax2;->d:Lgp5;

    .line 9
    .line 10
    iput p4, p0, Lax2;->c:I

    .line 11
    .line 12
    return-void
.end method
