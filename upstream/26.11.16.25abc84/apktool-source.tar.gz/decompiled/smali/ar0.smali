.class public final synthetic Lar0;
.super Ljava/lang/Object;
.source "r8-map-id-5db1e336ca56135def9a720c856abcf34e131b55b2e99e93ab23f26fa9bdffdb"

# interfaces
.implements Ll92;


# instance fields
.field public final synthetic i:Lw82;

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Lov0;

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:F

.field public final synthetic p:Lmz3;

.field public final synthetic q:F

.field public final synthetic r:Lh92;

.field public final synthetic s:Lh92;

.field public final synthetic t:Lmz3;


# direct methods
.method public synthetic constructor <init>(Lw82;ZZLov0;FFFLmz3;FLh92;Lh92;Lmz3;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lar0;->i:Lw82;

    .line 5
    .line 6
    iput-boolean p2, p0, Lar0;->j:Z

    .line 7
    .line 8
    iput-boolean p3, p0, Lar0;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Lar0;->l:Lov0;

    .line 11
    .line 12
    iput p5, p0, Lar0;->m:F

    .line 13
    .line 14
    iput p6, p0, Lar0;->n:F

    .line 15
    .line 16
    iput p7, p0, Lar0;->o:F

    .line 17
    .line 18
    iput-object p8, p0, Lar0;->p:Lmz3;

    .line 19
    .line 20
    iput p9, p0, Lar0;->q:F

    .line 21
    .line 22
    iput-object p10, p0, Lar0;->r:Lh92;

    .line 23
    .line 24
    iput-object p11, p0, Lar0;->s:Lh92;

    .line 25
    .line 26
    iput-object p12, p0, Lar0;->t:Lmz3;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    move-object v12, p1

    .line 2
    check-cast v12, Lla2;

    .line 3
    .line 4
    move-object/from16 v0, p2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    const/16 v0, 0x1b1

    .line 12
    .line 13
    invoke-static {v0}, Lt36;->a0(I)I

    .line 14
    .line 15
    .line 16
    move-result v13

    .line 17
    iget-object v0, p0, Lar0;->i:Lw82;

    .line 18
    .line 19
    iget-boolean v1, p0, Lar0;->j:Z

    .line 20
    .line 21
    iget-boolean v2, p0, Lar0;->k:Z

    .line 22
    .line 23
    iget-object v3, p0, Lar0;->l:Lov0;

    .line 24
    .line 25
    iget v4, p0, Lar0;->m:F

    .line 26
    .line 27
    iget v5, p0, Lar0;->n:F

    .line 28
    .line 29
    iget v6, p0, Lar0;->o:F

    .line 30
    .line 31
    iget-object v7, p0, Lar0;->p:Lmz3;

    .line 32
    .line 33
    iget v8, p0, Lar0;->q:F

    .line 34
    .line 35
    iget-object v9, p0, Lar0;->r:Lh92;

    .line 36
    .line 37
    iget-object v10, p0, Lar0;->s:Lh92;

    .line 38
    .line 39
    iget-object v11, p0, Lar0;->t:Lmz3;

    .line 40
    .line 41
    invoke-static/range {v0 .. v13}, Ltj;->e(Lw82;ZZLov0;FFFLmz3;FLh92;Lh92;Lmz3;Lla2;I)V

    .line 42
    .line 43
    .line 44
    sget-object p0, Loc7;->a:Loc7;

    .line 45
    .line 46
    return-object p0
.end method
