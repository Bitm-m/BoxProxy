.class public final Lbc0;
.super Ljs6;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public j:B

.field public final synthetic k:Lcom/box/app/notification/BoxPersistentNotificationService;


# direct methods
.method public synthetic constructor <init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lbc0;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lbc0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Ljs6;-><init>(ILia1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lia1;)Lia1;
    .locals 1

    .line 1
    iget-byte p1, p0, Lbc0;->i:B

    .line 2
    .line 3
    iget-object p0, p0, Lbc0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p1, Lbc0;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p1, p0, p2, v0}, Lbc0;-><init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V

    .line 12
    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_0
    new-instance p1, Lbc0;

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    invoke-direct {p1, p0, p2, v0}, Lbc0;-><init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V

    .line 19
    .line 20
    .line 21
    return-object p1

    .line 22
    :pswitch_1
    new-instance p1, Lbc0;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-direct {p1, p0, p2, v0}, Lbc0;-><init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V

    .line 26
    .line 27
    .line 28
    return-object p1

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lbc0;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    check-cast p1, Lrf1;

    .line 6
    .line 7
    check-cast p2, Lia1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lbc0;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lbc0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lbc0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Lbc0;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lbc0;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lbc0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_1
    invoke-virtual {p0, p1, p2}, Lbc0;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Lbc0;

    .line 39
    .line 40
    invoke-virtual {p0, v1}, Lbc0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte v0, p0, Lbc0;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    const v2, 0x7f0f01f3

    .line 6
    .line 7
    .line 8
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 9
    .line 10
    sget-object v4, Lsf1;->i:Lsf1;

    .line 11
    .line 12
    iget-object v5, p0, Lbc0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    const/4 v7, 0x2

    .line 16
    const/4 v8, 0x0

    .line 17
    const/4 v9, 0x0

    .line 18
    packed-switch v0, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    iget-byte v0, p0, Lbc0;->j:B

    .line 22
    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    if-eq v0, v6, :cond_1

    .line 26
    .line 27
    if-ne v0, v7, :cond_0

    .line 28
    .line 29
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_0
    invoke-static {v3}, Lj02;->c(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    move-object v1, v9

    .line 37
    goto :goto_1

    .line 38
    :cond_1
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_2
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    sget-object p1, Loq2;->a:Loq2;

    .line 46
    .line 47
    iput-byte v6, p0, Lbc0;->j:B

    .line 48
    .line 49
    sget-object p1, Lko1;->a:Ljk1;

    .line 50
    .line 51
    sget-object p1, Lbk1;->k:Lbk1;

    .line 52
    .line 53
    new-instance v0, Lmq2;

    .line 54
    .line 55
    invoke-direct {v0, v7, v9, v7}, Lmq2;-><init>(ILia1;B)V

    .line 56
    .line 57
    .line 58
    invoke-static {p1, v0, p0}, Lom;->k0(Lhf1;Lua2;Lia1;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    if-eq p1, v4, :cond_5

    .line 63
    .line 64
    :goto_0
    check-cast p1, Lkq2;

    .line 65
    .line 66
    iget-boolean v0, p1, Lkq2;->a:Z

    .line 67
    .line 68
    if-nez v0, :cond_4

    .line 69
    .line 70
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    iget-object p1, p1, Lkq2;->b:Ljava/lang/String;

    .line 75
    .line 76
    invoke-static {p1}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    if-eqz v3, :cond_3

    .line 81
    .line 82
    invoke-virtual {v5, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    :cond_3
    invoke-static {v0, p1, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 94
    .line 95
    .line 96
    :cond_4
    sget p1, Lcom/box/app/notification/BoxPersistentNotificationService;->r:I

    .line 97
    .line 98
    iput-object v9, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->q:Lyb0;

    .line 99
    .line 100
    iget-object p1, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->j:Lmj7;

    .line 101
    .line 102
    iput-object v9, p1, Lmj7;->j:Ljava/lang/Object;

    .line 103
    .line 104
    iput-byte v7, p0, Lbc0;->j:B

    .line 105
    .line 106
    invoke-virtual {v5, v8, v6, p0}, Lcom/box/app/notification/BoxPersistentNotificationService;->g(ZZLja1;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    if-ne p0, v4, :cond_6

    .line 111
    .line 112
    :cond_5
    move-object v1, v4

    .line 113
    :cond_6
    :goto_1
    return-object v1

    .line 114
    :pswitch_0
    iget-byte v0, p0, Lbc0;->j:B

    .line 115
    .line 116
    if-eqz v0, :cond_9

    .line 117
    .line 118
    if-eq v0, v6, :cond_8

    .line 119
    .line 120
    if-ne v0, v7, :cond_7

    .line 121
    .line 122
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    goto :goto_3

    .line 126
    :cond_7
    invoke-static {v3}, Lj02;->c(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    move-object v1, v9

    .line 130
    goto :goto_3

    .line 131
    :cond_8
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_9
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    sget-object p1, Loq2;->a:Loq2;

    .line 139
    .line 140
    iput-byte v6, p0, Lbc0;->j:B

    .line 141
    .line 142
    sget-object p1, Lko1;->a:Ljk1;

    .line 143
    .line 144
    sget-object p1, Lbk1;->k:Lbk1;

    .line 145
    .line 146
    new-instance v0, Lmq2;

    .line 147
    .line 148
    invoke-direct {v0, v7, v9, v8}, Lmq2;-><init>(ILia1;B)V

    .line 149
    .line 150
    .line 151
    invoke-static {p1, v0, p0}, Lom;->k0(Lhf1;Lua2;Lia1;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    if-eq p1, v4, :cond_c

    .line 156
    .line 157
    :goto_2
    check-cast p1, Lkq2;

    .line 158
    .line 159
    iget-boolean v0, p1, Lkq2;->a:Z

    .line 160
    .line 161
    if-nez v0, :cond_b

    .line 162
    .line 163
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    iget-object v3, p1, Lkq2;->b:Ljava/lang/String;

    .line 168
    .line 169
    invoke-static {v3}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 170
    .line 171
    .line 172
    move-result v10

    .line 173
    if-eqz v10, :cond_a

    .line 174
    .line 175
    invoke-virtual {v5, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v3

    .line 179
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 180
    .line 181
    .line 182
    :cond_a
    invoke-static {v0, v3, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 187
    .line 188
    .line 189
    :cond_b
    sget v0, Lcom/box/app/notification/BoxPersistentNotificationService;->r:I

    .line 190
    .line 191
    iput-object v9, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->q:Lyb0;

    .line 192
    .line 193
    iget-object v0, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->j:Lmj7;

    .line 194
    .line 195
    iput-object v9, v0, Lmj7;->j:Ljava/lang/Object;

    .line 196
    .line 197
    iget-boolean p1, p1, Lkq2;->a:Z

    .line 198
    .line 199
    iput-byte v7, p0, Lbc0;->j:B

    .line 200
    .line 201
    invoke-virtual {v5, p1, v6, p0}, Lcom/box/app/notification/BoxPersistentNotificationService;->g(ZZLja1;)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object p0

    .line 205
    if-ne p0, v4, :cond_d

    .line 206
    .line 207
    :cond_c
    move-object v1, v4

    .line 208
    :cond_d
    :goto_3
    return-object v1

    .line 209
    :pswitch_1
    iget-byte v0, p0, Lbc0;->j:B

    .line 210
    .line 211
    if-eqz v0, :cond_10

    .line 212
    .line 213
    if-eq v0, v6, :cond_f

    .line 214
    .line 215
    if-ne v0, v7, :cond_e

    .line 216
    .line 217
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 218
    .line 219
    .line 220
    goto :goto_5

    .line 221
    :cond_e
    invoke-static {v3}, Lj02;->c(Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    move-object v1, v9

    .line 225
    goto :goto_5

    .line 226
    :cond_f
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    goto :goto_4

    .line 230
    :cond_10
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    sget-object p1, Loq2;->a:Loq2;

    .line 234
    .line 235
    iput-byte v6, p0, Lbc0;->j:B

    .line 236
    .line 237
    sget-object p1, Lko1;->a:Ljk1;

    .line 238
    .line 239
    sget-object p1, Lbk1;->k:Lbk1;

    .line 240
    .line 241
    new-instance v0, La4;

    .line 242
    .line 243
    const/16 v3, 0x9

    .line 244
    .line 245
    invoke-direct {v0, v7, v9, v3}, La4;-><init>(ILia1;B)V

    .line 246
    .line 247
    .line 248
    invoke-static {p1, v0, p0}, Lom;->k0(Lhf1;Lua2;Lia1;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    if-eq p1, v4, :cond_13

    .line 253
    .line 254
    :goto_4
    check-cast p1, Lkq2;

    .line 255
    .line 256
    iget-boolean v0, p1, Lkq2;->a:Z

    .line 257
    .line 258
    if-nez v0, :cond_12

    .line 259
    .line 260
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    iget-object p1, p1, Lkq2;->b:Ljava/lang/String;

    .line 265
    .line 266
    invoke-static {p1}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 267
    .line 268
    .line 269
    move-result v3

    .line 270
    if-eqz v3, :cond_11

    .line 271
    .line 272
    invoke-virtual {v5, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object p1

    .line 276
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 277
    .line 278
    .line 279
    :cond_11
    invoke-static {v0, p1, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 280
    .line 281
    .line 282
    move-result-object p1

    .line 283
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 284
    .line 285
    .line 286
    :cond_12
    sget p1, Lcom/box/app/notification/BoxPersistentNotificationService;->r:I

    .line 287
    .line 288
    iput-object v9, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->q:Lyb0;

    .line 289
    .line 290
    iget-object p1, v5, Lcom/box/app/notification/BoxPersistentNotificationService;->j:Lmj7;

    .line 291
    .line 292
    iput-object v9, p1, Lmj7;->j:Ljava/lang/Object;

    .line 293
    .line 294
    iput-byte v7, p0, Lbc0;->j:B

    .line 295
    .line 296
    invoke-static {v5, v6, p0, v6}, Lcom/box/app/notification/BoxPersistentNotificationService;->h(Lcom/box/app/notification/BoxPersistentNotificationService;ZLjs6;I)Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object p0

    .line 300
    if-ne p0, v4, :cond_14

    .line 301
    .line 302
    :cond_13
    move-object v1, v4

    .line 303
    :cond_14
    :goto_5
    return-object v1

    .line 304
    nop

    .line 305
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
