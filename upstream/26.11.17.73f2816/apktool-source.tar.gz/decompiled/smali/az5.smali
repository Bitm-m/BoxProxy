.class public final synthetic Laz5;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/util/List;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;

.field public final synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ley5;Ljava/util/List;Le73;Lw06;Lij2;Lv06;Lne3;Lqa2;Landroid/content/Context;Llp3;)V
    .locals 1

    .line 28
    const/4 v0, 0x1

    iput-byte v0, p0, Laz5;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laz5;->j:Ljava/lang/Object;

    iput-object p2, p0, Laz5;->k:Ljava/util/List;

    iput-object p3, p0, Laz5;->l:Ljava/lang/Object;

    iput-object p4, p0, Laz5;->m:Ljava/lang/Object;

    iput-object p5, p0, Laz5;->n:Ljava/lang/Object;

    iput-object p6, p0, Laz5;->o:Ljava/lang/Object;

    iput-object p7, p0, Laz5;->p:Ljava/lang/Object;

    iput-object p8, p0, Laz5;->q:Ljava/lang/Object;

    iput-object p9, p0, Laz5;->r:Ljava/lang/Object;

    iput-object p10, p0, Laz5;->s:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ley5;Ljava/util/List;Le73;Lw06;Lv06;Lne3;Lqa2;Lij2;Landroid/content/Context;Llp3;)V
    .locals 1

    .line 29
    const/4 v0, 0x0

    iput-byte v0, p0, Laz5;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laz5;->j:Ljava/lang/Object;

    iput-object p2, p0, Laz5;->k:Ljava/util/List;

    iput-object p3, p0, Laz5;->l:Ljava/lang/Object;

    iput-object p4, p0, Laz5;->m:Ljava/lang/Object;

    iput-object p5, p0, Laz5;->o:Ljava/lang/Object;

    iput-object p6, p0, Laz5;->p:Ljava/lang/Object;

    iput-object p7, p0, Laz5;->q:Ljava/lang/Object;

    iput-object p8, p0, Laz5;->n:Ljava/lang/Object;

    iput-object p9, p0, Laz5;->r:Ljava/lang/Object;

    iput-object p10, p0, Laz5;->s:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ltk2;Ljava/util/List;Lj61;Ljava/util/List;Lq41;Lw44;Lw44;Lw44;Lw44;Lf61;Lw44;)V
    .locals 0

    .line 1
    const/4 p3, 0x2

    .line 2
    iput-byte p3, p0, Laz5;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Laz5;->j:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Laz5;->k:Ljava/util/List;

    .line 10
    .line 11
    iput-object p4, p0, Laz5;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p5, p0, Laz5;->m:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p6, p0, Laz5;->o:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p7, p0, Laz5;->p:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p8, p0, Laz5;->q:Ljava/lang/Object;

    .line 20
    .line 21
    iput-object p9, p0, Laz5;->n:Ljava/lang/Object;

    .line 22
    .line 23
    iput-object p10, p0, Laz5;->r:Ljava/lang/Object;

    .line 24
    .line 25
    iput-object p11, p0, Laz5;->s:Ljava/lang/Object;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laz5;->i:B

    .line 4
    .line 5
    const-string v3, "directory-status"

    .line 6
    .line 7
    const/16 v4, 0xa

    .line 8
    .line 9
    sget-object v5, Lne7;->a:Lne7;

    .line 10
    .line 11
    const/4 v6, 0x1

    .line 12
    iget-object v7, v0, Laz5;->s:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v8, v0, Laz5;->r:Ljava/lang/Object;

    .line 15
    .line 16
    iget-object v9, v0, Laz5;->n:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v10, v0, Laz5;->q:Ljava/lang/Object;

    .line 19
    .line 20
    iget-object v11, v0, Laz5;->p:Ljava/lang/Object;

    .line 21
    .line 22
    iget-object v12, v0, Laz5;->o:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v13, v0, Laz5;->m:Ljava/lang/Object;

    .line 25
    .line 26
    iget-object v14, v0, Laz5;->l:Ljava/lang/Object;

    .line 27
    .line 28
    iget-object v15, v0, Laz5;->j:Ljava/lang/Object;

    .line 29
    .line 30
    const/4 v2, 0x2

    .line 31
    packed-switch v1, :pswitch_data_0

    .line 32
    .line 33
    .line 34
    check-cast v15, Ltk2;

    .line 35
    .line 36
    move-object/from16 v18, v14

    .line 37
    .line 38
    check-cast v18, Ljava/util/List;

    .line 39
    .line 40
    move-object/from16 v19, v13

    .line 41
    .line 42
    check-cast v19, Lq41;

    .line 43
    .line 44
    move-object/from16 v21, v12

    .line 45
    .line 46
    check-cast v21, Lw44;

    .line 47
    .line 48
    move-object/from16 v22, v11

    .line 49
    .line 50
    check-cast v22, Lw44;

    .line 51
    .line 52
    move-object/from16 v23, v10

    .line 53
    .line 54
    check-cast v23, Lw44;

    .line 55
    .line 56
    move-object/from16 v24, v9

    .line 57
    .line 58
    check-cast v24, Lw44;

    .line 59
    .line 60
    move-object/from16 v26, v8

    .line 61
    .line 62
    check-cast v26, Lf61;

    .line 63
    .line 64
    move-object/from16 v27, v7

    .line 65
    .line 66
    check-cast v27, Lw44;

    .line 67
    .line 68
    move-object/from16 v1, p1

    .line 69
    .line 70
    check-cast v1, Lce3;

    .line 71
    .line 72
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    iget-boolean v3, v15, Ltk2;->l:Z

    .line 76
    .line 77
    iget-boolean v7, v15, Ltk2;->j:Z

    .line 78
    .line 79
    if-nez v3, :cond_0

    .line 80
    .line 81
    if-eqz v7, :cond_1

    .line 82
    .line 83
    :cond_0
    const-string v8, "connections-top-inset"

    .line 84
    .line 85
    sget-object v9, Lbs3;->n:Lc01;

    .line 86
    .line 87
    invoke-static {v1, v8, v9, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 88
    .line 89
    .line 90
    :cond_1
    if-eqz v3, :cond_2

    .line 91
    .line 92
    const-string v0, "connections-api-unavailable"

    .line 93
    .line 94
    sget-object v4, Lbs3;->o:Lc01;

    .line 95
    .line 96
    invoke-static {v1, v0, v4, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 97
    .line 98
    .line 99
    goto/16 :goto_0

    .line 100
    .line 101
    :cond_2
    if-eqz v7, :cond_5

    .line 102
    .line 103
    iget-boolean v8, v15, Ltk2;->k:Z

    .line 104
    .line 105
    if-eqz v8, :cond_3

    .line 106
    .line 107
    const-string v8, "connections-api-reconnecting"

    .line 108
    .line 109
    sget-object v9, Lbs3;->p:Lc01;

    .line 110
    .line 111
    invoke-static {v1, v8, v9, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 112
    .line 113
    .line 114
    :cond_3
    new-instance v16, La2;

    .line 115
    .line 116
    const/16 v25, 0x1

    .line 117
    .line 118
    iget-object v0, v0, Laz5;->k:Ljava/util/List;

    .line 119
    .line 120
    move-object/from16 v17, v0

    .line 121
    .line 122
    move-object/from16 v20, v15

    .line 123
    .line 124
    invoke-direct/range {v16 .. v25}, La2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 125
    .line 126
    .line 127
    move-object/from16 v0, v16

    .line 128
    .line 129
    move-object/from16 v8, v17

    .line 130
    .line 131
    move-object/from16 v13, v19

    .line 132
    .line 133
    new-instance v9, Lc01;

    .line 134
    .line 135
    const v10, -0x5ddcb2f0

    .line 136
    .line 137
    .line 138
    invoke-direct {v9, v10, v6, v0}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    const-string v0, "connections-header"

    .line 142
    .line 143
    invoke-static {v1, v0, v9, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 144
    .line 145
    .line 146
    new-instance v0, Lzw0;

    .line 147
    .line 148
    const/16 v9, 0x15

    .line 149
    .line 150
    invoke-direct {v0, v9}, Lzw0;-><init>(B)V

    .line 151
    .line 152
    .line 153
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 154
    .line 155
    .line 156
    move-result v9

    .line 157
    new-instance v10, Lc0;

    .line 158
    .line 159
    invoke-direct {v10, v0, v8, v4}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 160
    .line 161
    .line 162
    new-instance v0, Ld0;

    .line 163
    .line 164
    const/4 v4, 0x7

    .line 165
    invoke-direct {v0, v8, v4}, Ld0;-><init>(Ljava/util/List;B)V

    .line 166
    .line 167
    .line 168
    move-object/from16 v28, v24

    .line 169
    .line 170
    new-instance v24, Le71;

    .line 171
    .line 172
    const/16 v29, 0x1

    .line 173
    .line 174
    move-object/from16 v25, v8

    .line 175
    .line 176
    invoke-direct/range {v24 .. v29}, Le71;-><init>(Ljava/util/List;Lf61;Lw44;Lw44;B)V

    .line 177
    .line 178
    .line 179
    move-object/from16 v8, v24

    .line 180
    .line 181
    move-object/from16 v17, v25

    .line 182
    .line 183
    move-object/from16 v4, v28

    .line 184
    .line 185
    new-instance v11, Lc01;

    .line 186
    .line 187
    const v12, 0x2fd4df92

    .line 188
    .line 189
    .line 190
    invoke-direct {v11, v12, v6, v8}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v1, v9, v10, v0, v11}, Lce3;->P(ILqa2;Lqa2;Lc01;)V

    .line 194
    .line 195
    .line 196
    iget-boolean v0, v15, Ltk2;->g:Z

    .line 197
    .line 198
    if-eqz v0, :cond_4

    .line 199
    .line 200
    const-string v0, "connections-filtering"

    .line 201
    .line 202
    sget-object v4, Lbs3;->q:Lc01;

    .line 203
    .line 204
    invoke-static {v1, v0, v4, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 205
    .line 206
    .line 207
    goto :goto_0

    .line 208
    :cond_4
    invoke-interface/range {v17 .. v17}, Ljava/util/List;->isEmpty()Z

    .line 209
    .line 210
    .line 211
    move-result v0

    .line 212
    if-eqz v0, :cond_5

    .line 213
    .line 214
    new-instance v0, Lsz3;

    .line 215
    .line 216
    const/16 v8, 0xb

    .line 217
    .line 218
    invoke-direct {v0, v13, v4, v8}, Lsz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 219
    .line 220
    .line 221
    new-instance v4, Lc01;

    .line 222
    .line 223
    const v8, -0x685ec474

    .line 224
    .line 225
    .line 226
    invoke-direct {v4, v8, v6, v0}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    const-string v0, "connections-filter-empty"

    .line 230
    .line 231
    invoke-static {v1, v0, v4, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 232
    .line 233
    .line 234
    :cond_5
    :goto_0
    if-nez v3, :cond_6

    .line 235
    .line 236
    if-eqz v7, :cond_7

    .line 237
    .line 238
    :cond_6
    const-string v0, "connections-bottom-inset"

    .line 239
    .line 240
    sget-object v3, Lbs3;->r:Lc01;

    .line 241
    .line 242
    invoke-static {v1, v0, v3, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 243
    .line 244
    .line 245
    :cond_7
    return-object v5

    .line 246
    :pswitch_0
    move-object/from16 v18, v15

    .line 247
    .line 248
    check-cast v18, Ley5;

    .line 249
    .line 250
    check-cast v14, Le73;

    .line 251
    .line 252
    move-object/from16 v21, v13

    .line 253
    .line 254
    check-cast v21, Lw06;

    .line 255
    .line 256
    move-object/from16 v20, v9

    .line 257
    .line 258
    check-cast v20, Lij2;

    .line 259
    .line 260
    move-object/from16 v22, v12

    .line 261
    .line 262
    check-cast v22, Lv06;

    .line 263
    .line 264
    move-object/from16 v23, v11

    .line 265
    .line 266
    check-cast v23, Lne3;

    .line 267
    .line 268
    move-object/from16 v24, v10

    .line 269
    .line 270
    check-cast v24, Lqa2;

    .line 271
    .line 272
    move-object/from16 v25, v8

    .line 273
    .line 274
    check-cast v25, Landroid/content/Context;

    .line 275
    .line 276
    move-object/from16 v26, v7

    .line 277
    .line 278
    check-cast v26, Llp3;

    .line 279
    .line 280
    move-object/from16 v1, p1

    .line 281
    .line 282
    check-cast v1, Lce3;

    .line 283
    .line 284
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 285
    .line 286
    .line 287
    invoke-virtual/range {v18 .. v18}, Ley5;->d()Z

    .line 288
    .line 289
    .line 290
    move-result v7

    .line 291
    iget-object v8, v0, Laz5;->k:Ljava/util/List;

    .line 292
    .line 293
    if-nez v7, :cond_8

    .line 294
    .line 295
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 296
    .line 297
    .line 298
    move-result v0

    .line 299
    if-eqz v0, :cond_9

    .line 300
    .line 301
    :cond_8
    new-instance v7, Lcz5;

    .line 302
    .line 303
    const/4 v12, 0x1

    .line 304
    move-object v10, v14

    .line 305
    move-object/from16 v9, v18

    .line 306
    .line 307
    move-object/from16 v11, v21

    .line 308
    .line 309
    invoke-direct/range {v7 .. v12}, Lcz5;-><init>(Ljava/util/List;Ley5;Le73;Lw06;B)V

    .line 310
    .line 311
    .line 312
    new-instance v0, Lc01;

    .line 313
    .line 314
    const v9, -0x3af1c9fc

    .line 315
    .line 316
    .line 317
    invoke-direct {v0, v9, v6, v7}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    invoke-static {v1, v3, v0, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 321
    .line 322
    .line 323
    :cond_9
    new-instance v0, Lst5;

    .line 324
    .line 325
    invoke-direct {v0, v4}, Lst5;-><init>(B)V

    .line 326
    .line 327
    .line 328
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 329
    .line 330
    .line 331
    move-result v2

    .line 332
    new-instance v3, Lc0;

    .line 333
    .line 334
    const/16 v4, 0x1d

    .line 335
    .line 336
    invoke-direct {v3, v0, v8, v4}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 337
    .line 338
    .line 339
    new-instance v0, Ld0;

    .line 340
    .line 341
    const/16 v4, 0x17

    .line 342
    .line 343
    invoke-direct {v0, v8, v4}, Ld0;-><init>(Ljava/util/List;B)V

    .line 344
    .line 345
    .line 346
    new-instance v16, Luz5;

    .line 347
    .line 348
    move-object/from16 v19, v8

    .line 349
    .line 350
    move-object/from16 v17, v8

    .line 351
    .line 352
    invoke-direct/range {v16 .. v26}, Luz5;-><init>(Ljava/util/List;Ley5;Ljava/util/List;Lij2;Lw06;Lv06;Lne3;Lqa2;Landroid/content/Context;Llp3;)V

    .line 353
    .line 354
    .line 355
    move-object/from16 v4, v16

    .line 356
    .line 357
    new-instance v7, Lc01;

    .line 358
    .line 359
    const v8, 0x799532c4

    .line 360
    .line 361
    .line 362
    invoke-direct {v7, v8, v6, v4}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 363
    .line 364
    .line 365
    invoke-virtual {v1, v2, v3, v0, v7}, Lce3;->P(ILqa2;Lqa2;Lc01;)V

    .line 366
    .line 367
    .line 368
    return-object v5

    .line 369
    :pswitch_1
    move-object/from16 v18, v15

    .line 370
    .line 371
    check-cast v18, Ley5;

    .line 372
    .line 373
    check-cast v14, Le73;

    .line 374
    .line 375
    move-object/from16 v24, v13

    .line 376
    .line 377
    check-cast v24, Lw06;

    .line 378
    .line 379
    move-object/from16 v20, v12

    .line 380
    .line 381
    check-cast v20, Lv06;

    .line 382
    .line 383
    move-object/from16 v21, v11

    .line 384
    .line 385
    check-cast v21, Lne3;

    .line 386
    .line 387
    move-object/from16 v22, v10

    .line 388
    .line 389
    check-cast v22, Lqa2;

    .line 390
    .line 391
    move-object/from16 v23, v9

    .line 392
    .line 393
    check-cast v23, Lij2;

    .line 394
    .line 395
    move-object/from16 v25, v8

    .line 396
    .line 397
    check-cast v25, Landroid/content/Context;

    .line 398
    .line 399
    move-object/from16 v26, v7

    .line 400
    .line 401
    check-cast v26, Llp3;

    .line 402
    .line 403
    move-object/from16 v1, p1

    .line 404
    .line 405
    check-cast v1, Lce3;

    .line 406
    .line 407
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 408
    .line 409
    .line 410
    invoke-virtual/range {v18 .. v18}, Ley5;->d()Z

    .line 411
    .line 412
    .line 413
    move-result v4

    .line 414
    iget-object v10, v0, Laz5;->k:Ljava/util/List;

    .line 415
    .line 416
    if-nez v4, :cond_a

    .line 417
    .line 418
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    .line 419
    .line 420
    .line 421
    move-result v0

    .line 422
    if-eqz v0, :cond_b

    .line 423
    .line 424
    :cond_a
    new-instance v9, Lcz5;

    .line 425
    .line 426
    move-object v12, v14

    .line 427
    const/4 v14, 0x0

    .line 428
    move-object/from16 v11, v18

    .line 429
    .line 430
    move-object/from16 v13, v24

    .line 431
    .line 432
    invoke-direct/range {v9 .. v14}, Lcz5;-><init>(Ljava/util/List;Ley5;Le73;Lw06;B)V

    .line 433
    .line 434
    .line 435
    new-instance v0, Lc01;

    .line 436
    .line 437
    const v4, 0x6b0eb0cc

    .line 438
    .line 439
    .line 440
    invoke-direct {v0, v4, v6, v9}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 441
    .line 442
    .line 443
    invoke-static {v1, v3, v0, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 444
    .line 445
    .line 446
    :cond_b
    new-instance v0, Lst5;

    .line 447
    .line 448
    const/16 v2, 0x9

    .line 449
    .line 450
    invoke-direct {v0, v2}, Lst5;-><init>(B)V

    .line 451
    .line 452
    .line 453
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 454
    .line 455
    .line 456
    move-result v2

    .line 457
    new-instance v3, Lc0;

    .line 458
    .line 459
    const/16 v4, 0x1c

    .line 460
    .line 461
    invoke-direct {v3, v0, v10, v4}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 462
    .line 463
    .line 464
    new-instance v0, Ld0;

    .line 465
    .line 466
    const/16 v4, 0x16

    .line 467
    .line 468
    invoke-direct {v0, v10, v4}, Ld0;-><init>(Ljava/util/List;B)V

    .line 469
    .line 470
    .line 471
    new-instance v16, Luz5;

    .line 472
    .line 473
    move-object/from16 v19, v10

    .line 474
    .line 475
    move-object/from16 v17, v10

    .line 476
    .line 477
    invoke-direct/range {v16 .. v26}, Luz5;-><init>(Ljava/util/List;Ley5;Ljava/util/List;Lv06;Lne3;Lqa2;Lij2;Lw06;Landroid/content/Context;Llp3;)V

    .line 478
    .line 479
    .line 480
    move-object/from16 v4, v16

    .line 481
    .line 482
    new-instance v7, Lc01;

    .line 483
    .line 484
    const v8, 0x799532c4

    .line 485
    .line 486
    .line 487
    invoke-direct {v7, v8, v6, v4}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 488
    .line 489
    .line 490
    invoke-virtual {v1, v2, v3, v0, v7}, Lce3;->P(ILqa2;Lqa2;Lc01;)V

    .line 491
    .line 492
    .line 493
    return-object v5

    .line 494
    nop

    .line 495
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
