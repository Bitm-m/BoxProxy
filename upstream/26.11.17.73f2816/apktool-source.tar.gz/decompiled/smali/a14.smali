.class public final synthetic La14;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Lud6;

.field public final synthetic j:Ld14;

.field public final synthetic k:Lfa2;

.field public final synthetic l:J

.field public final synthetic m:Li14;

.field public final synthetic n:Lfa2;

.field public final synthetic o:F

.field public final synthetic p:Z

.field public final synthetic q:Lc01;

.field public final synthetic r:Lw33;

.field public final synthetic s:Lub6;

.field public final synthetic t:J

.field public final synthetic u:J

.field public final synthetic v:Lc01;


# direct methods
.method public synthetic constructor <init>(Lud6;Ld14;Lfa2;JLi14;Lfa2;FZLc01;Lw33;Lub6;JJLc01;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La14;->i:Lud6;

    .line 5
    .line 6
    iput-object p2, p0, La14;->j:Ld14;

    .line 7
    .line 8
    iput-object p3, p0, La14;->k:Lfa2;

    .line 9
    .line 10
    iput-wide p4, p0, La14;->l:J

    .line 11
    .line 12
    iput-object p6, p0, La14;->m:Li14;

    .line 13
    .line 14
    iput-object p7, p0, La14;->n:Lfa2;

    .line 15
    .line 16
    iput p8, p0, La14;->o:F

    .line 17
    .line 18
    iput-boolean p9, p0, La14;->p:Z

    .line 19
    .line 20
    iput-object p10, p0, La14;->q:Lc01;

    .line 21
    .line 22
    iput-object p11, p0, La14;->r:Lw33;

    .line 23
    .line 24
    iput-object p12, p0, La14;->s:Lub6;

    .line 25
    .line 26
    iput-wide p13, p0, La14;->t:J

    .line 27
    .line 28
    move-wide p1, p15

    .line 29
    iput-wide p1, p0, La14;->u:J

    .line 30
    .line 31
    move-object/from16 p1, p17

    .line 32
    .line 33
    iput-object p1, p0, La14;->v:Lc01;

    .line 34
    .line 35
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v14, p1

    .line 4
    .line 5
    check-cast v14, Lub2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    and-int/lit8 v2, v1, 0x3

    .line 16
    .line 17
    const/4 v3, 0x2

    .line 18
    const/4 v4, 0x0

    .line 19
    const/4 v9, 0x1

    .line 20
    if-eq v2, v3, :cond_0

    .line 21
    .line 22
    move v2, v9

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    move v2, v4

    .line 25
    :goto_0
    and-int/2addr v1, v9

    .line 26
    invoke-virtual {v14, v1, v2}, Lub2;->S(IZ)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_9

    .line 31
    .line 32
    sget-object v1, Lch6;->c:Li32;

    .line 33
    .line 34
    invoke-virtual {v14}, Lub2;->N()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    sget-object v7, Li21;->a:Ls9;

    .line 39
    .line 40
    if-ne v2, v7, :cond_1

    .line 41
    .line 42
    new-instance v2, Lsx3;

    .line 43
    .line 44
    const/4 v3, 0x6

    .line 45
    invoke-direct {v2, v3}, Lsx3;-><init>(B)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v14, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    check-cast v2, Lqa2;

    .line 52
    .line 53
    invoke-static {v1, v4, v2}, Lv86;->a(Li14;ZLqa2;)Li14;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    sget-object v2, Lt6;->k:Lr20;

    .line 58
    .line 59
    invoke-static {v2, v4}, Lnb0;->c(Lr20;Z)Lis3;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    iget-wide v5, v14, Lub2;->T:J

    .line 64
    .line 65
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 66
    .line 67
    .line 68
    move-result v3

    .line 69
    invoke-virtual {v14}, Lub2;->m()Lh05;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    invoke-static {v14, v1}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    sget-object v6, La21;->d:Lt6;

    .line 78
    .line 79
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v14}, Lub2;->e0()V

    .line 83
    .line 84
    .line 85
    iget-boolean v6, v14, Lub2;->S:Z

    .line 86
    .line 87
    if-eqz v6, :cond_2

    .line 88
    .line 89
    sget-object v6, Lja3;->a0:Lxg2;

    .line 90
    .line 91
    invoke-virtual {v14, v6}, Lub2;->l(Lfa2;)V

    .line 92
    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_2
    invoke-virtual {v14}, Lub2;->n0()V

    .line 96
    .line 97
    .line 98
    :goto_1
    sget-object v6, Lt6;->S:Lf11;

    .line 99
    .line 100
    invoke-static {v6, v14, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    sget-object v2, Lt6;->R:Lf11;

    .line 104
    .line 105
    invoke-static {v2, v14, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    sget-object v3, Lt6;->T:Lf11;

    .line 113
    .line 114
    invoke-static {v3, v14, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    invoke-static {v14}, Les6;->l(Lub2;)V

    .line 118
    .line 119
    .line 120
    sget-object v2, Lt6;->Q:Lf11;

    .line 121
    .line 122
    invoke-static {v2, v14, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    iget-object v10, v0, La14;->i:Lud6;

    .line 126
    .line 127
    invoke-virtual {v14, v10}, Lub2;->g(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    invoke-virtual {v14}, Lub2;->N()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    if-nez v1, :cond_3

    .line 136
    .line 137
    if-ne v2, v7, :cond_4

    .line 138
    .line 139
    :cond_3
    new-instance v2, Lwd6;

    .line 140
    .line 141
    invoke-direct {v2, v10}, Lwd6;-><init>(Lud6;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v14, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    :cond_4
    move-object v11, v2

    .line 148
    check-cast v11, Lwd6;

    .line 149
    .line 150
    invoke-virtual {v14}, Lub2;->N()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v1

    .line 154
    if-ne v1, v7, :cond_5

    .line 155
    .line 156
    new-instance v1, Lc14;

    .line 157
    .line 158
    invoke-direct {v1, v10, v4}, Lc14;-><init>(Lud6;B)V

    .line 159
    .line 160
    .line 161
    invoke-static {v1}, Lmj6;->b(Lfa2;)Ldm1;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    invoke-virtual {v14, v1}, Lub2;->k0(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    :cond_5
    check-cast v1, Lmm6;

    .line 169
    .line 170
    invoke-interface {v1}, Lmm6;->getValue()Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    check-cast v1, Ljava/lang/Boolean;

    .line 175
    .line 176
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 177
    .line 178
    .line 179
    move-result v1

    .line 180
    if-eqz v1, :cond_6

    .line 181
    .line 182
    const/high16 v1, 0x3f800000    # 1.0f

    .line 183
    .line 184
    goto :goto_2

    .line 185
    :cond_6
    const/4 v1, 0x0

    .line 186
    :goto_2
    const/4 v2, 0x3

    .line 187
    invoke-static {v2, v14}, Lvc3;->N(ILub2;)Lp32;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    const/16 v5, 0xc00

    .line 192
    .line 193
    const/16 v6, 0x14

    .line 194
    .line 195
    const-string v3, "ScrimAlphaAnimation"

    .line 196
    .line 197
    move-object v4, v14

    .line 198
    invoke-static/range {v1 .. v6}, Lpg;->b(FLp32;Ljava/lang/String;Lub2;II)Lmm6;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    const v2, 0x7f0f0098

    .line 203
    .line 204
    .line 205
    invoke-static {v2, v14}, Lq56;->C(ILub2;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    iget-object v3, v0, La14;->j:Ld14;

    .line 210
    .line 211
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v14, v1}, Lub2;->g(Ljava/lang/Object;)Z

    .line 215
    .line 216
    .line 217
    move-result v3

    .line 218
    invoke-virtual {v14}, Lub2;->N()Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v4

    .line 222
    if-nez v3, :cond_7

    .line 223
    .line 224
    if-ne v4, v7, :cond_8

    .line 225
    .line 226
    :cond_7
    new-instance v4, Lg1;

    .line 227
    .line 228
    const/16 v3, 0xc

    .line 229
    .line 230
    invoke-direct {v4, v1, v3}, Lg1;-><init>(Lmm6;B)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v14, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    :cond_8
    check-cast v4, Lfa2;

    .line 237
    .line 238
    const/4 v8, 0x0

    .line 239
    move-object v1, v2

    .line 240
    const/4 v2, 0x0

    .line 241
    iget-object v3, v0, La14;->k:Lfa2;

    .line 242
    .line 243
    iget-wide v5, v0, La14;->l:J

    .line 244
    .line 245
    move-object v7, v14

    .line 246
    invoke-static/range {v1 .. v8}, Lip3;->L(Ljava/lang/String;Li14;Lfa2;Lfa2;JLub2;I)V

    .line 247
    .line 248
    .line 249
    sget-object v1, Lt6;->l:Lr20;

    .line 250
    .line 251
    sget-object v2, Lwc0;->a:Lwc0;

    .line 252
    .line 253
    iget-object v3, v0, La14;->m:Li14;

    .line 254
    .line 255
    invoke-virtual {v2, v3, v1}, Lwc0;->a(Li14;Lg8;)Li14;

    .line 256
    .line 257
    .line 258
    move-result-object v1

    .line 259
    invoke-static {v1, v11}, Lu23;->o(Li14;Lkm7;)Li14;

    .line 260
    .line 261
    .line 262
    move-result-object v1

    .line 263
    const/4 v15, 0x0

    .line 264
    iget-object v2, v0, La14;->n:Lfa2;

    .line 265
    .line 266
    iget v3, v0, La14;->o:F

    .line 267
    .line 268
    iget-boolean v4, v0, La14;->p:Z

    .line 269
    .line 270
    iget-object v5, v0, La14;->q:Lc01;

    .line 271
    .line 272
    iget-object v6, v0, La14;->r:Lw33;

    .line 273
    .line 274
    iget-object v7, v0, La14;->s:Lub6;

    .line 275
    .line 276
    iget-wide v8, v0, La14;->t:J

    .line 277
    .line 278
    move-object v12, v1

    .line 279
    move-object v1, v10

    .line 280
    iget-wide v10, v0, La14;->u:J

    .line 281
    .line 282
    move-object/from16 v16, v12

    .line 283
    .line 284
    const/4 v12, 0x0

    .line 285
    iget-object v0, v0, La14;->v:Lc01;

    .line 286
    .line 287
    move-object v13, v0

    .line 288
    move-object/from16 v0, v16

    .line 289
    .line 290
    invoke-static/range {v0 .. v15}, Lom;->b(Li14;Lud6;Lfa2;FZLc01;Lua2;Lub6;JJFLc01;Lub2;I)V

    .line 291
    .line 292
    .line 293
    const/4 v13, 0x1

    .line 294
    invoke-virtual {v14, v13}, Lub2;->r(Z)V

    .line 295
    .line 296
    .line 297
    goto :goto_3

    .line 298
    :cond_9
    invoke-virtual {v14}, Lub2;->V()V

    .line 299
    .line 300
    .line 301
    :goto_3
    sget-object v0, Lne7;->a:Lne7;

    .line 302
    .line 303
    return-object v0
.end method
