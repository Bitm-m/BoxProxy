.class public final synthetic Lb80;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Lia4;

.field public final synthetic j:Li93;

.field public final synthetic k:Li93;

.field public final synthetic l:Lhv;

.field public final synthetic m:Lmv;

.field public final synthetic n:Lnd7;

.field public final synthetic o:J

.field public final synthetic p:Z

.field public final synthetic q:Ljava/util/List;

.field public final synthetic r:Lhp3;

.field public final synthetic s:Lta0;

.field public final synthetic t:Lsa0;


# direct methods
.method public synthetic constructor <init>(Lia4;Li93;Li93;Lhv;Lmv;Lnd7;JZLjava/util/List;Lhp3;Lta0;Lsa0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb80;->i:Lia4;

    .line 5
    .line 6
    iput-object p2, p0, Lb80;->j:Li93;

    .line 7
    .line 8
    iput-object p3, p0, Lb80;->k:Li93;

    .line 9
    .line 10
    iput-object p4, p0, Lb80;->l:Lhv;

    .line 11
    .line 12
    iput-object p5, p0, Lb80;->m:Lmv;

    .line 13
    .line 14
    iput-object p6, p0, Lb80;->n:Lnd7;

    .line 15
    .line 16
    iput-wide p7, p0, Lb80;->o:J

    .line 17
    .line 18
    iput-boolean p9, p0, Lb80;->p:Z

    .line 19
    .line 20
    iput-object p10, p0, Lb80;->q:Ljava/util/List;

    .line 21
    .line 22
    iput-object p11, p0, Lb80;->r:Lhp3;

    .line 23
    .line 24
    iput-object p12, p0, Lb80;->s:Lta0;

    .line 25
    .line 26
    iput-object p13, p0, Lb80;->t:Lsa0;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v15, p1

    .line 4
    .line 5
    check-cast v15, Lub2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    and-int/lit8 v2, v1, 0x3

    .line 16
    .line 17
    const/4 v3, 0x2

    .line 18
    const/4 v4, 0x1

    .line 19
    if-eq v2, v3, :cond_0

    .line 20
    .line 21
    move v2, v4

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v2, 0x0

    .line 24
    :goto_0
    and-int/2addr v1, v4

    .line 25
    invoke-virtual {v15, v1, v2}, Lub2;->S(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    sget-object v2, Lne7;->a:Lne7;

    .line 30
    .line 31
    if-eqz v1, :cond_5

    .line 32
    .line 33
    invoke-virtual {v15}, Lub2;->N()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    sget-object v3, Li21;->a:Ls9;

    .line 38
    .line 39
    if-ne v1, v3, :cond_1

    .line 40
    .line 41
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 42
    .line 43
    invoke-static {v1}, Lhb3;->Q(Ljava/lang/Object;)Ldy4;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v15, v1}, Lub2;->k0(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    :cond_1
    check-cast v1, Lw44;

    .line 51
    .line 52
    invoke-virtual {v15}, Lub2;->N()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    const/4 v6, 0x0

    .line 57
    if-ne v5, v3, :cond_2

    .line 58
    .line 59
    new-instance v5, Lgn;

    .line 60
    .line 61
    invoke-direct {v5, v1, v6, v4}, Lgn;-><init>(Lw44;Lia1;B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v15, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    check-cast v5, Lua2;

    .line 68
    .line 69
    invoke-static {v5, v15, v2}, Lac7;->i(Lua2;Lub2;Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {v1}, Lmm6;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Ljava/lang/Boolean;

    .line 77
    .line 78
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    iget-object v12, v0, Lb80;->i:Lia4;

    .line 83
    .line 84
    iget-object v3, v12, Lia4;->a:Lpj6;

    .line 85
    .line 86
    invoke-static {v3}, Lmv0;->U0(Ljava/util/List;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    instance-of v5, v3, Ly90;

    .line 91
    .line 92
    if-eqz v5, :cond_3

    .line 93
    .line 94
    move-object v6, v3

    .line 95
    check-cast v6, Ly90;

    .line 96
    .line 97
    :cond_3
    sget-object v3, Lx80;->INSTANCE:Lx80;

    .line 98
    .line 99
    invoke-static {v6, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v3

    .line 103
    sget-object v5, Lf14;->i:Lf14;

    .line 104
    .line 105
    iget-object v6, v0, Lb80;->j:Li93;

    .line 106
    .line 107
    invoke-static {v5, v6, v4}, Ldx3;->b(Li14;Li93;Z)Li14;

    .line 108
    .line 109
    .line 110
    move-result-object v4

    .line 111
    iget-object v7, v0, Lb80;->k:Li93;

    .line 112
    .line 113
    if-eqz v7, :cond_4

    .line 114
    .line 115
    invoke-static {v5, v7}, Lmf0;->L(Li14;Li93;)Li14;

    .line 116
    .line 117
    .line 118
    move-result-object v5

    .line 119
    :cond_4
    invoke-interface {v4, v5}, Li14;->a0(Li14;)Li14;

    .line 120
    .line 121
    .line 122
    move-result-object v13

    .line 123
    new-instance v4, Lp0;

    .line 124
    .line 125
    const/4 v5, 0x7

    .line 126
    iget-object v8, v0, Lb80;->q:Ljava/util/List;

    .line 127
    .line 128
    invoke-direct {v4, v8, v6, v7, v5}, Lp0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 129
    .line 130
    .line 131
    const v5, 0x4d2b1010    # 1.79372288E8f

    .line 132
    .line 133
    .line 134
    invoke-static {v5, v4, v15}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 135
    .line 136
    .line 137
    move-result-object v14

    .line 138
    sget-object v4, Lmv;->g:Ls9;

    .line 139
    .line 140
    const v16, 0x8001000

    .line 141
    .line 142
    .line 143
    move-object v4, v2

    .line 144
    iget-object v2, v0, Lb80;->l:Lhv;

    .line 145
    .line 146
    move v5, v1

    .line 147
    move v1, v3

    .line 148
    iget-object v3, v0, Lb80;->m:Lmv;

    .line 149
    .line 150
    move-object v6, v4

    .line 151
    iget-object v4, v0, Lb80;->n:Lnd7;

    .line 152
    .line 153
    move v7, v5

    .line 154
    move-object v9, v6

    .line 155
    iget-wide v5, v0, Lb80;->o:J

    .line 156
    .line 157
    move v10, v7

    .line 158
    iget-boolean v7, v0, Lb80;->p:Z

    .line 159
    .line 160
    move-object v11, v9

    .line 161
    iget-object v9, v0, Lb80;->r:Lhp3;

    .line 162
    .line 163
    move/from16 v17, v10

    .line 164
    .line 165
    iget-object v10, v0, Lb80;->s:Lta0;

    .line 166
    .line 167
    iget-object v0, v0, Lb80;->t:Lsa0;

    .line 168
    .line 169
    move-object/from16 v18, v11

    .line 170
    .line 171
    move-object v11, v0

    .line 172
    move/from16 v0, v17

    .line 173
    .line 174
    move-object/from16 v17, v18

    .line 175
    .line 176
    invoke-static/range {v0 .. v16}, Lnn;->a(ZZLhv;Lmv;Lnd7;JZLjava/util/List;Lhp3;Lta0;Lsa0;Lia4;Li14;Lc01;Lub2;I)V

    .line 177
    .line 178
    .line 179
    return-object v17

    .line 180
    :cond_5
    move-object/from16 v17, v2

    .line 181
    .line 182
    invoke-virtual {v15}, Lub2;->V()V

    .line 183
    .line 184
    .line 185
    return-object v17
.end method
