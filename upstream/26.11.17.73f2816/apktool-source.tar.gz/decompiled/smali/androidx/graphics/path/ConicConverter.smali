.class public final Landroidx/graphics/path/ConicConverter;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# direct methods
.method private final native internalConicToQuadratics([FI[FFF)I
.end method
