.class public interface abstract Landroidx/window/area/reflectionguard/ExtensionWindowAreaStatusRequirements;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# virtual methods
.method public abstract getWindowAreaDisplayMetrics()Landroid/util/DisplayMetrics;
.end method

.method public abstract getWindowAreaStatus()I
.end method
