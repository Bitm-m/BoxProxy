.class public interface abstract Landroidx/compose/ui/input/pointer/PointerInputEventHandler;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# virtual methods
.method public abstract invoke(Ls25;Lia1;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls25;",
            "Lia1;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
