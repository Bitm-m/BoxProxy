.class public final synthetic Laf6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/List;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Lqa2;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Lqa2;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Laf6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Laf6;->j:Ljava/util/List;

    .line 4
    .line 5
    iput-object p2, p0, Laf6;->k:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Laf6;->l:Lqa2;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laf6;->i:B

    .line 4
    .line 5
    sget-object v2, Lne7;->a:Lne7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    iget-object v5, v0, Laf6;->l:Lqa2;

    .line 11
    .line 12
    iget-object v6, v0, Laf6;->k:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v0, v0, Laf6;->j:Ljava/util/List;

    .line 15
    .line 16
    const/4 v7, 0x1

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lzx0;

    .line 23
    .line 24
    move-object/from16 v8, p2

    .line 25
    .line 26
    check-cast v8, Lub2;

    .line 27
    .line 28
    move-object/from16 v9, p3

    .line 29
    .line 30
    check-cast v9, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v9, 0x11

    .line 40
    .line 41
    if-eq v1, v3, :cond_0

    .line 42
    .line 43
    move v1, v7

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v1, v4

    .line 46
    :goto_0
    and-int/2addr v9, v7

    .line 47
    invoke-virtual {v8, v9, v1}, Lub2;->S(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_5

    .line 52
    .line 53
    const/4 v1, 0x0

    .line 54
    invoke-static {v1}, Lnm;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    new-instance v7, Ljava/util/ArrayList;

    .line 59
    .line 60
    const/16 v9, 0xa

    .line 61
    .line 62
    invoke-static {v0, v9}, Lnv0;->w0(Ljava/lang/Iterable;I)I

    .line 63
    .line 64
    .line 65
    move-result v9

    .line 66
    invoke-direct {v7, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 67
    .line 68
    .line 69
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    .line 75
    .line 76
    move-result v9

    .line 77
    if-eqz v9, :cond_1

    .line 78
    .line 79
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v9

    .line 83
    check-cast v9, Lkf6;

    .line 84
    .line 85
    iget-object v9, v9, Lkf6;->a:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_1
    invoke-static {v3, v7}, Lmv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    move v13, v4

    .line 100
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result v4

    .line 104
    if-eqz v4, :cond_6

    .line 105
    .line 106
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    add-int/lit8 v7, v13, 0x1

    .line 111
    .line 112
    if-ltz v13, :cond_4

    .line 113
    .line 114
    check-cast v4, Ljava/lang/String;

    .line 115
    .line 116
    invoke-static {v6, v4}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v9

    .line 120
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 121
    .line 122
    .line 123
    move-result v14

    .line 124
    new-instance v10, Lyc6;

    .line 125
    .line 126
    const/4 v11, 0x7

    .line 127
    invoke-direct {v10, v4, v11}, Lyc6;-><init>(Ljava/lang/String;B)V

    .line 128
    .line 129
    .line 130
    const v11, -0x49ae6673

    .line 131
    .line 132
    .line 133
    invoke-static {v11, v10, v8}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 134
    .line 135
    .line 136
    move-result-object v10

    .line 137
    invoke-virtual {v8, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v11

    .line 141
    invoke-virtual {v8, v4}, Lub2;->g(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v12

    .line 145
    or-int/2addr v11, v12

    .line 146
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v12

    .line 150
    if-nez v11, :cond_2

    .line 151
    .line 152
    sget-object v11, Li21;->a:Ls9;

    .line 153
    .line 154
    if-ne v12, v11, :cond_3

    .line 155
    .line 156
    :cond_2
    new-instance v12, Ls;

    .line 157
    .line 158
    const/4 v11, 0x5

    .line 159
    invoke-direct {v12, v11, v5, v4}, Ls;-><init>(BLqa2;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v8, v12}, Lub2;->k0(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    :cond_3
    check-cast v12, Lfa2;

    .line 166
    .line 167
    const/16 v18, 0x30

    .line 168
    .line 169
    const/16 v19, 0x678

    .line 170
    .line 171
    const/4 v11, 0x0

    .line 172
    move-object/from16 v17, v8

    .line 173
    .line 174
    move v8, v9

    .line 175
    move-object v9, v10

    .line 176
    move-object v10, v12

    .line 177
    const/4 v12, 0x0

    .line 178
    const/4 v15, 0x0

    .line 179
    const/16 v16, 0x0

    .line 180
    .line 181
    invoke-static/range {v8 .. v19}, Lkr3;->e(ZLc01;Lfa2;Li14;ZIILq66;Lxu4;Lub2;II)V

    .line 182
    .line 183
    .line 184
    move v13, v7

    .line 185
    move-object/from16 v8, v17

    .line 186
    .line 187
    goto :goto_2

    .line 188
    :cond_4
    invoke-static {}, Lnm;->q0()V

    .line 189
    .line 190
    .line 191
    throw v1

    .line 192
    :cond_5
    move-object/from16 v17, v8

    .line 193
    .line 194
    invoke-virtual/range {v17 .. v17}, Lub2;->V()V

    .line 195
    .line 196
    .line 197
    :cond_6
    return-object v2

    .line 198
    :pswitch_0
    move-object/from16 v1, p1

    .line 199
    .line 200
    check-cast v1, Lzx0;

    .line 201
    .line 202
    move-object/from16 v15, p2

    .line 203
    .line 204
    check-cast v15, Lub2;

    .line 205
    .line 206
    move-object/from16 v8, p3

    .line 207
    .line 208
    check-cast v8, Ljava/lang/Integer;

    .line 209
    .line 210
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 211
    .line 212
    .line 213
    move-result v8

    .line 214
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 215
    .line 216
    .line 217
    and-int/lit8 v1, v8, 0x11

    .line 218
    .line 219
    if-eq v1, v3, :cond_7

    .line 220
    .line 221
    move v4, v7

    .line 222
    :cond_7
    and-int/2addr v8, v7

    .line 223
    invoke-virtual {v15, v8, v4}, Lub2;->S(IZ)Z

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    if-eqz v1, :cond_8

    .line 228
    .line 229
    new-instance v1, Laf6;

    .line 230
    .line 231
    invoke-direct {v1, v0, v6, v5, v7}, Laf6;-><init>(Ljava/util/List;Ljava/lang/String;Lqa2;B)V

    .line 232
    .line 233
    .line 234
    const v0, 0x5c12dc9

    .line 235
    .line 236
    .line 237
    invoke-static {v0, v1, v15}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 238
    .line 239
    .line 240
    move-result-object v14

    .line 241
    const/high16 v16, 0x30000

    .line 242
    .line 243
    const/16 v17, 0x1f

    .line 244
    .line 245
    const/4 v8, 0x0

    .line 246
    const/4 v9, 0x0

    .line 247
    const/4 v10, 0x0

    .line 248
    const/4 v11, 0x0

    .line 249
    const-wide/16 v12, 0x0

    .line 250
    .line 251
    invoke-static/range {v8 .. v17}, Lkr3;->c(IILi14;Let3;JLc01;Lub2;II)V

    .line 252
    .line 253
    .line 254
    goto :goto_3

    .line 255
    :cond_8
    invoke-virtual {v15}, Lub2;->V()V

    .line 256
    .line 257
    .line 258
    :goto_3
    return-object v2

    .line 259
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
