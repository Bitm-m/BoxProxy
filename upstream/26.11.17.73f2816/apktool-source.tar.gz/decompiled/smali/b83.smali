.class public interface abstract Lb83;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lhl1;


# virtual methods
.method public abstract u(Landroid/view/KeyEvent;)Z
.end method

.method public abstract z0(Landroid/view/KeyEvent;)Z
.end method
