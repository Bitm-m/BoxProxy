.class public final synthetic Lax5;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Z

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;

.field public final synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;

.field public final synthetic t:Ljava/lang/Object;

.field public final synthetic u:Ljava/lang/Object;

.field public final synthetic v:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;ZZLhj7;Lw34;ZLua2;Lua2;Lua2;Lc01;Lc01;Lox6;Lub6;)V
    .locals 1

    .line 35
    const/4 v0, 0x2

    iput-byte v0, p0, Lax5;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lax5;->p:Ljava/lang/Object;

    iput-boolean p2, p0, Lax5;->j:Z

    iput-boolean p3, p0, Lax5;->k:Z

    iput-object p4, p0, Lax5;->o:Ljava/lang/Object;

    iput-object p5, p0, Lax5;->q:Ljava/lang/Object;

    iput-boolean p6, p0, Lax5;->l:Z

    iput-object p7, p0, Lax5;->r:Ljava/lang/Object;

    iput-object p8, p0, Lax5;->m:Ljava/lang/Object;

    iput-object p9, p0, Lax5;->n:Ljava/lang/Object;

    iput-object p10, p0, Lax5;->s:Ljava/lang/Object;

    iput-object p11, p0, Lax5;->t:Ljava/lang/Object;

    iput-object p12, p0, Lax5;->u:Ljava/lang/Object;

    iput-object p13, p0, Lax5;->v:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lnx5;Ljava/lang/String;Lqx5;ZZLw44;ZLjava/lang/String;Lw44;Lw44;Lw44;Lw44;Lw44;)V
    .locals 1

    .line 34
    const/4 v0, 0x0

    iput-byte v0, p0, Lax5;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lax5;->o:Ljava/lang/Object;

    iput-object p2, p0, Lax5;->p:Ljava/lang/Object;

    iput-object p3, p0, Lax5;->r:Ljava/lang/Object;

    iput-boolean p4, p0, Lax5;->j:Z

    iput-boolean p5, p0, Lax5;->k:Z

    iput-object p6, p0, Lax5;->m:Ljava/lang/Object;

    iput-boolean p7, p0, Lax5;->l:Z

    iput-object p8, p0, Lax5;->q:Ljava/lang/Object;

    iput-object p9, p0, Lax5;->n:Ljava/lang/Object;

    iput-object p10, p0, Lax5;->s:Ljava/lang/Object;

    iput-object p11, p0, Lax5;->t:Ljava/lang/Object;

    iput-object p12, p0, Lax5;->u:Ljava/lang/Object;

    iput-object p13, p0, Lax5;->v:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ltp0;ZZZLjava/util/List;Ly07;Lu46;Ly07;Lu46;Ly07;Lu46;Lw44;Lw44;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lax5;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lax5;->o:Ljava/lang/Object;

    .line 8
    .line 9
    iput-boolean p2, p0, Lax5;->j:Z

    .line 10
    .line 11
    iput-boolean p3, p0, Lax5;->k:Z

    .line 12
    .line 13
    iput-boolean p4, p0, Lax5;->l:Z

    .line 14
    .line 15
    iput-object p5, p0, Lax5;->p:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lax5;->q:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p7, p0, Lax5;->r:Ljava/lang/Object;

    .line 20
    .line 21
    iput-object p8, p0, Lax5;->s:Ljava/lang/Object;

    .line 22
    .line 23
    iput-object p9, p0, Lax5;->t:Ljava/lang/Object;

    .line 24
    .line 25
    iput-object p10, p0, Lax5;->u:Ljava/lang/Object;

    .line 26
    .line 27
    iput-object p11, p0, Lax5;->v:Ljava/lang/Object;

    .line 28
    .line 29
    iput-object p12, p0, Lax5;->m:Ljava/lang/Object;

    .line 30
    .line 31
    iput-object p13, p0, Lax5;->n:Ljava/lang/Object;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 64

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lax5;->i:B

    .line 4
    .line 5
    sget-object v2, Li21;->a:Ls9;

    .line 6
    .line 7
    const/16 v4, 0x12

    .line 8
    .line 9
    sget-object v6, Lne7;->a:Lne7;

    .line 10
    .line 11
    iget-object v8, v0, Lax5;->v:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v9, v0, Lax5;->u:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v10, v0, Lax5;->t:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v11, v0, Lax5;->s:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v12, v0, Lax5;->n:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v13, v0, Lax5;->m:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v14, v0, Lax5;->r:Ljava/lang/Object;

    .line 24
    .line 25
    iget-object v15, v0, Lax5;->q:Ljava/lang/Object;

    .line 26
    .line 27
    iget-object v5, v0, Lax5;->o:Ljava/lang/Object;

    .line 28
    .line 29
    iget-object v7, v0, Lax5;->p:Ljava/lang/Object;

    .line 30
    .line 31
    const/16 v20, 0x3

    .line 32
    .line 33
    const/4 v3, 0x1

    .line 34
    packed-switch v1, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    move-object/from16 v22, v7

    .line 38
    .line 39
    check-cast v22, Ljava/lang/String;

    .line 40
    .line 41
    move-object/from16 v26, v5

    .line 42
    .line 43
    check-cast v26, Lhj7;

    .line 44
    .line 45
    move-object/from16 v30, v15

    .line 46
    .line 47
    check-cast v30, Lw34;

    .line 48
    .line 49
    check-cast v14, Lua2;

    .line 50
    .line 51
    check-cast v13, Lua2;

    .line 52
    .line 53
    check-cast v12, Lua2;

    .line 54
    .line 55
    check-cast v11, Lc01;

    .line 56
    .line 57
    check-cast v10, Lc01;

    .line 58
    .line 59
    move-object/from16 v31, v9

    .line 60
    .line 61
    check-cast v31, Lox6;

    .line 62
    .line 63
    move-object/from16 v32, v8

    .line 64
    .line 65
    check-cast v32, Lub6;

    .line 66
    .line 67
    move-object/from16 v1, p1

    .line 68
    .line 69
    check-cast v1, Lua2;

    .line 70
    .line 71
    move-object/from16 v2, p2

    .line 72
    .line 73
    check-cast v2, Lub2;

    .line 74
    .line 75
    move-object/from16 v5, p3

    .line 76
    .line 77
    check-cast v5, Ljava/lang/Integer;

    .line 78
    .line 79
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    and-int/lit8 v7, v5, 0x6

    .line 84
    .line 85
    if-nez v7, :cond_1

    .line 86
    .line 87
    invoke-virtual {v2, v1}, Lub2;->i(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v7

    .line 91
    if-eqz v7, :cond_0

    .line 92
    .line 93
    const/16 v16, 0x4

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_0
    const/16 v16, 0x2

    .line 97
    .line 98
    :goto_0
    or-int v5, v5, v16

    .line 99
    .line 100
    :cond_1
    and-int/lit8 v7, v5, 0x13

    .line 101
    .line 102
    if-ne v7, v4, :cond_2

    .line 103
    .line 104
    const/4 v3, 0x0

    .line 105
    :cond_2
    and-int/lit8 v4, v5, 0x1

    .line 106
    .line 107
    invoke-virtual {v2, v4, v3}, Lub2;->S(IZ)Z

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    if-eqz v3, :cond_3

    .line 112
    .line 113
    sget-object v21, Lyy1;->C:Lyy1;

    .line 114
    .line 115
    new-instance v27, Ll84;

    .line 116
    .line 117
    const/16 v33, 0x2

    .line 118
    .line 119
    iget-boolean v3, v0, Lax5;->j:Z

    .line 120
    .line 121
    iget-boolean v4, v0, Lax5;->l:Z

    .line 122
    .line 123
    move/from16 v28, v3

    .line 124
    .line 125
    move/from16 v29, v4

    .line 126
    .line 127
    invoke-direct/range {v27 .. v33}, Ll84;-><init>(ZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 128
    .line 129
    .line 130
    move-object/from16 v3, v27

    .line 131
    .line 132
    const v4, -0x27281f48

    .line 133
    .line 134
    .line 135
    invoke-static {v4, v3, v2}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 136
    .line 137
    .line 138
    move-result-object v36

    .line 139
    shl-int/lit8 v5, v5, 0x3

    .line 140
    .line 141
    and-int/lit8 v38, v5, 0x70

    .line 142
    .line 143
    iget-boolean v0, v0, Lax5;->k:Z

    .line 144
    .line 145
    const/16 v35, 0x0

    .line 146
    .line 147
    move/from16 v25, v0

    .line 148
    .line 149
    move-object/from16 v23, v1

    .line 150
    .line 151
    move-object/from16 v37, v2

    .line 152
    .line 153
    move-object/from16 v33, v10

    .line 154
    .line 155
    move-object/from16 v32, v11

    .line 156
    .line 157
    move/from16 v24, v28

    .line 158
    .line 159
    move/from16 v28, v29

    .line 160
    .line 161
    move-object/from16 v27, v30

    .line 162
    .line 163
    move-object/from16 v34, v31

    .line 164
    .line 165
    move-object/from16 v31, v12

    .line 166
    .line 167
    move-object/from16 v30, v13

    .line 168
    .line 169
    move-object/from16 v29, v14

    .line 170
    .line 171
    invoke-virtual/range {v21 .. v38}, Lyy1;->d(Ljava/lang/String;Lua2;ZZLhj7;Ls13;ZLua2;Lua2;Lua2;Lc01;Lc01;Lox6;Lxu4;Lc01;Lub2;I)V

    .line 172
    .line 173
    .line 174
    goto :goto_1

    .line 175
    :cond_3
    move-object/from16 v37, v2

    .line 176
    .line 177
    invoke-virtual/range {v37 .. v37}, Lub2;->V()V

    .line 178
    .line 179
    .line 180
    :goto_1
    return-object v6

    .line 181
    :pswitch_0
    check-cast v5, Ltp0;

    .line 182
    .line 183
    check-cast v7, Ljava/util/List;

    .line 184
    .line 185
    check-cast v15, Ly07;

    .line 186
    .line 187
    check-cast v14, Lu46;

    .line 188
    .line 189
    check-cast v11, Ly07;

    .line 190
    .line 191
    move-object/from16 v16, v10

    .line 192
    .line 193
    check-cast v16, Lu46;

    .line 194
    .line 195
    move-object/from16 v17, v9

    .line 196
    .line 197
    check-cast v17, Ly07;

    .line 198
    .line 199
    check-cast v8, Lu46;

    .line 200
    .line 201
    check-cast v13, Lw44;

    .line 202
    .line 203
    check-cast v12, Lw44;

    .line 204
    .line 205
    move-object/from16 v1, p1

    .line 206
    .line 207
    check-cast v1, Lzx0;

    .line 208
    .line 209
    move-object/from16 v4, p2

    .line 210
    .line 211
    check-cast v4, Lub2;

    .line 212
    .line 213
    move-object/from16 v9, p3

    .line 214
    .line 215
    check-cast v9, Ljava/lang/Integer;

    .line 216
    .line 217
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 218
    .line 219
    .line 220
    move-result v9

    .line 221
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 222
    .line 223
    .line 224
    and-int/lit8 v1, v9, 0x11

    .line 225
    .line 226
    const/16 v10, 0x10

    .line 227
    .line 228
    if-eq v1, v10, :cond_4

    .line 229
    .line 230
    move v1, v3

    .line 231
    goto :goto_2

    .line 232
    :cond_4
    const/4 v1, 0x0

    .line 233
    :goto_2
    and-int/2addr v9, v3

    .line 234
    invoke-virtual {v4, v9, v1}, Lub2;->S(IZ)Z

    .line 235
    .line 236
    .line 237
    move-result v1

    .line 238
    if-eqz v1, :cond_6

    .line 239
    .line 240
    invoke-interface {v13}, Lmm6;->getValue()Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v1

    .line 244
    check-cast v1, Ldk;

    .line 245
    .line 246
    invoke-virtual {v4}, Lub2;->N()Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v9

    .line 250
    if-ne v9, v2, :cond_5

    .line 251
    .line 252
    new-instance v9, Lnl;

    .line 253
    .line 254
    invoke-direct {v9, v13, v12, v3}, Lnl;-><init>(Lw44;Lw44;B)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v4, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    :cond_5
    check-cast v9, Le73;

    .line 261
    .line 262
    move-object/from16 v19, v9

    .line 263
    .line 264
    check-cast v19, Lqa2;

    .line 265
    .line 266
    sget v2, Ldk;->l:I

    .line 267
    .line 268
    const/16 v21, 0x0

    .line 269
    .line 270
    iget-boolean v9, v0, Lax5;->j:Z

    .line 271
    .line 272
    iget-boolean v10, v0, Lax5;->k:Z

    .line 273
    .line 274
    move-object v13, v15

    .line 275
    move-object v15, v11

    .line 276
    iget-boolean v11, v0, Lax5;->l:Z

    .line 277
    .line 278
    move-object/from16 v20, v4

    .line 279
    .line 280
    move-object v12, v7

    .line 281
    move-object/from16 v18, v8

    .line 282
    .line 283
    move-object v8, v1

    .line 284
    move-object v7, v5

    .line 285
    invoke-static/range {v7 .. v21}, Lb70;->e(Ltp0;Ldk;ZZZLjava/util/List;Ly07;Lu46;Ly07;Lu46;Ly07;Lu46;Lqa2;Lub2;I)V

    .line 286
    .line 287
    .line 288
    goto :goto_3

    .line 289
    :cond_6
    move-object/from16 v20, v4

    .line 290
    .line 291
    invoke-virtual/range {v20 .. v20}, Lub2;->V()V

    .line 292
    .line 293
    .line 294
    :goto_3
    return-object v6

    .line 295
    :pswitch_1
    check-cast v5, Lnx5;

    .line 296
    .line 297
    move-object/from16 v21, v7

    .line 298
    .line 299
    check-cast v21, Ljava/lang/String;

    .line 300
    .line 301
    move-object v1, v14

    .line 302
    check-cast v1, Lqx5;

    .line 303
    .line 304
    check-cast v13, Lw44;

    .line 305
    .line 306
    check-cast v15, Ljava/lang/String;

    .line 307
    .line 308
    check-cast v12, Lw44;

    .line 309
    .line 310
    move-object/from16 v44, v11

    .line 311
    .line 312
    check-cast v44, Lw44;

    .line 313
    .line 314
    move-object/from16 v45, v10

    .line 315
    .line 316
    check-cast v45, Lw44;

    .line 317
    .line 318
    move-object/from16 v46, v9

    .line 319
    .line 320
    check-cast v46, Lw44;

    .line 321
    .line 322
    move-object/from16 v47, v8

    .line 323
    .line 324
    check-cast v47, Lw44;

    .line 325
    .line 326
    move-object/from16 v7, p1

    .line 327
    .line 328
    check-cast v7, Lvu4;

    .line 329
    .line 330
    move-object/from16 v8, p2

    .line 331
    .line 332
    check-cast v8, Lub2;

    .line 333
    .line 334
    move-object/from16 v9, p3

    .line 335
    .line 336
    check-cast v9, Ljava/lang/Integer;

    .line 337
    .line 338
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 339
    .line 340
    .line 341
    move-result v9

    .line 342
    sget-object v10, Lt6;->w:Lp20;

    .line 343
    .line 344
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 345
    .line 346
    .line 347
    and-int/lit8 v11, v9, 0x6

    .line 348
    .line 349
    if-nez v11, :cond_8

    .line 350
    .line 351
    invoke-virtual {v8, v7}, Lub2;->g(Ljava/lang/Object;)Z

    .line 352
    .line 353
    .line 354
    move-result v11

    .line 355
    if-eqz v11, :cond_7

    .line 356
    .line 357
    const/16 v16, 0x4

    .line 358
    .line 359
    goto :goto_4

    .line 360
    :cond_7
    const/16 v16, 0x2

    .line 361
    .line 362
    :goto_4
    or-int v9, v9, v16

    .line 363
    .line 364
    :cond_8
    and-int/lit8 v11, v9, 0x13

    .line 365
    .line 366
    if-eq v11, v4, :cond_9

    .line 367
    .line 368
    move v4, v3

    .line 369
    goto :goto_5

    .line 370
    :cond_9
    const/4 v4, 0x0

    .line 371
    :goto_5
    and-int/2addr v9, v3

    .line 372
    invoke-virtual {v8, v9, v4}, Lub2;->S(IZ)Z

    .line 373
    .line 374
    .line 375
    move-result v4

    .line 376
    if-eqz v4, :cond_2f

    .line 377
    .line 378
    sget-object v4, Lch6;->c:Li32;

    .line 379
    .line 380
    sget-object v9, Lt6;->k:Lr20;

    .line 381
    .line 382
    const/4 v11, 0x0

    .line 383
    invoke-static {v9, v11}, Lnb0;->c(Lr20;Z)Lis3;

    .line 384
    .line 385
    .line 386
    move-result-object v14

    .line 387
    move-object/from16 v22, v4

    .line 388
    .line 389
    iget-wide v3, v8, Lub2;->T:J

    .line 390
    .line 391
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 392
    .line 393
    .line 394
    move-result v3

    .line 395
    invoke-virtual {v8}, Lub2;->m()Lh05;

    .line 396
    .line 397
    .line 398
    move-result-object v4

    .line 399
    move/from16 p1, v3

    .line 400
    .line 401
    move-object/from16 v11, v22

    .line 402
    .line 403
    invoke-static {v8, v11}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 404
    .line 405
    .line 406
    move-result-object v3

    .line 407
    sget-object v22, La21;->d:Lt6;

    .line 408
    .line 409
    invoke-virtual/range {v22 .. v22}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 410
    .line 411
    .line 412
    invoke-virtual {v8}, Lub2;->e0()V

    .line 413
    .line 414
    .line 415
    move-object/from16 v48, v6

    .line 416
    .line 417
    iget-boolean v6, v8, Lub2;->S:Z

    .line 418
    .line 419
    move/from16 v22, v6

    .line 420
    .line 421
    sget-object v6, Lja3;->a0:Lxg2;

    .line 422
    .line 423
    if-eqz v22, :cond_a

    .line 424
    .line 425
    invoke-virtual {v8, v6}, Lub2;->l(Lfa2;)V

    .line 426
    .line 427
    .line 428
    :goto_6
    move-object/from16 v22, v7

    .line 429
    .line 430
    goto :goto_7

    .line 431
    :cond_a
    invoke-virtual {v8}, Lub2;->n0()V

    .line 432
    .line 433
    .line 434
    goto :goto_6

    .line 435
    :goto_7
    sget-object v7, Lt6;->S:Lf11;

    .line 436
    .line 437
    invoke-static {v7, v8, v14}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 438
    .line 439
    .line 440
    sget-object v14, Lt6;->R:Lf11;

    .line 441
    .line 442
    invoke-static {v14, v8, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 443
    .line 444
    .line 445
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 446
    .line 447
    .line 448
    move-result-object v4

    .line 449
    move-object/from16 v28, v12

    .line 450
    .line 451
    sget-object v12, Lt6;->T:Lf11;

    .line 452
    .line 453
    invoke-static {v12, v8, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 454
    .line 455
    .line 456
    invoke-static {v8}, Les6;->l(Lub2;)V

    .line 457
    .line 458
    .line 459
    sget-object v4, Lt6;->Q:Lf11;

    .line 460
    .line 461
    invoke-static {v4, v8, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v5}, Lnx5;->g()Z

    .line 465
    .line 466
    .line 467
    move-result v3

    .line 468
    move/from16 p1, v3

    .line 469
    .line 470
    const/high16 v23, 0x41400000    # 12.0f

    .line 471
    .line 472
    const/high16 v3, 0x41800000    # 16.0f

    .line 473
    .line 474
    move-object/from16 v29, v13

    .line 475
    .line 476
    sget-object v13, Lf14;->i:Lf14;

    .line 477
    .line 478
    if-eqz p1, :cond_c

    .line 479
    .line 480
    const v0, 0x12106619

    .line 481
    .line 482
    .line 483
    invoke-virtual {v8, v0}, Lub2;->b0(I)V

    .line 484
    .line 485
    .line 486
    invoke-interface/range {v22 .. v22}, Lvu4;->d()F

    .line 487
    .line 488
    .line 489
    move-result v0

    .line 490
    add-float v0, v0, v23

    .line 491
    .line 492
    invoke-interface/range {v22 .. v22}, Lvu4;->c()F

    .line 493
    .line 494
    .line 495
    move-result v1

    .line 496
    add-float v1, v1, v23

    .line 497
    .line 498
    invoke-static {v11, v3, v0, v3, v1}, Lmi1;->F(Li14;FFFF)Li14;

    .line 499
    .line 500
    .line 501
    move-result-object v0

    .line 502
    new-instance v1, Lvv;

    .line 503
    .line 504
    new-instance v2, Lj02;

    .line 505
    .line 506
    move/from16 v3, v20

    .line 507
    .line 508
    invoke-direct {v2, v3}, Lj02;-><init>(B)V

    .line 509
    .line 510
    .line 511
    move/from16 v5, v23

    .line 512
    .line 513
    const/4 v3, 0x1

    .line 514
    invoke-direct {v1, v5, v3, v2}, Lvv;-><init>(FZLj02;)V

    .line 515
    .line 516
    .line 517
    const/4 v2, 0x6

    .line 518
    invoke-static {v1, v10, v8, v2}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 519
    .line 520
    .line 521
    move-result-object v1

    .line 522
    iget-wide v2, v8, Lub2;->T:J

    .line 523
    .line 524
    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    .line 525
    .line 526
    .line 527
    move-result v2

    .line 528
    invoke-virtual {v8}, Lub2;->m()Lh05;

    .line 529
    .line 530
    .line 531
    move-result-object v3

    .line 532
    invoke-static {v8, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 533
    .line 534
    .line 535
    move-result-object v0

    .line 536
    invoke-virtual {v8}, Lub2;->e0()V

    .line 537
    .line 538
    .line 539
    iget-boolean v5, v8, Lub2;->S:Z

    .line 540
    .line 541
    if-eqz v5, :cond_b

    .line 542
    .line 543
    invoke-virtual {v8, v6}, Lub2;->l(Lfa2;)V

    .line 544
    .line 545
    .line 546
    goto :goto_8

    .line 547
    :cond_b
    invoke-virtual {v8}, Lub2;->n0()V

    .line 548
    .line 549
    .line 550
    :goto_8
    invoke-static {v7, v8, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 551
    .line 552
    .line 553
    invoke-static {v14, v8, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 554
    .line 555
    .line 556
    invoke-static {v2, v8, v12, v8}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 557
    .line 558
    .line 559
    invoke-static {v4, v8, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 560
    .line 561
    .line 562
    const/high16 v0, 0x3f800000    # 1.0f

    .line 563
    .line 564
    invoke-static {v13, v0}, Lch6;->d(Li14;F)Li14;

    .line 565
    .line 566
    .line 567
    move-result-object v22

    .line 568
    const/16 v26, 0x30

    .line 569
    .line 570
    const/16 v27, 0x4

    .line 571
    .line 572
    const-wide/16 v23, 0x0

    .line 573
    .line 574
    move-object/from16 v25, v8

    .line 575
    .line 576
    invoke-static/range {v21 .. v27}, Loa3;->q(Ljava/lang/String;Li14;JLub2;II)V

    .line 577
    .line 578
    .line 579
    const/4 v3, 0x1

    .line 580
    invoke-virtual {v8, v3}, Lub2;->r(Z)V

    .line 581
    .line 582
    .line 583
    const/4 v11, 0x0

    .line 584
    invoke-virtual {v8, v11}, Lub2;->r(Z)V

    .line 585
    .line 586
    .line 587
    :goto_9
    const/4 v3, 0x1

    .line 588
    goto/16 :goto_16

    .line 589
    .line 590
    :cond_c
    invoke-virtual {v5}, Lnx5;->c()Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object v21

    .line 594
    if-eqz v21, :cond_f

    .line 595
    .line 596
    const v0, 0x121d2f81

    .line 597
    .line 598
    .line 599
    invoke-virtual {v8, v0}, Lub2;->b0(I)V

    .line 600
    .line 601
    .line 602
    invoke-interface/range {v22 .. v22}, Lvu4;->d()F

    .line 603
    .line 604
    .line 605
    move-result v0

    .line 606
    const/high16 v1, 0x41400000    # 12.0f

    .line 607
    .line 608
    add-float/2addr v0, v1

    .line 609
    invoke-interface/range {v22 .. v22}, Lvu4;->c()F

    .line 610
    .line 611
    .line 612
    move-result v2

    .line 613
    add-float/2addr v2, v1

    .line 614
    invoke-static {v11, v3, v0, v3, v2}, Lmi1;->F(Li14;FFFF)Li14;

    .line 615
    .line 616
    .line 617
    move-result-object v0

    .line 618
    new-instance v2, Lvv;

    .line 619
    .line 620
    new-instance v3, Lj02;

    .line 621
    .line 622
    const/4 v9, 0x3

    .line 623
    invoke-direct {v3, v9}, Lj02;-><init>(B)V

    .line 624
    .line 625
    .line 626
    const/4 v9, 0x1

    .line 627
    invoke-direct {v2, v1, v9, v3}, Lvv;-><init>(FZLj02;)V

    .line 628
    .line 629
    .line 630
    const/4 v1, 0x6

    .line 631
    invoke-static {v2, v10, v8, v1}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 632
    .line 633
    .line 634
    move-result-object v1

    .line 635
    iget-wide v2, v8, Lub2;->T:J

    .line 636
    .line 637
    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    .line 638
    .line 639
    .line 640
    move-result v2

    .line 641
    invoke-virtual {v8}, Lub2;->m()Lh05;

    .line 642
    .line 643
    .line 644
    move-result-object v3

    .line 645
    invoke-static {v8, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 646
    .line 647
    .line 648
    move-result-object v0

    .line 649
    invoke-virtual {v8}, Lub2;->e0()V

    .line 650
    .line 651
    .line 652
    iget-boolean v9, v8, Lub2;->S:Z

    .line 653
    .line 654
    if-eqz v9, :cond_d

    .line 655
    .line 656
    invoke-virtual {v8, v6}, Lub2;->l(Lfa2;)V

    .line 657
    .line 658
    .line 659
    goto :goto_a

    .line 660
    :cond_d
    invoke-virtual {v8}, Lub2;->n0()V

    .line 661
    .line 662
    .line 663
    :goto_a
    invoke-static {v7, v8, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 664
    .line 665
    .line 666
    invoke-static {v14, v8, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 667
    .line 668
    .line 669
    invoke-static {v2, v8, v12, v8}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 670
    .line 671
    .line 672
    invoke-static {v4, v8, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 673
    .line 674
    .line 675
    invoke-virtual {v5}, Lnx5;->c()Ljava/lang/String;

    .line 676
    .line 677
    .line 678
    move-result-object v0

    .line 679
    if-nez v0, :cond_e

    .line 680
    .line 681
    const-string v0, ""

    .line 682
    .line 683
    :cond_e
    move-object/from16 v22, v0

    .line 684
    .line 685
    sget-object v0, Lwr3;->b:Lyt1;

    .line 686
    .line 687
    invoke-virtual {v8, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 688
    .line 689
    .line 690
    move-result-object v0

    .line 691
    check-cast v0, Ltr3;

    .line 692
    .line 693
    iget-object v0, v0, Ltr3;->a:Lyv0;

    .line 694
    .line 695
    iget-wide v0, v0, Lyv0;->w:J

    .line 696
    .line 697
    const/high16 v2, 0x3f800000    # 1.0f

    .line 698
    .line 699
    invoke-static {v13, v2}, Lch6;->d(Li14;F)Li14;

    .line 700
    .line 701
    .line 702
    move-result-object v23

    .line 703
    const/16 v27, 0x30

    .line 704
    .line 705
    const/16 v28, 0x0

    .line 706
    .line 707
    move-wide/from16 v24, v0

    .line 708
    .line 709
    move-object/from16 v26, v8

    .line 710
    .line 711
    invoke-static/range {v22 .. v28}, Loa3;->q(Ljava/lang/String;Li14;JLub2;II)V

    .line 712
    .line 713
    .line 714
    const/4 v3, 0x1

    .line 715
    invoke-virtual {v8, v3}, Lub2;->r(Z)V

    .line 716
    .line 717
    .line 718
    const/4 v11, 0x0

    .line 719
    invoke-virtual {v8, v11}, Lub2;->r(Z)V

    .line 720
    .line 721
    .line 722
    goto/16 :goto_9

    .line 723
    .line 724
    :cond_f
    invoke-virtual {v5}, Lnx5;->e()Lj06;

    .line 725
    .line 726
    .line 727
    move-result-object v21

    .line 728
    if-eqz v21, :cond_11

    .line 729
    .line 730
    const v0, 0x122b5283

    .line 731
    .line 732
    .line 733
    invoke-virtual {v8, v0}, Lub2;->b0(I)V

    .line 734
    .line 735
    .line 736
    invoke-interface/range {v22 .. v22}, Lvu4;->d()F

    .line 737
    .line 738
    .line 739
    move-result v0

    .line 740
    const/high16 v1, 0x41400000    # 12.0f

    .line 741
    .line 742
    add-float/2addr v0, v1

    .line 743
    invoke-interface/range {v22 .. v22}, Lvu4;->c()F

    .line 744
    .line 745
    .line 746
    move-result v2

    .line 747
    add-float/2addr v2, v1

    .line 748
    invoke-static {v11, v3, v0, v3, v2}, Lmi1;->F(Li14;FFFF)Li14;

    .line 749
    .line 750
    .line 751
    move-result-object v0

    .line 752
    new-instance v2, Lvv;

    .line 753
    .line 754
    new-instance v3, Lj02;

    .line 755
    .line 756
    const/4 v9, 0x3

    .line 757
    invoke-direct {v3, v9}, Lj02;-><init>(B)V

    .line 758
    .line 759
    .line 760
    const/4 v9, 0x1

    .line 761
    invoke-direct {v2, v1, v9, v3}, Lvv;-><init>(FZLj02;)V

    .line 762
    .line 763
    .line 764
    const/4 v1, 0x6

    .line 765
    invoke-static {v2, v10, v8, v1}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 766
    .line 767
    .line 768
    move-result-object v1

    .line 769
    iget-wide v2, v8, Lub2;->T:J

    .line 770
    .line 771
    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    .line 772
    .line 773
    .line 774
    move-result v2

    .line 775
    invoke-virtual {v8}, Lub2;->m()Lh05;

    .line 776
    .line 777
    .line 778
    move-result-object v3

    .line 779
    invoke-static {v8, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 780
    .line 781
    .line 782
    move-result-object v0

    .line 783
    invoke-virtual {v8}, Lub2;->e0()V

    .line 784
    .line 785
    .line 786
    iget-boolean v9, v8, Lub2;->S:Z

    .line 787
    .line 788
    if-eqz v9, :cond_10

    .line 789
    .line 790
    invoke-virtual {v8, v6}, Lub2;->l(Lfa2;)V

    .line 791
    .line 792
    .line 793
    goto :goto_b

    .line 794
    :cond_10
    invoke-virtual {v8}, Lub2;->n0()V

    .line 795
    .line 796
    .line 797
    :goto_b
    invoke-static {v7, v8, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 798
    .line 799
    .line 800
    invoke-static {v14, v8, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 801
    .line 802
    .line 803
    invoke-static {v2, v8, v12, v8}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 804
    .line 805
    .line 806
    invoke-static {v4, v8, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 807
    .line 808
    .line 809
    invoke-virtual {v5}, Lnx5;->e()Lj06;

    .line 810
    .line 811
    .line 812
    move-result-object v0

    .line 813
    invoke-static {v0, v8}, Lhb3;->Y(Lj06;Lub2;)Ljava/lang/String;

    .line 814
    .line 815
    .line 816
    move-result-object v22

    .line 817
    const/high16 v0, 0x3f800000    # 1.0f

    .line 818
    .line 819
    invoke-static {v13, v0}, Lch6;->d(Li14;F)Li14;

    .line 820
    .line 821
    .line 822
    move-result-object v23

    .line 823
    const/16 v27, 0x30

    .line 824
    .line 825
    const/16 v28, 0x4

    .line 826
    .line 827
    const-wide/16 v24, 0x0

    .line 828
    .line 829
    move-object/from16 v26, v8

    .line 830
    .line 831
    invoke-static/range {v22 .. v28}, Loa3;->q(Ljava/lang/String;Li14;JLub2;II)V

    .line 832
    .line 833
    .line 834
    move-object/from16 v3, v26

    .line 835
    .line 836
    const/4 v9, 0x1

    .line 837
    invoke-virtual {v3, v9}, Lub2;->r(Z)V

    .line 838
    .line 839
    .line 840
    const/4 v8, 0x0

    .line 841
    invoke-virtual {v3, v8}, Lub2;->r(Z)V

    .line 842
    .line 843
    .line 844
    move-object v8, v3

    .line 845
    goto/16 :goto_9

    .line 846
    .line 847
    :cond_11
    move-object v3, v8

    .line 848
    const v8, 0x123a157c

    .line 849
    .line 850
    .line 851
    invoke-virtual {v3, v8}, Lub2;->b0(I)V

    .line 852
    .line 853
    .line 854
    invoke-interface/range {v22 .. v22}, Lvu4;->d()F

    .line 855
    .line 856
    .line 857
    move-result v24

    .line 858
    const/16 v26, 0x0

    .line 859
    .line 860
    const/16 v27, 0xd

    .line 861
    .line 862
    const/16 v23, 0x0

    .line 863
    .line 864
    const/16 v25, 0x0

    .line 865
    .line 866
    move-object/from16 v22, v11

    .line 867
    .line 868
    invoke-static/range {v22 .. v27}, Lmi1;->G(Li14;FFFFI)Li14;

    .line 869
    .line 870
    .line 871
    move-result-object v8

    .line 872
    move-object/from16 v30, v22

    .line 873
    .line 874
    sget-object v11, Lac7;->d:Ltv;

    .line 875
    .line 876
    move-object/from16 p1, v13

    .line 877
    .line 878
    const/4 v13, 0x0

    .line 879
    invoke-static {v11, v10, v3, v13}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 880
    .line 881
    .line 882
    move-result-object v10

    .line 883
    move-object/from16 v24, v1

    .line 884
    .line 885
    iget-wide v0, v3, Lub2;->T:J

    .line 886
    .line 887
    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    .line 888
    .line 889
    .line 890
    move-result v0

    .line 891
    invoke-virtual {v3}, Lub2;->m()Lh05;

    .line 892
    .line 893
    .line 894
    move-result-object v1

    .line 895
    invoke-static {v3, v8}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 896
    .line 897
    .line 898
    move-result-object v8

    .line 899
    invoke-virtual {v3}, Lub2;->e0()V

    .line 900
    .line 901
    .line 902
    iget-boolean v11, v3, Lub2;->S:Z

    .line 903
    .line 904
    if-eqz v11, :cond_12

    .line 905
    .line 906
    invoke-virtual {v3, v6}, Lub2;->l(Lfa2;)V

    .line 907
    .line 908
    .line 909
    goto :goto_c

    .line 910
    :cond_12
    invoke-virtual {v3}, Lub2;->n0()V

    .line 911
    .line 912
    .line 913
    :goto_c
    invoke-static {v7, v3, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 914
    .line 915
    .line 916
    invoke-static {v14, v3, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 917
    .line 918
    .line 919
    invoke-static {v0, v3, v12, v3}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 920
    .line 921
    .line 922
    const/4 v0, 0x1

    .line 923
    const/high16 v1, 0x3f800000    # 1.0f

    .line 924
    .line 925
    invoke-static {v3, v8, v4, v1, v0}, Lvz1;->h(Lub2;Li14;Lf11;FZ)Lcb3;

    .line 926
    .line 927
    .line 928
    move-result-object v1

    .line 929
    const/4 v11, 0x0

    .line 930
    invoke-static {v9, v11}, Lnb0;->c(Lr20;Z)Lis3;

    .line 931
    .line 932
    .line 933
    move-result-object v0

    .line 934
    iget-wide v10, v3, Lub2;->T:J

    .line 935
    .line 936
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 937
    .line 938
    .line 939
    move-result v8

    .line 940
    invoke-virtual {v3}, Lub2;->m()Lh05;

    .line 941
    .line 942
    .line 943
    move-result-object v10

    .line 944
    invoke-static {v3, v1}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 945
    .line 946
    .line 947
    move-result-object v1

    .line 948
    invoke-virtual {v3}, Lub2;->e0()V

    .line 949
    .line 950
    .line 951
    iget-boolean v11, v3, Lub2;->S:Z

    .line 952
    .line 953
    if-eqz v11, :cond_13

    .line 954
    .line 955
    invoke-virtual {v3, v6}, Lub2;->l(Lfa2;)V

    .line 956
    .line 957
    .line 958
    goto :goto_d

    .line 959
    :cond_13
    invoke-virtual {v3}, Lub2;->n0()V

    .line 960
    .line 961
    .line 962
    :goto_d
    invoke-static {v7, v3, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 963
    .line 964
    .line 965
    invoke-static {v14, v3, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 966
    .line 967
    .line 968
    invoke-static {v8, v3, v12, v3}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 969
    .line 970
    .line 971
    invoke-static {v4, v3, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 972
    .line 973
    .line 974
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 975
    .line 976
    .line 977
    move-result-object v0

    .line 978
    iget-wide v0, v0, Lyv0;->p:J

    .line 979
    .line 980
    invoke-static {v0, v1}, Lrm;->O(J)F

    .line 981
    .line 982
    .line 983
    move-result v4

    .line 984
    const/high16 v6, 0x3f000000    # 0.5f

    .line 985
    .line 986
    cmpg-float v4, v4, v6

    .line 987
    .line 988
    if-gez v4, :cond_14

    .line 989
    .line 990
    const/4 v4, 0x1

    .line 991
    goto :goto_e

    .line 992
    :cond_14
    const/4 v4, 0x0

    .line 993
    :goto_e
    invoke-virtual {v5}, Lnx5;->b()Ljava/lang/String;

    .line 994
    .line 995
    .line 996
    move-result-object v6

    .line 997
    iget-object v7, v5, Lnx5;->q:Ldy4;

    .line 998
    .line 999
    invoke-virtual {v7}, Ldy4;->getValue()Ljava/lang/Object;

    .line 1000
    .line 1001
    .line 1002
    move-result-object v7

    .line 1003
    check-cast v7, Ljava/lang/Number;

    .line 1004
    .line 1005
    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    .line 1006
    .line 1007
    .line 1008
    move-result v21

    .line 1009
    invoke-virtual {v5}, Lnx5;->d()Ljava/lang/String;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v31

    .line 1013
    invoke-interface/range {v28 .. v28}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v7

    .line 1017
    check-cast v7, Ljava/lang/Boolean;

    .line 1018
    .line 1019
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1020
    .line 1021
    .line 1022
    move-result v32

    .line 1023
    invoke-interface/range {v44 .. v44}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1024
    .line 1025
    .line 1026
    move-result-object v7

    .line 1027
    check-cast v7, Ljava/lang/Boolean;

    .line 1028
    .line 1029
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1030
    .line 1031
    .line 1032
    move-result v33

    .line 1033
    move-object/from16 v7, v24

    .line 1034
    .line 1035
    iget-object v8, v7, Lqx5;->u:Lw44;

    .line 1036
    .line 1037
    invoke-interface {v8}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v8

    .line 1041
    move-object/from16 v34, v8

    .line 1042
    .line 1043
    check-cast v34, Ljava/lang/String;

    .line 1044
    .line 1045
    invoke-virtual {v5}, Lnx5;->a()Z

    .line 1046
    .line 1047
    .line 1048
    move-result v8

    .line 1049
    const/16 v16, 0x1

    .line 1050
    .line 1051
    xor-int/lit8 v35, v8, 0x1

    .line 1052
    .line 1053
    invoke-virtual {v3, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1054
    .line 1055
    .line 1056
    move-result v8

    .line 1057
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v10

    .line 1061
    if-nez v8, :cond_15

    .line 1062
    .line 1063
    if-eq v10, v2, :cond_15

    .line 1064
    .line 1065
    move/from16 v50, v4

    .line 1066
    .line 1067
    move-object/from16 v4, p1

    .line 1068
    .line 1069
    move/from16 p1, v50

    .line 1070
    .line 1071
    move-wide/from16 v50, v0

    .line 1072
    .line 1073
    move-object v1, v9

    .line 1074
    move-object/from16 v0, v29

    .line 1075
    .line 1076
    move-object v9, v5

    .line 1077
    move-object v5, v7

    .line 1078
    goto :goto_f

    .line 1079
    :cond_15
    move-object/from16 v24, v7

    .line 1080
    .line 1081
    new-instance v7, Lte5;

    .line 1082
    .line 1083
    const/4 v13, 0x0

    .line 1084
    const/16 v14, 0x12

    .line 1085
    .line 1086
    const/4 v8, 0x1

    .line 1087
    const-class v10, Lnx5;

    .line 1088
    .line 1089
    const-string v11, "updateContent"

    .line 1090
    .line 1091
    const-string v12, "updateContent(Ljava/lang/String;)V"

    .line 1092
    .line 1093
    move/from16 v50, v4

    .line 1094
    .line 1095
    move-object/from16 v4, p1

    .line 1096
    .line 1097
    move/from16 p1, v50

    .line 1098
    .line 1099
    move-wide/from16 v50, v0

    .line 1100
    .line 1101
    move-object v1, v9

    .line 1102
    move-object/from16 v0, v29

    .line 1103
    .line 1104
    move-object v9, v5

    .line 1105
    move-object/from16 v5, v24

    .line 1106
    .line 1107
    invoke-direct/range {v7 .. v14}, Lte5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1108
    .line 1109
    .line 1110
    invoke-virtual {v3, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1111
    .line 1112
    .line 1113
    move-object v10, v7

    .line 1114
    :goto_f
    check-cast v10, Le73;

    .line 1115
    .line 1116
    invoke-virtual {v3, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1117
    .line 1118
    .line 1119
    move-result v7

    .line 1120
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 1121
    .line 1122
    .line 1123
    move-result-object v8

    .line 1124
    if-nez v7, :cond_16

    .line 1125
    .line 1126
    if-ne v8, v2, :cond_17

    .line 1127
    .line 1128
    :cond_16
    new-instance v22, Lr72;

    .line 1129
    .line 1130
    const/16 v28, 0x0

    .line 1131
    .line 1132
    const/16 v29, 0x16

    .line 1133
    .line 1134
    const/16 v23, 0x2

    .line 1135
    .line 1136
    const-class v25, Lqx5;

    .line 1137
    .line 1138
    const-string v26, "updateSearchResult"

    .line 1139
    .line 1140
    const-string v27, "updateSearchResult(II)V"

    .line 1141
    .line 1142
    move-object/from16 v24, v5

    .line 1143
    .line 1144
    invoke-direct/range {v22 .. v29}, Lr72;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1145
    .line 1146
    .line 1147
    move-object/from16 v8, v22

    .line 1148
    .line 1149
    invoke-virtual {v3, v8}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1150
    .line 1151
    .line 1152
    :cond_17
    check-cast v8, Le73;

    .line 1153
    .line 1154
    invoke-virtual {v3, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1155
    .line 1156
    .line 1157
    move-result v7

    .line 1158
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 1159
    .line 1160
    .line 1161
    move-result-object v11

    .line 1162
    if-nez v7, :cond_18

    .line 1163
    .line 1164
    if-ne v11, v2, :cond_19

    .line 1165
    .line 1166
    :cond_18
    new-instance v22, Lr72;

    .line 1167
    .line 1168
    const/16 v28, 0x0

    .line 1169
    .line 1170
    const/16 v29, 0x17

    .line 1171
    .line 1172
    const/16 v23, 0x2

    .line 1173
    .line 1174
    const-class v25, Lqx5;

    .line 1175
    .line 1176
    const-string v26, "updateCursorPosition"

    .line 1177
    .line 1178
    const-string v27, "updateCursorPosition(II)V"

    .line 1179
    .line 1180
    move-object/from16 v24, v5

    .line 1181
    .line 1182
    invoke-direct/range {v22 .. v29}, Lr72;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1183
    .line 1184
    .line 1185
    move-object/from16 v11, v22

    .line 1186
    .line 1187
    invoke-virtual {v3, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1188
    .line 1189
    .line 1190
    :cond_19
    check-cast v11, Le73;

    .line 1191
    .line 1192
    new-instance v29, Lhw5;

    .line 1193
    .line 1194
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1195
    .line 1196
    .line 1197
    move-result-object v7

    .line 1198
    iget-wide v12, v7, Lyv0;->q:J

    .line 1199
    .line 1200
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1201
    .line 1202
    .line 1203
    move-result-object v7

    .line 1204
    move-object/from16 v22, v6

    .line 1205
    .line 1206
    iget-wide v6, v7, Lyv0;->s:J

    .line 1207
    .line 1208
    if-eqz p1, :cond_1a

    .line 1209
    .line 1210
    const v14, 0x3f51eb85    # 0.82f

    .line 1211
    .line 1212
    .line 1213
    goto :goto_10

    .line 1214
    :cond_1a
    const v14, 0x3f3851ec    # 0.72f

    .line 1215
    .line 1216
    .line 1217
    :goto_10
    invoke-static {v6, v7, v14}, Lsv0;->b(JF)J

    .line 1218
    .line 1219
    .line 1220
    move-result-wide v54

    .line 1221
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1222
    .line 1223
    .line 1224
    move-result-object v6

    .line 1225
    iget-wide v6, v6, Lyv0;->B:J

    .line 1226
    .line 1227
    if-eqz p1, :cond_1b

    .line 1228
    .line 1229
    const v23, 0x3f2e147b    # 0.68f

    .line 1230
    .line 1231
    .line 1232
    move/from16 v14, v23

    .line 1233
    .line 1234
    goto :goto_11

    .line 1235
    :cond_1b
    const v14, 0x3f666666    # 0.9f

    .line 1236
    .line 1237
    .line 1238
    :goto_11
    invoke-static {v6, v7, v14}, Lsv0;->b(JF)J

    .line 1239
    .line 1240
    .line 1241
    move-result-wide v56

    .line 1242
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1243
    .line 1244
    .line 1245
    move-result-object v6

    .line 1246
    const/high16 v7, 0x40000000    # 2.0f

    .line 1247
    .line 1248
    invoke-static {v6, v7}, Lzv0;->g(Lyv0;F)J

    .line 1249
    .line 1250
    .line 1251
    move-result-wide v58

    .line 1252
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1253
    .line 1254
    .line 1255
    move-result-object v6

    .line 1256
    iget-wide v6, v6, Lyv0;->a:J

    .line 1257
    .line 1258
    if-eqz p1, :cond_1c

    .line 1259
    .line 1260
    const v14, 0x3f75c28f    # 0.96f

    .line 1261
    .line 1262
    .line 1263
    goto :goto_12

    .line 1264
    :cond_1c
    const v14, 0x3f666666    # 0.9f

    .line 1265
    .line 1266
    .line 1267
    :goto_12
    invoke-static {v6, v7, v14}, Lsv0;->b(JF)J

    .line 1268
    .line 1269
    .line 1270
    move-result-wide v60

    .line 1271
    invoke-static {v3}, Lbb3;->F(Lub2;)Lyv0;

    .line 1272
    .line 1273
    .line 1274
    move-result-object v6

    .line 1275
    iget-wide v6, v6, Lyv0;->a:J

    .line 1276
    .line 1277
    if-eqz p1, :cond_1d

    .line 1278
    .line 1279
    const v14, 0x3ed70a3d    # 0.42f

    .line 1280
    .line 1281
    .line 1282
    goto :goto_13

    .line 1283
    :cond_1d
    const v14, 0x3e8f5c29    # 0.28f

    .line 1284
    .line 1285
    .line 1286
    :goto_13
    invoke-static {v6, v7, v14}, Lsv0;->b(JF)J

    .line 1287
    .line 1288
    .line 1289
    move-result-wide v62

    .line 1290
    move-wide/from16 v52, v12

    .line 1291
    .line 1292
    move-object/from16 v49, v29

    .line 1293
    .line 1294
    invoke-direct/range {v49 .. v63}, Lhw5;-><init>(JJJJJJJ)V

    .line 1295
    .line 1296
    .line 1297
    check-cast v10, Lqa2;

    .line 1298
    .line 1299
    check-cast v8, Lua2;

    .line 1300
    .line 1301
    check-cast v11, Lua2;

    .line 1302
    .line 1303
    invoke-virtual {v3, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1304
    .line 1305
    .line 1306
    move-result v6

    .line 1307
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 1308
    .line 1309
    .line 1310
    move-result-object v7

    .line 1311
    if-nez v6, :cond_1e

    .line 1312
    .line 1313
    if-ne v7, v2, :cond_1f

    .line 1314
    .line 1315
    :cond_1e
    new-instance v7, Lk95;

    .line 1316
    .line 1317
    const/16 v6, 0xf

    .line 1318
    .line 1319
    invoke-direct {v7, v0, v6}, Lk95;-><init>(Lw44;B)V

    .line 1320
    .line 1321
    .line 1322
    invoke-virtual {v3, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1323
    .line 1324
    .line 1325
    :cond_1f
    check-cast v7, Lqa2;

    .line 1326
    .line 1327
    const/high16 v37, 0x6000000

    .line 1328
    .line 1329
    move-object/from16 v6, p0

    .line 1330
    .line 1331
    iget-boolean v12, v6, Lax5;->l:Z

    .line 1332
    .line 1333
    move-object/from16 v36, v3

    .line 1334
    .line 1335
    move/from16 v25, v12

    .line 1336
    .line 1337
    move/from16 v23, v21

    .line 1338
    .line 1339
    move-object/from16 v24, v31

    .line 1340
    .line 1341
    move/from16 v26, v32

    .line 1342
    .line 1343
    move/from16 v27, v33

    .line 1344
    .line 1345
    move-object/from16 v28, v34

    .line 1346
    .line 1347
    move/from16 v31, v35

    .line 1348
    .line 1349
    move-object/from16 v35, v7

    .line 1350
    .line 1351
    move-object/from16 v33, v8

    .line 1352
    .line 1353
    move-object/from16 v32, v10

    .line 1354
    .line 1355
    move-object/from16 v34, v11

    .line 1356
    .line 1357
    invoke-static/range {v22 .. v37}, Lyx5;->a(Ljava/lang/String;ILjava/lang/String;ZZZLjava/lang/String;Lhw5;Li14;ZLqa2;Lua2;Lua2;Lqa2;Lub2;I)V

    .line 1358
    .line 1359
    .line 1360
    move-object/from16 v8, v36

    .line 1361
    .line 1362
    invoke-virtual {v9}, Lnx5;->h()Z

    .line 1363
    .line 1364
    .line 1365
    move-result v3

    .line 1366
    if-eqz v3, :cond_20

    .line 1367
    .line 1368
    const v3, 0x55c52223

    .line 1369
    .line 1370
    .line 1371
    invoke-virtual {v8, v3}, Lub2;->b0(I)V

    .line 1372
    .line 1373
    .line 1374
    sget-object v3, Lwc0;->a:Lwc0;

    .line 1375
    .line 1376
    invoke-virtual {v3, v4, v1}, Lwc0;->a(Li14;Lg8;)Li14;

    .line 1377
    .line 1378
    .line 1379
    move-result-object v21

    .line 1380
    const/16 v25, 0x0

    .line 1381
    .line 1382
    const/16 v26, 0xc

    .line 1383
    .line 1384
    const/high16 v22, 0x41800000    # 16.0f

    .line 1385
    .line 1386
    const/high16 v23, 0x41000000    # 8.0f

    .line 1387
    .line 1388
    const/16 v24, 0x0

    .line 1389
    .line 1390
    invoke-static/range {v21 .. v26}, Lmi1;->G(Li14;FFFFI)Li14;

    .line 1391
    .line 1392
    .line 1393
    move-result-object v23

    .line 1394
    invoke-static {v8}, Lbb3;->J(Lub2;)Lic7;

    .line 1395
    .line 1396
    .line 1397
    move-result-object v1

    .line 1398
    iget-object v1, v1, Lic7;->l:Lk37;

    .line 1399
    .line 1400
    invoke-static {v8}, Lbb3;->F(Lub2;)Lyv0;

    .line 1401
    .line 1402
    .line 1403
    move-result-object v3

    .line 1404
    iget-wide v3, v3, Lyv0;->a:J

    .line 1405
    .line 1406
    const/16 v42, 0x0

    .line 1407
    .line 1408
    const v43, 0x1fff8

    .line 1409
    .line 1410
    .line 1411
    const-wide/16 v26, 0x0

    .line 1412
    .line 1413
    const/16 v28, 0x0

    .line 1414
    .line 1415
    const/16 v29, 0x0

    .line 1416
    .line 1417
    const-wide/16 v30, 0x0

    .line 1418
    .line 1419
    const/16 v32, 0x0

    .line 1420
    .line 1421
    const-wide/16 v33, 0x0

    .line 1422
    .line 1423
    const/16 v35, 0x0

    .line 1424
    .line 1425
    const/16 v36, 0x0

    .line 1426
    .line 1427
    const/16 v37, 0x0

    .line 1428
    .line 1429
    const/16 v38, 0x0

    .line 1430
    .line 1431
    const/16 v41, 0x0

    .line 1432
    .line 1433
    move-object/from16 v39, v1

    .line 1434
    .line 1435
    move-wide/from16 v24, v3

    .line 1436
    .line 1437
    move-object/from16 v40, v8

    .line 1438
    .line 1439
    move-object/from16 v22, v15

    .line 1440
    .line 1441
    invoke-static/range {v22 .. v43}, Lq17;->b(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    .line 1442
    .line 1443
    .line 1444
    const/4 v11, 0x0

    .line 1445
    invoke-virtual {v8, v11}, Lub2;->r(Z)V

    .line 1446
    .line 1447
    .line 1448
    :goto_14
    const/4 v3, 0x1

    .line 1449
    goto :goto_15

    .line 1450
    :cond_20
    const/4 v11, 0x0

    .line 1451
    const v1, 0x55cc462b

    .line 1452
    .line 1453
    .line 1454
    invoke-virtual {v8, v1}, Lub2;->b0(I)V

    .line 1455
    .line 1456
    .line 1457
    invoke-virtual {v8, v11}, Lub2;->r(Z)V

    .line 1458
    .line 1459
    .line 1460
    goto :goto_14

    .line 1461
    :goto_15
    invoke-virtual {v8, v3}, Lub2;->r(Z)V

    .line 1462
    .line 1463
    .line 1464
    invoke-interface/range {v45 .. v45}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1465
    .line 1466
    .line 1467
    move-result-object v1

    .line 1468
    check-cast v1, Ljava/lang/Number;

    .line 1469
    .line 1470
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 1471
    .line 1472
    .line 1473
    move-result v1

    .line 1474
    invoke-interface/range {v46 .. v46}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1475
    .line 1476
    .line 1477
    move-result-object v3

    .line 1478
    check-cast v3, Ljava/lang/Number;

    .line 1479
    .line 1480
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 1481
    .line 1482
    .line 1483
    move-result v3

    .line 1484
    invoke-interface/range {v44 .. v44}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1485
    .line 1486
    .line 1487
    move-result-object v4

    .line 1488
    check-cast v4, Ljava/lang/Boolean;

    .line 1489
    .line 1490
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1491
    .line 1492
    .line 1493
    move-result v4

    .line 1494
    invoke-interface/range {v47 .. v47}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1495
    .line 1496
    .line 1497
    move-result-object v7

    .line 1498
    check-cast v7, Ljava/util/List;

    .line 1499
    .line 1500
    invoke-virtual {v9}, Lnx5;->a()Z

    .line 1501
    .line 1502
    .line 1503
    move-result v30

    .line 1504
    invoke-virtual {v8, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1505
    .line 1506
    .line 1507
    move-result v9

    .line 1508
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1509
    .line 1510
    .line 1511
    move-result-object v10

    .line 1512
    if-nez v9, :cond_21

    .line 1513
    .line 1514
    if-ne v10, v2, :cond_22

    .line 1515
    .line 1516
    :cond_21
    new-instance v22, Ldx5;

    .line 1517
    .line 1518
    const/16 v28, 0x0

    .line 1519
    .line 1520
    const/16 v29, 0x2

    .line 1521
    .line 1522
    const/16 v23, 0x0

    .line 1523
    .line 1524
    const-class v25, Lqx5;

    .line 1525
    .line 1526
    const-string v26, "showJumpToLine"

    .line 1527
    .line 1528
    const-string v27, "showJumpToLine()V"

    .line 1529
    .line 1530
    move-object/from16 v24, v5

    .line 1531
    .line 1532
    invoke-direct/range {v22 .. v29}, Ldx5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1533
    .line 1534
    .line 1535
    move-object/from16 v10, v22

    .line 1536
    .line 1537
    invoke-virtual {v8, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1538
    .line 1539
    .line 1540
    :cond_22
    check-cast v10, Le73;

    .line 1541
    .line 1542
    invoke-virtual {v8, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1543
    .line 1544
    .line 1545
    move-result v9

    .line 1546
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1547
    .line 1548
    .line 1549
    move-result-object v11

    .line 1550
    if-nez v9, :cond_23

    .line 1551
    .line 1552
    if-ne v11, v2, :cond_24

    .line 1553
    .line 1554
    :cond_23
    new-instance v22, Ldx5;

    .line 1555
    .line 1556
    const/16 v28, 0x0

    .line 1557
    .line 1558
    const/16 v29, 0x3

    .line 1559
    .line 1560
    const/16 v23, 0x0

    .line 1561
    .line 1562
    const-class v25, Lqx5;

    .line 1563
    .line 1564
    const-string v26, "toggleStickyScroll"

    .line 1565
    .line 1566
    const-string v27, "toggleStickyScroll()V"

    .line 1567
    .line 1568
    move-object/from16 v24, v5

    .line 1569
    .line 1570
    invoke-direct/range {v22 .. v29}, Ldx5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1571
    .line 1572
    .line 1573
    move-object/from16 v11, v22

    .line 1574
    .line 1575
    invoke-virtual {v8, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1576
    .line 1577
    .line 1578
    :cond_24
    check-cast v11, Le73;

    .line 1579
    .line 1580
    invoke-virtual {v8, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1581
    .line 1582
    .line 1583
    move-result v5

    .line 1584
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v9

    .line 1588
    if-nez v5, :cond_25

    .line 1589
    .line 1590
    if-ne v9, v2, :cond_26

    .line 1591
    .line 1592
    :cond_25
    new-instance v9, Lqw5;

    .line 1593
    .line 1594
    const/4 v13, 0x0

    .line 1595
    invoke-direct {v9, v0, v13}, Lqw5;-><init>(Lw44;B)V

    .line 1596
    .line 1597
    .line 1598
    invoke-virtual {v8, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1599
    .line 1600
    .line 1601
    :cond_26
    move-object/from16 v26, v9

    .line 1602
    .line 1603
    check-cast v26, Lfa2;

    .line 1604
    .line 1605
    invoke-virtual {v8, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1606
    .line 1607
    .line 1608
    move-result v5

    .line 1609
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1610
    .line 1611
    .line 1612
    move-result-object v9

    .line 1613
    if-nez v5, :cond_27

    .line 1614
    .line 1615
    if-ne v9, v2, :cond_28

    .line 1616
    .line 1617
    :cond_27
    new-instance v9, Lqw5;

    .line 1618
    .line 1619
    const/4 v5, 0x1

    .line 1620
    invoke-direct {v9, v0, v5}, Lqw5;-><init>(Lw44;B)V

    .line 1621
    .line 1622
    .line 1623
    invoke-virtual {v8, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1624
    .line 1625
    .line 1626
    :cond_28
    move-object/from16 v27, v9

    .line 1627
    .line 1628
    check-cast v27, Lfa2;

    .line 1629
    .line 1630
    move-object/from16 v31, v10

    .line 1631
    .line 1632
    check-cast v31, Lfa2;

    .line 1633
    .line 1634
    move-object/from16 v32, v11

    .line 1635
    .line 1636
    check-cast v32, Lfa2;

    .line 1637
    .line 1638
    invoke-virtual {v8, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1639
    .line 1640
    .line 1641
    move-result v5

    .line 1642
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1643
    .line 1644
    .line 1645
    move-result-object v9

    .line 1646
    if-nez v5, :cond_29

    .line 1647
    .line 1648
    if-ne v9, v2, :cond_2a

    .line 1649
    .line 1650
    :cond_29
    new-instance v9, Lk95;

    .line 1651
    .line 1652
    const/16 v10, 0x10

    .line 1653
    .line 1654
    invoke-direct {v9, v0, v10}, Lk95;-><init>(Lw44;B)V

    .line 1655
    .line 1656
    .line 1657
    invoke-virtual {v8, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1658
    .line 1659
    .line 1660
    :cond_2a
    move-object/from16 v33, v9

    .line 1661
    .line 1662
    check-cast v33, Lqa2;

    .line 1663
    .line 1664
    invoke-virtual {v8, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1665
    .line 1666
    .line 1667
    move-result v5

    .line 1668
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1669
    .line 1670
    .line 1671
    move-result-object v9

    .line 1672
    if-nez v5, :cond_2b

    .line 1673
    .line 1674
    if-ne v9, v2, :cond_2c

    .line 1675
    .line 1676
    :cond_2b
    new-instance v9, Lqw5;

    .line 1677
    .line 1678
    const/4 v5, 0x2

    .line 1679
    invoke-direct {v9, v0, v5}, Lqw5;-><init>(Lw44;B)V

    .line 1680
    .line 1681
    .line 1682
    invoke-virtual {v8, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1683
    .line 1684
    .line 1685
    :cond_2c
    move-object/from16 v34, v9

    .line 1686
    .line 1687
    check-cast v34, Lfa2;

    .line 1688
    .line 1689
    invoke-virtual {v8, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1690
    .line 1691
    .line 1692
    move-result v5

    .line 1693
    invoke-virtual {v8}, Lub2;->N()Ljava/lang/Object;

    .line 1694
    .line 1695
    .line 1696
    move-result-object v9

    .line 1697
    if-nez v5, :cond_2d

    .line 1698
    .line 1699
    if-ne v9, v2, :cond_2e

    .line 1700
    .line 1701
    :cond_2d
    new-instance v9, Lqw5;

    .line 1702
    .line 1703
    const/4 v2, 0x3

    .line 1704
    invoke-direct {v9, v0, v2}, Lqw5;-><init>(Lw44;B)V

    .line 1705
    .line 1706
    .line 1707
    invoke-virtual {v8, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1708
    .line 1709
    .line 1710
    :cond_2e
    move-object/from16 v35, v9

    .line 1711
    .line 1712
    check-cast v35, Lfa2;

    .line 1713
    .line 1714
    const/16 v37, 0x0

    .line 1715
    .line 1716
    iget-boolean v0, v6, Lax5;->j:Z

    .line 1717
    .line 1718
    iget-boolean v2, v6, Lax5;->k:Z

    .line 1719
    .line 1720
    move/from16 v24, v0

    .line 1721
    .line 1722
    move/from16 v22, v1

    .line 1723
    .line 1724
    move/from16 v25, v2

    .line 1725
    .line 1726
    move/from16 v23, v3

    .line 1727
    .line 1728
    move/from16 v28, v4

    .line 1729
    .line 1730
    move-object/from16 v29, v7

    .line 1731
    .line 1732
    move-object/from16 v36, v8

    .line 1733
    .line 1734
    invoke-static/range {v22 .. v37}, Loa3;->p(IIZZLfa2;Lfa2;ZLjava/util/List;ZLfa2;Lfa2;Lqa2;Lfa2;Lfa2;Lub2;I)V

    .line 1735
    .line 1736
    .line 1737
    const/4 v3, 0x1

    .line 1738
    invoke-virtual {v8, v3}, Lub2;->r(Z)V

    .line 1739
    .line 1740
    .line 1741
    const/4 v11, 0x0

    .line 1742
    invoke-virtual {v8, v11}, Lub2;->r(Z)V

    .line 1743
    .line 1744
    .line 1745
    :goto_16
    invoke-virtual {v8, v3}, Lub2;->r(Z)V

    .line 1746
    .line 1747
    .line 1748
    goto :goto_17

    .line 1749
    :cond_2f
    move-object/from16 v48, v6

    .line 1750
    .line 1751
    invoke-virtual {v8}, Lub2;->V()V

    .line 1752
    .line 1753
    .line 1754
    :goto_17
    return-object v48

    .line 1755
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
