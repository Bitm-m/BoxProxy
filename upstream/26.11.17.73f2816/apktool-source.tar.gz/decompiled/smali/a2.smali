.class public final synthetic La2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p9, p0, La2;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La2;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, La2;->k:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, La2;->l:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p4, p0, La2;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p5, p0, La2;->n:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p6, p0, La2;->o:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p7, p0, La2;->p:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p8, p0, La2;->q:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 47

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La2;->i:B

    .line 4
    .line 5
    sget-object v3, Lja3;->a0:Lxg2;

    .line 6
    .line 7
    const/high16 v5, 0x41400000    # 12.0f

    .line 8
    .line 9
    sget-object v7, Lf14;->i:Lf14;

    .line 10
    .line 11
    const/16 v8, 0x10

    .line 12
    .line 13
    sget-object v9, Lne7;->a:Lne7;

    .line 14
    .line 15
    sget-object v11, Li21;->a:Ls9;

    .line 16
    .line 17
    iget-object v12, v0, La2;->q:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v13, v0, La2;->p:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v14, v0, La2;->o:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v15, v0, La2;->n:Ljava/lang/Object;

    .line 24
    .line 25
    const/16 v16, 0x0

    .line 26
    .line 27
    iget-object v2, v0, La2;->m:Ljava/lang/Object;

    .line 28
    .line 29
    iget-object v10, v0, La2;->l:Ljava/lang/Object;

    .line 30
    .line 31
    iget-object v6, v0, La2;->k:Ljava/lang/Object;

    .line 32
    .line 33
    iget-object v0, v0, La2;->j:Ljava/lang/Object;

    .line 34
    .line 35
    const/4 v4, 0x1

    .line 36
    packed-switch v1, :pswitch_data_0

    .line 37
    .line 38
    .line 39
    move-object/from16 v23, v0

    .line 40
    .line 41
    check-cast v23, Lpj0;

    .line 42
    .line 43
    check-cast v6, Lw44;

    .line 44
    .line 45
    check-cast v10, Lhv;

    .line 46
    .line 47
    check-cast v2, Lc47;

    .line 48
    .line 49
    check-cast v15, Ljava/util/List;

    .line 50
    .line 51
    check-cast v14, Lz37;

    .line 52
    .line 53
    check-cast v13, Lzx4;

    .line 54
    .line 55
    check-cast v12, Lw44;

    .line 56
    .line 57
    move-object/from16 v0, p1

    .line 58
    .line 59
    check-cast v0, Lkc3;

    .line 60
    .line 61
    move-object/from16 v1, p2

    .line 62
    .line 63
    check-cast v1, Lub2;

    .line 64
    .line 65
    move-object/from16 v16, p3

    .line 66
    .line 67
    check-cast v16, Ljava/lang/Integer;

    .line 68
    .line 69
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Integer;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v16

    .line 73
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    and-int/lit8 v0, v16, 0x11

    .line 77
    .line 78
    if-eq v0, v8, :cond_0

    .line 79
    .line 80
    move v0, v4

    .line 81
    goto :goto_0

    .line 82
    :cond_0
    const/4 v0, 0x0

    .line 83
    :goto_0
    and-int/lit8 v8, v16, 0x1

    .line 84
    .line 85
    invoke-virtual {v1, v8, v0}, Lub2;->S(IZ)Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_7

    .line 90
    .line 91
    const/4 v0, 0x0

    .line 92
    invoke-static {v7, v0, v5, v4}, Lmi1;->E(Li14;FFI)Li14;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    new-instance v8, Lvv;

    .line 97
    .line 98
    move-object/from16 p0, v6

    .line 99
    .line 100
    new-instance v6, Lj02;

    .line 101
    .line 102
    move-object/from16 v33, v9

    .line 103
    .line 104
    const/4 v9, 0x3

    .line 105
    invoke-direct {v6, v9}, Lj02;-><init>(B)V

    .line 106
    .line 107
    .line 108
    invoke-direct {v8, v5, v4, v6}, Lvv;-><init>(FZLj02;)V

    .line 109
    .line 110
    .line 111
    sget-object v5, Lt6;->w:Lp20;

    .line 112
    .line 113
    const/4 v6, 0x6

    .line 114
    invoke-static {v8, v5, v1, v6}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 115
    .line 116
    .line 117
    move-result-object v5

    .line 118
    iget-wide v8, v1, Lub2;->T:J

    .line 119
    .line 120
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 121
    .line 122
    .line 123
    move-result v8

    .line 124
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 125
    .line 126
    .line 127
    move-result-object v9

    .line 128
    invoke-static {v1, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    sget-object v16, La21;->d:Lt6;

    .line 133
    .line 134
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    invoke-virtual {v1}, Lub2;->e0()V

    .line 138
    .line 139
    .line 140
    iget-boolean v4, v1, Lub2;->S:Z

    .line 141
    .line 142
    if-eqz v4, :cond_1

    .line 143
    .line 144
    invoke-virtual {v1, v3}, Lub2;->l(Lfa2;)V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_1
    invoke-virtual {v1}, Lub2;->n0()V

    .line 149
    .line 150
    .line 151
    :goto_1
    sget-object v3, Lt6;->S:Lf11;

    .line 152
    .line 153
    invoke-static {v3, v1, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    sget-object v3, Lt6;->R:Lf11;

    .line 157
    .line 158
    invoke-static {v3, v1, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object v3

    .line 165
    sget-object v4, Lt6;->T:Lf11;

    .line 166
    .line 167
    invoke-static {v4, v1, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    invoke-static {v1}, Les6;->l(Lub2;)V

    .line 171
    .line 172
    .line 173
    sget-object v3, Lt6;->Q:Lf11;

    .line 174
    .line 175
    invoke-static {v3, v1, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    const/high16 v0, 0x3f800000    # 1.0f

    .line 179
    .line 180
    invoke-static {v7, v0}, Lch6;->d(Li14;F)Li14;

    .line 181
    .line 182
    .line 183
    move-result-object v20

    .line 184
    new-instance v0, Lq47;

    .line 185
    .line 186
    const/4 v3, 0x5

    .line 187
    invoke-direct {v0, v10, v2, v3}, Lq47;-><init>(Lhv;Lc47;B)V

    .line 188
    .line 189
    .line 190
    const v3, 0x6f1d8fc1

    .line 191
    .line 192
    .line 193
    invoke-static {v3, v0, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 194
    .line 195
    .line 196
    move-result-object v29

    .line 197
    const/16 v31, 0x6

    .line 198
    .line 199
    const/16 v32, 0x3f6

    .line 200
    .line 201
    const/16 v21, 0x0

    .line 202
    .line 203
    const/16 v22, 0x0

    .line 204
    .line 205
    const/16 v24, 0x0

    .line 206
    .line 207
    const/16 v25, 0x0

    .line 208
    .line 209
    const/16 v26, 0x0

    .line 210
    .line 211
    const/16 v27, 0x0

    .line 212
    .line 213
    const/16 v28, 0x0

    .line 214
    .line 215
    move-object/from16 v30, v1

    .line 216
    .line 217
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 218
    .line 219
    .line 220
    move-object/from16 v0, v30

    .line 221
    .line 222
    const/high16 v1, 0x3f800000    # 1.0f

    .line 223
    .line 224
    invoke-static {v7, v1}, Lch6;->d(Li14;F)Li14;

    .line 225
    .line 226
    .line 227
    move-result-object v20

    .line 228
    new-instance v1, Lq47;

    .line 229
    .line 230
    invoke-direct {v1, v10, v2, v6}, Lq47;-><init>(Lhv;Lc47;B)V

    .line 231
    .line 232
    .line 233
    const v3, 0x2602766a

    .line 234
    .line 235
    .line 236
    invoke-static {v3, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 237
    .line 238
    .line 239
    move-result-object v29

    .line 240
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 241
    .line 242
    .line 243
    const/high16 v1, 0x3f800000    # 1.0f

    .line 244
    .line 245
    invoke-static {v7, v1}, Lch6;->d(Li14;F)Li14;

    .line 246
    .line 247
    .line 248
    move-result-object v20

    .line 249
    new-instance v1, Lt47;

    .line 250
    .line 251
    invoke-direct {v1, v10, v2, v15, v14}, Lt47;-><init>(Lhv;Lc47;Ljava/util/List;Lz37;)V

    .line 252
    .line 253
    .line 254
    const v3, 0x6052dec9

    .line 255
    .line 256
    .line 257
    invoke-static {v3, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 258
    .line 259
    .line 260
    move-result-object v29

    .line 261
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 262
    .line 263
    .line 264
    const/high16 v1, 0x3f800000    # 1.0f

    .line 265
    .line 266
    invoke-static {v7, v1}, Lch6;->d(Li14;F)Li14;

    .line 267
    .line 268
    .line 269
    move-result-object v20

    .line 270
    new-instance v1, Lq47;

    .line 271
    .line 272
    const/4 v3, 0x7

    .line 273
    invoke-direct {v1, v10, v2, v3}, Lq47;-><init>(Lhv;Lc47;B)V

    .line 274
    .line 275
    .line 276
    const v3, -0x655cb8d8

    .line 277
    .line 278
    .line 279
    invoke-static {v3, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 280
    .line 281
    .line 282
    move-result-object v29

    .line 283
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 284
    .line 285
    .line 286
    const/high16 v1, 0x3f800000    # 1.0f

    .line 287
    .line 288
    invoke-static {v7, v1}, Lch6;->d(Li14;F)Li14;

    .line 289
    .line 290
    .line 291
    move-result-object v20

    .line 292
    new-instance v1, Lq47;

    .line 293
    .line 294
    const/16 v3, 0x8

    .line 295
    .line 296
    invoke-direct {v1, v10, v2, v3}, Lq47;-><init>(Lhv;Lc47;B)V

    .line 297
    .line 298
    .line 299
    const v3, -0x2b0c5079

    .line 300
    .line 301
    .line 302
    invoke-static {v3, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 303
    .line 304
    .line 305
    move-result-object v29

    .line 306
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 307
    .line 308
    .line 309
    const/high16 v1, 0x3f800000    # 1.0f

    .line 310
    .line 311
    invoke-static {v7, v1}, Lch6;->d(Li14;F)Li14;

    .line 312
    .line 313
    .line 314
    move-result-object v20

    .line 315
    new-instance v24, Lll;

    .line 316
    .line 317
    const/16 v29, 0x17

    .line 318
    .line 319
    move-object/from16 v26, p0

    .line 320
    .line 321
    move-object/from16 v28, v2

    .line 322
    .line 323
    move-object/from16 v27, v12

    .line 324
    .line 325
    move-object/from16 v25, v13

    .line 326
    .line 327
    invoke-direct/range {v24 .. v29}, Lll;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 328
    .line 329
    .line 330
    move-object/from16 v3, v24

    .line 331
    .line 332
    move-object/from16 v1, v26

    .line 333
    .line 334
    const v4, 0xf4417e6

    .line 335
    .line 336
    .line 337
    invoke-static {v4, v3, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 338
    .line 339
    .line 340
    move-result-object v29

    .line 341
    const/16 v24, 0x0

    .line 342
    .line 343
    const/16 v25, 0x0

    .line 344
    .line 345
    const/16 v26, 0x0

    .line 346
    .line 347
    const/16 v27, 0x0

    .line 348
    .line 349
    const/16 v28, 0x0

    .line 350
    .line 351
    invoke-static/range {v20 .. v32}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 352
    .line 353
    .line 354
    invoke-interface {v1}, Lmm6;->getValue()Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    check-cast v3, Ljava/lang/Boolean;

    .line 359
    .line 360
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 361
    .line 362
    .line 363
    move-result v24

    .line 364
    invoke-virtual {v0, v1}, Lub2;->g(Ljava/lang/Object;)Z

    .line 365
    .line 366
    .line 367
    move-result v3

    .line 368
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v4

    .line 372
    if-nez v3, :cond_2

    .line 373
    .line 374
    if-ne v4, v11, :cond_3

    .line 375
    .line 376
    :cond_2
    new-instance v4, Ldp6;

    .line 377
    .line 378
    invoke-direct {v4, v1, v6}, Ldp6;-><init>(Lw44;B)V

    .line 379
    .line 380
    .line 381
    invoke-virtual {v0, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 382
    .line 383
    .line 384
    :cond_3
    move-object/from16 v25, v4

    .line 385
    .line 386
    check-cast v25, Lfa2;

    .line 387
    .line 388
    invoke-virtual {v0, v10}, Lub2;->i(Ljava/lang/Object;)Z

    .line 389
    .line 390
    .line 391
    move-result v1

    .line 392
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object v3

    .line 396
    if-nez v1, :cond_4

    .line 397
    .line 398
    if-ne v3, v11, :cond_5

    .line 399
    .line 400
    :cond_4
    new-instance v3, Lx70;

    .line 401
    .line 402
    const/4 v1, 0x1

    .line 403
    invoke-direct {v3, v10, v1}, Lx70;-><init>(Lhv;B)V

    .line 404
    .line 405
    .line 406
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 407
    .line 408
    .line 409
    :cond_5
    move-object/from16 v26, v3

    .line 410
    .line 411
    check-cast v26, Lfa2;

    .line 412
    .line 413
    invoke-virtual {v0, v2}, Lub2;->i(Ljava/lang/Object;)Z

    .line 414
    .line 415
    .line 416
    move-result v1

    .line 417
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v3

    .line 421
    if-nez v1, :cond_6

    .line 422
    .line 423
    if-eq v3, v11, :cond_6

    .line 424
    .line 425
    const/4 v1, 0x1

    .line 426
    goto :goto_2

    .line 427
    :cond_6
    new-instance v3, Lk47;

    .line 428
    .line 429
    const/4 v1, 0x1

    .line 430
    invoke-direct {v3, v2, v1}, Lk47;-><init>(Lc47;B)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 434
    .line 435
    .line 436
    :goto_2
    move-object/from16 v27, v3

    .line 437
    .line 438
    check-cast v27, Lqa2;

    .line 439
    .line 440
    const/16 v29, 0x0

    .line 441
    .line 442
    move-object/from16 v28, v0

    .line 443
    .line 444
    invoke-static/range {v24 .. v29}, Loa3;->s(ZLfa2;Lfa2;Lqa2;Lub2;I)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v0, v1}, Lub2;->r(Z)V

    .line 448
    .line 449
    .line 450
    goto :goto_3

    .line 451
    :cond_7
    move-object v0, v1

    .line 452
    move-object/from16 v33, v9

    .line 453
    .line 454
    invoke-virtual {v0}, Lub2;->V()V

    .line 455
    .line 456
    .line 457
    :goto_3
    return-object v33

    .line 458
    :pswitch_0
    move-object/from16 v33, v9

    .line 459
    .line 460
    move-object/from16 v19, v0

    .line 461
    .line 462
    check-cast v19, Ljava/util/List;

    .line 463
    .line 464
    check-cast v6, Lw44;

    .line 465
    .line 466
    move-object/from16 v20, v10

    .line 467
    .line 468
    check-cast v20, Lqa2;

    .line 469
    .line 470
    move-object/from16 v22, v2

    .line 471
    .line 472
    check-cast v22, Lw44;

    .line 473
    .line 474
    move-object/from16 v24, v15

    .line 475
    .line 476
    check-cast v24, Lge4;

    .line 477
    .line 478
    move-object/from16 v26, v14

    .line 479
    .line 480
    check-cast v26, Lqa2;

    .line 481
    .line 482
    move-object/from16 v27, v13

    .line 483
    .line 484
    check-cast v27, Lua2;

    .line 485
    .line 486
    check-cast v12, Lqa2;

    .line 487
    .line 488
    move-object/from16 v0, p1

    .line 489
    .line 490
    check-cast v0, Lzx0;

    .line 491
    .line 492
    move-object/from16 v1, p2

    .line 493
    .line 494
    check-cast v1, Lub2;

    .line 495
    .line 496
    move-object/from16 v2, p3

    .line 497
    .line 498
    check-cast v2, Ljava/lang/Integer;

    .line 499
    .line 500
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 501
    .line 502
    .line 503
    move-result v2

    .line 504
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 505
    .line 506
    .line 507
    and-int/lit8 v0, v2, 0x11

    .line 508
    .line 509
    if-eq v0, v8, :cond_8

    .line 510
    .line 511
    const/4 v0, 0x1

    .line 512
    :goto_4
    const/16 v34, 0x1

    .line 513
    .line 514
    goto :goto_5

    .line 515
    :cond_8
    const/4 v0, 0x0

    .line 516
    goto :goto_4

    .line 517
    :goto_5
    and-int/lit8 v2, v2, 0x1

    .line 518
    .line 519
    invoke-virtual {v1, v2, v0}, Lub2;->S(IZ)Z

    .line 520
    .line 521
    .line 522
    move-result v0

    .line 523
    if-eqz v0, :cond_12

    .line 524
    .line 525
    const v0, 0x7f0f02b9

    .line 526
    .line 527
    .line 528
    invoke-static {v0, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 529
    .line 530
    .line 531
    move-result-object v35

    .line 532
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 533
    .line 534
    .line 535
    move-result-object v0

    .line 536
    if-ne v0, v11, :cond_9

    .line 537
    .line 538
    new-instance v0, Lcw3;

    .line 539
    .line 540
    const/16 v2, 0xe

    .line 541
    .line 542
    invoke-direct {v0, v6, v2}, Lcw3;-><init>(Lw44;B)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v1, v0}, Lub2;->k0(Ljava/lang/Object;)V

    .line 546
    .line 547
    .line 548
    :cond_9
    move-object/from16 v36, v0

    .line 549
    .line 550
    check-cast v36, Lfa2;

    .line 551
    .line 552
    const v0, 0x7f0f02b6

    .line 553
    .line 554
    .line 555
    invoke-static {v0, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 556
    .line 557
    .line 558
    move-result-object v39

    .line 559
    new-instance v18, Lzl;

    .line 560
    .line 561
    const/16 v23, 0x13

    .line 562
    .line 563
    move-object/from16 v21, v6

    .line 564
    .line 565
    invoke-direct/range {v18 .. v23}, Lzl;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 566
    .line 567
    .line 568
    move-object/from16 v0, v18

    .line 569
    .line 570
    move-object/from16 v2, v22

    .line 571
    .line 572
    const v4, 0x7a46fa0f

    .line 573
    .line 574
    .line 575
    invoke-static {v4, v0, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 576
    .line 577
    .line 578
    move-result-object v40

    .line 579
    const v42, 0x30030

    .line 580
    .line 581
    .line 582
    const/16 v43, 0xc

    .line 583
    .line 584
    const/16 v37, 0x0

    .line 585
    .line 586
    const/16 v38, 0x0

    .line 587
    .line 588
    move-object/from16 v41, v1

    .line 589
    .line 590
    invoke-static/range {v35 .. v43}, Ltb3;->c(Ljava/lang/String;Lfa2;Li14;ZLjava/lang/String;Lua2;Lub2;II)V

    .line 591
    .line 592
    .line 593
    move-object/from16 v0, v41

    .line 594
    .line 595
    invoke-interface/range {v19 .. v19}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 596
    .line 597
    .line 598
    move-result-object v1

    .line 599
    const/4 v4, 0x0

    .line 600
    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 601
    .line 602
    .line 603
    move-result v5

    .line 604
    if-eqz v5, :cond_13

    .line 605
    .line 606
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 607
    .line 608
    .line 609
    move-result-object v5

    .line 610
    add-int/lit8 v6, v4, 0x1

    .line 611
    .line 612
    if-ltz v4, :cond_11

    .line 613
    .line 614
    check-cast v5, Lge4;

    .line 615
    .line 616
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 617
    .line 618
    .line 619
    instance-of v8, v5, Lde4;

    .line 620
    .line 621
    if-eqz v8, :cond_a

    .line 622
    .line 623
    check-cast v5, Lde4;

    .line 624
    .line 625
    goto :goto_7

    .line 626
    :cond_a
    instance-of v8, v5, Lee4;

    .line 627
    .line 628
    if-eqz v8, :cond_b

    .line 629
    .line 630
    check-cast v5, Lee4;

    .line 631
    .line 632
    iget-object v5, v5, Lee4;->b:Lge4;

    .line 633
    .line 634
    instance-of v8, v5, Lde4;

    .line 635
    .line 636
    if-eqz v8, :cond_b

    .line 637
    .line 638
    check-cast v5, Lde4;

    .line 639
    .line 640
    goto :goto_7

    .line 641
    :cond_b
    move-object/from16 v5, v16

    .line 642
    .line 643
    :goto_7
    if-eqz v5, :cond_10

    .line 644
    .line 645
    const v8, -0x3ca1744

    .line 646
    .line 647
    .line 648
    invoke-virtual {v0, v8}, Lub2;->b0(I)V

    .line 649
    .line 650
    .line 651
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 652
    .line 653
    .line 654
    move-result-object v8

    .line 655
    iget-object v9, v5, Lde4;->b:Ljava/lang/String;

    .line 656
    .line 657
    invoke-virtual {v0, v8, v9}, Lub2;->E(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 658
    .line 659
    .line 660
    move-result-object v8

    .line 661
    const v9, 0x316d3964

    .line 662
    .line 663
    .line 664
    invoke-virtual {v0, v9, v8}, Lub2;->Z(ILjava/lang/Object;)V

    .line 665
    .line 666
    .line 667
    invoke-interface {v2}, Lmm6;->getValue()Ljava/lang/Object;

    .line 668
    .line 669
    .line 670
    move-result-object v8

    .line 671
    check-cast v8, Ljava/lang/Integer;

    .line 672
    .line 673
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 674
    .line 675
    .line 676
    move-result-object v9

    .line 677
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 678
    .line 679
    .line 680
    move-result-object v10

    .line 681
    const/16 v13, 0xf

    .line 682
    .line 683
    if-ne v10, v11, :cond_c

    .line 684
    .line 685
    new-instance v10, Lcw3;

    .line 686
    .line 687
    invoke-direct {v10, v2, v13}, Lcw3;-><init>(Lw44;B)V

    .line 688
    .line 689
    .line 690
    invoke-virtual {v0, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 691
    .line 692
    .line 693
    :cond_c
    check-cast v10, Lfa2;

    .line 694
    .line 695
    invoke-static {v7, v8, v9, v10, v0}, Llc3;->J(Li14;Ljava/lang/Number;Ljava/lang/Number;Lfa2;Lub2;)Li14;

    .line 696
    .line 697
    .line 698
    move-result-object v8

    .line 699
    sget-object v9, Lac7;->d:Ltv;

    .line 700
    .line 701
    sget-object v10, Lt6;->w:Lp20;

    .line 702
    .line 703
    const/4 v14, 0x0

    .line 704
    invoke-static {v9, v10, v0, v14}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 705
    .line 706
    .line 707
    move-result-object v9

    .line 708
    iget-wide v14, v0, Lub2;->T:J

    .line 709
    .line 710
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 711
    .line 712
    .line 713
    move-result v10

    .line 714
    invoke-virtual {v0}, Lub2;->m()Lh05;

    .line 715
    .line 716
    .line 717
    move-result-object v14

    .line 718
    invoke-static {v0, v8}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 719
    .line 720
    .line 721
    move-result-object v8

    .line 722
    sget-object v15, La21;->d:Lt6;

    .line 723
    .line 724
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 725
    .line 726
    .line 727
    invoke-virtual {v0}, Lub2;->e0()V

    .line 728
    .line 729
    .line 730
    iget-boolean v15, v0, Lub2;->S:Z

    .line 731
    .line 732
    if-eqz v15, :cond_d

    .line 733
    .line 734
    invoke-virtual {v0, v3}, Lub2;->l(Lfa2;)V

    .line 735
    .line 736
    .line 737
    goto :goto_8

    .line 738
    :cond_d
    invoke-virtual {v0}, Lub2;->n0()V

    .line 739
    .line 740
    .line 741
    :goto_8
    sget-object v15, Lt6;->S:Lf11;

    .line 742
    .line 743
    invoke-static {v15, v0, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 744
    .line 745
    .line 746
    sget-object v9, Lt6;->R:Lf11;

    .line 747
    .line 748
    invoke-static {v9, v0, v14}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 749
    .line 750
    .line 751
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 752
    .line 753
    .line 754
    move-result-object v9

    .line 755
    sget-object v10, Lt6;->T:Lf11;

    .line 756
    .line 757
    invoke-static {v10, v0, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 758
    .line 759
    .line 760
    invoke-static {v0}, Les6;->l(Lub2;)V

    .line 761
    .line 762
    .line 763
    sget-object v9, Lt6;->Q:Lf11;

    .line 764
    .line 765
    invoke-static {v9, v0, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 766
    .line 767
    .line 768
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 769
    .line 770
    .line 771
    move-result-object v8

    .line 772
    invoke-static {v8}, Lnm;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 773
    .line 774
    .line 775
    move-result-object v25

    .line 776
    invoke-virtual {v0, v12}, Lub2;->g(Ljava/lang/Object;)Z

    .line 777
    .line 778
    .line 779
    move-result v8

    .line 780
    invoke-virtual {v0, v4}, Lub2;->e(I)Z

    .line 781
    .line 782
    .line 783
    move-result v9

    .line 784
    or-int/2addr v8, v9

    .line 785
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 786
    .line 787
    .line 788
    move-result-object v9

    .line 789
    if-nez v8, :cond_e

    .line 790
    .line 791
    if-ne v9, v11, :cond_f

    .line 792
    .line 793
    :cond_e
    new-instance v9, Lnj;

    .line 794
    .line 795
    invoke-direct {v9, v12, v4, v13}, Lnj;-><init>(Lqa2;IB)V

    .line 796
    .line 797
    .line 798
    invoke-virtual {v0, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 799
    .line 800
    .line 801
    :cond_f
    move-object/from16 v28, v9

    .line 802
    .line 803
    check-cast v28, Lfa2;

    .line 804
    .line 805
    const/16 v30, 0x0

    .line 806
    .line 807
    move-object/from16 v29, v0

    .line 808
    .line 809
    move-object/from16 v23, v5

    .line 810
    .line 811
    invoke-static/range {v23 .. v30}, Lrp7;->c(Lde4;Lge4;Ljava/util/List;Lqa2;Lua2;Lfa2;Lub2;I)V

    .line 812
    .line 813
    .line 814
    const/4 v4, 0x0

    .line 815
    const/4 v5, 0x1

    .line 816
    invoke-static {v0, v5, v4, v4}, Lvz1;->x(Lub2;ZZZ)V

    .line 817
    .line 818
    .line 819
    goto :goto_9

    .line 820
    :cond_10
    const/4 v4, 0x0

    .line 821
    const v5, -0x3bbb0ee

    .line 822
    .line 823
    .line 824
    invoke-virtual {v0, v5}, Lub2;->b0(I)V

    .line 825
    .line 826
    .line 827
    invoke-virtual {v0, v4}, Lub2;->r(Z)V

    .line 828
    .line 829
    .line 830
    :goto_9
    move v4, v6

    .line 831
    goto/16 :goto_6

    .line 832
    .line 833
    :cond_11
    invoke-static {}, Lnm;->q0()V

    .line 834
    .line 835
    .line 836
    throw v16

    .line 837
    :cond_12
    move-object v0, v1

    .line 838
    invoke-virtual {v0}, Lub2;->V()V

    .line 839
    .line 840
    .line 841
    :cond_13
    return-object v33

    .line 842
    :pswitch_1
    move-object/from16 v33, v9

    .line 843
    .line 844
    const/4 v4, 0x0

    .line 845
    check-cast v0, Ljava/util/List;

    .line 846
    .line 847
    check-cast v6, Ljava/util/List;

    .line 848
    .line 849
    check-cast v10, Lq41;

    .line 850
    .line 851
    check-cast v2, Ltk2;

    .line 852
    .line 853
    check-cast v15, Lw44;

    .line 854
    .line 855
    check-cast v14, Lw44;

    .line 856
    .line 857
    check-cast v13, Lw44;

    .line 858
    .line 859
    check-cast v12, Lw44;

    .line 860
    .line 861
    move-object/from16 v1, p1

    .line 862
    .line 863
    check-cast v1, Lkc3;

    .line 864
    .line 865
    move-object/from16 v3, p2

    .line 866
    .line 867
    check-cast v3, Lub2;

    .line 868
    .line 869
    move-object/from16 v5, p3

    .line 870
    .line 871
    check-cast v5, Ljava/lang/Integer;

    .line 872
    .line 873
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 874
    .line 875
    .line 876
    move-result v5

    .line 877
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 878
    .line 879
    .line 880
    and-int/lit8 v1, v5, 0x11

    .line 881
    .line 882
    if-eq v1, v8, :cond_14

    .line 883
    .line 884
    const/4 v4, 0x1

    .line 885
    :cond_14
    const/16 v34, 0x1

    .line 886
    .line 887
    and-int/lit8 v5, v5, 0x1

    .line 888
    .line 889
    invoke-virtual {v3, v5, v4}, Lub2;->S(IZ)Z

    .line 890
    .line 891
    .line 892
    move-result v1

    .line 893
    if-eqz v1, :cond_19

    .line 894
    .line 895
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 896
    .line 897
    .line 898
    move-result v16

    .line 899
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 900
    .line 901
    .line 902
    move-result v1

    .line 903
    invoke-virtual {v10}, Lq41;->b()Lo41;

    .line 904
    .line 905
    .line 906
    move-result-object v4

    .line 907
    invoke-virtual {v4}, Lo41;->b()Z

    .line 908
    .line 909
    .line 910
    move-result v4

    .line 911
    invoke-interface {v12}, Lmm6;->getValue()Ljava/lang/Object;

    .line 912
    .line 913
    .line 914
    move-result-object v5

    .line 915
    check-cast v5, Ljava/lang/String;

    .line 916
    .line 917
    invoke-static {v5}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 918
    .line 919
    .line 920
    move-result v5

    .line 921
    xor-int/lit8 v5, v5, 0x1

    .line 922
    .line 923
    iget-boolean v6, v2, Ltk2;->g:Z

    .line 924
    .line 925
    invoke-virtual {v3, v10}, Lub2;->g(Ljava/lang/Object;)Z

    .line 926
    .line 927
    .line 928
    move-result v7

    .line 929
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 930
    .line 931
    .line 932
    move-result-object v8

    .line 933
    if-nez v7, :cond_15

    .line 934
    .line 935
    if-ne v8, v11, :cond_16

    .line 936
    .line 937
    :cond_15
    new-instance v8, Lc41;

    .line 938
    .line 939
    const/4 v7, 0x4

    .line 940
    invoke-direct {v8, v10, v7}, Lc41;-><init>(Lq41;B)V

    .line 941
    .line 942
    .line 943
    invoke-virtual {v3, v8}, Lub2;->k0(Ljava/lang/Object;)V

    .line 944
    .line 945
    .line 946
    :cond_16
    check-cast v8, Lfa2;

    .line 947
    .line 948
    invoke-interface {v15}, Lmm6;->getValue()Ljava/lang/Object;

    .line 949
    .line 950
    .line 951
    move-result-object v7

    .line 952
    check-cast v7, Ljava/lang/String;

    .line 953
    .line 954
    invoke-interface {v14}, Lmm6;->getValue()Ljava/lang/Object;

    .line 955
    .line 956
    .line 957
    move-result-object v9

    .line 958
    check-cast v9, Ljava/lang/Boolean;

    .line 959
    .line 960
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 961
    .line 962
    .line 963
    move-result v9

    .line 964
    invoke-virtual {v3, v15}, Lub2;->g(Ljava/lang/Object;)Z

    .line 965
    .line 966
    .line 967
    move-result v10

    .line 968
    invoke-virtual {v3, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 969
    .line 970
    .line 971
    move-result v12

    .line 972
    or-int/2addr v10, v12

    .line 973
    invoke-virtual {v3, v2}, Lub2;->i(Ljava/lang/Object;)Z

    .line 974
    .line 975
    .line 976
    move-result v12

    .line 977
    or-int/2addr v10, v12

    .line 978
    invoke-virtual {v3, v0}, Lub2;->i(Ljava/lang/Object;)Z

    .line 979
    .line 980
    .line 981
    move-result v12

    .line 982
    or-int/2addr v10, v12

    .line 983
    invoke-virtual {v3, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 984
    .line 985
    .line 986
    move-result v12

    .line 987
    or-int/2addr v10, v12

    .line 988
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 989
    .line 990
    .line 991
    move-result-object v12

    .line 992
    if-nez v10, :cond_17

    .line 993
    .line 994
    if-ne v12, v11, :cond_18

    .line 995
    .line 996
    :cond_17
    new-instance v17, Lpd;

    .line 997
    .line 998
    const/16 v23, 0x3

    .line 999
    .line 1000
    move-object/from16 v19, v0

    .line 1001
    .line 1002
    move-object/from16 v18, v2

    .line 1003
    .line 1004
    move-object/from16 v22, v13

    .line 1005
    .line 1006
    move-object/from16 v21, v14

    .line 1007
    .line 1008
    move-object/from16 v20, v15

    .line 1009
    .line 1010
    invoke-direct/range {v17 .. v23}, Lpd;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1011
    .line 1012
    .line 1013
    move-object/from16 v12, v17

    .line 1014
    .line 1015
    invoke-virtual {v3, v12}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1016
    .line 1017
    .line 1018
    :cond_18
    move-object/from16 v24, v12

    .line 1019
    .line 1020
    check-cast v24, Lfa2;

    .line 1021
    .line 1022
    const/16 v25, 0x0

    .line 1023
    .line 1024
    const/16 v27, 0x0

    .line 1025
    .line 1026
    move/from16 v17, v1

    .line 1027
    .line 1028
    move-object/from16 v26, v3

    .line 1029
    .line 1030
    move/from16 v18, v4

    .line 1031
    .line 1032
    move/from16 v19, v5

    .line 1033
    .line 1034
    move/from16 v20, v6

    .line 1035
    .line 1036
    move-object/from16 v22, v7

    .line 1037
    .line 1038
    move-object/from16 v21, v8

    .line 1039
    .line 1040
    move/from16 v23, v9

    .line 1041
    .line 1042
    invoke-static/range {v16 .. v27}, Lnm;->k(IIZZZLfa2;Ljava/lang/String;ZLfa2;Li14;Lub2;I)V

    .line 1043
    .line 1044
    .line 1045
    goto :goto_a

    .line 1046
    :cond_19
    move-object/from16 v26, v3

    .line 1047
    .line 1048
    invoke-virtual/range {v26 .. v26}, Lub2;->V()V

    .line 1049
    .line 1050
    .line 1051
    :goto_a
    return-object v33

    .line 1052
    :pswitch_2
    move-object/from16 v33, v9

    .line 1053
    .line 1054
    const/4 v4, 0x0

    .line 1055
    check-cast v0, Li93;

    .line 1056
    .line 1057
    move-object/from16 v21, v6

    .line 1058
    .line 1059
    check-cast v21, Lt12;

    .line 1060
    .line 1061
    check-cast v10, Ls93;

    .line 1062
    .line 1063
    move-object/from16 v36, v2

    .line 1064
    .line 1065
    check-cast v36, Lne3;

    .line 1066
    .line 1067
    check-cast v15, Lsf;

    .line 1068
    .line 1069
    check-cast v14, Ljava/lang/String;

    .line 1070
    .line 1071
    check-cast v13, Lua2;

    .line 1072
    .line 1073
    check-cast v12, Landroid/content/Context;

    .line 1074
    .line 1075
    move-object/from16 v1, p1

    .line 1076
    .line 1077
    check-cast v1, Lvu4;

    .line 1078
    .line 1079
    move-object/from16 v2, p2

    .line 1080
    .line 1081
    check-cast v2, Lub2;

    .line 1082
    .line 1083
    move-object/from16 v3, p3

    .line 1084
    .line 1085
    check-cast v3, Ljava/lang/Integer;

    .line 1086
    .line 1087
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 1088
    .line 1089
    .line 1090
    move-result v3

    .line 1091
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1092
    .line 1093
    .line 1094
    and-int/lit8 v6, v3, 0x6

    .line 1095
    .line 1096
    if-nez v6, :cond_1b

    .line 1097
    .line 1098
    invoke-virtual {v2, v1}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1099
    .line 1100
    .line 1101
    move-result v6

    .line 1102
    if-eqz v6, :cond_1a

    .line 1103
    .line 1104
    const/4 v6, 0x4

    .line 1105
    goto :goto_b

    .line 1106
    :cond_1a
    const/4 v6, 0x2

    .line 1107
    :goto_b
    or-int/2addr v3, v6

    .line 1108
    :cond_1b
    and-int/lit8 v6, v3, 0x13

    .line 1109
    .line 1110
    const/16 v8, 0x12

    .line 1111
    .line 1112
    if-eq v6, v8, :cond_1c

    .line 1113
    .line 1114
    const/4 v4, 0x1

    .line 1115
    :cond_1c
    const/4 v6, 0x1

    .line 1116
    and-int/2addr v3, v6

    .line 1117
    invoke-virtual {v2, v3, v4}, Lub2;->S(IZ)Z

    .line 1118
    .line 1119
    .line 1120
    move-result v3

    .line 1121
    if-eqz v3, :cond_1f

    .line 1122
    .line 1123
    const/high16 v3, 0x3f800000    # 1.0f

    .line 1124
    .line 1125
    invoke-static {v7, v3}, Lch6;->c(Li14;F)Li14;

    .line 1126
    .line 1127
    .line 1128
    move-result-object v3

    .line 1129
    invoke-static {v3, v0, v6}, Ldx3;->b(Li14;Li93;Z)Li14;

    .line 1130
    .line 1131
    .line 1132
    move-result-object v0

    .line 1133
    invoke-static {v0}, Ljw;->q0(Li14;)Li14;

    .line 1134
    .line 1135
    .line 1136
    move-result-object v20

    .line 1137
    const/16 v24, 0x0

    .line 1138
    .line 1139
    const/16 v25, 0x2

    .line 1140
    .line 1141
    const/16 v22, 0x0

    .line 1142
    .line 1143
    move-object/from16 v23, v2

    .line 1144
    .line 1145
    invoke-static/range {v20 .. v25}, Lhb3;->P(Li14;Lt12;ZLub2;II)Li14;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v0

    .line 1149
    move-object/from16 v6, v21

    .line 1150
    .line 1151
    iget-object v3, v6, Lt12;->e:Ls12;

    .line 1152
    .line 1153
    move-object/from16 v4, v16

    .line 1154
    .line 1155
    invoke-static {v0, v3, v4}, Lvv6;->K(Li14;Lma4;Lpa4;)Li14;

    .line 1156
    .line 1157
    .line 1158
    move-result-object v35

    .line 1159
    invoke-static {v1, v10}, Lmi1;->q(Lvu4;Ls93;)F

    .line 1160
    .line 1161
    .line 1162
    move-result v0

    .line 1163
    add-float/2addr v0, v5

    .line 1164
    invoke-interface {v1}, Lvu4;->d()F

    .line 1165
    .line 1166
    .line 1167
    move-result v3

    .line 1168
    add-float/2addr v3, v5

    .line 1169
    invoke-static {v1, v10}, Lmi1;->p(Lvu4;Ls93;)F

    .line 1170
    .line 1171
    .line 1172
    move-result v4

    .line 1173
    add-float/2addr v4, v5

    .line 1174
    invoke-interface {v1}, Lvu4;->c()F

    .line 1175
    .line 1176
    .line 1177
    move-result v1

    .line 1178
    add-float/2addr v1, v5

    .line 1179
    new-instance v6, Lxu4;

    .line 1180
    .line 1181
    invoke-direct {v6, v0, v3, v4, v1}, Lxu4;-><init>(FFFF)V

    .line 1182
    .line 1183
    .line 1184
    new-instance v0, Lvv;

    .line 1185
    .line 1186
    new-instance v1, Lj02;

    .line 1187
    .line 1188
    const/4 v9, 0x3

    .line 1189
    invoke-direct {v1, v9}, Lj02;-><init>(B)V

    .line 1190
    .line 1191
    .line 1192
    const/4 v3, 0x1

    .line 1193
    invoke-direct {v0, v5, v3, v1}, Lvv;-><init>(FZLj02;)V

    .line 1194
    .line 1195
    .line 1196
    invoke-virtual {v2, v15}, Lub2;->i(Ljava/lang/Object;)Z

    .line 1197
    .line 1198
    .line 1199
    move-result v1

    .line 1200
    invoke-virtual {v2, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1201
    .line 1202
    .line 1203
    move-result v3

    .line 1204
    or-int/2addr v1, v3

    .line 1205
    invoke-virtual {v2, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1206
    .line 1207
    .line 1208
    move-result v3

    .line 1209
    or-int/2addr v1, v3

    .line 1210
    invoke-virtual {v2, v12}, Lub2;->i(Ljava/lang/Object;)Z

    .line 1211
    .line 1212
    .line 1213
    move-result v3

    .line 1214
    or-int/2addr v1, v3

    .line 1215
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 1216
    .line 1217
    .line 1218
    move-result-object v3

    .line 1219
    if-nez v1, :cond_1d

    .line 1220
    .line 1221
    if-ne v3, v11, :cond_1e

    .line 1222
    .line 1223
    :cond_1d
    new-instance v22, Lb2;

    .line 1224
    .line 1225
    const/16 v27, 0x0

    .line 1226
    .line 1227
    move-object/from16 v26, v12

    .line 1228
    .line 1229
    move-object/from16 v25, v13

    .line 1230
    .line 1231
    move-object/from16 v24, v14

    .line 1232
    .line 1233
    move-object/from16 v23, v15

    .line 1234
    .line 1235
    invoke-direct/range {v22 .. v27}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1236
    .line 1237
    .line 1238
    move-object/from16 v3, v22

    .line 1239
    .line 1240
    invoke-virtual {v2, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1241
    .line 1242
    .line 1243
    :cond_1e
    move-object/from16 v43, v3

    .line 1244
    .line 1245
    check-cast v43, Lqa2;

    .line 1246
    .line 1247
    const v45, 0x6006000

    .line 1248
    .line 1249
    .line 1250
    const/16 v46, 0xe8

    .line 1251
    .line 1252
    const/16 v39, 0x0

    .line 1253
    .line 1254
    const/16 v40, 0x0

    .line 1255
    .line 1256
    const/16 v41, 0x0

    .line 1257
    .line 1258
    const/16 v42, 0x0

    .line 1259
    .line 1260
    move-object/from16 v38, v0

    .line 1261
    .line 1262
    move-object/from16 v44, v2

    .line 1263
    .line 1264
    move-object/from16 v37, v6

    .line 1265
    .line 1266
    invoke-static/range {v35 .. v46}, Lhb3;->a(Li14;Lne3;Lvu4;Lwv;Lp20;Lwj1;ZLas4;Lqa2;Lub2;II)V

    .line 1267
    .line 1268
    .line 1269
    goto :goto_c

    .line 1270
    :cond_1f
    move-object/from16 v44, v2

    .line 1271
    .line 1272
    invoke-virtual/range {v44 .. v44}, Lub2;->V()V

    .line 1273
    .line 1274
    .line 1275
    :goto_c
    return-object v33

    .line 1276
    nop

    .line 1277
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
