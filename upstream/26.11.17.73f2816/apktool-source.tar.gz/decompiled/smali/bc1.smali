.class public final synthetic Lbc1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/ArrayList;

.field public final synthetic k:Ljava/util/ArrayList;

.field public final synthetic l:Z


# direct methods
.method public synthetic constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lbc1;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lbc1;->j:Ljava/util/ArrayList;

    .line 8
    .line 9
    iput-object p2, p0, Lbc1;->k:Ljava/util/ArrayList;

    .line 10
    .line 11
    iput-boolean p3, p0, Lbc1;->l:Z

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/ArrayList;ZLjava/util/ArrayList;)V
    .locals 1

    .line 14
    const/4 v0, 0x0

    iput-byte v0, p0, Lbc1;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbc1;->j:Ljava/util/ArrayList;

    iput-boolean p2, p0, Lbc1;->l:Z

    iput-object p3, p0, Lbc1;->k:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbc1;->i:B

    .line 4
    .line 5
    sget-object v2, Lne7;->a:Lne7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    iget-boolean v5, v0, Lbc1;->l:Z

    .line 10
    .line 11
    iget-object v6, v0, Lbc1;->k:Ljava/util/ArrayList;

    .line 12
    .line 13
    iget-object v0, v0, Lbc1;->j:Ljava/util/ArrayList;

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object/from16 v12, p1

    .line 20
    .line 21
    check-cast v12, Lub2;

    .line 22
    .line 23
    move-object/from16 v1, p2

    .line 24
    .line 25
    check-cast v1, Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    and-int/lit8 v8, v1, 0x3

    .line 32
    .line 33
    if-eq v8, v3, :cond_0

    .line 34
    .line 35
    move v3, v4

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v3, v7

    .line 38
    :goto_0
    and-int/2addr v1, v4

    .line 39
    invoke-virtual {v12, v1, v3}, Lub2;->S(IZ)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_4

    .line 44
    .line 45
    sget-object v1, Lf14;->i:Lf14;

    .line 46
    .line 47
    const/high16 v3, 0x3f800000    # 1.0f

    .line 48
    .line 49
    invoke-static {v1, v3}, Lch6;->d(Li14;F)Li14;

    .line 50
    .line 51
    .line 52
    move-result-object v8

    .line 53
    invoke-static {v12}, Ly60;->F(Lub2;)Lu46;

    .line 54
    .line 55
    .line 56
    move-result-object v9

    .line 57
    const/16 v10, 0xe

    .line 58
    .line 59
    invoke-static {v8, v9, v7, v10}, Ly60;->I(Li14;Lu46;ZI)Li14;

    .line 60
    .line 61
    .line 62
    move-result-object v8

    .line 63
    sget-object v9, Lac7;->d:Ltv;

    .line 64
    .line 65
    sget-object v10, Lt6;->w:Lp20;

    .line 66
    .line 67
    invoke-static {v9, v10, v12, v7}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    iget-wide v10, v12, Lub2;->T:J

    .line 72
    .line 73
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 74
    .line 75
    .line 76
    move-result v10

    .line 77
    invoke-virtual {v12}, Lub2;->m()Lh05;

    .line 78
    .line 79
    .line 80
    move-result-object v11

    .line 81
    invoke-static {v12, v8}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    sget-object v13, La21;->d:Lt6;

    .line 86
    .line 87
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v12}, Lub2;->e0()V

    .line 91
    .line 92
    .line 93
    iget-boolean v13, v12, Lub2;->S:Z

    .line 94
    .line 95
    if-eqz v13, :cond_1

    .line 96
    .line 97
    sget-object v13, Lja3;->a0:Lxg2;

    .line 98
    .line 99
    invoke-virtual {v12, v13}, Lub2;->l(Lfa2;)V

    .line 100
    .line 101
    .line 102
    goto :goto_1

    .line 103
    :cond_1
    invoke-virtual {v12}, Lub2;->n0()V

    .line 104
    .line 105
    .line 106
    :goto_1
    sget-object v13, Lt6;->S:Lf11;

    .line 107
    .line 108
    invoke-static {v13, v12, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    sget-object v9, Lt6;->R:Lf11;

    .line 112
    .line 113
    invoke-static {v9, v12, v11}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 117
    .line 118
    .line 119
    move-result-object v9

    .line 120
    sget-object v10, Lt6;->T:Lf11;

    .line 121
    .line 122
    invoke-static {v10, v12, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-static {v12}, Les6;->l(Lub2;)V

    .line 126
    .line 127
    .line 128
    sget-object v9, Lt6;->Q:Lf11;

    .line 129
    .line 130
    invoke-static {v9, v12, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v1, v3}, Lch6;->d(Li14;F)Li14;

    .line 134
    .line 135
    .line 136
    move-result-object v8

    .line 137
    const v1, -0x5d0bddbb

    .line 138
    .line 139
    .line 140
    invoke-virtual {v12, v1}, Lub2;->b0(I)V

    .line 141
    .line 142
    .line 143
    new-instance v11, Ljava/util/ArrayList;

    .line 144
    .line 145
    const/16 v1, 0xa

    .line 146
    .line 147
    invoke-static {v0, v1}, Lnv0;->w0(Ljava/lang/Iterable;I)I

    .line 148
    .line 149
    .line 150
    move-result v1

    .line 151
    invoke-direct {v11, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    move v1, v7

    .line 159
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 160
    .line 161
    .line 162
    move-result v3

    .line 163
    if-eqz v3, :cond_3

    .line 164
    .line 165
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    add-int/lit8 v9, v1, 0x1

    .line 170
    .line 171
    if-ltz v1, :cond_2

    .line 172
    .line 173
    check-cast v3, Ljava/lang/Number;

    .line 174
    .line 175
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 176
    .line 177
    .line 178
    move-result v3

    .line 179
    new-instance v10, Lgc1;

    .line 180
    .line 181
    invoke-direct {v10, v6, v1, v5, v3}, Lgc1;-><init>(Ljava/util/ArrayList;IZI)V

    .line 182
    .line 183
    .line 184
    const v1, -0xde99ff1

    .line 185
    .line 186
    .line 187
    invoke-static {v1, v10, v12}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    invoke-virtual {v11, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move v1, v9

    .line 195
    goto :goto_2

    .line 196
    :cond_2
    invoke-static {}, Lnm;->q0()V

    .line 197
    .line 198
    .line 199
    const/4 v0, 0x0

    .line 200
    throw v0

    .line 201
    :cond_3
    invoke-virtual {v12, v7}, Lub2;->r(Z)V

    .line 202
    .line 203
    .line 204
    const/4 v13, 0x6

    .line 205
    const/16 v14, 0x16

    .line 206
    .line 207
    const/4 v9, 0x0

    .line 208
    const/4 v10, 0x0

    .line 209
    invoke-static/range {v8 .. v14}, Lqr3;->d(Li14;Ljava/lang/String;Lc01;Ljava/util/List;Lub2;II)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v12, v4}, Lub2;->r(Z)V

    .line 213
    .line 214
    .line 215
    goto :goto_3

    .line 216
    :cond_4
    invoke-virtual {v12}, Lub2;->V()V

    .line 217
    .line 218
    .line 219
    :goto_3
    return-object v2

    .line 220
    :pswitch_0
    move-object/from16 v1, p1

    .line 221
    .line 222
    check-cast v1, Lub2;

    .line 223
    .line 224
    move-object/from16 v8, p2

    .line 225
    .line 226
    check-cast v8, Ljava/lang/Integer;

    .line 227
    .line 228
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 229
    .line 230
    .line 231
    move-result v8

    .line 232
    and-int/lit8 v9, v8, 0x3

    .line 233
    .line 234
    if-eq v9, v3, :cond_5

    .line 235
    .line 236
    move v3, v4

    .line 237
    goto :goto_4

    .line 238
    :cond_5
    move v3, v7

    .line 239
    :goto_4
    and-int/2addr v8, v4

    .line 240
    invoke-virtual {v1, v8, v3}, Lub2;->S(IZ)Z

    .line 241
    .line 242
    .line 243
    move-result v3

    .line 244
    if-eqz v3, :cond_6

    .line 245
    .line 246
    new-instance v3, Lcc1;

    .line 247
    .line 248
    invoke-direct {v3, v0, v5, v6, v7}, Lcc1;-><init>(Ljava/util/ArrayList;ZLjava/util/ArrayList;B)V

    .line 249
    .line 250
    .line 251
    const v0, 0x3c58ace0

    .line 252
    .line 253
    .line 254
    invoke-static {v0, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 255
    .line 256
    .line 257
    move-result-object v17

    .line 258
    const/16 v19, 0x6000

    .line 259
    .line 260
    const/16 v20, 0xf

    .line 261
    .line 262
    const/4 v13, 0x0

    .line 263
    const/4 v14, 0x0

    .line 264
    const/4 v15, 0x0

    .line 265
    const/16 v16, 0x0

    .line 266
    .line 267
    move-object/from16 v18, v1

    .line 268
    .line 269
    invoke-static/range {v13 .. v20}, Lkb3;->f(Li14;FLwv;Lu46;Lc01;Lub2;II)V

    .line 270
    .line 271
    .line 272
    goto :goto_5

    .line 273
    :cond_6
    move-object/from16 v18, v1

    .line 274
    .line 275
    invoke-virtual/range {v18 .. v18}, Lub2;->V()V

    .line 276
    .line 277
    .line 278
    :goto_5
    return-object v2

    .line 279
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
