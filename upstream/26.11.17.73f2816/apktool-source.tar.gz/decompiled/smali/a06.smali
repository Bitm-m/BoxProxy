.class public final synthetic La06;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:Li93;

.field public final synthetic j:Ley5;

.field public final synthetic k:Lyh5;

.field public final synthetic l:Ljava/util/List;

.field public final synthetic m:Lt12;

.field public final synthetic n:Lne3;

.field public final synthetic o:Ljava/util/List;

.field public final synthetic p:Le73;

.field public final synthetic q:Lw06;

.field public final synthetic r:Lij2;

.field public final synthetic s:Lv06;

.field public final synthetic t:Lqa2;

.field public final synthetic u:Landroid/content/Context;

.field public final synthetic v:Llp3;

.field public final synthetic w:Lfy5;

.field public final synthetic x:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Li93;Ley5;Lyh5;Ljava/util/List;Lt12;Lne3;Ljava/util/List;Le73;Lw06;Lij2;Lv06;Lqa2;Landroid/content/Context;Llp3;Lfy5;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La06;->i:Li93;

    .line 5
    .line 6
    iput-object p2, p0, La06;->j:Ley5;

    .line 7
    .line 8
    iput-object p3, p0, La06;->k:Lyh5;

    .line 9
    .line 10
    iput-object p4, p0, La06;->l:Ljava/util/List;

    .line 11
    .line 12
    iput-object p5, p0, La06;->m:Lt12;

    .line 13
    .line 14
    iput-object p6, p0, La06;->n:Lne3;

    .line 15
    .line 16
    iput-object p7, p0, La06;->o:Ljava/util/List;

    .line 17
    .line 18
    iput-object p8, p0, La06;->p:Le73;

    .line 19
    .line 20
    iput-object p9, p0, La06;->q:Lw06;

    .line 21
    .line 22
    iput-object p10, p0, La06;->r:Lij2;

    .line 23
    .line 24
    iput-object p11, p0, La06;->s:Lv06;

    .line 25
    .line 26
    iput-object p12, p0, La06;->t:Lqa2;

    .line 27
    .line 28
    iput-object p13, p0, La06;->u:Landroid/content/Context;

    .line 29
    .line 30
    iput-object p14, p0, La06;->v:Llp3;

    .line 31
    .line 32
    iput-object p15, p0, La06;->w:Lfy5;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, La06;->x:Ljava/lang/String;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v3, p1

    .line 4
    .line 5
    check-cast v3, Lvu4;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Lub2;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v4, v2, 0x6

    .line 23
    .line 24
    const/4 v5, 0x2

    .line 25
    if-nez v4, :cond_1

    .line 26
    .line 27
    invoke-virtual {v1, v3}, Lub2;->g(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    const/4 v4, 0x4

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    move v4, v5

    .line 36
    :goto_0
    or-int/2addr v2, v4

    .line 37
    :cond_1
    and-int/lit8 v4, v2, 0x13

    .line 38
    .line 39
    const/16 v6, 0x12

    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2

    .line 44
    .line 45
    move v4, v8

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    move v4, v7

    .line 48
    :goto_1
    and-int/2addr v2, v8

    .line 49
    invoke-virtual {v1, v2, v4}, Lub2;->S(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_6

    .line 54
    .line 55
    sget-object v2, Lch6;->c:Li32;

    .line 56
    .line 57
    iget-object v4, v0, La06;->i:Li93;

    .line 58
    .line 59
    invoke-static {v2, v4, v8}, Ldx3;->b(Li14;Li93;Z)Li14;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    sget-object v6, Lt6;->k:Lr20;

    .line 64
    .line 65
    invoke-static {v6, v7}, Lnb0;->c(Lr20;Z)Lis3;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    iget-wide v9, v1, Lub2;->T:J

    .line 70
    .line 71
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 72
    .line 73
    .line 74
    move-result v7

    .line 75
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 76
    .line 77
    .line 78
    move-result-object v9

    .line 79
    invoke-static {v1, v4}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 80
    .line 81
    .line 82
    move-result-object v4

    .line 83
    sget-object v10, La21;->d:Lt6;

    .line 84
    .line 85
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v1}, Lub2;->e0()V

    .line 89
    .line 90
    .line 91
    iget-boolean v10, v1, Lub2;->S:Z

    .line 92
    .line 93
    if-eqz v10, :cond_3

    .line 94
    .line 95
    sget-object v10, Lja3;->a0:Lxg2;

    .line 96
    .line 97
    invoke-virtual {v1, v10}, Lub2;->l(Lfa2;)V

    .line 98
    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_3
    invoke-virtual {v1}, Lub2;->n0()V

    .line 102
    .line 103
    .line 104
    :goto_2
    sget-object v10, Lt6;->S:Lf11;

    .line 105
    .line 106
    invoke-static {v10, v1, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    sget-object v6, Lt6;->R:Lf11;

    .line 110
    .line 111
    invoke-static {v6, v1, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    sget-object v7, Lt6;->T:Lf11;

    .line 119
    .line 120
    invoke-static {v7, v1, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v1}, Les6;->l(Lub2;)V

    .line 124
    .line 125
    .line 126
    sget-object v6, Lt6;->Q:Lf11;

    .line 127
    .line 128
    invoke-static {v6, v1, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    iget-object v4, v0, La06;->j:Ley5;

    .line 132
    .line 133
    iget-object v6, v4, Ley5;->h:Ldy4;

    .line 134
    .line 135
    invoke-virtual {v6}, Ldy4;->getValue()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v6

    .line 139
    check-cast v6, Ljava/lang/Boolean;

    .line 140
    .line 141
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 142
    .line 143
    .line 144
    move-result v16

    .line 145
    invoke-interface {v3}, Lvu4;->d()F

    .line 146
    .line 147
    .line 148
    move-result v6

    .line 149
    const/16 v7, 0xd

    .line 150
    .line 151
    const/4 v9, 0x0

    .line 152
    invoke-static {v9, v6, v9, v9, v7}, Lmi1;->i(FFFFI)Lxu4;

    .line 153
    .line 154
    .line 155
    move-result-object v17

    .line 156
    invoke-virtual {v1, v4}, Lub2;->g(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v6

    .line 160
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v7

    .line 164
    if-nez v6, :cond_4

    .line 165
    .line 166
    sget-object v6, Li21;->a:Ls9;

    .line 167
    .line 168
    if-ne v7, v6, :cond_5

    .line 169
    .line 170
    :cond_4
    new-instance v7, Ljn5;

    .line 171
    .line 172
    invoke-direct {v7, v4, v5}, Ljn5;-><init>(Ljava/lang/Object;B)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v1, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    :cond_5
    move-object/from16 v18, v7

    .line 179
    .line 180
    check-cast v18, Lfa2;

    .line 181
    .line 182
    move-object v15, v1

    .line 183
    new-instance v1, Lwz5;

    .line 184
    .line 185
    move-object v6, v2

    .line 186
    iget-object v2, v0, La06;->m:Lt12;

    .line 187
    .line 188
    move-object v5, v4

    .line 189
    iget-object v4, v0, La06;->n:Lne3;

    .line 190
    .line 191
    move-object v7, v6

    .line 192
    iget-object v6, v0, La06;->o:Ljava/util/List;

    .line 193
    .line 194
    move-object v9, v7

    .line 195
    iget-object v7, v0, La06;->p:Le73;

    .line 196
    .line 197
    iget-object v8, v0, La06;->q:Lw06;

    .line 198
    .line 199
    move-object v11, v9

    .line 200
    iget-object v9, v0, La06;->r:Lij2;

    .line 201
    .line 202
    iget-object v10, v0, La06;->s:Lv06;

    .line 203
    .line 204
    move-object v13, v11

    .line 205
    iget-object v11, v0, La06;->t:Lqa2;

    .line 206
    .line 207
    iget-object v12, v0, La06;->u:Landroid/content/Context;

    .line 208
    .line 209
    move-object/from16 v19, v13

    .line 210
    .line 211
    iget-object v13, v0, La06;->v:Llp3;

    .line 212
    .line 213
    iget-object v14, v0, La06;->w:Lfy5;

    .line 214
    .line 215
    move-object/from16 v21, v15

    .line 216
    .line 217
    iget-object v15, v0, La06;->x:Ljava/lang/String;

    .line 218
    .line 219
    move-object/from16 v0, v21

    .line 220
    .line 221
    invoke-direct/range {v1 .. v15}, Lwz5;-><init>(Lt12;Lvu4;Lne3;Ley5;Ljava/util/List;Le73;Lw06;Lij2;Lv06;Lqa2;Landroid/content/Context;Llp3;Lfy5;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    const v2, -0x3e449f2c

    .line 225
    .line 226
    .line 227
    invoke-static {v2, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 228
    .line 229
    .line 230
    move-result-object v14

    .line 231
    move/from16 v4, v16

    .line 232
    .line 233
    const/16 v16, 0x1180

    .line 234
    .line 235
    move-object/from16 v1, p0

    .line 236
    .line 237
    iget-object v7, v1, La06;->k:Lyh5;

    .line 238
    .line 239
    const-wide/16 v9, 0x0

    .line 240
    .line 241
    const/4 v11, 0x0

    .line 242
    iget-object v12, v1, La06;->l:Ljava/util/List;

    .line 243
    .line 244
    const/4 v13, 0x0

    .line 245
    move-object v15, v0

    .line 246
    move-object/from16 v8, v17

    .line 247
    .line 248
    move-object/from16 v5, v18

    .line 249
    .line 250
    move-object/from16 v6, v19

    .line 251
    .line 252
    invoke-static/range {v4 .. v16}, Lkh5;->a(ZLfa2;Li14;Lyh5;Lvu4;JFLjava/util/List;Lk37;Lc01;Lub2;I)V

    .line 253
    .line 254
    .line 255
    const/4 v12, 0x1

    .line 256
    invoke-virtual {v15, v12}, Lub2;->r(Z)V

    .line 257
    .line 258
    .line 259
    goto :goto_3

    .line 260
    :cond_6
    move-object v15, v1

    .line 261
    invoke-virtual {v15}, Lub2;->V()V

    .line 262
    .line 263
    .line 264
    :goto_3
    sget-object v0, Lne7;->a:Lne7;

    .line 265
    .line 266
    return-object v0
.end method
