.class public final La54;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lkm7;


# instance fields
.field public final a:Ldy4;


# direct methods
.method public constructor <init>(Lkm7;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, Lhb3;->Q(Ljava/lang/Object;)Ldy4;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    iput-object p1, p0, La54;->a:Ldy4;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final a(Lul1;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, La54;->a:Ldy4;

    .line 5
    .line 6
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lkm7;

    .line 11
    .line 12
    invoke-interface {p0, p1}, Lkm7;->a(Lul1;)I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public final b(Lul1;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, La54;->a:Ldy4;

    .line 5
    .line 6
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lkm7;

    .line 11
    .line 12
    invoke-interface {p0, p1}, Lkm7;->b(Lul1;)I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public final c(Lul1;Ls93;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, La54;->a:Ldy4;

    .line 8
    .line 9
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lkm7;

    .line 14
    .line 15
    invoke-interface {p0, p1, p2}, Lkm7;->c(Lul1;Ls93;)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method

.method public final d(Lul1;Ls93;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, La54;->a:Ldy4;

    .line 8
    .line 9
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lkm7;

    .line 14
    .line 15
    invoke-interface {p0, p1, p2}, Lkm7;->d(Lul1;Ls93;)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method
