.class public final Laa6;
.super Loa3;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final e:Laa6;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Laa6;

    .line 2
    .line 3
    invoke-direct {v0}, Loa3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Laa6;->e:Laa6;

    .line 7
    .line 8
    return-void
.end method
