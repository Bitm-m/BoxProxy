.class public interface abstract Lac2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lq73;


# virtual methods
.method public abstract a()[Lq73;
.end method
