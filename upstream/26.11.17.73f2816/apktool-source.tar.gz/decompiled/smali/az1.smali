.class public final Laz1;
.super Lja1;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public i:Ljk6;

.field public j:Lzz0;

.field public k:Llw2;

.field public l:Ljava/lang/Object;

.field public m:Lyp4;

.field public n:Lyy1;

.field public o:I

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Lez1;

.field public r:I


# direct methods
.method public constructor <init>(Lez1;Lja1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laz1;->q:Lez1;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lja1;-><init>(Lia1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iput-object p1, p0, Laz1;->p:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Laz1;->r:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Laz1;->r:I

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    const/4 v6, 0x0

    .line 12
    iget-object v0, p0, Laz1;->q:Lez1;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x0

    .line 16
    const/4 v3, 0x0

    .line 17
    const/4 v4, 0x0

    .line 18
    move-object v7, p0

    .line 19
    invoke-virtual/range {v0 .. v7}, Lez1;->a(Ljk6;Lzz0;Llw2;Ljava/lang/Object;Lyp4;Lyy1;Lja1;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method
