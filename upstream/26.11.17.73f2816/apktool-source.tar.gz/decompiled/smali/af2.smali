.class public final synthetic Laf2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic A:J

.field public final synthetic B:J

.field public final synthetic C:J

.field public final synthetic D:Lk37;

.field public final synthetic E:Ljava/lang/String;

.field public final synthetic F:Ljava/lang/String;

.field public final synthetic G:Lqa2;

.field public final synthetic H:Lu46;

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Ljava/util/List;

.field public final synthetic m:I

.field public final synthetic n:Lrf2;

.field public final synthetic o:Ljava/util/List;

.field public final synthetic p:Lng;

.field public final synthetic q:Ljava/util/List;

.field public final synthetic r:F

.field public final synthetic s:F

.field public final synthetic t:Lgz;

.field public final synthetic u:Lqg2;

.field public final synthetic v:F

.field public final synthetic w:Lce2;

.field public final synthetic x:Lpu1;

.field public final synthetic y:Lng2;

.field public final synthetic z:J


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;ZZLjava/util/List;ILrf2;Ljava/util/List;Lng;Ljava/util/List;FFLgz;Lqg2;FLce2;Lpu1;Lng2;JJJJLk37;Ljava/lang/String;Ljava/lang/String;Lqa2;Lu46;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laf2;->i:Ljava/util/List;

    iput-boolean p2, p0, Laf2;->j:Z

    iput-boolean p3, p0, Laf2;->k:Z

    iput-object p4, p0, Laf2;->l:Ljava/util/List;

    iput p5, p0, Laf2;->m:I

    iput-object p6, p0, Laf2;->n:Lrf2;

    iput-object p7, p0, Laf2;->o:Ljava/util/List;

    iput-object p8, p0, Laf2;->p:Lng;

    iput-object p9, p0, Laf2;->q:Ljava/util/List;

    iput p10, p0, Laf2;->r:F

    iput p11, p0, Laf2;->s:F

    iput-object p12, p0, Laf2;->t:Lgz;

    iput-object p13, p0, Laf2;->u:Lqg2;

    iput p14, p0, Laf2;->v:F

    iput-object p15, p0, Laf2;->w:Lce2;

    move-object/from16 p1, p16

    iput-object p1, p0, Laf2;->x:Lpu1;

    move-object/from16 p1, p17

    iput-object p1, p0, Laf2;->y:Lng2;

    move-wide/from16 p1, p18

    iput-wide p1, p0, Laf2;->z:J

    move-wide/from16 p1, p20

    iput-wide p1, p0, Laf2;->A:J

    move-wide/from16 p1, p22

    iput-wide p1, p0, Laf2;->B:J

    move-wide/from16 p1, p24

    iput-wide p1, p0, Laf2;->C:J

    move-object/from16 p1, p26

    iput-object p1, p0, Laf2;->D:Lk37;

    move-object/from16 p1, p27

    iput-object p1, p0, Laf2;->E:Ljava/lang/String;

    move-object/from16 p1, p28

    iput-object p1, p0, Laf2;->F:Ljava/lang/String;

    move-object/from16 p1, p29

    iput-object p1, p0, Laf2;->G:Lqa2;

    move-object/from16 p1, p30

    iput-object p1, p0, Laf2;->H:Lu46;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 36

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lmd0;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Lub2;

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 23
    .line 24
    const/4 v5, 0x4

    .line 25
    if-nez v4, :cond_1

    .line 26
    .line 27
    invoke-virtual {v2, v1}, Lub2;->g(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    move v4, v5

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    const/4 v4, 0x2

    .line 36
    :goto_0
    or-int/2addr v3, v4

    .line 37
    :cond_1
    and-int/lit8 v4, v3, 0x13

    .line 38
    .line 39
    const/16 v6, 0x12

    .line 40
    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2

    .line 44
    .line 45
    move v4, v8

    .line 46
    goto :goto_1

    .line 47
    :cond_2
    move v4, v7

    .line 48
    :goto_1
    and-int/2addr v3, v8

    .line 49
    invoke-virtual {v2, v3, v4}, Lub2;->S(IZ)Z

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_1b

    .line 54
    .line 55
    invoke-virtual {v1}, Lmd0;->c()F

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    iget-object v4, v1, Lmd0;->a:Lup6;

    .line 60
    .line 61
    iget-wide v8, v1, Lmd0;->b:J

    .line 62
    .line 63
    invoke-static {v8, v9}, Lb81;->d(J)Z

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_3

    .line 68
    .line 69
    invoke-static {v8, v9}, Lb81;->h(J)I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    invoke-interface {v4, v1}, Lul1;->l1(I)F

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    goto :goto_2

    .line 78
    :cond_3
    const/high16 v1, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 79
    .line 80
    :goto_2
    iget-object v4, v0, Laf2;->i:Ljava/util/List;

    .line 81
    .line 82
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 83
    .line 84
    .line 85
    move-result-object v6

    .line 86
    const/4 v8, 0x0

    .line 87
    move v9, v8

    .line 88
    :goto_3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 89
    .line 90
    .line 91
    move-result v10

    .line 92
    if-eqz v10, :cond_4

    .line 93
    .line 94
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v10

    .line 98
    check-cast v10, Lvp1;

    .line 99
    .line 100
    iget v10, v10, Lvp1;->i:F

    .line 101
    .line 102
    add-float/2addr v9, v10

    .line 103
    goto :goto_3

    .line 104
    :cond_4
    iget-boolean v6, v0, Laf2;->j:Z

    .line 105
    .line 106
    if-eqz v6, :cond_5

    .line 107
    .line 108
    sget v10, Lof2;->v:F

    .line 109
    .line 110
    goto :goto_4

    .line 111
    :cond_5
    move v10, v8

    .line 112
    :goto_4
    const/high16 v11, 0x41000000    # 8.0f

    .line 113
    .line 114
    add-float/2addr v10, v11

    .line 115
    sget v11, Lof2;->z:F

    .line 116
    .line 117
    add-float/2addr v11, v10

    .line 118
    add-float v12, v11, v9

    .line 119
    .line 120
    new-instance v13, Lvp1;

    .line 121
    .line 122
    invoke-direct {v13, v12}, Lvp1;-><init>(F)V

    .line 123
    .line 124
    .line 125
    sget v12, Lof2;->B:F

    .line 126
    .line 127
    const/high16 v14, 0x40000000    # 2.0f

    .line 128
    .line 129
    mul-float/2addr v12, v14

    .line 130
    sub-float v12, v3, v12

    .line 131
    .line 132
    new-instance v15, Lvp1;

    .line 133
    .line 134
    invoke-direct {v15, v12}, Lvp1;-><init>(F)V

    .line 135
    .line 136
    .line 137
    sget v12, Lof2;->C:F

    .line 138
    .line 139
    move/from16 p1, v14

    .line 140
    .line 141
    new-instance v14, Lvp1;

    .line 142
    .line 143
    invoke-direct {v14, v12}, Lvp1;-><init>(F)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v15, v14}, Lvp1;->compareTo(Ljava/lang/Object;)I

    .line 147
    .line 148
    .line 149
    move-result v12

    .line 150
    if-gez v12, :cond_6

    .line 151
    .line 152
    move-object v15, v14

    .line 153
    :cond_6
    invoke-virtual {v13, v15}, Lvp1;->compareTo(Ljava/lang/Object;)I

    .line 154
    .line 155
    .line 156
    move-result v12

    .line 157
    if-lez v12, :cond_7

    .line 158
    .line 159
    move-object v13, v15

    .line 160
    :cond_7
    new-instance v12, Lvp1;

    .line 161
    .line 162
    invoke-direct {v12, v3}, Lvp1;-><init>(F)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v13, v12}, Lvp1;->compareTo(Ljava/lang/Object;)I

    .line 166
    .line 167
    .line 168
    move-result v14

    .line 169
    if-lez v14, :cond_8

    .line 170
    .line 171
    move-object v13, v12

    .line 172
    :cond_8
    invoke-static {v9, v8}, Lvp1;->a(FF)I

    .line 173
    .line 174
    .line 175
    move-result v12

    .line 176
    iget v13, v13, Lvp1;->i:F

    .line 177
    .line 178
    if-lez v12, :cond_9

    .line 179
    .line 180
    sub-float v11, v13, v11

    .line 181
    .line 182
    div-float/2addr v11, v9

    .line 183
    cmpg-float v9, v11, v8

    .line 184
    .line 185
    if-ltz v9, :cond_a

    .line 186
    .line 187
    move v8, v11

    .line 188
    goto :goto_5

    .line 189
    :cond_9
    const/high16 v8, 0x3f800000    # 1.0f

    .line 190
    .line 191
    :cond_a
    :goto_5
    invoke-virtual {v2, v4}, Lub2;->g(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v9

    .line 195
    invoke-virtual {v2, v8}, Lub2;->d(F)Z

    .line 196
    .line 197
    .line 198
    move-result v11

    .line 199
    or-int/2addr v9, v11

    .line 200
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v11

    .line 204
    sget-object v12, Li21;->a:Ls9;

    .line 205
    .line 206
    if-nez v9, :cond_b

    .line 207
    .line 208
    if-ne v11, v12, :cond_d

    .line 209
    .line 210
    :cond_b
    new-instance v11, Ljava/util/ArrayList;

    .line 211
    .line 212
    const/16 v9, 0xa

    .line 213
    .line 214
    invoke-static {v4, v9}, Lnv0;->w0(Ljava/lang/Iterable;I)I

    .line 215
    .line 216
    .line 217
    move-result v9

    .line 218
    invoke-direct {v11, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 219
    .line 220
    .line 221
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 226
    .line 227
    .line 228
    move-result v9

    .line 229
    if-eqz v9, :cond_c

    .line 230
    .line 231
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v9

    .line 235
    check-cast v9, Lvp1;

    .line 236
    .line 237
    iget v9, v9, Lvp1;->i:F

    .line 238
    .line 239
    mul-float/2addr v9, v8

    .line 240
    new-instance v14, Lvp1;

    .line 241
    .line 242
    invoke-direct {v14, v9}, Lvp1;-><init>(F)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v11, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    goto :goto_6

    .line 249
    :cond_c
    invoke-virtual {v2, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    :cond_d
    move-object v8, v11

    .line 253
    check-cast v8, Ljava/util/List;

    .line 254
    .line 255
    sub-float/2addr v3, v13

    .line 256
    div-float v3, v3, p1

    .line 257
    .line 258
    sget v4, Lfj;->f:F

    .line 259
    .line 260
    sub-float/2addr v1, v4

    .line 261
    const/high16 v4, 0x41400000    # 12.0f

    .line 262
    .line 263
    sub-float/2addr v1, v4

    .line 264
    new-instance v9, Lvp1;

    .line 265
    .line 266
    invoke-direct {v9, v1}, Lvp1;-><init>(F)V

    .line 267
    .line 268
    .line 269
    new-instance v1, Lvp1;

    .line 270
    .line 271
    const/high16 v11, 0x42300000    # 44.0f

    .line 272
    .line 273
    invoke-direct {v1, v11}, Lvp1;-><init>(F)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v9, v1}, Lvp1;->compareTo(Ljava/lang/Object;)I

    .line 277
    .line 278
    .line 279
    move-result v14

    .line 280
    if-gez v14, :cond_e

    .line 281
    .line 282
    move-object v9, v1

    .line 283
    :cond_e
    iget-boolean v1, v0, Laf2;->k:Z

    .line 284
    .line 285
    iget v9, v9, Lvp1;->i:F

    .line 286
    .line 287
    if-eqz v1, :cond_f

    .line 288
    .line 289
    move v11, v9

    .line 290
    :cond_f
    invoke-virtual {v2, v9}, Lub2;->d(F)Z

    .line 291
    .line 292
    .line 293
    move-result v14

    .line 294
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 295
    .line 296
    .line 297
    move-result-object v15

    .line 298
    const/4 v4, 0x5

    .line 299
    if-nez v14, :cond_10

    .line 300
    .line 301
    if-ne v15, v12, :cond_11

    .line 302
    .line 303
    :cond_10
    new-instance v15, Lh1;

    .line 304
    .line 305
    invoke-direct {v15, v9, v4}, Lh1;-><init>(FB)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {v2, v15}, Lub2;->k0(Ljava/lang/Object;)V

    .line 309
    .line 310
    .line 311
    :cond_11
    check-cast v15, Lqa2;

    .line 312
    .line 313
    invoke-static {v11, v1, v15, v2, v7}, Lof2;->h(FZLqa2;Lub2;I)Lng;

    .line 314
    .line 315
    .line 316
    move-result-object v7

    .line 317
    if-eqz v1, :cond_12

    .line 318
    .line 319
    const/high16 v3, 0x41400000    # 12.0f

    .line 320
    .line 321
    :cond_12
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v9

    .line 325
    const/4 v11, 0x3

    .line 326
    if-ne v9, v12, :cond_13

    .line 327
    .line 328
    new-instance v9, Lsd2;

    .line 329
    .line 330
    invoke-direct {v9, v11}, Lsd2;-><init>(B)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v2, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    :cond_13
    check-cast v9, Lqa2;

    .line 337
    .line 338
    const/16 v14, 0x180

    .line 339
    .line 340
    invoke-static {v3, v1, v9, v2, v14}, Lof2;->h(FZLqa2;Lub2;I)Lng;

    .line 341
    .line 342
    .line 343
    move-result-object v3

    .line 344
    iget-object v9, v0, Laf2;->p:Lng;

    .line 345
    .line 346
    invoke-virtual {v2, v9}, Lub2;->i(Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    move-result v14

    .line 350
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v15

    .line 354
    if-nez v14, :cond_14

    .line 355
    .line 356
    if-ne v15, v12, :cond_15

    .line 357
    .line 358
    :cond_14
    new-instance v15, Lg20;

    .line 359
    .line 360
    invoke-direct {v15, v9, v11}, Lg20;-><init>(Lng;B)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v2, v15}, Lub2;->k0(Ljava/lang/Object;)V

    .line 364
    .line 365
    .line 366
    :cond_15
    check-cast v15, Lfa2;

    .line 367
    .line 368
    invoke-virtual {v2, v3}, Lub2;->i(Ljava/lang/Object;)Z

    .line 369
    .line 370
    .line 371
    move-result v9

    .line 372
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 373
    .line 374
    .line 375
    move-result-object v11

    .line 376
    if-nez v9, :cond_16

    .line 377
    .line 378
    if-ne v11, v12, :cond_17

    .line 379
    .line 380
    :cond_16
    new-instance v11, Lg20;

    .line 381
    .line 382
    invoke-direct {v11, v3, v5}, Lg20;-><init>(Lng;B)V

    .line 383
    .line 384
    .line 385
    invoke-virtual {v2, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 386
    .line 387
    .line 388
    :cond_17
    check-cast v11, Lfa2;

    .line 389
    .line 390
    invoke-virtual {v2, v7}, Lub2;->i(Ljava/lang/Object;)Z

    .line 391
    .line 392
    .line 393
    move-result v3

    .line 394
    invoke-virtual {v2}, Lub2;->N()Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v5

    .line 398
    if-nez v3, :cond_18

    .line 399
    .line 400
    if-ne v5, v12, :cond_19

    .line 401
    .line 402
    :cond_18
    new-instance v5, Lg20;

    .line 403
    .line 404
    invoke-direct {v5, v7, v4}, Lg20;-><init>(Lng;B)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v2, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    :cond_19
    check-cast v5, Lfa2;

    .line 411
    .line 412
    if-eqz v1, :cond_1a

    .line 413
    .line 414
    iget-object v1, v0, Laf2;->E:Ljava/lang/String;

    .line 415
    .line 416
    :goto_7
    move-object/from16 v31, v1

    .line 417
    .line 418
    goto :goto_8

    .line 419
    :cond_1a
    iget-object v1, v0, Laf2;->F:Ljava/lang/String;

    .line 420
    .line 421
    goto :goto_7

    .line 422
    :goto_8
    const/16 v35, 0x0

    .line 423
    .line 424
    move-object/from16 v34, v2

    .line 425
    .line 426
    iget-object v2, v0, Laf2;->l:Ljava/util/List;

    .line 427
    .line 428
    iget v3, v0, Laf2;->m:I

    .line 429
    .line 430
    iget-object v4, v0, Laf2;->n:Lrf2;

    .line 431
    .line 432
    move v7, v6

    .line 433
    move-object v6, v15

    .line 434
    move-object v15, v5

    .line 435
    iget-object v5, v0, Laf2;->o:Ljava/util/List;

    .line 436
    .line 437
    iget-object v9, v0, Laf2;->q:Ljava/util/List;

    .line 438
    .line 439
    iget v12, v0, Laf2;->r:F

    .line 440
    .line 441
    iget v14, v0, Laf2;->s:F

    .line 442
    .line 443
    iget-object v1, v0, Laf2;->t:Lgz;

    .line 444
    .line 445
    move-object/from16 v16, v1

    .line 446
    .line 447
    iget-object v1, v0, Laf2;->u:Lqg2;

    .line 448
    .line 449
    move-object/from16 v17, v1

    .line 450
    .line 451
    iget v1, v0, Laf2;->v:F

    .line 452
    .line 453
    move/from16 v18, v1

    .line 454
    .line 455
    iget-object v1, v0, Laf2;->w:Lce2;

    .line 456
    .line 457
    move-object/from16 v19, v1

    .line 458
    .line 459
    iget-object v1, v0, Laf2;->x:Lpu1;

    .line 460
    .line 461
    move-object/from16 v20, v1

    .line 462
    .line 463
    iget-object v1, v0, Laf2;->y:Lng2;

    .line 464
    .line 465
    move-object/from16 v22, v1

    .line 466
    .line 467
    move-object/from16 v21, v2

    .line 468
    .line 469
    iget-wide v1, v0, Laf2;->z:J

    .line 470
    .line 471
    move-wide/from16 v23, v1

    .line 472
    .line 473
    iget-wide v1, v0, Laf2;->A:J

    .line 474
    .line 475
    move-wide/from16 v25, v1

    .line 476
    .line 477
    iget-wide v1, v0, Laf2;->B:J

    .line 478
    .line 479
    move-wide/from16 v27, v1

    .line 480
    .line 481
    iget-wide v1, v0, Laf2;->C:J

    .line 482
    .line 483
    move-wide/from16 v29, v1

    .line 484
    .line 485
    iget-object v1, v0, Laf2;->D:Lk37;

    .line 486
    .line 487
    iget-object v2, v0, Laf2;->G:Lqa2;

    .line 488
    .line 489
    iget-object v0, v0, Laf2;->H:Lu46;

    .line 490
    .line 491
    move/from16 v32, v13

    .line 492
    .line 493
    move-object v13, v11

    .line 494
    move/from16 v11, v32

    .line 495
    .line 496
    move-object/from16 v33, v0

    .line 497
    .line 498
    move-object/from16 v32, v2

    .line 499
    .line 500
    move-object/from16 v2, v21

    .line 501
    .line 502
    move-object/from16 v21, v22

    .line 503
    .line 504
    move-wide/from16 v22, v23

    .line 505
    .line 506
    move-wide/from16 v24, v25

    .line 507
    .line 508
    move-wide/from16 v26, v27

    .line 509
    .line 510
    move-wide/from16 v28, v29

    .line 511
    .line 512
    move-object/from16 v30, v1

    .line 513
    .line 514
    invoke-static/range {v2 .. v35}, Lof2;->b(Ljava/util/List;ILrf2;Ljava/util/List;Lfa2;ZLjava/util/List;Ljava/util/List;FFFLfa2;FLfa2;Lgz;Lqg2;FLce2;Lpu1;Lng2;JJJJLk37;Ljava/lang/String;Lqa2;Lu46;Lub2;I)V

    .line 515
    .line 516
    .line 517
    goto :goto_9

    .line 518
    :cond_1b
    move-object/from16 v34, v2

    .line 519
    .line 520
    invoke-virtual/range {v34 .. v34}, Lub2;->V()V

    .line 521
    .line 522
    .line 523
    :goto_9
    sget-object v0, Lne7;->a:Lne7;

    .line 524
    .line 525
    return-object v0
.end method
