.class public interface abstract La21;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final d:Lt6;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lt6;->O:Lt6;

    .line 2
    .line 3
    sput-object v0, La21;->d:Lt6;

    .line 4
    .line 5
    return-void
.end method
