.class public final Laz4;
.super Lsz4;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final c:Laz4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Laz4;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-direct {v0, v1}, Lsz4;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Laz4;->c:Laz4;

    .line 8
    .line 9
    return-void
.end method
