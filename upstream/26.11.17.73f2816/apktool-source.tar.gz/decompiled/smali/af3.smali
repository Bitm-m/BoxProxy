.class public abstract Laf3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final a:Lze3;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lze3;->j:Lze3;

    .line 2
    .line 3
    sput-object v0, Laf3;->a:Lze3;

    .line 4
    .line 5
    return-void
.end method
