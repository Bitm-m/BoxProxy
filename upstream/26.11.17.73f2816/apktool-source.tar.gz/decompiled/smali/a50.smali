.class public final synthetic La50;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Lrf1;

.field public final synthetic k:Lul1;

.field public final synthetic l:Lng;

.field public final synthetic m:Lay4;

.field public final synthetic n:Lzx4;

.field public final synthetic o:Lim7;

.field public final synthetic p:Lfa2;

.field public final synthetic q:Lqa2;


# direct methods
.method public synthetic constructor <init>(ZLrf1;Lul1;Lng;Lay4;Lzx4;Lim7;Lfa2;Lqa2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, La50;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, La50;->j:Lrf1;

    .line 7
    .line 8
    iput-object p3, p0, La50;->k:Lul1;

    .line 9
    .line 10
    iput-object p4, p0, La50;->l:Lng;

    .line 11
    .line 12
    iput-object p5, p0, La50;->m:Lay4;

    .line 13
    .line 14
    iput-object p6, p0, La50;->n:Lzx4;

    .line 15
    .line 16
    iput-object p7, p0, La50;->o:Lim7;

    .line 17
    .line 18
    iput-object p8, p0, La50;->p:Lfa2;

    .line 19
    .line 20
    iput-object p9, p0, La50;->q:Lqa2;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 12

    .line 1
    const/4 v0, 0x3

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-boolean v2, p0, La50;->i:Z

    .line 4
    .line 5
    iget-object v3, p0, La50;->j:Lrf1;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    new-instance v4, Lq50;

    .line 10
    .line 11
    const/4 v11, 0x0

    .line 12
    iget-object v5, p0, La50;->k:Lul1;

    .line 13
    .line 14
    iget-object v6, p0, La50;->l:Lng;

    .line 15
    .line 16
    iget-object v7, p0, La50;->m:Lay4;

    .line 17
    .line 18
    iget-object v8, p0, La50;->n:Lzx4;

    .line 19
    .line 20
    iget-object v9, p0, La50;->o:Lim7;

    .line 21
    .line 22
    iget-object v10, p0, La50;->p:Lfa2;

    .line 23
    .line 24
    invoke-direct/range {v4 .. v11}, Lq50;-><init>(Lul1;Lng;Lay4;Lzx4;Lim7;Lfa2;Lia1;)V

    .line 25
    .line 26
    .line 27
    invoke-static {v3, v1, v1, v4, v0}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance v2, Lp50;

    .line 32
    .line 33
    const/4 v4, 0x1

    .line 34
    iget-object p0, p0, La50;->q:Lqa2;

    .line 35
    .line 36
    invoke-direct {v2, p0, v1, v4}, Lp50;-><init>(Lqa2;Lia1;B)V

    .line 37
    .line 38
    .line 39
    invoke-static {v3, v1, v1, v2, v0}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 40
    .line 41
    .line 42
    :goto_0
    sget-object p0, Lne7;->a:Lne7;

    .line 43
    .line 44
    return-object p0
.end method
