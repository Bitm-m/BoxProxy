.class public final synthetic La1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lw44;


# direct methods
.method public synthetic constructor <init>(Lw44;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La1;->j:Lw44;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-byte v0, p0, La1;->i:B

    .line 2
    .line 3
    const-string v1, "Required value was null."

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    sget-object v3, Lne7;->a:Lne7;

    .line 7
    .line 8
    iget-object p0, p0, La1;->j:Lw44;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 14
    .line 15
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-object v3

    .line 19
    :pswitch_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-object v3

    .line 25
    :pswitch_1
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/lang/Boolean;

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    xor-int/lit8 v0, v0, 0x1

    .line 36
    .line 37
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return-object v3

    .line 45
    :pswitch_2
    invoke-interface {p0, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    return-object v3

    .line 49
    :pswitch_3
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 50
    .line 51
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-object v3

    .line 55
    :pswitch_4
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 56
    .line 57
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    return-object v3

    .line 61
    :pswitch_5
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 62
    .line 63
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    return-object v3

    .line 67
    :pswitch_6
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 68
    .line 69
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    return-object v3

    .line 73
    :pswitch_7
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    check-cast v0, Ljava/lang/Boolean;

    .line 78
    .line 79
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    xor-int/lit8 v0, v0, 0x1

    .line 84
    .line 85
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    return-object v3

    .line 93
    :pswitch_8
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 94
    .line 95
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    return-object v3

    .line 99
    :pswitch_9
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 100
    .line 101
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    return-object v3

    .line 105
    :pswitch_a
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 106
    .line 107
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    return-object v3

    .line 111
    :pswitch_b
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    check-cast p0, Lfa2;

    .line 116
    .line 117
    if-eqz p0, :cond_0

    .line 118
    .line 119
    invoke-interface {p0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    :cond_0
    return-object v3

    .line 123
    :pswitch_c
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    check-cast p0, Landroid/content/Context;

    .line 128
    .line 129
    return-object p0

    .line 130
    :pswitch_d
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object p0

    .line 134
    check-cast p0, Ly03;

    .line 135
    .line 136
    iget-wide v0, p0, Ly03;->a:J

    .line 137
    .line 138
    return-object p0

    .line 139
    :pswitch_e
    invoke-interface {p0, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    return-object v3

    .line 143
    :pswitch_f
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object p0

    .line 147
    check-cast p0, Lfa2;

    .line 148
    .line 149
    invoke-interface {p0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    return-object v3

    .line 153
    :pswitch_10
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object p0

    .line 157
    check-cast p0, Lfa2;

    .line 158
    .line 159
    if-eqz p0, :cond_1

    .line 160
    .line 161
    invoke-interface {p0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    :cond_1
    return-object v3

    .line 165
    :pswitch_11
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object p0

    .line 169
    check-cast p0, Lfa2;

    .line 170
    .line 171
    if-eqz p0, :cond_2

    .line 172
    .line 173
    invoke-interface {p0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    :cond_2
    return-object v3

    .line 177
    :pswitch_12
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    check-cast p0, Landroid/content/Context;

    .line 182
    .line 183
    return-object p0

    .line 184
    :pswitch_13
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object p0

    .line 188
    check-cast p0, Lfa2;

    .line 189
    .line 190
    if-eqz p0, :cond_3

    .line 191
    .line 192
    invoke-interface {p0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    :cond_3
    return-object v3

    .line 196
    :pswitch_14
    if-eqz p0, :cond_4

    .line 197
    .line 198
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object p0

    .line 202
    move-object v2, p0

    .line 203
    check-cast v2, Ljava/util/List;

    .line 204
    .line 205
    :cond_4
    return-object v2

    .line 206
    :pswitch_15
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object p0

    .line 210
    check-cast p0, Lr93;

    .line 211
    .line 212
    if-eqz p0, :cond_5

    .line 213
    .line 214
    move-object v2, p0

    .line 215
    goto :goto_0

    .line 216
    :cond_5
    invoke-static {v1}, Lzy2;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 217
    .line 218
    .line 219
    invoke-static {}, Lqi1;->l()V

    .line 220
    .line 221
    .line 222
    :goto_0
    return-object v2

    .line 223
    :pswitch_16
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object p0

    .line 227
    check-cast p0, Landroid/content/Context;

    .line 228
    .line 229
    return-object p0

    .line 230
    :pswitch_17
    invoke-interface {p0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object p0

    .line 234
    check-cast p0, Lr93;

    .line 235
    .line 236
    if-eqz p0, :cond_6

    .line 237
    .line 238
    move-object v2, p0

    .line 239
    goto :goto_1

    .line 240
    :cond_6
    invoke-static {v1}, Lzy2;->d(Ljava/lang/String;)Ljava/lang/Void;

    .line 241
    .line 242
    .line 243
    invoke-static {}, Lqi1;->l()V

    .line 244
    .line 245
    .line 246
    :goto_1
    return-object v2

    .line 247
    :pswitch_18
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 248
    .line 249
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    return-object v3

    .line 253
    :pswitch_19
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 254
    .line 255
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    return-object v3

    .line 259
    :pswitch_1a
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 260
    .line 261
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 262
    .line 263
    .line 264
    return-object v3

    .line 265
    :pswitch_1b
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 266
    .line 267
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    return-object v3

    .line 271
    :pswitch_1c
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 272
    .line 273
    invoke-interface {p0, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 274
    .line 275
    .line 276
    return-object v3

    .line 277
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
