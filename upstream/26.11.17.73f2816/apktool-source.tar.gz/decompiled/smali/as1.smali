.class public final Las1;
.super Lh14;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Laa3;
.implements Lfs1;
.implements Llh2;
.implements Ldm4;
.implements Lz21;


# instance fields
.field public A:Lqa2;

.field public B:Lqa2;

.field public C:I

.field public D:Le75;

.field public E:Z

.field public final F:Lyb6;

.field public final G:Lyr1;

.field public final H:Lvr1;

.field public final I:Lhb0;

.field public final J:Ldy4;

.field public final K:Lwp4;

.field public L:Lvk5;

.field public M:Lbi2;

.field public N:Z

.field public O:Z

.field public P:Z

.field public Q:Z

.field public R:Lnm5;

.field public S:F

.field public T:F

.field public U:F

.field public V:F

.field public W:F

.field public X:F

.field public Y:F

.field public Z:Le75;

.field public a0:Lnm5;

.field public b0:Lnm5;

.field public c0:Lr30;

.field public d0:F

.field public e0:Lbe;

.field public f0:F

.field public g0:Z

.field public h0:Lnm5;

.field public i0:Le75;

.field public j0:F

.field public k0:F

.field public l0:F

.field public m0:F

.field public n0:F

.field public o0:I

.field public p0:J

.field public q0:J

.field public w:Lgz;

.field public x:Lqa2;

.field public y:Lqa2;

.field public z:Lua2;


# direct methods
.method public constructor <init>(Lgz;Lfa2;Lqa2;Lqa2;Lua2;Lqa2;Lqa2;ILe75;Z)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Lh14;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Las1;->w:Lgz;

    .line 8
    .line 9
    iput-object p3, p0, Las1;->x:Lqa2;

    .line 10
    .line 11
    iput-object p4, p0, Las1;->y:Lqa2;

    .line 12
    .line 13
    iput-object p5, p0, Las1;->z:Lua2;

    .line 14
    .line 15
    iput-object p6, p0, Las1;->A:Lqa2;

    .line 16
    .line 17
    iput-object p7, p0, Las1;->B:Lqa2;

    .line 18
    .line 19
    iput p8, p0, Las1;->C:I

    .line 20
    .line 21
    iput-object p9, p0, Las1;->D:Le75;

    .line 22
    .line 23
    iput-boolean p10, p0, Las1;->E:Z

    .line 24
    .line 25
    new-instance p1, Lyb6;

    .line 26
    .line 27
    invoke-direct {p1, p2}, Lyb6;-><init>(Lfa2;)V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, Las1;->F:Lyb6;

    .line 31
    .line 32
    new-instance p1, Lyr1;

    .line 33
    .line 34
    invoke-direct {p1, p0}, Lyr1;-><init>(Las1;)V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Las1;->G:Lyr1;

    .line 38
    .line 39
    new-instance p1, Lvr1;

    .line 40
    .line 41
    invoke-direct {p1, p0}, Lvr1;-><init>(Las1;)V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, Las1;->H:Lvr1;

    .line 45
    .line 46
    new-instance p1, Lhb0;

    .line 47
    .line 48
    const/16 p2, 0xa

    .line 49
    .line 50
    invoke-direct {p1, p0, p2}, Lhb0;-><init>(Ljava/lang/Object;B)V

    .line 51
    .line 52
    .line 53
    iput-object p1, p0, Las1;->I:Lhb0;

    .line 54
    .line 55
    sget-object p1, Lyy1;->z:Lyy1;

    .line 56
    .line 57
    new-instance p2, Ldy4;

    .line 58
    .line 59
    const/4 p3, 0x0

    .line 60
    invoke-direct {p2, p3, p1}, Ldy4;-><init>(Ljava/lang/Object;Llj6;)V

    .line 61
    .line 62
    .line 63
    iput-object p2, p0, Las1;->J:Ldy4;

    .line 64
    .line 65
    invoke-static {}, Ly60;->y()Lwp4;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, Las1;->K:Lwp4;

    .line 70
    .line 71
    const/high16 p1, 0x7fc00000    # Float.NaN

    .line 72
    .line 73
    iput p1, p0, Las1;->S:F

    .line 74
    .line 75
    iput p1, p0, Las1;->T:F

    .line 76
    .line 77
    iput p1, p0, Las1;->U:F

    .line 78
    .line 79
    iput p1, p0, Las1;->V:F

    .line 80
    .line 81
    iput p1, p0, Las1;->W:F

    .line 82
    .line 83
    iput p1, p0, Las1;->X:F

    .line 84
    .line 85
    iput p1, p0, Las1;->Y:F

    .line 86
    .line 87
    iput p1, p0, Las1;->d0:F

    .line 88
    .line 89
    iput p1, p0, Las1;->f0:F

    .line 90
    .line 91
    iput p1, p0, Las1;->j0:F

    .line 92
    .line 93
    iput p1, p0, Las1;->k0:F

    .line 94
    .line 95
    iput p1, p0, Las1;->l0:F

    .line 96
    .line 97
    iput p1, p0, Las1;->m0:F

    .line 98
    .line 99
    iput p1, p0, Las1;->n0:F

    .line 100
    .line 101
    const/4 p1, -0x1

    .line 102
    iput p1, p0, Las1;->o0:I

    .line 103
    .line 104
    const-wide/16 p1, 0x0

    .line 105
    .line 106
    iput-wide p1, p0, Las1;->p0:J

    .line 107
    .line 108
    iput-wide p1, p0, Las1;->q0:J

    .line 109
    .line 110
    return-void
.end method

.method public static I1(Lhs1;Lbi2;FFFF)V
    .locals 10

    .line 1
    float-to-double v0, p2

    .line 2
    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    double-to-float v0, v0

    .line 7
    const/4 v1, 0x0

    .line 8
    cmpg-float v1, p2, v1

    .line 9
    .line 10
    const-wide/16 v2, 0x0

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    move-wide v6, v2

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    float-to-int v1, v0

    .line 17
    neg-int v1, v1

    .line 18
    int-to-long v4, v1

    .line 19
    const/16 v1, 0x20

    .line 20
    .line 21
    shl-long v6, v4, v1

    .line 22
    .line 23
    const-wide v8, 0xffffffffL

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    and-long/2addr v4, v8

    .line 29
    or-long/2addr v6, v4

    .line 30
    :goto_0
    invoke-virtual {p1, v6, v7}, Lbi2;->m(J)V

    .line 31
    .line 32
    .line 33
    sub-float/2addr p2, v0

    .line 34
    mul-float/2addr p2, p3

    .line 35
    neg-float p4, p4

    .line 36
    sub-float/2addr p4, p2

    .line 37
    neg-float p5, p5

    .line 38
    sub-float/2addr p5, p2

    .line 39
    invoke-interface {p0}, Lhs1;->U()Lh47;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    iget-object p2, p2, Lh47;->j:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p2, Lmj7;

    .line 46
    .line 47
    invoke-virtual {p2, p4, p5}, Lmj7;->F(FF)V

    .line 48
    .line 49
    .line 50
    :try_start_0
    invoke-interface {p0}, Lhs1;->U()Lh47;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    invoke-virtual {p2}, Lh47;->F()J

    .line 55
    .line 56
    .line 57
    move-result-wide v0

    .line 58
    invoke-virtual {p2}, Lh47;->t()Ljj0;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    invoke-interface {v4}, Ljj0;->n()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 63
    .line 64
    .line 65
    :try_start_1
    iget-object v4, p2, Lh47;->j:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v4, Lmj7;

    .line 68
    .line 69
    invoke-virtual {v4, p3, p3, v2, v3}, Lmj7;->E(FFJ)V

    .line 70
    .line 71
    .line 72
    invoke-static {p0, p1}, Lfj;->w(Lhs1;Lbi2;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 73
    .line 74
    .line 75
    :try_start_2
    invoke-virtual {p2}, Lh47;->t()Ljj0;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-interface {p1}, Ljj0;->j()V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p2, v0, v1}, Lh47;->i0(J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 83
    .line 84
    .line 85
    invoke-interface {p0}, Lhs1;->U()Lh47;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    iget-object p0, p0, Lh47;->j:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast p0, Lmj7;

    .line 92
    .line 93
    neg-float p1, p4

    .line 94
    neg-float p2, p5

    .line 95
    invoke-virtual {p0, p1, p2}, Lmj7;->F(FF)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :catchall_0
    move-exception p1

    .line 100
    :try_start_3
    invoke-virtual {p2}, Lh47;->t()Ljj0;

    .line 101
    .line 102
    .line 103
    move-result-object p3

    .line 104
    invoke-interface {p3}, Ljj0;->j()V

    .line 105
    .line 106
    .line 107
    invoke-virtual {p2, v0, v1}, Lh47;->i0(J)V

    .line 108
    .line 109
    .line 110
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 111
    :catchall_1
    move-exception p1

    .line 112
    invoke-interface {p0}, Lhs1;->U()Lh47;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    iget-object p0, p0, Lh47;->j:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p0, Lmj7;

    .line 119
    .line 120
    neg-float p2, p4

    .line 121
    neg-float p3, p5

    .line 122
    invoke-virtual {p0, p2, p3}, Lmj7;->F(FF)V

    .line 123
    .line 124
    .line 125
    throw p1
.end method

.method public static final N1(FII)J
    .locals 4

    .line 1
    int-to-float p1, p1

    .line 2
    div-float/2addr p1, p0

    .line 3
    invoke-static {p1}, Lbs3;->Q(F)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x1

    .line 8
    if-ge p1, v0, :cond_0

    .line 9
    .line 10
    move p1, v0

    .line 11
    :cond_0
    int-to-float p2, p2

    .line 12
    div-float/2addr p2, p0

    .line 13
    invoke-static {p2}, Lbs3;->Q(F)I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-lt p0, v0, :cond_1

    .line 18
    .line 19
    move v0, p0

    .line 20
    :cond_1
    int-to-long p0, p1

    .line 21
    const/16 p2, 0x20

    .line 22
    .line 23
    shl-long/2addr p0, p2

    .line 24
    int-to-long v0, v0

    .line 25
    const-wide v2, 0xffffffffL

    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    and-long/2addr v0, v2

    .line 31
    or-long/2addr p0, v0

    .line 32
    return-wide p0
.end method


# virtual methods
.method public final F(Lij4;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Lij4;->z1()Lh14;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v0, v0, Lh14;->v:Z

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, Las1;->w:Lgz;

    .line 10
    .line 11
    invoke-interface {v0}, Lgz;->a()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    iget-object p0, p0, Las1;->J:Ldy4;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lr93;

    .line 28
    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    const/4 p1, 0x0

    .line 32
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    return-void
.end method

.method public final G1(Lhs1;Lvr1;ILbi2;JLbi2;JFLjava/lang/String;Ljava/lang/String;)V
    .locals 13

    .line 1
    move-object/from16 v1, p4

    .line 2
    .line 3
    move-object/from16 v2, p11

    .line 4
    .line 5
    const/16 v3, 0x20

    .line 6
    .line 7
    shr-long v3, p5, v3

    .line 8
    .line 9
    long-to-int v3, v3

    .line 10
    const-wide v4, 0xffffffffL

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    and-long v4, p5, v4

    .line 16
    .line 17
    long-to-int v4, v4

    .line 18
    iget-object v5, p2, Lvr1;->j:[Lnm5;

    .line 19
    .line 20
    iget-object v6, p2, Lvr1;->i:[I

    .line 21
    .line 22
    iget-object v7, p2, Lvr1;->h:[I

    .line 23
    .line 24
    iget-object v8, p2, Lvr1;->g:[Ljava/lang/String;

    .line 25
    .line 26
    aget-object v5, v5, p3

    .line 27
    .line 28
    if-eqz v5, :cond_0

    .line 29
    .line 30
    aget-object v9, v8, p3

    .line 31
    .line 32
    invoke-static {v9, v2}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    if-eqz v9, :cond_0

    .line 37
    .line 38
    aget v9, v7, p3

    .line 39
    .line 40
    if-ne v9, v3, :cond_0

    .line 41
    .line 42
    aget v9, v6, p3

    .line 43
    .line 44
    if-eq v9, v4, :cond_1

    .line 45
    .line 46
    :cond_0
    iget-object v5, p0, Las1;->G:Lyr1;

    .line 47
    .line 48
    move-object/from16 v9, p12

    .line 49
    .line 50
    invoke-virtual {v5, v2, v9}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    int-to-float v9, v3

    .line 55
    const/high16 v10, 0x3f000000    # 0.5f

    .line 56
    .line 57
    sub-float/2addr v9, v10

    .line 58
    int-to-float v11, v4

    .line 59
    sub-float/2addr v11, v10

    .line 60
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    iget-object v10, v5, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 64
    .line 65
    const-string v12, "maxCoord"

    .line 66
    .line 67
    invoke-static {v10, v12, v9, v11}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 68
    .line 69
    .line 70
    const-string v9, "child"

    .line 71
    .line 72
    invoke-static {v5, v9}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    iget-object v0, p2, Lvr1;->j:[Lnm5;

    .line 77
    .line 78
    aput-object v5, v0, p3

    .line 79
    .line 80
    aput-object v2, v8, p3

    .line 81
    .line 82
    aput v3, v7, p3

    .line 83
    .line 84
    aput v4, v6, p3

    .line 85
    .line 86
    :cond_1
    invoke-virtual {v1, v5}, Lbi2;->k(Lnm5;)V

    .line 87
    .line 88
    .line 89
    invoke-static {p0}, Lgj;->Z(Lhl1;)Lja3;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    iget-object p0, p0, Lja3;->G:Lul1;

    .line 94
    .line 95
    new-instance v0, Lwr1;

    .line 96
    .line 97
    const/4 v2, 0x0

    .line 98
    move/from16 v3, p10

    .line 99
    .line 100
    invoke-direct {v0, p0, v3, v1, v2}, Lwr1;-><init>(Lul1;FLbi2;B)V

    .line 101
    .line 102
    .line 103
    move-object/from16 p0, p7

    .line 104
    .line 105
    move-wide/from16 v1, p8

    .line 106
    .line 107
    invoke-interface {p1, p0, v1, v2, v0}, Lhs1;->c0(Lbi2;JLqa2;)V

    .line 108
    .line 109
    .line 110
    return-void
.end method

.method public final H1()V
    .locals 5

    .line 1
    iget-object p0, p0, Las1;->G:Lyr1;

    .line 2
    .line 3
    iget v0, p0, Lyr1;->p:F

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    cmpl-float v1, v0, v1

    .line 7
    .line 8
    if-lez v1, :cond_2

    .line 9
    .line 10
    iget v1, p0, Lyr1;->o:F

    .line 11
    .line 12
    const/high16 v2, 0x3f800000    # 1.0f

    .line 13
    .line 14
    cmpg-float v1, v1, v2

    .line 15
    .line 16
    if-gtz v1, :cond_2

    .line 17
    .line 18
    iget-object v1, p0, Lyr1;->n:Lnm5;

    .line 19
    .line 20
    iget-object v2, p0, Lyr1;->f0:Lnm5;

    .line 21
    .line 22
    if-eqz v2, :cond_0

    .line 23
    .line 24
    iget-object v3, p0, Lyr1;->d0:Lnm5;

    .line 25
    .line 26
    if-ne v3, v1, :cond_0

    .line 27
    .line 28
    iget v3, p0, Lyr1;->e0:F

    .line 29
    .line 30
    cmpg-float v3, v3, v0

    .line 31
    .line 32
    if-nez v3, :cond_0

    .line 33
    .line 34
    iput-object v2, p0, Lyr1;->n:Lnm5;

    .line 35
    .line 36
    return-void

    .line 37
    :cond_0
    invoke-static {}, Le5;->f()Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_1

    .line 42
    .line 43
    const-string v2, "NoiseDither"

    .line 44
    .line 45
    const-string v3, "\n    uniform shader child;\n    uniform float noise_coeff;\n\n    half4 main(float2 xy) {\n        float3 d = float3(\n            dot(xy, float2(6.9898, 78.233)),\n            dot(xy, float2(7.9898, 78.233)),\n            dot(xy, float2(8.9898, 78.233))\n        );\n        float3 n = (fract(sin(d) * float3(43734.5453, 43745.5453, 43767.5453)) - 0.5) * noise_coeff;\n        half4 color = child.eval(xy);\n        color.rg += half2(n.x);\n        color.rb += half2(n.y);\n        color.gb += half2(n.z);\n        return color;\n    }\n"

    .line 46
    .line 47
    invoke-virtual {p0, v2, v3}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    const-string v3, "noise_coeff"

    .line 55
    .line 56
    iget-object v4, v2, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 57
    .line 58
    invoke-static {v4, v3, v0}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 59
    .line 60
    .line 61
    const-string v3, "child"

    .line 62
    .line 63
    invoke-static {v2, v3}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    iget-object v3, p0, Lyr1;->n:Lnm5;

    .line 68
    .line 69
    invoke-static {v3, v2}, Ltc3;->E(Lnm5;Lnm5;)Lnm5;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    iput-object v2, p0, Lyr1;->n:Lnm5;

    .line 74
    .line 75
    :cond_1
    iput-object v1, p0, Lyr1;->d0:Lnm5;

    .line 76
    .line 77
    iput v0, p0, Lyr1;->e0:F

    .line 78
    .line 79
    iget-object v0, p0, Lyr1;->n:Lnm5;

    .line 80
    .line 81
    iput-object v0, p0, Lyr1;->f0:Lnm5;

    .line 82
    .line 83
    :cond_2
    return-void
.end method

.method public final J1(Lhs1;Lvr1;Lbi2;FFII)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    move/from16 v3, p4

    .line 8
    .line 9
    iget-boolean v4, v0, Las1;->g0:Z

    .line 10
    .line 11
    iget-object v5, v0, Las1;->G:Lyr1;

    .line 12
    .line 13
    const/4 v6, 0x0

    .line 14
    if-eqz v4, :cond_0

    .line 15
    .line 16
    move v4, v6

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    iget v4, v5, Lyr1;->p:F

    .line 19
    .line 20
    :goto_0
    iget-object v7, v0, Las1;->w:Lgz;

    .line 21
    .line 22
    invoke-interface {v7}, Lgz;->c()F

    .line 23
    .line 24
    .line 25
    move-result v12

    .line 26
    iget-object v7, v0, Las1;->w:Lgz;

    .line 27
    .line 28
    invoke-interface {v7}, Lgz;->d()F

    .line 29
    .line 30
    .line 31
    move-result v13

    .line 32
    cmpl-float v6, v4, v6

    .line 33
    .line 34
    if-lez v6, :cond_4

    .line 35
    .line 36
    const-wide/16 v6, 0x0

    .line 37
    .line 38
    invoke-virtual {v2, v6, v7}, Lbi2;->m(J)V

    .line 39
    .line 40
    .line 41
    iget-object v6, v1, Lvr1;->c:Lbi2;

    .line 42
    .line 43
    if-nez v6, :cond_1

    .line 44
    .line 45
    invoke-static {v0}, Lgj;->X(Lhl1;)Lzh2;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    invoke-interface {v6}, Lzh2;->c()Lbi2;

    .line 50
    .line 51
    .line 52
    move-result-object v6

    .line 53
    iput-object v6, v1, Lvr1;->c:Lbi2;

    .line 54
    .line 55
    :cond_1
    move-object v9, v6

    .line 56
    move/from16 v6, p6

    .line 57
    .line 58
    int-to-long v6, v6

    .line 59
    const/16 v8, 0x20

    .line 60
    .line 61
    shl-long/2addr v6, v8

    .line 62
    move/from16 v8, p7

    .line 63
    .line 64
    int-to-long v10, v8

    .line 65
    const-wide v14, 0xffffffffL

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    and-long/2addr v10, v14

    .line 71
    or-long/2addr v6, v10

    .line 72
    invoke-static {v0}, Lgj;->Z(Lhl1;)Lja3;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    iget-object v0, v0, Lja3;->G:Lul1;

    .line 77
    .line 78
    new-instance v8, Lwr1;

    .line 79
    .line 80
    const/4 v10, 0x1

    .line 81
    invoke-direct {v8, v0, v3, v2, v10}, Lwr1;-><init>(Lul1;FLbi2;B)V

    .line 82
    .line 83
    .line 84
    move-object/from16 v0, p1

    .line 85
    .line 86
    invoke-interface {v0, v9, v6, v7, v8}, Lhs1;->c0(Lbi2;JLqa2;)V

    .line 87
    .line 88
    .line 89
    iget-object v2, v1, Lvr1;->k:Lbe;

    .line 90
    .line 91
    if-eqz v2, :cond_2

    .line 92
    .line 93
    iget v3, v1, Lvr1;->l:F

    .line 94
    .line 95
    cmpg-float v3, v3, v4

    .line 96
    .line 97
    if-eqz v3, :cond_3

    .line 98
    .line 99
    :cond_2
    const-string v2, "NoiseDither"

    .line 100
    .line 101
    const-string v3, "\n    uniform shader child;\n    uniform float noise_coeff;\n\n    half4 main(float2 xy) {\n        float3 d = float3(\n            dot(xy, float2(6.9898, 78.233)),\n            dot(xy, float2(7.9898, 78.233)),\n            dot(xy, float2(8.9898, 78.233))\n        );\n        float3 n = (fract(sin(d) * float3(43734.5453, 43745.5453, 43767.5453)) - 0.5) * noise_coeff;\n        half4 color = child.eval(xy);\n        color.rg += half2(n.x);\n        color.rb += half2(n.y);\n        color.gb += half2(n.z);\n        return color;\n    }\n"

    .line 102
    .line 103
    invoke-virtual {v5, v2, v3}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    iget-object v3, v2, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 111
    .line 112
    const-string v5, "noise_coeff"

    .line 113
    .line 114
    invoke-static {v3, v5, v4}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 115
    .line 116
    .line 117
    const-string v3, "child"

    .line 118
    .line 119
    invoke-static {v2, v3}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    iput-object v2, v1, Lvr1;->k:Lbe;

    .line 124
    .line 125
    iput v4, v1, Lvr1;->l:F

    .line 126
    .line 127
    :cond_3
    invoke-virtual {v9, v2}, Lbi2;->k(Lnm5;)V

    .line 128
    .line 129
    .line 130
    const/high16 v11, 0x3f800000    # 1.0f

    .line 131
    .line 132
    move/from16 v10, p5

    .line 133
    .line 134
    move-object v8, v0

    .line 135
    invoke-static/range {v8 .. v13}, Las1;->I1(Lhs1;Lbi2;FFFF)V

    .line 136
    .line 137
    .line 138
    const/4 v0, 0x0

    .line 139
    invoke-virtual {v9, v0}, Lbi2;->k(Lnm5;)V

    .line 140
    .line 141
    .line 142
    return-void

    .line 143
    :cond_4
    div-float v0, p5, v3

    .line 144
    .line 145
    move-object v1, v2

    .line 146
    move v4, v12

    .line 147
    move v5, v13

    .line 148
    move v2, v0

    .line 149
    move-object/from16 v0, p1

    .line 150
    .line 151
    invoke-static/range {v0 .. v5}, Las1;->I1(Lhs1;Lbi2;FFFF)V

    .line 152
    .line 153
    .line 154
    return-void
.end method

.method public final K1(Lhs1;Lvr1;)V
    .locals 4

    .line 1
    iget-object v0, p2, Lvr1;->e:Lzx4;

    .line 2
    .line 3
    invoke-virtual {v0}, Lzx4;->g()F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget p2, p2, Lvr1;->f:F

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    cmpg-float v2, v0, v1

    .line 11
    .line 12
    if-eqz v2, :cond_0

    .line 13
    .line 14
    div-float v1, v0, p2

    .line 15
    .line 16
    :cond_0
    invoke-interface {p1}, Lhs1;->U()Lh47;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v0, v0, Lh47;->j:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Lmj7;

    .line 23
    .line 24
    invoke-virtual {v0, v1, v1}, Lmj7;->F(FF)V

    .line 25
    .line 26
    .line 27
    :try_start_0
    iget-object v0, p0, Las1;->z:Lua2;

    .line 28
    .line 29
    new-instance v2, Le60;

    .line 30
    .line 31
    const/4 v3, 0x3

    .line 32
    invoke-direct {v2, p0, p2, v3}, Le60;-><init>(Ljava/lang/Object;FB)V

    .line 33
    .line 34
    .line 35
    invoke-interface {v0, p1, v2}, Lua2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    .line 37
    .line 38
    invoke-interface {p1}, Lhs1;->U()Lh47;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    iget-object p0, p0, Lh47;->j:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p0, Lmj7;

    .line 45
    .line 46
    neg-float p1, v1

    .line 47
    invoke-virtual {p0, p1, p1}, Lmj7;->F(FF)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :catchall_0
    move-exception p0

    .line 52
    invoke-interface {p1}, Lhs1;->U()Lh47;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    iget-object p1, p1, Lh47;->j:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast p1, Lmj7;

    .line 59
    .line 60
    neg-float p2, v1

    .line 61
    invoke-virtual {p1, p2, p2}, Lmj7;->F(FF)V

    .line 62
    .line 63
    .line 64
    throw p0
.end method

.method public final L1()V
    .locals 3

    .line 1
    iget-object v0, p0, Las1;->M:Lbi2;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p0}, Lgj;->X(Lhl1;)Lzh2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1, v0}, Lzh2;->a(Lbi2;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    const/4 v0, 0x0

    .line 13
    iput-object v0, p0, Las1;->M:Lbi2;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput-boolean v1, p0, Las1;->Q:Z

    .line 17
    .line 18
    iput-object v0, p0, Las1;->R:Lnm5;

    .line 19
    .line 20
    const/high16 v2, 0x7fc00000    # Float.NaN

    .line 21
    .line 22
    iput v2, p0, Las1;->S:F

    .line 23
    .line 24
    iput v2, p0, Las1;->T:F

    .line 25
    .line 26
    iput v2, p0, Las1;->U:F

    .line 27
    .line 28
    iput v2, p0, Las1;->V:F

    .line 29
    .line 30
    iput v2, p0, Las1;->W:F

    .line 31
    .line 32
    iput v2, p0, Las1;->X:F

    .line 33
    .line 34
    iput v2, p0, Las1;->Y:F

    .line 35
    .line 36
    iput-object v0, p0, Las1;->Z:Le75;

    .line 37
    .line 38
    iput-object v0, p0, Las1;->a0:Lnm5;

    .line 39
    .line 40
    iput-object v0, p0, Las1;->b0:Lnm5;

    .line 41
    .line 42
    iput-object v0, p0, Las1;->c0:Lr30;

    .line 43
    .line 44
    iput v2, p0, Las1;->d0:F

    .line 45
    .line 46
    iput-object v0, p0, Las1;->e0:Lbe;

    .line 47
    .line 48
    iput v2, p0, Las1;->f0:F

    .line 49
    .line 50
    iput-boolean v1, p0, Las1;->g0:Z

    .line 51
    .line 52
    iput-object v0, p0, Las1;->h0:Lnm5;

    .line 53
    .line 54
    iput-object v0, p0, Las1;->i0:Le75;

    .line 55
    .line 56
    iput v2, p0, Las1;->j0:F

    .line 57
    .line 58
    iput v2, p0, Las1;->k0:F

    .line 59
    .line 60
    iput v2, p0, Las1;->m0:F

    .line 61
    .line 62
    iput v2, p0, Las1;->n0:F

    .line 63
    .line 64
    const/4 v0, -0x1

    .line 65
    iput v0, p0, Las1;->o0:I

    .line 66
    .line 67
    const-wide/16 v0, 0x0

    .line 68
    .line 69
    iput-wide v0, p0, Las1;->p0:J

    .line 70
    .line 71
    iput-wide v0, p0, Las1;->q0:J

    .line 72
    .line 73
    return-void
.end method

.method public final M1()V
    .locals 8

    .line 1
    iget-object v0, p0, Las1;->H:Lvr1;

    .line 2
    .line 3
    iget-object v1, v0, Lvr1;->b:Ljava/util/ArrayList;

    .line 4
    .line 5
    iget-object v2, v0, Lvr1;->m:Las1;

    .line 6
    .line 7
    invoke-static {v2}, Lgj;->X(Lhl1;)Lzh2;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    iget-object v3, v0, Lvr1;->a:Lbi2;

    .line 12
    .line 13
    if-eqz v3, :cond_0

    .line 14
    .line 15
    invoke-interface {v2, v3}, Lzh2;->a(Lbi2;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    const/4 v3, 0x0

    .line 19
    iput-object v3, v0, Lvr1;->a:Lbi2;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 22
    .line 23
    .line 24
    move-result-object v4

    .line 25
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    if-eqz v5, :cond_1

    .line 30
    .line 31
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    check-cast v5, Lbi2;

    .line 36
    .line 37
    invoke-interface {v2, v5}, Lzh2;->a(Lbi2;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 42
    .line 43
    .line 44
    iget-object v1, v0, Lvr1;->c:Lbi2;

    .line 45
    .line 46
    if-eqz v1, :cond_2

    .line 47
    .line 48
    invoke-interface {v2, v1}, Lzh2;->a(Lbi2;)V

    .line 49
    .line 50
    .line 51
    :cond_2
    iput-object v3, v0, Lvr1;->c:Lbi2;

    .line 52
    .line 53
    iget-object v1, v0, Lvr1;->j:[Lnm5;

    .line 54
    .line 55
    array-length v2, v1

    .line 56
    const/4 v4, 0x0

    .line 57
    invoke-static {v1, v3, v4, v2}, Low;->p0([Ljava/lang/Object;Ljava/lang/String;II)V

    .line 58
    .line 59
    .line 60
    iget-object v1, v0, Lvr1;->g:[Ljava/lang/String;

    .line 61
    .line 62
    const-string v2, ""

    .line 63
    .line 64
    array-length v5, v1

    .line 65
    invoke-static {v1, v2, v4, v5}, Low;->p0([Ljava/lang/Object;Ljava/lang/String;II)V

    .line 66
    .line 67
    .line 68
    iget-object v1, v0, Lvr1;->h:[I

    .line 69
    .line 70
    array-length v2, v1

    .line 71
    const/4 v5, -0x1

    .line 72
    invoke-static {v1, v4, v2, v5}, Ljava/util/Arrays;->fill([IIII)V

    .line 73
    .line 74
    .line 75
    iget-object v1, v0, Lvr1;->i:[I

    .line 76
    .line 77
    array-length v2, v1

    .line 78
    invoke-static {v1, v4, v2, v5}, Ljava/util/Arrays;->fill([IIII)V

    .line 79
    .line 80
    .line 81
    iput-object v3, v0, Lvr1;->k:Lbe;

    .line 82
    .line 83
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 84
    .line 85
    iput v1, v0, Lvr1;->l:F

    .line 86
    .line 87
    invoke-virtual {p0}, Las1;->L1()V

    .line 88
    .line 89
    .line 90
    iget-object p0, p0, Las1;->G:Lyr1;

    .line 91
    .line 92
    const/high16 v0, 0x3f800000    # 1.0f

    .line 93
    .line 94
    iput v0, p0, Lyr1;->i:F

    .line 95
    .line 96
    iput v0, p0, Lyr1;->j:F

    .line 97
    .line 98
    const-wide v6, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    iput-wide v6, p0, Lyr1;->k:J

    .line 104
    .line 105
    sget-object v2, Ls93;->i:Ls93;

    .line 106
    .line 107
    iput-object v2, p0, Lyr1;->l:Ls93;

    .line 108
    .line 109
    const/4 v2, 0x0

    .line 110
    iput v2, p0, Lyr1;->m:F

    .line 111
    .line 112
    iput-object v3, p0, Lyr1;->n:Lnm5;

    .line 113
    .line 114
    iput v0, p0, Lyr1;->o:F

    .line 115
    .line 116
    iput v2, p0, Lyr1;->p:F

    .line 117
    .line 118
    iput v1, p0, Lyr1;->y:F

    .line 119
    .line 120
    iput v1, p0, Lyr1;->z:F

    .line 121
    .line 122
    iput v1, p0, Lyr1;->A:F

    .line 123
    .line 124
    iput v1, p0, Lyr1;->B:F

    .line 125
    .line 126
    iput v1, p0, Lyr1;->C:F

    .line 127
    .line 128
    iput v1, p0, Lyr1;->D:F

    .line 129
    .line 130
    const/high16 v0, -0x40800000    # -1.0f

    .line 131
    .line 132
    iput v0, p0, Lyr1;->E:F

    .line 133
    .line 134
    iput-object v3, p0, Lyr1;->F:Lnm5;

    .line 135
    .line 136
    iput-object v3, p0, Lyr1;->G:Lr30;

    .line 137
    .line 138
    iput-object v3, p0, Lyr1;->H:Lbe;

    .line 139
    .line 140
    iput v1, p0, Lyr1;->I:F

    .line 141
    .line 142
    iput v1, p0, Lyr1;->J:F

    .line 143
    .line 144
    iput v1, p0, Lyr1;->K:F

    .line 145
    .line 146
    iput-object v3, p0, Lyr1;->L:Lbe;

    .line 147
    .line 148
    iput v1, p0, Lyr1;->M:F

    .line 149
    .line 150
    iput v1, p0, Lyr1;->N:F

    .line 151
    .line 152
    iput v1, p0, Lyr1;->O:F

    .line 153
    .line 154
    iput v1, p0, Lyr1;->P:F

    .line 155
    .line 156
    iput v1, p0, Lyr1;->Q:F

    .line 157
    .line 158
    iput v1, p0, Lyr1;->R:F

    .line 159
    .line 160
    iput v1, p0, Lyr1;->S:F

    .line 161
    .line 162
    iput v5, p0, Lyr1;->T:I

    .line 163
    .line 164
    iput v1, p0, Lyr1;->U:F

    .line 165
    .line 166
    iput v1, p0, Lyr1;->V:F

    .line 167
    .line 168
    iput v1, p0, Lyr1;->W:F

    .line 169
    .line 170
    iput v1, p0, Lyr1;->X:F

    .line 171
    .line 172
    iput-object v3, p0, Lyr1;->Y:Lnm5;

    .line 173
    .line 174
    iput-boolean v4, p0, Lyr1;->Z:Z

    .line 175
    .line 176
    iput-object v3, p0, Lyr1;->a0:Lnm5;

    .line 177
    .line 178
    iput-object v3, p0, Lyr1;->b0:Lr30;

    .line 179
    .line 180
    iput-object v3, p0, Lyr1;->c0:Lf75;

    .line 181
    .line 182
    iput-object v3, p0, Lyr1;->d0:Lnm5;

    .line 183
    .line 184
    iput v1, p0, Lyr1;->e0:F

    .line 185
    .line 186
    iput-object v3, p0, Lyr1;->f0:Lnm5;

    .line 187
    .line 188
    return-void
.end method

.method public final O1()V
    .locals 52

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-boolean v1, v0, Las1;->E:Z

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v1, v0, Las1;->H:Lvr1;

    .line 9
    .line 10
    iget-object v2, v1, Lvr1;->a:Lbi2;

    .line 11
    .line 12
    if-nez v2, :cond_1

    .line 13
    .line 14
    iget-object v2, v1, Lvr1;->m:Las1;

    .line 15
    .line 16
    invoke-static {v2}, Lgj;->X(Lhl1;)Lzh2;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-interface {v2}, Lzh2;->c()Lbi2;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    iput-object v2, v1, Lvr1;->a:Lbi2;

    .line 25
    .line 26
    :cond_1
    iget-object v2, v0, Las1;->D:Le75;

    .line 27
    .line 28
    if-eqz v2, :cond_3

    .line 29
    .line 30
    iget-boolean v2, v0, Las1;->N:Z

    .line 31
    .line 32
    if-eqz v2, :cond_2

    .line 33
    .line 34
    iget-boolean v2, v0, Las1;->O:Z

    .line 35
    .line 36
    if-eqz v2, :cond_3

    .line 37
    .line 38
    :cond_2
    const/4 v2, 0x1

    .line 39
    goto :goto_0

    .line 40
    :cond_3
    const/4 v2, 0x0

    .line 41
    :goto_0
    iget-object v5, v0, Las1;->G:Lyr1;

    .line 42
    .line 43
    iput-boolean v2, v5, Lyr1;->Z:Z

    .line 44
    .line 45
    iget-object v2, v0, Las1;->x:Lqa2;

    .line 46
    .line 47
    invoke-virtual {v5, v2}, Lyr1;->d(Lqa2;)V

    .line 48
    .line 49
    .line 50
    iget-boolean v2, v5, Lyr1;->Z:Z

    .line 51
    .line 52
    if-eqz v2, :cond_54

    .line 53
    .line 54
    iget-object v2, v0, Las1;->D:Le75;

    .line 55
    .line 56
    iget v7, v5, Lyr1;->M:F

    .line 57
    .line 58
    iget v8, v5, Lyr1;->N:F

    .line 59
    .line 60
    if-eqz v2, :cond_53

    .line 61
    .line 62
    iget v9, v2, Le75;->c:F

    .line 63
    .line 64
    iget v10, v2, Le75;->b:F

    .line 65
    .line 66
    iget v11, v2, Le75;->a:F

    .line 67
    .line 68
    invoke-static {v7}, Ljava/lang/Float;->isNaN(F)Z

    .line 69
    .line 70
    .line 71
    move-result v12

    .line 72
    if-nez v12, :cond_53

    .line 73
    .line 74
    invoke-static {v8}, Ljava/lang/Float;->isNaN(F)Z

    .line 75
    .line 76
    .line 77
    move-result v12

    .line 78
    if-nez v12, :cond_53

    .line 79
    .line 80
    iget v12, v5, Lyr1;->O:F

    .line 81
    .line 82
    iget v13, v5, Lyr1;->P:F

    .line 83
    .line 84
    iget-object v14, v5, Lyr1;->a0:Lnm5;

    .line 85
    .line 86
    iget-object v15, v5, Lyr1;->n:Lnm5;

    .line 87
    .line 88
    iget-object v4, v5, Lyr1;->b0:Lr30;

    .line 89
    .line 90
    const/16 v22, 0x1

    .line 91
    .line 92
    if-eqz v4, :cond_4

    .line 93
    .line 94
    if-eqz v15, :cond_4

    .line 95
    .line 96
    invoke-static {v5, v4}, Lcj;->Q(Lyr1;Lr30;)Lnm5;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    invoke-static {v4, v15}, Ltc3;->E(Lnm5;Lnm5;)Lnm5;

    .line 101
    .line 102
    .line 103
    move-result-object v15

    .line 104
    const/4 v4, 0x0

    .line 105
    :cond_4
    const/16 v16, 0x0

    .line 106
    .line 107
    iget v3, v5, Lyr1;->p:F

    .line 108
    .line 109
    const/16 v17, 0x0

    .line 110
    .line 111
    cmpg-float v18, v3, v17

    .line 112
    .line 113
    if-gtz v18, :cond_5

    .line 114
    .line 115
    move/from16 v20, v3

    .line 116
    .line 117
    move/from16 v3, v17

    .line 118
    .line 119
    const/high16 v18, 0x40000000    # 2.0f

    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_5
    const/high16 v18, 0x40000000    # 2.0f

    .line 123
    .line 124
    iget v6, v5, Lyr1;->T:I

    .line 125
    .line 126
    if-lez v6, :cond_6

    .line 127
    .line 128
    mul-float v6, v3, v18

    .line 129
    .line 130
    move/from16 v20, v3

    .line 131
    .line 132
    const v3, 0x3c1374bc    # 0.009f

    .line 133
    .line 134
    .line 135
    invoke-static {v6, v3}, Ljava/lang/Math;->min(FF)F

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    goto :goto_1

    .line 140
    :cond_6
    move/from16 v20, v3

    .line 141
    .line 142
    :goto_1
    iget-object v6, v0, Las1;->R:Lnm5;

    .line 143
    .line 144
    move-object/from16 v23, v6

    .line 145
    .line 146
    const-string v6, "\n    uniform shader child;\n    uniform float2 in_gradAxis;\n    uniform float2 in_gradBand;\n    uniform float in_curve;\n    uniform float in_level;\n    uniform float in_slope;\n\n    half4 main(float2 xy) {\n        float p = dot(xy, in_gradAxis);\n        float raw = clamp((p - in_gradBand.x) / (in_gradBand.y - in_gradBand.x), 0.0, 1.0);\n        raw = pow(raw * raw * (3.0 - 2.0 * raw), in_curve);\n        float w = clamp(in_level - raw * in_slope, 0.0, 1.0);\n        w = w * w * (3.0 - 2.0 * w);\n        half4 c = child.eval(xy);\n        if (c.a > 0.0039) {\n            c = half4(c.rgb / c.a, 1.0);\n        }\n        return c * half(w);\n    }\n"

    .line 147
    .line 148
    move/from16 v25, v10

    .line 149
    .line 150
    const-string v10, "in_gradAxis"

    .line 151
    .line 152
    move-object/from16 v28, v1

    .line 153
    .line 154
    const-string v1, "in_gradBand"

    .line 155
    .line 156
    move/from16 v29, v13

    .line 157
    .line 158
    const-string v13, "in_curve"

    .line 159
    .line 160
    const-wide v30, 0x3f91df46a2529d39L    # 0.017453292519943295

    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    const v32, 0x3a83126f    # 0.001f

    .line 166
    .line 167
    .line 168
    move/from16 v33, v12

    .line 169
    .line 170
    const-string v12, "child"

    .line 171
    .line 172
    const-wide v34, 0xffffffffL

    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    const/16 v36, 0x20

    .line 178
    .line 179
    if-eqz v23, :cond_8

    .line 180
    .line 181
    move/from16 v23, v8

    .line 182
    .line 183
    iget v8, v0, Las1;->S:F

    .line 184
    .line 185
    cmpg-float v8, v8, v7

    .line 186
    .line 187
    if-nez v8, :cond_7

    .line 188
    .line 189
    iget v8, v0, Las1;->T:F

    .line 190
    .line 191
    cmpg-float v8, v8, v23

    .line 192
    .line 193
    if-nez v8, :cond_7

    .line 194
    .line 195
    iget v8, v0, Las1;->U:F

    .line 196
    .line 197
    cmpg-float v8, v8, v33

    .line 198
    .line 199
    if-nez v8, :cond_7

    .line 200
    .line 201
    iget v8, v0, Las1;->V:F

    .line 202
    .line 203
    cmpg-float v8, v8, v29

    .line 204
    .line 205
    if-nez v8, :cond_7

    .line 206
    .line 207
    iget v8, v0, Las1;->W:F

    .line 208
    .line 209
    move/from16 v37, v8

    .line 210
    .line 211
    iget v8, v5, Lyr1;->m:F

    .line 212
    .line 213
    cmpg-float v8, v37, v8

    .line 214
    .line 215
    if-nez v8, :cond_7

    .line 216
    .line 217
    iget v8, v0, Las1;->X:F

    .line 218
    .line 219
    move/from16 v37, v7

    .line 220
    .line 221
    move/from16 v38, v8

    .line 222
    .line 223
    iget-wide v7, v5, Lyr1;->k:J

    .line 224
    .line 225
    shr-long v7, v7, v36

    .line 226
    .line 227
    long-to-int v7, v7

    .line 228
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 229
    .line 230
    .line 231
    move-result v7

    .line 232
    cmpg-float v7, v38, v7

    .line 233
    .line 234
    if-nez v7, :cond_9

    .line 235
    .line 236
    iget v7, v0, Las1;->Y:F

    .line 237
    .line 238
    move/from16 v38, v7

    .line 239
    .line 240
    iget-wide v7, v5, Lyr1;->k:J

    .line 241
    .line 242
    and-long v7, v7, v34

    .line 243
    .line 244
    long-to-int v7, v7

    .line 245
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 246
    .line 247
    .line 248
    move-result v7

    .line 249
    cmpg-float v7, v38, v7

    .line 250
    .line 251
    if-nez v7, :cond_9

    .line 252
    .line 253
    iget-object v7, v0, Las1;->Z:Le75;

    .line 254
    .line 255
    invoke-static {v7, v2}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v7

    .line 259
    if-eqz v7, :cond_9

    .line 260
    .line 261
    iget-object v7, v0, Las1;->a0:Lnm5;

    .line 262
    .line 263
    if-ne v7, v14, :cond_9

    .line 264
    .line 265
    iget-object v7, v0, Las1;->b0:Lnm5;

    .line 266
    .line 267
    if-ne v7, v15, :cond_9

    .line 268
    .line 269
    iget-object v7, v0, Las1;->c0:Lr30;

    .line 270
    .line 271
    invoke-static {v7, v4}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    move-result v7

    .line 275
    if-eqz v7, :cond_9

    .line 276
    .line 277
    iget v7, v0, Las1;->d0:F

    .line 278
    .line 279
    cmpg-float v7, v7, v3

    .line 280
    .line 281
    if-nez v7, :cond_9

    .line 282
    .line 283
    iget-object v4, v0, Las1;->R:Lnm5;

    .line 284
    .line 285
    move-object/from16 v49, v6

    .line 286
    .line 287
    move/from16 v45, v9

    .line 288
    .line 289
    move/from16 v43, v11

    .line 290
    .line 291
    move/from16 v8, v23

    .line 292
    .line 293
    move/from16 v6, v37

    .line 294
    .line 295
    move-object v9, v2

    .line 296
    move v11, v3

    .line 297
    move-object v3, v13

    .line 298
    move-object v2, v1

    .line 299
    move-object v1, v4

    .line 300
    move-object v4, v0

    .line 301
    move-object v0, v12

    .line 302
    :goto_2
    move/from16 v7, v22

    .line 303
    .line 304
    goto/16 :goto_16

    .line 305
    .line 306
    :cond_7
    move/from16 v37, v7

    .line 307
    .line 308
    goto :goto_3

    .line 309
    :cond_8
    move/from16 v37, v7

    .line 310
    .line 311
    move/from16 v23, v8

    .line 312
    .line 313
    :cond_9
    :goto_3
    iget v7, v5, Lyr1;->T:I

    .line 314
    .line 315
    iget v8, v5, Lyr1;->m:F

    .line 316
    .line 317
    move/from16 v38, v7

    .line 318
    .line 319
    move/from16 v39, v8

    .line 320
    .line 321
    iget-wide v7, v5, Lyr1;->k:J

    .line 322
    .line 323
    shr-long v7, v7, v36

    .line 324
    .line 325
    long-to-int v7, v7

    .line 326
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 327
    .line 328
    .line 329
    move-result v7

    .line 330
    move/from16 v40, v7

    .line 331
    .line 332
    iget-wide v7, v5, Lyr1;->k:J

    .line 333
    .line 334
    and-long v7, v7, v34

    .line 335
    .line 336
    long-to-int v7, v7

    .line 337
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 338
    .line 339
    .line 340
    move-result v7

    .line 341
    sget-object v8, Lu30;->a:[[Ljava/lang/String;

    .line 342
    .line 343
    shl-int v8, v22, v38

    .line 344
    .line 345
    int-to-float v8, v8

    .line 346
    cmpg-float v41, v37, v17

    .line 347
    .line 348
    if-gez v41, :cond_a

    .line 349
    .line 350
    move/from16 v41, v17

    .line 351
    .line 352
    goto :goto_4

    .line 353
    :cond_a
    move/from16 v41, v37

    .line 354
    .line 355
    :goto_4
    const v42, 0x3ee66666    # 0.45f

    .line 356
    .line 357
    .line 358
    move/from16 v43, v7

    .line 359
    .line 360
    mul-float v7, v41, v42

    .line 361
    .line 362
    cmpg-float v41, v23, v17

    .line 363
    .line 364
    if-gez v41, :cond_b

    .line 365
    .line 366
    move/from16 v41, v17

    .line 367
    .line 368
    :goto_5
    move-object/from16 v44, v15

    .line 369
    .line 370
    goto :goto_6

    .line 371
    :cond_b
    move/from16 v41, v23

    .line 372
    .line 373
    goto :goto_5

    .line 374
    :goto_6
    mul-float v15, v41, v42

    .line 375
    .line 376
    move-object/from16 v41, v2

    .line 377
    .line 378
    move/from16 v42, v3

    .line 379
    .line 380
    float-to-double v2, v11

    .line 381
    mul-double v2, v2, v30

    .line 382
    .line 383
    move-wide/from16 v45, v2

    .line 384
    .line 385
    invoke-static/range {v45 .. v46}, Ljava/lang/Math;->cos(D)D

    .line 386
    .line 387
    .line 388
    move-result-wide v2

    .line 389
    double-to-float v2, v2

    .line 390
    move v3, v11

    .line 391
    move-object/from16 v47, v12

    .line 392
    .line 393
    invoke-static/range {v45 .. v46}, Ljava/lang/Math;->sin(D)D

    .line 394
    .line 395
    .line 396
    move-result-wide v11

    .line 397
    double-to-float v11, v11

    .line 398
    cmpl-float v12, v2, v17

    .line 399
    .line 400
    if-lez v12, :cond_c

    .line 401
    .line 402
    move/from16 v45, v17

    .line 403
    .line 404
    goto :goto_7

    .line 405
    :cond_c
    mul-float v45, v2, v40

    .line 406
    .line 407
    :goto_7
    cmpl-float v46, v11, v17

    .line 408
    .line 409
    if-lez v46, :cond_d

    .line 410
    .line 411
    move/from16 v48, v17

    .line 412
    .line 413
    goto :goto_8

    .line 414
    :cond_d
    mul-float v48, v11, v43

    .line 415
    .line 416
    :goto_8
    add-float v45, v45, v48

    .line 417
    .line 418
    if-lez v12, :cond_e

    .line 419
    .line 420
    mul-float v12, v2, v40

    .line 421
    .line 422
    goto :goto_9

    .line 423
    :cond_e
    move/from16 v12, v17

    .line 424
    .line 425
    :goto_9
    if-lez v46, :cond_f

    .line 426
    .line 427
    mul-float v40, v11, v43

    .line 428
    .line 429
    goto :goto_a

    .line 430
    :cond_f
    move/from16 v40, v17

    .line 431
    .line 432
    :goto_a
    add-float v12, v12, v40

    .line 433
    .line 434
    sub-float v12, v12, v45

    .line 435
    .line 436
    add-float v40, v2, v11

    .line 437
    .line 438
    mul-float v40, v40, v39

    .line 439
    .line 440
    mul-float v39, v17, v12

    .line 441
    .line 442
    add-float v39, v39, v45

    .line 443
    .line 444
    add-float v39, v39, v40

    .line 445
    .line 446
    move/from16 v43, v3

    .line 447
    .line 448
    div-float v3, v39, v8

    .line 449
    .line 450
    mul-float v12, v12, v25

    .line 451
    .line 452
    add-float v12, v12, v45

    .line 453
    .line 454
    add-float v12, v12, v40

    .line 455
    .line 456
    div-float/2addr v12, v8

    .line 457
    sub-float v39, v12, v3

    .line 458
    .line 459
    invoke-static/range {v39 .. v39}, Ljava/lang/Math;->abs(F)F

    .line 460
    .line 461
    .line 462
    move-result v39

    .line 463
    cmpg-float v39, v39, v32

    .line 464
    .line 465
    if-gez v39, :cond_10

    .line 466
    .line 467
    add-float v12, v3, v32

    .line 468
    .line 469
    :cond_10
    move-object/from16 v40, v4

    .line 470
    .line 471
    move-object/from16 v39, v14

    .line 472
    .line 473
    const v0, 0x3d4ccccd    # 0.05f

    .line 474
    .line 475
    .line 476
    const/high16 v14, 0x41a00000    # 20.0f

    .line 477
    .line 478
    invoke-static {v9, v0, v14}, Lhb3;->B(FFF)F

    .line 479
    .line 480
    .line 481
    move-result v4

    .line 482
    const/high16 v0, 0x3f800000    # 1.0f

    .line 483
    .line 484
    invoke-static {v8, v7, v0}, Lu30;->d(FFF)F

    .line 485
    .line 486
    .line 487
    move-result v14

    .line 488
    move/from16 v45, v9

    .line 489
    .line 490
    invoke-static {v8, v15, v0}, Lu30;->d(FFF)F

    .line 491
    .line 492
    .line 493
    move-result v9

    .line 494
    const v0, 0x3ecccccd    # 0.4f

    .line 495
    .line 496
    .line 497
    move/from16 v46, v9

    .line 498
    .line 499
    invoke-static {v8, v7, v0}, Lu30;->d(FFF)F

    .line 500
    .line 501
    .line 502
    move-result v9

    .line 503
    invoke-static {v8, v15, v0}, Lu30;->d(FFF)F

    .line 504
    .line 505
    .line 506
    move-result v0

    .line 507
    move/from16 v48, v14

    .line 508
    .line 509
    const v14, 0x3e051eb8    # 0.13f

    .line 510
    .line 511
    .line 512
    invoke-static {v8, v7, v14}, Lu30;->d(FFF)F

    .line 513
    .line 514
    .line 515
    move-result v7

    .line 516
    invoke-static {v8, v15, v14}, Lu30;->d(FFF)F

    .line 517
    .line 518
    .line 519
    move-result v8

    .line 520
    if-nez v38, :cond_11

    .line 521
    .line 522
    move/from16 v14, v22

    .line 523
    .line 524
    goto :goto_b

    .line 525
    :cond_11
    const/4 v14, 0x0

    .line 526
    :goto_b
    iget-object v15, v5, Lyr1;->c0:Lf75;

    .line 527
    .line 528
    if-nez v15, :cond_12

    .line 529
    .line 530
    move-object/from16 v15, v16

    .line 531
    .line 532
    :cond_12
    if-nez v15, :cond_13

    .line 533
    .line 534
    new-instance v15, Lf75;

    .line 535
    .line 536
    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    .line 537
    .line 538
    .line 539
    move/from16 v38, v14

    .line 540
    .line 541
    const/high16 v14, 0x7fc00000    # Float.NaN

    .line 542
    .line 543
    iput v14, v15, Lf75;->a:F

    .line 544
    .line 545
    iput v14, v15, Lf75;->b:F

    .line 546
    .line 547
    iput v14, v15, Lf75;->c:F

    .line 548
    .line 549
    iput v14, v15, Lf75;->d:F

    .line 550
    .line 551
    iput v14, v15, Lf75;->e:F

    .line 552
    .line 553
    iput-object v15, v5, Lyr1;->c0:Lf75;

    .line 554
    .line 555
    goto :goto_c

    .line 556
    :cond_13
    move/from16 v38, v14

    .line 557
    .line 558
    :goto_c
    iget v14, v15, Lf75;->a:F

    .line 559
    .line 560
    cmpg-float v14, v14, v2

    .line 561
    .line 562
    if-nez v14, :cond_14

    .line 563
    .line 564
    iget v14, v15, Lf75;->b:F

    .line 565
    .line 566
    cmpg-float v14, v14, v11

    .line 567
    .line 568
    if-nez v14, :cond_14

    .line 569
    .line 570
    iget v14, v15, Lf75;->c:F

    .line 571
    .line 572
    cmpg-float v14, v14, v3

    .line 573
    .line 574
    if-nez v14, :cond_14

    .line 575
    .line 576
    iget v14, v15, Lf75;->d:F

    .line 577
    .line 578
    cmpg-float v14, v14, v12

    .line 579
    .line 580
    if-nez v14, :cond_14

    .line 581
    .line 582
    iget v14, v15, Lf75;->e:F

    .line 583
    .line 584
    cmpg-float v14, v14, v4

    .line 585
    .line 586
    if-nez v14, :cond_14

    .line 587
    .line 588
    move-object/from16 v51, v1

    .line 589
    .line 590
    move-object/from16 v49, v6

    .line 591
    .line 592
    move-object/from16 v50, v13

    .line 593
    .line 594
    goto :goto_d

    .line 595
    :cond_14
    const-string v14, "ProgLevelMask"

    .line 596
    .line 597
    invoke-virtual {v5, v14, v6}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 598
    .line 599
    .line 600
    move-result-object v14

    .line 601
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 602
    .line 603
    .line 604
    move-object/from16 v49, v6

    .line 605
    .line 606
    iget-object v6, v14, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 607
    .line 608
    invoke-static {v6, v10, v2, v11}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 609
    .line 610
    .line 611
    iget-object v6, v14, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 612
    .line 613
    invoke-static {v6, v1, v3, v12}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 614
    .line 615
    .line 616
    iget-object v6, v14, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 617
    .line 618
    invoke-static {v6, v13, v4}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 619
    .line 620
    .line 621
    iget-object v6, v14, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 622
    .line 623
    move-object/from16 v50, v13

    .line 624
    .line 625
    const/high16 v13, 0x40400000    # 3.0f

    .line 626
    .line 627
    move-object/from16 v51, v1

    .line 628
    .line 629
    move/from16 v1, v18

    .line 630
    .line 631
    invoke-static {v14, v6, v1, v13}, Ltc3;->S(Lfe;Landroid/graphics/RuntimeShader;FF)Landroid/graphics/RenderEffect;

    .line 632
    .line 633
    .line 634
    move-result-object v1

    .line 635
    iput-object v1, v15, Lf75;->f:Landroid/graphics/RenderEffect;

    .line 636
    .line 637
    const/high16 v1, 0x3f800000    # 1.0f

    .line 638
    .line 639
    invoke-static {v14, v6, v1, v13}, Ltc3;->S(Lfe;Landroid/graphics/RuntimeShader;FF)Landroid/graphics/RenderEffect;

    .line 640
    .line 641
    .line 642
    move-result-object v13

    .line 643
    iput-object v13, v15, Lf75;->g:Landroid/graphics/RenderEffect;

    .line 644
    .line 645
    invoke-static {v14, v6, v1, v1}, Ltc3;->S(Lfe;Landroid/graphics/RuntimeShader;FF)Landroid/graphics/RenderEffect;

    .line 646
    .line 647
    .line 648
    move-result-object v13

    .line 649
    iput-object v13, v15, Lf75;->h:Landroid/graphics/RenderEffect;

    .line 650
    .line 651
    const/high16 v1, -0x3fc00000    # -3.0f

    .line 652
    .line 653
    const/high16 v13, -0x40000000    # -2.0f

    .line 654
    .line 655
    invoke-static {v14, v6, v13, v1}, Ltc3;->S(Lfe;Landroid/graphics/RuntimeShader;FF)Landroid/graphics/RenderEffect;

    .line 656
    .line 657
    .line 658
    move-result-object v6

    .line 659
    iput-object v6, v15, Lf75;->i:Landroid/graphics/RenderEffect;

    .line 660
    .line 661
    iput v2, v15, Lf75;->a:F

    .line 662
    .line 663
    iput v11, v15, Lf75;->b:F

    .line 664
    .line 665
    iput v3, v15, Lf75;->c:F

    .line 666
    .line 667
    iput v12, v15, Lf75;->d:F

    .line 668
    .line 669
    iput v4, v15, Lf75;->e:F

    .line 670
    .line 671
    :goto_d
    if-eqz v39, :cond_15

    .line 672
    .line 673
    invoke-virtual/range {v39 .. v39}, Lnm5;->a()Landroid/graphics/RenderEffect;

    .line 674
    .line 675
    .line 676
    move-result-object v1

    .line 677
    goto :goto_e

    .line 678
    :cond_15
    move-object/from16 v1, v16

    .line 679
    .line 680
    :goto_e
    invoke-static {v7, v8, v1}, Ltc3;->T(FFLandroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 681
    .line 682
    .line 683
    move-result-object v6

    .line 684
    if-nez v6, :cond_16

    .line 685
    .line 686
    invoke-static {}, Lp15;->d()Landroid/graphics/RenderEffect;

    .line 687
    .line 688
    .line 689
    move-result-object v6

    .line 690
    goto :goto_f

    .line 691
    :cond_16
    if-eq v6, v1, :cond_18

    .line 692
    .line 693
    iget-object v7, v15, Lf75;->j:Landroid/graphics/RenderEffect;

    .line 694
    .line 695
    if-nez v7, :cond_17

    .line 696
    .line 697
    const-string v7, "ProgUnpremul"

    .line 698
    .line 699
    const-string v8, "\n    uniform shader child;\n\n    half4 main(float2 xy) {\n        half4 c = child.eval(xy);\n        if (c.a > 0.0039) {\n            return half4(c.rgb / c.a, 1.0);\n        }\n        return c;\n    }\n"

    .line 700
    .line 701
    invoke-virtual {v5, v7, v8}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 702
    .line 703
    .line 704
    move-result-object v7

    .line 705
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 706
    .line 707
    .line 708
    iget-object v7, v7, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 709
    .line 710
    invoke-static {v7}, Lw13;->a(Landroid/graphics/RuntimeShader;)Landroid/graphics/RenderEffect;

    .line 711
    .line 712
    .line 713
    move-result-object v7

    .line 714
    iput-object v7, v15, Lf75;->j:Landroid/graphics/RenderEffect;

    .line 715
    .line 716
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 717
    .line 718
    .line 719
    :cond_17
    invoke-static {v7, v6}, Lp15;->h(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 720
    .line 721
    .line 722
    move-result-object v6

    .line 723
    :cond_18
    :goto_f
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 724
    .line 725
    .line 726
    iget-object v7, v15, Lf75;->f:Landroid/graphics/RenderEffect;

    .line 727
    .line 728
    if-eqz v7, :cond_52

    .line 729
    .line 730
    invoke-static {v9, v0, v1}, Ltc3;->T(FFLandroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 731
    .line 732
    .line 733
    move-result-object v0

    .line 734
    if-eqz v0, :cond_19

    .line 735
    .line 736
    invoke-static {v7, v0}, Lp15;->h(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 737
    .line 738
    .line 739
    move-result-object v7

    .line 740
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 741
    .line 742
    .line 743
    :cond_19
    sget-object v0, Landroid/graphics/BlendMode;->SRC_OVER:Landroid/graphics/BlendMode;

    .line 744
    .line 745
    invoke-static {v6, v7}, Lp15;->u(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 746
    .line 747
    .line 748
    move-result-object v0

    .line 749
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 750
    .line 751
    .line 752
    iget-object v6, v15, Lf75;->g:Landroid/graphics/RenderEffect;

    .line 753
    .line 754
    if-eqz v6, :cond_51

    .line 755
    .line 756
    move/from16 v8, v46

    .line 757
    .line 758
    move/from16 v7, v48

    .line 759
    .line 760
    invoke-static {v7, v8, v1}, Ltc3;->T(FFLandroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 761
    .line 762
    .line 763
    move-result-object v7

    .line 764
    if-eqz v7, :cond_1a

    .line 765
    .line 766
    invoke-static {v6, v7}, Lp15;->h(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 767
    .line 768
    .line 769
    move-result-object v6

    .line 770
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 771
    .line 772
    .line 773
    :cond_1a
    invoke-static {v0, v6}, Lp15;->u(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 774
    .line 775
    .line 776
    move-result-object v0

    .line 777
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 778
    .line 779
    .line 780
    if-eqz v38, :cond_1e

    .line 781
    .line 782
    iget-object v6, v15, Lf75;->i:Landroid/graphics/RenderEffect;

    .line 783
    .line 784
    const-string v7, "sharp"

    .line 785
    .line 786
    if-nez v1, :cond_1b

    .line 787
    .line 788
    if-nez v6, :cond_1c

    .line 789
    .line 790
    invoke-static {v7}, Lv23;->B(Ljava/lang/String;)V

    .line 791
    .line 792
    .line 793
    throw v16

    .line 794
    :cond_1b
    if-eqz v6, :cond_1d

    .line 795
    .line 796
    invoke-static {v6, v1}, Lp15;->w(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 797
    .line 798
    .line 799
    move-result-object v6

    .line 800
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 801
    .line 802
    .line 803
    :cond_1c
    invoke-static {v0, v6}, Lp15;->x(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 804
    .line 805
    .line 806
    move-result-object v0

    .line 807
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 808
    .line 809
    .line 810
    goto :goto_10

    .line 811
    :cond_1d
    invoke-static {v7}, Lv23;->B(Ljava/lang/String;)V

    .line 812
    .line 813
    .line 814
    throw v16

    .line 815
    :cond_1e
    :goto_10
    if-eqz v44, :cond_20

    .line 816
    .line 817
    iget-object v1, v15, Lf75;->h:Landroid/graphics/RenderEffect;

    .line 818
    .line 819
    if-eqz v1, :cond_1f

    .line 820
    .line 821
    invoke-virtual/range {v44 .. v44}, Lnm5;->a()Landroid/graphics/RenderEffect;

    .line 822
    .line 823
    .line 824
    move-result-object v6

    .line 825
    invoke-static {v6, v0}, Lp15;->h(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 826
    .line 827
    .line 828
    move-result-object v6

    .line 829
    invoke-static {v1, v6}, Lp15;->y(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 830
    .line 831
    .line 832
    move-result-object v1

    .line 833
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 834
    .line 835
    .line 836
    invoke-static {v0, v1}, Lp15;->x(Landroid/graphics/RenderEffect;Landroid/graphics/RenderEffect;)Landroid/graphics/RenderEffect;

    .line 837
    .line 838
    .line 839
    move-result-object v0

    .line 840
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 841
    .line 842
    .line 843
    goto :goto_11

    .line 844
    :cond_1f
    const-string v0, "ramp"

    .line 845
    .line 846
    invoke-static {v0}, Lv23;->B(Ljava/lang/String;)V

    .line 847
    .line 848
    .line 849
    throw v16

    .line 850
    :cond_20
    :goto_11
    new-instance v1, Lbe;

    .line 851
    .line 852
    invoke-direct {v1, v0}, Lbe;-><init>(Landroid/graphics/RenderEffect;)V

    .line 853
    .line 854
    .line 855
    if-eqz v40, :cond_22

    .line 856
    .line 857
    invoke-static/range {v40 .. v40}, Lcj;->P(Lr30;)Z

    .line 858
    .line 859
    .line 860
    move-result v0

    .line 861
    if-eqz v0, :cond_21

    .line 862
    .line 863
    sget-object v6, Lpb6;->i:Ljava/lang/String;

    .line 864
    .line 865
    const-string v7, "MiBlendModesExtRamp"

    .line 866
    .line 867
    goto :goto_12

    .line 868
    :cond_21
    sget-object v6, Lpb6;->h:Ljava/lang/String;

    .line 869
    .line 870
    const-string v7, "MiBlendModesStdRamp"

    .line 871
    .line 872
    :goto_12
    invoke-virtual {v5, v7, v6}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 873
    .line 874
    .line 875
    move-result-object v6

    .line 876
    move-object/from16 v7, v40

    .line 877
    .line 878
    invoke-static {v6, v5, v7, v0}, Lcj;->Y(Lfe;Lyr1;Lr30;Z)V

    .line 879
    .line 880
    .line 881
    iget-object v0, v6, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 882
    .line 883
    invoke-static {v0, v10, v2, v11}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 884
    .line 885
    .line 886
    iget-object v0, v6, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 887
    .line 888
    move-object/from16 v2, v51

    .line 889
    .line 890
    invoke-static {v0, v2, v3, v12}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 891
    .line 892
    .line 893
    iget-object v0, v6, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 894
    .line 895
    move-object/from16 v3, v50

    .line 896
    .line 897
    invoke-static {v0, v3, v4}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 898
    .line 899
    .line 900
    move-object/from16 v0, v47

    .line 901
    .line 902
    invoke-static {v6, v0}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 903
    .line 904
    .line 905
    move-result-object v4

    .line 906
    invoke-static {v1, v4}, Ltc3;->E(Lnm5;Lnm5;)Lnm5;

    .line 907
    .line 908
    .line 909
    move-result-object v1

    .line 910
    goto :goto_13

    .line 911
    :cond_22
    move-object/from16 v7, v40

    .line 912
    .line 913
    move-object/from16 v0, v47

    .line 914
    .line 915
    move-object/from16 v3, v50

    .line 916
    .line 917
    move-object/from16 v2, v51

    .line 918
    .line 919
    :goto_13
    cmpl-float v4, v42, v17

    .line 920
    .line 921
    if-lez v4, :cond_24

    .line 922
    .line 923
    move-object/from16 v4, p0

    .line 924
    .line 925
    iget-object v6, v4, Las1;->e0:Lbe;

    .line 926
    .line 927
    if-eqz v6, :cond_23

    .line 928
    .line 929
    iget v8, v4, Las1;->f0:F

    .line 930
    .line 931
    cmpg-float v8, v8, v42

    .line 932
    .line 933
    if-nez v8, :cond_23

    .line 934
    .line 935
    move/from16 v11, v42

    .line 936
    .line 937
    goto :goto_14

    .line 938
    :cond_23
    const-string v6, "NoiseDither"

    .line 939
    .line 940
    const-string v8, "\n    uniform shader child;\n    uniform float noise_coeff;\n\n    half4 main(float2 xy) {\n        float3 d = float3(\n            dot(xy, float2(6.9898, 78.233)),\n            dot(xy, float2(7.9898, 78.233)),\n            dot(xy, float2(8.9898, 78.233))\n        );\n        float3 n = (fract(sin(d) * float3(43734.5453, 43745.5453, 43767.5453)) - 0.5) * noise_coeff;\n        half4 color = child.eval(xy);\n        color.rg += half2(n.x);\n        color.rb += half2(n.y);\n        color.gb += half2(n.z);\n        return color;\n    }\n"

    .line 941
    .line 942
    invoke-virtual {v5, v6, v8}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 943
    .line 944
    .line 945
    move-result-object v6

    .line 946
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 947
    .line 948
    .line 949
    iget-object v8, v6, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 950
    .line 951
    const-string v9, "noise_coeff"

    .line 952
    .line 953
    move/from16 v11, v42

    .line 954
    .line 955
    invoke-static {v8, v9, v11}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 956
    .line 957
    .line 958
    invoke-static {v6, v0}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 959
    .line 960
    .line 961
    move-result-object v6

    .line 962
    iput-object v6, v4, Las1;->e0:Lbe;

    .line 963
    .line 964
    iput v11, v4, Las1;->f0:F

    .line 965
    .line 966
    :goto_14
    invoke-static {v1, v6}, Ltc3;->E(Lnm5;Lnm5;)Lnm5;

    .line 967
    .line 968
    .line 969
    move-result-object v1

    .line 970
    goto :goto_15

    .line 971
    :cond_24
    move-object/from16 v4, p0

    .line 972
    .line 973
    move/from16 v11, v42

    .line 974
    .line 975
    :goto_15
    iput-object v1, v4, Las1;->R:Lnm5;

    .line 976
    .line 977
    move/from16 v6, v37

    .line 978
    .line 979
    iput v6, v4, Las1;->S:F

    .line 980
    .line 981
    move/from16 v8, v23

    .line 982
    .line 983
    iput v8, v4, Las1;->T:F

    .line 984
    .line 985
    move/from16 v9, v33

    .line 986
    .line 987
    iput v9, v4, Las1;->U:F

    .line 988
    .line 989
    move/from16 v9, v29

    .line 990
    .line 991
    iput v9, v4, Las1;->V:F

    .line 992
    .line 993
    iget v9, v5, Lyr1;->m:F

    .line 994
    .line 995
    iput v9, v4, Las1;->W:F

    .line 996
    .line 997
    iget-wide v12, v5, Lyr1;->k:J

    .line 998
    .line 999
    shr-long v12, v12, v36

    .line 1000
    .line 1001
    long-to-int v9, v12

    .line 1002
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1003
    .line 1004
    .line 1005
    move-result v9

    .line 1006
    iput v9, v4, Las1;->X:F

    .line 1007
    .line 1008
    iget-wide v12, v5, Lyr1;->k:J

    .line 1009
    .line 1010
    and-long v12, v12, v34

    .line 1011
    .line 1012
    long-to-int v9, v12

    .line 1013
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1014
    .line 1015
    .line 1016
    move-result v9

    .line 1017
    iput v9, v4, Las1;->Y:F

    .line 1018
    .line 1019
    move-object/from16 v9, v41

    .line 1020
    .line 1021
    iput-object v9, v4, Las1;->Z:Le75;

    .line 1022
    .line 1023
    move-object/from16 v12, v39

    .line 1024
    .line 1025
    iput-object v12, v4, Las1;->a0:Lnm5;

    .line 1026
    .line 1027
    move-object/from16 v15, v44

    .line 1028
    .line 1029
    iput-object v15, v4, Las1;->b0:Lnm5;

    .line 1030
    .line 1031
    iput-object v7, v4, Las1;->c0:Lr30;

    .line 1032
    .line 1033
    iput v11, v4, Las1;->d0:F

    .line 1034
    .line 1035
    goto/16 :goto_2

    .line 1036
    .line 1037
    :goto_16
    iput-boolean v7, v4, Las1;->N:Z

    .line 1038
    .line 1039
    if-eqz v1, :cond_25

    .line 1040
    .line 1041
    const/4 v7, 0x1

    .line 1042
    goto :goto_17

    .line 1043
    :cond_25
    const/4 v7, 0x0

    .line 1044
    :goto_17
    iput-boolean v7, v4, Las1;->O:Z

    .line 1045
    .line 1046
    if-nez v1, :cond_26

    .line 1047
    .line 1048
    const/4 v7, 0x0

    .line 1049
    iput-boolean v7, v5, Lyr1;->Z:Z

    .line 1050
    .line 1051
    iget-object v0, v4, Las1;->x:Lqa2;

    .line 1052
    .line 1053
    invoke-virtual {v5, v0}, Lyr1;->d(Lqa2;)V

    .line 1054
    .line 1055
    .line 1056
    invoke-virtual {v4}, Las1;->H1()V

    .line 1057
    .line 1058
    .line 1059
    iput-boolean v7, v4, Las1;->Q:Z

    .line 1060
    .line 1061
    iput-boolean v7, v4, Las1;->g0:Z

    .line 1062
    .line 1063
    :goto_18
    const/high16 v22, 0x3f800000    # 1.0f

    .line 1064
    .line 1065
    goto/16 :goto_34

    .line 1066
    .line 1067
    :cond_26
    iput-object v1, v5, Lyr1;->n:Lnm5;

    .line 1068
    .line 1069
    cmpl-float v1, v11, v17

    .line 1070
    .line 1071
    if-lez v1, :cond_27

    .line 1072
    .line 1073
    const v1, 0x3ba3d70a    # 0.005f

    .line 1074
    .line 1075
    .line 1076
    cmpg-float v1, v20, v1

    .line 1077
    .line 1078
    if-gtz v1, :cond_27

    .line 1079
    .line 1080
    const/4 v1, 0x1

    .line 1081
    goto :goto_19

    .line 1082
    :cond_27
    const/4 v1, 0x0

    .line 1083
    :goto_19
    iput-boolean v1, v4, Las1;->g0:Z

    .line 1084
    .line 1085
    iget-wide v11, v5, Lyr1;->k:J

    .line 1086
    .line 1087
    shr-long v11, v11, v36

    .line 1088
    .line 1089
    long-to-int v1, v11

    .line 1090
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1091
    .line 1092
    .line 1093
    move-result v1

    .line 1094
    iget-wide v11, v5, Lyr1;->k:J

    .line 1095
    .line 1096
    and-long v11, v11, v34

    .line 1097
    .line 1098
    long-to-int v7, v11

    .line 1099
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1100
    .line 1101
    .line 1102
    move-result v7

    .line 1103
    iget v11, v5, Lyr1;->T:I

    .line 1104
    .line 1105
    if-nez v11, :cond_28

    .line 1106
    .line 1107
    const/4 v12, 0x0

    .line 1108
    iput-boolean v12, v4, Las1;->Q:Z

    .line 1109
    .line 1110
    goto :goto_18

    .line 1111
    :cond_28
    iget-object v12, v4, Las1;->i0:Le75;

    .line 1112
    .line 1113
    invoke-static {v12, v9}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1114
    .line 1115
    .line 1116
    move-result v12

    .line 1117
    if-eqz v12, :cond_29

    .line 1118
    .line 1119
    iget v12, v4, Las1;->j0:F

    .line 1120
    .line 1121
    cmpg-float v12, v12, v1

    .line 1122
    .line 1123
    if-nez v12, :cond_29

    .line 1124
    .line 1125
    iget v12, v4, Las1;->k0:F

    .line 1126
    .line 1127
    cmpg-float v12, v12, v7

    .line 1128
    .line 1129
    if-nez v12, :cond_29

    .line 1130
    .line 1131
    iget v12, v4, Las1;->l0:F

    .line 1132
    .line 1133
    iget v13, v5, Lyr1;->m:F

    .line 1134
    .line 1135
    cmpg-float v12, v12, v13

    .line 1136
    .line 1137
    if-nez v12, :cond_29

    .line 1138
    .line 1139
    iget v12, v4, Las1;->m0:F

    .line 1140
    .line 1141
    cmpg-float v12, v12, v6

    .line 1142
    .line 1143
    if-nez v12, :cond_29

    .line 1144
    .line 1145
    iget v12, v4, Las1;->n0:F

    .line 1146
    .line 1147
    cmpg-float v12, v12, v8

    .line 1148
    .line 1149
    if-nez v12, :cond_29

    .line 1150
    .line 1151
    iget v12, v4, Las1;->o0:I

    .line 1152
    .line 1153
    if-ne v12, v11, :cond_29

    .line 1154
    .line 1155
    const/high16 v22, 0x3f800000    # 1.0f

    .line 1156
    .line 1157
    const/16 v23, 0x1

    .line 1158
    .line 1159
    goto/16 :goto_32

    .line 1160
    .line 1161
    :cond_29
    invoke-static {v11, v6}, Lu30;->h(IF)F

    .line 1162
    .line 1163
    .line 1164
    move-result v12

    .line 1165
    invoke-static {v11, v8}, Lu30;->h(IF)F

    .line 1166
    .line 1167
    .line 1168
    move-result v13

    .line 1169
    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    .line 1170
    .line 1171
    .line 1172
    move-result v12

    .line 1173
    invoke-static {v12}, Lpb6;->c(F)I

    .line 1174
    .line 1175
    .line 1176
    move-result v12

    .line 1177
    const/16 v22, 0x1

    .line 1178
    .line 1179
    add-int/lit8 v12, v12, 0x1

    .line 1180
    .line 1181
    int-to-float v12, v12

    .line 1182
    move/from16 v13, v43

    .line 1183
    .line 1184
    float-to-double v13, v13

    .line 1185
    mul-double v13, v13, v30

    .line 1186
    .line 1187
    move v15, v12

    .line 1188
    move-wide/from16 v29, v13

    .line 1189
    .line 1190
    invoke-static/range {v29 .. v30}, Ljava/lang/Math;->cos(D)D

    .line 1191
    .line 1192
    .line 1193
    move-result-wide v12

    .line 1194
    double-to-float v12, v12

    .line 1195
    invoke-static/range {v29 .. v30}, Ljava/lang/Math;->sin(D)D

    .line 1196
    .line 1197
    .line 1198
    move-result-wide v13

    .line 1199
    double-to-float v13, v13

    .line 1200
    cmpl-float v14, v12, v17

    .line 1201
    .line 1202
    if-lez v14, :cond_2a

    .line 1203
    .line 1204
    move/from16 v18, v17

    .line 1205
    .line 1206
    goto :goto_1a

    .line 1207
    :cond_2a
    mul-float v18, v12, v1

    .line 1208
    .line 1209
    :goto_1a
    cmpl-float v20, v13, v17

    .line 1210
    .line 1211
    if-lez v20, :cond_2b

    .line 1212
    .line 1213
    move/from16 v23, v17

    .line 1214
    .line 1215
    goto :goto_1b

    .line 1216
    :cond_2b
    mul-float v23, v13, v7

    .line 1217
    .line 1218
    :goto_1b
    add-float v18, v18, v23

    .line 1219
    .line 1220
    if-lez v14, :cond_2c

    .line 1221
    .line 1222
    mul-float v14, v12, v1

    .line 1223
    .line 1224
    goto :goto_1c

    .line 1225
    :cond_2c
    move/from16 v14, v17

    .line 1226
    .line 1227
    :goto_1c
    if-lez v20, :cond_2d

    .line 1228
    .line 1229
    mul-float v20, v13, v7

    .line 1230
    .line 1231
    goto :goto_1d

    .line 1232
    :cond_2d
    move/from16 v20, v17

    .line 1233
    .line 1234
    :goto_1d
    add-float v14, v14, v20

    .line 1235
    .line 1236
    sub-float v14, v14, v18

    .line 1237
    .line 1238
    mul-float v20, v17, v14

    .line 1239
    .line 1240
    move-object/from16 v23, v5

    .line 1241
    .line 1242
    add-float v5, v20, v18

    .line 1243
    .line 1244
    mul-float v14, v14, v25

    .line 1245
    .line 1246
    add-float v14, v14, v18

    .line 1247
    .line 1248
    sub-float v18, v14, v5

    .line 1249
    .line 1250
    invoke-static/range {v18 .. v18}, Ljava/lang/Math;->abs(F)F

    .line 1251
    .line 1252
    .line 1253
    move-result v18

    .line 1254
    cmpg-float v18, v18, v32

    .line 1255
    .line 1256
    if-gez v18, :cond_2e

    .line 1257
    .line 1258
    add-float v14, v5, v32

    .line 1259
    .line 1260
    :cond_2e
    move/from16 v18, v7

    .line 1261
    .line 1262
    invoke-static/range {v45 .. v45}, Lu30;->i(F)F

    .line 1263
    .line 1264
    .line 1265
    move-result v7

    .line 1266
    invoke-static {v14, v5, v7, v5}, Lxk6;->c(FFFF)F

    .line 1267
    .line 1268
    .line 1269
    move-result v7

    .line 1270
    cmpl-float v5, v14, v5

    .line 1271
    .line 1272
    if-ltz v5, :cond_2f

    .line 1273
    .line 1274
    const/high16 v5, 0x3f800000    # 1.0f

    .line 1275
    .line 1276
    goto :goto_1e

    .line 1277
    :cond_2f
    const/high16 v5, -0x40800000    # -1.0f

    .line 1278
    .line 1279
    :goto_1e
    const/4 v14, 0x4

    .line 1280
    move/from16 v20, v5

    .line 1281
    .line 1282
    new-array v5, v14, [F

    .line 1283
    .line 1284
    const/16 v21, 0x0

    .line 1285
    .line 1286
    aput v17, v5, v21

    .line 1287
    .line 1288
    const/16 v22, 0x1

    .line 1289
    .line 1290
    aput v1, v5, v22

    .line 1291
    .line 1292
    const/16 v31, 0x2

    .line 1293
    .line 1294
    aput v1, v5, v31

    .line 1295
    .line 1296
    const/16 v33, 0x3

    .line 1297
    .line 1298
    aput v17, v5, v33

    .line 1299
    .line 1300
    move-object/from16 v37, v5

    .line 1301
    .line 1302
    new-array v5, v14, [F

    .line 1303
    .line 1304
    aput v17, v5, v21

    .line 1305
    .line 1306
    aput v17, v5, v22

    .line 1307
    .line 1308
    aput v18, v5, v31

    .line 1309
    .line 1310
    aput v18, v5, v33

    .line 1311
    .line 1312
    const/high16 v31, -0x800000    # Float.NEGATIVE_INFINITY

    .line 1313
    .line 1314
    const/high16 v33, 0x7f800000    # Float.POSITIVE_INFINITY

    .line 1315
    .line 1316
    move-object/from16 v38, v5

    .line 1317
    .line 1318
    move/from16 v39, v33

    .line 1319
    .line 1320
    move/from16 v40, v39

    .line 1321
    .line 1322
    const/4 v5, 0x0

    .line 1323
    move/from16 v33, v31

    .line 1324
    .line 1325
    :goto_1f
    if-ge v5, v14, :cond_3a

    .line 1326
    .line 1327
    add-int/lit8 v41, v5, 0x1

    .line 1328
    .line 1329
    and-int/lit8 v42, v41, 0x3

    .line 1330
    .line 1331
    aget v14, v37, v5

    .line 1332
    .line 1333
    mul-float v44, v14, v12

    .line 1334
    .line 1335
    aget v5, v38, v5

    .line 1336
    .line 1337
    mul-float v46, v5, v13

    .line 1338
    .line 1339
    add-float v46, v46, v44

    .line 1340
    .line 1341
    sub-float v46, v46, v7

    .line 1342
    .line 1343
    mul-float v46, v46, v20

    .line 1344
    .line 1345
    move/from16 v44, v7

    .line 1346
    .line 1347
    aget v7, v37, v42

    .line 1348
    .line 1349
    mul-float v47, v7, v12

    .line 1350
    .line 1351
    move-object/from16 v48, v9

    .line 1352
    .line 1353
    aget v9, v38, v42

    .line 1354
    .line 1355
    mul-float v42, v9, v13

    .line 1356
    .line 1357
    add-float v42, v42, v47

    .line 1358
    .line 1359
    sub-float v42, v42, v44

    .line 1360
    .line 1361
    mul-float v42, v42, v20

    .line 1362
    .line 1363
    cmpl-float v47, v46, v17

    .line 1364
    .line 1365
    if-ltz v47, :cond_33

    .line 1366
    .line 1367
    cmpg-float v47, v14, v39

    .line 1368
    .line 1369
    if-gez v47, :cond_30

    .line 1370
    .line 1371
    move/from16 v39, v14

    .line 1372
    .line 1373
    :cond_30
    cmpg-float v47, v5, v40

    .line 1374
    .line 1375
    if-gez v47, :cond_31

    .line 1376
    .line 1377
    move/from16 v40, v5

    .line 1378
    .line 1379
    :cond_31
    cmpl-float v47, v14, v31

    .line 1380
    .line 1381
    if-lez v47, :cond_32

    .line 1382
    .line 1383
    move/from16 v31, v14

    .line 1384
    .line 1385
    :cond_32
    cmpl-float v47, v5, v33

    .line 1386
    .line 1387
    if-lez v47, :cond_33

    .line 1388
    .line 1389
    move/from16 v33, v5

    .line 1390
    .line 1391
    :cond_33
    cmpg-float v47, v46, v17

    .line 1392
    .line 1393
    if-gez v47, :cond_34

    .line 1394
    .line 1395
    move/from16 v47, v12

    .line 1396
    .line 1397
    const/4 v12, 0x1

    .line 1398
    goto :goto_20

    .line 1399
    :cond_34
    move/from16 v47, v12

    .line 1400
    .line 1401
    const/4 v12, 0x0

    .line 1402
    :goto_20
    cmpg-float v50, v42, v17

    .line 1403
    .line 1404
    if-gez v50, :cond_35

    .line 1405
    .line 1406
    move/from16 v50, v13

    .line 1407
    .line 1408
    const/4 v13, 0x1

    .line 1409
    goto :goto_21

    .line 1410
    :cond_35
    move/from16 v50, v13

    .line 1411
    .line 1412
    const/4 v13, 0x0

    .line 1413
    :goto_21
    if-eq v12, v13, :cond_39

    .line 1414
    .line 1415
    sub-float v12, v46, v42

    .line 1416
    .line 1417
    div-float v12, v46, v12

    .line 1418
    .line 1419
    invoke-static {v7, v14, v12, v14}, Lxk6;->c(FFFF)F

    .line 1420
    .line 1421
    .line 1422
    move-result v7

    .line 1423
    invoke-static {v9, v5, v12, v5}, Lxk6;->c(FFFF)F

    .line 1424
    .line 1425
    .line 1426
    move-result v5

    .line 1427
    cmpg-float v9, v7, v39

    .line 1428
    .line 1429
    if-gez v9, :cond_36

    .line 1430
    .line 1431
    move/from16 v39, v7

    .line 1432
    .line 1433
    :cond_36
    cmpg-float v9, v5, v40

    .line 1434
    .line 1435
    if-gez v9, :cond_37

    .line 1436
    .line 1437
    move/from16 v40, v5

    .line 1438
    .line 1439
    :cond_37
    cmpl-float v9, v7, v31

    .line 1440
    .line 1441
    if-lez v9, :cond_38

    .line 1442
    .line 1443
    move/from16 v31, v7

    .line 1444
    .line 1445
    :cond_38
    cmpl-float v7, v5, v33

    .line 1446
    .line 1447
    if-lez v7, :cond_39

    .line 1448
    .line 1449
    move/from16 v33, v5

    .line 1450
    .line 1451
    :cond_39
    move/from16 v5, v41

    .line 1452
    .line 1453
    move/from16 v7, v44

    .line 1454
    .line 1455
    move/from16 v12, v47

    .line 1456
    .line 1457
    move-object/from16 v9, v48

    .line 1458
    .line 1459
    move/from16 v13, v50

    .line 1460
    .line 1461
    const/4 v14, 0x4

    .line 1462
    goto/16 :goto_1f

    .line 1463
    .line 1464
    :cond_3a
    move-object/from16 v48, v9

    .line 1465
    .line 1466
    cmpl-float v5, v39, v31

    .line 1467
    .line 1468
    if-gtz v5, :cond_3f

    .line 1469
    .line 1470
    cmpl-float v5, v40, v33

    .line 1471
    .line 1472
    if-gtz v5, :cond_3f

    .line 1473
    .line 1474
    new-instance v5, Lvk5;

    .line 1475
    .line 1476
    sub-float v39, v39, v15

    .line 1477
    .line 1478
    cmpg-float v7, v39, v17

    .line 1479
    .line 1480
    if-gez v7, :cond_3b

    .line 1481
    .line 1482
    move/from16 v7, v17

    .line 1483
    .line 1484
    goto :goto_22

    .line 1485
    :cond_3b
    move/from16 v7, v39

    .line 1486
    .line 1487
    :goto_22
    sub-float v40, v40, v15

    .line 1488
    .line 1489
    cmpg-float v9, v40, v17

    .line 1490
    .line 1491
    if-gez v9, :cond_3c

    .line 1492
    .line 1493
    move/from16 v9, v17

    .line 1494
    .line 1495
    goto :goto_23

    .line 1496
    :cond_3c
    move/from16 v9, v40

    .line 1497
    .line 1498
    :goto_23
    add-float v31, v31, v15

    .line 1499
    .line 1500
    cmpl-float v12, v31, v1

    .line 1501
    .line 1502
    if-lez v12, :cond_3d

    .line 1503
    .line 1504
    move v12, v1

    .line 1505
    goto :goto_24

    .line 1506
    :cond_3d
    move/from16 v12, v31

    .line 1507
    .line 1508
    :goto_24
    add-float v33, v33, v15

    .line 1509
    .line 1510
    cmpl-float v13, v33, v18

    .line 1511
    .line 1512
    if-lez v13, :cond_3e

    .line 1513
    .line 1514
    move/from16 v13, v18

    .line 1515
    .line 1516
    goto :goto_25

    .line 1517
    :cond_3e
    move/from16 v13, v33

    .line 1518
    .line 1519
    :goto_25
    invoke-direct {v5, v7, v9, v12, v13}, Lvk5;-><init>(FFFF)V

    .line 1520
    .line 1521
    .line 1522
    goto :goto_26

    .line 1523
    :cond_3f
    move-object/from16 v5, v16

    .line 1524
    .line 1525
    :goto_26
    if-eqz v5, :cond_4f

    .line 1526
    .line 1527
    iget v7, v5, Lvk5;->b:F

    .line 1528
    .line 1529
    iget v9, v5, Lvk5;->d:F

    .line 1530
    .line 1531
    iget v12, v5, Lvk5;->c:F

    .line 1532
    .line 1533
    iget v5, v5, Lvk5;->a:F

    .line 1534
    .line 1535
    sub-float v13, v12, v5

    .line 1536
    .line 1537
    const/high16 v19, 0x3f800000    # 1.0f

    .line 1538
    .line 1539
    cmpg-float v13, v13, v19

    .line 1540
    .line 1541
    if-ltz v13, :cond_4e

    .line 1542
    .line 1543
    sub-float v13, v9, v7

    .line 1544
    .line 1545
    cmpg-float v13, v13, v19

    .line 1546
    .line 1547
    if-gez v13, :cond_40

    .line 1548
    .line 1549
    move-object/from16 v0, v16

    .line 1550
    .line 1551
    move/from16 v7, v18

    .line 1552
    .line 1553
    move/from16 v22, v19

    .line 1554
    .line 1555
    move-object/from16 v5, v23

    .line 1556
    .line 1557
    move-object/from16 v9, v48

    .line 1558
    .line 1559
    const/16 v23, 0x1

    .line 1560
    .line 1561
    move/from16 v19, v8

    .line 1562
    .line 1563
    move/from16 v18, v11

    .line 1564
    .line 1565
    goto/16 :goto_30

    .line 1566
    .line 1567
    :cond_40
    float-to-double v13, v5

    .line 1568
    invoke-static {v13, v14}, Ljava/lang/Math;->floor(D)D

    .line 1569
    .line 1570
    .line 1571
    move-result-wide v13

    .line 1572
    double-to-float v5, v13

    .line 1573
    float-to-int v5, v5

    .line 1574
    float-to-double v13, v7

    .line 1575
    invoke-static {v13, v14}, Ljava/lang/Math;->floor(D)D

    .line 1576
    .line 1577
    .line 1578
    move-result-wide v13

    .line 1579
    double-to-float v7, v13

    .line 1580
    float-to-int v7, v7

    .line 1581
    int-to-long v13, v5

    .line 1582
    shl-long v13, v13, v36

    .line 1583
    .line 1584
    move-wide v15, v13

    .line 1585
    int-to-long v13, v7

    .line 1586
    and-long v13, v13, v34

    .line 1587
    .line 1588
    or-long/2addr v13, v15

    .line 1589
    iput-wide v13, v4, Las1;->p0:J

    .line 1590
    .line 1591
    float-to-double v12, v12

    .line 1592
    invoke-static {v12, v13}, Ljava/lang/Math;->ceil(D)D

    .line 1593
    .line 1594
    .line 1595
    move-result-wide v12

    .line 1596
    double-to-float v12, v12

    .line 1597
    float-to-int v12, v12

    .line 1598
    sub-int/2addr v12, v5

    .line 1599
    const/4 v13, 0x1

    .line 1600
    if-ge v12, v13, :cond_41

    .line 1601
    .line 1602
    move v12, v13

    .line 1603
    :cond_41
    float-to-double v14, v9

    .line 1604
    invoke-static {v14, v15}, Ljava/lang/Math;->ceil(D)D

    .line 1605
    .line 1606
    .line 1607
    move-result-wide v14

    .line 1608
    double-to-float v9, v14

    .line 1609
    float-to-int v9, v9

    .line 1610
    sub-int/2addr v9, v7

    .line 1611
    if-ge v9, v13, :cond_42

    .line 1612
    .line 1613
    move v9, v13

    .line 1614
    :cond_42
    int-to-long v14, v12

    .line 1615
    shl-long v14, v14, v36

    .line 1616
    .line 1617
    move-wide/from16 v37, v14

    .line 1618
    .line 1619
    int-to-long v13, v9

    .line 1620
    and-long v13, v13, v34

    .line 1621
    .line 1622
    or-long v14, v37, v13

    .line 1623
    .line 1624
    iput-wide v14, v4, Las1;->q0:J

    .line 1625
    .line 1626
    int-to-float v5, v5

    .line 1627
    int-to-float v7, v7

    .line 1628
    shr-long v12, v14, v36

    .line 1629
    .line 1630
    long-to-int v9, v12

    .line 1631
    int-to-float v9, v9

    .line 1632
    and-long v14, v14, v34

    .line 1633
    .line 1634
    long-to-int v12, v14

    .line 1635
    int-to-float v12, v12

    .line 1636
    invoke-static/range {v29 .. v30}, Ljava/lang/Math;->cos(D)D

    .line 1637
    .line 1638
    .line 1639
    move-result-wide v13

    .line 1640
    double-to-float v13, v13

    .line 1641
    invoke-static/range {v29 .. v30}, Ljava/lang/Math;->sin(D)D

    .line 1642
    .line 1643
    .line 1644
    move-result-wide v14

    .line 1645
    double-to-float v14, v14

    .line 1646
    cmpl-float v15, v13, v17

    .line 1647
    .line 1648
    if-lez v15, :cond_43

    .line 1649
    .line 1650
    move/from16 v16, v17

    .line 1651
    .line 1652
    goto :goto_27

    .line 1653
    :cond_43
    mul-float v16, v13, v1

    .line 1654
    .line 1655
    :goto_27
    cmpl-float v20, v14, v17

    .line 1656
    .line 1657
    if-lez v20, :cond_44

    .line 1658
    .line 1659
    move/from16 v29, v17

    .line 1660
    .line 1661
    goto :goto_28

    .line 1662
    :cond_44
    mul-float v29, v14, v18

    .line 1663
    .line 1664
    :goto_28
    add-float v16, v16, v29

    .line 1665
    .line 1666
    if-lez v15, :cond_45

    .line 1667
    .line 1668
    mul-float v15, v13, v1

    .line 1669
    .line 1670
    goto :goto_29

    .line 1671
    :cond_45
    move/from16 v15, v17

    .line 1672
    .line 1673
    :goto_29
    if-lez v20, :cond_46

    .line 1674
    .line 1675
    mul-float v20, v14, v18

    .line 1676
    .line 1677
    goto :goto_2a

    .line 1678
    :cond_46
    move/from16 v20, v17

    .line 1679
    .line 1680
    :goto_2a
    add-float v15, v15, v20

    .line 1681
    .line 1682
    sub-float v15, v15, v16

    .line 1683
    .line 1684
    mul-float v17, v17, v15

    .line 1685
    .line 1686
    add-float v17, v17, v16

    .line 1687
    .line 1688
    move/from16 v20, v9

    .line 1689
    .line 1690
    move v9, v14

    .line 1691
    new-instance v14, Lyk5;

    .line 1692
    .line 1693
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 1694
    .line 1695
    .line 1696
    mul-float v15, v15, v25

    .line 1697
    .line 1698
    add-float v15, v15, v16

    .line 1699
    .line 1700
    iput v15, v14, Lyk5;->i:F

    .line 1701
    .line 1702
    sub-float v15, v15, v17

    .line 1703
    .line 1704
    invoke-static {v15}, Ljava/lang/Math;->abs(F)F

    .line 1705
    .line 1706
    .line 1707
    move-result v15

    .line 1708
    cmpg-float v15, v15, v32

    .line 1709
    .line 1710
    if-gez v15, :cond_47

    .line 1711
    .line 1712
    add-float v15, v17, v32

    .line 1713
    .line 1714
    iput v15, v14, Lyk5;->i:F

    .line 1715
    .line 1716
    :cond_47
    mul-float/2addr v5, v13

    .line 1717
    mul-float/2addr v7, v9

    .line 1718
    add-float/2addr v7, v5

    .line 1719
    move/from16 v16, v7

    .line 1720
    .line 1721
    move/from16 v5, v45

    .line 1722
    .line 1723
    const v7, 0x3d4ccccd    # 0.05f

    .line 1724
    .line 1725
    .line 1726
    const/high16 v15, 0x41a00000    # 20.0f

    .line 1727
    .line 1728
    invoke-static {v5, v7, v15}, Lhb3;->B(FFF)F

    .line 1729
    .line 1730
    .line 1731
    move-result v15

    .line 1732
    invoke-static {v5}, Lu30;->i(F)F

    .line 1733
    .line 1734
    .line 1735
    move-result v5

    .line 1736
    iget v7, v14, Lyk5;->i:F

    .line 1737
    .line 1738
    sub-float v25, v7, v17

    .line 1739
    .line 1740
    mul-float v25, v25, v5

    .line 1741
    .line 1742
    add-float v25, v25, v17

    .line 1743
    .line 1744
    sub-float v25, v25, v16

    .line 1745
    .line 1746
    new-instance v5, Lyk5;

    .line 1747
    .line 1748
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 1749
    .line 1750
    .line 1751
    sub-float v7, v7, v16

    .line 1752
    .line 1753
    iput v7, v5, Lyk5;->i:F

    .line 1754
    .line 1755
    sub-float v7, v7, v25

    .line 1756
    .line 1757
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    .line 1758
    .line 1759
    .line 1760
    move-result v7

    .line 1761
    cmpg-float v7, v7, v32

    .line 1762
    .line 1763
    if-gez v7, :cond_48

    .line 1764
    .line 1765
    add-float v7, v25, v32

    .line 1766
    .line 1767
    iput v7, v5, Lyk5;->i:F

    .line 1768
    .line 1769
    :cond_48
    move v7, v12

    .line 1770
    move/from16 v12, v17

    .line 1771
    .line 1772
    invoke-static {v11, v6}, Lu30;->h(IF)F

    .line 1773
    .line 1774
    .line 1775
    move-result v17

    .line 1776
    invoke-static {v11, v8}, Lu30;->h(IF)F

    .line 1777
    .line 1778
    .line 1779
    move-result v26

    .line 1780
    const/high16 v27, 0x3f000000    # 0.5f

    .line 1781
    .line 1782
    cmpl-float v29, v17, v27

    .line 1783
    .line 1784
    if-ltz v29, :cond_49

    .line 1785
    .line 1786
    const/16 v29, 0x1

    .line 1787
    .line 1788
    goto :goto_2b

    .line 1789
    :cond_49
    const/16 v29, 0x0

    .line 1790
    .line 1791
    :goto_2b
    cmpl-float v27, v26, v27

    .line 1792
    .line 1793
    if-ltz v27, :cond_4a

    .line 1794
    .line 1795
    const/16 v27, 0x1

    .line 1796
    .line 1797
    goto :goto_2c

    .line 1798
    :cond_4a
    const/16 v27, 0x0

    .line 1799
    .line 1800
    :goto_2c
    if-eqz v29, :cond_4c

    .line 1801
    .line 1802
    if-eqz v27, :cond_4b

    .line 1803
    .line 1804
    move/from16 v0, v19

    .line 1805
    .line 1806
    const/16 v19, 0x0

    .line 1807
    .line 1808
    move/from16 v37, v6

    .line 1809
    .line 1810
    move/from16 v6, v20

    .line 1811
    .line 1812
    const/16 v20, 0x0

    .line 1813
    .line 1814
    move v2, v8

    .line 1815
    move v8, v13

    .line 1816
    move/from16 v13, v16

    .line 1817
    .line 1818
    const/16 v16, 0x0

    .line 1819
    .line 1820
    move/from16 v3, v18

    .line 1821
    .line 1822
    const/high16 v18, 0x3f800000    # 1.0f

    .line 1823
    .line 1824
    move/from16 v22, v0

    .line 1825
    .line 1826
    move/from16 v24, v11

    .line 1827
    .line 1828
    move/from16 v10, v25

    .line 1829
    .line 1830
    move-object v11, v5

    .line 1831
    move-object/from16 v5, v23

    .line 1832
    .line 1833
    const/16 v23, 0x1

    .line 1834
    .line 1835
    invoke-static/range {v5 .. v20}, Lu30;->c(Lyr1;FFFFFLyk5;FFLyk5;FIFFFZ)Lbe;

    .line 1836
    .line 1837
    .line 1838
    move-result-object v0

    .line 1839
    const/high16 v19, 0x3f800000    # 1.0f

    .line 1840
    .line 1841
    const/16 v20, 0x1

    .line 1842
    .line 1843
    const/16 v16, 0x1

    .line 1844
    .line 1845
    const/16 v18, 0x0

    .line 1846
    .line 1847
    move/from16 v17, v26

    .line 1848
    .line 1849
    invoke-static/range {v5 .. v20}, Lu30;->c(Lyr1;FFFFFLyk5;FFLyk5;FIFFFZ)Lbe;

    .line 1850
    .line 1851
    .line 1852
    move-result-object v6

    .line 1853
    invoke-static {v0, v6}, Ltc3;->E(Lnm5;Lnm5;)Lnm5;

    .line 1854
    .line 1855
    .line 1856
    move-result-object v0

    .line 1857
    :goto_2d
    move/from16 v19, v2

    .line 1858
    .line 1859
    move v7, v3

    .line 1860
    move/from16 v18, v24

    .line 1861
    .line 1862
    move/from16 v6, v37

    .line 1863
    .line 1864
    move-object/from16 v9, v48

    .line 1865
    .line 1866
    goto/16 :goto_2e

    .line 1867
    .line 1868
    :cond_4b
    move/from16 v37, v6

    .line 1869
    .line 1870
    move v2, v8

    .line 1871
    move/from16 v24, v11

    .line 1872
    .line 1873
    move v8, v13

    .line 1874
    move/from16 v13, v16

    .line 1875
    .line 1876
    move/from16 v3, v18

    .line 1877
    .line 1878
    move/from16 v22, v19

    .line 1879
    .line 1880
    move/from16 v6, v20

    .line 1881
    .line 1882
    move/from16 v10, v25

    .line 1883
    .line 1884
    move-object v11, v5

    .line 1885
    move-object/from16 v5, v23

    .line 1886
    .line 1887
    const/16 v23, 0x1

    .line 1888
    .line 1889
    const/16 v19, 0x0

    .line 1890
    .line 1891
    const/16 v20, 0x1

    .line 1892
    .line 1893
    const/16 v16, 0x0

    .line 1894
    .line 1895
    const/high16 v18, 0x3f800000    # 1.0f

    .line 1896
    .line 1897
    invoke-static/range {v5 .. v20}, Lu30;->c(Lyr1;FFFFFLyk5;FFLyk5;FIFFFZ)Lbe;

    .line 1898
    .line 1899
    .line 1900
    move-result-object v0

    .line 1901
    goto :goto_2d

    .line 1902
    :cond_4c
    move/from16 v37, v6

    .line 1903
    .line 1904
    move v6, v11

    .line 1905
    move/from16 v22, v19

    .line 1906
    .line 1907
    move/from16 v17, v26

    .line 1908
    .line 1909
    move v11, v9

    .line 1910
    move v9, v13

    .line 1911
    move/from16 v13, v16

    .line 1912
    .line 1913
    move-object/from16 v16, v5

    .line 1914
    .line 1915
    move-object/from16 v5, v23

    .line 1916
    .line 1917
    const/16 v23, 0x1

    .line 1918
    .line 1919
    if-eqz v27, :cond_4d

    .line 1920
    .line 1921
    const/high16 v19, 0x3f800000    # 1.0f

    .line 1922
    .line 1923
    move/from16 v24, v6

    .line 1924
    .line 1925
    move/from16 v6, v20

    .line 1926
    .line 1927
    const/16 v20, 0x1

    .line 1928
    .line 1929
    move v2, v8

    .line 1930
    move v8, v9

    .line 1931
    move v9, v11

    .line 1932
    move-object/from16 v11, v16

    .line 1933
    .line 1934
    const/16 v16, 0x1

    .line 1935
    .line 1936
    move/from16 v3, v18

    .line 1937
    .line 1938
    const/16 v18, 0x0

    .line 1939
    .line 1940
    move/from16 v10, v25

    .line 1941
    .line 1942
    invoke-static/range {v5 .. v20}, Lu30;->c(Lyr1;FFFFFLyk5;FFLyk5;FIFFFZ)Lbe;

    .line 1943
    .line 1944
    .line 1945
    move-result-object v0

    .line 1946
    goto :goto_2d

    .line 1947
    :cond_4d
    move/from16 v17, v12

    .line 1948
    .line 1949
    move/from16 v16, v13

    .line 1950
    .line 1951
    move/from16 v7, v18

    .line 1952
    .line 1953
    move/from16 v18, v6

    .line 1954
    .line 1955
    move v12, v9

    .line 1956
    move v13, v11

    .line 1957
    move/from16 v6, v37

    .line 1958
    .line 1959
    move-object/from16 v9, v48

    .line 1960
    .line 1961
    const-string v11, "ProgSharpRamp"

    .line 1962
    .line 1963
    move/from16 v19, v8

    .line 1964
    .line 1965
    move-object/from16 v8, v49

    .line 1966
    .line 1967
    invoke-virtual {v5, v11, v8}, Lyr1;->c(Ljava/lang/String;Ljava/lang/String;)Lfe;

    .line 1968
    .line 1969
    .line 1970
    move-result-object v8

    .line 1971
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1972
    .line 1973
    .line 1974
    iget-object v11, v8, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 1975
    .line 1976
    invoke-static {v11, v10, v12, v13}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 1977
    .line 1978
    .line 1979
    sub-float v10, v17, v16

    .line 1980
    .line 1981
    iget v11, v14, Lyk5;->i:F

    .line 1982
    .line 1983
    sub-float v11, v11, v16

    .line 1984
    .line 1985
    iget-object v12, v8, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 1986
    .line 1987
    invoke-static {v12, v2, v10, v11}, Lb5;->t(Landroid/graphics/RuntimeShader;Ljava/lang/String;FF)V

    .line 1988
    .line 1989
    .line 1990
    iget-object v2, v8, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 1991
    .line 1992
    invoke-static {v2, v3, v15}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 1993
    .line 1994
    .line 1995
    const-string v2, "in_level"

    .line 1996
    .line 1997
    iget-object v3, v8, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 1998
    .line 1999
    const/high16 v13, -0x40000000    # -2.0f

    .line 2000
    .line 2001
    invoke-static {v3, v2, v13}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 2002
    .line 2003
    .line 2004
    const-string v2, "in_slope"

    .line 2005
    .line 2006
    iget-object v3, v8, Lfe;->a:Landroid/graphics/RuntimeShader;

    .line 2007
    .line 2008
    const/high16 v10, -0x3fc00000    # -3.0f

    .line 2009
    .line 2010
    invoke-static {v3, v2, v10}, Lb5;->s(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    .line 2011
    .line 2012
    .line 2013
    invoke-static {v8, v0}, Ltc3;->b0(Lfe;Ljava/lang/String;)Lbe;

    .line 2014
    .line 2015
    .line 2016
    move-result-object v0

    .line 2017
    :goto_2e
    iput-object v0, v4, Las1;->h0:Lnm5;

    .line 2018
    .line 2019
    goto :goto_31

    .line 2020
    :cond_4e
    move/from16 v7, v18

    .line 2021
    .line 2022
    move/from16 v22, v19

    .line 2023
    .line 2024
    move-object/from16 v5, v23

    .line 2025
    .line 2026
    move-object/from16 v9, v48

    .line 2027
    .line 2028
    const/16 v23, 0x1

    .line 2029
    .line 2030
    move/from16 v19, v8

    .line 2031
    .line 2032
    :goto_2f
    move/from16 v18, v11

    .line 2033
    .line 2034
    move-object/from16 v0, v16

    .line 2035
    .line 2036
    goto :goto_30

    .line 2037
    :cond_4f
    move/from16 v19, v8

    .line 2038
    .line 2039
    move/from16 v7, v18

    .line 2040
    .line 2041
    move-object/from16 v5, v23

    .line 2042
    .line 2043
    move-object/from16 v9, v48

    .line 2044
    .line 2045
    const/high16 v22, 0x3f800000    # 1.0f

    .line 2046
    .line 2047
    const/16 v23, 0x1

    .line 2048
    .line 2049
    goto :goto_2f

    .line 2050
    :goto_30
    iput-object v0, v4, Las1;->h0:Lnm5;

    .line 2051
    .line 2052
    const-wide/16 v2, 0x0

    .line 2053
    .line 2054
    iput-wide v2, v4, Las1;->p0:J

    .line 2055
    .line 2056
    iput-wide v2, v4, Las1;->q0:J

    .line 2057
    .line 2058
    :goto_31
    iput-object v9, v4, Las1;->i0:Le75;

    .line 2059
    .line 2060
    iput v1, v4, Las1;->j0:F

    .line 2061
    .line 2062
    iput v7, v4, Las1;->k0:F

    .line 2063
    .line 2064
    iget v0, v5, Lyr1;->m:F

    .line 2065
    .line 2066
    iput v0, v4, Las1;->l0:F

    .line 2067
    .line 2068
    iput v6, v4, Las1;->m0:F

    .line 2069
    .line 2070
    move/from16 v2, v19

    .line 2071
    .line 2072
    iput v2, v4, Las1;->n0:F

    .line 2073
    .line 2074
    move/from16 v6, v18

    .line 2075
    .line 2076
    iput v6, v4, Las1;->o0:I

    .line 2077
    .line 2078
    :goto_32
    iget-object v0, v4, Las1;->h0:Lnm5;

    .line 2079
    .line 2080
    if-eqz v0, :cond_50

    .line 2081
    .line 2082
    move/from16 v3, v23

    .line 2083
    .line 2084
    goto :goto_33

    .line 2085
    :cond_50
    const/4 v3, 0x0

    .line 2086
    :goto_33
    iput-boolean v3, v4, Las1;->Q:Z

    .line 2087
    .line 2088
    goto :goto_34

    .line 2089
    :cond_51
    const-string v0, "level1"

    .line 2090
    .line 2091
    invoke-static {v0}, Lv23;->B(Ljava/lang/String;)V

    .line 2092
    .line 2093
    .line 2094
    const/16 v16, 0x0

    .line 2095
    .line 2096
    throw v16

    .line 2097
    :cond_52
    const-string v0, "level2"

    .line 2098
    .line 2099
    invoke-static {v0}, Lv23;->B(Ljava/lang/String;)V

    .line 2100
    .line 2101
    .line 2102
    throw v16

    .line 2103
    :cond_53
    move-object v4, v0

    .line 2104
    move-object/from16 v28, v1

    .line 2105
    .line 2106
    const/high16 v22, 0x3f800000    # 1.0f

    .line 2107
    .line 2108
    invoke-virtual {v4}, Las1;->H1()V

    .line 2109
    .line 2110
    .line 2111
    const/4 v7, 0x0

    .line 2112
    iput-boolean v7, v4, Las1;->Q:Z

    .line 2113
    .line 2114
    iput-boolean v7, v4, Las1;->g0:Z

    .line 2115
    .line 2116
    :goto_34
    move-object/from16 v0, v28

    .line 2117
    .line 2118
    goto :goto_35

    .line 2119
    :cond_54
    move-object v4, v0

    .line 2120
    move-object/from16 v28, v1

    .line 2121
    .line 2122
    const/4 v7, 0x0

    .line 2123
    const/high16 v22, 0x3f800000    # 1.0f

    .line 2124
    .line 2125
    invoke-virtual {v4}, Las1;->H1()V

    .line 2126
    .line 2127
    .line 2128
    iput-boolean v7, v4, Las1;->Q:Z

    .line 2129
    .line 2130
    iput-boolean v7, v4, Las1;->g0:Z

    .line 2131
    .line 2132
    goto :goto_34

    .line 2133
    :goto_35
    iget-object v1, v0, Lvr1;->a:Lbi2;

    .line 2134
    .line 2135
    if-eqz v1, :cond_55

    .line 2136
    .line 2137
    iget-object v2, v5, Lyr1;->n:Lnm5;

    .line 2138
    .line 2139
    invoke-virtual {v1, v2}, Lbi2;->k(Lnm5;)V

    .line 2140
    .line 2141
    .line 2142
    :cond_55
    iget v1, v5, Lyr1;->m:F

    .line 2143
    .line 2144
    iget-object v2, v0, Lvr1;->e:Lzx4;

    .line 2145
    .line 2146
    invoke-virtual {v2, v1}, Lzx4;->h(F)V

    .line 2147
    .line 2148
    .line 2149
    iget v6, v5, Lyr1;->o:F

    .line 2150
    .line 2151
    cmpg-float v1, v6, v22

    .line 2152
    .line 2153
    if-gez v1, :cond_56

    .line 2154
    .line 2155
    move/from16 v6, v22

    .line 2156
    .line 2157
    :cond_56
    iput v6, v0, Lvr1;->d:F

    .line 2158
    .line 2159
    return-void
.end method

.method public final g0()V
    .locals 2

    .line 1
    new-instance v0, Lkd;

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    invoke-direct {v0, p0, v1}, Lkd;-><init>(Ljava/lang/Object;B)V

    .line 6
    .line 7
    .line 8
    invoke-static {p0, v0}, Ltc3;->P(Lh14;Lfa2;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final i(Lks3;Lds3;J)Ljs3;
    .locals 2

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-interface {p2, p3, p4}, Lds3;->e(J)Lb15;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    iget p3, p2, Lb15;->i:I

    .line 9
    .line 10
    iget p4, p2, Lb15;->j:I

    .line 11
    .line 12
    new-instance v0, Lk2;

    .line 13
    .line 14
    const/16 v1, 0x18

    .line 15
    .line 16
    invoke-direct {v0, p0, p2, v1}, Lk2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 17
    .line 18
    .line 19
    sget-object p0, Lly1;->i:Lly1;

    .line 20
    .line 21
    invoke-interface {p1, p3, p4, p0, v0}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0
.end method

.method public final l0(Lla3;)V
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v13, v1, Lla3;->i:Llj0;

    .line 6
    .line 7
    iget-object v14, v13, Llj0;->j:Lh47;

    .line 8
    .line 9
    iget-boolean v2, v0, Las1;->E:Z

    .line 10
    .line 11
    if-nez v2, :cond_0

    .line 12
    .line 13
    invoke-virtual {v1}, Lla3;->c()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_0
    iget-object v2, v0, Las1;->G:Lyr1;

    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-virtual {v13}, Llj0;->a()F

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    invoke-virtual {v13}, Llj0;->x()F

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    invoke-interface {v13}, Lhs1;->b()J

    .line 31
    .line 32
    .line 33
    move-result-wide v5

    .line 34
    invoke-virtual {v1}, Lla3;->getLayoutDirection()Ls93;

    .line 35
    .line 36
    .line 37
    move-result-object v7

    .line 38
    iget v8, v2, Lyr1;->i:F

    .line 39
    .line 40
    cmpg-float v8, v3, v8

    .line 41
    .line 42
    if-nez v8, :cond_1

    .line 43
    .line 44
    iget v8, v2, Lyr1;->j:F

    .line 45
    .line 46
    cmpg-float v8, v4, v8

    .line 47
    .line 48
    if-nez v8, :cond_1

    .line 49
    .line 50
    iget-wide v8, v2, Lyr1;->k:J

    .line 51
    .line 52
    invoke-static {v5, v6, v8, v9}, Lwg6;->a(JJ)Z

    .line 53
    .line 54
    .line 55
    move-result v8

    .line 56
    if-eqz v8, :cond_1

    .line 57
    .line 58
    iget-object v8, v2, Lyr1;->l:Ls93;

    .line 59
    .line 60
    if-eq v7, v8, :cond_3

    .line 61
    .line 62
    :cond_1
    iput v3, v2, Lyr1;->i:F

    .line 63
    .line 64
    iput v4, v2, Lyr1;->j:F

    .line 65
    .line 66
    iput-wide v5, v2, Lyr1;->k:J

    .line 67
    .line 68
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    iput-object v7, v2, Lyr1;->l:Ls93;

    .line 72
    .line 73
    iget-boolean v2, v0, Las1;->P:Z

    .line 74
    .line 75
    if-eqz v2, :cond_2

    .line 76
    .line 77
    invoke-virtual {v0}, Las1;->O1()V

    .line 78
    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_2
    new-instance v2, Lkd;

    .line 82
    .line 83
    const/16 v3, 0x17

    .line 84
    .line 85
    invoke-direct {v2, v0, v3}, Lkd;-><init>(Ljava/lang/Object;B)V

    .line 86
    .line 87
    .line 88
    invoke-static {v0, v2}, Ltc3;->P(Lh14;Lfa2;)V

    .line 89
    .line 90
    .line 91
    :cond_3
    :goto_0
    iget-object v2, v0, Las1;->H:Lvr1;

    .line 92
    .line 93
    iget-object v3, v2, Lvr1;->a:Lbi2;

    .line 94
    .line 95
    const/4 v15, 0x0

    .line 96
    const/16 v16, 0x20

    .line 97
    .line 98
    const-wide v17, 0xffffffffL

    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    if-nez v3, :cond_4

    .line 104
    .line 105
    :goto_1
    move-object/from16 v22, v13

    .line 106
    .line 107
    move-object/from16 v23, v14

    .line 108
    .line 109
    goto/16 :goto_b

    .line 110
    .line 111
    :cond_4
    iget-object v4, v2, Lvr1;->e:Lzx4;

    .line 112
    .line 113
    invoke-virtual {v4}, Lzx4;->g()F

    .line 114
    .line 115
    .line 116
    move-result v5

    .line 117
    iget v4, v2, Lvr1;->d:F

    .line 118
    .line 119
    invoke-interface {v13}, Lhs1;->b()J

    .line 120
    .line 121
    .line 122
    move-result-wide v6

    .line 123
    shr-long v6, v6, v16

    .line 124
    .line 125
    long-to-int v6, v6

    .line 126
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 127
    .line 128
    .line 129
    move-result v6

    .line 130
    const/high16 v7, 0x40000000    # 2.0f

    .line 131
    .line 132
    mul-float v8, v5, v7

    .line 133
    .line 134
    add-float/2addr v6, v8

    .line 135
    float-to-int v6, v6

    .line 136
    invoke-interface {v13}, Lhs1;->b()J

    .line 137
    .line 138
    .line 139
    move-result-wide v9

    .line 140
    and-long v9, v9, v17

    .line 141
    .line 142
    long-to-int v9, v9

    .line 143
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 144
    .line 145
    .line 146
    move-result v9

    .line 147
    add-float/2addr v9, v8

    .line 148
    float-to-int v8, v9

    .line 149
    iget-object v9, v2, Lvr1;->b:Ljava/util/ArrayList;

    .line 150
    .line 151
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 152
    .line 153
    .line 154
    move-result v10

    .line 155
    const/4 v11, 0x0

    .line 156
    move v12, v11

    .line 157
    :goto_2
    if-ge v12, v10, :cond_5

    .line 158
    .line 159
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v19

    .line 163
    move-object/from16 v7, v19

    .line 164
    .line 165
    check-cast v7, Lbi2;

    .line 166
    .line 167
    invoke-virtual {v7, v15}, Lbi2;->k(Lnm5;)V

    .line 168
    .line 169
    .line 170
    add-int/lit8 v12, v12, 0x1

    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_5
    const v7, 0x3f8020c5    # 1.001f

    .line 174
    .line 175
    .line 176
    cmpg-float v7, v4, v7

    .line 177
    .line 178
    if-gtz v7, :cond_6

    .line 179
    .line 180
    const/high16 v4, 0x3f800000    # 1.0f

    .line 181
    .line 182
    iput v4, v2, Lvr1;->f:F

    .line 183
    .line 184
    int-to-long v6, v6

    .line 185
    shl-long v6, v6, v16

    .line 186
    .line 187
    int-to-long v8, v8

    .line 188
    and-long v8, v8, v17

    .line 189
    .line 190
    or-long/2addr v6, v8

    .line 191
    invoke-static {v0}, Lgj;->Z(Lhl1;)Lja3;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    iget-object v4, v4, Lja3;->G:Lul1;

    .line 196
    .line 197
    new-instance v8, Lzr1;

    .line 198
    .line 199
    invoke-direct {v8, v4, v0, v2, v11}, Lzr1;-><init>(Lul1;Las1;Lvr1;B)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v1, v3, v6, v7, v8}, Lla3;->c0(Lbi2;JLqa2;)V

    .line 203
    .line 204
    .line 205
    move-object v2, v3

    .line 206
    move v3, v5

    .line 207
    const/4 v5, 0x0

    .line 208
    const/4 v6, 0x0

    .line 209
    const/high16 v4, 0x3f800000    # 1.0f

    .line 210
    .line 211
    invoke-static/range {v1 .. v6}, Las1;->I1(Lhs1;Lbi2;FFFF)V

    .line 212
    .line 213
    .line 214
    goto :goto_1

    .line 215
    :cond_6
    const v7, 0x40001062    # 2.001f

    .line 216
    .line 217
    .line 218
    cmpg-float v7, v4, v7

    .line 219
    .line 220
    if-gtz v7, :cond_7

    .line 221
    .line 222
    iput v4, v2, Lvr1;->f:F

    .line 223
    .line 224
    invoke-static {v4, v6, v8}, Las1;->N1(FII)J

    .line 225
    .line 226
    .line 227
    move-result-wide v9

    .line 228
    invoke-static {v0}, Lgj;->Z(Lhl1;)Lja3;

    .line 229
    .line 230
    .line 231
    move-result-object v7

    .line 232
    iget-object v7, v7, Lja3;->G:Lul1;

    .line 233
    .line 234
    new-instance v11, Lzr1;

    .line 235
    .line 236
    const/4 v12, 0x1

    .line 237
    invoke-direct {v11, v7, v0, v2, v12}, Lzr1;-><init>(Lul1;Las1;Lvr1;B)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v1, v3, v9, v10, v11}, Lla3;->c0(Lbi2;JLqa2;)V

    .line 241
    .line 242
    .line 243
    move v7, v8

    .line 244
    invoke-virtual/range {v0 .. v7}, Las1;->J1(Lhs1;Lvr1;Lbi2;FFII)V

    .line 245
    .line 246
    .line 247
    goto/16 :goto_1

    .line 248
    .line 249
    :cond_7
    move-object/from16 v19, v3

    .line 250
    .line 251
    move/from16 v20, v5

    .line 252
    .line 253
    move v3, v8

    .line 254
    move-object v5, v2

    .line 255
    move v2, v6

    .line 256
    const/high16 v6, 0x40000000    # 2.0f

    .line 257
    .line 258
    iput v6, v5, Lvr1;->f:F

    .line 259
    .line 260
    invoke-virtual {v5, v11}, Lvr1;->a(I)Lbi2;

    .line 261
    .line 262
    .line 263
    move-result-object v7

    .line 264
    invoke-static {v6, v2, v3}, Las1;->N1(FII)J

    .line 265
    .line 266
    .line 267
    move-result-wide v8

    .line 268
    invoke-static {v0}, Lgj;->Z(Lhl1;)Lja3;

    .line 269
    .line 270
    .line 271
    move-result-object v10

    .line 272
    iget-object v10, v10, Lja3;->G:Lul1;

    .line 273
    .line 274
    new-instance v12, Lzr1;

    .line 275
    .line 276
    const/4 v6, 0x2

    .line 277
    invoke-direct {v12, v10, v0, v5, v6}, Lzr1;-><init>(Lul1;Las1;Lvr1;B)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v1, v7, v8, v9, v12}, Lla3;->c0(Lbi2;JLqa2;)V

    .line 281
    .line 282
    .line 283
    const/high16 v6, 0x40000000    # 2.0f

    .line 284
    .line 285
    :goto_3
    const/high16 v10, 0x40800000    # 4.0f

    .line 286
    .line 287
    mul-float/2addr v10, v6

    .line 288
    const v21, 0x3a83126f    # 0.001f

    .line 289
    .line 290
    .line 291
    add-float v12, v4, v21

    .line 292
    .line 293
    cmpg-float v22, v10, v12

    .line 294
    .line 295
    if-gtz v22, :cond_9

    .line 296
    .line 297
    sub-float v6, v10, v4

    .line 298
    .line 299
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 300
    .line 301
    .line 302
    move-result v6

    .line 303
    cmpg-float v6, v6, v21

    .line 304
    .line 305
    if-gez v6, :cond_8

    .line 306
    .line 307
    move-object/from16 v6, v19

    .line 308
    .line 309
    :goto_4
    move-wide/from16 v21, v8

    .line 310
    .line 311
    goto :goto_5

    .line 312
    :cond_8
    add-int/lit8 v6, v11, 0x1

    .line 313
    .line 314
    invoke-virtual {v5, v6}, Lvr1;->a(I)Lbi2;

    .line 315
    .line 316
    .line 317
    move-result-object v6

    .line 318
    goto :goto_4

    .line 319
    :goto_5
    invoke-static {v10, v2, v3}, Las1;->N1(FII)J

    .line 320
    .line 321
    .line 322
    move-result-wide v8

    .line 323
    move v12, v3

    .line 324
    move v3, v11

    .line 325
    const-string v11, "Downsample4x"

    .line 326
    .line 327
    move/from16 v23, v12

    .line 328
    .line 329
    const-string v12, "\n    uniform shader child;\n    uniform float2 maxCoord;\n    half4 main(float2 xy) {\n        half4 color = half4(0);\n        for (int y = 0; y < 4; y++) {\n            for (int x = 0; x < 4; x++) {\n                float2 offset = float2(float(x), float(y)) - 1.5;\n                color += child.eval(clamp(xy + offset, float2(0.5), maxCoord));\n            }\n        }\n        return color * 0.0625;\n    }\n"

    .line 330
    .line 331
    move/from16 v24, v10

    .line 332
    .line 333
    const/high16 v10, 0x3e800000    # 0.25f

    .line 334
    .line 335
    move/from16 v15, v23

    .line 336
    .line 337
    move-object/from16 v23, v14

    .line 338
    .line 339
    move v14, v15

    .line 340
    move v15, v4

    .line 341
    move-object v4, v7

    .line 342
    move-object v7, v6

    .line 343
    move-object/from16 v26, v13

    .line 344
    .line 345
    move v13, v2

    .line 346
    move-object v2, v5

    .line 347
    move-wide/from16 v5, v21

    .line 348
    .line 349
    move-object/from16 v22, v26

    .line 350
    .line 351
    invoke-virtual/range {v0 .. v12}, Las1;->G1(Lhs1;Lvr1;ILbi2;JLbi2;JFLjava/lang/String;Ljava/lang/String;)V

    .line 352
    .line 353
    .line 354
    add-int/lit8 v11, v3, 0x1

    .line 355
    .line 356
    move-object/from16 v0, p0

    .line 357
    .line 358
    move-object/from16 v1, p1

    .line 359
    .line 360
    move-object v5, v2

    .line 361
    move v2, v13

    .line 362
    move v3, v14

    .line 363
    move v4, v15

    .line 364
    move-object/from16 v13, v22

    .line 365
    .line 366
    move-object/from16 v14, v23

    .line 367
    .line 368
    move/from16 v6, v24

    .line 369
    .line 370
    goto :goto_3

    .line 371
    :cond_9
    move v15, v4

    .line 372
    move/from16 v24, v6

    .line 373
    .line 374
    move-object v4, v7

    .line 375
    move-object/from16 v22, v13

    .line 376
    .line 377
    move-object/from16 v23, v14

    .line 378
    .line 379
    const/high16 v25, 0x40000000    # 2.0f

    .line 380
    .line 381
    move v13, v2

    .line 382
    move v14, v3

    .line 383
    move-object v2, v5

    .line 384
    move-wide v5, v8

    .line 385
    move v3, v11

    .line 386
    mul-float v0, v24, v25

    .line 387
    .line 388
    cmpg-float v1, v0, v12

    .line 389
    .line 390
    if-gtz v1, :cond_b

    .line 391
    .line 392
    sub-float v1, v0, v15

    .line 393
    .line 394
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    cmpg-float v1, v1, v21

    .line 399
    .line 400
    if-gez v1, :cond_a

    .line 401
    .line 402
    move-object/from16 v7, v19

    .line 403
    .line 404
    goto :goto_6

    .line 405
    :cond_a
    add-int/lit8 v11, v3, 0x1

    .line 406
    .line 407
    invoke-virtual {v2, v11}, Lvr1;->a(I)Lbi2;

    .line 408
    .line 409
    .line 410
    move-result-object v1

    .line 411
    move-object v7, v1

    .line 412
    :goto_6
    invoke-static {v0, v13, v14}, Las1;->N1(FII)J

    .line 413
    .line 414
    .line 415
    move-result-wide v8

    .line 416
    const-string v11, "Downsample2x"

    .line 417
    .line 418
    const-string v12, "\n    uniform shader child;\n    uniform float2 maxCoord;\n    half4 main(float2 xy) {\n        float2 minCoord = float2(0.5);\n        half4 color = half4(0);\n        color += child.eval(clamp(xy + float2(-0.25, -0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2( 0.25, -0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2(-0.25,  0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2( 0.25,  0.25), minCoord, maxCoord));\n        return color * 0.25;\n    }\n"

    .line 419
    .line 420
    const/high16 v10, 0x3f000000    # 0.5f

    .line 421
    .line 422
    move-object/from16 v1, p1

    .line 423
    .line 424
    move/from16 v24, v0

    .line 425
    .line 426
    move-object/from16 v0, p0

    .line 427
    .line 428
    invoke-virtual/range {v0 .. v12}, Las1;->G1(Lhs1;Lvr1;ILbi2;JLbi2;JFLjava/lang/String;Ljava/lang/String;)V

    .line 429
    .line 430
    .line 431
    add-int/lit8 v11, v3, 0x1

    .line 432
    .line 433
    move-object v4, v7

    .line 434
    move v3, v11

    .line 435
    :goto_7
    move/from16 v6, v24

    .line 436
    .line 437
    goto :goto_8

    .line 438
    :cond_b
    move-wide v8, v5

    .line 439
    goto :goto_7

    .line 440
    :goto_8
    sub-float v0, v6, v15

    .line 441
    .line 442
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 443
    .line 444
    .line 445
    move-result v0

    .line 446
    cmpl-float v0, v0, v21

    .line 447
    .line 448
    if-lez v0, :cond_c

    .line 449
    .line 450
    move/from16 v24, v6

    .line 451
    .line 452
    move-wide v5, v8

    .line 453
    invoke-static {v15, v13, v14}, Las1;->N1(FII)J

    .line 454
    .line 455
    .line 456
    move-result-wide v8

    .line 457
    div-float v10, v24, v15

    .line 458
    .line 459
    const-string v11, "Downsample2x"

    .line 460
    .line 461
    const-string v12, "\n    uniform shader child;\n    uniform float2 maxCoord;\n    half4 main(float2 xy) {\n        float2 minCoord = float2(0.5);\n        half4 color = half4(0);\n        color += child.eval(clamp(xy + float2(-0.25, -0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2( 0.25, -0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2(-0.25,  0.25), minCoord, maxCoord));\n        color += child.eval(clamp(xy + float2( 0.25,  0.25), minCoord, maxCoord));\n        return color * 0.25;\n    }\n"

    .line 462
    .line 463
    move-object/from16 v0, p0

    .line 464
    .line 465
    move-object/from16 v1, p1

    .line 466
    .line 467
    move-object/from16 v7, v19

    .line 468
    .line 469
    invoke-virtual/range {v0 .. v12}, Las1;->G1(Lhs1;Lvr1;ILbi2;JLbi2;JFLjava/lang/String;Ljava/lang/String;)V

    .line 470
    .line 471
    .line 472
    move-object v3, v7

    .line 473
    :goto_9
    move v6, v13

    .line 474
    move v7, v14

    .line 475
    move v4, v15

    .line 476
    move/from16 v5, v20

    .line 477
    .line 478
    goto :goto_a

    .line 479
    :cond_c
    move-object/from16 v3, v19

    .line 480
    .line 481
    move-object/from16 v0, p0

    .line 482
    .line 483
    move-object/from16 v1, p1

    .line 484
    .line 485
    goto :goto_9

    .line 486
    :goto_a
    invoke-virtual/range {v0 .. v7}, Las1;->J1(Lhs1;Lvr1;Lbi2;FFII)V

    .line 487
    .line 488
    .line 489
    :goto_b
    iget-boolean v2, v0, Las1;->Q:Z

    .line 490
    .line 491
    if-eqz v2, :cond_e

    .line 492
    .line 493
    iget-wide v2, v0, Las1;->q0:J

    .line 494
    .line 495
    shr-long v4, v2, v16

    .line 496
    .line 497
    long-to-int v4, v4

    .line 498
    if-lez v4, :cond_e

    .line 499
    .line 500
    and-long v4, v2, v17

    .line 501
    .line 502
    long-to-int v4, v4

    .line 503
    if-lez v4, :cond_e

    .line 504
    .line 505
    iget-wide v4, v0, Las1;->p0:J

    .line 506
    .line 507
    iget-object v6, v0, Las1;->M:Lbi2;

    .line 508
    .line 509
    if-nez v6, :cond_d

    .line 510
    .line 511
    invoke-static {v0}, Lgj;->X(Lhl1;)Lzh2;

    .line 512
    .line 513
    .line 514
    move-result-object v6

    .line 515
    invoke-interface {v6}, Lzh2;->c()Lbi2;

    .line 516
    .line 517
    .line 518
    move-result-object v6

    .line 519
    iput-object v6, v0, Las1;->M:Lbi2;

    .line 520
    .line 521
    :cond_d
    invoke-static {v0}, Lgj;->Z(Lhl1;)Lja3;

    .line 522
    .line 523
    .line 524
    move-result-object v7

    .line 525
    iget-object v7, v7, Lja3;->G:Lul1;

    .line 526
    .line 527
    new-instance v8, Lxr1;

    .line 528
    .line 529
    invoke-direct {v8, v7, v4, v5, v0}, Lxr1;-><init>(Lul1;JLas1;)V

    .line 530
    .line 531
    .line 532
    invoke-virtual {v1, v6, v2, v3, v8}, Lla3;->c0(Lbi2;JLqa2;)V

    .line 533
    .line 534
    .line 535
    iget-object v2, v0, Las1;->h0:Lnm5;

    .line 536
    .line 537
    invoke-virtual {v6, v2}, Lbi2;->k(Lnm5;)V

    .line 538
    .line 539
    .line 540
    invoke-virtual {v6, v4, v5}, Lbi2;->m(J)V

    .line 541
    .line 542
    .line 543
    invoke-static {v1, v6}, Lfj;->w(Lhs1;Lbi2;)V

    .line 544
    .line 545
    .line 546
    :cond_e
    iget-object v2, v0, Las1;->A:Lqa2;

    .line 547
    .line 548
    if-eqz v2, :cond_f

    .line 549
    .line 550
    invoke-interface {v2, v1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 551
    .line 552
    .line 553
    :cond_f
    iget v2, v0, Las1;->C:I

    .line 554
    .line 555
    const/4 v3, 0x3

    .line 556
    if-ne v2, v3, :cond_10

    .line 557
    .line 558
    invoke-virtual {v1}, Lla3;->c()V

    .line 559
    .line 560
    .line 561
    goto :goto_d

    .line 562
    :cond_10
    invoke-interface/range {v22 .. v22}, Lhs1;->b()J

    .line 563
    .line 564
    .line 565
    move-result-wide v2

    .line 566
    shr-long v2, v2, v16

    .line 567
    .line 568
    long-to-int v2, v2

    .line 569
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 570
    .line 571
    .line 572
    move-result v2

    .line 573
    invoke-interface/range {v22 .. v22}, Lhs1;->b()J

    .line 574
    .line 575
    .line 576
    move-result-wide v3

    .line 577
    and-long v3, v3, v17

    .line 578
    .line 579
    long-to-int v3, v3

    .line 580
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 581
    .line 582
    .line 583
    move-result v3

    .line 584
    iget-object v4, v0, Las1;->L:Lvk5;

    .line 585
    .line 586
    if-eqz v4, :cond_12

    .line 587
    .line 588
    iget v5, v4, Lvk5;->c:F

    .line 589
    .line 590
    cmpg-float v5, v5, v2

    .line 591
    .line 592
    if-nez v5, :cond_11

    .line 593
    .line 594
    iget v5, v4, Lvk5;->d:F

    .line 595
    .line 596
    cmpg-float v5, v5, v3

    .line 597
    .line 598
    if-nez v5, :cond_11

    .line 599
    .line 600
    move-object v15, v4

    .line 601
    goto :goto_c

    .line 602
    :cond_11
    const/4 v15, 0x0

    .line 603
    :goto_c
    if-nez v15, :cond_13

    .line 604
    .line 605
    :cond_12
    new-instance v15, Lvk5;

    .line 606
    .line 607
    const/4 v4, 0x0

    .line 608
    invoke-direct {v15, v4, v4, v2, v3}, Lvk5;-><init>(FFFF)V

    .line 609
    .line 610
    .line 611
    iput-object v15, v0, Las1;->L:Lvk5;

    .line 612
    .line 613
    :cond_13
    iget v2, v0, Las1;->C:I

    .line 614
    .line 615
    iget-object v3, v0, Las1;->K:Lwp4;

    .line 616
    .line 617
    invoke-virtual {v3, v2}, Lwp4;->o(I)V

    .line 618
    .line 619
    .line 620
    invoke-virtual/range {v23 .. v23}, Lh47;->t()Ljj0;

    .line 621
    .line 622
    .line 623
    move-result-object v2

    .line 624
    invoke-interface {v2, v15, v3}, Ljj0;->f(Lvk5;Lwp4;)V

    .line 625
    .line 626
    .line 627
    invoke-virtual {v1}, Lla3;->c()V

    .line 628
    .line 629
    .line 630
    invoke-virtual/range {v23 .. v23}, Lh47;->t()Ljj0;

    .line 631
    .line 632
    .line 633
    move-result-object v2

    .line 634
    invoke-interface {v2}, Ljj0;->j()V

    .line 635
    .line 636
    .line 637
    :goto_d
    iget-object v0, v0, Las1;->B:Lqa2;

    .line 638
    .line 639
    if-eqz v0, :cond_14

    .line 640
    .line 641
    invoke-interface {v0, v1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    :cond_14
    return-void
.end method

.method public final v1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final y1()V
    .locals 2

    .line 1
    sget-object v0, Ly06;->a:Lyt1;

    .line 2
    .line 3
    invoke-static {p0, v0}, Lin;->x(Lz21;Lm75;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lx06;

    .line 8
    .line 9
    iget-object v1, p0, Las1;->G:Lyr1;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iput-object v0, v1, Lyr1;->q:Lx06;

    .line 18
    .line 19
    iget-boolean v0, p0, Las1;->E:Z

    .line 20
    .line 21
    if-eqz v0, :cond_1

    .line 22
    .line 23
    iget-object v0, p0, Las1;->H:Lvr1;

    .line 24
    .line 25
    iget-object v1, v0, Lvr1;->a:Lbi2;

    .line 26
    .line 27
    if-nez v1, :cond_0

    .line 28
    .line 29
    iget-object v1, v0, Lvr1;->m:Las1;

    .line 30
    .line 31
    invoke-static {v1}, Lgj;->X(Lhl1;)Lzh2;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-interface {v1}, Lzh2;->c()Lbi2;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    iput-object v1, v0, Lvr1;->a:Lbi2;

    .line 40
    .line 41
    :cond_0
    new-instance v0, Lkd;

    .line 42
    .line 43
    const/16 v1, 0x17

    .line 44
    .line 45
    invoke-direct {v0, p0, v1}, Lkd;-><init>(Ljava/lang/Object;B)V

    .line 46
    .line 47
    .line 48
    invoke-static {p0, v0}, Ltc3;->P(Lh14;Lfa2;)V

    .line 49
    .line 50
    .line 51
    :cond_1
    return-void
.end method

.method public final z1()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Las1;->M1()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iget-object v1, p0, Las1;->J:Ldy4;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, Las1;->P:Z

    .line 12
    .line 13
    return-void
.end method
