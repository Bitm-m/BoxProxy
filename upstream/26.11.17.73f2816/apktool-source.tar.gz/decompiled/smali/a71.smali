.class public final synthetic La71;
.super Lfb2;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic j:B


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V
    .locals 0

    .line 1
    iput-byte p7, p0, La71;->j:B

    .line 2
    .line 3
    invoke-direct/range {p0 .. p6}, Lfb2;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte v0, p0, La71;->j:B

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    const/4 v2, 0x3

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x1

    .line 7
    const/4 v5, 0x0

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    sget-object v0, Lcv4;->k:Lcv4;

    .line 12
    .line 13
    check-cast p1, Lfm4;

    .line 14
    .line 15
    iget-wide v7, p1, Lfm4;->a:J

    .line 16
    .line 17
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lcw4;

    .line 20
    .line 21
    iget-object p1, p0, Lcw4;->A:Ldv4;

    .line 22
    .line 23
    iget-object v1, p1, Ldv4;->i:Ldq4;

    .line 24
    .line 25
    sget-object v2, Ldq4;->j:Ldq4;

    .line 26
    .line 27
    if-eq v1, v2, :cond_2

    .line 28
    .line 29
    invoke-static {p0}, Lgj;->Y(Lhl1;)Lij4;

    .line 30
    .line 31
    .line 32
    move-result-object v6

    .line 33
    new-instance v9, Lxk5;

    .line 34
    .line 35
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    iget-object p1, p1, Ldv4;->i:Ldq4;

    .line 39
    .line 40
    sget-object v1, Ldq4;->i:Ldq4;

    .line 41
    .line 42
    if-ne p1, v1, :cond_0

    .line 43
    .line 44
    move v3, v4

    .line 45
    :cond_0
    iput-boolean v3, v9, Lxk5;->i:Z

    .line 46
    .line 47
    new-instance v10, Lxk5;

    .line 48
    .line 49
    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    .line 50
    .line 51
    .line 52
    sget-object p1, Lyy1;->D:Ljava/lang/Object;

    .line 53
    .line 54
    new-instance v5, Lc40;

    .line 55
    .line 56
    invoke-direct/range {v5 .. v10}, Lc40;-><init>(Lij4;JLxk5;Lxk5;)V

    .line 57
    .line 58
    .line 59
    invoke-static {p0, p1, v5}, Lpv6;->s(Lhl1;Ljava/lang/Object;Lqa2;)V

    .line 60
    .line 61
    .line 62
    iget-boolean p0, v10, Lxk5;->i:Z

    .line 63
    .line 64
    if-nez p0, :cond_2

    .line 65
    .line 66
    iget-boolean p0, v9, Lxk5;->i:Z

    .line 67
    .line 68
    if-eqz p0, :cond_1

    .line 69
    .line 70
    sget-object v0, Lcv4;->j:Lcv4;

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_1
    sget-object v0, Lcv4;->i:Lcv4;

    .line 74
    .line 75
    :cond_2
    :goto_0
    return-object v0

    .line 76
    :pswitch_0
    check-cast p1, Ljava/lang/Number;

    .line 77
    .line 78
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast p0, Lpq0;

    .line 85
    .line 86
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    const/16 p0, 0x64

    .line 90
    .line 91
    invoke-static {p1, v4, p0}, Lhb3;->C(III)I

    .line 92
    .line 93
    .line 94
    move-result p0

    .line 95
    sget-object p1, Lpq0;->c:Lpm6;

    .line 96
    .line 97
    invoke-virtual {p1}, Lpm6;->getValue()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    check-cast p1, Lcq0;

    .line 102
    .line 103
    iget p1, p1, Lcq0;->k:I

    .line 104
    .line 105
    if-eq p1, p0, :cond_3

    .line 106
    .line 107
    sget-object p1, Lpq0;->b:Lga1;

    .line 108
    .line 109
    new-instance v0, Lnq0;

    .line 110
    .line 111
    invoke-direct {v0, p0, v5}, Lnq0;-><init>(ILia1;)V

    .line 112
    .line 113
    .line 114
    invoke-static {p1, v5, v5, v0, v2}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 115
    .line 116
    .line 117
    :cond_3
    sget-object p0, Lne7;->a:Lne7;

    .line 118
    .line 119
    return-object p0

    .line 120
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 121
    .line 122
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast p0, Lpq0;

    .line 129
    .line 130
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    .line 132
    .line 133
    sget-object p0, Lpq0;->c:Lpm6;

    .line 134
    .line 135
    invoke-virtual {p0}, Lpm6;->getValue()Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object p0

    .line 139
    check-cast p0, Lcq0;

    .line 140
    .line 141
    iget-boolean p0, p0, Lcq0;->j:Z

    .line 142
    .line 143
    if-eq p0, p1, :cond_4

    .line 144
    .line 145
    sget-object p0, Lpq0;->b:Lga1;

    .line 146
    .line 147
    new-instance v0, Loq0;

    .line 148
    .line 149
    invoke-direct {v0, p1, v5}, Loq0;-><init>(ZLia1;)V

    .line 150
    .line 151
    .line 152
    invoke-static {p0, v5, v5, v0, v2}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 153
    .line 154
    .line 155
    :cond_4
    sget-object p0, Lne7;->a:Lne7;

    .line 156
    .line 157
    return-object p0

    .line 158
    :pswitch_2
    check-cast p1, Lau4;

    .line 159
    .line 160
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 161
    .line 162
    .line 163
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast p0, Lpq0;

    .line 166
    .line 167
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    sget-object p0, Lpq0;->c:Lpm6;

    .line 171
    .line 172
    invoke-virtual {p0}, Lpm6;->getValue()Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object p0

    .line 176
    check-cast p0, Lcq0;

    .line 177
    .line 178
    iget-object p0, p0, Lcq0;->i:Lau4;

    .line 179
    .line 180
    if-eq p0, p1, :cond_5

    .line 181
    .line 182
    sget-object p0, Lpq0;->b:Lga1;

    .line 183
    .line 184
    new-instance v0, Ln2;

    .line 185
    .line 186
    const/16 v1, 0x12

    .line 187
    .line 188
    invoke-direct {v0, p1, v5, v1}, Ln2;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 189
    .line 190
    .line 191
    invoke-static {p0, v5, v5, v0, v2}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 192
    .line 193
    .line 194
    :cond_5
    sget-object p0, Lne7;->a:Lne7;

    .line 195
    .line 196
    return-object p0

    .line 197
    :pswitch_3
    check-cast p1, Ljava/lang/String;

    .line 198
    .line 199
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 200
    .line 201
    .line 202
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast p0, Lpq0;

    .line 205
    .line 206
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    sget-object p0, Lpq0;->c:Lpm6;

    .line 210
    .line 211
    invoke-virtual {p0}, Lpm6;->getValue()Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object p0

    .line 215
    check-cast p0, Lcq0;

    .line 216
    .line 217
    iget-object p0, p0, Lcq0;->h:Ljava/lang/String;

    .line 218
    .line 219
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result p0

    .line 223
    if-nez p0, :cond_6

    .line 224
    .line 225
    sget-object p0, Lpq0;->b:Lga1;

    .line 226
    .line 227
    new-instance v0, Ln2;

    .line 228
    .line 229
    const/16 v1, 0x13

    .line 230
    .line 231
    invoke-direct {v0, p1, v5, v1}, Ln2;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 232
    .line 233
    .line 234
    invoke-static {p0, v5, v5, v0, v2}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 235
    .line 236
    .line 237
    :cond_6
    sget-object p0, Lne7;->a:Lne7;

    .line 238
    .line 239
    return-object p0

    .line 240
    :pswitch_4
    check-cast p1, Leq0;

    .line 241
    .line 242
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 243
    .line 244
    .line 245
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast p0, Lpq0;

    .line 248
    .line 249
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 250
    .line 251
    .line 252
    sget-object p0, Lpq0;->c:Lpm6;

    .line 253
    .line 254
    invoke-virtual {p0}, Lpm6;->getValue()Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object p0

    .line 258
    check-cast p0, Lcq0;

    .line 259
    .line 260
    iget-object p0, p0, Lcq0;->g:Leq0;

    .line 261
    .line 262
    if-eq p0, p1, :cond_7

    .line 263
    .line 264
    sget-object p0, Lpq0;->b:Lga1;

    .line 265
    .line 266
    new-instance v0, Ln2;

    .line 267
    .line 268
    const/16 v1, 0x11

    .line 269
    .line 270
    invoke-direct {v0, p1, v5, v1}, Ln2;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 271
    .line 272
    .line 273
    invoke-static {p0, v5, v5, v0, v2}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 274
    .line 275
    .line 276
    :cond_7
    sget-object p0, Lne7;->a:Lne7;

    .line 277
    .line 278
    return-object p0

    .line 279
    :pswitch_5
    check-cast p1, Ljava/lang/String;

    .line 280
    .line 281
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 282
    .line 283
    .line 284
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast p0, Lf61;

    .line 287
    .line 288
    invoke-virtual {p0, p1}, Lf61;->k(Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    sget-object p0, Lne7;->a:Lne7;

    .line 292
    .line 293
    return-object p0

    .line 294
    :pswitch_6
    check-cast p1, Luo2;

    .line 295
    .line 296
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 297
    .line 298
    .line 299
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast p0, Ls41;

    .line 302
    .line 303
    invoke-virtual {p0}, Ls41;->b()Z

    .line 304
    .line 305
    .line 306
    move-result v0

    .line 307
    if-nez v0, :cond_8

    .line 308
    .line 309
    iget-object v0, p1, Luo2;->a:Ljava/lang/String;

    .line 310
    .line 311
    iget-object v2, p0, Ls41;->d:Ldy4;

    .line 312
    .line 313
    invoke-virtual {v2, v0}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    iget-object v0, p0, Ls41;->a:Lws4;

    .line 317
    .line 318
    new-instance v2, Lh9;

    .line 319
    .line 320
    invoke-direct {v2, p1, p0, v5, v1}, Lh9;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v0, v2}, Lws4;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    :cond_8
    sget-object p0, Lne7;->a:Lne7;

    .line 327
    .line 328
    return-object p0

    .line 329
    :pswitch_7
    check-cast p1, Lgf5;

    .line 330
    .line 331
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 332
    .line 333
    .line 334
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 335
    .line 336
    check-cast p0, Lf61;

    .line 337
    .line 338
    invoke-virtual {p0, p1}, Lf61;->n(Lgf5;)V

    .line 339
    .line 340
    .line 341
    iget-object p1, p1, Lgf5;->a:Ljava/lang/String;

    .line 342
    .line 343
    iget-object p0, p0, Lf61;->e:Ldy4;

    .line 344
    .line 345
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 346
    .line 347
    .line 348
    sget-object p0, Lne7;->a:Lne7;

    .line 349
    .line 350
    return-object p0

    .line 351
    :pswitch_8
    check-cast p1, Ljava/lang/String;

    .line 352
    .line 353
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 354
    .line 355
    .line 356
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 357
    .line 358
    check-cast p0, Lf61;

    .line 359
    .line 360
    invoke-virtual {p0, p1}, Lf61;->k(Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    sget-object p0, Lne7;->a:Lne7;

    .line 364
    .line 365
    return-object p0

    .line 366
    :pswitch_9
    check-cast p1, Luo2;

    .line 367
    .line 368
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 369
    .line 370
    .line 371
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast p0, Ls41;

    .line 374
    .line 375
    invoke-virtual {p0}, Ls41;->b()Z

    .line 376
    .line 377
    .line 378
    move-result v0

    .line 379
    if-nez v0, :cond_9

    .line 380
    .line 381
    iget-object v0, p1, Luo2;->a:Ljava/lang/String;

    .line 382
    .line 383
    iget-object v2, p0, Ls41;->d:Ldy4;

    .line 384
    .line 385
    invoke-virtual {v2, v0}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 386
    .line 387
    .line 388
    iget-object v0, p0, Ls41;->a:Lws4;

    .line 389
    .line 390
    new-instance v2, Lh9;

    .line 391
    .line 392
    invoke-direct {v2, p1, p0, v5, v1}, Lh9;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 393
    .line 394
    .line 395
    invoke-virtual {v0, v2}, Lws4;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 396
    .line 397
    .line 398
    :cond_9
    sget-object p0, Lne7;->a:Lne7;

    .line 399
    .line 400
    return-object p0

    .line 401
    :pswitch_a
    check-cast p1, Lgf5;

    .line 402
    .line 403
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 404
    .line 405
    .line 406
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 407
    .line 408
    check-cast p0, Lf61;

    .line 409
    .line 410
    invoke-virtual {p0, p1}, Lf61;->n(Lgf5;)V

    .line 411
    .line 412
    .line 413
    iget-object p1, p1, Lgf5;->a:Ljava/lang/String;

    .line 414
    .line 415
    iget-object p0, p0, Lf61;->e:Ldy4;

    .line 416
    .line 417
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 418
    .line 419
    .line 420
    sget-object p0, Lne7;->a:Lne7;

    .line 421
    .line 422
    return-object p0

    .line 423
    :pswitch_b
    check-cast p1, Lxb4;

    .line 424
    .line 425
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 426
    .line 427
    .line 428
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 429
    .line 430
    check-cast p0, Lqb4;

    .line 431
    .line 432
    invoke-virtual {p0, p1}, Lqb4;->c(Lxb4;)V

    .line 433
    .line 434
    .line 435
    sget-object p0, Lne7;->a:Lne7;

    .line 436
    .line 437
    return-object p0

    .line 438
    :pswitch_c
    check-cast p1, Lxb4;

    .line 439
    .line 440
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 441
    .line 442
    .line 443
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast p0, Lqb4;

    .line 446
    .line 447
    invoke-virtual {p0, p1}, Lqb4;->c(Lxb4;)V

    .line 448
    .line 449
    .line 450
    sget-object p0, Lne7;->a:Lne7;

    .line 451
    .line 452
    return-object p0

    .line 453
    :pswitch_d
    check-cast p1, Lia1;

    .line 454
    .line 455
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 456
    .line 457
    check-cast p0, Ldc4;

    .line 458
    .line 459
    invoke-virtual {p0, p1}, Ldc4;->b(Lia1;)Ljava/lang/Object;

    .line 460
    .line 461
    .line 462
    move-result-object p0

    .line 463
    return-object p0

    .line 464
    :pswitch_e
    check-cast p1, Ljava/lang/String;

    .line 465
    .line 466
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 467
    .line 468
    .line 469
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 470
    .line 471
    check-cast p0, Lpw3;

    .line 472
    .line 473
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 474
    .line 475
    .line 476
    invoke-static {p1}, Lyn6;->g1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 477
    .line 478
    .line 479
    move-result-object p0

    .line 480
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 481
    .line 482
    .line 483
    move-result-object p0

    .line 484
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 485
    .line 486
    .line 487
    move-result p1

    .line 488
    const/4 v0, 0x2

    .line 489
    if-lt p1, v0, :cond_a

    .line 490
    .line 491
    const-string p1, "\""

    .line 492
    .line 493
    invoke-static {p0, p1, v3}, Lfo6;->r0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 494
    .line 495
    .line 496
    move-result v0

    .line 497
    if-eqz v0, :cond_a

    .line 498
    .line 499
    invoke-static {p0, p1, v3}, Lfo6;->j0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 500
    .line 501
    .line 502
    move-result v0

    .line 503
    if-eqz v0, :cond_a

    .line 504
    .line 505
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 506
    .line 507
    .line 508
    move-result v0

    .line 509
    sub-int/2addr v0, v4

    .line 510
    invoke-virtual {p0, v4, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 511
    .line 512
    .line 513
    move-result-object p0

    .line 514
    const-string v0, "\\\""

    .line 515
    .line 516
    invoke-static {p0, v0, p1, v3}, Lfo6;->o0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    .line 517
    .line 518
    .line 519
    move-result-object p0

    .line 520
    const-string p1, "\\\\"

    .line 521
    .line 522
    const-string v0, "\\"

    .line 523
    .line 524
    invoke-static {p0, p1, v0, v3}, Lfo6;->o0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    .line 525
    .line 526
    .line 527
    move-result-object p0

    .line 528
    :cond_a
    return-object p0

    .line 529
    :pswitch_f
    check-cast p1, Ljava/lang/String;

    .line 530
    .line 531
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 532
    .line 533
    .line 534
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 535
    .line 536
    check-cast p0, Lpw3;

    .line 537
    .line 538
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 539
    .line 540
    .line 541
    const-string p0, "-"

    .line 542
    .line 543
    invoke-static {p1, p0, v3}, Lfo6;->r0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 544
    .line 545
    .line 546
    move-result p0

    .line 547
    if-eqz p0, :cond_c

    .line 548
    .line 549
    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 550
    .line 551
    .line 552
    move-result-object p0

    .line 553
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 554
    .line 555
    .line 556
    move-result v0

    .line 557
    if-eqz v0, :cond_b

    .line 558
    .line 559
    invoke-static {p0}, Lyn6;->A0(Ljava/lang/String;)C

    .line 560
    .line 561
    .line 562
    move-result v0

    .line 563
    invoke-static {v0}, Lvj;->Q(C)Z

    .line 564
    .line 565
    .line 566
    move-result v0

    .line 567
    if-eqz v0, :cond_c

    .line 568
    .line 569
    :cond_b
    invoke-static {p0}, Lyn6;->g1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 570
    .line 571
    .line 572
    move-result-object p0

    .line 573
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 574
    .line 575
    .line 576
    move-result-object p1

    .line 577
    :cond_c
    return-object p1

    .line 578
    :pswitch_10
    check-cast p1, Ljava/lang/String;

    .line 579
    .line 580
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 581
    .line 582
    .line 583
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 584
    .line 585
    check-cast p0, Lkn3;

    .line 586
    .line 587
    invoke-virtual {p0, p1}, Lkn3;->s(Ljava/lang/String;)V

    .line 588
    .line 589
    .line 590
    sget-object p0, Lne7;->a:Lne7;

    .line 591
    .line 592
    return-object p0

    .line 593
    :pswitch_11
    check-cast p1, Ljava/lang/String;

    .line 594
    .line 595
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 596
    .line 597
    .line 598
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 599
    .line 600
    check-cast p0, Lkn3;

    .line 601
    .line 602
    invoke-virtual {p0, p1}, Lkn3;->s(Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    sget-object p0, Lne7;->a:Lne7;

    .line 606
    .line 607
    return-object p0

    .line 608
    :pswitch_12
    check-cast p1, Ljava/lang/Throwable;

    .line 609
    .line 610
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 611
    .line 612
    check-cast p0, Li43;

    .line 613
    .line 614
    invoke-virtual {p0, p1}, Li43;->n(Ljava/lang/Throwable;)V

    .line 615
    .line 616
    .line 617
    sget-object p0, Lne7;->a:Lne7;

    .line 618
    .line 619
    return-object p0

    .line 620
    :pswitch_13
    check-cast p1, Ljava/lang/Number;

    .line 621
    .line 622
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 623
    .line 624
    .line 625
    move-result p1

    .line 626
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 627
    .line 628
    check-cast p0, Landroid/content/Context;

    .line 629
    .line 630
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 631
    .line 632
    .line 633
    move-result-object p0

    .line 634
    return-object p0

    .line 635
    :pswitch_14
    check-cast p1, Lia1;

    .line 636
    .line 637
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 638
    .line 639
    check-cast p0, Lip2;

    .line 640
    .line 641
    invoke-virtual {p0, p1}, Lip2;->p(Lia1;)Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    move-result-object p0

    .line 645
    sget-object p1, Lsf1;->i:Lsf1;

    .line 646
    .line 647
    if-eq p0, p1, :cond_d

    .line 648
    .line 649
    sget-object p0, Lne7;->a:Lne7;

    .line 650
    .line 651
    :cond_d
    return-object p0

    .line 652
    :pswitch_15
    check-cast p1, Ljava/lang/Number;

    .line 653
    .line 654
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 655
    .line 656
    .line 657
    move-result p1

    .line 658
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 659
    .line 660
    check-cast p0, Lhp3;

    .line 661
    .line 662
    invoke-virtual {p0, p1}, Lhp3;->a(I)V

    .line 663
    .line 664
    .line 665
    sget-object p0, Lne7;->a:Lne7;

    .line 666
    .line 667
    return-object p0

    .line 668
    :pswitch_16
    check-cast p1, Ljava/lang/String;

    .line 669
    .line 670
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 671
    .line 672
    .line 673
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 674
    .line 675
    check-cast p0, Ltp1;

    .line 676
    .line 677
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 678
    .line 679
    .line 680
    sget-object p0, Lcom/box/app/AppApplication;->i:Landroid/content/Context;

    .line 681
    .line 682
    invoke-static {}, Lpn;->Q()Landroid/content/Context;

    .line 683
    .line 684
    .line 685
    move-result-object p0

    .line 686
    const-string v0, "boxapp_settings"

    .line 687
    .line 688
    invoke-virtual {p0, v0, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 689
    .line 690
    .line 691
    move-result-object p0

    .line 692
    const-string v0, "accelerated_download_enabled"

    .line 693
    .line 694
    invoke-interface {p0, v0, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 695
    .line 696
    .line 697
    move-result v0

    .line 698
    const-string v1, "accelerated_download_prefix"

    .line 699
    .line 700
    invoke-interface {p0, v1, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 701
    .line 702
    .line 703
    move-result-object p0

    .line 704
    if-nez p0, :cond_e

    .line 705
    .line 706
    const-string p0, ""

    .line 707
    .line 708
    :cond_e
    if-eqz v0, :cond_10

    .line 709
    .line 710
    :try_start_0
    new-instance v0, Lsu2;

    .line 711
    .line 712
    invoke-direct {v0}, Lsu2;-><init>()V

    .line 713
    .line 714
    .line 715
    invoke-virtual {v0, v5, p1}, Lsu2;->c(Ltu2;Ljava/lang/String;)V

    .line 716
    .line 717
    .line 718
    invoke-virtual {v0}, Lsu2;->a()Ltu2;

    .line 719
    .line 720
    .line 721
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 722
    goto :goto_1

    .line 723
    :catch_0
    move-object p1, v5

    .line 724
    :goto_1
    if-eqz p1, :cond_10

    .line 725
    .line 726
    invoke-virtual {p1}, Ltu2;->f()Z

    .line 727
    .line 728
    .line 729
    move-result v0

    .line 730
    if-eqz v0, :cond_10

    .line 731
    .line 732
    iget-object v0, p1, Ltu2;->d:Ljava/lang/String;

    .line 733
    .line 734
    const-string v1, "api.github.com"

    .line 735
    .line 736
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 737
    .line 738
    .line 739
    move-result v0

    .line 740
    if-eqz v0, :cond_10

    .line 741
    .line 742
    iget v0, p1, Ltu2;->e:I

    .line 743
    .line 744
    const/16 v2, 0x1bb

    .line 745
    .line 746
    if-ne v0, v2, :cond_10

    .line 747
    .line 748
    invoke-static {p0}, Lyn6;->g1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 749
    .line 750
    .line 751
    move-result-object p0

    .line 752
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object p0

    .line 756
    new-array v0, v4, [C

    .line 757
    .line 758
    const/16 v2, 0x2f

    .line 759
    .line 760
    aput-char v2, v0, v3

    .line 761
    .line 762
    invoke-static {p0, v0}, Lyn6;->j1(Ljava/lang/String;[C)Ljava/lang/String;

    .line 763
    .line 764
    .line 765
    move-result-object p0

    .line 766
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 767
    .line 768
    .line 769
    :try_start_1
    new-instance v0, Lsu2;

    .line 770
    .line 771
    invoke-direct {v0}, Lsu2;-><init>()V

    .line 772
    .line 773
    .line 774
    invoke-virtual {v0, v5, p0}, Lsu2;->c(Ltu2;Ljava/lang/String;)V

    .line 775
    .line 776
    .line 777
    invoke-virtual {v0}, Lsu2;->a()Ltu2;

    .line 778
    .line 779
    .line 780
    move-result-object p0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    .line 781
    goto :goto_2

    .line 782
    :catch_1
    move-object p0, v5

    .line 783
    :goto_2
    if-eqz p0, :cond_10

    .line 784
    .line 785
    iget-object v0, p0, Ltu2;->d:Ljava/lang/String;

    .line 786
    .line 787
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 788
    .line 789
    .line 790
    move-result v0

    .line 791
    if-nez v0, :cond_10

    .line 792
    .line 793
    iget-object v0, p0, Ltu2;->b:Ljava/lang/String;

    .line 794
    .line 795
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 796
    .line 797
    .line 798
    move-result v0

    .line 799
    if-gtz v0, :cond_10

    .line 800
    .line 801
    iget-object v0, p0, Ltu2;->c:Ljava/lang/String;

    .line 802
    .line 803
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 804
    .line 805
    .line 806
    move-result v0

    .line 807
    if-gtz v0, :cond_10

    .line 808
    .line 809
    iget-object v0, p0, Ltu2;->g:Ljava/util/ArrayList;

    .line 810
    .line 811
    if-nez v0, :cond_f

    .line 812
    .line 813
    move-object v0, v5

    .line 814
    goto :goto_3

    .line 815
    :cond_f
    new-instance v1, Ljava/lang/StringBuilder;

    .line 816
    .line 817
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 818
    .line 819
    .line 820
    invoke-static {v1, v0}, Lcj;->b0(Ljava/lang/StringBuilder;Ljava/util/ArrayList;)V

    .line 821
    .line 822
    .line 823
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 824
    .line 825
    .line 826
    move-result-object v0

    .line 827
    :goto_3
    if-nez v0, :cond_10

    .line 828
    .line 829
    iget-object v0, p0, Ltu2;->h:Ljava/lang/String;

    .line 830
    .line 831
    if-nez v0, :cond_10

    .line 832
    .line 833
    iget-object p0, p0, Ltu2;->i:Ljava/lang/String;

    .line 834
    .line 835
    new-array v0, v4, [C

    .line 836
    .line 837
    aput-char v2, v0, v3

    .line 838
    .line 839
    invoke-static {p0, v0}, Lyn6;->j1(Ljava/lang/String;[C)Ljava/lang/String;

    .line 840
    .line 841
    .line 842
    move-result-object p0

    .line 843
    iget-object p1, p1, Ltu2;->i:Ljava/lang/String;

    .line 844
    .line 845
    const-string v0, "https://"

    .line 846
    .line 847
    invoke-static {p1, v0}, Lyn6;->Q0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 848
    .line 849
    .line 850
    move-result-object p1

    .line 851
    const-string v0, "/"

    .line 852
    .line 853
    invoke-static {p0, v0, p1}, Lvz1;->B(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 854
    .line 855
    .line 856
    move-result-object p0

    .line 857
    :try_start_2
    new-instance p1, Lsu2;

    .line 858
    .line 859
    invoke-direct {p1}, Lsu2;-><init>()V

    .line 860
    .line 861
    .line 862
    invoke-virtual {p1, v5, p0}, Lsu2;->c(Ltu2;Ljava/lang/String;)V

    .line 863
    .line 864
    .line 865
    invoke-virtual {p1}, Lsu2;->a()Ltu2;

    .line 866
    .line 867
    .line 868
    move-result-object p0
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    .line 869
    goto :goto_4

    .line 870
    :catch_2
    move-object p0, v5

    .line 871
    :goto_4
    if-eqz p0, :cond_10

    .line 872
    .line 873
    iget-object v5, p0, Ltu2;->i:Ljava/lang/String;

    .line 874
    .line 875
    :cond_10
    return-object v5

    .line 876
    :pswitch_17
    check-cast p1, Ljava/lang/Number;

    .line 877
    .line 878
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 879
    .line 880
    .line 881
    move-result p1

    .line 882
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 883
    .line 884
    check-cast p0, Leb1;

    .line 885
    .line 886
    invoke-virtual {p0, p1}, Leb1;->e(I)V

    .line 887
    .line 888
    .line 889
    sget-object p0, Lne7;->a:Lne7;

    .line 890
    .line 891
    return-object p0

    .line 892
    :pswitch_18
    check-cast p1, Ljava/lang/Number;

    .line 893
    .line 894
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 895
    .line 896
    .line 897
    move-result p1

    .line 898
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 899
    .line 900
    check-cast p0, Leb1;

    .line 901
    .line 902
    invoke-virtual {p0, p1}, Leb1;->e(I)V

    .line 903
    .line 904
    .line 905
    sget-object p0, Lne7;->a:Lne7;

    .line 906
    .line 907
    return-object p0

    .line 908
    :pswitch_19
    check-cast p1, Lgf5;

    .line 909
    .line 910
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 911
    .line 912
    .line 913
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 914
    .line 915
    check-cast p0, Lf61;

    .line 916
    .line 917
    invoke-virtual {p0, p1}, Lf61;->n(Lgf5;)V

    .line 918
    .line 919
    .line 920
    iget-object p1, p1, Lgf5;->a:Ljava/lang/String;

    .line 921
    .line 922
    iget-object p0, p0, Lf61;->e:Ldy4;

    .line 923
    .line 924
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 925
    .line 926
    .line 927
    sget-object p0, Lne7;->a:Lne7;

    .line 928
    .line 929
    return-object p0

    .line 930
    :pswitch_1a
    check-cast p1, Ljava/lang/String;

    .line 931
    .line 932
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 933
    .line 934
    .line 935
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 936
    .line 937
    check-cast p0, Lf61;

    .line 938
    .line 939
    invoke-virtual {p0, p1}, Lf61;->k(Ljava/lang/String;)V

    .line 940
    .line 941
    .line 942
    sget-object p0, Lne7;->a:Lne7;

    .line 943
    .line 944
    return-object p0

    .line 945
    :pswitch_1b
    check-cast p1, Lgf5;

    .line 946
    .line 947
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 948
    .line 949
    .line 950
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 951
    .line 952
    check-cast p0, Lf61;

    .line 953
    .line 954
    invoke-virtual {p0, p1}, Lf61;->n(Lgf5;)V

    .line 955
    .line 956
    .line 957
    iget-object p1, p1, Lgf5;->a:Ljava/lang/String;

    .line 958
    .line 959
    iget-object p0, p0, Lf61;->e:Ldy4;

    .line 960
    .line 961
    invoke-virtual {p0, p1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 962
    .line 963
    .line 964
    sget-object p0, Lne7;->a:Lne7;

    .line 965
    .line 966
    return-object p0

    .line 967
    :pswitch_1c
    check-cast p1, Ljava/lang/String;

    .line 968
    .line 969
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 970
    .line 971
    .line 972
    iget-object p0, p0, Lsi0;->receiver:Ljava/lang/Object;

    .line 973
    .line 974
    check-cast p0, Lf61;

    .line 975
    .line 976
    invoke-virtual {p0, p1}, Lf61;->k(Ljava/lang/String;)V

    .line 977
    .line 978
    .line 979
    sget-object p0, Lne7;->a:Lne7;

    .line 980
    .line 981
    return-object p0

    .line 982
    nop

    .line 983
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
