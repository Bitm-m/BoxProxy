.class public final Lap2;
.super Lja1;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public i:Lzo2;

.field public j:Ltp0;

.field public k:Ljava/lang/String;

.field public l:Ll54;

.field public m:Ll54;

.field public synthetic n:Ljava/lang/Object;

.field public final synthetic o:Lip2;

.field public p:I


# direct methods
.method public constructor <init>(Lip2;Lja1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lap2;->o:Lip2;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lja1;-><init>(Lia1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lap2;->n:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lap2;->p:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lap2;->p:I

    .line 9
    .line 10
    iget-object p1, p0, Lap2;->o:Lip2;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Lip2;->b(Lzo2;Ltp0;Ljava/lang/String;Lja1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
