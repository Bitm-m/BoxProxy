.class public abstract Lb82;
.super Lh14;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lca7;


# static fields
.field public static final w:Lv21;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lv21;

    .line 2
    .line 3
    const/16 v1, 0xf

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lv21;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lb82;->w:Lv21;

    .line 9
    .line 10
    return-void
.end method
