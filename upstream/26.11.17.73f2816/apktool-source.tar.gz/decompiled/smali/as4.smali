.class public interface abstract Las4;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# virtual methods
.method public abstract a(JILqa2;)J
.end method

.method public abstract b()Lhl1;
.end method

.method public abstract c()Z
.end method

.method public abstract d(JLua2;Lja1;)Ljava/lang/Object;
.end method
