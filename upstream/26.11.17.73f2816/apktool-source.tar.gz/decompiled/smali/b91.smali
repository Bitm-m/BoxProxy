.class public final Lb91;
.super Lh02;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final c:B

.field public final d:Lmo0;

.field public final e:Lmo0;

.field public final f:Z


# direct methods
.method public constructor <init>(Ldv0;ILmo0;Lmo0;Ljava/lang/CharSequence;Z)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lh02;-><init>(Ldv0;)V

    .line 2
    .line 3
    .line 4
    iput-byte p2, p0, Lb91;->c:B

    .line 5
    .line 6
    iput-object p3, p0, Lb91;->d:Lmo0;

    .line 7
    .line 8
    iput-object p4, p0, Lb91;->e:Lmo0;

    .line 9
    .line 10
    iput-boolean p6, p0, Lb91;->f:Z

    .line 11
    .line 12
    return-void
.end method
