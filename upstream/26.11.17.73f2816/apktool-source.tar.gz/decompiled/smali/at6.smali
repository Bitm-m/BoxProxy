.class public abstract Lat6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# direct methods
.method public static A(Ljava/lang/String;Ljava/lang/String;Z)Z
    .locals 5

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    if-lt v0, v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    move v1, v2

    .line 17
    :goto_0
    if-ge v1, v0, :cond_2

    .line 18
    .line 19
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    if-eq v3, v4, :cond_1

    .line 28
    .line 29
    if-eqz p2, :cond_0

    .line 30
    .line 31
    invoke-static {v3}, Ljava/lang/Character;->toLowerCase(C)C

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    invoke-static {v4}, Ljava/lang/Character;->toLowerCase(C)C

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-eq v3, v4, :cond_1

    .line 40
    .line 41
    :cond_0
    return v2

    .line 42
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_2
    const/4 p0, 0x1

    .line 46
    return p0
.end method

.method public static final B(ILwf;Lv72;Lvk5;)Ljava/lang/Boolean;
    .locals 7

    .line 1
    invoke-virtual {p2}, Lv72;->L1()Lp72;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_d

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    const/4 v2, 0x3

    .line 13
    const/4 v3, 0x2

    .line 14
    const/4 v4, 0x1

    .line 15
    if-eq v0, v4, :cond_3

    .line 16
    .line 17
    if-eq v0, v3, :cond_d

    .line 18
    .line 19
    if-ne v0, v2, :cond_2

    .line 20
    .line 21
    invoke-virtual {p2}, Lv72;->I1()Lh72;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iget-boolean v0, v0, Lh72;->a:Z

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    invoke-virtual {p1, p2}, Lwf;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    check-cast p0, Ljava/lang/Boolean;

    .line 34
    .line 35
    return-object p0

    .line 36
    :cond_0
    if-nez p3, :cond_1

    .line 37
    .line 38
    invoke-static {p2, p0, p1}, Lat6;->o(Lv72;ILqa2;)Z

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0

    .line 47
    :cond_1
    invoke-static {p0, p1, p2, p3}, Lat6;->y(ILwf;Lv72;Lvk5;)Z

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :cond_2
    invoke-static {}, Lqi1;->a()V

    .line 57
    .line 58
    .line 59
    return-object v1

    .line 60
    :cond_3
    invoke-static {p2}, Lom;->G(Lv72;)Lv72;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    const-string v5, "ActiveParent must have a focusedChild"

    .line 65
    .line 66
    if-eqz v0, :cond_c

    .line 67
    .line 68
    invoke-virtual {v0}, Lv72;->L1()Lp72;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 73
    .line 74
    .line 75
    move-result v6

    .line 76
    if-eqz v6, :cond_a

    .line 77
    .line 78
    if-eq v6, v4, :cond_5

    .line 79
    .line 80
    if-eq v6, v3, :cond_a

    .line 81
    .line 82
    if-eq v6, v2, :cond_4

    .line 83
    .line 84
    invoke-static {}, Lqi1;->a()V

    .line 85
    .line 86
    .line 87
    return-object v1

    .line 88
    :cond_4
    invoke-static {v5}, Lj02;->c(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    return-object v1

    .line 92
    :cond_5
    invoke-static {p0, p1, v0, p3}, Lat6;->B(ILwf;Lv72;Lvk5;)Ljava/lang/Boolean;

    .line 93
    .line 94
    .line 95
    move-result-object v2

    .line 96
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 97
    .line 98
    invoke-static {v2, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 99
    .line 100
    .line 101
    move-result v3

    .line 102
    if-nez v3, :cond_6

    .line 103
    .line 104
    return-object v2

    .line 105
    :cond_6
    if-nez p3, :cond_9

    .line 106
    .line 107
    invoke-virtual {v0}, Lv72;->L1()Lp72;

    .line 108
    .line 109
    .line 110
    move-result-object p3

    .line 111
    sget-object v2, Lp72;->j:Lp72;

    .line 112
    .line 113
    if-ne p3, v2, :cond_8

    .line 114
    .line 115
    invoke-static {v0}, Lom;->A(Lv72;)Lv72;

    .line 116
    .line 117
    .line 118
    move-result-object p3

    .line 119
    if-eqz p3, :cond_7

    .line 120
    .line 121
    invoke-static {p3}, Lom;->F(Lv72;)Lvk5;

    .line 122
    .line 123
    .line 124
    move-result-object p3

    .line 125
    goto :goto_0

    .line 126
    :cond_7
    invoke-static {v5}, Lj02;->c(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    return-object v1

    .line 130
    :cond_8
    const-string p0, "Searching for active node in inactive hierarchy"

    .line 131
    .line 132
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    return-object v1

    .line 136
    :cond_9
    :goto_0
    invoke-static {p0, p1, p2, p3}, Lat6;->q(ILwf;Lv72;Lvk5;)Z

    .line 137
    .line 138
    .line 139
    move-result p0

    .line 140
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    return-object p0

    .line 145
    :cond_a
    if-nez p3, :cond_b

    .line 146
    .line 147
    invoke-static {v0}, Lom;->F(Lv72;)Lvk5;

    .line 148
    .line 149
    .line 150
    move-result-object p3

    .line 151
    :cond_b
    invoke-static {p0, p1, p2, p3}, Lat6;->q(ILwf;Lv72;Lvk5;)Z

    .line 152
    .line 153
    .line 154
    move-result p0

    .line 155
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    return-object p0

    .line 160
    :cond_c
    invoke-static {v5}, Lj02;->c(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    return-object v1

    .line 164
    :cond_d
    invoke-static {p2, p0, p1}, Lat6;->o(Lv72;ILqa2;)Z

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    return-object p0
.end method

.method public static C(ILjava/lang/String;)Lvf7;
    .locals 2

    .line 1
    new-instance p0, Lvf7;

    .line 2
    .line 3
    new-instance v0, Ld03;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-direct {v0, v1, v1, v1, v1}, Ld03;-><init>(IIII)V

    .line 7
    .line 8
    .line 9
    invoke-direct {p0, v0, p1}, Lvf7;-><init>(Ld03;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public static final a(Ljava/lang/String;FLi14;ZJJLjava/lang/String;JLjava/lang/String;JLc01;Lc01;Lt12;ZFFFLfa2;Lc01;Lub2;III)V
    .locals 30

    move-object/from16 v0, p15

    move-object/from16 v1, p23

    move/from16 v2, p24

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v3, 0x4d3aa7a1    # 1.95721744E8f

    .line 1
    invoke-virtual {v1, v3}, Lub2;->c0(I)Lub2;

    move-object/from16 v3, p0

    invoke-virtual {v1, v3}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v4, v2

    and-int/lit8 v7, v2, 0x30

    if-nez v7, :cond_2

    move/from16 v7, p1

    invoke-virtual {v1, v7}, Lub2;->d(F)Z

    move-result v10

    if-eqz v10, :cond_1

    const/16 v10, 0x20

    goto :goto_1

    :cond_1
    const/16 v10, 0x10

    :goto_1
    or-int/2addr v4, v10

    :cond_2
    move-object/from16 v10, p2

    invoke-virtual {v1, v10}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_3

    const/16 v11, 0x100

    goto :goto_2

    :cond_3
    const/16 v11, 0x80

    :goto_2
    or-int/2addr v4, v11

    move/from16 v11, p3

    invoke-virtual {v1, v11}, Lub2;->h(Z)Z

    move-result v14

    const/16 v16, 0x800

    if-eqz v14, :cond_4

    move/from16 v14, v16

    goto :goto_3

    :cond_4
    const/16 v14, 0x400

    :goto_3
    or-int/2addr v4, v14

    and-int/lit16 v14, v2, 0x6000

    if-nez v14, :cond_6

    move-wide/from16 v5, p4

    invoke-virtual {v1, v5, v6}, Lub2;->f(J)Z

    move-result v18

    if-eqz v18, :cond_5

    const/16 v18, 0x4000

    goto :goto_4

    :cond_5
    const/16 v18, 0x2000

    :goto_4
    or-int v4, v4, v18

    :cond_6
    and-int/lit8 v18, p26, 0x20

    const/high16 v19, 0x10000

    const/high16 v20, 0x20000

    move-wide/from16 v8, p6

    if-nez v18, :cond_7

    invoke-virtual {v1, v8, v9}, Lub2;->f(J)Z

    move-result v22

    if-eqz v22, :cond_7

    move/from16 v22, v20

    goto :goto_5

    :cond_7
    move/from16 v22, v19

    :goto_5
    or-int v4, v4, v22

    and-int/lit8 v22, p26, 0x40

    const/high16 v23, 0x80000

    const/high16 v24, 0x100000

    move-object/from16 v12, p8

    if-nez v22, :cond_8

    invoke-virtual {v1, v12}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v25

    if-eqz v25, :cond_8

    move/from16 v25, v24

    goto :goto_6

    :cond_8
    move/from16 v25, v23

    :goto_6
    or-int v4, v4, v25

    const/high16 v25, 0x400000

    or-int v4, v4, v25

    move-object/from16 v13, p11

    invoke-virtual {v1, v13}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v27

    if-eqz v27, :cond_9

    const/high16 v27, 0x4000000

    goto :goto_7

    :cond_9
    const/high16 v27, 0x2000000

    :goto_7
    or-int v4, v4, v27

    const/high16 v27, 0x10000000

    or-int v4, v4, v27

    and-int/lit8 v27, p25, 0x6

    if-nez v27, :cond_b

    move-object/from16 v14, p14

    invoke-virtual {v1, v14}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v28

    if-eqz v28, :cond_a

    const/16 v27, 0x4

    goto :goto_8

    :cond_a
    const/16 v27, 0x2

    :goto_8
    or-int v27, p25, v27

    goto :goto_9

    :cond_b
    move/from16 v27, p25

    :goto_9
    and-int/lit8 v17, p25, 0x30

    if-nez v17, :cond_d

    invoke-virtual {v1, v0}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_c

    const/16 v21, 0x20

    goto :goto_a

    :cond_c
    const/16 v21, 0x10

    :goto_a
    or-int v27, v27, v21

    :cond_d
    move-object/from16 v15, p16

    invoke-virtual {v1, v15}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_e

    const/16 v22, 0x100

    goto :goto_b

    :cond_e
    const/16 v22, 0x80

    :goto_b
    or-int v27, v27, v22

    move/from16 v2, p17

    invoke-virtual {v1, v2}, Lub2;->h(Z)Z

    move-result v18

    if-nez v18, :cond_f

    const/16 v16, 0x400

    :cond_f
    or-int v2, v27, v16

    or-int/lit16 v3, v2, 0x6000

    const v16, 0x8000

    and-int v16, p26, v16

    if-eqz v16, :cond_10

    const v3, 0x36000

    or-int/2addr v3, v2

    goto :goto_c

    :cond_10
    const/high16 v2, 0x30000

    and-int v2, p25, v2

    if-nez v2, :cond_12

    move/from16 v2, p19

    invoke-virtual {v1, v2}, Lub2;->d(F)Z

    move-result v17

    if-nez v17, :cond_11

    move/from16 v20, v19

    :cond_11
    or-int v3, v3, v20

    :cond_12
    :goto_c
    and-int v19, p26, v19

    const/high16 v17, 0x180000

    if-eqz v19, :cond_14

    or-int v3, v3, v17

    :cond_13
    :goto_d
    move-object/from16 v2, p21

    goto :goto_e

    :cond_14
    and-int v17, p25, v17

    if-nez v17, :cond_13

    move/from16 v2, p20

    invoke-virtual {v1, v2}, Lub2;->d(F)Z

    move-result v17

    if-eqz v17, :cond_15

    move/from16 v23, v24

    :cond_15
    or-int v3, v3, v23

    goto :goto_d

    :goto_e
    invoke-virtual {v1, v2}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_16

    const/high16 v25, 0x800000

    :cond_16
    or-int v3, v3, v25

    const v17, 0x12492493

    and-int v2, v4, v17

    move/from16 v17, v3

    const v3, 0x12492492

    if-ne v2, v3, :cond_17

    const v2, 0x2492493

    and-int v3, v17, v2

    const v2, 0x2492492

    if-ne v3, v2, :cond_17

    const/4 v2, 0x0

    goto :goto_f

    :cond_17
    const/4 v2, 0x1

    :goto_f
    and-int/lit8 v3, v4, 0x1

    invoke-virtual {v1, v3, v2}, Lub2;->S(IZ)Z

    move-result v2

    if-eqz v2, :cond_1f

    invoke-virtual {v1}, Lub2;->X()V

    and-int/lit8 v2, p24, 0x1

    const v3, -0x71c00001

    const v18, -0x380001

    const v20, -0x70001

    if-eqz v2, :cond_1a

    invoke-virtual {v1}, Lub2;->z()Z

    move-result v2

    if-nez v2, :cond_1a

    .line 2
    invoke-virtual {v1}, Lub2;->V()V

    and-int/lit8 v2, p26, 0x20

    if-eqz v2, :cond_18

    and-int v4, v4, v20

    :cond_18
    and-int/lit8 v2, p26, 0x40

    if-eqz v2, :cond_19

    and-int v4, v4, v18

    :cond_19
    and-int/2addr v4, v3

    move-wide/from16 v6, p9

    move-wide/from16 v22, p12

    move/from16 v13, p18

    move/from16 v14, p19

    move/from16 v15, p20

    :goto_10
    move-object/from16 v19, v12

    goto :goto_12

    :cond_1a
    and-int/lit8 v2, p26, 0x20

    if-eqz v2, :cond_1b

    .line 3
    sget-object v2, Lfx0;->a:Lyt1;

    .line 4
    invoke-virtual {v1, v2}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v2

    .line 5
    check-cast v2, Lex0;

    .line 6
    invoke-virtual {v2}, Lex0;->i()J

    move-result-wide v8

    and-int v4, v4, v20

    :cond_1b
    and-int/lit8 v2, p26, 0x40

    if-eqz v2, :cond_1c

    and-int v4, v4, v18

    move-object/from16 v12, p0

    .line 7
    :cond_1c
    sget-object v2, Lfx0;->a:Lyt1;

    .line 8
    invoke-virtual {v1, v2}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v18

    .line 9
    check-cast v18, Lex0;

    .line 10
    invoke-virtual/range {v18 .. v18}, Lex0;->i()J

    move-result-wide v20

    .line 11
    invoke-virtual {v1, v2}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v2

    .line 12
    check-cast v2, Lex0;

    .line 13
    invoke-virtual {v2}, Lex0;->n()J

    move-result-wide v22

    and-int/2addr v4, v3

    const/high16 v2, 0x41800000    # 16.0f

    if-eqz v16, :cond_1d

    move v3, v2

    goto :goto_11

    :cond_1d
    move/from16 v3, p19

    :goto_11
    if-nez v19, :cond_1e

    move/from16 v2, p20

    :cond_1e
    const/high16 v16, 0x41d00000    # 26.0f

    move v15, v2

    move v14, v3

    move/from16 v13, v16

    move-wide/from16 v6, v20

    goto :goto_10

    .line 14
    :goto_12
    invoke-virtual {v1}, Lub2;->s()V

    .line 15
    new-instance v2, Lj47;

    invoke-direct {v2, v0}, Lj47;-><init>(Lc01;)V

    const v3, 0x7d206778

    invoke-static {v3, v2, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    move-result-object v12

    and-int/lit8 v2, v4, 0xe

    const/high16 v3, 0xc00000

    or-int/2addr v2, v3

    shr-int/lit8 v3, v4, 0x9

    and-int/lit8 v5, v3, 0x70

    or-int/2addr v2, v5

    and-int/lit16 v3, v3, 0x380

    or-int/2addr v2, v3

    shr-int/lit8 v3, v4, 0xc

    const v5, 0xe000

    and-int/2addr v3, v5

    or-int/2addr v2, v3

    shl-int/lit8 v3, v17, 0x12

    const/high16 v16, 0x380000

    and-int v3, v3, v16

    or-int/2addr v2, v3

    shl-int/lit8 v3, v17, 0xc

    const/high16 v18, 0x6000000

    or-int v2, v2, v18

    const/high16 v20, 0x70000000

    and-int v3, v3, v20

    or-int v25, v2, v3

    shr-int/lit8 v3, v17, 0x12

    and-int/lit8 v3, v3, 0xe

    shr-int/lit8 v2, v17, 0x3

    and-int/lit8 v2, v2, 0x70

    or-int/2addr v3, v2

    and-int/lit16 v2, v4, 0x380

    or-int/2addr v3, v2

    and-int/lit16 v2, v4, 0x1c00

    or-int/2addr v3, v2

    shr-int/lit8 v2, v4, 0x6

    and-int/2addr v2, v5

    or-int/2addr v3, v2

    const/high16 v2, 0x70000

    shl-int/lit8 v4, v4, 0xc

    and-int/2addr v4, v2

    or-int/2addr v3, v4

    shl-int/lit8 v2, v17, 0x9

    and-int v2, v2, v16

    or-int/2addr v3, v2

    const/high16 v2, 0x1c00000

    and-int v2, v17, v2

    or-int/2addr v3, v2

    or-int v26, v3, v18

    move/from16 v20, p1

    move-wide/from16 v2, p4

    move-object/from16 v16, p16

    move/from16 v21, p17

    move-object/from16 v24, v1

    move-wide v4, v8

    move-object/from16 v17, v10

    move/from16 v18, v11

    move-wide/from16 v9, v22

    move-object/from16 v1, p0

    move-object/from16 v8, p11

    move-object/from16 v11, p14

    move-object/from16 v22, p21

    move-object/from16 v23, p22

    .line 16
    invoke-static/range {v1 .. v26}, Lat6;->e(Ljava/lang/String;JJJLjava/lang/String;JLc01;Lc01;FFFLt12;Li14;ZLjava/lang/String;FZLfa2;Lua2;Lub2;II)V

    move/from16 v20, v14

    move/from16 v21, v15

    move-object/from16 v8, v19

    move/from16 v19, v13

    move-wide v13, v9

    move-object v9, v8

    move-wide v10, v6

    move-wide v7, v4

    goto :goto_13

    .line 17
    :cond_1f
    invoke-virtual/range {p23 .. p23}, Lub2;->V()V

    move-wide/from16 v10, p9

    move-wide/from16 v13, p12

    move/from16 v19, p18

    move/from16 v20, p19

    move/from16 v21, p20

    move-wide v7, v8

    move-object v9, v12

    .line 18
    :goto_13
    invoke-virtual/range {p23 .. p23}, Lub2;->t()Lkk5;

    move-result-object v1

    if-eqz v1, :cond_20

    new-instance v0, Lg87;

    move/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-wide/from16 v5, p4

    move-object/from16 v12, p11

    move-object/from16 v15, p14

    move-object/from16 v16, p15

    move-object/from16 v17, p16

    move/from16 v18, p17

    move-object/from16 v22, p21

    move-object/from16 v23, p22

    move/from16 v24, p24

    move/from16 v25, p25

    move/from16 v26, p26

    move-object/from16 v29, v1

    move-object/from16 v1, p0

    invoke-direct/range {v0 .. v26}, Lg87;-><init>(Ljava/lang/String;FLi14;ZJJLjava/lang/String;JLjava/lang/String;JLc01;Lc01;Lt12;ZFFFLfa2;Lc01;III)V

    move-object v1, v0

    move-object/from16 v0, v29

    .line 19
    iput-object v1, v0, Lkk5;->d:Lua2;

    :cond_20
    return-void
.end method

.method public static final b(Lub2;)Lt12;
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    sget-object v2, Ll87;->f:Lb26;

    .line 5
    .line 6
    const v3, -0x800001

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, v3}, Lub2;->d(F)Z

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    const/4 v4, 0x0

    .line 14
    invoke-virtual {p0, v4}, Lub2;->d(F)Z

    .line 15
    .line 16
    .line 17
    move-result v5

    .line 18
    or-int/2addr v3, v5

    .line 19
    invoke-virtual {p0, v4}, Lub2;->d(F)Z

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    or-int/2addr v3, v5

    .line 24
    invoke-virtual {p0}, Lub2;->N()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    sget-object v6, Li21;->a:Ls9;

    .line 29
    .line 30
    if-nez v3, :cond_0

    .line 31
    .line 32
    if-ne v5, v6, :cond_1

    .line 33
    .line 34
    :cond_0
    new-instance v5, Lu47;

    .line 35
    .line 36
    const/16 v3, 0x8

    .line 37
    .line 38
    invoke-direct {v5, v3}, Lu47;-><init>(B)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_1
    check-cast v5, Lfa2;

    .line 45
    .line 46
    invoke-static {v1, v2, v5, p0, v0}, Llc3;->S([Ljava/lang/Object;La26;Lfa2;Lub2;I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Ll87;

    .line 51
    .line 52
    invoke-virtual {p0}, Lub2;->N()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    if-ne v1, v6, :cond_2

    .line 57
    .line 58
    new-instance v1, Lu47;

    .line 59
    .line 60
    const/4 v2, 0x7

    .line 61
    invoke-direct {v1, v2}, Lu47;-><init>(B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p0, v1}, Lub2;->k0(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    check-cast v1, Lfa2;

    .line 68
    .line 69
    const v2, 0x451c4000    # 2500.0f

    .line 70
    .line 71
    .line 72
    const/4 v3, 0x5

    .line 73
    const/4 v5, 0x0

    .line 74
    invoke-static {v4, v2, v5, v3}, Lac7;->Y(FFLjava/lang/Object;I)Lll6;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    invoke-static {p0}, Lhl6;->a(Lub2;)Loi1;

    .line 79
    .line 80
    .line 81
    move-result-object v3

    .line 82
    invoke-virtual {p0, v0}, Lub2;->g(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v4

    .line 86
    invoke-virtual {p0, v1}, Lub2;->g(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    or-int/2addr v4, v5

    .line 91
    invoke-virtual {p0, v2}, Lub2;->g(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    or-int/2addr v4, v5

    .line 96
    invoke-virtual {p0, v3}, Lub2;->g(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v5

    .line 100
    or-int/2addr v4, v5

    .line 101
    invoke-virtual {p0}, Lub2;->N()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    if-nez v4, :cond_3

    .line 106
    .line 107
    if-ne v5, v6, :cond_4

    .line 108
    .line 109
    :cond_3
    new-instance v5, Lt12;

    .line 110
    .line 111
    invoke-direct {v5, v0, v2, v3, v1}, Lt12;-><init>(Ll87;Lll6;Loi1;Lfa2;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {p0, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_4
    check-cast v5, Lt12;

    .line 118
    .line 119
    return-object v5
.end method

.method public static final c(ZLqa2;Ljava/lang/String;Ljava/lang/String;Lc01;ZLub2;III)V
    .locals 18

    .line 1
    move/from16 v0, p0

    .line 2
    .line 3
    move/from16 v7, p8

    .line 4
    .line 5
    move/from16 v8, p9

    .line 6
    .line 7
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    const-wide/16 v3, 0x0

    .line 14
    .line 15
    const/4 v6, 0x3

    .line 16
    const-wide/16 v1, 0x0

    .line 17
    .line 18
    move-object/from16 v5, p6

    .line 19
    .line 20
    invoke-static/range {v1 .. v6}, Lo00;->b(JJLub2;I)Ln00;

    .line 21
    .line 22
    .line 23
    move-result-object v9

    .line 24
    and-int/lit8 v1, v8, 0x20

    .line 25
    .line 26
    const/4 v10, 0x0

    .line 27
    if-eqz v1, :cond_0

    .line 28
    .line 29
    move-object v11, v10

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move-object/from16 v11, p3

    .line 32
    .line 33
    :goto_0
    const-wide/16 v3, 0x0

    .line 34
    .line 35
    const/4 v6, 0x3

    .line 36
    const-wide/16 v1, 0x0

    .line 37
    .line 38
    move-object/from16 v5, p6

    .line 39
    .line 40
    invoke-static/range {v1 .. v6}, Lo00;->a(JJLub2;I)Ln00;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    and-int/lit16 v1, v8, 0x80

    .line 45
    .line 46
    if-nez v1, :cond_1

    .line 47
    .line 48
    move-object/from16 v10, p4

    .line 49
    .line 50
    :cond_1
    invoke-static {v5}, Lts6;->n(Lub2;)Lrs6;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    sget-object v2, Lo00;->a:Lxu4;

    .line 55
    .line 56
    and-int/lit16 v3, v8, 0x2000

    .line 57
    .line 58
    if-eqz v3, :cond_2

    .line 59
    .line 60
    const/4 v12, 0x1

    .line 61
    goto :goto_1

    .line 62
    :cond_2
    move/from16 v12, p5

    .line 63
    .line 64
    :goto_1
    shr-int/lit8 v3, p7, 0x3

    .line 65
    .line 66
    move-object/from16 v8, p1

    .line 67
    .line 68
    invoke-static {v8, v5}, Lhb3;->T(Ljava/lang/Object;Lub2;)Lw44;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    new-instance v13, Lns;

    .line 73
    .line 74
    invoke-direct {v13, v0, v12, v1, v8}, Lns;-><init>(ZZLrs6;Lw44;)V

    .line 75
    .line 76
    .line 77
    const v1, -0x15117a9b

    .line 78
    .line 79
    .line 80
    invoke-static {v1, v13, v5}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    invoke-virtual {v5, v8}, Lub2;->g(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result v13

    .line 88
    and-int/lit16 v14, v7, 0x1c00

    .line 89
    .line 90
    xor-int/lit16 v14, v14, 0xc00

    .line 91
    .line 92
    const/4 v15, 0x0

    .line 93
    const/16 v6, 0x800

    .line 94
    .line 95
    if-le v14, v6, :cond_3

    .line 96
    .line 97
    invoke-virtual {v5, v12}, Lub2;->h(Z)Z

    .line 98
    .line 99
    .line 100
    move-result v14

    .line 101
    if-nez v14, :cond_4

    .line 102
    .line 103
    :cond_3
    and-int/lit16 v14, v7, 0xc00

    .line 104
    .line 105
    if-ne v14, v6, :cond_5

    .line 106
    .line 107
    :cond_4
    const/4 v6, 0x1

    .line 108
    goto :goto_2

    .line 109
    :cond_5
    move v6, v15

    .line 110
    :goto_2
    or-int/2addr v13, v6

    .line 111
    and-int/lit8 v6, p7, 0xe

    .line 112
    .line 113
    xor-int/lit8 v6, v6, 0x6

    .line 114
    .line 115
    const/4 v14, 0x4

    .line 116
    if-le v6, v14, :cond_6

    .line 117
    .line 118
    invoke-virtual {v5, v0}, Lub2;->h(Z)Z

    .line 119
    .line 120
    .line 121
    move-result v6

    .line 122
    if-nez v6, :cond_7

    .line 123
    .line 124
    :cond_6
    and-int/lit8 v6, p7, 0x6

    .line 125
    .line 126
    if-ne v6, v14, :cond_8

    .line 127
    .line 128
    :cond_7
    const/4 v6, 0x1

    .line 129
    goto :goto_3

    .line 130
    :cond_8
    move v6, v15

    .line 131
    :goto_3
    or-int/2addr v13, v6

    .line 132
    invoke-virtual {v5}, Lub2;->N()Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v6

    .line 136
    if-nez v13, :cond_9

    .line 137
    .line 138
    sget-object v13, Li21;->a:Ls9;

    .line 139
    .line 140
    if-ne v6, v13, :cond_a

    .line 141
    .line 142
    :cond_9
    new-instance v6, Llb5;

    .line 143
    .line 144
    invoke-direct {v6, v0, v8, v12}, Llb5;-><init>(ZLw44;Z)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v5, v6}, Lub2;->k0(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    :cond_a
    check-cast v6, Lfa2;

    .line 151
    .line 152
    move-object v5, v10

    .line 153
    new-instance v10, Ljp5;

    .line 154
    .line 155
    const/4 v0, 0x2

    .line 156
    invoke-direct {v10, v0}, Ljp5;-><init>(I)V

    .line 157
    .line 158
    .line 159
    shr-int/lit8 v0, p7, 0x9

    .line 160
    .line 161
    and-int/lit8 v0, v0, 0xe

    .line 162
    .line 163
    const/high16 v8, 0x180000

    .line 164
    .line 165
    or-int/2addr v0, v8

    .line 166
    and-int/lit8 v3, v3, 0x70

    .line 167
    .line 168
    or-int/2addr v0, v3

    .line 169
    shr-int/lit8 v3, p7, 0x6

    .line 170
    .line 171
    and-int/lit16 v8, v3, 0x380

    .line 172
    .line 173
    or-int/2addr v0, v8

    .line 174
    and-int/lit16 v8, v3, 0x1c00

    .line 175
    .line 176
    or-int/2addr v0, v8

    .line 177
    const v8, 0xe000

    .line 178
    .line 179
    .line 180
    and-int/2addr v8, v3

    .line 181
    or-int/2addr v0, v8

    .line 182
    const/high16 v8, 0x70000

    .line 183
    .line 184
    and-int/2addr v8, v3

    .line 185
    or-int/2addr v0, v8

    .line 186
    const/high16 v8, 0x1c00000

    .line 187
    .line 188
    and-int/2addr v3, v8

    .line 189
    or-int/2addr v0, v3

    .line 190
    shl-int/lit8 v3, v7, 0x15

    .line 191
    .line 192
    const/high16 v8, 0xe000000

    .line 193
    .line 194
    and-int/2addr v3, v8

    .line 195
    or-int v15, v0, v3

    .line 196
    .line 197
    and-int/lit16 v0, v7, 0x1f80

    .line 198
    .line 199
    const/16 v17, 0x4400

    .line 200
    .line 201
    move/from16 v16, v0

    .line 202
    .line 203
    sget-object v0, Lf14;->i:Lf14;

    .line 204
    .line 205
    const/4 v7, 0x0

    .line 206
    move-object v3, v11

    .line 207
    const/4 v11, 0x0

    .line 208
    const/4 v13, 0x0

    .line 209
    move-object/from16 v14, p6

    .line 210
    .line 211
    move-object v8, v2

    .line 212
    move-object v2, v9

    .line 213
    move-object v9, v6

    .line 214
    move-object v6, v1

    .line 215
    move-object/from16 v1, p2

    .line 216
    .line 217
    invoke-static/range {v0 .. v17}, Lgj;->h(Li14;Ljava/lang/String;Ln00;Ljava/lang/String;Ln00;Lua2;Lva2;Lc01;Lxu4;Lfa2;Ljp5;ZZLw34;Lub2;III)V

    .line 218
    .line 219
    .line 220
    return-void
.end method

.method public static final d(ZLqa2;ZLrs6;Lub2;I)V
    .locals 10

    .line 1
    const v0, 0x696fe65b

    .line 2
    .line 3
    .line 4
    invoke-virtual {p4, v0}, Lub2;->c0(I)Lub2;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p4, p0}, Lub2;->h(Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x4

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x2

    .line 16
    :goto_0
    or-int/2addr v0, p5

    .line 17
    invoke-virtual {p4, p1}, Lub2;->i(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    const/16 v1, 0x20

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_1
    const/16 v1, 0x10

    .line 27
    .line 28
    :goto_1
    or-int/2addr v0, v1

    .line 29
    invoke-virtual {p4, p2}, Lub2;->h(Z)Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    const/16 v1, 0x100

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_2
    const/16 v1, 0x80

    .line 39
    .line 40
    :goto_2
    or-int/2addr v0, v1

    .line 41
    invoke-virtual {p4, p3}, Lub2;->g(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_3

    .line 46
    .line 47
    const/16 v1, 0x800

    .line 48
    .line 49
    goto :goto_3

    .line 50
    :cond_3
    const/16 v1, 0x400

    .line 51
    .line 52
    :goto_3
    or-int/2addr v0, v1

    .line 53
    and-int/lit16 v1, v0, 0x493

    .line 54
    .line 55
    const/16 v2, 0x492

    .line 56
    .line 57
    if-eq v1, v2, :cond_4

    .line 58
    .line 59
    const/4 v1, 0x1

    .line 60
    goto :goto_4

    .line 61
    :cond_4
    const/4 v1, 0x0

    .line 62
    :goto_4
    and-int/lit8 v2, v0, 0x1

    .line 63
    .line 64
    invoke-virtual {p4, v2, v1}, Lub2;->S(IZ)Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    if-eqz v1, :cond_5

    .line 69
    .line 70
    and-int/lit16 v1, v0, 0x1c7e

    .line 71
    .line 72
    const v2, 0xe000

    .line 73
    .line 74
    .line 75
    shl-int/lit8 v0, v0, 0x6

    .line 76
    .line 77
    and-int/2addr v0, v2

    .line 78
    or-int v8, v1, v0

    .line 79
    .line 80
    const/4 v9, 0x4

    .line 81
    const/4 v4, 0x0

    .line 82
    move v2, p0

    .line 83
    move-object v3, p1

    .line 84
    move v6, p2

    .line 85
    move-object v5, p3

    .line 86
    move-object v7, p4

    .line 87
    invoke-static/range {v2 .. v9}, Lzs6;->b(ZLqa2;Li14;Lrs6;ZLub2;II)V

    .line 88
    .line 89
    .line 90
    move p1, v2

    .line 91
    move-object p2, v3

    .line 92
    move-object p4, v5

    .line 93
    move p3, v6

    .line 94
    goto :goto_5

    .line 95
    :cond_5
    move-object v7, p4

    .line 96
    move-object p4, p3

    .line 97
    move p3, p2

    .line 98
    move-object p2, p1

    .line 99
    move p1, p0

    .line 100
    invoke-virtual {v7}, Lub2;->V()V

    .line 101
    .line 102
    .line 103
    :goto_5
    invoke-virtual {v7}, Lub2;->t()Lkk5;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    if-eqz v0, :cond_6

    .line 108
    .line 109
    new-instance p0, Lan;

    .line 110
    .line 111
    invoke-direct/range {p0 .. p5}, Lan;-><init>(ZLqa2;ZLrs6;I)V

    .line 112
    .line 113
    .line 114
    iput-object p0, v0, Lkk5;->d:Lua2;

    .line 115
    .line 116
    :cond_6
    return-void
.end method

.method public static final e(Ljava/lang/String;JJJLjava/lang/String;JLc01;Lc01;FFFLt12;Li14;ZLjava/lang/String;FZLfa2;Lua2;Lub2;II)V
    .locals 57

    move-wide/from16 v2, p1

    move-object/from16 v11, p10

    move-object/from16 v12, p11

    move/from16 v13, p12

    move-object/from16 v0, p15

    move-object/from16 v1, p16

    move/from16 v4, p17

    move/from16 v5, p19

    move/from16 v6, p20

    move-object/from16 v7, p21

    move-object/from16 v8, p22

    move-object/from16 v9, p23

    move/from16 v10, p24

    move/from16 v14, p25

    const v15, 0x7009d261

    .line 1
    invoke-virtual {v9, v15}, Lub2;->c0(I)Lub2;

    and-int/lit8 v15, v10, 0x6

    move/from16 v16, v15

    if-nez v16, :cond_1

    move-object/from16 v15, p0

    invoke-virtual {v9, v15}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_0

    const/16 v18, 0x4

    goto :goto_0

    :cond_0
    const/16 v18, 0x2

    :goto_0
    or-int v18, v10, v18

    goto :goto_1

    :cond_1
    move/from16 v18, v10

    :goto_1
    and-int/lit8 v19, v10, 0x30

    if-nez v19, :cond_3

    invoke-virtual {v9, v2, v3}, Lub2;->f(J)Z

    move-result v19

    if-eqz v19, :cond_2

    const/16 v19, 0x20

    goto :goto_2

    :cond_2
    const/16 v19, 0x10

    :goto_2
    or-int v18, v18, v19

    :cond_3
    and-int/lit16 v15, v10, 0x180

    const/16 v21, 0x80

    const/16 v22, 0x100

    if-nez v15, :cond_5

    move-wide/from16 v2, p3

    invoke-virtual {v9, v2, v3}, Lub2;->f(J)Z

    move-result v15

    if-eqz v15, :cond_4

    move/from16 v15, v22

    goto :goto_3

    :cond_4
    move/from16 v15, v21

    :goto_3
    or-int v18, v18, v15

    :cond_5
    and-int/lit16 v15, v10, 0xc00

    const/16 v23, 0x400

    if-nez v15, :cond_7

    move-wide/from16 v2, p5

    invoke-virtual {v9, v2, v3}, Lub2;->f(J)Z

    move-result v24

    if-eqz v24, :cond_6

    const/16 v24, 0x800

    goto :goto_4

    :cond_6
    move/from16 v24, v23

    :goto_4
    or-int v18, v18, v24

    :cond_7
    and-int/lit16 v15, v10, 0x6000

    const/16 v25, 0x2000

    const/16 v26, 0x4000

    if-nez v15, :cond_9

    move-object/from16 v15, p7

    invoke-virtual {v9, v15}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v27

    if-eqz v27, :cond_8

    move/from16 v27, v26

    goto :goto_5

    :cond_8
    move/from16 v27, v25

    :goto_5
    or-int v18, v18, v27

    :cond_9
    const/high16 v27, 0x30000

    and-int v28, v10, v27

    const/high16 v29, 0x10000

    if-nez v28, :cond_b

    move-wide/from16 v2, p8

    invoke-virtual {v9, v2, v3}, Lub2;->f(J)Z

    move-result v28

    if-eqz v28, :cond_a

    const/high16 v28, 0x20000

    goto :goto_6

    :cond_a
    move/from16 v28, v29

    :goto_6
    or-int v18, v18, v28

    :cond_b
    const/high16 v37, 0x180000

    and-int v28, v10, v37

    const/high16 v30, 0x80000

    const/high16 v31, 0x100000

    if-nez v28, :cond_d

    invoke-virtual {v9, v11}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v28

    if-eqz v28, :cond_c

    move/from16 v28, v31

    goto :goto_7

    :cond_c
    move/from16 v28, v30

    :goto_7
    or-int v18, v18, v28

    :cond_d
    const/high16 v28, 0xc00000

    and-int v32, v10, v28

    const/high16 v33, 0x400000

    if-nez v32, :cond_f

    invoke-virtual {v9, v12}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e

    const/high16 v3, 0x800000

    goto :goto_8

    :cond_e
    move/from16 v3, v33

    :goto_8
    or-int v18, v18, v3

    :cond_f
    const/high16 v3, 0x6000000

    and-int v32, v10, v3

    const/high16 v34, 0x2000000

    const/high16 v35, 0x4000000

    if-nez v32, :cond_11

    invoke-virtual {v9, v13}, Lub2;->d(F)Z

    move-result v32

    if-eqz v32, :cond_10

    move/from16 v32, v35

    goto :goto_9

    :cond_10
    move/from16 v32, v34

    :goto_9
    or-int v18, v18, v32

    :cond_11
    const/high16 v32, 0x30000000

    and-int v32, v10, v32

    if-nez v32, :cond_13

    move/from16 v32, v3

    move/from16 v3, p13

    invoke-virtual {v9, v3}, Lub2;->d(F)Z

    move-result v38

    if-eqz v38, :cond_12

    const/high16 v38, 0x20000000

    goto :goto_a

    :cond_12
    const/high16 v38, 0x10000000

    :goto_a
    or-int v18, v18, v38

    :goto_b
    move/from16 v44, v18

    goto :goto_c

    :cond_13
    move/from16 v32, v3

    goto :goto_b

    :goto_c
    and-int/lit8 v18, v14, 0x6

    if-nez v18, :cond_15

    move/from16 v2, p14

    invoke-virtual {v9, v2}, Lub2;->d(F)Z

    move-result v18

    if-eqz v18, :cond_14

    const/16 v18, 0x4

    goto :goto_d

    :cond_14
    const/16 v18, 0x2

    :goto_d
    or-int v18, v14, v18

    goto :goto_e

    :cond_15
    move/from16 v18, v14

    :goto_e
    and-int/lit8 v38, v14, 0x30

    if-nez v38, :cond_17

    invoke-virtual {v9, v0}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v38

    if-eqz v38, :cond_16

    const/16 v38, 0x20

    goto :goto_f

    :cond_16
    const/16 v38, 0x10

    :goto_f
    or-int v18, v18, v38

    :cond_17
    and-int/lit16 v2, v14, 0x180

    if-nez v2, :cond_19

    invoke-virtual {v9, v1}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_18

    move/from16 v21, v22

    :cond_18
    or-int v18, v18, v21

    :cond_19
    and-int/lit16 v2, v14, 0xc00

    if-nez v2, :cond_1b

    invoke-virtual {v9, v4}, Lub2;->h(Z)Z

    move-result v2

    if-eqz v2, :cond_1a

    const/16 v23, 0x800

    :cond_1a
    or-int v18, v18, v23

    :cond_1b
    and-int/lit16 v2, v14, 0x6000

    if-nez v2, :cond_1d

    move-object/from16 v2, p18

    invoke-virtual {v9, v2}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_1c

    move/from16 v25, v26

    :cond_1c
    or-int v18, v18, v25

    :cond_1d
    and-int v21, v14, v27

    if-nez v21, :cond_1f

    invoke-virtual {v9, v5}, Lub2;->d(F)Z

    move-result v21

    if-eqz v21, :cond_1e

    const/high16 v29, 0x20000

    :cond_1e
    or-int v18, v18, v29

    :cond_1f
    and-int v21, v14, v37

    if-nez v21, :cond_21

    invoke-virtual {v9, v6}, Lub2;->h(Z)Z

    move-result v21

    if-eqz v21, :cond_20

    move/from16 v30, v31

    :cond_20
    or-int v18, v18, v30

    :cond_21
    and-int v21, v14, v28

    if-nez v21, :cond_23

    invoke-virtual {v9, v7}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_22

    const/high16 v33, 0x800000

    :cond_22
    or-int v18, v18, v33

    :cond_23
    and-int v21, v14, v32

    if-nez v21, :cond_25

    invoke-virtual {v9, v8}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_24

    move/from16 v34, v35

    :cond_24
    or-int v18, v18, v34

    :cond_25
    move/from16 v2, v18

    const v18, 0x12492493

    and-int v3, v44, v18

    const v6, 0x12492492

    if-ne v3, v6, :cond_26

    const v3, 0x2492493

    and-int/2addr v3, v2

    const v6, 0x2492492

    if-ne v3, v6, :cond_26

    const/4 v3, 0x0

    goto :goto_10

    :cond_26
    const/4 v3, 0x1

    :goto_10
    and-int/lit8 v6, v44, 0x1

    invoke-virtual {v9, v6, v3}, Lub2;->S(IZ)Z

    move-result v3

    if-eqz v3, :cond_5b

    invoke-virtual {v9}, Lub2;->X()V

    and-int/lit8 v3, p24, 0x1

    if-eqz v3, :cond_27

    invoke-virtual {v9}, Lub2;->z()Z

    move-result v3

    if-nez v3, :cond_27

    .line 2
    invoke-virtual {v9}, Lub2;->V()V

    :cond_27
    invoke-virtual {v9}, Lub2;->s()V

    .line 3
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v3

    .line 4
    sget-object v6, Li21;->a:Ls9;

    if-ne v3, v6, :cond_28

    .line 5
    new-instance v3, Ln87;

    invoke-direct {v3}, Ln87;-><init>()V

    .line 6
    invoke-virtual {v9, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 7
    :cond_28
    check-cast v3, Ln87;

    and-int/lit8 v10, v2, 0x70

    const/16 v14, 0x20

    if-ne v10, v14, :cond_29

    const/16 v18, 0x1

    goto :goto_11

    :cond_29
    const/16 v18, 0x0

    .line 8
    :goto_11
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v14

    if-nez v18, :cond_2a

    if-ne v14, v6, :cond_2b

    .line 9
    :cond_2a
    new-instance v14, Ld87;

    const/4 v15, 0x0

    invoke-direct {v14, v0, v15}, Ld87;-><init>(Lt12;B)V

    .line 10
    invoke-virtual {v9, v14}, Lub2;->k0(Ljava/lang/Object;)V

    .line 11
    :cond_2b
    check-cast v14, Lfa2;

    const/16 v15, 0x20

    if-ne v10, v15, :cond_2c

    const/4 v15, 0x1

    :goto_12
    move-object/from16 v18, v14

    goto :goto_13

    :cond_2c
    const/4 v15, 0x0

    goto :goto_12

    .line 12
    :goto_13
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v14

    if-nez v15, :cond_2d

    if-ne v14, v6, :cond_2e

    .line 13
    :cond_2d
    new-instance v14, Ld87;

    const/4 v15, 0x1

    invoke-direct {v14, v0, v15}, Ld87;-><init>(Lt12;B)V

    .line 14
    invoke-virtual {v9, v14}, Lub2;->k0(Ljava/lang/Object;)V

    .line 15
    :cond_2e
    check-cast v14, Lfa2;

    .line 16
    invoke-virtual {v9, v14}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v15

    move/from16 v21, v15

    .line 17
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v15

    if-nez v21, :cond_2f

    if-ne v15, v6, :cond_30

    .line 18
    :cond_2f
    new-instance v15, Lx65;

    const/4 v8, 0x4

    invoke-direct {v15, v14, v8}, Lx65;-><init>(Lfa2;B)V

    .line 19
    invoke-virtual {v9, v15}, Lub2;->k0(Ljava/lang/Object;)V

    .line 20
    :cond_30
    check-cast v15, Lfa2;

    const/16 v8, 0x20

    if-ne v10, v8, :cond_31

    const/4 v8, 0x1

    goto :goto_14

    :cond_31
    const/4 v8, 0x0

    :goto_14
    move/from16 v21, v8

    and-int/lit16 v8, v2, 0x1c00

    move/from16 v45, v2

    const/16 v2, 0x800

    if-ne v8, v2, :cond_32

    const/16 v22, 0x1

    :goto_15
    move-object v2, v15

    goto :goto_16

    :cond_32
    const/16 v22, 0x0

    goto :goto_15

    :goto_16
    or-int v21, v21, v22

    .line 21
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v15

    if-nez v21, :cond_33

    if-eq v15, v6, :cond_33

    move-object/from16 v21, v14

    goto :goto_17

    .line 22
    :cond_33
    new-instance v15, Lxy;

    move-object/from16 v21, v14

    const/4 v14, 0x5

    invoke-direct {v15, v0, v4, v14}, Lxy;-><init>(Ljava/lang/Object;ZB)V

    .line 23
    invoke-virtual {v9, v15}, Lub2;->k0(Ljava/lang/Object;)V

    .line 24
    :goto_17
    check-cast v15, Lqa2;

    const/16 v14, 0x20

    if-ne v10, v14, :cond_34

    const/4 v10, 0x1

    :goto_18
    const/16 v14, 0x800

    goto :goto_19

    :cond_34
    const/4 v10, 0x0

    goto :goto_18

    :goto_19
    if-ne v8, v14, :cond_35

    const/4 v8, 0x1

    goto :goto_1a

    :cond_35
    const/4 v8, 0x0

    :goto_1a
    or-int/2addr v10, v8

    .line 25
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v8

    if-nez v10, :cond_36

    if-ne v8, v6, :cond_37

    .line 26
    :cond_36
    new-instance v8, Lbv;

    const/4 v10, 0x7

    invoke-direct {v8, v4, v0, v10}, Lbv;-><init>(ZLjava/lang/Object;B)V

    .line 27
    invoke-static {v8}, Lmj6;->b(Lfa2;)Ldm1;

    move-result-object v8

    .line 28
    invoke-virtual {v9, v8}, Lub2;->k0(Ljava/lang/Object;)V

    .line 29
    :cond_37
    check-cast v8, Lmm6;

    .line 30
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v6, :cond_39

    .line 31
    invoke-interface {v8}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Boolean;

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    if-eqz v10, :cond_38

    const/high16 v10, 0x3f800000    # 1.0f

    :goto_1b
    const v14, 0x3c23d70a    # 0.01f

    goto :goto_1c

    :cond_38
    const/4 v10, 0x0

    goto :goto_1b

    .line 32
    :goto_1c
    invoke-static {v10, v14}, Lrp7;->b(FF)Lng;

    move-result-object v10

    .line 33
    invoke-virtual {v9, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 34
    :cond_39
    check-cast v10, Lng;

    .line 35
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v6, :cond_3b

    .line 36
    invoke-interface {v8}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Boolean;

    invoke-virtual {v14}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v14

    if-eqz v14, :cond_3a

    const/4 v14, 0x0

    :goto_1d
    const v0, 0x3c23d70a    # 0.01f

    goto :goto_1e

    :cond_3a
    const/high16 v14, 0x41a00000    # 20.0f

    goto :goto_1d

    .line 37
    :goto_1e
    invoke-static {v14, v0}, Lrp7;->b(FF)Lng;

    move-result-object v14

    .line 38
    invoke-virtual {v9, v14}, Lub2;->k0(Ljava/lang/Object;)V

    .line 39
    :cond_3b
    check-cast v14, Lng;

    .line 40
    invoke-interface {v8}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    invoke-virtual {v9, v8}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v19

    invoke-virtual {v9, v10}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v22

    or-int v19, v19, v22

    invoke-virtual {v9, v14}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v22

    or-int v19, v19, v22

    .line 42
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v4

    const/16 v26, 0x0

    if-nez v19, :cond_3c

    if-eq v4, v6, :cond_3c

    move-object v8, v14

    move-object/from16 v14, v26

    goto :goto_1f

    .line 43
    :cond_3c
    new-instance v22, Ltd1;

    const/16 v27, 0x2

    move-object/from16 v23, v8

    move-object/from16 v24, v10

    move-object/from16 v25, v14

    invoke-direct/range {v22 .. v27}, Ltd1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    move-object/from16 v4, v22

    move-object/from16 v8, v25

    move-object/from16 v14, v26

    .line 44
    invoke-virtual {v9, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 45
    :goto_1f
    check-cast v4, Lua2;

    invoke-static {v4, v9, v0}, Lac7;->i(Lua2;Lub2;Ljava/lang/Object;)V

    const/16 v0, 0x32

    const/4 v4, 0x6

    const/4 v9, 0x0

    .line 46
    invoke-static {v0, v9, v14, v4}, Lac7;->d0(IILfu1;I)Lqa7;

    move-result-object v16

    shr-int/lit8 v22, v44, 0x6

    and-int/lit8 v22, v22, 0xe

    or-int/lit8 v22, v22, 0x30

    const/16 v20, 0xc

    const/16 v17, 0x0

    move-object/from16 v48, v2

    move-object v2, v14

    move-object/from16 v47, v15

    move-object/from16 v5, v18

    move-object/from16 v46, v21

    move/from16 v19, v22

    move-wide/from16 v14, p3

    move-object/from16 v18, p23

    .line 47
    invoke-static/range {v14 .. v20}, Log6;->a(JLci;Ljava/lang/String;Lub2;II)Lmm6;

    move-result-object v21

    .line 48
    invoke-static {v0, v9, v2, v4}, Lac7;->d0(IILfu1;I)Lqa7;

    move-result-object v16

    shr-int/lit8 v14, v44, 0x9

    and-int/lit8 v14, v14, 0xe

    or-int/lit8 v19, v14, 0x30

    move-wide/from16 v14, p5

    .line 49
    invoke-static/range {v14 .. v20}, Log6;->a(JLci;Ljava/lang/String;Lub2;II)Lmm6;

    move-result-object v49

    .line 50
    invoke-static {v0, v9, v2, v4}, Lac7;->d0(IILfu1;I)Lqa7;

    move-result-object v16

    shr-int/lit8 v0, v44, 0xf

    and-int/lit8 v0, v0, 0xe

    or-int/lit8 v19, v0, 0x30

    move-wide/from16 v14, p8

    .line 51
    invoke-static/range {v14 .. v20}, Log6;->a(JLci;Ljava/lang/String;Lub2;II)Lmm6;

    move-result-object v0

    move-object/from16 v9, v18

    .line 52
    sget-object v2, Lmf0;->d0:Lft2;

    move-wide/from16 v14, p1

    .line 53
    invoke-static {v1, v14, v15, v2}, Lgb;->N(Li14;JLub6;)Li14;

    move-result-object v2

    .line 54
    sget-object v4, Lf14;->i:Lf14;

    move-object/from16 v50, v0

    if-eqz p20, :cond_3d

    const v0, 0x77bc758

    invoke-virtual {v9, v0}, Lub2;->b0(I)V

    .line 55
    sget-object v0, Lrn7;->w:Ljava/util/WeakHashMap;

    invoke-static {v9}, Lat6;->l(Lub2;)Lrn7;

    move-result-object v0

    .line 56
    iget-object v0, v0, Lrn7;->b:Lkg;

    .line 57
    new-instance v1, Lpg3;

    .line 58
    sget v14, Let6;->d:I

    invoke-direct {v1, v0, v14}, Lpg3;-><init>(Lkm7;I)V

    .line 59
    invoke-static {v4, v1}, Lu23;->L(Li14;Lkm7;)Li14;

    move-result-object v0

    .line 60
    invoke-static {v9}, Lat6;->l(Lub2;)Lrn7;

    move-result-object v1

    .line 61
    iget-object v1, v1, Lrn7;->e:Lkg;

    .line 62
    new-instance v15, Lpg3;

    .line 63
    invoke-direct {v15, v1, v14}, Lpg3;-><init>(Lkm7;I)V

    .line 64
    invoke-static {v0, v15}, Lu23;->L(Li14;Lkm7;)Li14;

    move-result-object v0

    const/4 v15, 0x0

    .line 65
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    goto :goto_20

    :cond_3d
    const/4 v15, 0x0

    const v0, 0x77fc731

    .line 66
    invoke-virtual {v9, v0}, Lub2;->b0(I)V

    .line 67
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    move-object v0, v4

    .line 68
    :goto_20
    invoke-interface {v2, v0}, Li14;->a0(Li14;)Li14;

    move-result-object v0

    .line 69
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_3e

    .line 70
    new-instance v1, Lr57;

    const/4 v15, 0x1

    invoke-direct {v1, v3, v15}, Lr57;-><init>(Ljava/lang/Object;B)V

    .line 71
    invoke-virtual {v9, v1}, Lub2;->k0(Ljava/lang/Object;)V

    .line 72
    :cond_3e
    check-cast v1, Lqa2;

    invoke-static {v0, v1}, Lif7;->K(Li14;Lqa2;)Li14;

    move-result-object v0

    .line 73
    sget-object v1, Lrn7;->w:Ljava/util/WeakHashMap;

    invoke-static {v9}, Lat6;->l(Lub2;)Lrn7;

    move-result-object v1

    .line 74
    iget-object v1, v1, Lrn7;->g:Lkg;

    .line 75
    new-instance v2, Lpg3;

    const/16 v14, 0x10

    .line 76
    invoke-direct {v2, v1, v14}, Lpg3;-><init>(Lkm7;I)V

    .line 77
    invoke-static {v0, v2}, Lu23;->L(Li14;Lkm7;)Li14;

    move-result-object v0

    .line 78
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_3f

    .line 79
    sget-object v1, Lyo;->q:Lyo;

    .line 80
    invoke-virtual {v9, v1}, Lub2;->k0(Ljava/lang/Object;)V

    .line 81
    :cond_3f
    check-cast v1, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    sget-object v2, Lne7;->a:Lne7;

    invoke-static {v0, v2, v1}, Lls6;->b(Li14;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Li14;

    move-result-object v0

    .line 82
    invoke-virtual {v9, v5}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v1

    .line 83
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v2

    if-nez v1, :cond_40

    if-ne v2, v6, :cond_41

    .line 84
    :cond_40
    new-instance v2, Lsd;

    const/4 v1, 0x4

    invoke-direct {v2, v5, v3, v1}, Lsd;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 85
    invoke-virtual {v9, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 86
    :cond_41
    check-cast v2, Lis3;

    .line 87
    iget-wide v14, v9, Lub2;->T:J

    .line 88
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v1

    .line 89
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v14

    .line 90
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 91
    sget-object v15, La21;->d:Lt6;

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    invoke-virtual {v9}, Lub2;->e0()V

    .line 93
    iget-boolean v15, v9, Lub2;->S:Z

    move/from16 v16, v15

    .line 94
    sget-object v15, Lja3;->a0:Lxg2;

    if-eqz v16, :cond_42

    .line 95
    invoke-virtual {v9, v15}, Lub2;->l(Lfa2;)V

    :goto_21
    move/from16 v16, v1

    goto :goto_22

    .line 96
    :cond_42
    invoke-virtual {v9}, Lub2;->n0()V

    goto :goto_21

    .line 97
    :goto_22
    sget-object v1, Lt6;->S:Lf11;

    .line 98
    invoke-static {v1, v9, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 99
    sget-object v2, Lt6;->R:Lf11;

    .line 100
    invoke-static {v2, v9, v14}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 101
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    move-object/from16 v51, v5

    .line 102
    sget-object v5, Lt6;->T:Lf11;

    .line 103
    invoke-static {v5, v9, v14}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 104
    invoke-static {v9}, Les6;->l(Lub2;)V

    .line 105
    sget-object v14, Lt6;->Q:Lf11;

    .line 106
    invoke-static {v14, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 107
    const-string v0, "navigationIcon"

    invoke-static {v4, v0}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v38

    const/16 v42, 0x0

    const/16 v43, 0xe

    const/16 v40, 0x0

    const/16 v41, 0x0

    move/from16 v39, p13

    .line 108
    invoke-static/range {v38 .. v43}, Lmi1;->G(Li14;FFFFI)Li14;

    move-result-object v0

    .line 109
    sget-object v12, Lt6;->k:Lr20;

    move-object/from16 v52, v8

    const/4 v7, 0x0

    .line 110
    invoke-static {v12, v7}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v8

    move-object v7, v12

    .line 111
    iget-wide v12, v9, Lub2;->T:J

    .line 112
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    move-result v12

    .line 113
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v13

    .line 114
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 115
    invoke-virtual {v9}, Lub2;->e0()V

    move-object/from16 v16, v7

    .line 116
    iget-boolean v7, v9, Lub2;->S:Z

    if-eqz v7, :cond_43

    .line 117
    invoke-virtual {v9, v15}, Lub2;->l(Lfa2;)V

    goto :goto_23

    .line 118
    :cond_43
    invoke-virtual {v9}, Lub2;->n0()V

    .line 119
    :goto_23
    invoke-static {v1, v9, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 120
    invoke-static {v2, v9, v13}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 121
    invoke-static {v12, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 122
    invoke-static {v14, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    shr-int/lit8 v0, v44, 0x12

    and-int/lit8 v0, v0, 0xe

    const/4 v7, 0x1

    .line 123
    invoke-static {v0, v11, v9, v7}, Lvz1;->v(ILc01;Lub2;Z)V

    .line 124
    const-string v0, "title"

    invoke-static {v4, v0}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v0

    .line 125
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v7

    if-ne v7, v6, :cond_44

    .line 126
    new-instance v7, Le87;

    const/4 v8, 0x0

    invoke-direct {v7, v3, v8}, Le87;-><init>(Ln87;B)V

    .line 127
    invoke-virtual {v9, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 128
    :cond_44
    check-cast v7, Lfa2;

    .line 129
    new-instance v8, Lqy6;

    const/16 v12, 0xa

    invoke-direct {v8, v7, v3, v12}, Lqy6;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    invoke-static {v0, v8}, Lvv6;->w(Li14;Lqa2;)Li14;

    move-result-object v0

    move/from16 v13, p12

    const/4 v7, 0x2

    const/4 v8, 0x0

    .line 130
    invoke-static {v0, v13, v8, v7}, Lmi1;->E(Li14;FFI)Li14;

    move-result-object v0

    .line 131
    invoke-virtual {v9, v10}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v17

    const/high16 v18, 0x1c00000

    and-int v7, v45, v18

    const/high16 v8, 0x800000

    if-ne v7, v8, :cond_45

    const/4 v8, 0x1

    goto :goto_24

    :cond_45
    const/4 v8, 0x0

    :goto_24
    or-int v17, v17, v8

    move-object/from16 v8, v52

    invoke-virtual {v9, v8}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v18

    or-int v17, v17, v18

    .line 132
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v12

    if-nez v17, :cond_46

    if-eq v12, v6, :cond_46

    move/from16 v53, v7

    goto :goto_25

    .line 133
    :cond_46
    new-instance v12, Lb87;

    move-object/from16 v11, p21

    move/from16 v53, v7

    const/4 v7, 0x1

    invoke-direct {v12, v10, v11, v8, v7}, Lb87;-><init>(Lng;Lfa2;Lng;B)V

    .line 134
    invoke-virtual {v9, v12}, Lub2;->k0(Ljava/lang/Object;)V

    .line 135
    :goto_25
    check-cast v12, Lqa2;

    invoke-static {v0, v12}, Lv23;->s(Li14;Lqa2;)Li14;

    move-result-object v0

    move-object/from16 v54, v8

    move-object/from16 v7, v16

    const/4 v12, 0x0

    .line 136
    invoke-static {v7, v12}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v8

    move-object v12, v10

    .line 137
    iget-wide v10, v9, Lub2;->T:J

    .line 138
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 139
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v11

    .line 140
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 141
    invoke-virtual {v9}, Lub2;->e0()V

    move-object/from16 v55, v12

    .line 142
    iget-boolean v12, v9, Lub2;->S:Z

    if-eqz v12, :cond_47

    .line 143
    invoke-virtual {v9, v15}, Lub2;->l(Lfa2;)V

    goto :goto_26

    .line 144
    :cond_47
    invoke-virtual {v9}, Lub2;->n0()V

    .line 145
    :goto_26
    invoke-static {v1, v9, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 146
    invoke-static {v2, v9, v11}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 147
    invoke-static {v10, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 148
    invoke-static {v14, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 149
    invoke-interface/range {v21 .. v21}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lsv0;

    .line 150
    iget-wide v10, v0, Lsv0;->a:J

    .line 151
    sget-object v0, Ln37;->a:Lyt1;

    .line 152
    invoke-virtual {v9, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v8

    .line 153
    check-cast v8, Lm37;

    .line 154
    iget-object v8, v8, Lm37;->m:Ldy4;

    .line 155
    invoke-virtual {v8}, Ldy4;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lk37;

    .line 156
    iget-object v8, v8, Lk37;->a:Lqk6;

    .line 157
    iget-wide v8, v8, Lqk6;->b:J

    .line 158
    sget-object v20, Lc92;->l:Lc92;

    and-int/lit8 v12, v44, 0xe

    or-int v33, v12, v37

    const/16 v34, 0xd80

    const v35, 0x3cfaa    # 3.50002E-40f

    move-object v12, v15

    const/4 v15, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x2

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v32, p23

    move-wide/from16 v18, v8

    move-wide/from16 v16, v10

    move-object v8, v14

    move-object/from16 v14, p0

    .line 159
    invoke-static/range {v14 .. v35}, Lzs6;->c(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    move-object/from16 v9, v32

    const/4 v15, 0x1

    .line 160
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    .line 161
    const-string v10, "actionIcons"

    invoke-static {v4, v10}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v38

    const/16 v42, 0x0

    const/16 v43, 0xb

    const/16 v39, 0x0

    const/16 v40, 0x0

    move/from16 v41, p14

    .line 162
    invoke-static/range {v38 .. v43}, Lmi1;->G(Li14;FFFFI)Li14;

    move-result-object v10

    const/4 v15, 0x0

    .line 163
    invoke-static {v7, v15}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v11

    .line 164
    iget-wide v14, v9, Lub2;->T:J

    .line 165
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 166
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v15

    .line 167
    invoke-static {v9, v10}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v10

    .line 168
    invoke-virtual {v9}, Lub2;->e0()V

    move-object/from16 v38, v0

    .line 169
    iget-boolean v0, v9, Lub2;->S:Z

    if-eqz v0, :cond_48

    .line 170
    invoke-virtual {v9, v12}, Lub2;->l(Lfa2;)V

    goto :goto_27

    .line 171
    :cond_48
    invoke-virtual {v9}, Lub2;->n0()V

    .line 172
    :goto_27
    invoke-static {v1, v9, v11}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 173
    invoke-static {v2, v9, v15}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 174
    invoke-static {v14, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 175
    invoke-static {v8, v9, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    shr-int/lit8 v0, v44, 0x15

    and-int/lit8 v0, v0, 0xe

    move-object/from16 v10, p11

    const/4 v15, 0x1

    .line 176
    invoke-static {v0, v10, v9, v15}, Lvz1;->v(ILc01;Lub2;Z)V

    .line 177
    const-string v0, "largeTitle"

    invoke-static {v4, v0}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v0

    .line 178
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v11

    if-ne v11, v6, :cond_49

    .line 179
    new-instance v11, Le87;

    invoke-direct {v11, v3, v15}, Le87;-><init>(Ln87;B)V

    .line 180
    invoke-virtual {v9, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 181
    :cond_49
    check-cast v11, Lfa2;

    .line 182
    new-instance v14, Lqy6;

    const/16 v15, 0xa

    invoke-direct {v14, v11, v3, v15}, Lqy6;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    invoke-static {v0, v14}, Lvv6;->w(Li14;Lqa2;)Li14;

    move-result-object v16

    const/16 v20, 0x0

    const/16 v21, 0xd

    const/16 v17, 0x0

    const/high16 v18, 0x42500000    # 52.0f

    const/16 v19, 0x0

    .line 183
    invoke-static/range {v16 .. v21}, Lmi1;->G(Li14;FFFFI)Li14;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v14, 0x0

    .line 184
    invoke-static {v0, v13, v14, v11}, Lmi1;->E(Li14;FFI)Li14;

    move-result-object v0

    move-object/from16 v15, v48

    .line 185
    invoke-virtual {v9, v15}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v11

    move/from16 v14, v53

    const/high16 v10, 0x800000

    if-ne v14, v10, :cond_4a

    const/4 v10, 0x1

    goto :goto_28

    :cond_4a
    const/4 v10, 0x0

    :goto_28
    or-int/2addr v11, v10

    const/high16 v10, 0x70000

    and-int v10, v45, v10

    move/from16 v16, v11

    const/high16 v11, 0x20000

    if-ne v10, v11, :cond_4b

    const/4 v10, 0x1

    goto :goto_29

    :cond_4b
    const/4 v10, 0x0

    :goto_29
    or-int v11, v16, v10

    move-object/from16 v10, v46

    invoke-virtual {v9, v10}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v16

    or-int v11, v11, v16

    move/from16 v16, v11

    .line 186
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v11

    if-nez v16, :cond_4c

    if-eq v11, v6, :cond_4c

    move-object/from16 v36, v3

    move-object/from16 v3, p21

    goto :goto_2a

    .line 187
    :cond_4c
    new-instance v11, Lfk0;

    move/from16 v13, p19

    move-object/from16 v36, v3

    move-object/from16 v3, p21

    invoke-direct {v11, v15, v3, v13, v10}, Lfk0;-><init>(Lfa2;Lfa2;FLfa2;)V

    .line 188
    invoke-virtual {v9, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 189
    :goto_2a
    check-cast v11, Lqa2;

    invoke-static {v0, v11}, Lv23;->s(Li14;Lqa2;)Li14;

    move-result-object v0

    const/4 v15, 0x0

    .line 190
    invoke-static {v7, v15}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v10

    move/from16 v53, v14

    .line 191
    iget-wide v13, v9, Lub2;->T:J

    .line 192
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v11

    .line 193
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v13

    .line 194
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 195
    invoke-virtual {v9}, Lub2;->e0()V

    .line 196
    iget-boolean v14, v9, Lub2;->S:Z

    if-eqz v14, :cond_4d

    .line 197
    invoke-virtual {v9, v12}, Lub2;->l(Lfa2;)V

    goto :goto_2b

    .line 198
    :cond_4d
    invoke-virtual {v9}, Lub2;->n0()V

    .line 199
    :goto_2b
    invoke-static {v1, v9, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 200
    invoke-static {v2, v9, v13}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 201
    invoke-static {v11, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 202
    invoke-static {v8, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    move-object/from16 v14, v51

    .line 203
    invoke-virtual {v9, v14}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v0

    .line 204
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v10

    if-nez v0, :cond_4e

    if-ne v10, v6, :cond_4f

    .line 205
    :cond_4e
    new-instance v10, Lr95;

    const/16 v0, 0x9

    invoke-direct {v10, v14, v0}, Lr95;-><init>(Lfa2;B)V

    .line 206
    invoke-virtual {v9, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 207
    :cond_4f
    check-cast v10, Lqa2;

    invoke-static {v4, v10}, Lvv6;->M(Li14;Lqa2;)Li14;

    move-result-object v0

    move-object/from16 v15, v47

    .line 208
    invoke-virtual {v9, v15}, Lub2;->g(Ljava/lang/Object;)Z

    move-result v10

    .line 209
    invoke-virtual {v9}, Lub2;->N()Ljava/lang/Object;

    move-result-object v11

    if-nez v10, :cond_50

    if-ne v11, v6, :cond_51

    .line 210
    :cond_50
    new-instance v11, Lm50;

    const/16 v10, 0x16

    invoke-direct {v11, v15, v10}, Lm50;-><init>(Lqa2;B)V

    .line 211
    invoke-virtual {v9, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 212
    :cond_51
    check-cast v11, Lqa2;

    invoke-static {v0, v11}, Lif7;->K(Li14;Lqa2;)Li14;

    move-result-object v0

    .line 213
    sget-object v10, Lac7;->d:Ltv;

    .line 214
    sget-object v11, Lt6;->w:Lp20;

    const/4 v15, 0x0

    .line 215
    invoke-static {v10, v11, v9, v15}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    move-result-object v10

    .line 216
    iget-wide v13, v9, Lub2;->T:J

    .line 217
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v11

    .line 218
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v13

    .line 219
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 220
    invoke-virtual {v9}, Lub2;->e0()V

    .line 221
    iget-boolean v14, v9, Lub2;->S:Z

    if-eqz v14, :cond_52

    .line 222
    invoke-virtual {v9, v12}, Lub2;->l(Lfa2;)V

    goto :goto_2c

    .line 223
    :cond_52
    invoke-virtual {v9}, Lub2;->n0()V

    .line 224
    :goto_2c
    invoke-static {v1, v9, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 225
    invoke-static {v2, v9, v13}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 226
    invoke-static {v11, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 227
    invoke-static {v8, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    if-eqz p17, :cond_54

    const v0, 0x19cebb2c

    .line 228
    invoke-virtual {v9, v0}, Lub2;->b0(I)V

    .line 229
    invoke-interface/range {v49 .. v49}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lsv0;

    .line 230
    iget-wide v10, v0, Lsv0;->a:J

    move-object/from16 v0, v38

    .line 231
    invoke-virtual {v9, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v13

    .line 232
    check-cast v13, Lm37;

    .line 233
    iget-object v13, v13, Lm37;->k:Ldy4;

    .line 234
    invoke-virtual {v13}, Ldy4;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lk37;

    .line 235
    iget-object v13, v13, Lk37;->a:Lqk6;

    .line 236
    iget-wide v13, v13, Lqk6;->b:J

    .line 237
    sget-object v20, Lc92;->k:Lc92;

    shr-int/lit8 v15, v45, 0xc

    and-int/lit8 v15, v15, 0xe

    or-int v33, v15, v37

    const/16 v34, 0x0

    const v35, 0x3ffaa

    const/4 v15, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v32, v9

    move-wide/from16 v16, v10

    move-wide/from16 v18, v13

    move/from16 v9, v53

    move-object/from16 v14, p18

    .line 238
    invoke-static/range {v14 .. v35}, Lzs6;->c(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    move-object/from16 v10, v32

    .line 239
    invoke-virtual/range {p7 .. p7}, Ljava/lang/String;->length()I

    move-result v11

    if-lez v11, :cond_53

    const v11, 0x19d3ed25

    invoke-virtual {v10, v11}, Lub2;->b0(I)V

    .line 240
    invoke-interface/range {v50 .. v50}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lsv0;

    .line 241
    iget-wide v13, v11, Lsv0;->a:J

    .line 242
    invoke-virtual {v10, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v11

    .line 243
    check-cast v11, Lm37;

    .line 244
    invoke-virtual {v11}, Lm37;->c()Lk37;

    move-result-object v31

    shr-int/lit8 v11, v44, 0xc

    and-int/lit8 v33, v11, 0xe

    const/16 v34, 0x0

    const v35, 0x1fffa

    const/4 v15, 0x0

    const-wide/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object/from16 v32, v10

    move-wide/from16 v16, v13

    move-object/from16 v14, p7

    .line 245
    invoke-static/range {v14 .. v35}, Lzs6;->c(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    const/4 v15, 0x0

    .line 246
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    goto :goto_2d

    :cond_53
    const/4 v15, 0x0

    const v11, 0x19d7ea35

    .line 247
    invoke-virtual {v10, v11}, Lub2;->b0(I)V

    .line 248
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    .line 249
    :goto_2d
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    :goto_2e
    const/4 v15, 0x1

    goto :goto_2f

    :cond_54
    move-object v10, v9

    move-object/from16 v0, v38

    move/from16 v9, v53

    const/4 v15, 0x0

    const v11, 0x19d83f75

    .line 250
    invoke-virtual {v10, v11}, Lub2;->b0(I)V

    .line 251
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    goto :goto_2e

    .line 252
    :goto_2f
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    .line 253
    invoke-virtual {v10, v15}, Lub2;->r(Z)V

    .line 254
    invoke-virtual/range {p7 .. p7}, Ljava/lang/String;->length()I

    move-result v11

    if-lez v11, :cond_59

    const v11, -0x58ddcb66

    invoke-virtual {v10, v11}, Lub2;->b0(I)V

    .line 255
    const-string v11, "smallSubtitle"

    invoke-static {v4, v11}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v11

    .line 256
    invoke-virtual {v10}, Lub2;->N()Ljava/lang/Object;

    move-result-object v13

    if-ne v13, v6, :cond_55

    .line 257
    new-instance v13, Le87;

    move-object/from16 v14, v36

    const/4 v15, 0x2

    invoke-direct {v13, v14, v15}, Le87;-><init>(Ln87;B)V

    .line 258
    invoke-virtual {v10, v13}, Lub2;->k0(Ljava/lang/Object;)V

    goto :goto_30

    :cond_55
    move-object/from16 v14, v36

    .line 259
    :goto_30
    check-cast v13, Lfa2;

    .line 260
    new-instance v15, Lqy6;

    move-object/from16 v36, v4

    const/16 v4, 0xa

    invoke-direct {v15, v13, v14, v4}, Lqy6;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    invoke-static {v11, v15}, Lvv6;->w(Li14;Lqa2;)Li14;

    move-result-object v4

    move-object/from16 v11, v55

    .line 261
    invoke-virtual {v10, v11}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v13

    const/high16 v14, 0x800000

    if-ne v9, v14, :cond_56

    const/4 v9, 0x1

    goto :goto_31

    :cond_56
    const/4 v9, 0x0

    :goto_31
    or-int/2addr v13, v9

    move-object/from16 v14, v54

    invoke-virtual {v10, v14}, Lub2;->i(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v13, v9

    .line 262
    invoke-virtual {v10}, Lub2;->N()Ljava/lang/Object;

    move-result-object v9

    if-nez v13, :cond_57

    if-eq v9, v6, :cond_57

    const/4 v15, 0x0

    goto :goto_32

    .line 263
    :cond_57
    new-instance v9, Lb87;

    const/4 v15, 0x0

    invoke-direct {v9, v11, v3, v14, v15}, Lb87;-><init>(Lng;Lfa2;Lng;B)V

    .line 264
    invoke-virtual {v10, v9}, Lub2;->k0(Ljava/lang/Object;)V

    .line 265
    :goto_32
    check-cast v9, Lqa2;

    invoke-static {v4, v9}, Lv23;->s(Li14;Lqa2;)Li14;

    move-result-object v4

    .line 266
    invoke-static {v7, v15}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v6

    .line 267
    iget-wide v13, v10, Lub2;->T:J

    .line 268
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v9

    .line 269
    invoke-virtual {v10}, Lub2;->m()Lh05;

    move-result-object v11

    .line 270
    invoke-static {v10, v4}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v4

    .line 271
    invoke-virtual {v10}, Lub2;->e0()V

    .line 272
    iget-boolean v13, v10, Lub2;->S:Z

    if-eqz v13, :cond_58

    .line 273
    invoke-virtual {v10, v12}, Lub2;->l(Lfa2;)V

    goto :goto_33

    .line 274
    :cond_58
    invoke-virtual {v10}, Lub2;->n0()V

    .line 275
    :goto_33
    invoke-static {v1, v10, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 276
    invoke-static {v2, v10, v11}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 277
    invoke-static {v9, v10, v5, v10}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 278
    invoke-static {v8, v10, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 279
    invoke-interface/range {v50 .. v50}, Lmm6;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lsv0;

    .line 280
    iget-wide v13, v4, Lsv0;->a:J

    .line 281
    invoke-virtual {v10, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    move-result-object v0

    .line 282
    check-cast v0, Lm37;

    .line 283
    invoke-virtual {v0}, Lm37;->c()Lk37;

    move-result-object v31

    shr-int/lit8 v44, v44, 0xc

    and-int/lit8 v33, v44, 0xe

    const/16 v34, 0x0

    const v35, 0x1fffa

    const/4 v15, 0x0

    const-wide/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const-wide/16 v22, 0x0

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object/from16 v32, v10

    move-wide/from16 v16, v13

    move-object/from16 v14, p7

    .line 284
    invoke-static/range {v14 .. v35}, Lzs6;->c(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    move-object/from16 v9, v32

    const/4 v15, 0x1

    .line 285
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    const/4 v15, 0x0

    .line 286
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    goto :goto_34

    :cond_59
    move-object/from16 v36, v4

    move-object v9, v10

    const/4 v15, 0x0

    const v0, -0x58d42cd6

    .line 287
    invoke-virtual {v9, v0}, Lub2;->b0(I)V

    .line 288
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    .line 289
    :goto_34
    const-string v0, "bottomContent"

    move-object/from16 v4, v36

    invoke-static {v4, v0}, Lr71;->A(Li14;Ljava/lang/Object;)Li14;

    move-result-object v0

    .line 290
    invoke-static {v7, v15}, Lnb0;->c(Lr20;Z)Lis3;

    move-result-object v4

    .line 291
    iget-wide v6, v9, Lub2;->T:J

    .line 292
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    move-result v6

    .line 293
    invoke-virtual {v9}, Lub2;->m()Lh05;

    move-result-object v7

    .line 294
    invoke-static {v9, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    move-result-object v0

    .line 295
    invoke-virtual {v9}, Lub2;->e0()V

    .line 296
    iget-boolean v10, v9, Lub2;->S:Z

    if-eqz v10, :cond_5a

    .line 297
    invoke-virtual {v9, v12}, Lub2;->l(Lfa2;)V

    goto :goto_35

    .line 298
    :cond_5a
    invoke-virtual {v9}, Lub2;->n0()V

    .line 299
    :goto_35
    invoke-static {v1, v9, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 300
    invoke-static {v2, v9, v7}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 301
    invoke-static {v6, v9, v5, v9}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 302
    invoke-static {v8, v9, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    shr-int/lit8 v2, v45, 0x18

    and-int/lit8 v2, v2, 0xe

    .line 303
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v8, p22

    invoke-interface {v8, v9, v0}, Lua2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v15, 0x1

    .line 304
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    .line 305
    invoke-virtual {v9, v15}, Lub2;->r(Z)V

    goto :goto_36

    :cond_5b
    move-object v3, v7

    .line 306
    invoke-virtual {v9}, Lub2;->V()V

    .line 307
    :goto_36
    invoke-virtual {v9}, Lub2;->t()Lkk5;

    move-result-object v0

    if-eqz v0, :cond_5c

    move-object v1, v0

    new-instance v0, Lc87;

    move-wide/from16 v4, p3

    move-wide/from16 v6, p5

    move-wide/from16 v9, p8

    move-object/from16 v11, p10

    move-object/from16 v12, p11

    move/from16 v13, p12

    move/from16 v14, p13

    move/from16 v15, p14

    move-object/from16 v16, p15

    move-object/from16 v17, p16

    move/from16 v18, p17

    move-object/from16 v19, p18

    move/from16 v20, p19

    move/from16 v21, p20

    move/from16 v24, p24

    move/from16 v25, p25

    move-object/from16 v56, v1

    move-object/from16 v22, v3

    move-object/from16 v23, v8

    move-object/from16 v1, p0

    move-wide/from16 v2, p1

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v25}, Lc87;-><init>(Ljava/lang/String;JJJLjava/lang/String;JLc01;Lc01;FFFLt12;Li14;ZLjava/lang/String;FZLfa2;Lua2;II)V

    move-object/from16 v1, v56

    .line 308
    iput-object v0, v1, Lkk5;->d:Lua2;

    :cond_5c
    return-void
.end method

.method public static final f(Lvk5;Lvk5;Lvk5;I)Z
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    invoke-static {v3, v2, v0}, Lat6;->g(ILvk5;Lvk5;)Z

    .line 10
    .line 11
    .line 12
    move-result v4

    .line 13
    iget v5, v2, Lvk5;->b:F

    .line 14
    .line 15
    iget v6, v2, Lvk5;->d:F

    .line 16
    .line 17
    iget v7, v2, Lvk5;->a:F

    .line 18
    .line 19
    iget v2, v2, Lvk5;->c:F

    .line 20
    .line 21
    iget v8, v0, Lvk5;->d:F

    .line 22
    .line 23
    iget v9, v0, Lvk5;->b:F

    .line 24
    .line 25
    iget v10, v0, Lvk5;->c:F

    .line 26
    .line 27
    iget v11, v0, Lvk5;->a:F

    .line 28
    .line 29
    const/4 v12, 0x0

    .line 30
    if-nez v4, :cond_12

    .line 31
    .line 32
    invoke-static {v3, v1, v0}, Lat6;->g(ILvk5;Lvk5;)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_12

    .line 37
    .line 38
    const-string v4, "This function should only be used for 2-D focus search"

    .line 39
    .line 40
    const/4 v13, 0x6

    .line 41
    const/4 v14, 0x5

    .line 42
    const/4 v15, 0x4

    .line 43
    const/16 p0, 0x1

    .line 44
    .line 45
    const/4 v0, 0x3

    .line 46
    if-ne v3, v0, :cond_0

    .line 47
    .line 48
    cmpl-float v16, v11, v2

    .line 49
    .line 50
    if-ltz v16, :cond_10

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    if-ne v3, v15, :cond_1

    .line 54
    .line 55
    cmpg-float v16, v10, v7

    .line 56
    .line 57
    if-gtz v16, :cond_10

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_1
    if-ne v3, v14, :cond_2

    .line 61
    .line 62
    cmpl-float v16, v9, v6

    .line 63
    .line 64
    if-ltz v16, :cond_10

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_2
    if-ne v3, v13, :cond_11

    .line 68
    .line 69
    cmpg-float v16, v8, v5

    .line 70
    .line 71
    if-gtz v16, :cond_10

    .line 72
    .line 73
    :goto_0
    if-eq v3, v0, :cond_3

    .line 74
    .line 75
    if-ne v3, v15, :cond_4

    .line 76
    .line 77
    :cond_3
    return p0

    .line 78
    :cond_4
    if-ne v3, v0, :cond_5

    .line 79
    .line 80
    iget v1, v1, Lvk5;->c:F

    .line 81
    .line 82
    sub-float v1, v11, v1

    .line 83
    .line 84
    goto :goto_1

    .line 85
    :cond_5
    if-ne v3, v15, :cond_6

    .line 86
    .line 87
    iget v1, v1, Lvk5;->a:F

    .line 88
    .line 89
    sub-float/2addr v1, v10

    .line 90
    goto :goto_1

    .line 91
    :cond_6
    if-ne v3, v14, :cond_7

    .line 92
    .line 93
    iget v1, v1, Lvk5;->d:F

    .line 94
    .line 95
    sub-float v1, v9, v1

    .line 96
    .line 97
    goto :goto_1

    .line 98
    :cond_7
    if-ne v3, v13, :cond_f

    .line 99
    .line 100
    iget v1, v1, Lvk5;->b:F

    .line 101
    .line 102
    sub-float/2addr v1, v8

    .line 103
    :goto_1
    const/16 v16, 0x0

    .line 104
    .line 105
    cmpg-float v17, v1, v16

    .line 106
    .line 107
    if-gez v17, :cond_8

    .line 108
    .line 109
    move/from16 v1, v16

    .line 110
    .line 111
    :cond_8
    if-ne v3, v0, :cond_9

    .line 112
    .line 113
    sub-float/2addr v11, v7

    .line 114
    goto :goto_2

    .line 115
    :cond_9
    if-ne v3, v15, :cond_a

    .line 116
    .line 117
    sub-float v11, v2, v10

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_a
    if-ne v3, v14, :cond_b

    .line 121
    .line 122
    sub-float v11, v9, v5

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_b
    if-ne v3, v13, :cond_e

    .line 126
    .line 127
    sub-float v11, v6, v8

    .line 128
    .line 129
    :goto_2
    const/high16 v0, 0x3f800000    # 1.0f

    .line 130
    .line 131
    cmpg-float v2, v11, v0

    .line 132
    .line 133
    if-gez v2, :cond_c

    .line 134
    .line 135
    move v11, v0

    .line 136
    :cond_c
    cmpg-float v0, v1, v11

    .line 137
    .line 138
    if-gez v0, :cond_d

    .line 139
    .line 140
    return p0

    .line 141
    :cond_d
    return v12

    .line 142
    :cond_e
    invoke-static {v4}, Lj02;->c(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    return v12

    .line 146
    :cond_f
    invoke-static {v4}, Lj02;->c(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    return v12

    .line 150
    :cond_10
    return p0

    .line 151
    :cond_11
    invoke-static {v4}, Lj02;->c(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    :cond_12
    return v12
.end method

.method public static final g(ILvk5;Lvk5;)Z
    .locals 3

    .line 1
    const/4 v0, 0x3

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x1

    .line 4
    if-eq p0, v0, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x4

    .line 7
    if-ne p0, v0, :cond_2

    .line 8
    .line 9
    :cond_0
    iget p0, p1, Lvk5;->d:F

    .line 10
    .line 11
    iget v0, p2, Lvk5;->b:F

    .line 12
    .line 13
    cmpl-float p0, p0, v0

    .line 14
    .line 15
    if-lez p0, :cond_1

    .line 16
    .line 17
    iget p0, p1, Lvk5;->b:F

    .line 18
    .line 19
    iget p1, p2, Lvk5;->d:F

    .line 20
    .line 21
    cmpg-float p0, p0, p1

    .line 22
    .line 23
    if-gez p0, :cond_1

    .line 24
    .line 25
    return v2

    .line 26
    :cond_1
    return v1

    .line 27
    :cond_2
    const/4 v0, 0x5

    .line 28
    if-eq p0, v0, :cond_3

    .line 29
    .line 30
    const/4 v0, 0x6

    .line 31
    if-ne p0, v0, :cond_5

    .line 32
    .line 33
    :cond_3
    iget p0, p1, Lvk5;->c:F

    .line 34
    .line 35
    iget v0, p2, Lvk5;->a:F

    .line 36
    .line 37
    cmpl-float p0, p0, v0

    .line 38
    .line 39
    if-lez p0, :cond_4

    .line 40
    .line 41
    iget p0, p1, Lvk5;->a:F

    .line 42
    .line 43
    iget p1, p2, Lvk5;->c:F

    .line 44
    .line 45
    cmpg-float p0, p0, p1

    .line 46
    .line 47
    if-gez p0, :cond_4

    .line 48
    .line 49
    return v2

    .line 50
    :cond_4
    return v1

    .line 51
    :cond_5
    const-string p0, "This function should only be used for 2-D focus search"

    .line 52
    .line 53
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    return v1
.end method

.method public static final h(F)I
    .locals 2

    .line 1
    float-to-double v0, p0

    .line 2
    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    .line 3
    .line 4
    .line 5
    move-result-wide v0

    .line 6
    double-to-float p0, v0

    .line 7
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public static final i(Lv72;Ly44;)V
    .locals 9

    .line 1
    iget-object v0, p0, Lh14;->i:Lh14;

    .line 2
    .line 3
    iget-boolean v0, v0, Lh14;->v:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const-string v0, "visitChildren called on an unattached node"

    .line 8
    .line 9
    invoke-static {v0}, Lwy2;->b(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    new-instance v0, Ly44;

    .line 13
    .line 14
    const/16 v1, 0x10

    .line 15
    .line 16
    new-array v2, v1, [Lh14;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-direct {v0, v3, v2}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object p0, p0, Lh14;->i:Lh14;

    .line 23
    .line 24
    iget-object v2, p0, Lh14;->n:Lh14;

    .line 25
    .line 26
    if-nez v2, :cond_1

    .line 27
    .line 28
    invoke-static {v0, p0}, Lgj;->l(Ly44;Lh14;)V

    .line 29
    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    invoke-virtual {v0, v2}, Ly44;->b(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_2
    :goto_0
    iget p0, v0, Ly44;->k:I

    .line 36
    .line 37
    if-eqz p0, :cond_e

    .line 38
    .line 39
    add-int/lit8 p0, p0, -0x1

    .line 40
    .line 41
    invoke-virtual {v0, p0}, Ly44;->k(I)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    check-cast p0, Lh14;

    .line 46
    .line 47
    iget v2, p0, Lh14;->l:I

    .line 48
    .line 49
    and-int/lit16 v2, v2, 0x400

    .line 50
    .line 51
    if-nez v2, :cond_3

    .line 52
    .line 53
    invoke-static {v0, p0}, Lgj;->l(Ly44;Lh14;)V

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_3
    :goto_1
    if-eqz p0, :cond_2

    .line 58
    .line 59
    iget v2, p0, Lh14;->k:I

    .line 60
    .line 61
    and-int/lit16 v2, v2, 0x400

    .line 62
    .line 63
    if-eqz v2, :cond_d

    .line 64
    .line 65
    const/4 v2, 0x0

    .line 66
    move-object v4, v2

    .line 67
    :cond_4
    :goto_2
    if-eqz p0, :cond_2

    .line 68
    .line 69
    instance-of v5, p0, Lv72;

    .line 70
    .line 71
    if-eqz v5, :cond_6

    .line 72
    .line 73
    check-cast p0, Lv72;

    .line 74
    .line 75
    iget-boolean v5, p0, Lh14;->v:Z

    .line 76
    .line 77
    if-eqz v5, :cond_c

    .line 78
    .line 79
    invoke-static {p0}, Lgj;->Z(Lhl1;)Lja3;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    iget-boolean v5, v5, Lja3;->Y:Z

    .line 84
    .line 85
    if-nez v5, :cond_c

    .line 86
    .line 87
    invoke-virtual {p0}, Lv72;->I1()Lh72;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    iget-boolean v5, v5, Lh72;->a:Z

    .line 92
    .line 93
    if-eqz v5, :cond_5

    .line 94
    .line 95
    invoke-virtual {p1, p0}, Ly44;->b(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    goto :goto_5

    .line 99
    :cond_5
    invoke-static {p0, p1}, Lat6;->i(Lv72;Ly44;)V

    .line 100
    .line 101
    .line 102
    goto :goto_5

    .line 103
    :cond_6
    iget v5, p0, Lh14;->k:I

    .line 104
    .line 105
    and-int/lit16 v5, v5, 0x400

    .line 106
    .line 107
    if-eqz v5, :cond_c

    .line 108
    .line 109
    instance-of v5, p0, Lil1;

    .line 110
    .line 111
    if-eqz v5, :cond_c

    .line 112
    .line 113
    move-object v5, p0

    .line 114
    check-cast v5, Lil1;

    .line 115
    .line 116
    iget-object v5, v5, Lil1;->x:Lh14;

    .line 117
    .line 118
    move v6, v3

    .line 119
    :goto_3
    const/4 v7, 0x1

    .line 120
    if-eqz v5, :cond_b

    .line 121
    .line 122
    iget v8, v5, Lh14;->k:I

    .line 123
    .line 124
    and-int/lit16 v8, v8, 0x400

    .line 125
    .line 126
    if-eqz v8, :cond_a

    .line 127
    .line 128
    add-int/lit8 v6, v6, 0x1

    .line 129
    .line 130
    if-ne v6, v7, :cond_7

    .line 131
    .line 132
    move-object p0, v5

    .line 133
    goto :goto_4

    .line 134
    :cond_7
    if-nez v4, :cond_8

    .line 135
    .line 136
    new-instance v4, Ly44;

    .line 137
    .line 138
    new-array v7, v1, [Lh14;

    .line 139
    .line 140
    invoke-direct {v4, v3, v7}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    :cond_8
    if-eqz p0, :cond_9

    .line 144
    .line 145
    invoke-virtual {v4, p0}, Ly44;->b(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    move-object p0, v2

    .line 149
    :cond_9
    invoke-virtual {v4, v5}, Ly44;->b(Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    :cond_a
    :goto_4
    iget-object v5, v5, Lh14;->n:Lh14;

    .line 153
    .line 154
    goto :goto_3

    .line 155
    :cond_b
    if-eq v6, v7, :cond_4

    .line 156
    .line 157
    :cond_c
    :goto_5
    invoke-static {v4}, Lgj;->N(Ly44;)Lh14;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    goto :goto_2

    .line 162
    :cond_d
    iget-object p0, p0, Lh14;->n:Lh14;

    .line 163
    .line 164
    goto :goto_1

    .line 165
    :cond_e
    return-void
.end method

.method public static j(Ljava/lang/CharSequence;)J
    .locals 6

    .line 1
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    move v1, v0

    .line 6
    move v2, v1

    .line 7
    :goto_0
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    if-ge v0, v3, :cond_2

    .line 12
    .line 13
    invoke-interface {p0, v0}, Ljava/lang/CharSequence;->charAt(I)C

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    const/16 v4, 0x9

    .line 18
    .line 19
    if-eq v3, v4, :cond_0

    .line 20
    .line 21
    const/16 v5, 0x20

    .line 22
    .line 23
    if-ne v3, v5, :cond_2

    .line 24
    .line 25
    :cond_0
    if-ne v3, v4, :cond_1

    .line 26
    .line 27
    add-int/lit8 v2, v2, 0x1

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 31
    .line 32
    :goto_1
    add-int/lit8 v0, v0, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_2
    invoke-static {v1, v2}, Lsq;->g0(II)J

    .line 36
    .line 37
    .line 38
    move-result-wide v0

    .line 39
    return-wide v0
.end method

.method public static k(IIZ)Ljava/lang/String;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    if-eqz p2, :cond_0

    .line 7
    .line 8
    div-int p2, p0, p1

    .line 9
    .line 10
    rem-int/2addr p0, p1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    move p2, v0

    .line 13
    :goto_0
    new-instance p1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 16
    .line 17
    .line 18
    move v1, v0

    .line 19
    :goto_1
    if-ge v1, p2, :cond_1

    .line 20
    .line 21
    const/16 v2, 0x9

    .line 22
    .line 23
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    add-int/lit8 v1, v1, 0x1

    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_1
    :goto_2
    if-ge v0, p0, :cond_2

    .line 30
    .line 31
    const/16 p2, 0x20

    .line 32
    .line 33
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    add-int/lit8 v0, v0, 0x1

    .line 37
    .line 38
    goto :goto_2

    .line 39
    :cond_2
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method

.method public static l(Lub2;)Lrn7;
    .locals 4

    .line 1
    sget-object v0, Lhb;->f:Lyt1;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/view/View;

    .line 8
    .line 9
    invoke-static {v0}, Lat6;->s(Landroid/view/View;)Lrn7;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {p0, v1}, Lub2;->i(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    invoke-virtual {p0, v0}, Lub2;->i(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    or-int/2addr v2, v3

    .line 22
    invoke-virtual {p0}, Lub2;->N()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    if-nez v2, :cond_0

    .line 27
    .line 28
    sget-object v2, Li21;->a:Ls9;

    .line 29
    .line 30
    if-ne v3, v2, :cond_1

    .line 31
    .line 32
    :cond_0
    new-instance v3, Lqy6;

    .line 33
    .line 34
    const/16 v2, 0x12

    .line 35
    .line 36
    invoke-direct {v3, v1, v0, v2}, Lqy6;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    check-cast v3, Lqa2;

    .line 43
    .line 44
    invoke-static {v1, v3, p0}, Lac7;->e(Ljava/lang/Object;Lqa2;Lub2;)V

    .line 45
    .line 46
    .line 47
    return-object v1
.end method

.method public static m()Ljava/lang/reflect/InvocationHandler;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {}, Landroid/webkit/WebView;->getWebViewClassLoader()Ljava/lang/ClassLoader;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const-string v2, "org.chromium.support_lib_glue.SupportLibReflectionUtil"

    .line 7
    .line 8
    invoke-static {v2, v0, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v1, "createWebViewProviderFactory"

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0, v2, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Ljava/lang/reflect/InvocationHandler;

    .line 24
    .line 25
    return-object v0
.end method

.method public static final n(Ly44;Lvk5;I)Lv72;
    .locals 7

    .line 1
    const/4 v0, 0x3

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    const/high16 v3, 0x3f800000    # 1.0f

    .line 5
    .line 6
    if-ne p2, v0, :cond_0

    .line 7
    .line 8
    iget v0, p1, Lvk5;->c:F

    .line 9
    .line 10
    iget v4, p1, Lvk5;->a:F

    .line 11
    .line 12
    sub-float/2addr v0, v4

    .line 13
    add-float/2addr v0, v3

    .line 14
    invoke-virtual {p1, v0, v2}, Lvk5;->j(FF)Lvk5;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v0, 0x4

    .line 20
    if-ne p2, v0, :cond_1

    .line 21
    .line 22
    iget v0, p1, Lvk5;->c:F

    .line 23
    .line 24
    iget v4, p1, Lvk5;->a:F

    .line 25
    .line 26
    sub-float/2addr v0, v4

    .line 27
    add-float/2addr v0, v3

    .line 28
    neg-float v0, v0

    .line 29
    invoke-virtual {p1, v0, v2}, Lvk5;->j(FF)Lvk5;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    goto :goto_0

    .line 34
    :cond_1
    const/4 v0, 0x5

    .line 35
    if-ne p2, v0, :cond_2

    .line 36
    .line 37
    iget v0, p1, Lvk5;->d:F

    .line 38
    .line 39
    iget v4, p1, Lvk5;->b:F

    .line 40
    .line 41
    sub-float/2addr v0, v4

    .line 42
    add-float/2addr v0, v3

    .line 43
    invoke-virtual {p1, v2, v0}, Lvk5;->j(FF)Lvk5;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/4 v0, 0x6

    .line 49
    if-ne p2, v0, :cond_5

    .line 50
    .line 51
    iget v0, p1, Lvk5;->d:F

    .line 52
    .line 53
    iget v4, p1, Lvk5;->b:F

    .line 54
    .line 55
    sub-float/2addr v0, v4

    .line 56
    add-float/2addr v0, v3

    .line 57
    neg-float v0, v0

    .line 58
    invoke-virtual {p1, v2, v0}, Lvk5;->j(FF)Lvk5;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    :goto_0
    iget-object v2, p0, Ly44;->i:[Ljava/lang/Object;

    .line 63
    .line 64
    iget p0, p0, Ly44;->k:I

    .line 65
    .line 66
    const/4 v3, 0x0

    .line 67
    :goto_1
    if-ge v3, p0, :cond_4

    .line 68
    .line 69
    aget-object v4, v2, v3

    .line 70
    .line 71
    check-cast v4, Lv72;

    .line 72
    .line 73
    invoke-static {v4}, Lom;->T(Lv72;)Z

    .line 74
    .line 75
    .line 76
    move-result v5

    .line 77
    if-eqz v5, :cond_3

    .line 78
    .line 79
    invoke-static {v4}, Lom;->F(Lv72;)Lvk5;

    .line 80
    .line 81
    .line 82
    move-result-object v5

    .line 83
    invoke-static {v5, v0, p1, p2}, Lat6;->v(Lvk5;Lvk5;Lvk5;I)Z

    .line 84
    .line 85
    .line 86
    move-result v6

    .line 87
    if-eqz v6, :cond_3

    .line 88
    .line 89
    move-object v1, v4

    .line 90
    move-object v0, v5

    .line 91
    :cond_3
    add-int/lit8 v3, v3, 0x1

    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_4
    return-object v1

    .line 95
    :cond_5
    const-string p0, "This function should only be used for 2-D focus search"

    .line 96
    .line 97
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    return-object v1
.end method

.method public static final o(Lv72;ILqa2;)Z
    .locals 4

    .line 1
    new-instance v0, Ly44;

    .line 2
    .line 3
    const/16 v1, 0x10

    .line 4
    .line 5
    new-array v1, v1, [Lv72;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-direct {v0, v2, v1}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    invoke-static {p0, v0}, Lat6;->i(Lv72;Ly44;)V

    .line 12
    .line 13
    .line 14
    iget v1, v0, Ly44;->k:I

    .line 15
    .line 16
    const/4 v3, 0x1

    .line 17
    if-gt v1, v3, :cond_1

    .line 18
    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    iget-object p0, v0, Ly44;->i:[Ljava/lang/Object;

    .line 24
    .line 25
    aget-object p0, p0, v2

    .line 26
    .line 27
    :goto_0
    check-cast p0, Lv72;

    .line 28
    .line 29
    if-eqz p0, :cond_6

    .line 30
    .line 31
    invoke-interface {p2, p0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    check-cast p0, Ljava/lang/Boolean;

    .line 36
    .line 37
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    return p0

    .line 42
    :cond_1
    const/4 v1, 0x7

    .line 43
    const/4 v3, 0x4

    .line 44
    if-ne p1, v1, :cond_2

    .line 45
    .line 46
    move p1, v3

    .line 47
    :cond_2
    if-eq p1, v3, :cond_3

    .line 48
    .line 49
    const/4 v1, 0x6

    .line 50
    if-ne p1, v1, :cond_4

    .line 51
    .line 52
    :cond_3
    invoke-static {p0}, Lom;->F(Lv72;)Lvk5;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    new-instance v1, Lvk5;

    .line 57
    .line 58
    iget v3, p0, Lvk5;->a:F

    .line 59
    .line 60
    iget p0, p0, Lvk5;->b:F

    .line 61
    .line 62
    invoke-direct {v1, v3, p0, v3, p0}, Lvk5;-><init>(FFFF)V

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_4
    const/4 v1, 0x3

    .line 67
    if-eq p1, v1, :cond_5

    .line 68
    .line 69
    const/4 v1, 0x5

    .line 70
    if-ne p1, v1, :cond_7

    .line 71
    .line 72
    :cond_5
    invoke-static {p0}, Lom;->F(Lv72;)Lvk5;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    new-instance v1, Lvk5;

    .line 77
    .line 78
    iget v3, p0, Lvk5;->c:F

    .line 79
    .line 80
    iget p0, p0, Lvk5;->d:F

    .line 81
    .line 82
    invoke-direct {v1, v3, p0, v3, p0}, Lvk5;-><init>(FFFF)V

    .line 83
    .line 84
    .line 85
    :goto_1
    invoke-static {v0, v1, p1}, Lat6;->n(Ly44;Lvk5;I)Lv72;

    .line 86
    .line 87
    .line 88
    move-result-object p0

    .line 89
    if-eqz p0, :cond_6

    .line 90
    .line 91
    invoke-interface {p2, p0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p0

    .line 95
    check-cast p0, Ljava/lang/Boolean;

    .line 96
    .line 97
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 98
    .line 99
    .line 100
    move-result p0

    .line 101
    return p0

    .line 102
    :cond_6
    return v2

    .line 103
    :cond_7
    const-string p0, "This function should only be used for 2-D focus search"

    .line 104
    .line 105
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    return v2
.end method

.method public static p(Lp91;II)J
    .locals 3

    .line 1
    :goto_0
    const/16 v0, 0x20

    .line 2
    .line 3
    const/16 v1, 0x9

    .line 4
    .line 5
    if-ge p1, p2, :cond_1

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Lp91;->charAt(I)C

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eq v2, v1, :cond_0

    .line 12
    .line 13
    if-ne v2, v0, :cond_1

    .line 14
    .line 15
    :cond_0
    add-int/lit8 p1, p1, 0x1

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_1
    if-eq p1, p2, :cond_3

    .line 19
    .line 20
    :goto_1
    if-lez p2, :cond_3

    .line 21
    .line 22
    add-int/lit8 v2, p2, -0x1

    .line 23
    .line 24
    invoke-virtual {p0, v2}, Lp91;->charAt(I)C

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eq v2, v1, :cond_2

    .line 29
    .line 30
    if-ne v2, v0, :cond_3

    .line 31
    .line 32
    :cond_2
    add-int/lit8 p2, p2, -0x1

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_3
    invoke-static {p1, p2}, Lsq;->g0(II)J

    .line 36
    .line 37
    .line 38
    move-result-wide p0

    .line 39
    return-wide p0
.end method

.method public static final q(ILwf;Lv72;Lvk5;)Z
    .locals 8

    .line 1
    invoke-static {p0, p1, p2, p3}, Lat6;->y(ILwf;Lv72;Lvk5;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_0
    invoke-static {p2}, Lgj;->a0(Lhl1;)Lra;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {v0}, Lra;->getFocusOwner()Lb72;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Le72;

    .line 18
    .line 19
    invoke-virtual {v0}, Le72;->h()Lv72;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    new-instance v1, Lyn4;

    .line 24
    .line 25
    const/4 v7, 0x1

    .line 26
    move v5, p0

    .line 27
    move-object v6, p1

    .line 28
    move-object v3, p2

    .line 29
    move-object v4, p3

    .line 30
    invoke-direct/range {v1 .. v7}, Lyn4;-><init>(Lv72;Lv72;Ljava/lang/Object;ILwf;B)V

    .line 31
    .line 32
    .line 33
    invoke-static {v3, v5, v1}, Lin;->O(Lv72;ILqa2;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    check-cast p0, Ljava/lang/Boolean;

    .line 38
    .line 39
    if-eqz p0, :cond_1

    .line 40
    .line 41
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    return p0

    .line 46
    :cond_1
    const/4 p0, 0x0

    .line 47
    return p0
.end method

.method public static final r(Landroid/view/View;)Lpi7;
    .locals 3

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    :goto_0
    const/4 v0, 0x0

    .line 5
    if-eqz p0, :cond_3

    .line 6
    .line 7
    const v1, 0x7f0900e5

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    instance-of v2, v1, Lpi7;

    .line 15
    .line 16
    if-eqz v2, :cond_0

    .line 17
    .line 18
    check-cast v1, Lpi7;

    .line 19
    .line 20
    goto :goto_1

    .line 21
    :cond_0
    move-object v1, v0

    .line 22
    :goto_1
    if-eqz v1, :cond_1

    .line 23
    .line 24
    return-object v1

    .line 25
    :cond_1
    invoke-static {p0}, Lis6;->o(Landroid/view/View;)Landroid/view/ViewParent;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    instance-of v1, p0, Landroid/view/View;

    .line 30
    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    check-cast p0, Landroid/view/View;

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_2
    move-object p0, v0

    .line 37
    goto :goto_0

    .line 38
    :cond_3
    return-object v0
.end method

.method public static s(Landroid/view/View;)Lrn7;
    .locals 2

    .line 1
    sget-object v0, Lrn7;->w:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    invoke-virtual {v0, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    if-nez v1, :cond_0

    .line 9
    .line 10
    new-instance v1, Lrn7;

    .line 11
    .line 12
    invoke-direct {v1, p0}, Lrn7;-><init>(Landroid/view/View;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, p0, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    :cond_0
    check-cast v1, Lrn7;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 19
    .line 20
    monitor-exit v0

    .line 21
    return-object v1

    .line 22
    :catchall_0
    move-exception p0

    .line 23
    monitor-exit v0

    .line 24
    throw p0
.end method

.method public static final t(Lr17;Landroid/text/Layout;Lyh2;ILandroid/graphics/RectF;Lb66;Lt;Z)I
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    move-object/from16 v4, p4

    .line 10
    .line 11
    move-object/from16 v5, p5

    .line 12
    .line 13
    move-object/from16 v6, p6

    .line 14
    .line 15
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineTop(I)I

    .line 16
    .line 17
    .line 18
    move-result v7

    .line 19
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineBottom(I)I

    .line 20
    .line 21
    .line 22
    move-result v8

    .line 23
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineStart(I)I

    .line 24
    .line 25
    .line 26
    move-result v9

    .line 27
    invoke-virtual {v1, v3}, Landroid/text/Layout;->getLineEnd(I)I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eq v9, v1, :cond_32

    .line 32
    .line 33
    sub-int/2addr v1, v9

    .line 34
    const/4 v11, 0x1

    .line 35
    shl-int/2addr v1, v11

    .line 36
    new-array v12, v1, [F

    .line 37
    .line 38
    iget-object v13, v0, Lr17;->f:Landroid/text/Layout;

    .line 39
    .line 40
    invoke-virtual {v13, v3}, Landroid/text/Layout;->getLineStart(I)I

    .line 41
    .line 42
    .line 43
    move-result v14

    .line 44
    invoke-virtual {v0, v3}, Lr17;->f(I)I

    .line 45
    .line 46
    .line 47
    move-result v15

    .line 48
    sub-int v16, v15, v14

    .line 49
    .line 50
    shl-int/lit8 v10, v16, 0x1

    .line 51
    .line 52
    if-ge v1, v10, :cond_0

    .line 53
    .line 54
    const-string v1, "array.size - arrayStart must be greater or equal than (endOffset - startOffset) * 2"

    .line 55
    .line 56
    invoke-static {v1}, Lxy2;->a(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    :cond_0
    new-instance v1, Lbt2;

    .line 60
    .line 61
    invoke-direct {v1, v0}, Lbt2;-><init>(Lr17;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v13, v3}, Landroid/text/Layout;->getParagraphDirection(I)I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    const/4 v10, 0x0

    .line 69
    if-ne v0, v11, :cond_1

    .line 70
    .line 71
    move v0, v11

    .line 72
    goto :goto_0

    .line 73
    :cond_1
    move v0, v10

    .line 74
    :goto_0
    move/from16 v16, v10

    .line 75
    .line 76
    :goto_1
    if-ge v14, v15, :cond_5

    .line 77
    .line 78
    invoke-virtual {v13, v14}, Landroid/text/Layout;->isRtlCharAt(I)Z

    .line 79
    .line 80
    .line 81
    move-result v17

    .line 82
    if-eqz v0, :cond_3

    .line 83
    .line 84
    if-nez v17, :cond_2

    .line 85
    .line 86
    invoke-virtual {v1, v14, v10, v10, v11}, Lbt2;->a(IZZZ)F

    .line 87
    .line 88
    .line 89
    move-result v17

    .line 90
    add-int/lit8 v10, v14, 0x1

    .line 91
    .line 92
    invoke-virtual {v1, v10, v11, v11, v11}, Lbt2;->a(IZZZ)F

    .line 93
    .line 94
    .line 95
    move-result v10

    .line 96
    move/from16 v18, v0

    .line 97
    .line 98
    goto :goto_3

    .line 99
    :cond_2
    const/4 v10, 0x0

    .line 100
    if-eqz v17, :cond_3

    .line 101
    .line 102
    invoke-virtual {v1, v14, v10, v10, v10}, Lbt2;->a(IZZZ)F

    .line 103
    .line 104
    .line 105
    move-result v17

    .line 106
    move/from16 v18, v0

    .line 107
    .line 108
    add-int/lit8 v0, v14, 0x1

    .line 109
    .line 110
    invoke-virtual {v1, v0, v11, v11, v10}, Lbt2;->a(IZZZ)F

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    move/from16 v10, v17

    .line 115
    .line 116
    move/from16 v17, v0

    .line 117
    .line 118
    goto :goto_3

    .line 119
    :cond_3
    move/from16 v18, v0

    .line 120
    .line 121
    if-eqz v17, :cond_4

    .line 122
    .line 123
    invoke-virtual {v1, v14, v10, v10, v11}, Lbt2;->a(IZZZ)F

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    add-int/lit8 v10, v14, 0x1

    .line 128
    .line 129
    invoke-virtual {v1, v10, v11, v11, v11}, Lbt2;->a(IZZZ)F

    .line 130
    .line 131
    .line 132
    move-result v17

    .line 133
    :goto_2
    move v10, v0

    .line 134
    goto :goto_3

    .line 135
    :cond_4
    invoke-virtual {v1, v14, v10, v10, v10}, Lbt2;->a(IZZZ)F

    .line 136
    .line 137
    .line 138
    move-result v17

    .line 139
    add-int/lit8 v0, v14, 0x1

    .line 140
    .line 141
    invoke-virtual {v1, v0, v11, v11, v10}, Lbt2;->a(IZZZ)F

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    goto :goto_2

    .line 146
    :goto_3
    aput v17, v12, v16

    .line 147
    .line 148
    add-int/lit8 v0, v16, 0x1

    .line 149
    .line 150
    aput v10, v12, v0

    .line 151
    .line 152
    add-int/lit8 v16, v16, 0x2

    .line 153
    .line 154
    add-int/lit8 v14, v14, 0x1

    .line 155
    .line 156
    move/from16 v0, v18

    .line 157
    .line 158
    const/4 v10, 0x0

    .line 159
    goto :goto_1

    .line 160
    :cond_5
    iget-object v0, v2, Lyh2;->a:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v0, Landroid/text/Layout;

    .line 163
    .line 164
    invoke-virtual {v0, v3}, Landroid/text/Layout;->getLineStart(I)I

    .line 165
    .line 166
    .line 167
    move-result v1

    .line 168
    invoke-virtual {v0, v3}, Landroid/text/Layout;->getLineEnd(I)I

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    const/4 v10, 0x0

    .line 173
    invoke-virtual {v2, v1, v10}, Lyh2;->p(IZ)I

    .line 174
    .line 175
    .line 176
    move-result v13

    .line 177
    invoke-virtual {v2, v13}, Lyh2;->q(I)I

    .line 178
    .line 179
    .line 180
    move-result v10

    .line 181
    sub-int v14, v1, v10

    .line 182
    .line 183
    sub-int v10, v3, v10

    .line 184
    .line 185
    invoke-virtual {v2, v13}, Lyh2;->d(I)Ljava/text/Bidi;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    if-eqz v2, :cond_7

    .line 190
    .line 191
    invoke-virtual {v2, v14, v10}, Ljava/text/Bidi;->createLineBidi(II)Ljava/text/Bidi;

    .line 192
    .line 193
    .line 194
    move-result-object v2

    .line 195
    if-eqz v2, :cond_7

    .line 196
    .line 197
    invoke-virtual {v2}, Ljava/text/Bidi;->getRunCount()I

    .line 198
    .line 199
    .line 200
    move-result v0

    .line 201
    new-array v3, v0, [Lu93;

    .line 202
    .line 203
    const/4 v10, 0x0

    .line 204
    :goto_4
    if-ge v10, v0, :cond_8

    .line 205
    .line 206
    new-instance v13, Lu93;

    .line 207
    .line 208
    invoke-virtual {v2, v10}, Ljava/text/Bidi;->getRunStart(I)I

    .line 209
    .line 210
    .line 211
    move-result v14

    .line 212
    add-int/2addr v14, v1

    .line 213
    invoke-virtual {v2, v10}, Ljava/text/Bidi;->getRunLimit(I)I

    .line 214
    .line 215
    .line 216
    move-result v15

    .line 217
    add-int/2addr v15, v1

    .line 218
    invoke-virtual {v2, v10}, Ljava/text/Bidi;->getRunLevel(I)I

    .line 219
    .line 220
    .line 221
    move-result v16

    .line 222
    move/from16 p2, v0

    .line 223
    .line 224
    rem-int/lit8 v0, v16, 0x2

    .line 225
    .line 226
    if-ne v0, v11, :cond_6

    .line 227
    .line 228
    move v0, v11

    .line 229
    goto :goto_5

    .line 230
    :cond_6
    const/4 v0, 0x0

    .line 231
    :goto_5
    invoke-direct {v13, v14, v15, v0}, Lu93;-><init>(IIZ)V

    .line 232
    .line 233
    .line 234
    aput-object v13, v3, v10

    .line 235
    .line 236
    add-int/lit8 v10, v10, 0x1

    .line 237
    .line 238
    move/from16 v0, p2

    .line 239
    .line 240
    goto :goto_4

    .line 241
    :cond_7
    new-instance v2, Lu93;

    .line 242
    .line 243
    invoke-virtual {v0, v1}, Landroid/text/Layout;->isRtlCharAt(I)Z

    .line 244
    .line 245
    .line 246
    move-result v0

    .line 247
    invoke-direct {v2, v1, v3, v0}, Lu93;-><init>(IIZ)V

    .line 248
    .line 249
    .line 250
    filled-new-array {v2}, [Lu93;

    .line 251
    .line 252
    .line 253
    move-result-object v3

    .line 254
    :cond_8
    if-eqz p7, :cond_9

    .line 255
    .line 256
    new-instance v0, Lb13;

    .line 257
    .line 258
    array-length v1, v3

    .line 259
    sub-int/2addr v1, v11

    .line 260
    const/4 v10, 0x0

    .line 261
    invoke-direct {v0, v10, v1, v11}, Lz03;-><init>(III)V

    .line 262
    .line 263
    .line 264
    goto :goto_6

    .line 265
    :cond_9
    const/4 v10, 0x0

    .line 266
    array-length v0, v3

    .line 267
    sub-int/2addr v0, v11

    .line 268
    new-instance v1, Lz03;

    .line 269
    .line 270
    const/4 v2, -0x1

    .line 271
    invoke-direct {v1, v0, v10, v2}, Lz03;-><init>(III)V

    .line 272
    .line 273
    .line 274
    move-object v0, v1

    .line 275
    :goto_6
    iget v1, v0, Lz03;->i:I

    .line 276
    .line 277
    iget v2, v0, Lz03;->j:I

    .line 278
    .line 279
    iget v0, v0, Lz03;->k:I

    .line 280
    .line 281
    if-lez v0, :cond_a

    .line 282
    .line 283
    if-le v1, v2, :cond_b

    .line 284
    .line 285
    :cond_a
    if-gez v0, :cond_32

    .line 286
    .line 287
    if-gt v2, v1, :cond_32

    .line 288
    .line 289
    :cond_b
    :goto_7
    aget-object v10, v3, v1

    .line 290
    .line 291
    iget-boolean v13, v10, Lu93;->c:Z

    .line 292
    .line 293
    iget v14, v10, Lu93;->a:I

    .line 294
    .line 295
    iget v10, v10, Lu93;->b:I

    .line 296
    .line 297
    if-eqz v13, :cond_c

    .line 298
    .line 299
    add-int/lit8 v15, v10, -0x1

    .line 300
    .line 301
    sub-int/2addr v15, v9

    .line 302
    shl-int/2addr v15, v11

    .line 303
    aget v15, v12, v15

    .line 304
    .line 305
    sub-int v16, v14, v9

    .line 306
    .line 307
    shl-int/lit8 v16, v16, 0x1

    .line 308
    .line 309
    add-int/lit8 v16, v16, 0x1

    .line 310
    .line 311
    aget v16, v12, v16

    .line 312
    .line 313
    goto :goto_8

    .line 314
    :cond_c
    sub-int v15, v14, v9

    .line 315
    .line 316
    shl-int/2addr v15, v11

    .line 317
    aget v15, v12, v15

    .line 318
    .line 319
    add-int/lit8 v16, v10, -0x1

    .line 320
    .line 321
    sub-int v16, v16, v9

    .line 322
    .line 323
    shl-int/lit8 v16, v16, 0x1

    .line 324
    .line 325
    add-int/lit8 v16, v16, 0x1

    .line 326
    .line 327
    aget v16, v12, v16

    .line 328
    .line 329
    :goto_8
    iget v11, v4, Landroid/graphics/RectF;->left:F

    .line 330
    .line 331
    move/from16 v18, v0

    .line 332
    .line 333
    if-eqz p7, :cond_1e

    .line 334
    .line 335
    cmpl-float v19, v16, v11

    .line 336
    .line 337
    if-ltz v19, :cond_15

    .line 338
    .line 339
    iget v0, v4, Landroid/graphics/RectF;->right:F

    .line 340
    .line 341
    cmpg-float v19, v15, v0

    .line 342
    .line 343
    if-gtz v19, :cond_15

    .line 344
    .line 345
    if-nez v13, :cond_d

    .line 346
    .line 347
    cmpg-float v0, v11, v15

    .line 348
    .line 349
    if-lez v0, :cond_e

    .line 350
    .line 351
    goto :goto_9

    .line 352
    :cond_d
    cmpl-float v0, v0, v16

    .line 353
    .line 354
    if-ltz v0, :cond_f

    .line 355
    .line 356
    :cond_e
    move v0, v14

    .line 357
    goto :goto_c

    .line 358
    :cond_f
    :goto_9
    move v0, v10

    .line 359
    move v11, v14

    .line 360
    :goto_a
    sub-int v15, v0, v11

    .line 361
    .line 362
    move/from16 p2, v0

    .line 363
    .line 364
    const/4 v0, 0x1

    .line 365
    if-le v15, v0, :cond_13

    .line 366
    .line 367
    add-int v15, p2, v11

    .line 368
    .line 369
    div-int/lit8 v15, v15, 0x2

    .line 370
    .line 371
    sub-int v16, v15, v9

    .line 372
    .line 373
    shl-int/lit8 v16, v16, 0x1

    .line 374
    .line 375
    aget v0, v12, v16

    .line 376
    .line 377
    move/from16 p3, v0

    .line 378
    .line 379
    if-nez v13, :cond_10

    .line 380
    .line 381
    iget v0, v4, Landroid/graphics/RectF;->left:F

    .line 382
    .line 383
    cmpl-float v0, p3, v0

    .line 384
    .line 385
    if-gtz v0, :cond_11

    .line 386
    .line 387
    goto :goto_b

    .line 388
    :cond_10
    iget v0, v4, Landroid/graphics/RectF;->right:F

    .line 389
    .line 390
    cmpg-float v0, p3, v0

    .line 391
    .line 392
    if-gez v0, :cond_12

    .line 393
    .line 394
    :cond_11
    move v0, v15

    .line 395
    goto :goto_a

    .line 396
    :cond_12
    :goto_b
    move/from16 v0, p2

    .line 397
    .line 398
    move v11, v15

    .line 399
    goto :goto_a

    .line 400
    :cond_13
    if-eqz v13, :cond_14

    .line 401
    .line 402
    move/from16 v0, p2

    .line 403
    .line 404
    goto :goto_c

    .line 405
    :cond_14
    move v0, v11

    .line 406
    :goto_c
    invoke-interface {v5, v0}, Lb66;->e(I)I

    .line 407
    .line 408
    .line 409
    move-result v0

    .line 410
    const/4 v11, -0x1

    .line 411
    if-eq v0, v11, :cond_15

    .line 412
    .line 413
    invoke-interface {v5, v0}, Lb66;->c(I)I

    .line 414
    .line 415
    .line 416
    move-result v11

    .line 417
    if-lt v11, v10, :cond_17

    .line 418
    .line 419
    :cond_15
    move-object/from16 v19, v3

    .line 420
    .line 421
    :cond_16
    const/4 v14, -0x1

    .line 422
    goto :goto_10

    .line 423
    :cond_17
    if-lt v11, v14, :cond_18

    .line 424
    .line 425
    move v14, v11

    .line 426
    :cond_18
    if-le v0, v10, :cond_19

    .line 427
    .line 428
    move v0, v10

    .line 429
    :cond_19
    new-instance v11, Landroid/graphics/RectF;

    .line 430
    .line 431
    int-to-float v15, v7

    .line 432
    move/from16 p2, v0

    .line 433
    .line 434
    int-to-float v0, v8

    .line 435
    move-object/from16 v19, v3

    .line 436
    .line 437
    const/4 v3, 0x0

    .line 438
    invoke-direct {v11, v3, v15, v3, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 439
    .line 440
    .line 441
    move/from16 v0, p2

    .line 442
    .line 443
    :cond_1a
    :goto_d
    if-eqz v13, :cond_1b

    .line 444
    .line 445
    add-int/lit8 v3, v0, -0x1

    .line 446
    .line 447
    sub-int/2addr v3, v9

    .line 448
    const/16 v17, 0x1

    .line 449
    .line 450
    shl-int/lit8 v3, v3, 0x1

    .line 451
    .line 452
    aget v3, v12, v3

    .line 453
    .line 454
    goto :goto_e

    .line 455
    :cond_1b
    const/16 v17, 0x1

    .line 456
    .line 457
    sub-int v3, v14, v9

    .line 458
    .line 459
    shl-int/lit8 v3, v3, 0x1

    .line 460
    .line 461
    aget v3, v12, v3

    .line 462
    .line 463
    :goto_e
    iput v3, v11, Landroid/graphics/RectF;->left:F

    .line 464
    .line 465
    if-eqz v13, :cond_1c

    .line 466
    .line 467
    sub-int v0, v14, v9

    .line 468
    .line 469
    shl-int/lit8 v0, v0, 0x1

    .line 470
    .line 471
    add-int/lit8 v0, v0, 0x1

    .line 472
    .line 473
    aget v0, v12, v0

    .line 474
    .line 475
    goto :goto_f

    .line 476
    :cond_1c
    add-int/lit8 v0, v0, -0x1

    .line 477
    .line 478
    sub-int/2addr v0, v9

    .line 479
    shl-int/lit8 v0, v0, 0x1

    .line 480
    .line 481
    add-int/lit8 v0, v0, 0x1

    .line 482
    .line 483
    aget v0, v12, v0

    .line 484
    .line 485
    :goto_f
    iput v0, v11, Landroid/graphics/RectF;->right:F

    .line 486
    .line 487
    invoke-virtual {v6, v11, v4}, Lt;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    check-cast v0, Ljava/lang/Boolean;

    .line 492
    .line 493
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 494
    .line 495
    .line 496
    move-result v0

    .line 497
    if-nez v0, :cond_1d

    .line 498
    .line 499
    invoke-interface {v5, v14}, Lb66;->k(I)I

    .line 500
    .line 501
    .line 502
    move-result v14

    .line 503
    const/4 v0, -0x1

    .line 504
    if-eq v14, v0, :cond_16

    .line 505
    .line 506
    if-ge v14, v10, :cond_16

    .line 507
    .line 508
    invoke-interface {v5, v14}, Lb66;->e(I)I

    .line 509
    .line 510
    .line 511
    move-result v0

    .line 512
    if-le v0, v10, :cond_1a

    .line 513
    .line 514
    move v0, v10

    .line 515
    goto :goto_d

    .line 516
    :cond_1d
    :goto_10
    const/16 v17, 0x1

    .line 517
    .line 518
    goto/16 :goto_1a

    .line 519
    .line 520
    :cond_1e
    move-object/from16 v19, v3

    .line 521
    .line 522
    cmpl-float v0, v16, v11

    .line 523
    .line 524
    if-ltz v0, :cond_2e

    .line 525
    .line 526
    iget v0, v4, Landroid/graphics/RectF;->right:F

    .line 527
    .line 528
    cmpg-float v3, v15, v0

    .line 529
    .line 530
    if-gtz v3, :cond_2e

    .line 531
    .line 532
    if-nez v13, :cond_1f

    .line 533
    .line 534
    cmpl-float v0, v0, v16

    .line 535
    .line 536
    if-gez v0, :cond_20

    .line 537
    .line 538
    goto :goto_12

    .line 539
    :cond_1f
    cmpg-float v0, v11, v15

    .line 540
    .line 541
    if-gtz v0, :cond_21

    .line 542
    .line 543
    :cond_20
    add-int/lit8 v0, v10, -0x1

    .line 544
    .line 545
    :goto_11
    const/16 v17, 0x1

    .line 546
    .line 547
    goto :goto_15

    .line 548
    :cond_21
    :goto_12
    move v0, v10

    .line 549
    move v3, v14

    .line 550
    :goto_13
    sub-int v11, v0, v3

    .line 551
    .line 552
    const/4 v15, 0x1

    .line 553
    if-le v11, v15, :cond_25

    .line 554
    .line 555
    add-int v11, v0, v3

    .line 556
    .line 557
    div-int/lit8 v11, v11, 0x2

    .line 558
    .line 559
    sub-int v16, v11, v9

    .line 560
    .line 561
    shl-int/lit8 v16, v16, 0x1

    .line 562
    .line 563
    aget v15, v12, v16

    .line 564
    .line 565
    move/from16 p2, v0

    .line 566
    .line 567
    if-nez v13, :cond_22

    .line 568
    .line 569
    iget v0, v4, Landroid/graphics/RectF;->right:F

    .line 570
    .line 571
    cmpl-float v0, v15, v0

    .line 572
    .line 573
    if-gtz v0, :cond_23

    .line 574
    .line 575
    goto :goto_14

    .line 576
    :cond_22
    iget v0, v4, Landroid/graphics/RectF;->left:F

    .line 577
    .line 578
    cmpg-float v0, v15, v0

    .line 579
    .line 580
    if-gez v0, :cond_24

    .line 581
    .line 582
    :cond_23
    move v0, v11

    .line 583
    goto :goto_13

    .line 584
    :cond_24
    :goto_14
    move/from16 v0, p2

    .line 585
    .line 586
    move v3, v11

    .line 587
    goto :goto_13

    .line 588
    :cond_25
    move/from16 p2, v0

    .line 589
    .line 590
    if-eqz v13, :cond_26

    .line 591
    .line 592
    move/from16 v0, p2

    .line 593
    .line 594
    goto :goto_11

    .line 595
    :cond_26
    move v0, v3

    .line 596
    goto :goto_11

    .line 597
    :goto_15
    add-int/lit8 v0, v0, 0x1

    .line 598
    .line 599
    invoke-interface {v5, v0}, Lb66;->c(I)I

    .line 600
    .line 601
    .line 602
    move-result v0

    .line 603
    const/4 v11, -0x1

    .line 604
    if-eq v0, v11, :cond_27

    .line 605
    .line 606
    invoke-interface {v5, v0}, Lb66;->e(I)I

    .line 607
    .line 608
    .line 609
    move-result v3

    .line 610
    if-gt v3, v14, :cond_28

    .line 611
    .line 612
    :cond_27
    const/4 v10, -0x1

    .line 613
    const/16 v17, 0x1

    .line 614
    .line 615
    goto :goto_19

    .line 616
    :cond_28
    if-ge v0, v14, :cond_29

    .line 617
    .line 618
    move v0, v14

    .line 619
    :cond_29
    if-gt v3, v10, :cond_2a

    .line 620
    .line 621
    move v10, v3

    .line 622
    :cond_2a
    new-instance v3, Landroid/graphics/RectF;

    .line 623
    .line 624
    int-to-float v11, v7

    .line 625
    int-to-float v15, v8

    .line 626
    move/from16 p2, v0

    .line 627
    .line 628
    const/4 v0, 0x0

    .line 629
    invoke-direct {v3, v0, v11, v0, v15}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 630
    .line 631
    .line 632
    move/from16 v0, p2

    .line 633
    .line 634
    :cond_2b
    :goto_16
    if-eqz v13, :cond_2c

    .line 635
    .line 636
    add-int/lit8 v11, v10, -0x1

    .line 637
    .line 638
    sub-int/2addr v11, v9

    .line 639
    const/16 v17, 0x1

    .line 640
    .line 641
    shl-int/lit8 v11, v11, 0x1

    .line 642
    .line 643
    aget v11, v12, v11

    .line 644
    .line 645
    goto :goto_17

    .line 646
    :cond_2c
    const/16 v17, 0x1

    .line 647
    .line 648
    sub-int v11, v0, v9

    .line 649
    .line 650
    shl-int/lit8 v11, v11, 0x1

    .line 651
    .line 652
    aget v11, v12, v11

    .line 653
    .line 654
    :goto_17
    iput v11, v3, Landroid/graphics/RectF;->left:F

    .line 655
    .line 656
    if-eqz v13, :cond_2d

    .line 657
    .line 658
    sub-int/2addr v0, v9

    .line 659
    shl-int/lit8 v0, v0, 0x1

    .line 660
    .line 661
    add-int/lit8 v0, v0, 0x1

    .line 662
    .line 663
    aget v0, v12, v0

    .line 664
    .line 665
    goto :goto_18

    .line 666
    :cond_2d
    add-int/lit8 v0, v10, -0x1

    .line 667
    .line 668
    sub-int/2addr v0, v9

    .line 669
    shl-int/lit8 v0, v0, 0x1

    .line 670
    .line 671
    add-int/lit8 v0, v0, 0x1

    .line 672
    .line 673
    aget v0, v12, v0

    .line 674
    .line 675
    :goto_18
    iput v0, v3, Landroid/graphics/RectF;->right:F

    .line 676
    .line 677
    invoke-virtual {v6, v3, v4}, Lt;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    check-cast v0, Ljava/lang/Boolean;

    .line 682
    .line 683
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 684
    .line 685
    .line 686
    move-result v0

    .line 687
    if-nez v0, :cond_30

    .line 688
    .line 689
    invoke-interface {v5, v10}, Lb66;->l(I)I

    .line 690
    .line 691
    .line 692
    move-result v10

    .line 693
    const/4 v11, -0x1

    .line 694
    if-eq v10, v11, :cond_2f

    .line 695
    .line 696
    if-le v10, v14, :cond_2f

    .line 697
    .line 698
    invoke-interface {v5, v10}, Lb66;->c(I)I

    .line 699
    .line 700
    .line 701
    move-result v0

    .line 702
    if-ge v0, v14, :cond_2b

    .line 703
    .line 704
    move v0, v14

    .line 705
    goto :goto_16

    .line 706
    :cond_2e
    const/16 v17, 0x1

    .line 707
    .line 708
    :cond_2f
    const/4 v10, -0x1

    .line 709
    :cond_30
    :goto_19
    move v14, v10

    .line 710
    :goto_1a
    if-ltz v14, :cond_31

    .line 711
    .line 712
    return v14

    .line 713
    :cond_31
    if-eq v1, v2, :cond_32

    .line 714
    .line 715
    add-int v1, v1, v18

    .line 716
    .line 717
    move/from16 v11, v17

    .line 718
    .line 719
    move/from16 v0, v18

    .line 720
    .line 721
    move-object/from16 v3, v19

    .line 722
    .line 723
    goto/16 :goto_7

    .line 724
    .line 725
    :cond_32
    const/4 v11, -0x1

    .line 726
    return v11
.end method

.method public static final u(II)I
    .locals 0

    .line 1
    shr-int/2addr p0, p1

    .line 2
    and-int/lit8 p0, p0, 0x1f

    .line 3
    .line 4
    return p0
.end method

.method public static final v(Lvk5;Lvk5;Lvk5;I)Z
    .locals 2

    .line 1
    invoke-static {p3, p0, p2}, Lat6;->w(ILvk5;Lvk5;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-static {p3, p1, p2}, Lat6;->w(ILvk5;Lvk5;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-static {p2, p0, p1, p3}, Lat6;->f(Lvk5;Lvk5;Lvk5;I)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_0

    .line 18
    .line 19
    invoke-static {p2, p1, p0, p3}, Lat6;->f(Lvk5;Lvk5;Lvk5;I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    invoke-static {p3, p2, p0}, Lat6;->x(ILvk5;Lvk5;)J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    invoke-static {p3, p2, p1}, Lat6;->x(ILvk5;Lvk5;)J

    .line 30
    .line 31
    .line 32
    move-result-wide p0

    .line 33
    cmp-long p0, v0, p0

    .line 34
    .line 35
    if-gez p0, :cond_1

    .line 36
    .line 37
    :cond_0
    const/4 p0, 0x1

    .line 38
    return p0

    .line 39
    :cond_1
    const/4 p0, 0x0

    .line 40
    return p0
.end method

.method public static final w(ILvk5;Lvk5;)Z
    .locals 3

    .line 1
    const/4 v0, 0x3

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x1

    .line 4
    if-ne p0, v0, :cond_2

    .line 5
    .line 6
    iget p0, p2, Lvk5;->c:F

    .line 7
    .line 8
    iget p2, p2, Lvk5;->a:F

    .line 9
    .line 10
    iget v0, p1, Lvk5;->c:F

    .line 11
    .line 12
    cmpl-float p0, p0, v0

    .line 13
    .line 14
    if-gtz p0, :cond_0

    .line 15
    .line 16
    cmpl-float p0, p2, v0

    .line 17
    .line 18
    if-ltz p0, :cond_1

    .line 19
    .line 20
    :cond_0
    iget p0, p1, Lvk5;->a:F

    .line 21
    .line 22
    cmpl-float p0, p2, p0

    .line 23
    .line 24
    if-lez p0, :cond_1

    .line 25
    .line 26
    return v2

    .line 27
    :cond_1
    return v1

    .line 28
    :cond_2
    const/4 v0, 0x4

    .line 29
    if-ne p0, v0, :cond_5

    .line 30
    .line 31
    iget p0, p2, Lvk5;->a:F

    .line 32
    .line 33
    iget p2, p2, Lvk5;->c:F

    .line 34
    .line 35
    iget v0, p1, Lvk5;->a:F

    .line 36
    .line 37
    cmpg-float p0, p0, v0

    .line 38
    .line 39
    if-ltz p0, :cond_3

    .line 40
    .line 41
    cmpg-float p0, p2, v0

    .line 42
    .line 43
    if-gtz p0, :cond_4

    .line 44
    .line 45
    :cond_3
    iget p0, p1, Lvk5;->c:F

    .line 46
    .line 47
    cmpg-float p0, p2, p0

    .line 48
    .line 49
    if-gez p0, :cond_4

    .line 50
    .line 51
    return v2

    .line 52
    :cond_4
    return v1

    .line 53
    :cond_5
    const/4 v0, 0x5

    .line 54
    if-ne p0, v0, :cond_8

    .line 55
    .line 56
    iget p0, p2, Lvk5;->d:F

    .line 57
    .line 58
    iget p2, p2, Lvk5;->b:F

    .line 59
    .line 60
    iget v0, p1, Lvk5;->d:F

    .line 61
    .line 62
    cmpl-float p0, p0, v0

    .line 63
    .line 64
    if-gtz p0, :cond_6

    .line 65
    .line 66
    cmpl-float p0, p2, v0

    .line 67
    .line 68
    if-ltz p0, :cond_7

    .line 69
    .line 70
    :cond_6
    iget p0, p1, Lvk5;->b:F

    .line 71
    .line 72
    cmpl-float p0, p2, p0

    .line 73
    .line 74
    if-lez p0, :cond_7

    .line 75
    .line 76
    return v2

    .line 77
    :cond_7
    return v1

    .line 78
    :cond_8
    const/4 v0, 0x6

    .line 79
    if-ne p0, v0, :cond_b

    .line 80
    .line 81
    iget p0, p2, Lvk5;->b:F

    .line 82
    .line 83
    iget p2, p2, Lvk5;->d:F

    .line 84
    .line 85
    iget v0, p1, Lvk5;->b:F

    .line 86
    .line 87
    cmpg-float p0, p0, v0

    .line 88
    .line 89
    if-ltz p0, :cond_9

    .line 90
    .line 91
    cmpg-float p0, p2, v0

    .line 92
    .line 93
    if-gtz p0, :cond_a

    .line 94
    .line 95
    :cond_9
    iget p0, p1, Lvk5;->d:F

    .line 96
    .line 97
    cmpg-float p0, p2, p0

    .line 98
    .line 99
    if-gez p0, :cond_a

    .line 100
    .line 101
    return v2

    .line 102
    :cond_a
    return v1

    .line 103
    :cond_b
    const-string p0, "This function should only be used for 2-D focus search"

    .line 104
    .line 105
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    return v1
.end method

.method public static final x(ILvk5;Lvk5;)J
    .locals 10

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    const-string v2, "This function should only be used for 2-D focus search"

    .line 4
    .line 5
    const/4 v3, 0x6

    .line 6
    const/4 v4, 0x5

    .line 7
    const/4 v5, 0x4

    .line 8
    const/4 v6, 0x3

    .line 9
    if-ne p0, v6, :cond_0

    .line 10
    .line 11
    iget v7, p1, Lvk5;->a:F

    .line 12
    .line 13
    iget v8, p2, Lvk5;->c:F

    .line 14
    .line 15
    :goto_0
    sub-float/2addr v7, v8

    .line 16
    goto :goto_1

    .line 17
    :cond_0
    if-ne p0, v5, :cond_1

    .line 18
    .line 19
    iget v7, p2, Lvk5;->a:F

    .line 20
    .line 21
    iget v8, p1, Lvk5;->c:F

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    if-ne p0, v4, :cond_2

    .line 25
    .line 26
    iget v7, p1, Lvk5;->b:F

    .line 27
    .line 28
    iget v8, p2, Lvk5;->d:F

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_2
    if-ne p0, v3, :cond_8

    .line 32
    .line 33
    iget v7, p2, Lvk5;->b:F

    .line 34
    .line 35
    iget v8, p1, Lvk5;->d:F

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :goto_1
    const/4 v8, 0x0

    .line 39
    cmpg-float v9, v7, v8

    .line 40
    .line 41
    if-gez v9, :cond_3

    .line 42
    .line 43
    move v7, v8

    .line 44
    :cond_3
    float-to-long v7, v7

    .line 45
    const/high16 v9, 0x40000000    # 2.0f

    .line 46
    .line 47
    if-eq p0, v6, :cond_4

    .line 48
    .line 49
    if-ne p0, v5, :cond_5

    .line 50
    .line 51
    :cond_4
    iget p0, p1, Lvk5;->b:F

    .line 52
    .line 53
    iget p1, p1, Lvk5;->d:F

    .line 54
    .line 55
    sub-float/2addr p1, p0

    .line 56
    div-float/2addr p1, v9

    .line 57
    add-float/2addr p1, p0

    .line 58
    iget p0, p2, Lvk5;->b:F

    .line 59
    .line 60
    iget p2, p2, Lvk5;->d:F

    .line 61
    .line 62
    :goto_2
    sub-float/2addr p2, p0

    .line 63
    div-float/2addr p2, v9

    .line 64
    add-float/2addr p2, p0

    .line 65
    sub-float/2addr p1, p2

    .line 66
    goto :goto_3

    .line 67
    :cond_5
    if-eq p0, v4, :cond_6

    .line 68
    .line 69
    if-ne p0, v3, :cond_7

    .line 70
    .line 71
    :cond_6
    iget p0, p1, Lvk5;->a:F

    .line 72
    .line 73
    iget p1, p1, Lvk5;->c:F

    .line 74
    .line 75
    sub-float/2addr p1, p0

    .line 76
    div-float/2addr p1, v9

    .line 77
    add-float/2addr p1, p0

    .line 78
    iget p0, p2, Lvk5;->a:F

    .line 79
    .line 80
    iget p2, p2, Lvk5;->c:F

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :goto_3
    float-to-long p0, p1

    .line 84
    const-wide/16 v0, 0xd

    .line 85
    .line 86
    mul-long/2addr v0, v7

    .line 87
    mul-long/2addr v0, v7

    .line 88
    mul-long/2addr p0, p0

    .line 89
    add-long/2addr p0, v0

    .line 90
    return-wide p0

    .line 91
    :cond_7
    invoke-static {v2}, Lj02;->c(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    return-wide v0

    .line 95
    :cond_8
    invoke-static {v2}, Lj02;->c(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    return-wide v0
.end method

.method public static final y(ILwf;Lv72;Lvk5;)Z
    .locals 10

    .line 1
    new-instance v0, Ly44;

    .line 2
    .line 3
    const/16 v1, 0x10

    .line 4
    .line 5
    new-array v2, v1, [Lv72;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-direct {v0, v3, v2}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v2, p2, Lh14;->i:Lh14;

    .line 12
    .line 13
    iget-boolean v2, v2, Lh14;->v:Z

    .line 14
    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    const-string v2, "visitChildren called on an unattached node"

    .line 18
    .line 19
    invoke-static {v2}, Lwy2;->b(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    new-instance v2, Ly44;

    .line 23
    .line 24
    new-array v4, v1, [Lh14;

    .line 25
    .line 26
    invoke-direct {v2, v3, v4}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    iget-object p2, p2, Lh14;->i:Lh14;

    .line 30
    .line 31
    iget-object v4, p2, Lh14;->n:Lh14;

    .line 32
    .line 33
    if-nez v4, :cond_1

    .line 34
    .line 35
    invoke-static {v2, p2}, Lgj;->l(Ly44;Lh14;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    invoke-virtual {v2, v4}, Ly44;->b(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_2
    :goto_0
    iget p2, v2, Ly44;->k:I

    .line 43
    .line 44
    const/4 v4, 0x1

    .line 45
    if-eqz p2, :cond_d

    .line 46
    .line 47
    add-int/lit8 p2, p2, -0x1

    .line 48
    .line 49
    invoke-virtual {v2, p2}, Ly44;->k(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    check-cast p2, Lh14;

    .line 54
    .line 55
    iget v5, p2, Lh14;->l:I

    .line 56
    .line 57
    and-int/lit16 v5, v5, 0x400

    .line 58
    .line 59
    if-nez v5, :cond_3

    .line 60
    .line 61
    invoke-static {v2, p2}, Lgj;->l(Ly44;Lh14;)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_3
    :goto_1
    if-eqz p2, :cond_2

    .line 66
    .line 67
    iget v5, p2, Lh14;->k:I

    .line 68
    .line 69
    and-int/lit16 v5, v5, 0x400

    .line 70
    .line 71
    if-eqz v5, :cond_c

    .line 72
    .line 73
    const/4 v5, 0x0

    .line 74
    move-object v6, v5

    .line 75
    :cond_4
    :goto_2
    if-eqz p2, :cond_2

    .line 76
    .line 77
    instance-of v7, p2, Lv72;

    .line 78
    .line 79
    if-eqz v7, :cond_5

    .line 80
    .line 81
    check-cast p2, Lv72;

    .line 82
    .line 83
    iget-boolean v7, p2, Lh14;->v:Z

    .line 84
    .line 85
    if-eqz v7, :cond_b

    .line 86
    .line 87
    invoke-virtual {v0, p2}, Ly44;->b(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    goto :goto_5

    .line 91
    :cond_5
    iget v7, p2, Lh14;->k:I

    .line 92
    .line 93
    and-int/lit16 v7, v7, 0x400

    .line 94
    .line 95
    if-eqz v7, :cond_b

    .line 96
    .line 97
    instance-of v7, p2, Lil1;

    .line 98
    .line 99
    if-eqz v7, :cond_b

    .line 100
    .line 101
    move-object v7, p2

    .line 102
    check-cast v7, Lil1;

    .line 103
    .line 104
    iget-object v7, v7, Lil1;->x:Lh14;

    .line 105
    .line 106
    move v8, v3

    .line 107
    :goto_3
    if-eqz v7, :cond_a

    .line 108
    .line 109
    iget v9, v7, Lh14;->k:I

    .line 110
    .line 111
    and-int/lit16 v9, v9, 0x400

    .line 112
    .line 113
    if-eqz v9, :cond_9

    .line 114
    .line 115
    add-int/lit8 v8, v8, 0x1

    .line 116
    .line 117
    if-ne v8, v4, :cond_6

    .line 118
    .line 119
    move-object p2, v7

    .line 120
    goto :goto_4

    .line 121
    :cond_6
    if-nez v6, :cond_7

    .line 122
    .line 123
    new-instance v6, Ly44;

    .line 124
    .line 125
    new-array v9, v1, [Lh14;

    .line 126
    .line 127
    invoke-direct {v6, v3, v9}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_7
    if-eqz p2, :cond_8

    .line 131
    .line 132
    invoke-virtual {v6, p2}, Ly44;->b(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    move-object p2, v5

    .line 136
    :cond_8
    invoke-virtual {v6, v7}, Ly44;->b(Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    :cond_9
    :goto_4
    iget-object v7, v7, Lh14;->n:Lh14;

    .line 140
    .line 141
    goto :goto_3

    .line 142
    :cond_a
    if-eq v8, v4, :cond_4

    .line 143
    .line 144
    :cond_b
    :goto_5
    invoke-static {v6}, Lgj;->N(Ly44;)Lh14;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    goto :goto_2

    .line 149
    :cond_c
    iget-object p2, p2, Lh14;->n:Lh14;

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_d
    :goto_6
    iget p2, v0, Ly44;->k:I

    .line 153
    .line 154
    if-eqz p2, :cond_10

    .line 155
    .line 156
    invoke-static {v0, p3, p0}, Lat6;->n(Ly44;Lvk5;I)Lv72;

    .line 157
    .line 158
    .line 159
    move-result-object p2

    .line 160
    if-eqz p2, :cond_10

    .line 161
    .line 162
    invoke-virtual {p2}, Lv72;->I1()Lh72;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    iget-boolean v1, v1, Lh72;->a:Z

    .line 167
    .line 168
    if-eqz v1, :cond_e

    .line 169
    .line 170
    invoke-virtual {p1, p2}, Lwf;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object p0

    .line 174
    check-cast p0, Ljava/lang/Boolean;

    .line 175
    .line 176
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 177
    .line 178
    .line 179
    move-result p0

    .line 180
    return p0

    .line 181
    :cond_e
    invoke-static {p0, p1, p2, p3}, Lat6;->q(ILwf;Lv72;Lvk5;)Z

    .line 182
    .line 183
    .line 184
    move-result v1

    .line 185
    if-eqz v1, :cond_f

    .line 186
    .line 187
    return v4

    .line 188
    :cond_f
    invoke-virtual {v0, p2}, Ly44;->j(Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    goto :goto_6

    .line 192
    :cond_10
    return v3
.end method

.method public static final z(Ll87;FLoi1;Lll6;Lja1;)Ljava/lang/Object;
    .locals 10

    .line 1
    instance-of v0, p4, Li87;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p4

    .line 6
    check-cast v0, Li87;

    .line 7
    .line 8
    iget v1, v0, Li87;->n:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Li87;->n:I

    .line 18
    .line 19
    :goto_0
    move-object v6, v0

    .line 20
    goto :goto_1

    .line 21
    :cond_0
    new-instance v0, Li87;

    .line 22
    .line 23
    invoke-direct {v0, p4}, Lja1;-><init>(Lia1;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :goto_1
    iget-object p4, v6, Li87;->m:Ljava/lang/Object;

    .line 28
    .line 29
    iget v0, v6, Li87;->n:I

    .line 30
    .line 31
    const/4 v1, 0x2

    .line 32
    const/4 v2, 0x1

    .line 33
    const/4 v8, 0x0

    .line 34
    const/4 v3, 0x0

    .line 35
    sget-object v9, Lsf1;->i:Lsf1;

    .line 36
    .line 37
    if-eqz v0, :cond_3

    .line 38
    .line 39
    if-eq v0, v2, :cond_2

    .line 40
    .line 41
    if-ne v0, v1, :cond_1

    .line 42
    .line 43
    iget p0, v6, Li87;->l:F

    .line 44
    .line 45
    iget-object p1, v6, Li87;->k:Lyk5;

    .line 46
    .line 47
    invoke-static {p4}, Loa3;->U(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    goto/16 :goto_4

    .line 51
    .line 52
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 53
    .line 54
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-object v3

    .line 58
    :cond_2
    iget p1, v6, Li87;->l:F

    .line 59
    .line 60
    iget-object p0, v6, Li87;->k:Lyk5;

    .line 61
    .line 62
    iget-object p3, v6, Li87;->j:Lll6;

    .line 63
    .line 64
    iget-object p2, v6, Li87;->i:Ll87;

    .line 65
    .line 66
    invoke-static {p4}, Loa3;->U(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    move-object p4, p0

    .line 70
    move-object p0, p2

    .line 71
    goto :goto_2

    .line 72
    :cond_3
    invoke-static {p4}, Loa3;->U(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0}, Ll87;->a()F

    .line 76
    .line 77
    .line 78
    move-result p4

    .line 79
    const v0, 0x3c23d70a    # 0.01f

    .line 80
    .line 81
    .line 82
    cmpg-float p4, p4, v0

    .line 83
    .line 84
    if-ltz p4, :cond_9

    .line 85
    .line 86
    invoke-virtual {p0}, Ll87;->a()F

    .line 87
    .line 88
    .line 89
    move-result p4

    .line 90
    const/high16 v0, 0x3f800000    # 1.0f

    .line 91
    .line 92
    cmpg-float p4, p4, v0

    .line 93
    .line 94
    if-eqz p4, :cond_9

    .line 95
    .line 96
    new-instance p4, Lyk5;

    .line 97
    .line 98
    invoke-direct {p4}, Ljava/lang/Object;-><init>()V

    .line 99
    .line 100
    .line 101
    iput p1, p4, Lyk5;->i:F

    .line 102
    .line 103
    if-eqz p2, :cond_4

    .line 104
    .line 105
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 106
    .line 107
    .line 108
    move-result v4

    .line 109
    cmpl-float v0, v4, v0

    .line 110
    .line 111
    if-lez v0, :cond_4

    .line 112
    .line 113
    new-instance v0, Lyk5;

    .line 114
    .line 115
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 116
    .line 117
    .line 118
    const/16 v4, 0x1c

    .line 119
    .line 120
    invoke-static {v8, p1, v4}, Lif7;->d(FFI)Ldi;

    .line 121
    .line 122
    .line 123
    move-result-object v4

    .line 124
    new-instance v5, Lf87;

    .line 125
    .line 126
    invoke-direct {v5, v0, p0, p4}, Lf87;-><init>(Lyk5;Ll87;Lyk5;)V

    .line 127
    .line 128
    .line 129
    iput-object p0, v6, Li87;->i:Ll87;

    .line 130
    .line 131
    iput-object p3, v6, Li87;->j:Lll6;

    .line 132
    .line 133
    iput-object p4, v6, Li87;->k:Lyk5;

    .line 134
    .line 135
    iput p1, v6, Li87;->l:F

    .line 136
    .line 137
    iput v2, v6, Li87;->n:I

    .line 138
    .line 139
    const/4 v0, 0x0

    .line 140
    invoke-static {v4, p2, v0, v5, v6}, Lis6;->e(Ldi;Loi1;ZLqa2;Lja1;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object p2

    .line 144
    if-eq p2, v9, :cond_6

    .line 145
    .line 146
    :cond_4
    :goto_2
    if-eqz p3, :cond_8

    .line 147
    .line 148
    iget-object p2, p0, Ll87;->e:Lzx4;

    .line 149
    .line 150
    invoke-virtual {p2}, Lzx4;->g()F

    .line 151
    .line 152
    .line 153
    move-result v0

    .line 154
    cmpg-float v0, v0, v8

    .line 155
    .line 156
    if-gez v0, :cond_8

    .line 157
    .line 158
    invoke-virtual {p2}, Lzx4;->g()F

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    iget v2, p0, Ll87;->a:F

    .line 163
    .line 164
    cmpl-float v0, v0, v2

    .line 165
    .line 166
    if-lez v0, :cond_8

    .line 167
    .line 168
    invoke-virtual {p2}, Lzx4;->g()F

    .line 169
    .line 170
    .line 171
    move-result p2

    .line 172
    const/16 v0, 0x1e

    .line 173
    .line 174
    invoke-static {p2, v8, v0}, Lif7;->d(FFI)Ldi;

    .line 175
    .line 176
    .line 177
    move-result-object p2

    .line 178
    invoke-virtual {p0}, Ll87;->a()F

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    const/high16 v2, 0x3f000000    # 0.5f

    .line 183
    .line 184
    cmpg-float v0, v0, v2

    .line 185
    .line 186
    if-gez v0, :cond_5

    .line 187
    .line 188
    move v0, v8

    .line 189
    goto :goto_3

    .line 190
    :cond_5
    iget v0, p0, Ll87;->a:F

    .line 191
    .line 192
    :goto_3
    new-instance v2, Ljava/lang/Float;

    .line 193
    .line 194
    invoke-direct {v2, v0}, Ljava/lang/Float;-><init>(F)V

    .line 195
    .line 196
    .line 197
    new-instance v5, Lr57;

    .line 198
    .line 199
    invoke-direct {v5, p0, v1}, Lr57;-><init>(Ljava/lang/Object;B)V

    .line 200
    .line 201
    .line 202
    iput-object v3, v6, Li87;->i:Ll87;

    .line 203
    .line 204
    iput-object v3, v6, Li87;->j:Lll6;

    .line 205
    .line 206
    iput-object p4, v6, Li87;->k:Lyk5;

    .line 207
    .line 208
    iput p1, v6, Li87;->l:F

    .line 209
    .line 210
    iput v1, v6, Li87;->n:I

    .line 211
    .line 212
    const/4 v4, 0x0

    .line 213
    const/4 v7, 0x4

    .line 214
    move-object v1, p2

    .line 215
    move-object v3, p3

    .line 216
    invoke-static/range {v1 .. v7}, Lis6;->g(Ldi;Ljava/lang/Float;Lci;ZLqa2;Lja1;I)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    if-ne p0, v9, :cond_7

    .line 221
    .line 222
    :cond_6
    return-object v9

    .line 223
    :cond_7
    move p0, p1

    .line 224
    move-object p1, p4

    .line 225
    :goto_4
    move-object p4, p1

    .line 226
    move p1, p0

    .line 227
    :cond_8
    iget p0, p4, Lyk5;->i:F

    .line 228
    .line 229
    sub-float/2addr p1, p0

    .line 230
    invoke-static {v8, p1}, Lqt6;->b(FF)J

    .line 231
    .line 232
    .line 233
    move-result-wide p0

    .line 234
    new-instance p2, Lrg7;

    .line 235
    .line 236
    invoke-direct {p2, p0, p1}, Lrg7;-><init>(J)V

    .line 237
    .line 238
    .line 239
    return-object p2

    .line 240
    :cond_9
    new-instance p0, Lrg7;

    .line 241
    .line 242
    const-wide/16 p1, 0x0

    .line 243
    .line 244
    invoke-direct {p0, p1, p2}, Lrg7;-><init>(J)V

    .line 245
    .line 246
    .line 247
    return-object p0
.end method
