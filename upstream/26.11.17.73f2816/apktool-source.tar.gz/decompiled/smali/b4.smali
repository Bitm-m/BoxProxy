.class public final Lb4;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic a:B

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lb4;->a:B

    .line 2
    .line 3
    iput-object p1, p0, Lb4;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ls25;Lia1;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    iget-byte v2, v0, Lb4;->a:B

    .line 8
    .line 9
    const/4 v3, 0x3

    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v5, 0x1

    .line 12
    const/4 v7, 0x0

    .line 13
    sget-object v8, Lne7;->a:Lne7;

    .line 14
    .line 15
    sget-object v9, Lsf1;->i:Lsf1;

    .line 16
    .line 17
    iget-object v0, v0, Lb4;->b:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v2, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    check-cast v0, Lc07;

    .line 23
    .line 24
    iget-object v2, v0, Lc07;->A:Lzz6;

    .line 25
    .line 26
    iget-object v0, v0, Lc07;->z:La07;

    .line 27
    .line 28
    invoke-static {v1, v2, v0, v6}, Ltb3;->m(Ls25;Lf24;Ljx6;Lia1;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-ne v0, v9, :cond_0

    .line 33
    .line 34
    move-object v8, v0

    .line 35
    :cond_0
    return-object v8

    .line 36
    :pswitch_0
    new-instance v2, Lou;

    .line 37
    .line 38
    check-cast v0, Ldy6;

    .line 39
    .line 40
    const/16 v3, 0xf

    .line 41
    .line 42
    invoke-direct {v2, v0, v1, v7, v3}, Lou;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 43
    .line 44
    .line 45
    invoke-static {v2, v6}, Lgj;->p(Lua2;Lia1;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    if-ne v0, v9, :cond_1

    .line 50
    .line 51
    move-object v8, v0

    .line 52
    :cond_1
    return-object v8

    .line 53
    :pswitch_1
    new-instance v10, Led6;

    .line 54
    .line 55
    move-object v12, v0

    .line 56
    check-cast v12, Luw6;

    .line 57
    .line 58
    const/16 v16, 0x0

    .line 59
    .line 60
    const/16 v17, 0x5

    .line 61
    .line 62
    const/4 v11, 0x1

    .line 63
    const-class v13, Luw6;

    .line 64
    .line 65
    const-string v14, "tryShowContextMenu"

    .line 66
    .line 67
    const-string v15, "tryShowContextMenu-k-4lQ0M(J)V"

    .line 68
    .line 69
    invoke-direct/range {v10 .. v17}, Led6;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 70
    .line 71
    .line 72
    new-instance v0, Lfc;

    .line 73
    .line 74
    invoke-direct {v0, v10, v7, v5}, Lfc;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 75
    .line 76
    .line 77
    invoke-static {v1, v0, v6}, Lsq;->J(Ls25;Lua2;Lia1;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-eq v0, v9, :cond_2

    .line 82
    .line 83
    move-object v0, v8

    .line 84
    :cond_2
    if-ne v0, v9, :cond_3

    .line 85
    .line 86
    move-object v8, v0

    .line 87
    :cond_3
    return-object v8

    .line 88
    :pswitch_2
    new-instance v2, Ljd3;

    .line 89
    .line 90
    check-cast v0, Lmo6;

    .line 91
    .line 92
    invoke-direct {v2, v0, v7, v3}, Ljd3;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 93
    .line 94
    .line 95
    invoke-static {v1, v2, v6}, Lsq;->J(Ls25;Lua2;Lia1;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    if-ne v0, v9, :cond_4

    .line 100
    .line 101
    move-object v8, v0

    .line 102
    :cond_4
    return-object v8

    .line 103
    :pswitch_3
    check-cast v0, Lh86;

    .line 104
    .line 105
    iget-object v2, v0, Lh86;->D:Lj86;

    .line 106
    .line 107
    iget-object v0, v0, Lh86;->C:Li86;

    .line 108
    .line 109
    invoke-static {v1, v2, v0, v6}, Ltb3;->m(Ls25;Lf24;Ljx6;Lia1;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    if-ne v0, v9, :cond_5

    .line 114
    .line 115
    move-object v8, v0

    .line 116
    :cond_5
    return-object v8

    .line 117
    :pswitch_4
    check-cast v0, Lc86;

    .line 118
    .line 119
    iget-object v0, v0, Lc86;->E:Lfb3;

    .line 120
    .line 121
    invoke-interface {v0}, Lfb3;->getValue()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    check-cast v0, Lf24;

    .line 126
    .line 127
    invoke-static {v1, v0, v7, v6}, Ltb3;->m(Ls25;Lf24;Ljx6;Lia1;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    if-ne v0, v9, :cond_6

    .line 132
    .line 133
    move-object v8, v0

    .line 134
    :cond_6
    return-object v8

    .line 135
    :pswitch_5
    new-instance v2, Lv10;

    .line 136
    .line 137
    check-cast v0, Ljs4;

    .line 138
    .line 139
    invoke-direct {v2, v0, v7, v5}, Lv10;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 140
    .line 141
    .line 142
    move-object v0, v1

    .line 143
    check-cast v0, Lqs6;

    .line 144
    .line 145
    invoke-virtual {v0, v2, v6}, Lqs6;->G1(Lua2;Lia1;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    if-ne v0, v9, :cond_7

    .line 150
    .line 151
    move-object v8, v0

    .line 152
    :cond_7
    return-object v8

    .line 153
    :pswitch_6
    new-instance v2, Lb52;

    .line 154
    .line 155
    check-cast v0, Lhk1;

    .line 156
    .line 157
    const/16 v3, 0x8

    .line 158
    .line 159
    invoke-direct {v2, v1, v0, v7, v3}, Lb52;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 160
    .line 161
    .line 162
    invoke-static {v2, v6}, Lgj;->p(Lua2;Lia1;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    if-ne v0, v9, :cond_8

    .line 167
    .line 168
    move-object v8, v0

    .line 169
    :cond_8
    return-object v8

    .line 170
    :pswitch_7
    check-cast v0, La23;

    .line 171
    .line 172
    new-instance v11, Lx13;

    .line 173
    .line 174
    invoke-direct {v11, v0, v5}, Lx13;-><init>(La23;B)V

    .line 175
    .line 176
    .line 177
    new-instance v14, Lx13;

    .line 178
    .line 179
    const/4 v2, 0x2

    .line 180
    invoke-direct {v14, v0, v2}, Lx13;-><init>(La23;B)V

    .line 181
    .line 182
    .line 183
    new-instance v13, Lcu2;

    .line 184
    .line 185
    const/4 v2, 0x4

    .line 186
    invoke-direct {v13, v0, v2}, Lcu2;-><init>(Ljava/lang/Object;B)V

    .line 187
    .line 188
    .line 189
    new-instance v12, Lt;

    .line 190
    .line 191
    const/16 v2, 0x16

    .line 192
    .line 193
    invoke-direct {v12, v0, v2}, Lt;-><init>(Ljava/lang/Object;B)V

    .line 194
    .line 195
    .line 196
    new-instance v10, Lar1;

    .line 197
    .line 198
    const/4 v15, 0x0

    .line 199
    invoke-direct/range {v10 .. v15}, Lar1;-><init>(Lqa2;Lua2;Lfa2;Lqa2;Lia1;)V

    .line 200
    .line 201
    .line 202
    invoke-static {v1, v10, v6}, Lsq;->J(Ls25;Lua2;Lia1;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    if-eq v0, v9, :cond_9

    .line 207
    .line 208
    move-object v0, v8

    .line 209
    :cond_9
    if-ne v0, v9, :cond_a

    .line 210
    .line 211
    move-object v8, v0

    .line 212
    :cond_a
    return-object v8

    .line 213
    :pswitch_8
    check-cast v0, Lei1;

    .line 214
    .line 215
    new-instance v11, Lxh1;

    .line 216
    .line 217
    invoke-direct {v11, v0, v4}, Lxh1;-><init>(Lei1;B)V

    .line 218
    .line 219
    .line 220
    new-instance v14, Lxh1;

    .line 221
    .line 222
    invoke-direct {v14, v0, v5}, Lxh1;-><init>(Lei1;B)V

    .line 223
    .line 224
    .line 225
    new-instance v13, Lyh1;

    .line 226
    .line 227
    invoke-direct {v13, v0, v4}, Lyh1;-><init>(Lei1;B)V

    .line 228
    .line 229
    .line 230
    new-instance v12, Lcb1;

    .line 231
    .line 232
    invoke-direct {v12, v0, v1, v3}, Lcb1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 233
    .line 234
    .line 235
    new-instance v10, Lar1;

    .line 236
    .line 237
    const/4 v15, 0x0

    .line 238
    invoke-direct/range {v10 .. v15}, Lar1;-><init>(Lqa2;Lua2;Lfa2;Lqa2;Lia1;)V

    .line 239
    .line 240
    .line 241
    invoke-static {v1, v10, v6}, Lsq;->J(Ls25;Lua2;Lia1;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    if-eq v0, v9, :cond_b

    .line 246
    .line 247
    move-object v0, v8

    .line 248
    :cond_b
    if-ne v0, v9, :cond_c

    .line 249
    .line 250
    move-object v8, v0

    .line 251
    :cond_c
    return-object v8

    .line 252
    :pswitch_9
    new-instance v2, Lfc;

    .line 253
    .line 254
    check-cast v0, Lgc;

    .line 255
    .line 256
    invoke-direct {v2, v0, v7, v4}, Lfc;-><init>(Ljava/lang/Object;Lia1;B)V

    .line 257
    .line 258
    .line 259
    invoke-static {v1, v2, v6}, Lsq;->J(Ls25;Lua2;Lia1;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    if-ne v0, v9, :cond_d

    .line 264
    .line 265
    move-object v8, v0

    .line 266
    :cond_d
    return-object v8

    .line 267
    :pswitch_a
    move-object v2, v0

    .line 268
    check-cast v2, Lt55;

    .line 269
    .line 270
    new-instance v3, Ly3;

    .line 271
    .line 272
    const/4 v4, 0x0

    .line 273
    invoke-direct {v3, v2, v4}, Ly3;-><init>(Lt55;Lia1;)V

    .line 274
    .line 275
    .line 276
    new-instance v0, Lx3;

    .line 277
    .line 278
    const/4 v5, 0x0

    .line 279
    invoke-direct/range {v0 .. v5}, Lx3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 280
    .line 281
    .line 282
    invoke-static {v0, v6}, Lgj;->p(Lua2;Lia1;)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v0

    .line 286
    if-eq v0, v9, :cond_e

    .line 287
    .line 288
    move-object v0, v8

    .line 289
    :cond_e
    if-ne v0, v9, :cond_f

    .line 290
    .line 291
    move-object v8, v0

    .line 292
    :cond_f
    return-object v8

    .line 293
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
