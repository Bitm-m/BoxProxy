.class public final Lak5;
.super Lvn5;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final j:Ljava/lang/String;

.field public final k:J

.field public final l:Lij5;


# direct methods
.method public constructor <init>(Ljava/lang/String;JLij5;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lak5;->j:Ljava/lang/String;

    .line 5
    .line 6
    iput-wide p2, p0, Lak5;->k:J

    .line 7
    .line 8
    iput-object p4, p0, Lak5;->l:Lij5;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final C()Lgf0;
    .locals 0

    .line 1
    iget-object p0, p0, Lak5;->l:Lij5;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lak5;->k:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final f()Lts3;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object p0, p0, Lak5;->j:Ljava/lang/String;

    .line 3
    .line 4
    if-eqz p0, :cond_0

    .line 5
    .line 6
    sget-object v1, Lts3;->c:Lyl5;

    .line 7
    .line 8
    :try_start_0
    invoke-static {p0}, Lad3;->s(Ljava/lang/String;)Lts3;

    .line 9
    .line 10
    .line 11
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    return-object p0

    .line 13
    :catch_0
    :cond_0
    return-object v0
.end method
