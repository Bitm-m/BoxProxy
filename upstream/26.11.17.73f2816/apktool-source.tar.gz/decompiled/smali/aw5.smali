.class public final synthetic Law5;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Law5;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte p0, p0, Law5;->i:B

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    sget-object v1, Lne7;->a:Lne7;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    packed-switch p0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    check-cast p1, Ljava/util/List;

    .line 16
    .line 17
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    if-eqz p0, :cond_0

    .line 22
    .line 23
    check-cast p0, Ljava/lang/String;

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    move-object p0, v2

    .line 27
    :goto_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    sget-object v0, Lg26;->j:Lb26;

    .line 35
    .line 36
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-static {p1, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_1

    .line 43
    .line 44
    if-eqz p1, :cond_1

    .line 45
    .line 46
    iget-object v0, v0, Lb26;->b:Lqa2;

    .line 47
    .line 48
    invoke-interface {v0, p1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    move-object v2, p1

    .line 53
    check-cast v2, Lb27;

    .line 54
    .line 55
    :cond_1
    new-instance p1, Lli3;

    .line 56
    .line 57
    invoke-direct {p1, p0, v2}, Lli3;-><init>(Ljava/lang/String;Lb27;)V

    .line 58
    .line 59
    .line 60
    return-object p1

    .line 61
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    check-cast p1, Ljava/lang/Integer;

    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 67
    .line 68
    .line 69
    move-result p0

    .line 70
    new-instance p1, Law6;

    .line 71
    .line 72
    invoke-direct {p1, p0}, Law6;-><init>(I)V

    .line 73
    .line 74
    .line 75
    return-object p1

    .line 76
    :pswitch_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    check-cast p1, Ljava/util/List;

    .line 80
    .line 81
    new-instance v5, Lrb6;

    .line 82
    .line 83
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    sget v1, Lsv0;->i:I

    .line 88
    .line 89
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 90
    .line 91
    invoke-static {p0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    if-eqz p0, :cond_3

    .line 95
    .line 96
    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v3

    .line 100
    if-eqz v3, :cond_2

    .line 101
    .line 102
    sget-wide v6, Lsv0;->h:J

    .line 103
    .line 104
    new-instance p0, Lsv0;

    .line 105
    .line 106
    invoke-direct {p0, v6, v7}, Lsv0;-><init>(J)V

    .line 107
    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_2
    check-cast p0, Ljava/lang/Integer;

    .line 111
    .line 112
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result p0

    .line 116
    invoke-static {p0}, Lrm;->e(I)J

    .line 117
    .line 118
    .line 119
    move-result-wide v6

    .line 120
    new-instance p0, Lsv0;

    .line 121
    .line 122
    invoke-direct {p0, v6, v7}, Lsv0;-><init>(J)V

    .line 123
    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_3
    move-object p0, v2

    .line 127
    :goto_1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    iget-wide v7, p0, Lsv0;->a:J

    .line 131
    .line 132
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    sget-object v3, Lg26;->y:Lf26;

    .line 137
    .line 138
    invoke-static {p0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    if-eqz p0, :cond_4

    .line 142
    .line 143
    iget-object v1, v3, Lf26;->b:Lqa2;

    .line 144
    .line 145
    invoke-interface {v1, p0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    check-cast p0, Lfm4;

    .line 150
    .line 151
    goto :goto_2

    .line 152
    :cond_4
    move-object p0, v2

    .line 153
    :goto_2
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    iget-wide v9, p0, Lfm4;->a:J

    .line 157
    .line 158
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object p0

    .line 162
    if-eqz p0, :cond_5

    .line 163
    .line 164
    move-object v2, p0

    .line 165
    check-cast v2, Ljava/lang/Float;

    .line 166
    .line 167
    :cond_5
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 171
    .line 172
    .line 173
    move-result v6

    .line 174
    invoke-direct/range {v5 .. v10}, Lrb6;-><init>(FJJ)V

    .line 175
    .line 176
    .line 177
    return-object v5

    .line 178
    :pswitch_2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 179
    .line 180
    .line 181
    check-cast p1, Ljava/util/List;

    .line 182
    .line 183
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    if-eqz p0, :cond_6

    .line 188
    .line 189
    check-cast p0, Ljava/lang/Integer;

    .line 190
    .line 191
    goto :goto_3

    .line 192
    :cond_6
    move-object p0, v2

    .line 193
    :goto_3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 197
    .line 198
    .line 199
    move-result p0

    .line 200
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object p1

    .line 204
    if-eqz p1, :cond_7

    .line 205
    .line 206
    move-object v2, p1

    .line 207
    check-cast v2, Ljava/lang/Integer;

    .line 208
    .line 209
    :cond_7
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 210
    .line 211
    .line 212
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 213
    .line 214
    .line 215
    move-result p1

    .line 216
    invoke-static {p0, p1}, Lxu6;->a(II)J

    .line 217
    .line 218
    .line 219
    move-result-wide p0

    .line 220
    new-instance v0, Lp27;

    .line 221
    .line 222
    invoke-direct {v0, p0, p1}, Lp27;-><init>(J)V

    .line 223
    .line 224
    .line 225
    return-object v0

    .line 226
    :pswitch_3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    check-cast p1, Ljava/lang/Float;

    .line 230
    .line 231
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 232
    .line 233
    .line 234
    move-result p0

    .line 235
    new-instance p1, Lk00;

    .line 236
    .line 237
    invoke-direct {p1, p0}, Lk00;-><init>(F)V

    .line 238
    .line 239
    .line 240
    return-object p1

    .line 241
    :pswitch_4
    new-instance p0, Lc92;

    .line 242
    .line 243
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    .line 245
    .line 246
    check-cast p1, Ljava/lang/Integer;

    .line 247
    .line 248
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 249
    .line 250
    .line 251
    move-result p1

    .line 252
    invoke-direct {p0, p1}, Lc92;-><init>(I)V

    .line 253
    .line 254
    .line 255
    return-object p0

    .line 256
    :pswitch_5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 257
    .line 258
    .line 259
    check-cast p1, Ljava/util/List;

    .line 260
    .line 261
    new-instance p0, Lh17;

    .line 262
    .line 263
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    sget-object v1, Ls37;->b:[Lt37;

    .line 268
    .line 269
    sget-object v1, Lg26;->w:Lf26;

    .line 270
    .line 271
    iget-object v1, v1, Lf26;->b:Lqa2;

    .line 272
    .line 273
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 274
    .line 275
    invoke-static {v0, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 276
    .line 277
    .line 278
    if-eqz v0, :cond_8

    .line 279
    .line 280
    invoke-interface {v1, v0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    check-cast v0, Ls37;

    .line 285
    .line 286
    goto :goto_4

    .line 287
    :cond_8
    move-object v0, v2

    .line 288
    :goto_4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 289
    .line 290
    .line 291
    iget-wide v5, v0, Ls37;->a:J

    .line 292
    .line 293
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object p1

    .line 297
    invoke-static {p1, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    if-eqz p1, :cond_9

    .line 301
    .line 302
    invoke-interface {v1, p1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object p1

    .line 306
    move-object v2, p1

    .line 307
    check-cast v2, Ls37;

    .line 308
    .line 309
    :cond_9
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 310
    .line 311
    .line 312
    iget-wide v0, v2, Ls37;->a:J

    .line 313
    .line 314
    invoke-direct {p0, v5, v6, v0, v1}, Lh17;-><init>(JJ)V

    .line 315
    .line 316
    .line 317
    return-object p0

    .line 318
    :pswitch_6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 319
    .line 320
    .line 321
    check-cast p1, Ljava/util/List;

    .line 322
    .line 323
    new-instance p0, Lf17;

    .line 324
    .line 325
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    check-cast v0, Ljava/lang/Number;

    .line 330
    .line 331
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 332
    .line 333
    .line 334
    move-result v0

    .line 335
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    check-cast p1, Ljava/lang/Number;

    .line 340
    .line 341
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 342
    .line 343
    .line 344
    move-result p1

    .line 345
    invoke-direct {p0, v0, p1}, Lf17;-><init>(FF)V

    .line 346
    .line 347
    .line 348
    return-object p0

    .line 349
    :pswitch_7
    new-instance p0, Lfx6;

    .line 350
    .line 351
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 352
    .line 353
    .line 354
    check-cast p1, Ljava/lang/Integer;

    .line 355
    .line 356
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 357
    .line 358
    .line 359
    move-result p1

    .line 360
    invoke-direct {p0, p1}, Lfx6;-><init>(I)V

    .line 361
    .line 362
    .line 363
    return-object p0

    .line 364
    :pswitch_8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 365
    .line 366
    .line 367
    check-cast p1, Ljava/util/List;

    .line 368
    .line 369
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object p0

    .line 373
    sget-object v0, Lg26;->b:Lb26;

    .line 374
    .line 375
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 376
    .line 377
    invoke-static {p0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    move-result v1

    .line 381
    if-nez v1, :cond_a

    .line 382
    .line 383
    if-eqz p0, :cond_a

    .line 384
    .line 385
    iget-object v0, v0, Lb26;->b:Lqa2;

    .line 386
    .line 387
    invoke-interface {v0, p0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object p0

    .line 391
    check-cast p0, Ljava/util/List;

    .line 392
    .line 393
    goto :goto_5

    .line 394
    :cond_a
    move-object p0, v2

    .line 395
    :goto_5
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 396
    .line 397
    .line 398
    move-result-object p1

    .line 399
    if-eqz p1, :cond_b

    .line 400
    .line 401
    move-object v2, p1

    .line 402
    check-cast v2, Ljava/lang/String;

    .line 403
    .line 404
    :cond_b
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 405
    .line 406
    .line 407
    new-instance p1, Loi;

    .line 408
    .line 409
    invoke-direct {p1, p0, v2}, Loi;-><init>(Ljava/util/List;Ljava/lang/String;)V

    .line 410
    .line 411
    .line 412
    return-object p1

    .line 413
    :pswitch_9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 414
    .line 415
    .line 416
    check-cast p1, Ljava/util/List;

    .line 417
    .line 418
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 419
    .line 420
    .line 421
    move-result-object p0

    .line 422
    sget-object v1, Lg26;->i:Lb26;

    .line 423
    .line 424
    iget-object v1, v1, Lb26;->b:Lqa2;

    .line 425
    .line 426
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 427
    .line 428
    invoke-static {p0, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 429
    .line 430
    .line 431
    move-result v5

    .line 432
    if-nez v5, :cond_c

    .line 433
    .line 434
    if-eqz p0, :cond_c

    .line 435
    .line 436
    invoke-interface {v1, p0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object p0

    .line 440
    check-cast p0, Lqk6;

    .line 441
    .line 442
    goto :goto_6

    .line 443
    :cond_c
    move-object p0, v2

    .line 444
    :goto_6
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    move-result-object v4

    .line 448
    invoke-static {v4, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 449
    .line 450
    .line 451
    move-result v5

    .line 452
    if-nez v5, :cond_d

    .line 453
    .line 454
    if-eqz v4, :cond_d

    .line 455
    .line 456
    invoke-interface {v1, v4}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v4

    .line 460
    check-cast v4, Lqk6;

    .line 461
    .line 462
    goto :goto_7

    .line 463
    :cond_d
    move-object v4, v2

    .line 464
    :goto_7
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 465
    .line 466
    .line 467
    move-result-object v0

    .line 468
    invoke-static {v0, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 469
    .line 470
    .line 471
    move-result v5

    .line 472
    if-nez v5, :cond_e

    .line 473
    .line 474
    if-eqz v0, :cond_e

    .line 475
    .line 476
    invoke-interface {v1, v0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v0

    .line 480
    check-cast v0, Lqk6;

    .line 481
    .line 482
    goto :goto_8

    .line 483
    :cond_e
    move-object v0, v2

    .line 484
    :goto_8
    const/4 v5, 0x3

    .line 485
    invoke-interface {p1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 486
    .line 487
    .line 488
    move-result-object p1

    .line 489
    invoke-static {p1, v3}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 490
    .line 491
    .line 492
    move-result v3

    .line 493
    if-nez v3, :cond_f

    .line 494
    .line 495
    if-eqz p1, :cond_f

    .line 496
    .line 497
    invoke-interface {v1, p1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object p1

    .line 501
    move-object v2, p1

    .line 502
    check-cast v2, Lqk6;

    .line 503
    .line 504
    :cond_f
    new-instance p1, Lb27;

    .line 505
    .line 506
    invoke-direct {p1, p0, v4, v0, v2}, Lb27;-><init>(Lqk6;Lqk6;Lqk6;Lqk6;)V

    .line 507
    .line 508
    .line 509
    :pswitch_a
    return-object p1

    .line 510
    :pswitch_b
    check-cast p1, Ljava/util/Map;

    .line 511
    .line 512
    new-instance p0, Li16;

    .line 513
    .line 514
    invoke-direct {p0, p1}, Li16;-><init>(Ljava/util/Map;)V

    .line 515
    .line 516
    .line 517
    return-object p0

    .line 518
    :pswitch_c
    check-cast p1, Lg06;

    .line 519
    .line 520
    iget-object p0, p1, Lg06;->a:Ljava/lang/String;

    .line 521
    .line 522
    sget-object p1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 523
    .line 524
    invoke-virtual {p0, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 525
    .line 526
    .line 527
    move-result-object p0

    .line 528
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 529
    .line 530
    .line 531
    return-object p0

    .line 532
    :pswitch_d
    check-cast p1, Lg06;

    .line 533
    .line 534
    iget-boolean p0, p1, Lg06;->c:Z

    .line 535
    .line 536
    xor-int/2addr p0, v4

    .line 537
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 538
    .line 539
    .line 540
    move-result-object p0

    .line 541
    return-object p0

    .line 542
    :pswitch_e
    check-cast p1, Ljava/lang/String;

    .line 543
    .line 544
    sget-object p0, Lq06;->a:Lq06;

    .line 545
    .line 546
    invoke-static {p1, v3}, Lq06;->r(Ljava/lang/String;Z)Lg06;

    .line 547
    .line 548
    .line 549
    move-result-object p0

    .line 550
    return-object p0

    .line 551
    :pswitch_f
    check-cast p1, Ljava/lang/String;

    .line 552
    .line 553
    invoke-static {p1}, Lyn6;->g1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 554
    .line 555
    .line 556
    move-result-object p0

    .line 557
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 558
    .line 559
    .line 560
    move-result-object p0

    .line 561
    invoke-static {p0}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 562
    .line 563
    .line 564
    move-result p1

    .line 565
    if-nez p1, :cond_10

    .line 566
    .line 567
    move-object v2, p0

    .line 568
    :cond_10
    return-object v2

    .line 569
    :pswitch_10
    check-cast p1, Ljava/lang/String;

    .line 570
    .line 571
    sget-object p0, Lq06;->a:Lq06;

    .line 572
    .line 573
    invoke-static {p1, v4}, Lq06;->r(Ljava/lang/String;Z)Lg06;

    .line 574
    .line 575
    .line 576
    move-result-object p0

    .line 577
    return-object p0

    .line 578
    :pswitch_11
    check-cast p1, Ljava/lang/String;

    .line 579
    .line 580
    invoke-static {p1}, Lyn6;->g1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 581
    .line 582
    .line 583
    move-result-object p0

    .line 584
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 585
    .line 586
    .line 587
    move-result-object p0

    .line 588
    invoke-static {p0}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 589
    .line 590
    .line 591
    move-result p1

    .line 592
    if-nez p1, :cond_11

    .line 593
    .line 594
    move-object v2, p0

    .line 595
    :cond_11
    return-object v2

    .line 596
    :pswitch_12
    check-cast p1, Ljava/io/File;

    .line 597
    .line 598
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 599
    .line 600
    .line 601
    new-instance p0, Ljava/io/FileInputStream;

    .line 602
    .line 603
    invoke-direct {p0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 604
    .line 605
    .line 606
    const-wide/32 v0, 0x2000000

    .line 607
    .line 608
    .line 609
    :try_start_0
    invoke-static {p0, v0, v1, v2}, Lrm;->U(Ljava/io/InputStream;JLy81;)[B

    .line 610
    .line 611
    .line 612
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 613
    invoke-virtual {p0}, Ljava/io/FileInputStream;->close()V

    .line 614
    .line 615
    .line 616
    return-object p1

    .line 617
    :catchall_0
    move-exception v0

    .line 618
    move-object p1, v0

    .line 619
    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 620
    :catchall_1
    move-exception v0

    .line 621
    invoke-static {p0, p1}, Llq;->B(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 622
    .line 623
    .line 624
    throw v0

    .line 625
    :pswitch_13
    check-cast p1, Ljava/lang/String;

    .line 626
    .line 627
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 628
    .line 629
    .line 630
    return-object v1

    .line 631
    :pswitch_14
    check-cast p1, Ljava/lang/Long;

    .line 632
    .line 633
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 634
    .line 635
    .line 636
    return-object v1

    .line 637
    :pswitch_15
    check-cast p1, Lgv;

    .line 638
    .line 639
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 640
    .line 641
    .line 642
    return-object v1

    .line 643
    :pswitch_16
    check-cast p1, Ljava/lang/String;

    .line 644
    .line 645
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 646
    .line 647
    .line 648
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 649
    .line 650
    .line 651
    move-result p0

    .line 652
    move v0, v3

    .line 653
    :goto_9
    if-ge v0, p0, :cond_13

    .line 654
    .line 655
    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    .line 656
    .line 657
    .line 658
    move-result v1

    .line 659
    const/16 v2, 0x20

    .line 660
    .line 661
    if-eq v1, v2, :cond_12

    .line 662
    .line 663
    const/16 v2, 0x9

    .line 664
    .line 665
    if-eq v1, v2, :cond_12

    .line 666
    .line 667
    invoke-virtual {p1, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 668
    .line 669
    .line 670
    move-result-object p1

    .line 671
    goto :goto_a

    .line 672
    :cond_12
    add-int/lit8 v0, v0, 0x1

    .line 673
    .line 674
    goto :goto_9

    .line 675
    :cond_13
    :goto_a
    return-object p1

    .line 676
    :pswitch_17
    check-cast p1, Ljava/lang/String;

    .line 677
    .line 678
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 679
    .line 680
    .line 681
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 682
    .line 683
    .line 684
    move-result p0

    .line 685
    if-lez p0, :cond_14

    .line 686
    .line 687
    move v3, v4

    .line 688
    :cond_14
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 689
    .line 690
    .line 691
    move-result-object p0

    .line 692
    return-object p0

    .line 693
    :pswitch_18
    check-cast p1, Ljava/lang/String;

    .line 694
    .line 695
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 696
    .line 697
    .line 698
    return-object v1

    .line 699
    :pswitch_19
    check-cast p1, Ljava/lang/Boolean;

    .line 700
    .line 701
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 702
    .line 703
    .line 704
    return-object v1

    .line 705
    :pswitch_1a
    check-cast p1, Ljava/lang/String;

    .line 706
    .line 707
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 708
    .line 709
    .line 710
    return-object v1

    .line 711
    :pswitch_1b
    check-cast p1, Ljava/util/Set;

    .line 712
    .line 713
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 714
    .line 715
    .line 716
    return-object v1

    .line 717
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_14
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
