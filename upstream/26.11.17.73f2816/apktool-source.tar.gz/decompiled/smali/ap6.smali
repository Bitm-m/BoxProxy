.class public final synthetic Lap6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Lfa2;

.field public final synthetic l:Lsj7;

.field public final synthetic m:Lw44;

.field public final synthetic n:Lw44;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lfa2;Lsj7;Lw44;Lw44;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lap6;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lap6;->j:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p2, p0, Lap6;->k:Lfa2;

    .line 10
    .line 11
    iput-object p3, p0, Lap6;->l:Lsj7;

    .line 12
    .line 13
    iput-object p4, p0, Lap6;->m:Lw44;

    .line 14
    .line 15
    iput-object p5, p0, Lap6;->n:Lw44;

    .line 16
    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lsj7;Lfa2;Lw44;Lw44;B)V
    .locals 0

    .line 18
    iput-byte p6, p0, Lap6;->i:B

    iput-object p1, p0, Lap6;->j:Ljava/lang/String;

    iput-object p2, p0, Lap6;->l:Lsj7;

    iput-object p3, p0, Lap6;->k:Lfa2;

    iput-object p4, p0, Lap6;->m:Lw44;

    iput-object p5, p0, Lap6;->n:Lw44;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lap6;->i:B

    .line 4
    .line 5
    sget-object v2, Li21;->a:Ls9;

    .line 6
    .line 7
    sget-object v3, Lne7;->a:Lne7;

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    iget-object v5, v0, Lap6;->n:Lw44;

    .line 11
    .line 12
    iget-object v6, v0, Lap6;->m:Lw44;

    .line 13
    .line 14
    iget-object v7, v0, Lap6;->l:Lsj7;

    .line 15
    .line 16
    const/4 v8, 0x0

    .line 17
    const/4 v9, 0x3

    .line 18
    const/4 v10, 0x2

    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object/from16 v1, p1

    .line 23
    .line 24
    check-cast v1, Lub2;

    .line 25
    .line 26
    move-object/from16 v9, p2

    .line 27
    .line 28
    check-cast v9, Ljava/lang/Integer;

    .line 29
    .line 30
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result v9

    .line 34
    and-int/lit8 v11, v9, 0x3

    .line 35
    .line 36
    if-eq v11, v10, :cond_0

    .line 37
    .line 38
    move v8, v4

    .line 39
    :cond_0
    and-int/2addr v9, v4

    .line 40
    invoke-virtual {v1, v9, v8}, Lub2;->S(IZ)Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_7

    .line 45
    .line 46
    iget-object v4, v7, Lsj7;->l:Lw44;

    .line 47
    .line 48
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    check-cast v4, Ljava/lang/Boolean;

    .line 53
    .line 54
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 55
    .line 56
    .line 57
    move-result v12

    .line 58
    invoke-virtual {v7}, Lsj7;->d()Z

    .line 59
    .line 60
    .line 61
    move-result v13

    .line 62
    invoke-virtual {v1, v7}, Lub2;->g(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v8

    .line 70
    if-nez v4, :cond_1

    .line 71
    .line 72
    if-ne v8, v2, :cond_2

    .line 73
    .line 74
    :cond_1
    new-instance v8, Lgp6;

    .line 75
    .line 76
    invoke-direct {v8, v7, v10}, Lgp6;-><init>(Lsj7;B)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v1, v8}, Lub2;->k0(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_2
    move-object v15, v8

    .line 83
    check-cast v15, Lfa2;

    .line 84
    .line 85
    invoke-virtual {v1, v6}, Lub2;->g(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v7

    .line 93
    if-nez v4, :cond_3

    .line 94
    .line 95
    if-ne v7, v2, :cond_4

    .line 96
    .line 97
    :cond_3
    new-instance v7, Ldp6;

    .line 98
    .line 99
    const/16 v4, 0x1b

    .line 100
    .line 101
    invoke-direct {v7, v6, v4}, Ldp6;-><init>(Lw44;B)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v1, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    :cond_4
    move-object/from16 v16, v7

    .line 108
    .line 109
    check-cast v16, Lfa2;

    .line 110
    .line 111
    invoke-virtual {v1, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    if-nez v4, :cond_5

    .line 120
    .line 121
    if-ne v6, v2, :cond_6

    .line 122
    .line 123
    :cond_5
    new-instance v6, Ldp6;

    .line 124
    .line 125
    const/16 v2, 0x1c

    .line 126
    .line 127
    invoke-direct {v6, v5, v2}, Ldp6;-><init>(Lw44;B)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v1, v6}, Lub2;->k0(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_6
    move-object/from16 v17, v6

    .line 134
    .line 135
    check-cast v17, Lfa2;

    .line 136
    .line 137
    const/16 v18, 0x0

    .line 138
    .line 139
    const/16 v20, 0x0

    .line 140
    .line 141
    iget-object v11, v0, Lap6;->j:Ljava/lang/String;

    .line 142
    .line 143
    iget-object v14, v0, Lap6;->k:Lfa2;

    .line 144
    .line 145
    move-object/from16 v19, v1

    .line 146
    .line 147
    invoke-static/range {v11 .. v20}, Liu6;->m(Ljava/lang/String;ZZLfa2;Lfa2;Lfa2;Lfa2;Li14;Lub2;I)V

    .line 148
    .line 149
    .line 150
    goto :goto_0

    .line 151
    :cond_7
    move-object/from16 v19, v1

    .line 152
    .line 153
    invoke-virtual/range {v19 .. v19}, Lub2;->V()V

    .line 154
    .line 155
    .line 156
    :goto_0
    return-object v3

    .line 157
    :pswitch_0
    move-object/from16 v12, p1

    .line 158
    .line 159
    check-cast v12, Lub2;

    .line 160
    .line 161
    move-object/from16 v1, p2

    .line 162
    .line 163
    check-cast v1, Ljava/lang/Integer;

    .line 164
    .line 165
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    and-int/lit8 v2, v1, 0x3

    .line 170
    .line 171
    if-eq v2, v10, :cond_8

    .line 172
    .line 173
    move v2, v4

    .line 174
    goto :goto_1

    .line 175
    :cond_8
    move v2, v8

    .line 176
    :goto_1
    and-int/2addr v1, v4

    .line 177
    invoke-virtual {v12, v1, v2}, Lub2;->S(IZ)Z

    .line 178
    .line 179
    .line 180
    move-result v1

    .line 181
    if-eqz v1, :cond_9

    .line 182
    .line 183
    sget-object v1, Lz77;->a:Lxu4;

    .line 184
    .line 185
    invoke-static {v12}, Lab3;->N(Lub2;)J

    .line 186
    .line 187
    .line 188
    move-result-wide v1

    .line 189
    invoke-static {v12}, Lab3;->N(Lub2;)J

    .line 190
    .line 191
    .line 192
    move-result-wide v10

    .line 193
    invoke-static {v8, v8, v12, v9}, Lab3;->L(ZZLub2;I)J

    .line 194
    .line 195
    .line 196
    move-result-wide v13

    .line 197
    invoke-static {v8, v8, v12, v9}, Lab3;->L(ZZLub2;I)J

    .line 198
    .line 199
    .line 200
    move-result-wide v16

    .line 201
    sget-object v4, Lwr3;->b:Lyt1;

    .line 202
    .line 203
    invoke-virtual {v12, v4}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 204
    .line 205
    .line 206
    move-result-object v4

    .line 207
    check-cast v4, Ltr3;

    .line 208
    .line 209
    iget-object v4, v4, Ltr3;->a:Lyv0;

    .line 210
    .line 211
    iget-wide v8, v4, Lyv0;->q:J

    .line 212
    .line 213
    move-object/from16 v18, v12

    .line 214
    .line 215
    move-wide v12, v13

    .line 216
    move-wide v14, v8

    .line 217
    move-wide v8, v1

    .line 218
    invoke-static/range {v8 .. v18}, Lz77;->b(JJJJJLub2;)Ly77;

    .line 219
    .line 220
    .line 221
    move-result-object v10

    .line 222
    move-object/from16 v12, v18

    .line 223
    .line 224
    sget-object v1, Lrn7;->w:Ljava/util/WeakHashMap;

    .line 225
    .line 226
    invoke-static {v12}, Lat6;->l(Lub2;)Lrn7;

    .line 227
    .line 228
    .line 229
    move-result-object v1

    .line 230
    iget-object v1, v1, Lrn7;->l:Lke7;

    .line 231
    .line 232
    const/16 v2, 0x10

    .line 233
    .line 234
    const/16 v4, 0xf

    .line 235
    .line 236
    or-int/2addr v2, v4

    .line 237
    new-instance v9, Lpg3;

    .line 238
    .line 239
    invoke-direct {v9, v1, v2}, Lpg3;-><init>(Lkm7;I)V

    .line 240
    .line 241
    .line 242
    new-instance v1, Lyc6;

    .line 243
    .line 244
    const/16 v2, 0xb

    .line 245
    .line 246
    iget-object v8, v0, Lap6;->j:Ljava/lang/String;

    .line 247
    .line 248
    invoke-direct {v1, v8, v2}, Lyc6;-><init>(Ljava/lang/String;B)V

    .line 249
    .line 250
    .line 251
    const v2, -0x206693b

    .line 252
    .line 253
    .line 254
    invoke-static {v2, v1, v12}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    new-instance v2, Lx47;

    .line 259
    .line 260
    iget-object v0, v0, Lap6;->k:Lfa2;

    .line 261
    .line 262
    invoke-direct {v2, v0, v4}, Lx47;-><init>(Lfa2;B)V

    .line 263
    .line 264
    .line 265
    const v0, -0x4e0433b9

    .line 266
    .line 267
    .line 268
    invoke-static {v0, v2, v12}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    new-instance v2, Lbv5;

    .line 273
    .line 274
    const/4 v4, 0x4

    .line 275
    invoke-direct {v2, v7, v6, v5, v4}, Lbv5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 276
    .line 277
    .line 278
    const v4, 0x4200f0b0

    .line 279
    .line 280
    .line 281
    invoke-static {v4, v2, v12}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 282
    .line 283
    .line 284
    move-result-object v7

    .line 285
    const/4 v11, 0x0

    .line 286
    const/16 v13, 0xd86

    .line 287
    .line 288
    const/4 v5, 0x0

    .line 289
    const/4 v8, 0x0

    .line 290
    move-object v6, v0

    .line 291
    move-object v4, v1

    .line 292
    invoke-static/range {v4 .. v13}, Ldp;->c(Lc01;Li14;Lc01;Lc01;FLpg3;Ly77;Lxu4;Lub2;I)V

    .line 293
    .line 294
    .line 295
    goto :goto_2

    .line 296
    :cond_9
    invoke-virtual {v12}, Lub2;->V()V

    .line 297
    .line 298
    .line 299
    :goto_2
    return-object v3

    .line 300
    :pswitch_1
    move-object/from16 v1, p1

    .line 301
    .line 302
    check-cast v1, Lub2;

    .line 303
    .line 304
    move-object/from16 v11, p2

    .line 305
    .line 306
    check-cast v11, Ljava/lang/Integer;

    .line 307
    .line 308
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 309
    .line 310
    .line 311
    move-result v11

    .line 312
    and-int/lit8 v12, v11, 0x3

    .line 313
    .line 314
    if-eq v12, v10, :cond_a

    .line 315
    .line 316
    move v12, v4

    .line 317
    goto :goto_3

    .line 318
    :cond_a
    move v12, v8

    .line 319
    :goto_3
    and-int/2addr v11, v4

    .line 320
    invoke-virtual {v1, v11, v12}, Lub2;->S(IZ)Z

    .line 321
    .line 322
    .line 323
    move-result v4

    .line 324
    if-eqz v4, :cond_11

    .line 325
    .line 326
    iget-object v4, v7, Lsj7;->l:Lw44;

    .line 327
    .line 328
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 329
    .line 330
    .line 331
    move-result-object v4

    .line 332
    check-cast v4, Ljava/lang/Boolean;

    .line 333
    .line 334
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 335
    .line 336
    .line 337
    move-result v14

    .line 338
    invoke-virtual {v7}, Lsj7;->d()Z

    .line 339
    .line 340
    .line 341
    move-result v15

    .line 342
    invoke-virtual {v1, v7}, Lub2;->g(Ljava/lang/Object;)Z

    .line 343
    .line 344
    .line 345
    move-result v4

    .line 346
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 347
    .line 348
    .line 349
    move-result-object v11

    .line 350
    if-nez v4, :cond_b

    .line 351
    .line 352
    if-ne v11, v2, :cond_c

    .line 353
    .line 354
    :cond_b
    new-instance v11, Lgp6;

    .line 355
    .line 356
    invoke-direct {v11, v7, v8}, Lgp6;-><init>(Lsj7;B)V

    .line 357
    .line 358
    .line 359
    invoke-virtual {v1, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    :cond_c
    move-object/from16 v17, v11

    .line 363
    .line 364
    check-cast v17, Lfa2;

    .line 365
    .line 366
    invoke-virtual {v1, v6}, Lub2;->g(Ljava/lang/Object;)Z

    .line 367
    .line 368
    .line 369
    move-result v4

    .line 370
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v7

    .line 374
    if-nez v4, :cond_d

    .line 375
    .line 376
    if-ne v7, v2, :cond_e

    .line 377
    .line 378
    :cond_d
    new-instance v7, Ldp6;

    .line 379
    .line 380
    invoke-direct {v7, v6, v10}, Ldp6;-><init>(Lw44;B)V

    .line 381
    .line 382
    .line 383
    invoke-virtual {v1, v7}, Lub2;->k0(Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    :cond_e
    move-object/from16 v18, v7

    .line 387
    .line 388
    check-cast v18, Lfa2;

    .line 389
    .line 390
    invoke-virtual {v1, v5}, Lub2;->g(Ljava/lang/Object;)Z

    .line 391
    .line 392
    .line 393
    move-result v4

    .line 394
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v6

    .line 398
    if-nez v4, :cond_f

    .line 399
    .line 400
    if-ne v6, v2, :cond_10

    .line 401
    .line 402
    :cond_f
    new-instance v6, Ldp6;

    .line 403
    .line 404
    invoke-direct {v6, v5, v9}, Ldp6;-><init>(Lw44;B)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v1, v6}, Lub2;->k0(Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    :cond_10
    move-object/from16 v19, v6

    .line 411
    .line 412
    check-cast v19, Lfa2;

    .line 413
    .line 414
    const/16 v20, 0x0

    .line 415
    .line 416
    const/16 v22, 0x0

    .line 417
    .line 418
    iget-object v13, v0, Lap6;->j:Ljava/lang/String;

    .line 419
    .line 420
    iget-object v0, v0, Lap6;->k:Lfa2;

    .line 421
    .line 422
    move-object/from16 v16, v0

    .line 423
    .line 424
    move-object/from16 v21, v1

    .line 425
    .line 426
    invoke-static/range {v13 .. v22}, Liu6;->m(Ljava/lang/String;ZZLfa2;Lfa2;Lfa2;Lfa2;Li14;Lub2;I)V

    .line 427
    .line 428
    .line 429
    goto :goto_4

    .line 430
    :cond_11
    move-object/from16 v21, v1

    .line 431
    .line 432
    invoke-virtual/range {v21 .. v21}, Lub2;->V()V

    .line 433
    .line 434
    .line 435
    :goto_4
    return-object v3

    .line 436
    nop

    .line 437
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
