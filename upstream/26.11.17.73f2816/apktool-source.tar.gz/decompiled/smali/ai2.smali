.class public final Lai2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lhm5;


# instance fields
.field public final i:Lzh2;

.field public final j:Lbi2;


# direct methods
.method public constructor <init>(Lzh2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lai2;->i:Lzh2;

    .line 5
    .line 6
    invoke-interface {p1}, Lzh2;->c()Lbi2;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    iput-object p1, p0, Lai2;->j:Lbi2;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    return-void
.end method

.method public final d()V
    .locals 1

    .line 1
    iget-object v0, p0, Lai2;->i:Lzh2;

    .line 2
    .line 3
    iget-object p0, p0, Lai2;->j:Lbi2;

    .line 4
    .line 5
    invoke-interface {v0, p0}, Lzh2;->a(Lbi2;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final g()V
    .locals 1

    .line 1
    iget-object v0, p0, Lai2;->i:Lzh2;

    .line 2
    .line 3
    iget-object p0, p0, Lai2;->j:Lbi2;

    .line 4
    .line 5
    invoke-interface {v0, p0}, Lzh2;->a(Lbi2;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
