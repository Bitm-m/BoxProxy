.class public final synthetic Lbb6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Lva0;

.field public final synthetic l:Lw44;


# direct methods
.method public synthetic constructor <init>(ZLva0;Lw44;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lbb6;->i:B

    .line 2
    .line 3
    iput-boolean p1, p0, Lbb6;->j:Z

    .line 4
    .line 5
    iput-object p2, p0, Lbb6;->k:Lva0;

    .line 6
    .line 7
    iput-object p3, p0, Lbb6;->l:Lw44;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lbb6;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    sget-object v2, Lqy1;->i:Lqy1;

    .line 6
    .line 7
    iget-object v3, p0, Lbb6;->l:Lw44;

    .line 8
    .line 9
    iget-object v4, p0, Lbb6;->k:Lva0;

    .line 10
    .line 11
    iget-boolean p0, p0, Lbb6;->j:Z

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 17
    .line 18
    invoke-interface {v3, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    if-eqz p0, :cond_0

    .line 22
    .line 23
    invoke-virtual {v4, v2}, Lva0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    :cond_0
    return-object v1

    .line 27
    :pswitch_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-interface {v3, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    if-eqz p0, :cond_1

    .line 33
    .line 34
    invoke-virtual {v4, v2}, Lva0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    :cond_1
    return-object v1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
