.class public final synthetic Lb93;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lw83;


# direct methods
.method public synthetic constructor <init>(Lw83;B)V
    .locals 0

    .line 10
    iput-byte p2, p0, Lb93;->i:B

    iput-object p1, p0, Lb93;->j:Lw83;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lw83;I)V
    .locals 0

    .line 1
    const/4 p2, 0x4

    .line 2
    iput-byte p2, p0, Lb93;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb93;->j:Lw83;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb93;->i:B

    .line 4
    .line 5
    sget-object v2, Lja3;->a0:Lxg2;

    .line 6
    .line 7
    const/high16 v3, 0x41900000    # 18.0f

    .line 8
    .line 9
    const/high16 v4, 0x41a00000    # 20.0f

    .line 10
    .line 11
    const/high16 v5, 0x3f800000    # 1.0f

    .line 12
    .line 13
    sget-object v6, Lf14;->i:Lf14;

    .line 14
    .line 15
    const/4 v7, 0x2

    .line 16
    const/4 v8, 0x0

    .line 17
    sget-object v9, Lne7;->a:Lne7;

    .line 18
    .line 19
    iget-object v0, v0, Lb93;->j:Lw83;

    .line 20
    .line 21
    const/4 v10, 0x1

    .line 22
    packed-switch v1, :pswitch_data_0

    .line 23
    .line 24
    .line 25
    move-object/from16 v1, p1

    .line 26
    .line 27
    check-cast v1, Lub2;

    .line 28
    .line 29
    move-object/from16 v2, p2

    .line 30
    .line 31
    check-cast v2, Ljava/lang/Integer;

    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    invoke-static {v10}, Lub3;->b0(I)I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-static {v0, v1, v2}, Ljw;->N(Lw83;Lub2;I)V

    .line 41
    .line 42
    .line 43
    return-object v9

    .line 44
    :pswitch_0
    move-object/from16 v14, p1

    .line 45
    .line 46
    check-cast v14, Lub2;

    .line 47
    .line 48
    move-object/from16 v1, p2

    .line 49
    .line 50
    check-cast v1, Ljava/lang/Integer;

    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    and-int/lit8 v2, v1, 0x3

    .line 57
    .line 58
    if-eq v2, v7, :cond_0

    .line 59
    .line 60
    move v2, v10

    .line 61
    goto :goto_0

    .line 62
    :cond_0
    move v2, v8

    .line 63
    :goto_0
    and-int/2addr v1, v10

    .line 64
    invoke-virtual {v14, v1, v2}, Lub2;->S(IZ)Z

    .line 65
    .line 66
    .line 67
    move-result v1

    .line 68
    if-eqz v1, :cond_1

    .line 69
    .line 70
    invoke-static {v6, v5}, Lch6;->d(Li14;F)Li14;

    .line 71
    .line 72
    .line 73
    move-result-object v10

    .line 74
    new-instance v1, Lb93;

    .line 75
    .line 76
    invoke-direct {v1, v0, v8}, Lb93;-><init>(Lw83;B)V

    .line 77
    .line 78
    .line 79
    const v0, 0x62705495

    .line 80
    .line 81
    .line 82
    invoke-static {v0, v1, v14}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 83
    .line 84
    .line 85
    move-result-object v13

    .line 86
    const/16 v15, 0x186

    .line 87
    .line 88
    const/16 v16, 0x2

    .line 89
    .line 90
    const-wide/16 v11, 0x0

    .line 91
    .line 92
    invoke-static/range {v10 .. v16}, Lqr3;->g(Li14;JLc01;Lub2;II)V

    .line 93
    .line 94
    .line 95
    goto :goto_1

    .line 96
    :cond_1
    invoke-virtual {v14}, Lub2;->V()V

    .line 97
    .line 98
    .line 99
    :goto_1
    return-object v9

    .line 100
    :pswitch_1
    move-object/from16 v4, p1

    .line 101
    .line 102
    check-cast v4, Lub2;

    .line 103
    .line 104
    move-object/from16 v1, p2

    .line 105
    .line 106
    check-cast v1, Ljava/lang/Integer;

    .line 107
    .line 108
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    and-int/lit8 v2, v1, 0x3

    .line 113
    .line 114
    if-eq v2, v7, :cond_2

    .line 115
    .line 116
    move v8, v10

    .line 117
    :cond_2
    and-int/2addr v1, v10

    .line 118
    invoke-virtual {v4, v1, v8}, Lub2;->S(IZ)Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-eqz v1, :cond_3

    .line 123
    .line 124
    invoke-static {v6, v5}, Lch6;->d(Li14;F)Li14;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    new-instance v2, Lb93;

    .line 129
    .line 130
    invoke-direct {v2, v0, v10}, Lb93;-><init>(Lw83;B)V

    .line 131
    .line 132
    .line 133
    const v0, 0x266be8d4

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v2, v4}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 137
    .line 138
    .line 139
    move-result-object v3

    .line 140
    const/16 v5, 0x186

    .line 141
    .line 142
    const/4 v6, 0x2

    .line 143
    move-object v0, v1

    .line 144
    const-wide/16 v1, 0x0

    .line 145
    .line 146
    invoke-static/range {v0 .. v6}, Lqr3;->g(Li14;JLc01;Lub2;II)V

    .line 147
    .line 148
    .line 149
    goto :goto_2

    .line 150
    :cond_3
    invoke-virtual {v4}, Lub2;->V()V

    .line 151
    .line 152
    .line 153
    :goto_2
    return-object v9

    .line 154
    :pswitch_2
    move-object/from16 v15, p1

    .line 155
    .line 156
    check-cast v15, Lub2;

    .line 157
    .line 158
    move-object/from16 v1, p2

    .line 159
    .line 160
    check-cast v1, Ljava/lang/Integer;

    .line 161
    .line 162
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 163
    .line 164
    .line 165
    move-result v1

    .line 166
    and-int/lit8 v5, v1, 0x3

    .line 167
    .line 168
    if-eq v5, v7, :cond_4

    .line 169
    .line 170
    move v5, v10

    .line 171
    goto :goto_3

    .line 172
    :cond_4
    move v5, v8

    .line 173
    :goto_3
    and-int/2addr v1, v10

    .line 174
    invoke-virtual {v15, v1, v5}, Lub2;->S(IZ)Z

    .line 175
    .line 176
    .line 177
    move-result v1

    .line 178
    if-eqz v1, :cond_6

    .line 179
    .line 180
    invoke-static {v6, v4, v3}, Lmi1;->D(Li14;FF)Li14;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    sget-object v3, Lt6;->k:Lr20;

    .line 185
    .line 186
    invoke-static {v3, v8}, Lnb0;->c(Lr20;Z)Lis3;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    iget-wide v4, v15, Lub2;->T:J

    .line 191
    .line 192
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 193
    .line 194
    .line 195
    move-result v4

    .line 196
    invoke-virtual {v15}, Lub2;->m()Lh05;

    .line 197
    .line 198
    .line 199
    move-result-object v5

    .line 200
    invoke-static {v15, v1}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    sget-object v6, La21;->d:Lt6;

    .line 205
    .line 206
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 207
    .line 208
    .line 209
    invoke-virtual {v15}, Lub2;->e0()V

    .line 210
    .line 211
    .line 212
    iget-boolean v6, v15, Lub2;->S:Z

    .line 213
    .line 214
    if-eqz v6, :cond_5

    .line 215
    .line 216
    invoke-virtual {v15, v2}, Lub2;->l(Lfa2;)V

    .line 217
    .line 218
    .line 219
    goto :goto_4

    .line 220
    :cond_5
    invoke-virtual {v15}, Lub2;->n0()V

    .line 221
    .line 222
    .line 223
    :goto_4
    sget-object v2, Lt6;->S:Lf11;

    .line 224
    .line 225
    invoke-static {v2, v15, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    sget-object v2, Lt6;->R:Lf11;

    .line 229
    .line 230
    invoke-static {v2, v15, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 234
    .line 235
    .line 236
    move-result-object v2

    .line 237
    sget-object v3, Lt6;->T:Lf11;

    .line 238
    .line 239
    invoke-static {v3, v15, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 240
    .line 241
    .line 242
    invoke-static {v15}, Les6;->l(Lub2;)V

    .line 243
    .line 244
    .line 245
    sget-object v2, Lt6;->Q:Lf11;

    .line 246
    .line 247
    invoke-static {v2, v15, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    iget-object v11, v0, Lw83;->b:Ly07;

    .line 251
    .line 252
    iget-object v12, v0, Lw83;->d:Lu46;

    .line 253
    .line 254
    const v0, 0x7f0f0221

    .line 255
    .line 256
    .line 257
    invoke-static {v0, v15}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object v13

    .line 261
    invoke-static {}, Les6;->g()Ltw2;

    .line 262
    .line 263
    .line 264
    move-result-object v14

    .line 265
    const/16 v16, 0x0

    .line 266
    .line 267
    invoke-static/range {v11 .. v16}, Ljw;->O(Ly07;Lu46;Ljava/lang/String;Ltw2;Lub2;I)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v15, v10}, Lub2;->r(Z)V

    .line 271
    .line 272
    .line 273
    goto :goto_5

    .line 274
    :cond_6
    invoke-virtual {v15}, Lub2;->V()V

    .line 275
    .line 276
    .line 277
    :goto_5
    return-object v9

    .line 278
    :pswitch_3
    move-object/from16 v1, p1

    .line 279
    .line 280
    check-cast v1, Lub2;

    .line 281
    .line 282
    move-object/from16 v5, p2

    .line 283
    .line 284
    check-cast v5, Ljava/lang/Integer;

    .line 285
    .line 286
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 287
    .line 288
    .line 289
    move-result v5

    .line 290
    and-int/lit8 v11, v5, 0x3

    .line 291
    .line 292
    if-eq v11, v7, :cond_7

    .line 293
    .line 294
    move v7, v10

    .line 295
    goto :goto_6

    .line 296
    :cond_7
    move v7, v8

    .line 297
    :goto_6
    and-int/2addr v5, v10

    .line 298
    invoke-virtual {v1, v5, v7}, Lub2;->S(IZ)Z

    .line 299
    .line 300
    .line 301
    move-result v5

    .line 302
    if-eqz v5, :cond_9

    .line 303
    .line 304
    invoke-static {v6, v4, v3}, Lmi1;->D(Li14;FF)Li14;

    .line 305
    .line 306
    .line 307
    move-result-object v3

    .line 308
    sget-object v4, Lt6;->k:Lr20;

    .line 309
    .line 310
    invoke-static {v4, v8}, Lnb0;->c(Lr20;Z)Lis3;

    .line 311
    .line 312
    .line 313
    move-result-object v4

    .line 314
    iget-wide v5, v1, Lub2;->T:J

    .line 315
    .line 316
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 317
    .line 318
    .line 319
    move-result v5

    .line 320
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 321
    .line 322
    .line 323
    move-result-object v6

    .line 324
    invoke-static {v1, v3}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 325
    .line 326
    .line 327
    move-result-object v3

    .line 328
    sget-object v7, La21;->d:Lt6;

    .line 329
    .line 330
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 331
    .line 332
    .line 333
    invoke-virtual {v1}, Lub2;->e0()V

    .line 334
    .line 335
    .line 336
    iget-boolean v7, v1, Lub2;->S:Z

    .line 337
    .line 338
    if-eqz v7, :cond_8

    .line 339
    .line 340
    invoke-virtual {v1, v2}, Lub2;->l(Lfa2;)V

    .line 341
    .line 342
    .line 343
    goto :goto_7

    .line 344
    :cond_8
    invoke-virtual {v1}, Lub2;->n0()V

    .line 345
    .line 346
    .line 347
    :goto_7
    sget-object v2, Lt6;->S:Lf11;

    .line 348
    .line 349
    invoke-static {v2, v1, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    sget-object v2, Lt6;->R:Lf11;

    .line 353
    .line 354
    invoke-static {v2, v1, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 355
    .line 356
    .line 357
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 358
    .line 359
    .line 360
    move-result-object v2

    .line 361
    sget-object v4, Lt6;->T:Lf11;

    .line 362
    .line 363
    invoke-static {v4, v1, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 364
    .line 365
    .line 366
    invoke-static {v1}, Les6;->l(Lub2;)V

    .line 367
    .line 368
    .line 369
    sget-object v2, Lt6;->Q:Lf11;

    .line 370
    .line 371
    invoke-static {v2, v1, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 372
    .line 373
    .line 374
    iget-object v2, v0, Lw83;->c:Ly07;

    .line 375
    .line 376
    iget-object v0, v0, Lw83;->e:Lu46;

    .line 377
    .line 378
    const v3, 0x7f0f0228

    .line 379
    .line 380
    .line 381
    invoke-static {v3, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v3

    .line 385
    move-object v4, v1

    .line 386
    move-object v1, v0

    .line 387
    move-object v0, v2

    .line 388
    move-object v2, v3

    .line 389
    invoke-static {}, Lbb3;->H()Ltw2;

    .line 390
    .line 391
    .line 392
    move-result-object v3

    .line 393
    const/4 v5, 0x0

    .line 394
    invoke-static/range {v0 .. v5}, Ljw;->O(Ly07;Lu46;Ljava/lang/String;Ltw2;Lub2;I)V

    .line 395
    .line 396
    .line 397
    invoke-virtual {v4, v10}, Lub2;->r(Z)V

    .line 398
    .line 399
    .line 400
    goto :goto_8

    .line 401
    :cond_9
    move-object v4, v1

    .line 402
    invoke-virtual {v4}, Lub2;->V()V

    .line 403
    .line 404
    .line 405
    :goto_8
    return-object v9

    .line 406
    nop

    .line 407
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
