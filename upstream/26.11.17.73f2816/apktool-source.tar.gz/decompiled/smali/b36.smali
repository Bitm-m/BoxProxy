.class public final synthetic Lb36;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Lfa2;

.field public final synthetic l:Lfa2;

.field public final synthetic m:Lqa2;


# direct methods
.method public synthetic constructor <init>(ZLfa2;Lfa2;Lqa2;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lb36;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-boolean p1, p0, Lb36;->j:Z

    .line 8
    .line 9
    iput-object p2, p0, Lb36;->k:Lfa2;

    .line 10
    .line 11
    iput-object p3, p0, Lb36;->l:Lfa2;

    .line 12
    .line 13
    iput-object p4, p0, Lb36;->m:Lqa2;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(ZLfa2;Lfa2;Lqa2;I)V
    .locals 0

    .line 16
    const/4 p5, 0x1

    iput-byte p5, p0, Lb36;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lb36;->j:Z

    iput-object p2, p0, Lb36;->k:Lfa2;

    iput-object p3, p0, Lb36;->l:Lfa2;

    iput-object p4, p0, Lb36;->m:Lqa2;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb36;->i:B

    .line 4
    .line 5
    sget-object v2, Lne7;->a:Lne7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    packed-switch v1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    move-object/from16 v8, p1

    .line 12
    .line 13
    check-cast v8, Lub2;

    .line 14
    .line 15
    move-object/from16 v1, p2

    .line 16
    .line 17
    check-cast v1, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {v3}, Lub3;->b0(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    iget-boolean v4, v0, Lb36;->j:Z

    .line 27
    .line 28
    iget-object v5, v0, Lb36;->k:Lfa2;

    .line 29
    .line 30
    iget-object v6, v0, Lb36;->l:Lfa2;

    .line 31
    .line 32
    iget-object v7, v0, Lb36;->m:Lqa2;

    .line 33
    .line 34
    invoke-static/range {v4 .. v9}, Loa3;->s(ZLfa2;Lfa2;Lqa2;Lub2;I)V

    .line 35
    .line 36
    .line 37
    return-object v2

    .line 38
    :pswitch_0
    move-object/from16 v1, p1

    .line 39
    .line 40
    check-cast v1, Lub2;

    .line 41
    .line 42
    move-object/from16 v4, p2

    .line 43
    .line 44
    check-cast v4, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    and-int/lit8 v5, v4, 0x3

    .line 51
    .line 52
    const/4 v6, 0x2

    .line 53
    if-eq v5, v6, :cond_0

    .line 54
    .line 55
    move v5, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_0
    const/4 v5, 0x0

    .line 58
    :goto_0
    and-int/2addr v4, v3

    .line 59
    invoke-virtual {v1, v4, v5}, Lub2;->S(IZ)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    if-eqz v3, :cond_3

    .line 64
    .line 65
    iget-boolean v3, v0, Lb36;->j:Z

    .line 66
    .line 67
    invoke-virtual {v1, v3}, Lub2;->h(Z)Z

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    iget-object v5, v0, Lb36;->k:Lfa2;

    .line 76
    .line 77
    if-nez v3, :cond_1

    .line 78
    .line 79
    sget-object v3, Li21;->a:Ls9;

    .line 80
    .line 81
    if-ne v4, v3, :cond_2

    .line 82
    .line 83
    :cond_1
    invoke-interface {v5}, Lfa2;->invoke()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    check-cast v3, Ljava/lang/Number;

    .line 88
    .line 89
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 90
    .line 91
    .line 92
    move-result v3

    .line 93
    const/high16 v4, 0x42c80000    # 100.0f

    .line 94
    .line 95
    mul-float/2addr v3, v4

    .line 96
    float-to-int v3, v3

    .line 97
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    invoke-static {v3}, Lhb3;->Q(Ljava/lang/Object;)Ldy4;

    .line 102
    .line 103
    .line 104
    move-result-object v4

    .line 105
    invoke-virtual {v1, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    :cond_2
    check-cast v4, Lw44;

    .line 109
    .line 110
    new-instance v3, Lh41;

    .line 111
    .line 112
    const/16 v6, 0xd

    .line 113
    .line 114
    invoke-direct {v3, v4, v6}, Lh41;-><init>(Lw44;B)V

    .line 115
    .line 116
    .line 117
    const v6, -0x6eaca153

    .line 118
    .line 119
    .line 120
    invoke-static {v6, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 121
    .line 122
    .line 123
    move-result-object v14

    .line 124
    new-instance v3, Lzl;

    .line 125
    .line 126
    iget-object v6, v0, Lb36;->l:Lfa2;

    .line 127
    .line 128
    iget-object v0, v0, Lb36;->m:Lqa2;

    .line 129
    .line 130
    invoke-direct {v3, v6, v5, v0, v4}, Lzl;-><init>(Lfa2;Lfa2;Lqa2;Lw44;)V

    .line 131
    .line 132
    .line 133
    const v0, 0x66e7e61e

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 137
    .line 138
    .line 139
    move-result-object v15

    .line 140
    const v17, 0x36000

    .line 141
    .line 142
    .line 143
    const/16 v18, 0xf

    .line 144
    .line 145
    const/4 v10, 0x0

    .line 146
    const/4 v11, 0x0

    .line 147
    const/4 v12, 0x0

    .line 148
    const/4 v13, 0x0

    .line 149
    move-object/from16 v16, v1

    .line 150
    .line 151
    invoke-static/range {v10 .. v18}, Lkb3;->d(Li14;FLvv;Lu46;Lc01;Lc01;Lub2;II)V

    .line 152
    .line 153
    .line 154
    goto :goto_1

    .line 155
    :cond_3
    move-object/from16 v16, v1

    .line 156
    .line 157
    invoke-virtual/range {v16 .. v16}, Lub2;->V()V

    .line 158
    .line 159
    .line 160
    :goto_1
    return-object v2

    .line 161
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
