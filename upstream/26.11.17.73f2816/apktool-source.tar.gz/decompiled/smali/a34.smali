.class public final La34;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lb34;


# instance fields
.field public final a:Lsn0;


# direct methods
.method public constructor <init>(Lsn0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La34;->a:Lsn0;

    .line 5
    .line 6
    return-void
.end method
