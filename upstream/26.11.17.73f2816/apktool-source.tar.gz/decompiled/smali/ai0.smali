.class public final Lai0;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lul1;


# instance fields
.field public i:Ljf0;

.field public j:Lmj7;

.field public k:Lkd;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lt6;->f0:Lt6;

    .line 5
    .line 6
    iput-object v0, p0, Lai0;->i:Ljf0;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lai0;->i:Ljf0;

    .line 2
    .line 3
    invoke-interface {p0}, Ljf0;->a()Lul1;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Lul1;->a()F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public final c(Lqa2;)Lmj7;
    .locals 2

    .line 1
    new-instance v0, Lm50;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, p1, v1}, Lm50;-><init>(Lqa2;B)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Lai0;->d(Lqa2;)Lmj7;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public final d(Lqa2;)Lmj7;
    .locals 3

    .line 1
    new-instance v0, Lmj7;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Lmj7;-><init>(BZ)V

    .line 7
    .line 8
    .line 9
    iput-object p1, v0, Lmj7;->j:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object v0, p0, Lai0;->j:Lmj7;

    .line 12
    .line 13
    return-object v0
.end method

.method public final x()F
    .locals 0

    .line 1
    iget-object p0, p0, Lai0;->i:Ljf0;

    .line 2
    .line 3
    invoke-interface {p0}, Ljf0;->a()Lul1;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Lul1;->x()F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method
