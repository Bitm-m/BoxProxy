.class public interface abstract Lb66;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# virtual methods
.method public abstract c(I)I
.end method

.method public abstract e(I)I
.end method

.method public abstract k(I)I
.end method

.method public abstract l(I)I
.end method
