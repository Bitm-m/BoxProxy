.class public final Lbe0;
.super Lh14;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public w:Lyf;

.field public final x:Lhb0;


# direct methods
.method public constructor <init>(Lyf;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Lh14;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbe0;->w:Lyf;

    .line 5
    .line 6
    new-instance p1, Lhb0;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p1, p0, v0}, Lhb0;-><init>(Ljava/lang/Object;B)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lbe0;->x:Lhb0;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final y1()V
    .locals 1

    .line 1
    iget-object v0, p0, Lbe0;->w:Lyf;

    .line 2
    .line 3
    iget-object p0, p0, Lbe0;->x:Lhb0;

    .line 4
    .line 5
    invoke-virtual {v0, p0}, Lyf;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final z1()V
    .locals 1

    .line 1
    iget-object p0, p0, Lbe0;->w:Lyf;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p0, v0}, Lyf;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    return-void
.end method
