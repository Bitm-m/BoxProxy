.class public final Lbb0;
.super Lh14;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfy4;


# instance fields
.field public w:Lg8;

.field public x:Z


# virtual methods
.method public final g(Lul1;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    return-object p0
.end method
