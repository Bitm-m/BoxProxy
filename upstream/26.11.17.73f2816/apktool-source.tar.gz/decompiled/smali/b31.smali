.class public final Lb31;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final synthetic a:Lb31;

.field public static final b:Lh05;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lb31;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lb31;->a:Lb31;

    .line 7
    .line 8
    sget-object v0, Lh05;->l:Lh05;

    .line 9
    .line 10
    sput-object v0, Lb31;->b:Lh05;

    .line 11
    .line 12
    return-void
.end method
