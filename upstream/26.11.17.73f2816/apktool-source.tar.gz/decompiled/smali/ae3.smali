.class public final Lae3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Luc3;


# instance fields
.field public final a:Lqa2;

.field public final b:Lqa2;

.field public final c:Lc01;


# direct methods
.method public constructor <init>(Lqa2;Lqa2;Lc01;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae3;->a:Lqa2;

    .line 5
    .line 6
    iput-object p2, p0, Lae3;->b:Lqa2;

    .line 7
    .line 8
    iput-object p3, p0, Lae3;->c:Lc01;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final getKey()Lqa2;
    .locals 0

    .line 1
    iget-object p0, p0, Lae3;->a:Lqa2;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getType()Lqa2;
    .locals 0

    .line 1
    iget-object p0, p0, Lae3;->b:Lqa2;

    .line 2
    .line 3
    return-object p0
.end method
