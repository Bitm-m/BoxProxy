.class public final Lac3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lt46;


# instance fields
.field public final synthetic a:B

.field public final synthetic b:Lt46;

.field public final synthetic c:Lf56;


# direct methods
.method public synthetic constructor <init>(Lt46;Lf56;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lac3;->a:B

    .line 2
    .line 3
    iput-object p2, p0, Lac3;->c:Lf56;

    .line 4
    .line 5
    iput-object p1, p0, Lac3;->b:Lt46;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(F)F
    .locals 1

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lac3;->b:Lt46;

    .line 7
    .line 8
    invoke-interface {p0, p1}, Lt46;->a(F)F

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lac3;->b:Lt46;

    .line 14
    .line 15
    invoke-interface {p0, p1}, Lt46;->a(F)F

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lac3;->b:Lt46;

    .line 21
    .line 22
    invoke-interface {p0, p1}, Lt46;->a(F)F

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final b(I)I
    .locals 10

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Lac3;->c:Lf56;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v3, Lxw4;

    .line 11
    .line 12
    invoke-virtual {v3}, Lxw4;->k()I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    sub-int/2addr p1, p0

    .line 17
    invoke-virtual {v3}, Lxw4;->p()I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    mul-int/2addr p0, p1

    .line 22
    int-to-float p0, p0

    .line 23
    invoke-virtual {v3}, Lxw4;->l()F

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    invoke-virtual {v3}, Lxw4;->p()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    int-to-float v0, v0

    .line 32
    mul-float/2addr p1, v0

    .line 33
    sub-float/2addr p0, p1

    .line 34
    const/4 p1, 0x0

    .line 35
    add-float/2addr p0, p1

    .line 36
    invoke-static {p0}, Lbs3;->Q(F)I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    invoke-static {v3}, Lbb3;->x(Lxw4;)J

    .line 41
    .line 42
    .line 43
    move-result-wide v0

    .line 44
    int-to-long p0, p0

    .line 45
    add-long v4, v0, p0

    .line 46
    .line 47
    iget-wide v6, v3, Lxw4;->h:J

    .line 48
    .line 49
    iget-wide v8, v3, Lxw4;->g:J

    .line 50
    .line 51
    invoke-static/range {v4 .. v9}, Lhb3;->E(JJJ)J

    .line 52
    .line 53
    .line 54
    move-result-wide p0

    .line 55
    invoke-static {v3}, Lbb3;->x(Lxw4;)J

    .line 56
    .line 57
    .line 58
    move-result-wide v0

    .line 59
    sub-long/2addr p0, v0

    .line 60
    long-to-int p0, p0

    .line 61
    return p0

    .line 62
    :pswitch_0
    check-cast v3, Lne3;

    .line 63
    .line 64
    invoke-virtual {v3}, Lne3;->j()Lhe3;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    iget-object v4, v0, Lhe3;->l:Ljava/util/List;

    .line 69
    .line 70
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 71
    .line 72
    .line 73
    move-result v4

    .line 74
    if-nez v4, :cond_3

    .line 75
    .line 76
    invoke-virtual {v3}, Lne3;->h()I

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    invoke-virtual {p0}, Lac3;->e()I

    .line 81
    .line 82
    .line 83
    move-result p0

    .line 84
    if-gt p1, p0, :cond_2

    .line 85
    .line 86
    if-gt v4, p1, :cond_2

    .line 87
    .line 88
    iget-object p0, v0, Lhe3;->l:Ljava/util/List;

    .line 89
    .line 90
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    move v3, v2

    .line 95
    :goto_0
    if-ge v3, v0, :cond_1

    .line 96
    .line 97
    invoke-interface {p0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    move-object v5, v4

    .line 102
    check-cast v5, Lie3;

    .line 103
    .line 104
    iget v5, v5, Lie3;->a:I

    .line 105
    .line 106
    if-ne v5, p1, :cond_0

    .line 107
    .line 108
    move-object v1, v4

    .line 109
    goto :goto_1

    .line 110
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 111
    .line 112
    goto :goto_0

    .line 113
    :cond_1
    :goto_1
    check-cast v1, Lie3;

    .line 114
    .line 115
    if-eqz v1, :cond_3

    .line 116
    .line 117
    iget v2, v1, Lie3;->l:I

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_2
    invoke-static {v0}, Ltb3;->d0(Lhe3;)I

    .line 121
    .line 122
    .line 123
    move-result p0

    .line 124
    invoke-virtual {v3}, Lne3;->h()I

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    sub-int/2addr p1, v0

    .line 129
    mul-int/2addr p1, p0

    .line 130
    invoke-virtual {v3}, Lne3;->i()I

    .line 131
    .line 132
    .line 133
    move-result p0

    .line 134
    sub-int v2, p1, p0

    .line 135
    .line 136
    :cond_3
    :goto_2
    return v2

    .line 137
    :pswitch_1
    check-cast v3, Lhc3;

    .line 138
    .line 139
    invoke-virtual {v3}, Lhc3;->i()Lwb3;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    iget-object v4, v0, Lwb3;->n:Ljava/util/List;

    .line 144
    .line 145
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 146
    .line 147
    .line 148
    move-result v4

    .line 149
    if-nez v4, :cond_b

    .line 150
    .line 151
    invoke-virtual {v3}, Lhc3;->g()I

    .line 152
    .line 153
    .line 154
    move-result v4

    .line 155
    invoke-virtual {p0}, Lac3;->e()I

    .line 156
    .line 157
    .line 158
    move-result p0

    .line 159
    if-gt p1, p0, :cond_8

    .line 160
    .line 161
    if-gt v4, p1, :cond_8

    .line 162
    .line 163
    iget-object p0, v0, Lwb3;->n:Ljava/util/List;

    .line 164
    .line 165
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 166
    .line 167
    .line 168
    move-result v3

    .line 169
    move v4, v2

    .line 170
    :goto_3
    if-ge v4, v3, :cond_4

    .line 171
    .line 172
    invoke-interface {p0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    move-object v6, v5

    .line 177
    check-cast v6, Lxb3;

    .line 178
    .line 179
    iget v6, v6, Lxb3;->a:I

    .line 180
    .line 181
    if-eq v6, p1, :cond_5

    .line 182
    .line 183
    add-int/lit8 v4, v4, 0x1

    .line 184
    .line 185
    goto :goto_3

    .line 186
    :cond_4
    move-object v5, v1

    .line 187
    :cond_5
    check-cast v5, Lxb3;

    .line 188
    .line 189
    iget-object p0, v0, Lwb3;->r:Ldq4;

    .line 190
    .line 191
    sget-object p1, Ldq4;->i:Ldq4;

    .line 192
    .line 193
    if-ne p0, p1, :cond_6

    .line 194
    .line 195
    if-eqz v5, :cond_7

    .line 196
    .line 197
    iget-wide p0, v5, Lxb3;->r:J

    .line 198
    .line 199
    const-wide v0, 0xffffffffL

    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    and-long/2addr p0, v0

    .line 205
    long-to-int p0, p0

    .line 206
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    goto :goto_4

    .line 211
    :cond_6
    if-eqz v5, :cond_7

    .line 212
    .line 213
    iget-wide p0, v5, Lxb3;->r:J

    .line 214
    .line 215
    const/16 v0, 0x20

    .line 216
    .line 217
    shr-long/2addr p0, v0

    .line 218
    long-to-int p0, p0

    .line 219
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    :cond_7
    :goto_4
    if-eqz v1, :cond_b

    .line 224
    .line 225
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    goto :goto_5

    .line 230
    :cond_8
    iget-object p0, v3, Lhc3;->e:Ldy4;

    .line 231
    .line 232
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object p0

    .line 236
    check-cast p0, Lwb3;

    .line 237
    .line 238
    iget p0, p0, Lwb3;->j:I

    .line 239
    .line 240
    invoke-static {v0}, Lub3;->c0(Lwb3;)I

    .line 241
    .line 242
    .line 243
    move-result v0

    .line 244
    invoke-virtual {v3}, Lhc3;->g()I

    .line 245
    .line 246
    .line 247
    move-result v1

    .line 248
    const/4 v4, 0x1

    .line 249
    if-ge p1, v1, :cond_9

    .line 250
    .line 251
    move v2, v4

    .line 252
    :cond_9
    invoke-virtual {v3}, Lhc3;->g()I

    .line 253
    .line 254
    .line 255
    move-result v1

    .line 256
    sub-int/2addr p1, v1

    .line 257
    add-int/lit8 v1, p0, -0x1

    .line 258
    .line 259
    if-eqz v2, :cond_a

    .line 260
    .line 261
    const/4 v4, -0x1

    .line 262
    :cond_a
    mul-int/2addr v1, v4

    .line 263
    add-int/2addr v1, p1

    .line 264
    div-int/2addr v1, p0

    .line 265
    mul-int/2addr v1, v0

    .line 266
    invoke-virtual {v3}, Lhc3;->h()I

    .line 267
    .line 268
    .line 269
    move-result p0

    .line 270
    sub-int v2, v1, p0

    .line 271
    .line 272
    :cond_b
    :goto_5
    return v2

    .line 273
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final c()I
    .locals 1

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    iget-object p0, p0, Lac3;->c:Lf56;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p0, Lxw4;

    .line 9
    .line 10
    iget p0, p0, Lxw4;->e:I

    .line 11
    .line 12
    return p0

    .line 13
    :pswitch_0
    check-cast p0, Lne3;

    .line 14
    .line 15
    invoke-virtual {p0}, Lne3;->h()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    check-cast p0, Lhc3;

    .line 21
    .line 22
    invoke-virtual {p0}, Lhc3;->g()I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d()I
    .locals 1

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    iget-object p0, p0, Lac3;->c:Lf56;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p0, Lxw4;

    .line 9
    .line 10
    iget p0, p0, Lxw4;->f:I

    .line 11
    .line 12
    return p0

    .line 13
    :pswitch_0
    check-cast p0, Lne3;

    .line 14
    .line 15
    invoke-virtual {p0}, Lne3;->i()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    check-cast p0, Lhc3;

    .line 21
    .line 22
    invoke-virtual {p0}, Lhc3;->h()I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final e()I
    .locals 2

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object p0, p0, Lac3;->c:Lf56;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p0, Lxw4;

    .line 10
    .line 11
    invoke-virtual {p0}, Lxw4;->m()Lpv4;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    iget-object p0, p0, Lpv4;->a:Ljava/util/List;

    .line 16
    .line 17
    invoke-static {p0}, Lmv0;->T0(Ljava/util/List;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    check-cast p0, Lls3;

    .line 22
    .line 23
    iget p0, p0, Lls3;->a:I

    .line 24
    .line 25
    return p0

    .line 26
    :pswitch_0
    check-cast p0, Lne3;

    .line 27
    .line 28
    invoke-virtual {p0}, Lne3;->j()Lhe3;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    iget-object p0, p0, Lhe3;->l:Ljava/util/List;

    .line 33
    .line 34
    invoke-static {p0}, Lmv0;->U0(Ljava/util/List;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Lie3;

    .line 39
    .line 40
    if-eqz p0, :cond_0

    .line 41
    .line 42
    iget v1, p0, Lie3;->a:I

    .line 43
    .line 44
    :cond_0
    return v1

    .line 45
    :pswitch_1
    check-cast p0, Lhc3;

    .line 46
    .line 47
    invoke-virtual {p0}, Lhc3;->i()Lwb3;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    iget-object p0, p0, Lwb3;->n:Ljava/util/List;

    .line 52
    .line 53
    invoke-static {p0}, Lmv0;->U0(Ljava/util/List;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    check-cast p0, Lxb3;

    .line 58
    .line 59
    if-eqz p0, :cond_1

    .line 60
    .line 61
    iget v1, p0, Lxb3;->a:I

    .line 62
    .line 63
    :cond_1
    return v1

    .line 64
    nop

    .line 65
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final f(II)V
    .locals 4

    .line 1
    iget-byte v0, p0, Lac3;->a:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object p0, p0, Lac3;->c:Lf56;

    .line 5
    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p0, Lxw4;

    .line 10
    .line 11
    invoke-virtual {p0}, Lxw4;->p()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    int-to-float v0, v0

    .line 16
    const/4 v2, 0x0

    .line 17
    cmpg-float v3, v0, v2

    .line 18
    .line 19
    if-eqz v3, :cond_0

    .line 20
    .line 21
    int-to-float p2, p2

    .line 22
    div-float v2, p2, v0

    .line 23
    .line 24
    :cond_0
    invoke-virtual {p0, p1, v2, v1}, Lxw4;->u(IFZ)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :pswitch_0
    check-cast p0, Lne3;

    .line 29
    .line 30
    invoke-virtual {p0, p1, p2, v1}, Lne3;->n(IIZ)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_1
    check-cast p0, Lhc3;

    .line 35
    .line 36
    invoke-virtual {p0, p1, p2, v1}, Lhc3;->k(IIZ)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
