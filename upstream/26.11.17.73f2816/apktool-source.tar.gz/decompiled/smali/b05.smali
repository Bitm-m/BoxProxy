.class public final Lb05;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lch;


# instance fields
.field public final synthetic a:Lch;

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lch;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb05;->a:Lch;

    .line 5
    .line 6
    iput-object p2, p0, Lb05;->b:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lb05;->c:Ljava/lang/Object;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Ly91;Lfh6;)Ly91;
    .locals 0

    .line 1
    iget-object p0, p0, Lb05;->a:Lch;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lch;->a(Ly91;Lfh6;)Ly91;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final b()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lb05;->b:Ljava/lang/Object;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 0

    .line 1
    iget-object p0, p0, Lb05;->a:Lch;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lr97;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final d()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lb05;->c:Ljava/lang/Object;

    .line 2
    .line 3
    return-object p0
.end method
