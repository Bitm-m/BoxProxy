.class public final synthetic Lax;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:I

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IB)V
    .locals 0

    .line 21
    iput-byte p7, p0, Lax;->i:B

    iput-object p1, p0, Lax;->l:Ljava/lang/Object;

    iput-object p2, p0, Lax;->m:Ljava/lang/Object;

    iput-object p3, p0, Lax;->j:Ljava/lang/Object;

    iput-object p4, p0, Lax;->n:Ljava/lang/Object;

    iput-object p5, p0, Lax;->o:Ljava/lang/Object;

    iput p6, p0, Lax;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lu77;Lc01;Lw77;Li14;Lc01;I)V
    .locals 1

    .line 20
    const/4 v0, 0x1

    iput-byte v0, p0, Lax;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lax;->l:Ljava/lang/Object;

    iput-object p2, p0, Lax;->m:Ljava/lang/Object;

    iput-object p3, p0, Lax;->n:Ljava/lang/Object;

    iput-object p4, p0, Lax;->j:Ljava/lang/Object;

    iput-object p5, p0, Lax;->o:Ljava/lang/Object;

    iput p6, p0, Lax;->k:I

    return-void
.end method

.method public synthetic constructor <init>(Lwf4;Lt12;Lfa2;Lae4;ILgg4;)V
    .locals 1

    .line 1
    const/4 v0, 0x5

    .line 2
    iput-byte v0, p0, Lax;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lax;->l:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lax;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lax;->j:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lax;->n:Ljava/lang/Object;

    .line 14
    .line 15
    iput p5, p0, Lax;->k:I

    .line 16
    .line 17
    iput-object p6, p0, Lax;->o:Ljava/lang/Object;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lax;->i:B

    .line 4
    .line 5
    iget v2, v0, Lax;->k:I

    .line 6
    .line 7
    iget-object v3, v0, Lax;->o:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, v0, Lax;->n:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v5, v0, Lax;->j:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v6, v0, Lax;->m:Ljava/lang/Object;

    .line 14
    .line 15
    sget-object v7, Lne7;->a:Lne7;

    .line 16
    .line 17
    const/4 v8, 0x1

    .line 18
    iget-object v9, v0, Lax;->l:Ljava/lang/Object;

    .line 19
    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    move-object v10, v9

    .line 24
    check-cast v10, Lvs4;

    .line 25
    .line 26
    move-object v11, v6

    .line 27
    check-cast v11, Ljava/lang/String;

    .line 28
    .line 29
    move-object v12, v5

    .line 30
    check-cast v12, Lne3;

    .line 31
    .line 32
    move-object v13, v4

    .line 33
    check-cast v13, Lvu4;

    .line 34
    .line 35
    move-object v14, v3

    .line 36
    check-cast v14, Lfa2;

    .line 37
    .line 38
    move-object/from16 v15, p1

    .line 39
    .line 40
    check-cast v15, Lub2;

    .line 41
    .line 42
    move-object/from16 v0, p2

    .line 43
    .line 44
    check-cast v0, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    or-int/2addr v2, v8

    .line 50
    invoke-static {v2}, Lub3;->b0(I)I

    .line 51
    .line 52
    .line 53
    move-result v16

    .line 54
    invoke-static/range {v10 .. v16}, Lmf0;->w(Lvs4;Ljava/lang/String;Lne3;Lvu4;Lfa2;Lub2;I)V

    .line 55
    .line 56
    .line 57
    return-object v7

    .line 58
    :pswitch_0
    check-cast v9, Lwf4;

    .line 59
    .line 60
    move-object/from16 v19, v6

    .line 61
    .line 62
    check-cast v19, Lt12;

    .line 63
    .line 64
    move-object v13, v5

    .line 65
    check-cast v13, Lfa2;

    .line 66
    .line 67
    move-object v14, v4

    .line 68
    check-cast v14, Lae4;

    .line 69
    .line 70
    move-object v15, v3

    .line 71
    check-cast v15, Lgg4;

    .line 72
    .line 73
    move-object/from16 v1, p1

    .line 74
    .line 75
    check-cast v1, Lub2;

    .line 76
    .line 77
    move-object/from16 v2, p2

    .line 78
    .line 79
    check-cast v2, Ljava/lang/Integer;

    .line 80
    .line 81
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    and-int/lit8 v3, v2, 0x3

    .line 86
    .line 87
    const/4 v4, 0x2

    .line 88
    if-eq v3, v4, :cond_0

    .line 89
    .line 90
    move v3, v8

    .line 91
    goto :goto_0

    .line 92
    :cond_0
    const/4 v3, 0x0

    .line 93
    :goto_0
    and-int/2addr v2, v8

    .line 94
    invoke-virtual {v1, v2, v3}, Lub2;->S(IZ)Z

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    if-eqz v2, :cond_3

    .line 99
    .line 100
    if-eqz v9, :cond_1

    .line 101
    .line 102
    iget-object v2, v9, Lwf4;->b:Ljava/lang/String;

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_1
    const/4 v2, 0x0

    .line 106
    :goto_1
    if-nez v2, :cond_2

    .line 107
    .line 108
    const-string v2, ""

    .line 109
    .line 110
    :cond_2
    new-instance v3, Lf93;

    .line 111
    .line 112
    const/16 v4, 0xc

    .line 113
    .line 114
    invoke-direct {v3, v13, v4}, Lf93;-><init>(Lfa2;B)V

    .line 115
    .line 116
    .line 117
    const v4, 0x2ebce558

    .line 118
    .line 119
    .line 120
    invoke-static {v4, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 121
    .line 122
    .line 123
    move-result-object v17

    .line 124
    new-instance v10, Lpc4;

    .line 125
    .line 126
    const/4 v11, 0x1

    .line 127
    iget v12, v0, Lax;->k:I

    .line 128
    .line 129
    invoke-direct/range {v10 .. v15}, Lpc4;-><init>(BILfa2;Lae4;Lgg4;)V

    .line 130
    .line 131
    .line 132
    const v0, -0x683fc27f

    .line 133
    .line 134
    .line 135
    invoke-static {v0, v10, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 136
    .line 137
    .line 138
    move-result-object v18

    .line 139
    const/16 v25, 0x0

    .line 140
    .line 141
    const/16 v26, 0x71e

    .line 142
    .line 143
    const/4 v11, 0x0

    .line 144
    const-wide/16 v12, 0x0

    .line 145
    .line 146
    const-wide/16 v14, 0x0

    .line 147
    .line 148
    const/16 v16, 0x0

    .line 149
    .line 150
    const/16 v20, 0x0

    .line 151
    .line 152
    const/16 v21, 0x0

    .line 153
    .line 154
    const/16 v22, 0x0

    .line 155
    .line 156
    const/high16 v24, 0x1b0000

    .line 157
    .line 158
    move-object/from16 v23, v1

    .line 159
    .line 160
    move-object v10, v2

    .line 161
    invoke-static/range {v10 .. v26}, Lv04;->g(Ljava/lang/String;Li14;JJLjava/lang/String;Lc01;Lc01;Lt12;ZLjava/lang/Boolean;Lc01;Lub2;III)V

    .line 162
    .line 163
    .line 164
    goto :goto_2

    .line 165
    :cond_3
    move-object/from16 v23, v1

    .line 166
    .line 167
    invoke-virtual/range {v23 .. v23}, Lub2;->V()V

    .line 168
    .line 169
    .line 170
    :goto_2
    return-object v7

    .line 171
    :pswitch_1
    move-object v0, v9

    .line 172
    check-cast v0, Lyv0;

    .line 173
    .line 174
    move-object v1, v6

    .line 175
    check-cast v1, Le24;

    .line 176
    .line 177
    check-cast v5, Lac6;

    .line 178
    .line 179
    check-cast v4, Lic7;

    .line 180
    .line 181
    check-cast v3, Lc01;

    .line 182
    .line 183
    move v10, v2

    .line 184
    move-object v2, v5

    .line 185
    move-object/from16 v5, p1

    .line 186
    .line 187
    check-cast v5, Lub2;

    .line 188
    .line 189
    move-object/from16 v6, p2

    .line 190
    .line 191
    check-cast v6, Ljava/lang/Integer;

    .line 192
    .line 193
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    or-int/lit8 v6, v10, 0x1

    .line 197
    .line 198
    invoke-static {v6}, Lub3;->b0(I)I

    .line 199
    .line 200
    .line 201
    move-result v6

    .line 202
    move-object/from16 v27, v4

    .line 203
    .line 204
    move-object v4, v3

    .line 205
    move-object/from16 v3, v27

    .line 206
    .line 207
    invoke-static/range {v0 .. v6}, Lwr3;->b(Lyv0;Le24;Lac6;Lic7;Lc01;Lub2;I)V

    .line 208
    .line 209
    .line 210
    return-object v7

    .line 211
    :pswitch_2
    move v10, v2

    .line 212
    check-cast v9, Lnd7;

    .line 213
    .line 214
    check-cast v6, Lpe1;

    .line 215
    .line 216
    check-cast v5, Lfa2;

    .line 217
    .line 218
    move-object v11, v4

    .line 219
    check-cast v11, Lqa2;

    .line 220
    .line 221
    move-object v12, v3

    .line 222
    check-cast v12, Lqa2;

    .line 223
    .line 224
    move-object/from16 v13, p1

    .line 225
    .line 226
    check-cast v13, Lub2;

    .line 227
    .line 228
    move-object/from16 v0, p2

    .line 229
    .line 230
    check-cast v0, Ljava/lang/Integer;

    .line 231
    .line 232
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 233
    .line 234
    .line 235
    or-int/lit8 v2, v10, 0x1

    .line 236
    .line 237
    invoke-static {v2}, Lub3;->b0(I)I

    .line 238
    .line 239
    .line 240
    move-result v14

    .line 241
    move-object v10, v5

    .line 242
    move-object v8, v9

    .line 243
    move-object v9, v6

    .line 244
    invoke-static/range {v8 .. v14}, Lvj;->o(Lnd7;Lpe1;Lfa2;Lqa2;Lqa2;Lub2;I)V

    .line 245
    .line 246
    .line 247
    return-object v7

    .line 248
    :pswitch_3
    move v10, v2

    .line 249
    move-object v15, v9

    .line 250
    check-cast v15, Lc01;

    .line 251
    .line 252
    move-object/from16 v20, p1

    .line 253
    .line 254
    check-cast v20, Lub2;

    .line 255
    .line 256
    move-object/from16 v1, p2

    .line 257
    .line 258
    check-cast v1, Ljava/lang/Integer;

    .line 259
    .line 260
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 261
    .line 262
    .line 263
    invoke-static {v10}, Lub3;->b0(I)I

    .line 264
    .line 265
    .line 266
    move-result v1

    .line 267
    or-int/lit8 v21, v1, 0x1

    .line 268
    .line 269
    iget-object v1, v0, Lax;->m:Ljava/lang/Object;

    .line 270
    .line 271
    iget-object v2, v0, Lax;->j:Ljava/lang/Object;

    .line 272
    .line 273
    iget-object v3, v0, Lax;->n:Ljava/lang/Object;

    .line 274
    .line 275
    iget-object v0, v0, Lax;->o:Ljava/lang/Object;

    .line 276
    .line 277
    move-object/from16 v19, v0

    .line 278
    .line 279
    move-object/from16 v16, v1

    .line 280
    .line 281
    move-object/from16 v17, v2

    .line 282
    .line 283
    move-object/from16 v18, v3

    .line 284
    .line 285
    invoke-virtual/range {v15 .. v21}, Lc01;->l(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lub2;I)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    return-object v7

    .line 289
    :pswitch_4
    move v10, v2

    .line 290
    check-cast v9, Lu77;

    .line 291
    .line 292
    check-cast v6, Lc01;

    .line 293
    .line 294
    check-cast v4, Lw77;

    .line 295
    .line 296
    move-object v11, v5

    .line 297
    check-cast v11, Li14;

    .line 298
    .line 299
    move-object v12, v3

    .line 300
    check-cast v12, Lc01;

    .line 301
    .line 302
    move-object/from16 v13, p1

    .line 303
    .line 304
    check-cast v13, Lub2;

    .line 305
    .line 306
    move-object/from16 v0, p2

    .line 307
    .line 308
    check-cast v0, Ljava/lang/Integer;

    .line 309
    .line 310
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 311
    .line 312
    .line 313
    or-int/lit8 v2, v10, 0x1

    .line 314
    .line 315
    invoke-static {v2}, Lub3;->b0(I)I

    .line 316
    .line 317
    .line 318
    move-result v14

    .line 319
    move-object v10, v4

    .line 320
    move-object v8, v9

    .line 321
    move-object v9, v6

    .line 322
    invoke-static/range {v8 .. v14}, Lom;->a(Lu77;Lc01;Lw77;Li14;Lc01;Lub2;I)V

    .line 323
    .line 324
    .line 325
    return-object v7

    .line 326
    :pswitch_5
    move v10, v2

    .line 327
    move-object v15, v9

    .line 328
    check-cast v15, Llx;

    .line 329
    .line 330
    move-object/from16 v16, v6

    .line 331
    .line 332
    check-cast v16, Ljava/lang/String;

    .line 333
    .line 334
    move-object/from16 v17, v5

    .line 335
    .line 336
    check-cast v17, Li14;

    .line 337
    .line 338
    move-object/from16 v18, v4

    .line 339
    .line 340
    check-cast v18, Lw91;

    .line 341
    .line 342
    move-object/from16 v19, v3

    .line 343
    .line 344
    check-cast v19, Ltv0;

    .line 345
    .line 346
    move-object/from16 v20, p1

    .line 347
    .line 348
    check-cast v20, Lub2;

    .line 349
    .line 350
    move-object/from16 v0, p2

    .line 351
    .line 352
    check-cast v0, Ljava/lang/Integer;

    .line 353
    .line 354
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 355
    .line 356
    .line 357
    or-int/lit8 v2, v10, 0x1

    .line 358
    .line 359
    invoke-static {v2}, Lub3;->b0(I)I

    .line 360
    .line 361
    .line 362
    move-result v21

    .line 363
    invoke-static/range {v15 .. v21}, Lnm;->b(Llx;Ljava/lang/String;Li14;Lw91;Ltv0;Lub2;I)V

    .line 364
    .line 365
    .line 366
    return-object v7

    .line 367
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
