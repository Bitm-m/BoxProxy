.class public final Lba3;
.super Lko3;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final synthetic I:Lca3;


# direct methods
.method public constructor <init>(Lca3;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lba3;->I:Lca3;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lko3;-><init>(Lij4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final F0(Lh8;)I
    .locals 1

    .line 1
    invoke-static {p0, p1}, Lsq;->K(Lio3;Lh8;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object p0, p0, Lko3;->H:Le44;

    .line 6
    .line 7
    invoke-virtual {p0, v0, p1}, Le44;->g(ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return v0
.end method

.method public final S(I)I
    .locals 2

    .line 1
    iget-object v0, p0, Lba3;->I:Lca3;

    .line 2
    .line 3
    iget-object v1, v0, Lca3;->j0:Laa3;

    .line 4
    .line 5
    iget-object v0, v0, Lij4;->D:Lij4;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Lij4;->x1()Lko3;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-interface {v1, p0, v0, p1}, Laa3;->u0(Lio3;Lds3;I)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final e(J)Lb15;
    .locals 2

    .line 1
    invoke-virtual {p0, p1, p2}, Lb15;->C0(J)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lb81;

    .line 5
    .line 6
    invoke-direct {v0, p1, p2}, Lb81;-><init>(J)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lba3;->I:Lca3;

    .line 10
    .line 11
    iget-object v1, v0, Lca3;->j0:Laa3;

    .line 12
    .line 13
    iget-object v0, v0, Lij4;->D:Lij4;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lij4;->x1()Lko3;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-interface {v1, p0, v0, p1, p2}, Laa3;->i(Lks3;Lds3;J)Ljs3;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {p0, p1}, Lko3;->n1(Ljs3;)V

    .line 30
    .line 31
    .line 32
    return-object p0
.end method

.method public final f(I)I
    .locals 2

    .line 1
    iget-object v0, p0, Lba3;->I:Lca3;

    .line 2
    .line 3
    iget-object v1, v0, Lca3;->j0:Laa3;

    .line 4
    .line 5
    iget-object v0, v0, Lij4;->D:Lij4;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Lij4;->x1()Lko3;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-interface {v1, p0, v0, p1}, Laa3;->z(Lio3;Lds3;I)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final g0(I)I
    .locals 2

    .line 1
    iget-object v0, p0, Lba3;->I:Lca3;

    .line 2
    .line 3
    iget-object v1, v0, Lca3;->j0:Laa3;

    .line 4
    .line 5
    iget-object v0, v0, Lij4;->D:Lij4;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Lij4;->x1()Lko3;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-interface {v1, p0, v0, p1}, Laa3;->n(Lio3;Lds3;I)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final h0(I)I
    .locals 2

    .line 1
    iget-object v0, p0, Lba3;->I:Lca3;

    .line 2
    .line 3
    iget-object v1, v0, Lca3;->j0:Laa3;

    .line 4
    .line 5
    iget-object v0, v0, Lij4;->D:Lij4;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Lij4;->x1()Lko3;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-interface {v1, p0, v0, p1}, Laa3;->S(Lio3;Lds3;I)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method
