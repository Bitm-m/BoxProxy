.class public final La60;
.super Ljs6;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:Lzx4;

.field public final synthetic j:Lrf1;

.field public final synthetic k:Lng;

.field public final synthetic l:Lng;


# direct methods
.method public constructor <init>(Lzx4;Lrf1;Lng;Lng;Lia1;)V
    .locals 0

    .line 1
    iput-object p1, p0, La60;->i:Lzx4;

    .line 2
    .line 3
    iput-object p2, p0, La60;->j:Lrf1;

    .line 4
    .line 5
    iput-object p3, p0, La60;->k:Lng;

    .line 6
    .line 7
    iput-object p4, p0, La60;->l:Lng;

    .line 8
    .line 9
    const/4 p1, 0x3

    .line 10
    invoke-direct {p0, p1, p5}, Ljs6;-><init>(ILia1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    check-cast p1, Lrf1;

    .line 2
    .line 3
    check-cast p2, Lfm4;

    .line 4
    .line 5
    iget-wide p1, p2, Lfm4;->a:J

    .line 6
    .line 7
    move-object v5, p3

    .line 8
    check-cast v5, Lia1;

    .line 9
    .line 10
    new-instance v0, La60;

    .line 11
    .line 12
    iget-object v3, p0, La60;->k:Lng;

    .line 13
    .line 14
    iget-object v4, p0, La60;->l:Lng;

    .line 15
    .line 16
    iget-object v1, p0, La60;->i:Lzx4;

    .line 17
    .line 18
    iget-object v2, p0, La60;->j:Lrf1;

    .line 19
    .line 20
    invoke-direct/range {v0 .. v5}, La60;-><init>(Lzx4;Lrf1;Lng;Lng;Lia1;)V

    .line 21
    .line 22
    .line 23
    sget-object p0, Lne7;->a:Lne7;

    .line 24
    .line 25
    invoke-virtual {v0, p0}, La60;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, La60;->i:Lzx4;

    .line 5
    .line 6
    const/high16 v0, 0x3f800000    # 1.0f

    .line 7
    .line 8
    invoke-virtual {p1, v0}, Lzx4;->h(F)V

    .line 9
    .line 10
    .line 11
    sget-object p1, Lh60;->a:Lyt1;

    .line 12
    .line 13
    new-instance p1, Lg60;

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    iget-object v1, p0, La60;->k:Lng;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-direct {p1, v1, v2, v0}, Lg60;-><init>(Lng;Lia1;B)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, La60;->j:Lrf1;

    .line 23
    .line 24
    const/4 v1, 0x3

    .line 25
    invoke-static {v0, v2, v2, p1, v1}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 26
    .line 27
    .line 28
    new-instance p1, Lg60;

    .line 29
    .line 30
    const/4 v3, 0x1

    .line 31
    iget-object p0, p0, La60;->l:Lng;

    .line 32
    .line 33
    invoke-direct {p1, p0, v2, v3}, Lg60;-><init>(Lng;Lia1;B)V

    .line 34
    .line 35
    .line 36
    invoke-static {v0, v2, v2, p1, v1}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 37
    .line 38
    .line 39
    sget-object p0, Lne7;->a:Lne7;

    .line 40
    .line 41
    return-object p0
.end method
