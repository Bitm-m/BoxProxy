.class public final Lan7;
.super Lzm7;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lzm7;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>(Lnn7;)V
    .locals 0

    .line 5
    invoke-direct {p0, p1}, Lzm7;-><init>(Lnn7;)V

    return-void
.end method
