.class public final La87;
.super Lnb6;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final c:Lx77;

.field public final d:F


# direct methods
.method public constructor <init>(Lx77;F)V
    .locals 0

    .line 1
    invoke-direct {p0}, Lnb6;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La87;->c:Lx77;

    .line 5
    .line 6
    iput p2, p0, La87;->d:F

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final c(J)Landroid/graphics/Shader;
    .locals 12

    .line 1
    const-wide v0, 0xffffffffL

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    and-long/2addr p1, v0

    .line 7
    long-to-int p1, p1

    .line 8
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    iget v2, p0, La87;->d:F

    .line 13
    .line 14
    sub-float/2addr p2, v2

    .line 15
    const/4 v3, 0x0

    .line 16
    cmpg-float v4, p2, v3

    .line 17
    .line 18
    if-gez v4, :cond_0

    .line 19
    .line 20
    move p2, v3

    .line 21
    :cond_0
    iget-object p0, p0, La87;->c:Lx77;

    .line 22
    .line 23
    iget-object v4, p0, Lx77;->d:Ljava/util/ArrayList;

    .line 24
    .line 25
    iget-wide v5, p0, Lx77;->c:J

    .line 26
    .line 27
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    const/high16 v7, 0x3f800000    # 1.0f

    .line 36
    .line 37
    cmpg-float v8, p1, v7

    .line 38
    .line 39
    if-gez v8, :cond_1

    .line 40
    .line 41
    move p1, v7

    .line 42
    :cond_1
    invoke-static {p2, v3, p1}, Lhb3;->B(FFF)F

    .line 43
    .line 44
    .line 45
    move-result p2

    .line 46
    cmpg-float v8, v2, v7

    .line 47
    .line 48
    if-gez v8, :cond_2

    .line 49
    .line 50
    move v2, v7

    .line 51
    :cond_2
    sget-object v7, Lx77;->e:Ljava/util/ArrayList;

    .line 52
    .line 53
    const/4 v8, 0x1

    .line 54
    invoke-static {v7, v8}, Lmv0;->H0(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 55
    .line 56
    .line 57
    move-result-object v7

    .line 58
    new-instance v9, Ljava/util/ArrayList;

    .line 59
    .line 60
    const/16 v10, 0xa

    .line 61
    .line 62
    invoke-static {v7, v10}, Lnv0;->w0(Ljava/lang/Iterable;I)I

    .line 63
    .line 64
    .line 65
    move-result v10

    .line 66
    invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 67
    .line 68
    .line 69
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 70
    .line 71
    .line 72
    move-result-object v7

    .line 73
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    .line 75
    .line 76
    move-result v10

    .line 77
    if-eqz v10, :cond_4

    .line 78
    .line 79
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v10

    .line 83
    check-cast v10, Ljava/lang/Number;

    .line 84
    .line 85
    invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F

    .line 86
    .line 87
    .line 88
    move-result v10

    .line 89
    mul-float/2addr v10, v2

    .line 90
    add-float/2addr v10, p2

    .line 91
    cmpl-float v11, v10, p1

    .line 92
    .line 93
    if-lez v11, :cond_3

    .line 94
    .line 95
    move v10, p1

    .line 96
    :cond_3
    div-float/2addr v10, p1

    .line 97
    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 98
    .line 99
    .line 100
    move-result-object v10

    .line 101
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_4
    cmpl-float v2, p2, v3

    .line 106
    .line 107
    if-lez v2, :cond_5

    .line 108
    .line 109
    div-float/2addr p2, p1

    .line 110
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    filled-new-array {p0, p2}, [Ljava/lang/Float;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    invoke-static {p0}, Lnm;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    invoke-static {p0, v9}, Lmv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    new-instance p2, Lsv0;

    .line 127
    .line 128
    invoke-direct {p2, v5, v6}, Lsv0;-><init>(J)V

    .line 129
    .line 130
    .line 131
    new-instance v2, Lsv0;

    .line 132
    .line 133
    invoke-direct {v2, v5, v6}, Lsv0;-><init>(J)V

    .line 134
    .line 135
    .line 136
    filled-new-array {p2, v2}, [Lsv0;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    invoke-static {p2}, Lnm;->V([Ljava/lang/Object;)Ljava/util/List;

    .line 141
    .line 142
    .line 143
    move-result-object p2

    .line 144
    :goto_1
    invoke-static {v4, v8}, Lmv0;->H0(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    invoke-static {p2, v2}, Lmv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 149
    .line 150
    .line 151
    move-result-object p2

    .line 152
    move-object v6, p0

    .line 153
    move-object v7, p2

    .line 154
    goto :goto_2

    .line 155
    :cond_5
    invoke-static {p0}, Lnm;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    invoke-static {p0, v9}, Lmv0;->Y0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 160
    .line 161
    .line 162
    move-result-object p0

    .line 163
    new-instance p2, Lsv0;

    .line 164
    .line 165
    invoke-direct {p2, v5, v6}, Lsv0;-><init>(J)V

    .line 166
    .line 167
    .line 168
    invoke-static {p2}, Lnm;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 169
    .line 170
    .line 171
    move-result-object p2

    .line 172
    goto :goto_1

    .line 173
    :goto_2
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 174
    .line 175
    .line 176
    move-result p0

    .line 177
    int-to-long p0, p0

    .line 178
    and-long v4, p0, v0

    .line 179
    .line 180
    const-wide/16 v2, 0x0

    .line 181
    .line 182
    invoke-static/range {v2 .. v7}, Lr71;->d(JJLjava/util/ArrayList;Ljava/util/List;)Landroid/graphics/LinearGradient;

    .line 183
    .line 184
    .line 185
    move-result-object p0

    .line 186
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, La87;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, La87;

    .line 8
    .line 9
    iget-object v0, p0, La87;->c:Lx77;

    .line 10
    .line 11
    iget-object v1, p1, La87;->c:Lx77;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lx77;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget p0, p0, La87;->d:F

    .line 20
    .line 21
    iget p1, p1, La87;->d:F

    .line 22
    .line 23
    invoke-static {p0, p1}, Ljava/lang/Float;->compare(FF)I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-eqz p0, :cond_1

    .line 28
    .line 29
    :cond_0
    const/4 p0, 0x0

    .line 30
    return p0

    .line 31
    :cond_1
    const/4 p0, 0x1

    .line 32
    return p0
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, La87;->c:Lx77;

    .line 2
    .line 3
    invoke-virtual {v0}, Lx77;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget p0, p0, La87;->d:F

    .line 10
    .line 11
    invoke-static {p0}, Ljava/lang/Float;->hashCode(F)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "TopAppBarFadeBrush(band="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, La87;->c:Lx77;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", fadeHeight="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget p0, p0, La87;->d:F

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p0, ")"

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method
