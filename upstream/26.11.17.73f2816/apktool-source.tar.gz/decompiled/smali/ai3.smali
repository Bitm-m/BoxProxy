.class public final Lai3;
.super Lth2;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final l:Z


# direct methods
.method public constructor <init>(Lbr5;[Lao4;Z)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lth2;-><init>(Lbr5;[Lao4;)V

    .line 2
    .line 3
    .line 4
    iput-boolean p3, p0, Lai3;->l:Z

    .line 5
    .line 6
    return-void
.end method
