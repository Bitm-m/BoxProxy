.class public final synthetic Lac1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Lnd7;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Lfa2;

.field public final synthetic n:Lfa2;

.field public final synthetic o:Z

.field public final synthetic p:Z

.field public final synthetic q:I

.field public final synthetic r:S


# direct methods
.method public synthetic constructor <init>(Lnd7;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lfa2;Lfa2;ZZII)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lac1;->i:Lnd7;

    .line 5
    .line 6
    iput-object p2, p0, Lac1;->j:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lac1;->k:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lac1;->l:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p5, p0, Lac1;->m:Lfa2;

    .line 13
    .line 14
    iput-object p6, p0, Lac1;->n:Lfa2;

    .line 15
    .line 16
    iput-boolean p7, p0, Lac1;->o:Z

    .line 17
    .line 18
    iput-boolean p8, p0, Lac1;->p:Z

    .line 19
    .line 20
    iput p9, p0, Lac1;->q:I

    .line 21
    .line 22
    iput-short p10, p0, Lac1;->r:S

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    move-object v8, p1

    .line 2
    check-cast v8, Lub2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lac1;->q:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lub3;->b0(I)I

    .line 14
    .line 15
    .line 16
    move-result v9

    .line 17
    iget-object v0, p0, Lac1;->i:Lnd7;

    .line 18
    .line 19
    iget-object v1, p0, Lac1;->j:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v2, p0, Lac1;->k:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v3, p0, Lac1;->l:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v4, p0, Lac1;->m:Lfa2;

    .line 26
    .line 27
    iget-object v5, p0, Lac1;->n:Lfa2;

    .line 28
    .line 29
    iget-boolean v6, p0, Lac1;->o:Z

    .line 30
    .line 31
    iget-boolean v7, p0, Lac1;->p:Z

    .line 32
    .line 33
    iget-short v10, p0, Lac1;->r:S

    .line 34
    .line 35
    invoke-static/range {v0 .. v10}, Lnm;->w(Lnd7;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lfa2;Lfa2;ZZLub2;II)V

    .line 36
    .line 37
    .line 38
    sget-object p0, Lne7;->a:Lne7;

    .line 39
    .line 40
    return-object p0
.end method
