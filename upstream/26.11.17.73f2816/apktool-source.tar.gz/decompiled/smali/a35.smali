.class public final synthetic La35;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lgf5;

.field public final synthetic k:Ln35;

.field public final synthetic l:Z

.field public final synthetic m:Lfa2;


# direct methods
.method public synthetic constructor <init>(Lgf5;Ln35;ZLfa2;IB)V
    .locals 0

    .line 1
    iput-byte p6, p0, La35;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La35;->j:Lgf5;

    .line 4
    .line 5
    iput-object p2, p0, La35;->k:Ln35;

    .line 6
    .line 7
    iput-boolean p3, p0, La35;->l:Z

    .line 8
    .line 9
    iput-object p4, p0, La35;->m:Lfa2;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, La35;->i:B

    .line 4
    .line 5
    sget-object v2, Lne7;->a:Lne7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    packed-switch v1, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    move-object/from16 v8, p1

    .line 12
    .line 13
    check-cast v8, Lub2;

    .line 14
    .line 15
    move-object/from16 v1, p2

    .line 16
    .line 17
    check-cast v1, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {v3}, Lub3;->b0(I)I

    .line 23
    .line 24
    .line 25
    move-result v9

    .line 26
    iget-object v4, v0, La35;->j:Lgf5;

    .line 27
    .line 28
    iget-object v5, v0, La35;->k:Ln35;

    .line 29
    .line 30
    iget-boolean v6, v0, La35;->l:Z

    .line 31
    .line 32
    iget-object v7, v0, La35;->m:Lfa2;

    .line 33
    .line 34
    invoke-static/range {v4 .. v9}, Lda3;->j(Lgf5;Ln35;ZLfa2;Lub2;I)V

    .line 35
    .line 36
    .line 37
    return-object v2

    .line 38
    :pswitch_0
    move-object/from16 v14, p1

    .line 39
    .line 40
    check-cast v14, Lub2;

    .line 41
    .line 42
    move-object/from16 v1, p2

    .line 43
    .line 44
    check-cast v1, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    invoke-static {v3}, Lub3;->b0(I)I

    .line 50
    .line 51
    .line 52
    move-result v15

    .line 53
    iget-object v10, v0, La35;->j:Lgf5;

    .line 54
    .line 55
    iget-object v11, v0, La35;->k:Ln35;

    .line 56
    .line 57
    iget-boolean v12, v0, La35;->l:Z

    .line 58
    .line 59
    iget-object v13, v0, La35;->m:Lfa2;

    .line 60
    .line 61
    invoke-static/range {v10 .. v15}, Lvc3;->e(Lgf5;Ln35;ZLfa2;Lub2;I)V

    .line 62
    .line 63
    .line 64
    return-object v2

    .line 65
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
