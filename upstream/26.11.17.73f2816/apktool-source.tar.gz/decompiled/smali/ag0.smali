.class public final synthetic Lag0;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:J

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(JLxu4;Lva2;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lag0;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-wide p1, p0, Lag0;->j:J

    .line 8
    .line 9
    iput-object p3, p0, Lag0;->k:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p4, p0, Lag0;->l:Ljava/lang/Object;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;JI)V
    .locals 0

    .line 15
    const/4 p5, 0x1

    iput-byte p5, p0, Lag0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lag0;->k:Ljava/lang/Object;

    iput-object p2, p0, Lag0;->l:Ljava/lang/Object;

    iput-wide p3, p0, Lag0;->j:J

    return-void
.end method

.method public synthetic constructor <init>(Llu4;JLmm6;)V
    .locals 1

    .line 14
    const/4 v0, 0x2

    iput-byte v0, p0, Lag0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lag0;->k:Ljava/lang/Object;

    iput-wide p2, p0, Lag0;->j:J

    iput-object p4, p0, Lag0;->l:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lag0;->i:B

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    sget-object v4, Lne7;->a:Lne7;

    .line 7
    .line 8
    const/4 v5, 0x1

    .line 9
    iget-object v6, v0, Lag0;->l:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v7, v0, Lag0;->k:Ljava/lang/Object;

    .line 12
    .line 13
    packed-switch v1, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast v7, Llu4;

    .line 17
    .line 18
    check-cast v6, Lmm6;

    .line 19
    .line 20
    move-object/from16 v12, p1

    .line 21
    .line 22
    check-cast v12, Lub2;

    .line 23
    .line 24
    move-object/from16 v1, p2

    .line 25
    .line 26
    check-cast v1, Ljava/lang/Integer;

    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    sget-object v8, Lt6;->t:Lq20;

    .line 33
    .line 34
    sget-object v9, Lac7;->b:Lsv;

    .line 35
    .line 36
    and-int/lit8 v10, v1, 0x3

    .line 37
    .line 38
    if-eq v10, v2, :cond_0

    .line 39
    .line 40
    move v2, v5

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const/4 v2, 0x0

    .line 43
    :goto_0
    and-int/2addr v1, v5

    .line 44
    invoke-virtual {v12, v1, v2}, Lub2;->S(IZ)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_c

    .line 49
    .line 50
    sget-object v1, Lf14;->i:Lf14;

    .line 51
    .line 52
    const/high16 v2, 0x3f800000    # 1.0f

    .line 53
    .line 54
    invoke-static {v1, v2}, Lch6;->d(Li14;F)Li14;

    .line 55
    .line 56
    .line 57
    move-result-object v10

    .line 58
    const/high16 v11, 0x41800000    # 16.0f

    .line 59
    .line 60
    const/high16 v13, 0x41600000    # 14.0f

    .line 61
    .line 62
    invoke-static {v10, v11, v13}, Lmi1;->D(Li14;FF)Li14;

    .line 63
    .line 64
    .line 65
    move-result-object v10

    .line 66
    new-instance v11, Lvv;

    .line 67
    .line 68
    new-instance v13, Lj02;

    .line 69
    .line 70
    const/4 v14, 0x3

    .line 71
    invoke-direct {v13, v14}, Lj02;-><init>(B)V

    .line 72
    .line 73
    .line 74
    const/high16 v14, 0x41000000    # 8.0f

    .line 75
    .line 76
    invoke-direct {v11, v14, v5, v13}, Lvv;-><init>(FZLj02;)V

    .line 77
    .line 78
    .line 79
    sget-object v13, Lt6;->w:Lp20;

    .line 80
    .line 81
    const/4 v14, 0x6

    .line 82
    invoke-static {v11, v13, v12, v14}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 83
    .line 84
    .line 85
    move-result-object v11

    .line 86
    iget-wide v14, v12, Lub2;->T:J

    .line 87
    .line 88
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 89
    .line 90
    .line 91
    move-result v13

    .line 92
    invoke-virtual {v12}, Lub2;->m()Lh05;

    .line 93
    .line 94
    .line 95
    move-result-object v14

    .line 96
    invoke-static {v12, v10}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 97
    .line 98
    .line 99
    move-result-object v10

    .line 100
    sget-object v15, La21;->d:Lt6;

    .line 101
    .line 102
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v12}, Lub2;->e0()V

    .line 106
    .line 107
    .line 108
    iget-boolean v15, v12, Lub2;->S:Z

    .line 109
    .line 110
    move/from16 v16, v15

    .line 111
    .line 112
    sget-object v15, Lja3;->a0:Lxg2;

    .line 113
    .line 114
    if-eqz v16, :cond_1

    .line 115
    .line 116
    invoke-virtual {v12, v15}, Lub2;->l(Lfa2;)V

    .line 117
    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_1
    invoke-virtual {v12}, Lub2;->n0()V

    .line 121
    .line 122
    .line 123
    :goto_1
    sget-object v5, Lt6;->S:Lf11;

    .line 124
    .line 125
    invoke-static {v5, v12, v11}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    sget-object v11, Lt6;->R:Lf11;

    .line 129
    .line 130
    invoke-static {v11, v12, v14}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 134
    .line 135
    .line 136
    move-result-object v13

    .line 137
    sget-object v14, Lt6;->T:Lf11;

    .line 138
    .line 139
    invoke-static {v14, v12, v13}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    invoke-static {v12}, Les6;->l(Lub2;)V

    .line 143
    .line 144
    .line 145
    sget-object v13, Lt6;->Q:Lf11;

    .line 146
    .line 147
    invoke-static {v13, v12, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    iget-boolean v10, v7, Llu4;->a:Z

    .line 151
    .line 152
    iget v3, v7, Llu4;->i:I

    .line 153
    .line 154
    move/from16 v19, v3

    .line 155
    .line 156
    iget-wide v2, v0, Lag0;->j:J

    .line 157
    .line 158
    sget-object v0, Li21;->a:Ls9;

    .line 159
    .line 160
    move-object/from16 v31, v4

    .line 161
    .line 162
    if-eqz v10, :cond_4

    .line 163
    .line 164
    const v6, 0x2b33de44

    .line 165
    .line 166
    .line 167
    invoke-virtual {v12, v6}, Lub2;->b0(I)V

    .line 168
    .line 169
    .line 170
    const/high16 v6, 0x3f800000    # 1.0f

    .line 171
    .line 172
    invoke-static {v1, v6}, Lch6;->d(Li14;F)Li14;

    .line 173
    .line 174
    .line 175
    move-result-object v10

    .line 176
    const/4 v6, 0x0

    .line 177
    invoke-static {v9, v8, v12, v6}, Lsq5;->a(Luv;Lq20;Lub2;I)Ltq5;

    .line 178
    .line 179
    .line 180
    move-result-object v8

    .line 181
    move-object/from16 v20, v5

    .line 182
    .line 183
    iget-wide v4, v12, Lub2;->T:J

    .line 184
    .line 185
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 186
    .line 187
    .line 188
    move-result v4

    .line 189
    invoke-virtual {v12}, Lub2;->m()Lh05;

    .line 190
    .line 191
    .line 192
    move-result-object v5

    .line 193
    invoke-static {v12, v10}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 194
    .line 195
    .line 196
    move-result-object v6

    .line 197
    invoke-virtual {v12}, Lub2;->e0()V

    .line 198
    .line 199
    .line 200
    iget-boolean v10, v12, Lub2;->S:Z

    .line 201
    .line 202
    if-eqz v10, :cond_2

    .line 203
    .line 204
    invoke-virtual {v12, v15}, Lub2;->l(Lfa2;)V

    .line 205
    .line 206
    .line 207
    :goto_2
    move-object/from16 v10, v20

    .line 208
    .line 209
    goto :goto_3

    .line 210
    :cond_2
    invoke-virtual {v12}, Lub2;->n0()V

    .line 211
    .line 212
    .line 213
    goto :goto_2

    .line 214
    :goto_3
    invoke-static {v10, v12, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    invoke-static {v11, v12, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 218
    .line 219
    .line 220
    invoke-static {v4, v12, v14, v12}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 221
    .line 222
    .line 223
    invoke-static {v13, v12, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    const v4, 0x7f0f0206

    .line 227
    .line 228
    .line 229
    invoke-static {v4, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v4

    .line 233
    new-instance v5, Lcb3;

    .line 234
    .line 235
    const/4 v6, 0x1

    .line 236
    const/high16 v8, 0x3f800000    # 1.0f

    .line 237
    .line 238
    invoke-direct {v5, v8, v6}, Lcb3;-><init>(FZ)V

    .line 239
    .line 240
    .line 241
    const/4 v6, 0x6

    .line 242
    invoke-static {v4, v5, v12, v6}, Lsc3;->o(Ljava/lang/String;Li14;Lub2;I)V

    .line 243
    .line 244
    .line 245
    const v4, 0x7f0f0368

    .line 246
    .line 247
    .line 248
    invoke-static {v4, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v4

    .line 252
    new-instance v5, Lcb3;

    .line 253
    .line 254
    move-object/from16 p1, v9

    .line 255
    .line 256
    const/4 v9, 0x1

    .line 257
    invoke-direct {v5, v8, v9}, Lcb3;-><init>(FZ)V

    .line 258
    .line 259
    .line 260
    invoke-static {v4, v5, v12, v6}, Lsc3;->o(Ljava/lang/String;Li14;Lub2;I)V

    .line 261
    .line 262
    .line 263
    const v4, 0x7f0f0205

    .line 264
    .line 265
    .line 266
    invoke-static {v4, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    new-instance v5, Lcb3;

    .line 271
    .line 272
    invoke-direct {v5, v8, v9}, Lcb3;-><init>(FZ)V

    .line 273
    .line 274
    .line 275
    invoke-static {v4, v5, v12, v6}, Lsc3;->o(Ljava/lang/String;Li14;Lub2;I)V

    .line 276
    .line 277
    .line 278
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v12}, Lub2;->N()Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v4

    .line 285
    if-ne v4, v0, :cond_3

    .line 286
    .line 287
    new-instance v4, Lwh4;

    .line 288
    .line 289
    const/16 v0, 0xf

    .line 290
    .line 291
    invoke-direct {v4, v0}, Lwh4;-><init>(B)V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v12, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 295
    .line 296
    .line 297
    :cond_3
    move-object v8, v4

    .line 298
    check-cast v8, Lfa2;

    .line 299
    .line 300
    const/high16 v6, 0x3f800000    # 1.0f

    .line 301
    .line 302
    invoke-static {v1, v6}, Lch6;->d(Li14;F)Li14;

    .line 303
    .line 304
    .line 305
    move-result-object v9

    .line 306
    const v0, 0x3e3851ec    # 0.18f

    .line 307
    .line 308
    .line 309
    invoke-static {v2, v3, v0}, Lsv0;->b(JF)J

    .line 310
    .line 311
    .line 312
    move-result-wide v4

    .line 313
    const/16 v16, 0x0

    .line 314
    .line 315
    const/16 v18, 0x36

    .line 316
    .line 317
    move-object v0, v14

    .line 318
    const/4 v14, 0x0

    .line 319
    move-object v6, v15

    .line 320
    const/4 v15, 0x0

    .line 321
    move-object/from16 v17, v12

    .line 322
    .line 323
    move-wide/from16 v35, v2

    .line 324
    .line 325
    move-object/from16 v2, p1

    .line 326
    .line 327
    move-object v3, v10

    .line 328
    move-wide/from16 v37, v4

    .line 329
    .line 330
    move-object v5, v0

    .line 331
    move-object v4, v11

    .line 332
    move-object v0, v13

    .line 333
    move-wide/from16 v10, v35

    .line 334
    .line 335
    move-wide/from16 v12, v37

    .line 336
    .line 337
    invoke-static/range {v8 .. v18}, Lc75;->b(Lfa2;Li14;JJIFLqa2;Lub2;I)V

    .line 338
    .line 339
    .line 340
    move-object/from16 v12, v17

    .line 341
    .line 342
    const/4 v9, 0x0

    .line 343
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 344
    .line 345
    .line 346
    move-object/from16 v22, v2

    .line 347
    .line 348
    move-object/from16 v34, v6

    .line 349
    .line 350
    move-object v6, v0

    .line 351
    move-object v0, v1

    .line 352
    goto/16 :goto_6

    .line 353
    .line 354
    :cond_4
    move-object v4, v15

    .line 355
    move-object v15, v13

    .line 356
    move-object v13, v4

    .line 357
    move-object v4, v11

    .line 358
    move-wide v10, v2

    .line 359
    move-object v3, v5

    .line 360
    move-object v2, v9

    .line 361
    move-object v5, v14

    .line 362
    const/4 v9, 0x0

    .line 363
    iget-boolean v14, v7, Llu4;->b:Z

    .line 364
    .line 365
    if-eqz v14, :cond_8

    .line 366
    .line 367
    const v14, 0x2b4a5d9b

    .line 368
    .line 369
    .line 370
    invoke-virtual {v12, v14}, Lub2;->b0(I)V

    .line 371
    .line 372
    .line 373
    move-wide/from16 v20, v10

    .line 374
    .line 375
    const/high16 v14, 0x3f800000    # 1.0f

    .line 376
    .line 377
    invoke-static {v1, v14}, Lch6;->d(Li14;F)Li14;

    .line 378
    .line 379
    .line 380
    move-result-object v10

    .line 381
    invoke-static {v2, v8, v12, v9}, Lsq5;->a(Luv;Lq20;Lub2;I)Ltq5;

    .line 382
    .line 383
    .line 384
    move-result-object v8

    .line 385
    move-object/from16 p1, v1

    .line 386
    .line 387
    move-object/from16 v22, v2

    .line 388
    .line 389
    iget-wide v1, v12, Lub2;->T:J

    .line 390
    .line 391
    invoke-static {v1, v2}, Ljava/lang/Long;->hashCode(J)I

    .line 392
    .line 393
    .line 394
    move-result v1

    .line 395
    invoke-virtual {v12}, Lub2;->m()Lh05;

    .line 396
    .line 397
    .line 398
    move-result-object v2

    .line 399
    invoke-static {v12, v10}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 400
    .line 401
    .line 402
    move-result-object v9

    .line 403
    invoke-virtual {v12}, Lub2;->e0()V

    .line 404
    .line 405
    .line 406
    iget-boolean v10, v12, Lub2;->S:Z

    .line 407
    .line 408
    if-eqz v10, :cond_5

    .line 409
    .line 410
    invoke-virtual {v12, v13}, Lub2;->l(Lfa2;)V

    .line 411
    .line 412
    .line 413
    goto :goto_4

    .line 414
    :cond_5
    invoke-virtual {v12}, Lub2;->n0()V

    .line 415
    .line 416
    .line 417
    :goto_4
    invoke-static {v3, v12, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 418
    .line 419
    .line 420
    invoke-static {v4, v12, v2}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 421
    .line 422
    .line 423
    invoke-static {v1, v12, v5, v12}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 424
    .line 425
    .line 426
    invoke-static {v15, v12, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 427
    .line 428
    .line 429
    const v1, 0x7f0f0206

    .line 430
    .line 431
    .line 432
    invoke-static {v1, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 433
    .line 434
    .line 435
    move-result-object v8

    .line 436
    iget-object v9, v7, Llu4;->d:Ljava/lang/String;

    .line 437
    .line 438
    new-instance v10, Lcb3;

    .line 439
    .line 440
    const/4 v1, 0x1

    .line 441
    const/high16 v2, 0x3f800000    # 1.0f

    .line 442
    .line 443
    invoke-direct {v10, v2, v1}, Lcb3;-><init>(FZ)V

    .line 444
    .line 445
    .line 446
    const/16 v14, 0x8

    .line 447
    .line 448
    const/4 v11, 0x0

    .line 449
    move-object/from16 v18, v13

    .line 450
    .line 451
    const/4 v13, 0x6

    .line 452
    move-object/from16 v34, v18

    .line 453
    .line 454
    move-wide/from16 v32, v20

    .line 455
    .line 456
    invoke-static/range {v8 .. v14}, Lsc3;->n(Ljava/lang/String;Ljava/lang/String;Li14;Lfa2;Lub2;II)V

    .line 457
    .line 458
    .line 459
    const v8, 0x7f0f0368

    .line 460
    .line 461
    .line 462
    invoke-static {v8, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object v8

    .line 466
    iget-object v9, v7, Llu4;->f:Ljava/lang/String;

    .line 467
    .line 468
    new-instance v10, Lcb3;

    .line 469
    .line 470
    invoke-direct {v10, v2, v1}, Lcb3;-><init>(FZ)V

    .line 471
    .line 472
    .line 473
    invoke-static/range {v8 .. v14}, Lsc3;->n(Ljava/lang/String;Ljava/lang/String;Li14;Lfa2;Lub2;II)V

    .line 474
    .line 475
    .line 476
    const v8, 0x7f0f0205

    .line 477
    .line 478
    .line 479
    invoke-static {v8, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 480
    .line 481
    .line 482
    move-result-object v8

    .line 483
    iget-object v9, v7, Llu4;->e:Ljava/lang/String;

    .line 484
    .line 485
    new-instance v10, Lcb3;

    .line 486
    .line 487
    invoke-direct {v10, v2, v1}, Lcb3;-><init>(FZ)V

    .line 488
    .line 489
    .line 490
    invoke-static/range {v8 .. v14}, Lsc3;->n(Ljava/lang/String;Ljava/lang/String;Li14;Lfa2;Lub2;II)V

    .line 491
    .line 492
    .line 493
    invoke-virtual {v12, v1}, Lub2;->r(Z)V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v12, v6}, Lub2;->g(Ljava/lang/Object;)Z

    .line 497
    .line 498
    .line 499
    move-result v1

    .line 500
    invoke-virtual {v12}, Lub2;->N()Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v2

    .line 504
    if-nez v1, :cond_6

    .line 505
    .line 506
    if-ne v2, v0, :cond_7

    .line 507
    .line 508
    :cond_6
    new-instance v2, Lg1;

    .line 509
    .line 510
    const/16 v0, 0x11

    .line 511
    .line 512
    invoke-direct {v2, v6, v0}, Lg1;-><init>(Lmm6;B)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {v12, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 516
    .line 517
    .line 518
    :cond_7
    move-object v8, v2

    .line 519
    check-cast v8, Lfa2;

    .line 520
    .line 521
    move-object/from16 v0, p1

    .line 522
    .line 523
    const/high16 v6, 0x3f800000    # 1.0f

    .line 524
    .line 525
    invoke-static {v0, v6}, Lch6;->d(Li14;F)Li14;

    .line 526
    .line 527
    .line 528
    move-result-object v9

    .line 529
    move-wide/from16 v10, v32

    .line 530
    .line 531
    const v1, 0x3e3851ec    # 0.18f

    .line 532
    .line 533
    .line 534
    invoke-static {v10, v11, v1}, Lsv0;->b(JF)J

    .line 535
    .line 536
    .line 537
    move-result-wide v1

    .line 538
    const/16 v16, 0x0

    .line 539
    .line 540
    const/16 v18, 0x30

    .line 541
    .line 542
    const/4 v14, 0x0

    .line 543
    move-object v6, v15

    .line 544
    const/4 v15, 0x0

    .line 545
    move-object/from16 v17, v12

    .line 546
    .line 547
    move-wide v12, v1

    .line 548
    invoke-static/range {v8 .. v18}, Lc75;->b(Lfa2;Li14;JJIFLqa2;Lub2;I)V

    .line 549
    .line 550
    .line 551
    move-object/from16 v12, v17

    .line 552
    .line 553
    const/4 v9, 0x0

    .line 554
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 555
    .line 556
    .line 557
    goto :goto_6

    .line 558
    :cond_8
    move-object v0, v1

    .line 559
    move-object/from16 v22, v2

    .line 560
    .line 561
    move-object/from16 v34, v13

    .line 562
    .line 563
    move-object v6, v15

    .line 564
    const v1, -0x38683fa2

    .line 565
    .line 566
    .line 567
    invoke-virtual {v12, v1}, Lub2;->b0(I)V

    .line 568
    .line 569
    .line 570
    iget-boolean v1, v7, Llu4;->c:Z

    .line 571
    .line 572
    if-eqz v1, :cond_9

    .line 573
    .line 574
    const v1, 0x7f0f0366

    .line 575
    .line 576
    .line 577
    goto :goto_5

    .line 578
    :cond_9
    const v1, 0x7f0f0203

    .line 579
    .line 580
    .line 581
    :goto_5
    invoke-static {v1, v12}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 582
    .line 583
    .line 584
    move-result-object v1

    .line 585
    invoke-static {v1, v12, v9}, Lsc3;->e(Ljava/lang/String;Lub2;I)V

    .line 586
    .line 587
    .line 588
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 589
    .line 590
    .line 591
    :goto_6
    if-lez v19, :cond_b

    .line 592
    .line 593
    const v1, 0x2b67f4fd

    .line 594
    .line 595
    .line 596
    invoke-virtual {v12, v1}, Lub2;->b0(I)V

    .line 597
    .line 598
    .line 599
    const/high16 v14, 0x3f800000    # 1.0f

    .line 600
    .line 601
    invoke-static {v0, v14}, Lch6;->d(Li14;F)Li14;

    .line 602
    .line 603
    .line 604
    move-result-object v0

    .line 605
    sget-object v1, Lt6;->u:Lq20;

    .line 606
    .line 607
    const/16 v2, 0x30

    .line 608
    .line 609
    move-object/from16 v8, v22

    .line 610
    .line 611
    invoke-static {v8, v1, v12, v2}, Lsq5;->a(Luv;Lq20;Lub2;I)Ltq5;

    .line 612
    .line 613
    .line 614
    move-result-object v1

    .line 615
    iget-wide v8, v12, Lub2;->T:J

    .line 616
    .line 617
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 618
    .line 619
    .line 620
    move-result v2

    .line 621
    invoke-virtual {v12}, Lub2;->m()Lh05;

    .line 622
    .line 623
    .line 624
    move-result-object v8

    .line 625
    invoke-static {v12, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 626
    .line 627
    .line 628
    move-result-object v0

    .line 629
    invoke-virtual {v12}, Lub2;->e0()V

    .line 630
    .line 631
    .line 632
    iget-boolean v9, v12, Lub2;->S:Z

    .line 633
    .line 634
    if-eqz v9, :cond_a

    .line 635
    .line 636
    move-object/from16 v13, v34

    .line 637
    .line 638
    invoke-virtual {v12, v13}, Lub2;->l(Lfa2;)V

    .line 639
    .line 640
    .line 641
    goto :goto_7

    .line 642
    :cond_a
    invoke-virtual {v12}, Lub2;->n0()V

    .line 643
    .line 644
    .line 645
    :goto_7
    invoke-static {v3, v12, v1}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 646
    .line 647
    .line 648
    invoke-static {v4, v12, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 649
    .line 650
    .line 651
    invoke-static {v2, v12, v5, v12}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 652
    .line 653
    .line 654
    invoke-static {v6, v12, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 655
    .line 656
    .line 657
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 658
    .line 659
    .line 660
    move-result-object v0

    .line 661
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 662
    .line 663
    .line 664
    move-result-object v0

    .line 665
    const v1, 0x7f0f0365

    .line 666
    .line 667
    .line 668
    invoke-static {v1, v0, v12}, Lkb3;->e0(I[Ljava/lang/Object;Lub2;)Ljava/lang/String;

    .line 669
    .line 670
    .line 671
    move-result-object v8

    .line 672
    new-instance v9, Lcb3;

    .line 673
    .line 674
    const/4 v1, 0x1

    .line 675
    const/high16 v6, 0x3f800000    # 1.0f

    .line 676
    .line 677
    invoke-direct {v9, v6, v1}, Lcb3;-><init>(FZ)V

    .line 678
    .line 679
    .line 680
    sget-object v0, Lwr3;->b:Lyt1;

    .line 681
    .line 682
    invoke-virtual {v12, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    check-cast v1, Ltr3;

    .line 687
    .line 688
    iget-object v1, v1, Ltr3;->b:Lic7;

    .line 689
    .line 690
    iget-object v1, v1, Lic7;->l:Lk37;

    .line 691
    .line 692
    invoke-virtual {v12, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 693
    .line 694
    .line 695
    move-result-object v2

    .line 696
    check-cast v2, Ltr3;

    .line 697
    .line 698
    iget-object v2, v2, Ltr3;->a:Lyv0;

    .line 699
    .line 700
    iget-wide v10, v2, Lyv0;->s:J

    .line 701
    .line 702
    const/16 v28, 0x6180

    .line 703
    .line 704
    const v29, 0x1aff8

    .line 705
    .line 706
    .line 707
    move-object/from16 v17, v12

    .line 708
    .line 709
    const-wide/16 v12, 0x0

    .line 710
    .line 711
    const/4 v14, 0x0

    .line 712
    const/4 v15, 0x0

    .line 713
    move-object/from16 v26, v17

    .line 714
    .line 715
    const-wide/16 v16, 0x0

    .line 716
    .line 717
    const/16 v18, 0x0

    .line 718
    .line 719
    const-wide/16 v19, 0x0

    .line 720
    .line 721
    const/16 v21, 0x2

    .line 722
    .line 723
    const/16 v22, 0x0

    .line 724
    .line 725
    const/16 v23, 0x1

    .line 726
    .line 727
    const/16 v24, 0x0

    .line 728
    .line 729
    const/16 v27, 0x0

    .line 730
    .line 731
    move-object/from16 v25, v1

    .line 732
    .line 733
    invoke-static/range {v8 .. v29}, Lq17;->b(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    .line 734
    .line 735
    .line 736
    move-object/from16 v12, v26

    .line 737
    .line 738
    iget v1, v7, Llu4;->j:I

    .line 739
    .line 740
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 741
    .line 742
    .line 743
    move-result-object v1

    .line 744
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 745
    .line 746
    .line 747
    move-result-object v1

    .line 748
    const v2, 0x7f0f00c4

    .line 749
    .line 750
    .line 751
    invoke-static {v2, v1, v12}, Lkb3;->e0(I[Ljava/lang/Object;Lub2;)Ljava/lang/String;

    .line 752
    .line 753
    .line 754
    move-result-object v8

    .line 755
    invoke-virtual {v12, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 756
    .line 757
    .line 758
    move-result-object v1

    .line 759
    check-cast v1, Ltr3;

    .line 760
    .line 761
    iget-object v1, v1, Ltr3;->b:Lic7;

    .line 762
    .line 763
    iget-object v1, v1, Lic7;->l:Lk37;

    .line 764
    .line 765
    invoke-virtual {v12, v0}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 766
    .line 767
    .line 768
    move-result-object v0

    .line 769
    check-cast v0, Ltr3;

    .line 770
    .line 771
    iget-object v0, v0, Ltr3;->a:Lyv0;

    .line 772
    .line 773
    iget-wide v10, v0, Lyv0;->s:J

    .line 774
    .line 775
    const v29, 0x1affa

    .line 776
    .line 777
    .line 778
    const/4 v9, 0x0

    .line 779
    move-object/from16 v17, v12

    .line 780
    .line 781
    const-wide/16 v12, 0x0

    .line 782
    .line 783
    move-object/from16 v26, v17

    .line 784
    .line 785
    const-wide/16 v16, 0x0

    .line 786
    .line 787
    move-object/from16 v25, v1

    .line 788
    .line 789
    invoke-static/range {v8 .. v29}, Lq17;->b(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    .line 790
    .line 791
    .line 792
    move-object/from16 v12, v26

    .line 793
    .line 794
    const/4 v1, 0x1

    .line 795
    invoke-virtual {v12, v1}, Lub2;->r(Z)V

    .line 796
    .line 797
    .line 798
    const/4 v9, 0x0

    .line 799
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 800
    .line 801
    .line 802
    goto :goto_8

    .line 803
    :cond_b
    const/4 v1, 0x1

    .line 804
    const/4 v9, 0x0

    .line 805
    const v0, 0x2b796462

    .line 806
    .line 807
    .line 808
    invoke-virtual {v12, v0}, Lub2;->b0(I)V

    .line 809
    .line 810
    .line 811
    invoke-virtual {v12, v9}, Lub2;->r(Z)V

    .line 812
    .line 813
    .line 814
    :goto_8
    invoke-virtual {v12, v1}, Lub2;->r(Z)V

    .line 815
    .line 816
    .line 817
    goto :goto_9

    .line 818
    :cond_c
    move-object/from16 v31, v4

    .line 819
    .line 820
    invoke-virtual {v12}, Lub2;->V()V

    .line 821
    .line 822
    .line 823
    :goto_9
    return-object v31

    .line 824
    :pswitch_0
    move-object/from16 v31, v4

    .line 825
    .line 826
    move v1, v5

    .line 827
    move-object v2, v7

    .line 828
    check-cast v2, Ljava/lang/String;

    .line 829
    .line 830
    move-object v3, v6

    .line 831
    check-cast v3, Ljava/lang/String;

    .line 832
    .line 833
    move-object/from16 v6, p1

    .line 834
    .line 835
    check-cast v6, Lub2;

    .line 836
    .line 837
    move-object/from16 v4, p2

    .line 838
    .line 839
    check-cast v4, Ljava/lang/Integer;

    .line 840
    .line 841
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 842
    .line 843
    .line 844
    invoke-static {v1}, Lub3;->b0(I)I

    .line 845
    .line 846
    .line 847
    move-result v7

    .line 848
    iget-wide v4, v0, Lag0;->j:J

    .line 849
    .line 850
    invoke-static/range {v2 .. v7}, Lpn;->w(Ljava/lang/String;Ljava/lang/String;JLub2;I)V

    .line 851
    .line 852
    .line 853
    return-object v31

    .line 854
    :pswitch_1
    move-object/from16 v31, v4

    .line 855
    .line 856
    const/4 v9, 0x0

    .line 857
    check-cast v7, Lxu4;

    .line 858
    .line 859
    check-cast v6, Lva2;

    .line 860
    .line 861
    move-object/from16 v14, p1

    .line 862
    .line 863
    check-cast v14, Lub2;

    .line 864
    .line 865
    move-object/from16 v1, p2

    .line 866
    .line 867
    check-cast v1, Ljava/lang/Integer;

    .line 868
    .line 869
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 870
    .line 871
    .line 872
    move-result v1

    .line 873
    and-int/lit8 v3, v1, 0x3

    .line 874
    .line 875
    if-eq v3, v2, :cond_d

    .line 876
    .line 877
    const/4 v3, 0x1

    .line 878
    :goto_a
    const/16 v30, 0x1

    .line 879
    .line 880
    goto :goto_b

    .line 881
    :cond_d
    move v3, v9

    .line 882
    goto :goto_a

    .line 883
    :goto_b
    and-int/lit8 v1, v1, 0x1

    .line 884
    .line 885
    invoke-virtual {v14, v1, v3}, Lub2;->S(IZ)Z

    .line 886
    .line 887
    .line 888
    move-result v1

    .line 889
    if-eqz v1, :cond_e

    .line 890
    .line 891
    sget-object v1, Lwr3;->b:Lyt1;

    .line 892
    .line 893
    invoke-virtual {v14, v1}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 894
    .line 895
    .line 896
    move-result-object v1

    .line 897
    check-cast v1, Ltr3;

    .line 898
    .line 899
    iget-object v1, v1, Ltr3;->b:Lic7;

    .line 900
    .line 901
    iget-object v12, v1, Lic7;->m:Lk37;

    .line 902
    .line 903
    new-instance v1, Lda0;

    .line 904
    .line 905
    const/16 v2, 0x14

    .line 906
    .line 907
    invoke-direct {v1, v7, v6, v2}, Lda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 908
    .line 909
    .line 910
    const v2, 0x18e49c83

    .line 911
    .line 912
    .line 913
    invoke-static {v2, v1, v14}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 914
    .line 915
    .line 916
    move-result-object v13

    .line 917
    const/16 v15, 0x180

    .line 918
    .line 919
    iget-wide v10, v0, Lag0;->j:J

    .line 920
    .line 921
    invoke-static/range {v10 .. v15}, Lkb3;->k(JLk37;Lua2;Lub2;I)V

    .line 922
    .line 923
    .line 924
    goto :goto_c

    .line 925
    :cond_e
    invoke-virtual {v14}, Lub2;->V()V

    .line 926
    .line 927
    .line 928
    :goto_c
    return-object v31

    .line 929
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
