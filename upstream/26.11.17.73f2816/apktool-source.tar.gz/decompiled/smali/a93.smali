.class public final synthetic La93;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lz83;


# direct methods
.method public synthetic constructor <init>(Lz83;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La93;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La93;->j:Lz83;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, La93;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x0

    .line 7
    const-string v4, "latency-targets-reset"

    .line 8
    .line 9
    iget-object p0, p0, La93;->j:Lz83;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lz83;->c:Lnd6;

    .line 15
    .line 16
    new-instance v5, Ly83;

    .line 17
    .line 18
    invoke-direct {v5, p0, v3, v2}, Ly83;-><init>(Lz83;Lia1;B)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, v5, v4}, Lnd6;->f(Lqa2;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object v1

    .line 25
    :pswitch_0
    iget-object v0, p0, Lz83;->c:Lnd6;

    .line 26
    .line 27
    new-instance v5, Ly83;

    .line 28
    .line 29
    invoke-direct {v5, p0, v3, v2}, Ly83;-><init>(Lz83;Lia1;B)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0, v5, v4}, Lnd6;->f(Lqa2;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
