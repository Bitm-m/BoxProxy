.class public final Lb74;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lg52;


# instance fields
.field public final synthetic i:Lng;

.field public final synthetic j:I

.field public final synthetic k:F


# direct methods
.method public constructor <init>(Lng;IF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb74;->i:Lng;

    .line 5
    .line 6
    iput p2, p0, Lb74;->j:I

    .line 7
    .line 8
    iput p3, p0, Lb74;->k:F

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;Lia1;)Ljava/lang/Object;
    .locals 2

    .line 1
    check-cast p1, Lu54;

    .line 2
    .line 3
    iget p1, p1, Lu54;->a:F

    .line 4
    .line 5
    iget v0, p0, Lb74;->k:F

    .line 6
    .line 7
    iget-object v1, p0, Lb74;->i:Lng;

    .line 8
    .line 9
    iget p0, p0, Lb74;->j:I

    .line 10
    .line 11
    invoke-static {v1, p0, p1, v0, p2}, Lbb3;->W(Lng;IFFLia1;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    sget-object p1, Lsf1;->i:Lsf1;

    .line 16
    .line 17
    if-ne p0, p1, :cond_0

    .line 18
    .line 19
    return-object p0

    .line 20
    :cond_0
    sget-object p0, Lne7;->a:Lne7;

    .line 21
    .line 22
    return-object p0
.end method
