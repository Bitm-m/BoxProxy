.class public final synthetic Lb04;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Ljava/lang/String;

.field public final synthetic j:Lqa2;

.field public final synthetic k:Lqa2;

.field public final synthetic l:Z

.field public final synthetic m:Lqa2;

.field public final synthetic n:Li14;

.field public final synthetic o:Ljava/lang/String;

.field public final synthetic p:Z

.field public final synthetic q:J

.field public final synthetic r:Lw34;

.field public final synthetic s:I

.field public final synthetic t:S

.field public final synthetic u:S


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lqa2;Lqa2;ZLqa2;Li14;Ljava/lang/String;ZJLw34;III)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb04;->i:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lb04;->j:Lqa2;

    .line 7
    .line 8
    iput-object p3, p0, Lb04;->k:Lqa2;

    .line 9
    .line 10
    iput-boolean p4, p0, Lb04;->l:Z

    .line 11
    .line 12
    iput-object p5, p0, Lb04;->m:Lqa2;

    .line 13
    .line 14
    iput-object p6, p0, Lb04;->n:Li14;

    .line 15
    .line 16
    iput-object p7, p0, Lb04;->o:Ljava/lang/String;

    .line 17
    .line 18
    iput-boolean p8, p0, Lb04;->p:Z

    .line 19
    .line 20
    iput-wide p9, p0, Lb04;->q:J

    .line 21
    .line 22
    iput-object p11, p0, Lb04;->r:Lw34;

    .line 23
    .line 24
    iput p12, p0, Lb04;->s:I

    .line 25
    .line 26
    iput-short p13, p0, Lb04;->t:S

    .line 27
    .line 28
    iput-short p14, p0, Lb04;->u:S

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v11, p1

    .line 4
    .line 5
    check-cast v11, Lub2;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v1, v0, Lb04;->s:I

    .line 15
    .line 16
    or-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    invoke-static {v1}, Lub3;->b0(I)I

    .line 19
    .line 20
    .line 21
    move-result v12

    .line 22
    iget-short v1, v0, Lb04;->t:S

    .line 23
    .line 24
    invoke-static {v1}, Lub3;->b0(I)I

    .line 25
    .line 26
    .line 27
    move-result v13

    .line 28
    iget-object v1, v0, Lb04;->i:Ljava/lang/String;

    .line 29
    .line 30
    move-object v2, v1

    .line 31
    iget-object v1, v0, Lb04;->j:Lqa2;

    .line 32
    .line 33
    move-object v3, v2

    .line 34
    iget-object v2, v0, Lb04;->k:Lqa2;

    .line 35
    .line 36
    move-object v4, v3

    .line 37
    iget-boolean v3, v0, Lb04;->l:Z

    .line 38
    .line 39
    move-object v5, v4

    .line 40
    iget-object v4, v0, Lb04;->m:Lqa2;

    .line 41
    .line 42
    move-object v6, v5

    .line 43
    iget-object v5, v0, Lb04;->n:Li14;

    .line 44
    .line 45
    move-object v7, v6

    .line 46
    iget-object v6, v0, Lb04;->o:Ljava/lang/String;

    .line 47
    .line 48
    move-object v8, v7

    .line 49
    iget-boolean v7, v0, Lb04;->p:Z

    .line 50
    .line 51
    move-object v10, v8

    .line 52
    iget-wide v8, v0, Lb04;->q:J

    .line 53
    .line 54
    move-object v14, v10

    .line 55
    iget-object v10, v0, Lb04;->r:Lw34;

    .line 56
    .line 57
    iget-short v0, v0, Lb04;->u:S

    .line 58
    .line 59
    move-object v15, v14

    .line 60
    move v14, v0

    .line 61
    move-object v0, v15

    .line 62
    invoke-static/range {v0 .. v14}, Lsc3;->d(Ljava/lang/String;Lqa2;Lqa2;ZLqa2;Li14;Ljava/lang/String;ZJLw34;Lub2;III)V

    .line 63
    .line 64
    .line 65
    sget-object v0, Lne7;->a:Lne7;

    .line 66
    .line 67
    return-object v0
.end method
