.class public final Lah5;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final a:Lah5;

.field public static final b:Lfq5;

.field public static final c:F

.field public static final d:F

.field public static final e:F


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lah5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lah5;->a:Lah5;

    .line 7
    .line 8
    sget-object v0, Lhq5;->a:Lfq5;

    .line 9
    .line 10
    sput-object v0, Lah5;->b:Lfq5;

    .line 11
    .line 12
    const/high16 v0, 0x42a00000    # 80.0f

    .line 13
    .line 14
    sput v0, Lah5;->c:F

    .line 15
    .line 16
    sput v0, Lah5;->d:F

    .line 17
    .line 18
    const/high16 v0, 0x40400000    # 3.0f

    .line 19
    .line 20
    sput v0, Lah5;->e:F

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final a(Lbi5;ZLi14;FLfq5;JFLc01;Lub2;II)V
    .locals 20

    .line 1
    move-object/from16 v4, p3

    .line 2
    .line 3
    move/from16 v5, p4

    .line 4
    .line 5
    move-wide/from16 v0, p6

    .line 6
    .line 7
    move-object/from16 v2, p9

    .line 8
    .line 9
    move-object/from16 v3, p10

    .line 10
    .line 11
    move/from16 v11, p11

    .line 12
    .line 13
    const v6, -0x4ff03da9

    .line 14
    .line 15
    .line 16
    invoke-virtual {v3, v6}, Lub2;->c0(I)Lub2;

    .line 17
    .line 18
    .line 19
    and-int/lit8 v6, v11, 0x6

    .line 20
    .line 21
    if-nez v6, :cond_1

    .line 22
    .line 23
    move-object/from16 v6, p1

    .line 24
    .line 25
    invoke-virtual {v3, v6}, Lub2;->g(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v8

    .line 29
    if-eqz v8, :cond_0

    .line 30
    .line 31
    const/4 v8, 0x4

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    const/4 v8, 0x2

    .line 34
    :goto_0
    or-int/2addr v8, v11

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    move-object/from16 v6, p1

    .line 37
    .line 38
    move v8, v11

    .line 39
    :goto_1
    and-int/lit8 v9, v11, 0x30

    .line 40
    .line 41
    if-nez v9, :cond_3

    .line 42
    .line 43
    move/from16 v9, p2

    .line 44
    .line 45
    invoke-virtual {v3, v9}, Lub2;->h(Z)Z

    .line 46
    .line 47
    .line 48
    move-result v12

    .line 49
    if-eqz v12, :cond_2

    .line 50
    .line 51
    const/16 v12, 0x20

    .line 52
    .line 53
    goto :goto_2

    .line 54
    :cond_2
    const/16 v12, 0x10

    .line 55
    .line 56
    :goto_2
    or-int/2addr v8, v12

    .line 57
    :cond_3
    and-int/lit16 v12, v11, 0x180

    .line 58
    .line 59
    if-nez v12, :cond_5

    .line 60
    .line 61
    invoke-virtual {v3, v4}, Lub2;->g(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v12

    .line 65
    if-eqz v12, :cond_4

    .line 66
    .line 67
    const/16 v12, 0x100

    .line 68
    .line 69
    goto :goto_3

    .line 70
    :cond_4
    const/16 v12, 0x80

    .line 71
    .line 72
    :goto_3
    or-int/2addr v8, v12

    .line 73
    :cond_5
    and-int/lit16 v12, v11, 0xc00

    .line 74
    .line 75
    if-nez v12, :cond_7

    .line 76
    .line 77
    invoke-virtual {v3, v5}, Lub2;->d(F)Z

    .line 78
    .line 79
    .line 80
    move-result v12

    .line 81
    if-eqz v12, :cond_6

    .line 82
    .line 83
    const/16 v12, 0x800

    .line 84
    .line 85
    goto :goto_4

    .line 86
    :cond_6
    const/16 v12, 0x400

    .line 87
    .line 88
    :goto_4
    or-int/2addr v8, v12

    .line 89
    :cond_7
    and-int/lit16 v12, v11, 0x6000

    .line 90
    .line 91
    if-nez v12, :cond_8

    .line 92
    .line 93
    or-int/lit16 v8, v8, 0x2000

    .line 94
    .line 95
    :cond_8
    const/high16 v12, 0x30000

    .line 96
    .line 97
    and-int/2addr v12, v11

    .line 98
    if-nez v12, :cond_a

    .line 99
    .line 100
    invoke-virtual {v3, v0, v1}, Lub2;->f(J)Z

    .line 101
    .line 102
    .line 103
    move-result v12

    .line 104
    if-eqz v12, :cond_9

    .line 105
    .line 106
    const/high16 v12, 0x20000

    .line 107
    .line 108
    goto :goto_5

    .line 109
    :cond_9
    const/high16 v12, 0x10000

    .line 110
    .line 111
    :goto_5
    or-int/2addr v8, v12

    .line 112
    :cond_a
    const/high16 v12, 0x180000

    .line 113
    .line 114
    and-int v14, v11, v12

    .line 115
    .line 116
    if-nez v14, :cond_d

    .line 117
    .line 118
    and-int/lit8 v14, p12, 0x40

    .line 119
    .line 120
    if-nez v14, :cond_b

    .line 121
    .line 122
    move/from16 v14, p8

    .line 123
    .line 124
    invoke-virtual {v3, v14}, Lub2;->d(F)Z

    .line 125
    .line 126
    .line 127
    move-result v16

    .line 128
    if-eqz v16, :cond_c

    .line 129
    .line 130
    const/high16 v16, 0x100000

    .line 131
    .line 132
    goto :goto_6

    .line 133
    :cond_b
    move/from16 v14, p8

    .line 134
    .line 135
    :cond_c
    const/high16 v16, 0x80000

    .line 136
    .line 137
    :goto_6
    or-int v8, v8, v16

    .line 138
    .line 139
    goto :goto_7

    .line 140
    :cond_d
    move/from16 v14, p8

    .line 141
    .line 142
    :goto_7
    const/high16 v16, 0xc00000

    .line 143
    .line 144
    and-int v16, v11, v16

    .line 145
    .line 146
    if-nez v16, :cond_f

    .line 147
    .line 148
    invoke-virtual {v3, v2}, Lub2;->i(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v16

    .line 152
    if-eqz v16, :cond_e

    .line 153
    .line 154
    const/high16 v16, 0x800000

    .line 155
    .line 156
    goto :goto_8

    .line 157
    :cond_e
    const/high16 v16, 0x400000

    .line 158
    .line 159
    :goto_8
    or-int v8, v8, v16

    .line 160
    .line 161
    :cond_f
    const/high16 v16, 0x6000000

    .line 162
    .line 163
    and-int v16, v11, v16

    .line 164
    .line 165
    if-nez v16, :cond_11

    .line 166
    .line 167
    move/from16 v16, v12

    .line 168
    .line 169
    move-object/from16 v12, p0

    .line 170
    .line 171
    invoke-virtual {v3, v12}, Lub2;->g(Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v17

    .line 175
    if-eqz v17, :cond_10

    .line 176
    .line 177
    const/high16 v17, 0x4000000

    .line 178
    .line 179
    goto :goto_9

    .line 180
    :cond_10
    const/high16 v17, 0x2000000

    .line 181
    .line 182
    :goto_9
    or-int v8, v8, v17

    .line 183
    .line 184
    goto :goto_a

    .line 185
    :cond_11
    move/from16 v16, v12

    .line 186
    .line 187
    move-object/from16 v12, p0

    .line 188
    .line 189
    :goto_a
    const v17, 0x2492493

    .line 190
    .line 191
    .line 192
    and-int v15, v8, v17

    .line 193
    .line 194
    const v13, 0x2492492

    .line 195
    .line 196
    .line 197
    if-eq v15, v13, :cond_12

    .line 198
    .line 199
    const/4 v13, 0x1

    .line 200
    goto :goto_b

    .line 201
    :cond_12
    const/4 v13, 0x0

    .line 202
    :goto_b
    and-int/lit8 v15, v8, 0x1

    .line 203
    .line 204
    invoke-virtual {v3, v15, v13}, Lub2;->S(IZ)Z

    .line 205
    .line 206
    .line 207
    move-result v13

    .line 208
    if-eqz v13, :cond_21

    .line 209
    .line 210
    invoke-virtual {v3}, Lub2;->X()V

    .line 211
    .line 212
    .line 213
    and-int/lit8 v13, v11, 0x1

    .line 214
    .line 215
    const v15, -0x38e001

    .line 216
    .line 217
    .line 218
    const v18, -0xe001

    .line 219
    .line 220
    .line 221
    if-eqz v13, :cond_14

    .line 222
    .line 223
    invoke-virtual {v3}, Lub2;->z()Z

    .line 224
    .line 225
    .line 226
    move-result v13

    .line 227
    if-nez v13, :cond_14

    .line 228
    .line 229
    invoke-virtual {v3}, Lub2;->V()V

    .line 230
    .line 231
    .line 232
    and-int v18, v8, v18

    .line 233
    .line 234
    and-int/lit8 v13, p12, 0x40

    .line 235
    .line 236
    if-eqz v13, :cond_13

    .line 237
    .line 238
    and-int v18, v8, v15

    .line 239
    .line 240
    :cond_13
    move-object/from16 v8, p5

    .line 241
    .line 242
    move v9, v14

    .line 243
    move/from16 v13, v18

    .line 244
    .line 245
    goto :goto_d

    .line 246
    :cond_14
    and-int v18, v8, v18

    .line 247
    .line 248
    and-int/lit8 v13, p12, 0x40

    .line 249
    .line 250
    sget-object v19, Lah5;->b:Lfq5;

    .line 251
    .line 252
    if-eqz v13, :cond_15

    .line 253
    .line 254
    and-int v18, v8, v15

    .line 255
    .line 256
    sget v8, Lah5;->e:F

    .line 257
    .line 258
    move v9, v8

    .line 259
    :goto_c
    move/from16 v13, v18

    .line 260
    .line 261
    move-object/from16 v8, v19

    .line 262
    .line 263
    goto :goto_d

    .line 264
    :cond_15
    move v9, v14

    .line 265
    goto :goto_c

    .line 266
    :goto_d
    invoke-virtual {v3}, Lub2;->s()V

    .line 267
    .line 268
    .line 269
    const/high16 v14, 0x42200000    # 40.0f

    .line 270
    .line 271
    invoke-static {v4, v14}, Lch6;->m(Li14;F)Li14;

    .line 272
    .line 273
    .line 274
    move-result-object v14

    .line 275
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v15

    .line 279
    sget-object v7, Li21;->a:Ls9;

    .line 280
    .line 281
    if-ne v15, v7, :cond_16

    .line 282
    .line 283
    new-instance v15, Lhe5;

    .line 284
    .line 285
    const/16 v10, 0x8

    .line 286
    .line 287
    invoke-direct {v15, v10}, Lhe5;-><init>(B)V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v3, v15}, Lub2;->k0(Ljava/lang/Object;)V

    .line 291
    .line 292
    .line 293
    :cond_16
    check-cast v15, Lqa2;

    .line 294
    .line 295
    invoke-static {v14, v15}, Lvv6;->w(Li14;Lqa2;)Li14;

    .line 296
    .line 297
    .line 298
    move-result-object v14

    .line 299
    and-int/lit8 v10, v13, 0xe

    .line 300
    .line 301
    const/4 v15, 0x4

    .line 302
    if-ne v10, v15, :cond_17

    .line 303
    .line 304
    const/4 v10, 0x1

    .line 305
    goto :goto_e

    .line 306
    :cond_17
    const/4 v10, 0x0

    .line 307
    :goto_e
    and-int/lit8 v15, v13, 0x70

    .line 308
    .line 309
    const/16 v4, 0x20

    .line 310
    .line 311
    if-ne v15, v4, :cond_18

    .line 312
    .line 313
    const/4 v4, 0x1

    .line 314
    goto :goto_f

    .line 315
    :cond_18
    const/4 v4, 0x0

    .line 316
    :goto_f
    or-int/2addr v10, v4

    .line 317
    and-int/lit16 v4, v13, 0x1c00

    .line 318
    .line 319
    xor-int/lit16 v4, v4, 0xc00

    .line 320
    .line 321
    const/16 v15, 0x800

    .line 322
    .line 323
    if-le v4, v15, :cond_19

    .line 324
    .line 325
    invoke-virtual {v3, v5}, Lub2;->d(F)Z

    .line 326
    .line 327
    .line 328
    move-result v4

    .line 329
    if-nez v4, :cond_1a

    .line 330
    .line 331
    :cond_19
    and-int/lit16 v4, v13, 0xc00

    .line 332
    .line 333
    if-ne v4, v15, :cond_1b

    .line 334
    .line 335
    :cond_1a
    const/4 v4, 0x1

    .line 336
    goto :goto_10

    .line 337
    :cond_1b
    const/4 v4, 0x0

    .line 338
    :goto_10
    or-int/2addr v10, v4

    .line 339
    const/high16 v4, 0x380000

    .line 340
    .line 341
    and-int/2addr v4, v13

    .line 342
    xor-int v4, v4, v16

    .line 343
    .line 344
    const/high16 v15, 0x100000

    .line 345
    .line 346
    if-le v4, v15, :cond_1c

    .line 347
    .line 348
    invoke-virtual {v3, v9}, Lub2;->d(F)Z

    .line 349
    .line 350
    .line 351
    move-result v4

    .line 352
    if-nez v4, :cond_1d

    .line 353
    .line 354
    :cond_1c
    and-int v4, v13, v16

    .line 355
    .line 356
    if-ne v4, v15, :cond_1e

    .line 357
    .line 358
    :cond_1d
    const/4 v4, 0x1

    .line 359
    goto :goto_11

    .line 360
    :cond_1e
    const/4 v4, 0x0

    .line 361
    :goto_11
    or-int/2addr v10, v4

    .line 362
    invoke-virtual {v3, v8}, Lub2;->g(Ljava/lang/Object;)Z

    .line 363
    .line 364
    .line 365
    move-result v4

    .line 366
    or-int/2addr v10, v4

    .line 367
    invoke-virtual {v3}, Lub2;->N()Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v4

    .line 371
    if-nez v10, :cond_1f

    .line 372
    .line 373
    if-eq v4, v7, :cond_1f

    .line 374
    .line 375
    move-object v5, v4

    .line 376
    move-object v10, v8

    .line 377
    const/4 v4, 0x0

    .line 378
    const/4 v15, 0x1

    .line 379
    goto :goto_12

    .line 380
    :cond_1f
    new-instance v5, Lvg5;

    .line 381
    .line 382
    move/from16 v7, p2

    .line 383
    .line 384
    move-object v10, v8

    .line 385
    const/4 v4, 0x0

    .line 386
    const/4 v15, 0x1

    .line 387
    move/from16 v8, p4

    .line 388
    .line 389
    invoke-direct/range {v5 .. v10}, Lvg5;-><init>(Lbi5;ZFFLfq5;)V

    .line 390
    .line 391
    .line 392
    invoke-virtual {v3, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 393
    .line 394
    .line 395
    :goto_12
    check-cast v5, Lva2;

    .line 396
    .line 397
    invoke-static {v14, v5}, Lu23;->z(Li14;Lva2;)Li14;

    .line 398
    .line 399
    .line 400
    move-result-object v5

    .line 401
    invoke-static {v5, v0, v1, v10}, Lgb;->N(Li14;JLub6;)Li14;

    .line 402
    .line 403
    .line 404
    move-result-object v5

    .line 405
    sget-object v6, Lt6;->o:Lr20;

    .line 406
    .line 407
    shr-int/lit8 v13, v13, 0xc

    .line 408
    .line 409
    and-int/lit16 v13, v13, 0x1c00

    .line 410
    .line 411
    or-int/lit8 v13, v13, 0x30

    .line 412
    .line 413
    invoke-static {v6, v4}, Lnb0;->c(Lr20;Z)Lis3;

    .line 414
    .line 415
    .line 416
    move-result-object v4

    .line 417
    iget-wide v6, v3, Lub2;->T:J

    .line 418
    .line 419
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 420
    .line 421
    .line 422
    move-result v6

    .line 423
    invoke-virtual {v3}, Lub2;->m()Lh05;

    .line 424
    .line 425
    .line 426
    move-result-object v7

    .line 427
    invoke-static {v3, v5}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 428
    .line 429
    .line 430
    move-result-object v5

    .line 431
    sget-object v8, La21;->d:Lt6;

    .line 432
    .line 433
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 434
    .line 435
    .line 436
    invoke-virtual {v3}, Lub2;->e0()V

    .line 437
    .line 438
    .line 439
    iget-boolean v8, v3, Lub2;->S:Z

    .line 440
    .line 441
    if-eqz v8, :cond_20

    .line 442
    .line 443
    sget-object v8, Lja3;->a0:Lxg2;

    .line 444
    .line 445
    invoke-virtual {v3, v8}, Lub2;->l(Lfa2;)V

    .line 446
    .line 447
    .line 448
    goto :goto_13

    .line 449
    :cond_20
    invoke-virtual {v3}, Lub2;->n0()V

    .line 450
    .line 451
    .line 452
    :goto_13
    sget-object v8, Lt6;->S:Lf11;

    .line 453
    .line 454
    invoke-static {v8, v3, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 455
    .line 456
    .line 457
    sget-object v4, Lt6;->R:Lf11;

    .line 458
    .line 459
    invoke-static {v4, v3, v7}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 460
    .line 461
    .line 462
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 463
    .line 464
    .line 465
    move-result-object v4

    .line 466
    sget-object v6, Lt6;->T:Lf11;

    .line 467
    .line 468
    invoke-static {v6, v3, v4}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    invoke-static {v3}, Les6;->l(Lub2;)V

    .line 472
    .line 473
    .line 474
    sget-object v4, Lt6;->Q:Lf11;

    .line 475
    .line 476
    invoke-static {v4, v3, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 477
    .line 478
    .line 479
    shr-int/lit8 v13, v13, 0x6

    .line 480
    .line 481
    and-int/lit8 v13, v13, 0x70

    .line 482
    .line 483
    or-int/lit8 v13, v13, 0x6

    .line 484
    .line 485
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 486
    .line 487
    .line 488
    move-result-object v4

    .line 489
    sget-object v5, Lwc0;->a:Lwc0;

    .line 490
    .line 491
    invoke-virtual {v2, v5, v3, v4}, Lc01;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 492
    .line 493
    .line 494
    invoke-virtual {v3, v15}, Lub2;->r(Z)V

    .line 495
    .line 496
    .line 497
    move-object v6, v10

    .line 498
    goto :goto_14

    .line 499
    :cond_21
    invoke-virtual {v3}, Lub2;->V()V

    .line 500
    .line 501
    .line 502
    move-object/from16 v6, p5

    .line 503
    .line 504
    move v9, v14

    .line 505
    :goto_14
    invoke-virtual {v3}, Lub2;->t()Lkk5;

    .line 506
    .line 507
    .line 508
    move-result-object v13

    .line 509
    if-eqz v13, :cond_22

    .line 510
    .line 511
    new-instance v0, Lwg5;

    .line 512
    .line 513
    move/from16 v3, p2

    .line 514
    .line 515
    move-object/from16 v4, p3

    .line 516
    .line 517
    move/from16 v5, p4

    .line 518
    .line 519
    move-wide/from16 v7, p6

    .line 520
    .line 521
    move-object v10, v2

    .line 522
    move-object v1, v12

    .line 523
    move-object/from16 v2, p1

    .line 524
    .line 525
    move/from16 v12, p12

    .line 526
    .line 527
    invoke-direct/range {v0 .. v12}, Lwg5;-><init>(Lah5;Lbi5;ZLi14;FLfq5;JFLc01;II)V

    .line 528
    .line 529
    .line 530
    iput-object v0, v13, Lkk5;->d:Lua2;

    .line 531
    .line 532
    :cond_22
    return-void
.end method

.method public final b(Lbi5;ZLi14;JJFLub2;I)V
    .locals 22

    .line 1
    move-object/from16 v4, p3

    .line 2
    .line 3
    move-object/from16 v15, p9

    .line 4
    .line 5
    const v0, 0xae28da8

    .line 6
    .line 7
    .line 8
    invoke-virtual {v15, v0}, Lub2;->c0(I)Lub2;

    .line 9
    .line 10
    .line 11
    move-object/from16 v6, p1

    .line 12
    .line 13
    invoke-virtual {v15, v6}, Lub2;->g(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const/4 v0, 0x4

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v0, 0x2

    .line 22
    :goto_0
    or-int v0, p10, v0

    .line 23
    .line 24
    move/from16 v7, p2

    .line 25
    .line 26
    invoke-virtual {v15, v7}, Lub2;->h(Z)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    const/16 v1, 0x20

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_1
    const/16 v1, 0x10

    .line 36
    .line 37
    :goto_1
    or-int/2addr v0, v1

    .line 38
    invoke-virtual {v15, v4}, Lub2;->g(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_2

    .line 43
    .line 44
    const/16 v1, 0x100

    .line 45
    .line 46
    goto :goto_2

    .line 47
    :cond_2
    const/16 v1, 0x80

    .line 48
    .line 49
    :goto_2
    or-int/2addr v0, v1

    .line 50
    const v1, 0x92400

    .line 51
    .line 52
    .line 53
    or-int/2addr v0, v1

    .line 54
    const v1, 0x492493

    .line 55
    .line 56
    .line 57
    and-int/2addr v1, v0

    .line 58
    const v2, 0x492492

    .line 59
    .line 60
    .line 61
    if-eq v1, v2, :cond_3

    .line 62
    .line 63
    const/4 v1, 0x1

    .line 64
    goto :goto_3

    .line 65
    :cond_3
    const/4 v1, 0x0

    .line 66
    :goto_3
    and-int/lit8 v2, v0, 0x1

    .line 67
    .line 68
    invoke-virtual {v15, v2, v1}, Lub2;->S(IZ)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-eqz v1, :cond_5

    .line 73
    .line 74
    invoke-virtual {v15}, Lub2;->X()V

    .line 75
    .line 76
    .line 77
    and-int/lit8 v1, p10, 0x1

    .line 78
    .line 79
    const v2, -0x3ffc01

    .line 80
    .line 81
    .line 82
    if-eqz v1, :cond_4

    .line 83
    .line 84
    invoke-virtual {v15}, Lub2;->z()Z

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    if-nez v1, :cond_4

    .line 89
    .line 90
    invoke-virtual {v15}, Lub2;->V()V

    .line 91
    .line 92
    .line 93
    and-int/2addr v0, v2

    .line 94
    move-wide/from16 v11, p4

    .line 95
    .line 96
    move-wide/from16 v9, p6

    .line 97
    .line 98
    move/from16 v1, p8

    .line 99
    .line 100
    goto :goto_4

    .line 101
    :cond_4
    sget-object v1, Lsk3;->a:Ljava/util/List;

    .line 102
    .line 103
    const/16 v1, 0x1a

    .line 104
    .line 105
    invoke-static {v1, v15}, Lzv0;->e(ILub2;)J

    .line 106
    .line 107
    .line 108
    move-result-wide v8

    .line 109
    const/16 v1, 0xa

    .line 110
    .line 111
    invoke-static {v1, v15}, Lzv0;->e(ILub2;)J

    .line 112
    .line 113
    .line 114
    move-result-wide v10

    .line 115
    and-int/2addr v0, v2

    .line 116
    sget v1, Lah5;->d:F

    .line 117
    .line 118
    move-wide/from16 v20, v10

    .line 119
    .line 120
    move-wide v11, v8

    .line 121
    move-wide/from16 v9, v20

    .line 122
    .line 123
    :goto_4
    invoke-virtual {v15}, Lub2;->s()V

    .line 124
    .line 125
    .line 126
    sget-object v2, Lsk3;->a:Ljava/util/List;

    .line 127
    .line 128
    const/high16 v2, 0x42400000    # 48.0f

    .line 129
    .line 130
    invoke-static {v4, v2, v2}, Lch6;->n(Li14;FF)Li14;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    new-instance v5, Lsg5;

    .line 135
    .line 136
    move-wide/from16 v20, v11

    .line 137
    .line 138
    move-object v11, v6

    .line 139
    move v6, v7

    .line 140
    move-wide/from16 v7, v20

    .line 141
    .line 142
    invoke-direct/range {v5 .. v11}, Lsg5;-><init>(ZJJLbi5;)V

    .line 143
    .line 144
    .line 145
    move-wide/from16 v18, v9

    .line 146
    .line 147
    const v3, 0x7e896221

    .line 148
    .line 149
    .line 150
    invoke-static {v3, v5, v15}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 151
    .line 152
    .line 153
    move-result-object v14

    .line 154
    and-int/lit8 v3, v0, 0xe

    .line 155
    .line 156
    const/high16 v5, 0xc00000

    .line 157
    .line 158
    or-int/2addr v3, v5

    .line 159
    and-int/lit8 v0, v0, 0x70

    .line 160
    .line 161
    or-int/2addr v3, v0

    .line 162
    const/high16 v0, 0x6000000

    .line 163
    .line 164
    or-int v16, v3, v0

    .line 165
    .line 166
    const/16 v17, 0x10

    .line 167
    .line 168
    const/4 v10, 0x0

    .line 169
    const/4 v13, 0x0

    .line 170
    move-object/from16 v5, p0

    .line 171
    .line 172
    move-object/from16 v6, p1

    .line 173
    .line 174
    move v9, v1

    .line 175
    move-wide v11, v7

    .line 176
    move/from16 v7, p2

    .line 177
    .line 178
    move-object v8, v2

    .line 179
    invoke-virtual/range {v5 .. v17}, Lah5;->a(Lbi5;ZLi14;FLfq5;JFLc01;Lub2;II)V

    .line 180
    .line 181
    .line 182
    move-wide v7, v11

    .line 183
    move-wide v5, v7

    .line 184
    move-wide/from16 v7, v18

    .line 185
    .line 186
    goto :goto_5

    .line 187
    :cond_5
    invoke-virtual/range {p9 .. p9}, Lub2;->V()V

    .line 188
    .line 189
    .line 190
    move-wide/from16 v5, p4

    .line 191
    .line 192
    move-wide/from16 v7, p6

    .line 193
    .line 194
    move/from16 v9, p8

    .line 195
    .line 196
    :goto_5
    invoke-virtual/range {p9 .. p9}, Lub2;->t()Lkk5;

    .line 197
    .line 198
    .line 199
    move-result-object v11

    .line 200
    if-eqz v11, :cond_6

    .line 201
    .line 202
    new-instance v0, Ltg5;

    .line 203
    .line 204
    move-object/from16 v1, p0

    .line 205
    .line 206
    move-object/from16 v2, p1

    .line 207
    .line 208
    move/from16 v3, p2

    .line 209
    .line 210
    move/from16 v10, p10

    .line 211
    .line 212
    invoke-direct/range {v0 .. v10}, Ltg5;-><init>(Lah5;Lbi5;ZLi14;JJFI)V

    .line 213
    .line 214
    .line 215
    iput-object v0, v11, Lkk5;->d:Lua2;

    .line 216
    .line 217
    :cond_6
    return-void
.end method
