.class public abstract La00;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lol0;


# instance fields
.field public final a:Lpl0;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lpl0;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La00;->a:Lpl0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public a(Lam0;Lpl0;Lj34;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p4, Lsl0;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final b(Lam0;Lpl0;FLjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p4, Lsl0;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public abstract d(Lll0;Lsl0;)V
.end method

.method public abstract e()Ljava/util/LinkedHashMap;
.end method

.method public abstract f(Lsl0;Lkl0;Lp34;)V
.end method

.method public abstract g(Lp34;FLzj0;)Ljava/lang/Object;
.end method

.method public abstract h(Lh34;Lsl0;)V
.end method

.method public abstract i(Lam0;Lj34;Lsl0;)V
.end method
