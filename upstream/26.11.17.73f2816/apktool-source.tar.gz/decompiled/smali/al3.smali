.class public abstract Lal3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final a:Lyt1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ljf3;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1}, Ljf3;-><init>(B)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lyt1;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v1, v0, v2}, Lyt1;-><init>(Lfa2;B)V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lal3;->a:Lyt1;

    .line 14
    .line 15
    return-void
.end method
