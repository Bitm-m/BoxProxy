.class public final synthetic Lah2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Leh2;

.field public final synthetic k:F

.field public final synthetic l:Li14;

.field public final synthetic m:Lc01;

.field public final synthetic n:I


# direct methods
.method public synthetic constructor <init>(ZLeh2;FLi14;Lc01;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lah2;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Lah2;->j:Leh2;

    .line 7
    .line 8
    iput p3, p0, Lah2;->k:F

    .line 9
    .line 10
    iput-object p4, p0, Lah2;->l:Li14;

    .line 11
    .line 12
    iput-object p5, p0, Lah2;->m:Lc01;

    .line 13
    .line 14
    iput p6, p0, Lah2;->n:I

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, Lub2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lah2;->n:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lub3;->b0(I)I

    .line 14
    .line 15
    .line 16
    move-result v6

    .line 17
    iget-boolean v0, p0, Lah2;->i:Z

    .line 18
    .line 19
    iget-object v1, p0, Lah2;->j:Leh2;

    .line 20
    .line 21
    iget v2, p0, Lah2;->k:F

    .line 22
    .line 23
    iget-object v3, p0, Lah2;->l:Li14;

    .line 24
    .line 25
    iget-object v4, p0, Lah2;->m:Lc01;

    .line 26
    .line 27
    invoke-static/range {v0 .. v6}, Ldh2;->b(ZLeh2;FLi14;Lc01;Lub2;I)V

    .line 28
    .line 29
    .line 30
    sget-object p0, Lne7;->a:Lne7;

    .line 31
    .line 32
    return-object p0
.end method
