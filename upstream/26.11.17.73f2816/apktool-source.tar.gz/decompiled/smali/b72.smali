.class public interface abstract Lb72;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# direct methods
.method public static synthetic a(Lb72;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    check-cast p0, Le72;

    .line 3
    .line 4
    invoke-virtual {p0, v0}, Le72;->b(Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
