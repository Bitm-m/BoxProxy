.class public final Laj7;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lro1;


# instance fields
.field public volatile i:Lyk1;


# virtual methods
.method public final a()Lxk1;
    .locals 0

    .line 1
    iget-object p0, p0, Laj7;->i:Lyk1;

    .line 2
    .line 3
    return-object p0
.end method
