.class public final synthetic Lag7;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lag7;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget-byte p0, p0, Lag7;->i:B

    .line 2
    .line 3
    sget-object v0, Lne7;->a:Lne7;

    .line 4
    .line 5
    const-wide v1, 0xffffffffL

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    const/16 v3, 0x20

    .line 11
    .line 12
    packed-switch p0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast p1, Lkp7;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 21
    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lyn7;

    .line 24
    .line 25
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    return-object p1

    .line 29
    :pswitch_1
    check-cast p1, Lrn7;

    .line 30
    .line 31
    iget-object p0, p1, Lrn7;->a:Lkg;

    .line 32
    .line 33
    return-object p0

    .line 34
    :pswitch_2
    check-cast p1, Lrn7;

    .line 35
    .line 36
    iget-object p0, p1, Lrn7;->e:Lkg;

    .line 37
    .line 38
    return-object p0

    .line 39
    :pswitch_3
    check-cast p1, Lrn7;

    .line 40
    .line 41
    iget-object p0, p1, Lrn7;->c:Lkg;

    .line 42
    .line 43
    return-object p0

    .line 44
    :pswitch_4
    check-cast p1, Lrn7;

    .line 45
    .line 46
    iget-object p0, p1, Lrn7;->f:Lkg;

    .line 47
    .line 48
    return-object p0

    .line 49
    :pswitch_5
    check-cast p1, La15;

    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_6
    check-cast p1, Lf96;

    .line 53
    .line 54
    invoke-static {p1}, Ld96;->p(Lf96;)V

    .line 55
    .line 56
    .line 57
    return-object v0

    .line 58
    :pswitch_7
    check-cast p1, Lmk7;

    .line 59
    .line 60
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    return-object v0

    .line 64
    :pswitch_8
    check-cast p1, Lmk7;

    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    return-object v0

    .line 70
    :pswitch_9
    check-cast p1, Lei;

    .line 71
    .line 72
    iget p0, p1, Lei;->a:F

    .line 73
    .line 74
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    return-object p0

    .line 79
    :pswitch_a
    check-cast p1, Lhi;

    .line 80
    .line 81
    new-instance p0, Lvk5;

    .line 82
    .line 83
    iget v0, p1, Lhi;->a:F

    .line 84
    .line 85
    iget v1, p1, Lhi;->b:F

    .line 86
    .line 87
    iget v2, p1, Lhi;->c:F

    .line 88
    .line 89
    iget p1, p1, Lhi;->d:F

    .line 90
    .line 91
    invoke-direct {p0, v0, v1, v2, p1}, Lvk5;-><init>(FFFF)V

    .line 92
    .line 93
    .line 94
    return-object p0

    .line 95
    :pswitch_b
    check-cast p1, Lvk5;

    .line 96
    .line 97
    new-instance p0, Lhi;

    .line 98
    .line 99
    iget v0, p1, Lvk5;->a:F

    .line 100
    .line 101
    iget v1, p1, Lvk5;->b:F

    .line 102
    .line 103
    iget v2, p1, Lvk5;->c:F

    .line 104
    .line 105
    iget p1, p1, Lvk5;->d:F

    .line 106
    .line 107
    invoke-direct {p0, v0, v1, v2, p1}, Lhi;-><init>(FFFF)V

    .line 108
    .line 109
    .line 110
    return-object p0

    .line 111
    :pswitch_c
    check-cast p1, Lfi;

    .line 112
    .line 113
    iget p0, p1, Lfi;->a:F

    .line 114
    .line 115
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 116
    .line 117
    .line 118
    move-result p0

    .line 119
    const/4 v0, 0x0

    .line 120
    if-gez p0, :cond_0

    .line 121
    .line 122
    move p0, v0

    .line 123
    :cond_0
    iget p1, p1, Lfi;->b:F

    .line 124
    .line 125
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    if-ltz p1, :cond_1

    .line 130
    .line 131
    move v0, p1

    .line 132
    :cond_1
    int-to-long p0, p0

    .line 133
    shl-long/2addr p0, v3

    .line 134
    int-to-long v3, v0

    .line 135
    and-long/2addr v3, v1

    .line 136
    or-long/2addr p0, v3

    .line 137
    new-instance v0, Lg13;

    .line 138
    .line 139
    invoke-direct {v0, p0, p1}, Lg13;-><init>(J)V

    .line 140
    .line 141
    .line 142
    return-object v0

    .line 143
    :pswitch_d
    check-cast p1, Lg13;

    .line 144
    .line 145
    new-instance p0, Lfi;

    .line 146
    .line 147
    iget-wide v4, p1, Lg13;->a:J

    .line 148
    .line 149
    shr-long v6, v4, v3

    .line 150
    .line 151
    long-to-int p1, v6

    .line 152
    int-to-float p1, p1

    .line 153
    and-long/2addr v4, v1

    .line 154
    long-to-int v0, v4

    .line 155
    int-to-float v0, v0

    .line 156
    invoke-direct {p0, p1, v0}, Lfi;-><init>(FF)V

    .line 157
    .line 158
    .line 159
    return-object p0

    .line 160
    :pswitch_e
    check-cast p1, Lfi;

    .line 161
    .line 162
    iget p0, p1, Lfi;->a:F

    .line 163
    .line 164
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    iget p1, p1, Lfi;->b:F

    .line 169
    .line 170
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    int-to-long v4, p0

    .line 175
    shl-long/2addr v4, v3

    .line 176
    int-to-long p0, p1

    .line 177
    and-long/2addr p0, v1

    .line 178
    or-long/2addr v4, p0

    .line 179
    new-instance p0, Ly03;

    .line 180
    .line 181
    invoke-direct {p0, v4, v5}, Ly03;-><init>(J)V

    .line 182
    .line 183
    .line 184
    return-object p0

    .line 185
    :pswitch_f
    check-cast p1, Ly03;

    .line 186
    .line 187
    new-instance p0, Lfi;

    .line 188
    .line 189
    iget-wide v4, p1, Ly03;->a:J

    .line 190
    .line 191
    shr-long v6, v4, v3

    .line 192
    .line 193
    long-to-int p1, v6

    .line 194
    int-to-float p1, p1

    .line 195
    and-long/2addr v4, v1

    .line 196
    long-to-int v0, v4

    .line 197
    int-to-float v0, v0

    .line 198
    invoke-direct {p0, p1, v0}, Lfi;-><init>(FF)V

    .line 199
    .line 200
    .line 201
    return-object p0

    .line 202
    :pswitch_10
    check-cast p1, Lfi;

    .line 203
    .line 204
    iget p0, p1, Lfi;->a:F

    .line 205
    .line 206
    iget p1, p1, Lfi;->b:F

    .line 207
    .line 208
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 209
    .line 210
    .line 211
    move-result p0

    .line 212
    int-to-long v4, p0

    .line 213
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 214
    .line 215
    .line 216
    move-result p0

    .line 217
    int-to-long p0, p0

    .line 218
    shl-long/2addr v4, v3

    .line 219
    and-long/2addr p0, v1

    .line 220
    or-long/2addr v4, p0

    .line 221
    new-instance p0, Lfm4;

    .line 222
    .line 223
    invoke-direct {p0, v4, v5}, Lfm4;-><init>(J)V

    .line 224
    .line 225
    .line 226
    return-object p0

    .line 227
    :pswitch_11
    check-cast p1, Lfm4;

    .line 228
    .line 229
    new-instance p0, Lfi;

    .line 230
    .line 231
    iget-wide v4, p1, Lfm4;->a:J

    .line 232
    .line 233
    shr-long/2addr v4, v3

    .line 234
    long-to-int v0, v4

    .line 235
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 236
    .line 237
    .line 238
    move-result v0

    .line 239
    iget-wide v3, p1, Lfm4;->a:J

    .line 240
    .line 241
    and-long/2addr v3, v1

    .line 242
    long-to-int p1, v3

    .line 243
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 244
    .line 245
    .line 246
    move-result p1

    .line 247
    invoke-direct {p0, v0, p1}, Lfi;-><init>(FF)V

    .line 248
    .line 249
    .line 250
    return-object p0

    .line 251
    :pswitch_12
    check-cast p1, Lfi;

    .line 252
    .line 253
    iget p0, p1, Lfi;->a:F

    .line 254
    .line 255
    iget p1, p1, Lfi;->b:F

    .line 256
    .line 257
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 258
    .line 259
    .line 260
    move-result p0

    .line 261
    int-to-long v4, p0

    .line 262
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 263
    .line 264
    .line 265
    move-result p0

    .line 266
    int-to-long p0, p0

    .line 267
    shl-long/2addr v4, v3

    .line 268
    and-long/2addr p0, v1

    .line 269
    or-long/2addr v4, p0

    .line 270
    new-instance p0, Lwg6;

    .line 271
    .line 272
    invoke-direct {p0, v4, v5}, Lwg6;-><init>(J)V

    .line 273
    .line 274
    .line 275
    return-object p0

    .line 276
    :pswitch_13
    check-cast p1, Lwg6;

    .line 277
    .line 278
    new-instance p0, Lfi;

    .line 279
    .line 280
    iget-wide v4, p1, Lwg6;->a:J

    .line 281
    .line 282
    shr-long/2addr v4, v3

    .line 283
    long-to-int v0, v4

    .line 284
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 285
    .line 286
    .line 287
    move-result v0

    .line 288
    iget-wide v3, p1, Lwg6;->a:J

    .line 289
    .line 290
    and-long/2addr v3, v1

    .line 291
    long-to-int p1, v3

    .line 292
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 293
    .line 294
    .line 295
    move-result p1

    .line 296
    invoke-direct {p0, v0, p1}, Lfi;-><init>(FF)V

    .line 297
    .line 298
    .line 299
    return-object p0

    .line 300
    :pswitch_14
    check-cast p1, Lfi;

    .line 301
    .line 302
    iget p0, p1, Lfi;->a:F

    .line 303
    .line 304
    iget p1, p1, Lfi;->b:F

    .line 305
    .line 306
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 307
    .line 308
    .line 309
    move-result p0

    .line 310
    int-to-long v4, p0

    .line 311
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 312
    .line 313
    .line 314
    move-result p0

    .line 315
    int-to-long p0, p0

    .line 316
    shl-long/2addr v4, v3

    .line 317
    and-long/2addr p0, v1

    .line 318
    or-long/2addr v4, p0

    .line 319
    new-instance p0, Lxp1;

    .line 320
    .line 321
    invoke-direct {p0, v4, v5}, Lxp1;-><init>(J)V

    .line 322
    .line 323
    .line 324
    return-object p0

    .line 325
    :pswitch_15
    check-cast p1, Lxp1;

    .line 326
    .line 327
    new-instance p0, Lfi;

    .line 328
    .line 329
    iget-wide v4, p1, Lxp1;->a:J

    .line 330
    .line 331
    shr-long/2addr v4, v3

    .line 332
    long-to-int v0, v4

    .line 333
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 334
    .line 335
    .line 336
    move-result v0

    .line 337
    iget-wide v3, p1, Lxp1;->a:J

    .line 338
    .line 339
    and-long/2addr v3, v1

    .line 340
    long-to-int p1, v3

    .line 341
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 342
    .line 343
    .line 344
    move-result p1

    .line 345
    invoke-direct {p0, v0, p1}, Lfi;-><init>(FF)V

    .line 346
    .line 347
    .line 348
    return-object p0

    .line 349
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
