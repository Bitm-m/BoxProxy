.class public final Laj;
.super Landroid/text/SegmentFinder;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final synthetic a:Lnd6;


# direct methods
.method public constructor <init>(Lnd6;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laj;->a:Lnd6;

    .line 2
    .line 3
    invoke-direct {p0}, Landroid/text/SegmentFinder;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final nextEndBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Lnd6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lnd6;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final nextStartBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Lnd6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lnd6;->k(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final previousEndBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Lnd6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lnd6;->l(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final previousStartBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Lnd6;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lnd6;->c(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
