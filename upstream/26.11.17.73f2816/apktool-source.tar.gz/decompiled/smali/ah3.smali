.class public final Lah3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final synthetic a:Lah3;

.field public static final b:Lv21;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lah3;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lah3;->a:Lah3;

    .line 7
    .line 8
    new-instance v0, Lv21;

    .line 9
    .line 10
    const/16 v1, 0x1d

    .line 11
    .line 12
    invoke-direct {v0, v1}, Lv21;-><init>(B)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lah3;->b:Lv21;

    .line 16
    .line 17
    return-void
.end method
