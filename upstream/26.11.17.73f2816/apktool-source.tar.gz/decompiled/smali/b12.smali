.class public final Lb12;
.super Lua7;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public volatile a:Lua7;

.field public final synthetic b:Z

.field public final synthetic c:Lqi2;

.field public final synthetic d:Lbc7;

.field public final synthetic e:Lc12;


# direct methods
.method public constructor <init>(Lc12;ZZLqi2;Lbc7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb12;->e:Lc12;

    .line 5
    .line 6
    iput-boolean p2, p0, Lb12;->b:Z

    .line 7
    .line 8
    iput-object p4, p0, Lb12;->c:Lqi2;

    .line 9
    .line 10
    iput-object p5, p0, Lb12;->d:Lbc7;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final b(Lq63;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-boolean v0, p0, Lb12;->b:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, Lq63;->R()V

    .line 6
    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    return-object p0

    .line 10
    :cond_0
    iget-object v0, p0, Lb12;->a:Lua7;

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    iget-object v0, p0, Lb12;->c:Lqi2;

    .line 15
    .line 16
    iget-object v1, p0, Lb12;->e:Lc12;

    .line 17
    .line 18
    iget-object v2, p0, Lb12;->d:Lbc7;

    .line 19
    .line 20
    invoke-virtual {v0, v1, v2}, Lqi2;->c(Lva7;Lbc7;)Lua7;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object v0, p0, Lb12;->a:Lua7;

    .line 25
    .line 26
    :cond_1
    invoke-virtual {v0, p1}, Lua7;->b(Lq63;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0
.end method
