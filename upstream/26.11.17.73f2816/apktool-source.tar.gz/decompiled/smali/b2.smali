.class public final synthetic Lb2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 17
    iput-byte p5, p0, Lb2;->i:B

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lvs4;Ljava/lang/String;Lfa2;)V
    .locals 1

    .line 1
    const/16 v0, 0xc

    .line 2
    .line 3
    iput-byte v0, p0, Lb2;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lb2;->k:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p2, p0, Lb2;->j:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    .line 13
    .line 14
    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/ArrayList;Lzk5;Ljava/util/List;ILwb3;)V
    .locals 0

    .line 18
    const/4 p4, 0x7

    iput-byte p4, p0, Lb2;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p5, p0, Lb2;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb2;->i:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/16 v3, 0xb

    .line 7
    .line 8
    const/16 v4, 0x18

    .line 9
    .line 10
    const/4 v5, 0x3

    .line 11
    const/4 v6, 0x2

    .line 12
    const/16 v9, 0x20

    .line 13
    .line 14
    const/4 v11, 0x0

    .line 15
    const/4 v12, 0x1

    .line 16
    sget-object v13, Lne7;->a:Lne7;

    .line 17
    .line 18
    iget-object v14, v0, Lb2;->m:Ljava/lang/Object;

    .line 19
    .line 20
    iget-object v15, v0, Lb2;->l:Ljava/lang/Object;

    .line 21
    .line 22
    const-wide v16, 0xffffffffL

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    iget-object v7, v0, Lb2;->k:Ljava/lang/Object;

    .line 28
    .line 29
    iget-object v0, v0, Lb2;->j:Ljava/lang/Object;

    .line 30
    .line 31
    packed-switch v1, :pswitch_data_0

    .line 32
    .line 33
    .line 34
    check-cast v0, Lfa2;

    .line 35
    .line 36
    check-cast v7, Ly00;

    .line 37
    .line 38
    check-cast v15, Ls07;

    .line 39
    .line 40
    check-cast v14, Lp37;

    .line 41
    .line 42
    move-object/from16 v1, p1

    .line 43
    .line 44
    check-cast v1, Lbx6;

    .line 45
    .line 46
    invoke-interface {v0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    if-eqz v7, :cond_0

    .line 50
    .line 51
    invoke-virtual {v7}, Ly00;->invoke()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Ljava/lang/Boolean;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 58
    .line 59
    .line 60
    move-result v12

    .line 61
    :cond_0
    if-eqz v12, :cond_1

    .line 62
    .line 63
    invoke-interface {v1}, Lbx6;->close()V

    .line 64
    .line 65
    .line 66
    :cond_1
    invoke-virtual {v15, v14}, Ls07;->x(Lp37;)V

    .line 67
    .line 68
    .line 69
    return-object v13

    .line 70
    :pswitch_0
    check-cast v0, Lxl6;

    .line 71
    .line 72
    check-cast v7, Lsv0;

    .line 73
    .line 74
    check-cast v15, Lbi2;

    .line 75
    .line 76
    move-object/from16 v18, v14

    .line 77
    .line 78
    check-cast v18, Lwp4;

    .line 79
    .line 80
    move-object/from16 v1, p1

    .line 81
    .line 82
    check-cast v1, Lla3;

    .line 83
    .line 84
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    iget-object v2, v1, Lla3;->i:Llj0;

    .line 88
    .line 89
    invoke-interface {v2}, Lhs1;->b()J

    .line 90
    .line 91
    .line 92
    move-result-wide v3

    .line 93
    shr-long/2addr v3, v9

    .line 94
    long-to-int v3, v3

    .line 95
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 96
    .line 97
    .line 98
    move-result v3

    .line 99
    invoke-interface {v2}, Lhs1;->b()J

    .line 100
    .line 101
    .line 102
    move-result-wide v19

    .line 103
    move v8, v9

    .line 104
    const/16 v29, 0x0

    .line 105
    .line 106
    and-long v9, v19, v16

    .line 107
    .line 108
    long-to-int v4, v9

    .line 109
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 110
    .line 111
    .line 112
    move-result v4

    .line 113
    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    const/high16 v4, 0x45000000    # 2048.0f

    .line 118
    .line 119
    cmpg-float v3, v3, v4

    .line 120
    .line 121
    if-gtz v3, :cond_3

    .line 122
    .line 123
    if-eqz v7, :cond_2

    .line 124
    .line 125
    iget-wide v2, v7, Lsv0;->a:J

    .line 126
    .line 127
    const/16 v27, 0x0

    .line 128
    .line 129
    const/16 v28, 0x7e

    .line 130
    .line 131
    const-wide/16 v22, 0x0

    .line 132
    .line 133
    const-wide/16 v24, 0x0

    .line 134
    .line 135
    const/16 v26, 0x0

    .line 136
    .line 137
    move-object/from16 v19, v1

    .line 138
    .line 139
    move-wide/from16 v20, v2

    .line 140
    .line 141
    invoke-static/range {v19 .. v28}, Lhs1;->n0(Lhs1;JJJFII)V

    .line 142
    .line 143
    .line 144
    :cond_2
    invoke-virtual {v1}, Lla3;->c()V

    .line 145
    .line 146
    .line 147
    invoke-static {v1, v0, v12, v12}, Ltl6;->c(Lla3;Lxl6;ZZ)V

    .line 148
    .line 149
    .line 150
    goto/16 :goto_3

    .line 151
    .line 152
    :cond_3
    new-instance v3, Lgq3;

    .line 153
    .line 154
    invoke-direct {v3, v1, v12}, Lgq3;-><init>(Lla3;B)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v1}, Lla3;->b()J

    .line 158
    .line 159
    .line 160
    move-result-wide v9

    .line 161
    invoke-static {v9, v10}, Lfj;->S(J)J

    .line 162
    .line 163
    .line 164
    move-result-wide v9

    .line 165
    invoke-virtual {v1, v15, v9, v10, v3}, Lla3;->c0(Lbi2;JLqa2;)V

    .line 166
    .line 167
    .line 168
    invoke-interface {v2}, Lhs1;->b()J

    .line 169
    .line 170
    .line 171
    move-result-wide v3

    .line 172
    shr-long/2addr v3, v8

    .line 173
    long-to-int v3, v3

    .line 174
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 175
    .line 176
    .line 177
    move-result v3

    .line 178
    invoke-interface {v2}, Lhs1;->b()J

    .line 179
    .line 180
    .line 181
    move-result-wide v9

    .line 182
    and-long v9, v9, v16

    .line 183
    .line 184
    long-to-int v4, v9

    .line 185
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 186
    .line 187
    .line 188
    move-result v24

    .line 189
    iget-object v4, v2, Llj0;->j:Lh47;

    .line 190
    .line 191
    invoke-virtual {v4}, Lh47;->t()Ljj0;

    .line 192
    .line 193
    .line 194
    move-result-object v16

    .line 195
    invoke-interface {v2}, Lhs1;->b()J

    .line 196
    .line 197
    .line 198
    move-result-wide v9

    .line 199
    invoke-virtual {v0, v11, v9, v10}, Lxl6;->d(IJ)F

    .line 200
    .line 201
    .line 202
    move-result v4

    .line 203
    invoke-virtual {v0, v12, v9, v10}, Lxl6;->d(IJ)F

    .line 204
    .line 205
    .line 206
    move-result v9

    .line 207
    invoke-static {v4, v9}, Ljava/lang/Math;->max(FF)F

    .line 208
    .line 209
    .line 210
    move-result v4

    .line 211
    invoke-interface {v2}, Lhs1;->b()J

    .line 212
    .line 213
    .line 214
    move-result-wide v9

    .line 215
    invoke-virtual {v0, v6, v9, v10}, Lxl6;->d(IJ)F

    .line 216
    .line 217
    .line 218
    move-result v6

    .line 219
    invoke-virtual {v0, v5, v9, v10}, Lxl6;->d(IJ)F

    .line 220
    .line 221
    .line 222
    move-result v5

    .line 223
    invoke-static {v6, v5}, Ljava/lang/Math;->max(FF)F

    .line 224
    .line 225
    .line 226
    move-result v5

    .line 227
    add-float v6, v4, v5

    .line 228
    .line 229
    cmpg-float v6, v24, v6

    .line 230
    .line 231
    if-gtz v6, :cond_4

    .line 232
    .line 233
    const/16 v26, 0x1

    .line 234
    .line 235
    const/16 v27, 0x0

    .line 236
    .line 237
    const/16 v23, 0x0

    .line 238
    .line 239
    const/16 v25, 0x1

    .line 240
    .line 241
    move-object/from16 v22, v0

    .line 242
    .line 243
    move-object/from16 v20, v1

    .line 244
    .line 245
    move/from16 v17, v3

    .line 246
    .line 247
    move-object/from16 v19, v7

    .line 248
    .line 249
    move-object/from16 v21, v15

    .line 250
    .line 251
    invoke-static/range {v16 .. v27}, Ltl6;->b(Ljj0;FLwp4;Lsv0;Lla3;Lbi2;Lxl6;FFZZZ)V

    .line 252
    .line 253
    .line 254
    goto/16 :goto_3

    .line 255
    .line 256
    :cond_4
    move-object/from16 v22, v0

    .line 257
    .line 258
    move-object/from16 v20, v1

    .line 259
    .line 260
    move/from16 v17, v3

    .line 261
    .line 262
    move-object/from16 v19, v7

    .line 263
    .line 264
    move-object/from16 v21, v15

    .line 265
    .line 266
    move/from16 v0, v24

    .line 267
    .line 268
    float-to-double v6, v4

    .line 269
    invoke-static {v6, v7}, Ljava/lang/Math;->ceil(D)D

    .line 270
    .line 271
    .line 272
    move-result-wide v6

    .line 273
    double-to-float v1, v6

    .line 274
    sub-float v3, v0, v5

    .line 275
    .line 276
    float-to-double v6, v3

    .line 277
    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    .line 278
    .line 279
    .line 280
    move-result-wide v6

    .line 281
    double-to-float v3, v6

    .line 282
    cmpl-float v4, v4, v29

    .line 283
    .line 284
    if-lez v4, :cond_5

    .line 285
    .line 286
    const/16 v26, 0x0

    .line 287
    .line 288
    const/16 v27, 0x1

    .line 289
    .line 290
    const/16 v23, 0x0

    .line 291
    .line 292
    const/16 v25, 0x1

    .line 293
    .line 294
    move/from16 v24, v1

    .line 295
    .line 296
    invoke-static/range {v16 .. v27}, Ltl6;->b(Ljj0;FLwp4;Lsv0;Lla3;Lbi2;Lxl6;FFZZZ)V

    .line 297
    .line 298
    .line 299
    :goto_0
    move-object/from16 v7, v19

    .line 300
    .line 301
    move-object/from16 v15, v21

    .line 302
    .line 303
    move-object/from16 v1, v22

    .line 304
    .line 305
    goto :goto_1

    .line 306
    :cond_5
    move/from16 v24, v1

    .line 307
    .line 308
    goto :goto_0

    .line 309
    :goto_1
    invoke-interface {v2}, Lhs1;->b()J

    .line 310
    .line 311
    .line 312
    move-result-wide v9

    .line 313
    shr-long/2addr v9, v8

    .line 314
    long-to-int v4, v9

    .line 315
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 316
    .line 317
    .line 318
    move-result v26

    .line 319
    iget-object v2, v2, Llj0;->j:Lh47;

    .line 320
    .line 321
    invoke-virtual {v2}, Lh47;->F()J

    .line 322
    .line 323
    .line 324
    move-result-wide v8

    .line 325
    invoke-virtual {v2}, Lh47;->t()Ljj0;

    .line 326
    .line 327
    .line 328
    move-result-object v4

    .line 329
    invoke-interface {v4}, Ljj0;->n()V

    .line 330
    .line 331
    .line 332
    :try_start_0
    iget-object v4, v2, Lh47;->j:Ljava/lang/Object;

    .line 333
    .line 334
    move-object/from16 v23, v4

    .line 335
    .line 336
    check-cast v23, Lmj7;

    .line 337
    .line 338
    move/from16 v25, v24

    .line 339
    .line 340
    const/16 v24, 0x0

    .line 341
    .line 342
    const/16 v28, 0x1

    .line 343
    .line 344
    move/from16 v27, v3

    .line 345
    .line 346
    invoke-virtual/range {v23 .. v28}, Lmj7;->o(FFFFI)V

    .line 347
    .line 348
    .line 349
    if-eqz v7, :cond_6

    .line 350
    .line 351
    iget-wide v10, v7, Lsv0;->a:J

    .line 352
    .line 353
    const/16 v27, 0x0

    .line 354
    .line 355
    const/16 v28, 0x7e

    .line 356
    .line 357
    const-wide/16 v22, 0x0

    .line 358
    .line 359
    const-wide/16 v24, 0x0

    .line 360
    .line 361
    const/16 v26, 0x0

    .line 362
    .line 363
    move-object/from16 v19, v20

    .line 364
    .line 365
    move-wide/from16 v20, v10

    .line 366
    .line 367
    invoke-static/range {v19 .. v28}, Lhs1;->n0(Lhs1;JJJFII)V

    .line 368
    .line 369
    .line 370
    move-object/from16 v4, v19

    .line 371
    .line 372
    goto :goto_2

    .line 373
    :cond_6
    move-object/from16 v4, v20

    .line 374
    .line 375
    :goto_2
    invoke-static {v4, v15}, Lfj;->w(Lhs1;Lbi2;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 376
    .line 377
    .line 378
    invoke-static {v2, v8, v9}, Lxk6;->z(Lh47;J)V

    .line 379
    .line 380
    .line 381
    cmpl-float v2, v5, v29

    .line 382
    .line 383
    if-lez v2, :cond_7

    .line 384
    .line 385
    const/16 v26, 0x1

    .line 386
    .line 387
    const/16 v27, 0x1

    .line 388
    .line 389
    const/16 v25, 0x0

    .line 390
    .line 391
    move/from16 v24, v0

    .line 392
    .line 393
    move-object/from16 v22, v1

    .line 394
    .line 395
    move/from16 v23, v3

    .line 396
    .line 397
    move-object/from16 v20, v4

    .line 398
    .line 399
    move-object/from16 v19, v7

    .line 400
    .line 401
    move-object/from16 v21, v15

    .line 402
    .line 403
    invoke-static/range {v16 .. v27}, Ltl6;->b(Ljj0;FLwp4;Lsv0;Lla3;Lbi2;Lxl6;FFZZZ)V

    .line 404
    .line 405
    .line 406
    :cond_7
    :goto_3
    return-object v13

    .line 407
    :catchall_0
    move-exception v0

    .line 408
    invoke-static {v2, v8, v9}, Lxk6;->z(Lh47;J)V

    .line 409
    .line 410
    .line 411
    throw v0

    .line 412
    :pswitch_1
    check-cast v0, Lyk5;

    .line 413
    .line 414
    check-cast v7, Luv4;

    .line 415
    .line 416
    check-cast v15, Low4;

    .line 417
    .line 418
    check-cast v14, La7;

    .line 419
    .line 420
    move-object/from16 v1, p1

    .line 421
    .line 422
    check-cast v1, Lbi;

    .line 423
    .line 424
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 425
    .line 426
    .line 427
    iget-object v2, v1, Lbi;->e:Ldy4;

    .line 428
    .line 429
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v2

    .line 433
    check-cast v2, Ljava/lang/Number;

    .line 434
    .line 435
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 436
    .line 437
    .line 438
    move-result v2

    .line 439
    iget v3, v0, Lyk5;->i:F

    .line 440
    .line 441
    sub-float/2addr v2, v3

    .line 442
    invoke-static {v2}, Lv23;->u(F)Z

    .line 443
    .line 444
    .line 445
    move-result v3

    .line 446
    if-nez v3, :cond_9

    .line 447
    .line 448
    iget-object v3, v7, Ltj4;->d:Ljava/lang/Object;

    .line 449
    .line 450
    check-cast v3, Lpw4;

    .line 451
    .line 452
    invoke-virtual {v3, v15, v2, v12}, Lpw4;->a(Low4;FI)F

    .line 453
    .line 454
    .line 455
    move-result v3

    .line 456
    sub-float v3, v2, v3

    .line 457
    .line 458
    invoke-static {v3}, Lv23;->u(F)Z

    .line 459
    .line 460
    .line 461
    move-result v3

    .line 462
    if-nez v3, :cond_8

    .line 463
    .line 464
    invoke-virtual {v1}, Lbi;->a()V

    .line 465
    .line 466
    .line 467
    goto :goto_4

    .line 468
    :cond_8
    iget v3, v0, Lyk5;->i:F

    .line 469
    .line 470
    add-float/2addr v3, v2

    .line 471
    iput v3, v0, Lyk5;->i:F

    .line 472
    .line 473
    :cond_9
    iget v0, v0, Lyk5;->i:F

    .line 474
    .line 475
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 476
    .line 477
    .line 478
    move-result-object v0

    .line 479
    invoke-virtual {v14, v0}, La7;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 480
    .line 481
    .line 482
    move-result-object v0

    .line 483
    check-cast v0, Ljava/lang/Boolean;

    .line 484
    .line 485
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 486
    .line 487
    .line 488
    move-result v0

    .line 489
    if-eqz v0, :cond_a

    .line 490
    .line 491
    invoke-virtual {v1}, Lbi;->a()V

    .line 492
    .line 493
    .line 494
    :cond_a
    :goto_4
    return-object v13

    .line 495
    :pswitch_2
    check-cast v7, Ljava/lang/String;

    .line 496
    .line 497
    move-object/from16 v16, v0

    .line 498
    .line 499
    check-cast v16, Lvs4;

    .line 500
    .line 501
    move-object/from16 v17, v15

    .line 502
    .line 503
    check-cast v17, Ljava/lang/String;

    .line 504
    .line 505
    move-object/from16 v18, v14

    .line 506
    .line 507
    check-cast v18, Lfa2;

    .line 508
    .line 509
    move-object/from16 v0, p1

    .line 510
    .line 511
    check-cast v0, Lce3;

    .line 512
    .line 513
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 514
    .line 515
    .line 516
    if-eqz v7, :cond_b

    .line 517
    .line 518
    new-instance v14, Lll;

    .line 519
    .line 520
    const/16 v19, 0x11

    .line 521
    .line 522
    move-object v15, v7

    .line 523
    invoke-direct/range {v14 .. v19}, Lll;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 524
    .line 525
    .line 526
    move-object/from16 v1, v16

    .line 527
    .line 528
    move-object/from16 v15, v17

    .line 529
    .line 530
    new-instance v2, Lc01;

    .line 531
    .line 532
    const v5, -0x3d240a0b

    .line 533
    .line 534
    .line 535
    invoke-direct {v2, v5, v12, v14}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 536
    .line 537
    .line 538
    const-string v5, "status"

    .line 539
    .line 540
    invoke-static {v0, v5, v2, v6}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 541
    .line 542
    .line 543
    goto :goto_5

    .line 544
    :cond_b
    move-object/from16 v1, v16

    .line 545
    .line 546
    move-object/from16 v15, v17

    .line 547
    .line 548
    :goto_5
    iget-object v2, v1, Lvs4;->b:Ljava/util/List;

    .line 549
    .line 550
    new-instance v5, Lpg4;

    .line 551
    .line 552
    invoke-direct {v5, v4}, Lpg4;-><init>(B)V

    .line 553
    .line 554
    .line 555
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 556
    .line 557
    .line 558
    move-result v4

    .line 559
    new-instance v6, Lc0;

    .line 560
    .line 561
    const/16 v7, 0x13

    .line 562
    .line 563
    invoke-direct {v6, v5, v2, v7}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 564
    .line 565
    .line 566
    new-instance v5, Ld0;

    .line 567
    .line 568
    invoke-direct {v5, v2, v3}, Ld0;-><init>(Ljava/util/List;B)V

    .line 569
    .line 570
    .line 571
    new-instance v3, Lrs4;

    .line 572
    .line 573
    invoke-direct {v3, v2, v1, v15, v12}, Lrs4;-><init>(Ljava/util/List;Lvs4;Ljava/lang/Object;B)V

    .line 574
    .line 575
    .line 576
    new-instance v1, Lc01;

    .line 577
    .line 578
    const v2, 0x2fd4df92

    .line 579
    .line 580
    .line 581
    invoke-direct {v1, v2, v12, v3}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 582
    .line 583
    .line 584
    invoke-virtual {v0, v4, v6, v5, v1}, Lce3;->P(ILqa2;Lqa2;Lc01;)V

    .line 585
    .line 586
    .line 587
    return-object v13

    .line 588
    :pswitch_3
    check-cast v0, Ljava/util/List;

    .line 589
    .line 590
    check-cast v7, Lqa2;

    .line 591
    .line 592
    check-cast v15, Lw44;

    .line 593
    .line 594
    check-cast v14, Lw44;

    .line 595
    .line 596
    move-object/from16 v1, p1

    .line 597
    .line 598
    check-cast v1, Lsf4;

    .line 599
    .line 600
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 601
    .line 602
    .line 603
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 604
    .line 605
    invoke-interface {v15, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 606
    .line 607
    .line 608
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 609
    .line 610
    .line 611
    move-result v0

    .line 612
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 613
    .line 614
    .line 615
    move-result-object v0

    .line 616
    invoke-interface {v14, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 617
    .line 618
    .line 619
    invoke-interface {v7, v1}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    return-object v13

    .line 623
    :pswitch_4
    check-cast v0, Lyk5;

    .line 624
    .line 625
    check-cast v7, Ll24;

    .line 626
    .line 627
    check-cast v15, Lj56;

    .line 628
    .line 629
    check-cast v14, La7;

    .line 630
    .line 631
    move-object/from16 v1, p1

    .line 632
    .line 633
    check-cast v1, Lbi;

    .line 634
    .line 635
    iget-object v2, v1, Lbi;->e:Ldy4;

    .line 636
    .line 637
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 638
    .line 639
    .line 640
    move-result-object v2

    .line 641
    check-cast v2, Ljava/lang/Number;

    .line 642
    .line 643
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 644
    .line 645
    .line 646
    move-result v2

    .line 647
    iget v3, v0, Lyk5;->i:F

    .line 648
    .line 649
    sub-float/2addr v2, v3

    .line 650
    invoke-static {v2}, Lad3;->y(F)Z

    .line 651
    .line 652
    .line 653
    move-result v3

    .line 654
    if-nez v3, :cond_d

    .line 655
    .line 656
    invoke-virtual {v7, v15, v2}, Ll24;->d(Lj56;F)F

    .line 657
    .line 658
    .line 659
    move-result v3

    .line 660
    sub-float v3, v2, v3

    .line 661
    .line 662
    invoke-static {v3}, Lad3;->y(F)Z

    .line 663
    .line 664
    .line 665
    move-result v3

    .line 666
    if-nez v3, :cond_c

    .line 667
    .line 668
    invoke-virtual {v1}, Lbi;->a()V

    .line 669
    .line 670
    .line 671
    goto :goto_6

    .line 672
    :cond_c
    iget v3, v0, Lyk5;->i:F

    .line 673
    .line 674
    add-float/2addr v3, v2

    .line 675
    iput v3, v0, Lyk5;->i:F

    .line 676
    .line 677
    :cond_d
    iget v0, v0, Lyk5;->i:F

    .line 678
    .line 679
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    invoke-virtual {v14, v0}, La7;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 684
    .line 685
    .line 686
    move-result-object v0

    .line 687
    check-cast v0, Ljava/lang/Boolean;

    .line 688
    .line 689
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 690
    .line 691
    .line 692
    move-result v0

    .line 693
    if-eqz v0, :cond_e

    .line 694
    .line 695
    invoke-virtual {v1}, Lbi;->a()V

    .line 696
    .line 697
    .line 698
    :cond_e
    :goto_6
    return-object v13

    .line 699
    :pswitch_5
    check-cast v0, Lmz3;

    .line 700
    .line 701
    check-cast v7, Ljj;

    .line 702
    .line 703
    check-cast v15, Ll87;

    .line 704
    .line 705
    check-cast v14, Lw44;

    .line 706
    .line 707
    move-object/from16 v1, p1

    .line 708
    .line 709
    check-cast v1, Ljava/lang/Float;

    .line 710
    .line 711
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 712
    .line 713
    .line 714
    move-result v2

    .line 715
    if-eqz v0, :cond_f

    .line 716
    .line 717
    if-eqz v7, :cond_f

    .line 718
    .line 719
    iget-object v3, v0, Lmz3;->b:Ljava/util/LinkedHashMap;

    .line 720
    .line 721
    invoke-interface {v3, v7, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 722
    .line 723
    .line 724
    iget-object v1, v0, Lmz3;->c:Ljj;

    .line 725
    .line 726
    if-ne v7, v1, :cond_10

    .line 727
    .line 728
    iget-object v0, v0, Lmz3;->d:Ll87;

    .line 729
    .line 730
    if-eqz v0, :cond_10

    .line 731
    .line 732
    iget-object v0, v0, Ll87;->c:Lzx4;

    .line 733
    .line 734
    invoke-virtual {v0, v2}, Lzx4;->h(F)V

    .line 735
    .line 736
    .line 737
    goto :goto_7

    .line 738
    :cond_f
    invoke-interface {v14}, Lmm6;->getValue()Ljava/lang/Object;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    check-cast v0, Ljava/lang/Boolean;

    .line 743
    .line 744
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 745
    .line 746
    .line 747
    move-result v0

    .line 748
    if-eqz v0, :cond_10

    .line 749
    .line 750
    iget-object v0, v15, Ll87;->c:Lzx4;

    .line 751
    .line 752
    invoke-virtual {v0, v2}, Lzx4;->h(F)V

    .line 753
    .line 754
    .line 755
    :cond_10
    :goto_7
    return-object v13

    .line 756
    :pswitch_6
    check-cast v0, Lod3;

    .line 757
    .line 758
    check-cast v7, Lzc3;

    .line 759
    .line 760
    check-cast v15, Ltp6;

    .line 761
    .line 762
    check-cast v14, Ld55;

    .line 763
    .line 764
    move-object/from16 v1, p1

    .line 765
    .line 766
    check-cast v1, Luo1;

    .line 767
    .line 768
    new-instance v1, Lxn1;

    .line 769
    .line 770
    invoke-direct {v1, v7, v15, v14}, Lxn1;-><init>(Lzc3;Ltp6;Ld55;)V

    .line 771
    .line 772
    .line 773
    iput-object v1, v0, Lod3;->c:Lxn1;

    .line 774
    .line 775
    new-instance v1, Lc7;

    .line 776
    .line 777
    invoke-direct {v1, v0, v3}, Lc7;-><init>(Ljava/lang/Object;B)V

    .line 778
    .line 779
    .line 780
    return-object v1

    .line 781
    :pswitch_7
    move v8, v9

    .line 782
    check-cast v0, Ljava/util/ArrayList;

    .line 783
    .line 784
    check-cast v7, Lzk5;

    .line 785
    .line 786
    check-cast v15, Ljava/util/List;

    .line 787
    .line 788
    check-cast v14, Lwb3;

    .line 789
    .line 790
    move-object/from16 v1, p1

    .line 791
    .line 792
    check-cast v1, Lc55;

    .line 793
    .line 794
    iget-object v2, v1, Lc55;->e:Lsp6;

    .line 795
    .line 796
    if-eqz v2, :cond_11

    .line 797
    .line 798
    invoke-interface {v2}, Lsp6;->d()I

    .line 799
    .line 800
    .line 801
    move-result v2

    .line 802
    goto :goto_8

    .line 803
    :cond_11
    move v2, v11

    .line 804
    :goto_8
    move v3, v11

    .line 805
    :goto_9
    if-ge v11, v2, :cond_15

    .line 806
    .line 807
    iget-object v4, v14, Lwb3;->r:Ldq4;

    .line 808
    .line 809
    iget-object v5, v1, Lc55;->e:Lsp6;

    .line 810
    .line 811
    const-wide/16 v9, 0x0

    .line 812
    .line 813
    sget-object v6, Ldq4;->i:Ldq4;

    .line 814
    .line 815
    if-ne v4, v6, :cond_13

    .line 816
    .line 817
    if-eqz v5, :cond_12

    .line 818
    .line 819
    invoke-interface {v5, v11}, Lsp6;->c(I)J

    .line 820
    .line 821
    .line 822
    move-result-wide v9

    .line 823
    :cond_12
    and-long v9, v9, v16

    .line 824
    .line 825
    :goto_a
    long-to-int v4, v9

    .line 826
    goto :goto_b

    .line 827
    :cond_13
    if-eqz v5, :cond_14

    .line 828
    .line 829
    invoke-interface {v5, v11}, Lsp6;->c(I)J

    .line 830
    .line 831
    .line 832
    move-result-wide v9

    .line 833
    :cond_14
    shr-long/2addr v9, v8

    .line 834
    goto :goto_a

    .line 835
    :goto_b
    add-int/2addr v3, v4

    .line 836
    add-int/lit8 v11, v11, 0x1

    .line 837
    .line 838
    goto :goto_9

    .line 839
    :cond_15
    if-eqz v0, :cond_16

    .line 840
    .line 841
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 842
    .line 843
    .line 844
    move-result-object v1

    .line 845
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 846
    .line 847
    .line 848
    :cond_16
    iget v0, v7, Lzk5;->i:I

    .line 849
    .line 850
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 851
    .line 852
    .line 853
    move-result v1

    .line 854
    if-eq v0, v1, :cond_17

    .line 855
    .line 856
    iget v0, v7, Lzk5;->i:I

    .line 857
    .line 858
    add-int/2addr v0, v12

    .line 859
    iput v0, v7, Lzk5;->i:I

    .line 860
    .line 861
    :cond_17
    return-object v13

    .line 862
    :pswitch_8
    const/16 v29, 0x0

    .line 863
    .line 864
    check-cast v0, Lw44;

    .line 865
    .line 866
    check-cast v7, Lly2;

    .line 867
    .line 868
    check-cast v15, Lyk5;

    .line 869
    .line 870
    check-cast v14, Lrf1;

    .line 871
    .line 872
    move-object/from16 v1, p1

    .line 873
    .line 874
    check-cast v1, Ljava/lang/Long;

    .line 875
    .line 876
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 877
    .line 878
    .line 879
    move-result-wide v1

    .line 880
    invoke-interface {v0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 881
    .line 882
    .line 883
    move-result-object v0

    .line 884
    check-cast v0, Lmm6;

    .line 885
    .line 886
    if-eqz v0, :cond_18

    .line 887
    .line 888
    invoke-interface {v0}, Lmm6;->getValue()Ljava/lang/Object;

    .line 889
    .line 890
    .line 891
    move-result-object v0

    .line 892
    check-cast v0, Ljava/lang/Number;

    .line 893
    .line 894
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 895
    .line 896
    .line 897
    move-result-wide v3

    .line 898
    goto :goto_c

    .line 899
    :cond_18
    move-wide v3, v1

    .line 900
    :goto_c
    iget-wide v5, v7, Lly2;->c:J

    .line 901
    .line 902
    iget-object v0, v7, Lly2;->a:Ly44;

    .line 903
    .line 904
    const-wide/high16 v8, -0x8000000000000000L

    .line 905
    .line 906
    cmp-long v5, v5, v8

    .line 907
    .line 908
    if-eqz v5, :cond_19

    .line 909
    .line 910
    iget v5, v15, Lyk5;->i:F

    .line 911
    .line 912
    invoke-interface {v14}, Lrf1;->e()Lhf1;

    .line 913
    .line 914
    .line 915
    move-result-object v6

    .line 916
    invoke-static {v6}, Lis6;->m(Lhf1;)F

    .line 917
    .line 918
    .line 919
    move-result v6

    .line 920
    cmpg-float v5, v5, v6

    .line 921
    .line 922
    if-eqz v5, :cond_1b

    .line 923
    .line 924
    :cond_19
    iput-wide v1, v7, Lly2;->c:J

    .line 925
    .line 926
    iget-object v1, v0, Ly44;->i:[Ljava/lang/Object;

    .line 927
    .line 928
    iget v2, v0, Ly44;->k:I

    .line 929
    .line 930
    move v5, v11

    .line 931
    :goto_d
    if-ge v5, v2, :cond_1a

    .line 932
    .line 933
    aget-object v6, v1, v5

    .line 934
    .line 935
    check-cast v6, Liy2;

    .line 936
    .line 937
    iput-boolean v12, v6, Liy2;->n:Z

    .line 938
    .line 939
    add-int/lit8 v5, v5, 0x1

    .line 940
    .line 941
    goto :goto_d

    .line 942
    :cond_1a
    invoke-interface {v14}, Lrf1;->e()Lhf1;

    .line 943
    .line 944
    .line 945
    move-result-object v1

    .line 946
    invoke-static {v1}, Lis6;->m(Lhf1;)F

    .line 947
    .line 948
    .line 949
    move-result v1

    .line 950
    iput v1, v15, Lyk5;->i:F

    .line 951
    .line 952
    :cond_1b
    iget v1, v15, Lyk5;->i:F

    .line 953
    .line 954
    cmpg-float v2, v1, v29

    .line 955
    .line 956
    if-nez v2, :cond_1c

    .line 957
    .line 958
    iget-object v1, v0, Ly44;->i:[Ljava/lang/Object;

    .line 959
    .line 960
    iget v0, v0, Ly44;->k:I

    .line 961
    .line 962
    :goto_e
    if-ge v11, v0, :cond_21

    .line 963
    .line 964
    aget-object v2, v1, v11

    .line 965
    .line 966
    check-cast v2, Liy2;

    .line 967
    .line 968
    iget-object v3, v2, Liy2;->l:Ljv6;

    .line 969
    .line 970
    iget-object v3, v3, Ljv6;->c:Ljava/lang/Object;

    .line 971
    .line 972
    iget-object v4, v2, Liy2;->k:Ldy4;

    .line 973
    .line 974
    invoke-virtual {v4, v3}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 975
    .line 976
    .line 977
    iput-boolean v12, v2, Liy2;->n:Z

    .line 978
    .line 979
    add-int/lit8 v11, v11, 0x1

    .line 980
    .line 981
    goto :goto_e

    .line 982
    :cond_1c
    iget-wide v5, v7, Lly2;->c:J

    .line 983
    .line 984
    sub-long/2addr v3, v5

    .line 985
    long-to-float v2, v3

    .line 986
    div-float/2addr v2, v1

    .line 987
    float-to-long v1, v2

    .line 988
    iget-object v3, v0, Ly44;->i:[Ljava/lang/Object;

    .line 989
    .line 990
    iget v0, v0, Ly44;->k:I

    .line 991
    .line 992
    move v4, v11

    .line 993
    move v5, v12

    .line 994
    :goto_f
    if-ge v4, v0, :cond_20

    .line 995
    .line 996
    aget-object v6, v3, v4

    .line 997
    .line 998
    check-cast v6, Liy2;

    .line 999
    .line 1000
    iget-boolean v8, v6, Liy2;->m:Z

    .line 1001
    .line 1002
    if-nez v8, :cond_1e

    .line 1003
    .line 1004
    iget-object v8, v6, Liy2;->p:Lly2;

    .line 1005
    .line 1006
    iget-object v8, v8, Lly2;->b:Ldy4;

    .line 1007
    .line 1008
    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1009
    .line 1010
    invoke-virtual {v8, v9}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1011
    .line 1012
    .line 1013
    iget-boolean v8, v6, Liy2;->n:Z

    .line 1014
    .line 1015
    if-eqz v8, :cond_1d

    .line 1016
    .line 1017
    iput-boolean v11, v6, Liy2;->n:Z

    .line 1018
    .line 1019
    iput-wide v1, v6, Liy2;->o:J

    .line 1020
    .line 1021
    :cond_1d
    iget-wide v8, v6, Liy2;->o:J

    .line 1022
    .line 1023
    sub-long v8, v1, v8

    .line 1024
    .line 1025
    iget-object v10, v6, Liy2;->l:Ljv6;

    .line 1026
    .line 1027
    invoke-virtual {v10, v8, v9}, Ljv6;->b(J)Ljava/lang/Object;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v10

    .line 1031
    iget-object v14, v6, Liy2;->k:Ldy4;

    .line 1032
    .line 1033
    invoke-virtual {v14, v10}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1034
    .line 1035
    .line 1036
    iget-object v10, v6, Liy2;->l:Ljv6;

    .line 1037
    .line 1038
    invoke-interface {v10, v8, v9}, Lxh;->g(J)Z

    .line 1039
    .line 1040
    .line 1041
    move-result v8

    .line 1042
    iput-boolean v8, v6, Liy2;->m:Z

    .line 1043
    .line 1044
    :cond_1e
    if-nez v8, :cond_1f

    .line 1045
    .line 1046
    move v5, v11

    .line 1047
    :cond_1f
    add-int/lit8 v4, v4, 0x1

    .line 1048
    .line 1049
    goto :goto_f

    .line 1050
    :cond_20
    xor-int/2addr v5, v12

    .line 1051
    iget-object v0, v7, Lly2;->d:Ldy4;

    .line 1052
    .line 1053
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v1

    .line 1057
    invoke-virtual {v0, v1}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1058
    .line 1059
    .line 1060
    :cond_21
    return-object v13

    .line 1061
    :pswitch_9
    const/16 v29, 0x0

    .line 1062
    .line 1063
    check-cast v0, Lfa2;

    .line 1064
    .line 1065
    check-cast v7, Lt12;

    .line 1066
    .line 1067
    check-cast v15, Lt97;

    .line 1068
    .line 1069
    check-cast v14, Lfa2;

    .line 1070
    .line 1071
    move-object/from16 v1, p1

    .line 1072
    .line 1073
    check-cast v1, Lei2;

    .line 1074
    .line 1075
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1076
    .line 1077
    .line 1078
    if-eqz v0, :cond_22

    .line 1079
    .line 1080
    invoke-interface {v0}, Lfa2;->invoke()Ljava/lang/Object;

    .line 1081
    .line 1082
    .line 1083
    move-result-object v0

    .line 1084
    check-cast v0, Ljava/lang/Number;

    .line 1085
    .line 1086
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1087
    .line 1088
    .line 1089
    move-result v0

    .line 1090
    :goto_10
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1091
    .line 1092
    .line 1093
    move-result-object v2

    .line 1094
    goto :goto_11

    .line 1095
    :cond_22
    if-eqz v7, :cond_23

    .line 1096
    .line 1097
    iget-object v0, v7, Lt12;->a:Ll87;

    .line 1098
    .line 1099
    if-eqz v0, :cond_23

    .line 1100
    .line 1101
    iget-object v2, v0, Ll87;->b:Lzx4;

    .line 1102
    .line 1103
    invoke-virtual {v2}, Lzx4;->g()F

    .line 1104
    .line 1105
    .line 1106
    move-result v2

    .line 1107
    iget-object v0, v0, Ll87;->c:Lzx4;

    .line 1108
    .line 1109
    invoke-virtual {v0}, Lzx4;->g()F

    .line 1110
    .line 1111
    .line 1112
    move-result v0

    .line 1113
    add-float/2addr v0, v2

    .line 1114
    goto :goto_10

    .line 1115
    :cond_23
    :goto_11
    const/high16 v0, 0x3f800000    # 1.0f

    .line 1116
    .line 1117
    if-eqz v2, :cond_24

    .line 1118
    .line 1119
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 1120
    .line 1121
    .line 1122
    move-result v2

    .line 1123
    neg-float v2, v2

    .line 1124
    const/high16 v3, 0x42400000    # 48.0f

    .line 1125
    .line 1126
    invoke-interface {v1}, Lul1;->a()F

    .line 1127
    .line 1128
    .line 1129
    move-result v4

    .line 1130
    mul-float/2addr v4, v3

    .line 1131
    div-float/2addr v2, v4

    .line 1132
    move/from16 v3, v29

    .line 1133
    .line 1134
    invoke-static {v2, v3, v0}, Lhb3;->B(FFF)F

    .line 1135
    .line 1136
    .line 1137
    move-result v2

    .line 1138
    goto :goto_12

    .line 1139
    :cond_24
    move/from16 v3, v29

    .line 1140
    .line 1141
    iget-object v2, v15, Lt97;->p:Ldy4;

    .line 1142
    .line 1143
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 1144
    .line 1145
    .line 1146
    move-result-object v2

    .line 1147
    check-cast v2, Ljava/lang/Number;

    .line 1148
    .line 1149
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 1150
    .line 1151
    .line 1152
    move-result v2

    .line 1153
    :goto_12
    invoke-interface {v14}, Lfa2;->invoke()Ljava/lang/Object;

    .line 1154
    .line 1155
    .line 1156
    move-result-object v4

    .line 1157
    check-cast v4, Ljava/lang/Number;

    .line 1158
    .line 1159
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 1160
    .line 1161
    .line 1162
    move-result v4

    .line 1163
    invoke-static {v4, v3, v0}, Lhb3;->B(FFF)F

    .line 1164
    .line 1165
    .line 1166
    move-result v0

    .line 1167
    mul-float/2addr v0, v2

    .line 1168
    invoke-interface {v1, v0}, Lei2;->v(F)V

    .line 1169
    .line 1170
    .line 1171
    return-object v13

    .line 1172
    :pswitch_a
    check-cast v0, Lcf3;

    .line 1173
    .line 1174
    check-cast v7, Li17;

    .line 1175
    .line 1176
    check-cast v15, Lc17;

    .line 1177
    .line 1178
    check-cast v14, Lcx2;

    .line 1179
    .line 1180
    move-object/from16 v1, p1

    .line 1181
    .line 1182
    check-cast v1, Luo1;

    .line 1183
    .line 1184
    invoke-virtual {v0}, Lcf3;->b()Z

    .line 1185
    .line 1186
    .line 1187
    move-result v1

    .line 1188
    if-eqz v1, :cond_25

    .line 1189
    .line 1190
    iget-object v1, v0, Lcf3;->d:Llz2;

    .line 1191
    .line 1192
    iget-object v2, v0, Lcf3;->v:Lkd1;

    .line 1193
    .line 1194
    iget-object v3, v0, Lcf3;->w:Lkd1;

    .line 1195
    .line 1196
    new-instance v5, Lbl5;

    .line 1197
    .line 1198
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 1199
    .line 1200
    .line 1201
    new-instance v6, Lnz3;

    .line 1202
    .line 1203
    invoke-direct {v6, v1, v2, v5, v4}, Lnz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1204
    .line 1205
    .line 1206
    iget-object v1, v7, Li17;->a:Lz15;

    .line 1207
    .line 1208
    invoke-interface {v1, v15, v14, v6, v3}, Lz15;->b(Lc17;Lcx2;Lnz3;Lkd1;)V

    .line 1209
    .line 1210
    .line 1211
    new-instance v2, Ll17;

    .line 1212
    .line 1213
    invoke-direct {v2, v7, v1}, Ll17;-><init>(Li17;Lz15;)V

    .line 1214
    .line 1215
    .line 1216
    iget-object v1, v7, Li17;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 1217
    .line 1218
    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 1219
    .line 1220
    .line 1221
    iput-object v2, v5, Lbl5;->i:Ljava/lang/Object;

    .line 1222
    .line 1223
    iput-object v2, v0, Lcf3;->e:Ll17;

    .line 1224
    .line 1225
    :cond_25
    new-instance v0, Ltd;

    .line 1226
    .line 1227
    const/16 v1, 0x8

    .line 1228
    .line 1229
    invoke-direct {v0, v1}, Ltd;-><init>(B)V

    .line 1230
    .line 1231
    .line 1232
    return-object v0

    .line 1233
    :pswitch_b
    check-cast v0, Laf1;

    .line 1234
    .line 1235
    check-cast v7, Laf1;

    .line 1236
    .line 1237
    check-cast v15, Laf1;

    .line 1238
    .line 1239
    check-cast v14, Lw44;

    .line 1240
    .line 1241
    move-object/from16 v1, p1

    .line 1242
    .line 1243
    check-cast v1, Ljava/lang/String;

    .line 1244
    .line 1245
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1246
    .line 1247
    .line 1248
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 1249
    .line 1250
    .line 1251
    move-result v2

    .line 1252
    const v3, -0x353274c5    # -6735261.5f

    .line 1253
    .line 1254
    .line 1255
    if-eq v2, v3, :cond_27

    .line 1256
    .line 1257
    const v0, 0x589b15e

    .line 1258
    .line 1259
    .line 1260
    if-eq v2, v0, :cond_26

    .line 1261
    .line 1262
    const v0, 0x68795c9

    .line 1263
    .line 1264
    .line 1265
    if-ne v2, v0, :cond_28

    .line 1266
    .line 1267
    const-string v0, "smart"

    .line 1268
    .line 1269
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1270
    .line 1271
    .line 1272
    move-result v0

    .line 1273
    if-eqz v0, :cond_28

    .line 1274
    .line 1275
    move-object v0, v15

    .line 1276
    goto :goto_13

    .line 1277
    :cond_26
    const-string v0, "alpha"

    .line 1278
    .line 1279
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1280
    .line 1281
    .line 1282
    move-result v0

    .line 1283
    if-eqz v0, :cond_28

    .line 1284
    .line 1285
    move-object v0, v7

    .line 1286
    goto :goto_13

    .line 1287
    :cond_27
    const-string v2, "stable"

    .line 1288
    .line 1289
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1290
    .line 1291
    .line 1292
    move-result v1

    .line 1293
    if-nez v1, :cond_29

    .line 1294
    .line 1295
    :cond_28
    invoke-interface {v14}, Lmm6;->getValue()Ljava/lang/Object;

    .line 1296
    .line 1297
    .line 1298
    move-result-object v0

    .line 1299
    check-cast v0, Laf1;

    .line 1300
    .line 1301
    :cond_29
    :goto_13
    invoke-interface {v14, v0}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 1302
    .line 1303
    .line 1304
    return-object v13

    .line 1305
    :pswitch_c
    check-cast v0, Ljava/util/List;

    .line 1306
    .line 1307
    check-cast v7, Lhp3;

    .line 1308
    .line 1309
    check-cast v15, Lta0;

    .line 1310
    .line 1311
    check-cast v14, Lmv;

    .line 1312
    .line 1313
    move-object/from16 v1, p1

    .line 1314
    .line 1315
    check-cast v1, Ljava/lang/Boolean;

    .line 1316
    .line 1317
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1318
    .line 1319
    .line 1320
    move-result v1

    .line 1321
    iget-object v2, v7, Lhp3;->c:Lay4;

    .line 1322
    .line 1323
    invoke-virtual {v2}, Lay4;->g()I

    .line 1324
    .line 1325
    .line 1326
    move-result v2

    .line 1327
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1328
    .line 1329
    .line 1330
    invoke-static {v2, v0}, Lmv0;->O0(ILjava/util/List;)Ljava/lang/Object;

    .line 1331
    .line 1332
    .line 1333
    move-result-object v0

    .line 1334
    check-cast v0, Lg40;

    .line 1335
    .line 1336
    if-nez v0, :cond_2a

    .line 1337
    .line 1338
    sget-object v0, Lg40;->m:Lg40;

    .line 1339
    .line 1340
    :cond_2a
    invoke-static {v1}, Lwj;->S(Z)Ljava/util/List;

    .line 1341
    .line 1342
    .line 1343
    move-result-object v2

    .line 1344
    invoke-static {v2, v0}, Lwj;->F(Ljava/util/List;Lg40;)I

    .line 1345
    .line 1346
    .line 1347
    move-result v0

    .line 1348
    if-eqz v1, :cond_2b

    .line 1349
    .line 1350
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1351
    .line 1352
    .line 1353
    move-result-object v0

    .line 1354
    iget-object v2, v15, Lta0;->i:Ldy4;

    .line 1355
    .line 1356
    invoke-virtual {v2, v0}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1357
    .line 1358
    .line 1359
    goto :goto_14

    .line 1360
    :cond_2b
    invoke-virtual {v7, v0}, Lhp3;->b(I)V

    .line 1361
    .line 1362
    .line 1363
    :goto_14
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1364
    .line 1365
    .line 1366
    new-instance v0, Las;

    .line 1367
    .line 1368
    const/16 v2, 0xc

    .line 1369
    .line 1370
    invoke-direct {v0, v2, v1}, Las;-><init>(BZ)V

    .line 1371
    .line 1372
    .line 1373
    invoke-virtual {v14, v0}, Lmv;->c(Lqa2;)V

    .line 1374
    .line 1375
    .line 1376
    return-object v13

    .line 1377
    :pswitch_d
    check-cast v0, Lng;

    .line 1378
    .line 1379
    check-cast v7, Ldi;

    .line 1380
    .line 1381
    check-cast v15, Lqa2;

    .line 1382
    .line 1383
    check-cast v14, Lxk5;

    .line 1384
    .line 1385
    move-object/from16 v1, p1

    .line 1386
    .line 1387
    check-cast v1, Lbi;

    .line 1388
    .line 1389
    iget-object v2, v0, Lng;->c:Ldi;

    .line 1390
    .line 1391
    invoke-static {v1, v2}, Lis6;->z(Lbi;Ldi;)V

    .line 1392
    .line 1393
    .line 1394
    iget-object v2, v1, Lbi;->e:Ldy4;

    .line 1395
    .line 1396
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v3

    .line 1400
    invoke-virtual {v0, v3}, Lng;->c(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1401
    .line 1402
    .line 1403
    move-result-object v3

    .line 1404
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 1405
    .line 1406
    .line 1407
    move-result-object v2

    .line 1408
    invoke-static {v3, v2}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1409
    .line 1410
    .line 1411
    move-result v2

    .line 1412
    if-nez v2, :cond_2d

    .line 1413
    .line 1414
    iget-object v2, v0, Lng;->c:Ldi;

    .line 1415
    .line 1416
    iget-object v2, v2, Ldi;->j:Ldy4;

    .line 1417
    .line 1418
    invoke-virtual {v2, v3}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1419
    .line 1420
    .line 1421
    iget-object v2, v7, Ldi;->j:Ldy4;

    .line 1422
    .line 1423
    invoke-virtual {v2, v3}, Ldy4;->setValue(Ljava/lang/Object;)V

    .line 1424
    .line 1425
    .line 1426
    if-eqz v15, :cond_2c

    .line 1427
    .line 1428
    invoke-interface {v15, v0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1429
    .line 1430
    .line 1431
    :cond_2c
    invoke-virtual {v1}, Lbi;->a()V

    .line 1432
    .line 1433
    .line 1434
    iput-boolean v12, v14, Lxk5;->i:Z

    .line 1435
    .line 1436
    goto :goto_15

    .line 1437
    :cond_2d
    if-eqz v15, :cond_2e

    .line 1438
    .line 1439
    invoke-interface {v15, v0}, Lqa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1440
    .line 1441
    .line 1442
    :cond_2e
    :goto_15
    return-object v13

    .line 1443
    :pswitch_e
    check-cast v0, Lsf;

    .line 1444
    .line 1445
    check-cast v7, Ljava/lang/String;

    .line 1446
    .line 1447
    check-cast v15, Lua2;

    .line 1448
    .line 1449
    check-cast v14, Landroid/content/Context;

    .line 1450
    .line 1451
    move-object/from16 v1, p1

    .line 1452
    .line 1453
    check-cast v1, Lce3;

    .line 1454
    .line 1455
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1456
    .line 1457
    .line 1458
    new-instance v3, Lc2;

    .line 1459
    .line 1460
    invoke-direct {v3, v0, v7, v11}, Lc2;-><init>(Lsf;Ljava/lang/String;B)V

    .line 1461
    .line 1462
    .line 1463
    new-instance v0, Lc01;

    .line 1464
    .line 1465
    const v4, 0x290b7044

    .line 1466
    .line 1467
    .line 1468
    invoke-direct {v0, v4, v12, v3}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 1469
    .line 1470
    .line 1471
    invoke-static {v1, v2, v0, v5}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 1472
    .line 1473
    .line 1474
    new-instance v0, Ld2;

    .line 1475
    .line 1476
    invoke-direct {v0, v15, v14, v11}, Ld2;-><init>(Lua2;Landroid/content/Context;B)V

    .line 1477
    .line 1478
    .line 1479
    new-instance v3, Lc01;

    .line 1480
    .line 1481
    const v4, 0xa6505fb

    .line 1482
    .line 1483
    .line 1484
    invoke-direct {v3, v4, v12, v0}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 1485
    .line 1486
    .line 1487
    invoke-static {v1, v2, v3, v5}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 1488
    .line 1489
    .line 1490
    return-object v13

    .line 1491
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
