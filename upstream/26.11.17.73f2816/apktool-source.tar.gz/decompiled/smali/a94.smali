.class public final synthetic La94;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:Ll11;

.field public final synthetic j:Z

.field public final synthetic k:Lfa2;

.field public final synthetic l:Lfa2;

.field public final synthetic m:Z

.field public final synthetic n:Lfa2;

.field public final synthetic o:Lfa2;

.field public final synthetic p:Lg94;


# direct methods
.method public synthetic constructor <init>(Ll11;ZLfa2;Lfa2;ZLfa2;Lfa2;Lg94;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La94;->i:Ll11;

    .line 5
    .line 6
    iput-boolean p2, p0, La94;->j:Z

    .line 7
    .line 8
    iput-object p3, p0, La94;->k:Lfa2;

    .line 9
    .line 10
    iput-object p4, p0, La94;->l:Lfa2;

    .line 11
    .line 12
    iput-boolean p5, p0, La94;->m:Z

    .line 13
    .line 14
    iput-object p6, p0, La94;->n:Lfa2;

    .line 15
    .line 16
    iput-object p7, p0, La94;->o:Lfa2;

    .line 17
    .line 18
    iput-object p8, p0, La94;->p:Lg94;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, La94;->i:Ll11;

    .line 2
    .line 3
    iget-boolean v1, v0, Lx84;->f:Z

    .line 4
    .line 5
    iget-boolean v2, p0, La94;->j:Z

    .line 6
    .line 7
    if-eq v1, v2, :cond_0

    .line 8
    .line 9
    iput-boolean v2, v0, Lx84;->f:Z

    .line 10
    .line 11
    iget-object v1, v0, Lx84;->g:Lt84;

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    iget-object v1, v1, Lt84;->e:Lf94;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    invoke-virtual {v1}, Lf94;->b()V

    .line 20
    .line 21
    .line 22
    :cond_0
    iget-object v1, p0, La94;->k:Lfa2;

    .line 23
    .line 24
    iput-object v1, v0, Ll11;->i:Lfa2;

    .line 25
    .line 26
    iget-boolean v1, p0, La94;->m:Z

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lx84;->j(Z)V

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, La94;->n:Lfa2;

    .line 32
    .line 33
    iput-object v1, v0, Ll11;->j:Lfa2;

    .line 34
    .line 35
    iget-object v1, p0, La94;->o:Lfa2;

    .line 36
    .line 37
    iput-object v1, v0, Ll11;->k:Lfa2;

    .line 38
    .line 39
    iget-object p0, p0, La94;->p:Lg94;

    .line 40
    .line 41
    iget-object v1, p0, Lg94;->c:Ldy4;

    .line 42
    .line 43
    invoke-virtual {v1}, Ldy4;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    check-cast v1, Ld94;

    .line 48
    .line 49
    iget-object v2, p0, Lg94;->b:Ldy4;

    .line 50
    .line 51
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    check-cast v2, Ljava/util/List;

    .line 56
    .line 57
    iget-object p0, p0, Lg94;->d:Ldy4;

    .line 58
    .line 59
    invoke-virtual {p0}, Ldy4;->getValue()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    check-cast p0, Ljava/util/List;

    .line 64
    .line 65
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    iput-object v1, v0, Lx84;->a:Ld94;

    .line 75
    .line 76
    iput-object v2, v0, Lx84;->b:Ljava/util/List;

    .line 77
    .line 78
    iput-object p0, v0, Lx84;->c:Ljava/util/List;

    .line 79
    .line 80
    iget-object p0, v0, Lx84;->g:Lt84;

    .line 81
    .line 82
    if-eqz p0, :cond_1

    .line 83
    .line 84
    iget-object p0, p0, Lt84;->e:Lf94;

    .line 85
    .line 86
    if-eqz p0, :cond_1

    .line 87
    .line 88
    invoke-virtual {p0, v0}, Lf94;->d(Lx84;)V

    .line 89
    .line 90
    .line 91
    :cond_1
    sget-object p0, Lne7;->a:Lne7;

    .line 92
    .line 93
    return-object p0
.end method
