.class public final synthetic Lan;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Z

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lev;Lfa2;ZZ)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lan;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lan;->l:Ljava/lang/Object;

    .line 8
    .line 9
    iput-boolean p3, p0, Lan;->j:Z

    .line 10
    .line 11
    iput-object p2, p0, Lan;->m:Ljava/lang/Object;

    .line 12
    .line 13
    iput-boolean p4, p0, Lan;->k:Z

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;ZZB)V
    .locals 0

    .line 16
    iput-byte p5, p0, Lan;->i:B

    iput-object p1, p0, Lan;->l:Ljava/lang/Object;

    iput-object p2, p0, Lan;->m:Ljava/lang/Object;

    iput-boolean p3, p0, Lan;->j:Z

    iput-boolean p4, p0, Lan;->k:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;ZZLqa2;I)V
    .locals 0

    .line 17
    const/4 p5, 0x5

    iput-byte p5, p0, Lan;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lan;->l:Ljava/lang/Object;

    iput-boolean p2, p0, Lan;->j:Z

    iput-boolean p3, p0, Lan;->k:Z

    iput-object p4, p0, Lan;->m:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ZLqa2;ZLrs6;I)V
    .locals 0

    .line 18
    const/4 p5, 0x6

    iput-byte p5, p0, Lan;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lan;->j:Z

    iput-object p2, p0, Lan;->l:Ljava/lang/Object;

    iput-boolean p3, p0, Lan;->k:Z

    iput-object p4, p0, Lan;->m:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ZZLhv;Lc01;)V
    .locals 1

    .line 19
    const/4 v0, 0x3

    iput-byte v0, p0, Lan;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lan;->j:Z

    iput-boolean p2, p0, Lan;->k:Z

    iput-object p3, p0, Lan;->l:Ljava/lang/Object;

    iput-object p4, p0, Lan;->m:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ZZLi14;Lc01;I)V
    .locals 0

    .line 20
    const/4 p5, 0x4

    iput-byte p5, p0, Lan;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lan;->j:Z

    iput-boolean p2, p0, Lan;->k:Z

    iput-object p3, p0, Lan;->l:Ljava/lang/Object;

    iput-object p4, p0, Lan;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 72

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lan;->i:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-boolean v3, v0, Lan;->k:Z

    .line 7
    .line 8
    iget-boolean v4, v0, Lan;->j:Z

    .line 9
    .line 10
    sget-object v5, Li21;->a:Ls9;

    .line 11
    .line 12
    const/4 v6, 0x2

    .line 13
    const/4 v7, 0x0

    .line 14
    sget-object v8, Lne7;->a:Lne7;

    .line 15
    .line 16
    const/4 v9, 0x1

    .line 17
    iget-object v10, v0, Lan;->m:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v11, v0, Lan;->l:Ljava/lang/Object;

    .line 20
    .line 21
    packed-switch v1, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    move-object v13, v11

    .line 25
    check-cast v13, Lqa2;

    .line 26
    .line 27
    move-object v15, v10

    .line 28
    check-cast v15, Lrs6;

    .line 29
    .line 30
    move-object/from16 v16, p1

    .line 31
    .line 32
    check-cast v16, Lub2;

    .line 33
    .line 34
    move-object/from16 v1, p2

    .line 35
    .line 36
    check-cast v1, Ljava/lang/Integer;

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    invoke-static {v9}, Lub3;->b0(I)I

    .line 42
    .line 43
    .line 44
    move-result v17

    .line 45
    iget-boolean v12, v0, Lan;->j:Z

    .line 46
    .line 47
    iget-boolean v14, v0, Lan;->k:Z

    .line 48
    .line 49
    invoke-static/range {v12 .. v17}, Lat6;->d(ZLqa2;ZLrs6;Lub2;I)V

    .line 50
    .line 51
    .line 52
    return-object v8

    .line 53
    :pswitch_0
    check-cast v11, Ljava/lang/String;

    .line 54
    .line 55
    move-object v3, v10

    .line 56
    check-cast v3, Lqa2;

    .line 57
    .line 58
    move-object/from16 v4, p1

    .line 59
    .line 60
    check-cast v4, Lub2;

    .line 61
    .line 62
    move-object/from16 v1, p2

    .line 63
    .line 64
    check-cast v1, Ljava/lang/Integer;

    .line 65
    .line 66
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    invoke-static {v9}, Lub3;->b0(I)I

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    iget-boolean v1, v0, Lan;->j:Z

    .line 74
    .line 75
    iget-boolean v2, v0, Lan;->k:Z

    .line 76
    .line 77
    move-object v0, v11

    .line 78
    invoke-static/range {v0 .. v5}, Lgb;->G(Ljava/lang/String;ZZLqa2;Lub2;I)V

    .line 79
    .line 80
    .line 81
    return-object v8

    .line 82
    :pswitch_1
    move-object v14, v11

    .line 83
    check-cast v14, Li14;

    .line 84
    .line 85
    move-object v15, v10

    .line 86
    check-cast v15, Lc01;

    .line 87
    .line 88
    move-object/from16 v16, p1

    .line 89
    .line 90
    check-cast v16, Lub2;

    .line 91
    .line 92
    move-object/from16 v1, p2

    .line 93
    .line 94
    check-cast v1, Ljava/lang/Integer;

    .line 95
    .line 96
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    const/16 v1, 0xc01

    .line 100
    .line 101
    invoke-static {v1}, Lub3;->b0(I)I

    .line 102
    .line 103
    .line 104
    move-result v17

    .line 105
    iget-boolean v12, v0, Lan;->j:Z

    .line 106
    .line 107
    iget-boolean v13, v0, Lan;->k:Z

    .line 108
    .line 109
    invoke-static/range {v12 .. v17}, Lgb;->o(ZZLi14;Lc01;Lub2;I)V

    .line 110
    .line 111
    .line 112
    return-object v8

    .line 113
    :pswitch_2
    check-cast v11, Lhv;

    .line 114
    .line 115
    check-cast v10, Lc01;

    .line 116
    .line 117
    move-object/from16 v0, p1

    .line 118
    .line 119
    check-cast v0, Lub2;

    .line 120
    .line 121
    move-object/from16 v1, p2

    .line 122
    .line 123
    check-cast v1, Ljava/lang/Integer;

    .line 124
    .line 125
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    and-int/lit8 v5, v1, 0x3

    .line 130
    .line 131
    if-eq v5, v6, :cond_0

    .line 132
    .line 133
    move v7, v9

    .line 134
    :cond_0
    and-int/2addr v1, v9

    .line 135
    invoke-virtual {v0, v1, v7}, Lub2;->S(IZ)Z

    .line 136
    .line 137
    .line 138
    move-result v1

    .line 139
    if-eqz v1, :cond_4

    .line 140
    .line 141
    sget-object v1, Lfx0;->a:Lyt1;

    .line 142
    .line 143
    invoke-virtual {v0, v1}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    move-object v12, v1

    .line 148
    check-cast v12, Lex0;

    .line 149
    .line 150
    if-eqz v4, :cond_2

    .line 151
    .line 152
    invoke-virtual {v12}, Lex0;->t()J

    .line 153
    .line 154
    .line 155
    move-result-wide v33

    .line 156
    if-eqz v3, :cond_1

    .line 157
    .line 158
    invoke-virtual {v12}, Lex0;->v()J

    .line 159
    .line 160
    .line 161
    move-result-wide v5

    .line 162
    :goto_0
    move-wide/from16 v47, v5

    .line 163
    .line 164
    goto :goto_1

    .line 165
    :cond_1
    invoke-virtual {v12}, Lex0;->s()J

    .line 166
    .line 167
    .line 168
    move-result-wide v5

    .line 169
    goto :goto_0

    .line 170
    :goto_1
    invoke-virtual {v12}, Lex0;->i()J

    .line 171
    .line 172
    .line 173
    move-result-wide v49

    .line 174
    invoke-virtual {v12}, Lex0;->u()J

    .line 175
    .line 176
    .line 177
    move-result-wide v25

    .line 178
    invoke-virtual {v12}, Lex0;->u()J

    .line 179
    .line 180
    .line 181
    move-result-wide v29

    .line 182
    invoke-virtual {v12}, Lex0;->k()J

    .line 183
    .line 184
    .line 185
    move-result-wide v27

    .line 186
    invoke-virtual {v12}, Lex0;->k()J

    .line 187
    .line 188
    .line 189
    move-result-wide v31

    .line 190
    const v69, -0x47800001

    .line 191
    .line 192
    .line 193
    const v70, 0x1ffcfd

    .line 194
    .line 195
    .line 196
    const-wide/16 v13, 0x0

    .line 197
    .line 198
    const-wide/16 v15, 0x0

    .line 199
    .line 200
    const-wide/16 v17, 0x0

    .line 201
    .line 202
    const-wide/16 v19, 0x0

    .line 203
    .line 204
    const-wide/16 v21, 0x0

    .line 205
    .line 206
    const-wide/16 v23, 0x0

    .line 207
    .line 208
    const-wide/16 v35, 0x0

    .line 209
    .line 210
    const-wide/16 v39, 0x0

    .line 211
    .line 212
    const-wide/16 v41, 0x0

    .line 213
    .line 214
    const-wide/16 v43, 0x0

    .line 215
    .line 216
    const-wide/16 v45, 0x0

    .line 217
    .line 218
    const-wide/16 v51, 0x0

    .line 219
    .line 220
    const-wide/16 v53, 0x0

    .line 221
    .line 222
    const-wide/16 v55, 0x0

    .line 223
    .line 224
    const-wide/16 v57, 0x0

    .line 225
    .line 226
    const-wide/16 v59, 0x0

    .line 227
    .line 228
    const-wide/16 v61, 0x0

    .line 229
    .line 230
    const-wide/16 v63, 0x0

    .line 231
    .line 232
    const-wide/16 v65, 0x0

    .line 233
    .line 234
    const-wide/16 v67, 0x0

    .line 235
    .line 236
    move-wide/from16 v37, v33

    .line 237
    .line 238
    invoke-static/range {v12 .. v70}, Lex0;->a(Lex0;JJJJJJJJJJJJJJJJJJJJJJJJJJJJII)Lex0;

    .line 239
    .line 240
    .line 241
    move-result-object v12

    .line 242
    :cond_2
    move-object v13, v12

    .line 243
    invoke-static {v13, v4, v3}, Lsy3;->a(Lex0;ZZ)Lqy3;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    if-eqz v3, :cond_3

    .line 248
    .line 249
    iget-boolean v3, v11, Lhv;->A:Z

    .line 250
    .line 251
    if-eqz v3, :cond_3

    .line 252
    .line 253
    sget-wide v3, Lsv0;->b:J

    .line 254
    .line 255
    const-wide v5, 0xff121212L

    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    invoke-static {v5, v6}, Lrm;->f(J)J

    .line 261
    .line 262
    .line 263
    move-result-wide v42

    .line 264
    const-wide v5, 0xff1e1e1eL

    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    invoke-static {v5, v6}, Lrm;->f(J)J

    .line 270
    .line 271
    .line 272
    move-result-wide v48

    .line 273
    const-wide v5, 0xff272727L

    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    invoke-static {v5, v6}, Lrm;->f(J)J

    .line 279
    .line 280
    .line 281
    move-result-wide v54

    .line 282
    const-wide v5, 0xff313131L

    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    invoke-static {v5, v6}, Lrm;->f(J)J

    .line 288
    .line 289
    .line 290
    move-result-wide v58

    .line 291
    sget-wide v5, Lsv0;->d:J

    .line 292
    .line 293
    const v7, 0x3df5c28f    # 0.12f

    .line 294
    .line 295
    .line 296
    invoke-static {v5, v6, v7}, Lsv0;->b(JF)J

    .line 297
    .line 298
    .line 299
    move-result-wide v62

    .line 300
    invoke-static {v5, v6, v7}, Lsv0;->b(JF)J

    .line 301
    .line 302
    .line 303
    move-result-wide v64

    .line 304
    const v7, 0x3f3851ec    # 0.72f

    .line 305
    .line 306
    .line 307
    invoke-static {v3, v4, v7}, Lsv0;->b(JF)J

    .line 308
    .line 309
    .line 310
    move-result-wide v66

    .line 311
    const v7, 0x3e23d70a    # 0.16f

    .line 312
    .line 313
    .line 314
    invoke-static {v5, v6, v7}, Lsv0;->b(JF)J

    .line 315
    .line 316
    .line 317
    move-result-wide v68

    .line 318
    const v70, -0x40000001    # -1.9999999f

    .line 319
    .line 320
    .line 321
    const v71, 0xc56f5

    .line 322
    .line 323
    .line 324
    const-wide/16 v14, 0x0

    .line 325
    .line 326
    const-wide/16 v16, 0x0

    .line 327
    .line 328
    const-wide/16 v18, 0x0

    .line 329
    .line 330
    const-wide/16 v20, 0x0

    .line 331
    .line 332
    const-wide/16 v22, 0x0

    .line 333
    .line 334
    const-wide/16 v24, 0x0

    .line 335
    .line 336
    const-wide/16 v26, 0x0

    .line 337
    .line 338
    const-wide/16 v28, 0x0

    .line 339
    .line 340
    const-wide/16 v30, 0x0

    .line 341
    .line 342
    const-wide/16 v32, 0x0

    .line 343
    .line 344
    const-wide/16 v36, 0x0

    .line 345
    .line 346
    const-wide/16 v40, 0x0

    .line 347
    .line 348
    const-wide/16 v44, 0x0

    .line 349
    .line 350
    const-wide/16 v46, 0x0

    .line 351
    .line 352
    const-wide/16 v50, 0x0

    .line 353
    .line 354
    const-wide/16 v52, 0x0

    .line 355
    .line 356
    const-wide/16 v56, 0x0

    .line 357
    .line 358
    const-wide/16 v60, 0x0

    .line 359
    .line 360
    move-wide/from16 v38, v3

    .line 361
    .line 362
    move-wide/from16 v34, v3

    .line 363
    .line 364
    invoke-static/range {v13 .. v71}, Lex0;->a(Lex0;JJJJJJJJJJJJJJJJJJJJJJJJJJJJII)Lex0;

    .line 365
    .line 366
    .line 367
    move-result-object v13

    .line 368
    :cond_3
    new-instance v3, Lp0;

    .line 369
    .line 370
    const/16 v4, 0x1b

    .line 371
    .line 372
    invoke-direct {v3, v1, v11, v10, v4}, Lp0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 373
    .line 374
    .line 375
    const v1, 0x1a17dd87

    .line 376
    .line 377
    .line 378
    invoke-static {v1, v3, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 379
    .line 380
    .line 381
    move-result-object v1

    .line 382
    const/16 v3, 0x180

    .line 383
    .line 384
    invoke-static {v13, v2, v1, v0, v3}, Lad3;->e(Lex0;Lm37;Lc01;Lub2;I)V

    .line 385
    .line 386
    .line 387
    goto :goto_2

    .line 388
    :cond_4
    invoke-virtual {v0}, Lub2;->V()V

    .line 389
    .line 390
    .line 391
    :goto_2
    return-object v8

    .line 392
    :pswitch_3
    check-cast v11, Lqa2;

    .line 393
    .line 394
    check-cast v10, Luo2;

    .line 395
    .line 396
    move-object/from16 v0, p1

    .line 397
    .line 398
    check-cast v0, Lub2;

    .line 399
    .line 400
    move-object/from16 v1, p2

    .line 401
    .line 402
    check-cast v1, Ljava/lang/Integer;

    .line 403
    .line 404
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 405
    .line 406
    .line 407
    move-result v1

    .line 408
    and-int/lit8 v2, v1, 0x3

    .line 409
    .line 410
    if-eq v2, v6, :cond_5

    .line 411
    .line 412
    move v2, v9

    .line 413
    goto :goto_3

    .line 414
    :cond_5
    move v2, v7

    .line 415
    :goto_3
    and-int/2addr v1, v9

    .line 416
    invoke-virtual {v0, v1, v2}, Lub2;->S(IZ)Z

    .line 417
    .line 418
    .line 419
    move-result v1

    .line 420
    if-eqz v1, :cond_a

    .line 421
    .line 422
    invoke-virtual {v0, v11}, Lub2;->g(Ljava/lang/Object;)Z

    .line 423
    .line 424
    .line 425
    move-result v1

    .line 426
    invoke-virtual {v0, v10}, Lub2;->i(Ljava/lang/Object;)Z

    .line 427
    .line 428
    .line 429
    move-result v2

    .line 430
    or-int/2addr v1, v2

    .line 431
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    move-result-object v2

    .line 435
    if-nez v1, :cond_6

    .line 436
    .line 437
    if-ne v2, v5, :cond_7

    .line 438
    .line 439
    :cond_6
    new-instance v2, Ll51;

    .line 440
    .line 441
    invoke-direct {v2, v11, v10, v7}, Ll51;-><init>(Lqa2;Luo2;B)V

    .line 442
    .line 443
    .line 444
    invoke-virtual {v0, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 445
    .line 446
    .line 447
    :cond_7
    check-cast v2, Lfa2;

    .line 448
    .line 449
    if-eqz v4, :cond_8

    .line 450
    .line 451
    if-nez v3, :cond_8

    .line 452
    .line 453
    iget-object v1, v10, Luo2;->a:Ljava/lang/String;

    .line 454
    .line 455
    invoke-static {v1}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 456
    .line 457
    .line 458
    move-result v1

    .line 459
    if-eqz v1, :cond_9

    .line 460
    .line 461
    :cond_8
    move v9, v7

    .line 462
    :cond_9
    sget-object v1, Lqf0;->a:Lxu4;

    .line 463
    .line 464
    sget-object v1, Lwr3;->b:Lyt1;

    .line 465
    .line 466
    invoke-virtual {v0, v1}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 467
    .line 468
    .line 469
    move-result-object v1

    .line 470
    check-cast v1, Ltr3;

    .line 471
    .line 472
    iget-object v1, v1, Ltr3;->a:Lyv0;

    .line 473
    .line 474
    iget-wide v14, v1, Lyv0;->w:J

    .line 475
    .line 476
    const/16 v17, 0xd

    .line 477
    .line 478
    const-wide/16 v12, 0x0

    .line 479
    .line 480
    move-object/from16 v16, v0

    .line 481
    .line 482
    invoke-static/range {v12 .. v17}, Lqf0;->d(JJLub2;I)Lof0;

    .line 483
    .line 484
    .line 485
    move-result-object v0

    .line 486
    move-object/from16 v1, v16

    .line 487
    .line 488
    new-instance v4, Lm51;

    .line 489
    .line 490
    invoke-direct {v4, v7, v3}, Lm51;-><init>(BZ)V

    .line 491
    .line 492
    .line 493
    const v3, 0x34502b80

    .line 494
    .line 495
    .line 496
    invoke-static {v3, v4, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 497
    .line 498
    .line 499
    move-result-object v18

    .line 500
    const/high16 v20, 0x30000000

    .line 501
    .line 502
    const/16 v21, 0x1ea

    .line 503
    .line 504
    const/4 v13, 0x0

    .line 505
    const/4 v15, 0x0

    .line 506
    const/16 v17, 0x0

    .line 507
    .line 508
    move-object/from16 v16, v0

    .line 509
    .line 510
    move-object/from16 v19, v1

    .line 511
    .line 512
    move-object v12, v2

    .line 513
    move v14, v9

    .line 514
    invoke-static/range {v12 .. v21}, Lpn;->D(Lfa2;Li14;ZLub6;Lof0;Lxu4;Lva2;Lub2;II)V

    .line 515
    .line 516
    .line 517
    goto :goto_4

    .line 518
    :cond_a
    move-object/from16 v16, v0

    .line 519
    .line 520
    invoke-virtual/range {v16 .. v16}, Lub2;->V()V

    .line 521
    .line 522
    .line 523
    :goto_4
    return-object v8

    .line 524
    :pswitch_4
    check-cast v11, Lev;

    .line 525
    .line 526
    check-cast v10, Lfa2;

    .line 527
    .line 528
    move-object/from16 v1, p1

    .line 529
    .line 530
    check-cast v1, Lub2;

    .line 531
    .line 532
    move-object/from16 v3, p2

    .line 533
    .line 534
    check-cast v3, Ljava/lang/Integer;

    .line 535
    .line 536
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 537
    .line 538
    .line 539
    move-result v3

    .line 540
    and-int/lit8 v4, v3, 0x3

    .line 541
    .line 542
    if-eq v4, v6, :cond_b

    .line 543
    .line 544
    move v4, v9

    .line 545
    goto :goto_5

    .line 546
    :cond_b
    move v4, v7

    .line 547
    :goto_5
    and-int/2addr v3, v9

    .line 548
    invoke-virtual {v1, v3, v4}, Lub2;->S(IZ)Z

    .line 549
    .line 550
    .line 551
    move-result v3

    .line 552
    if-eqz v3, :cond_10

    .line 553
    .line 554
    new-instance v3, Lvv;

    .line 555
    .line 556
    new-instance v4, Lj02;

    .line 557
    .line 558
    const/4 v6, 0x3

    .line 559
    invoke-direct {v4, v6}, Lj02;-><init>(B)V

    .line 560
    .line 561
    .line 562
    const/high16 v12, 0x40c00000    # 6.0f

    .line 563
    .line 564
    invoke-direct {v3, v12, v9, v4}, Lvv;-><init>(FZLj02;)V

    .line 565
    .line 566
    .line 567
    sget-object v4, Lt6;->u:Lq20;

    .line 568
    .line 569
    const/16 v12, 0x36

    .line 570
    .line 571
    invoke-static {v3, v4, v1, v12}, Lsq5;->a(Luv;Lq20;Lub2;I)Ltq5;

    .line 572
    .line 573
    .line 574
    move-result-object v3

    .line 575
    iget-wide v12, v1, Lub2;->T:J

    .line 576
    .line 577
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    .line 578
    .line 579
    .line 580
    move-result v4

    .line 581
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 582
    .line 583
    .line 584
    move-result-object v12

    .line 585
    sget-object v13, Lf14;->i:Lf14;

    .line 586
    .line 587
    invoke-static {v1, v13}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 588
    .line 589
    .line 590
    move-result-object v13

    .line 591
    sget-object v14, La21;->d:Lt6;

    .line 592
    .line 593
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 594
    .line 595
    .line 596
    invoke-virtual {v1}, Lub2;->e0()V

    .line 597
    .line 598
    .line 599
    iget-boolean v14, v1, Lub2;->S:Z

    .line 600
    .line 601
    if-eqz v14, :cond_c

    .line 602
    .line 603
    sget-object v14, Lja3;->a0:Lxg2;

    .line 604
    .line 605
    invoke-virtual {v1, v14}, Lub2;->l(Lfa2;)V

    .line 606
    .line 607
    .line 608
    goto :goto_6

    .line 609
    :cond_c
    invoke-virtual {v1}, Lub2;->n0()V

    .line 610
    .line 611
    .line 612
    :goto_6
    sget-object v14, Lt6;->S:Lf11;

    .line 613
    .line 614
    invoke-static {v14, v1, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 615
    .line 616
    .line 617
    sget-object v3, Lt6;->R:Lf11;

    .line 618
    .line 619
    invoke-static {v3, v1, v12}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 620
    .line 621
    .line 622
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 623
    .line 624
    .line 625
    move-result-object v3

    .line 626
    sget-object v4, Lt6;->T:Lf11;

    .line 627
    .line 628
    invoke-static {v4, v1, v3}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 629
    .line 630
    .line 631
    invoke-static {v1}, Les6;->l(Lub2;)V

    .line 632
    .line 633
    .line 634
    sget-object v3, Lt6;->Q:Lf11;

    .line 635
    .line 636
    invoke-static {v3, v1, v13}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 637
    .line 638
    .line 639
    iget-object v3, v11, Lev;->a:Ljava/lang/String;

    .line 640
    .line 641
    iget-boolean v15, v0, Lan;->j:Z

    .line 642
    .line 643
    invoke-static {v3, v15, v1, v7}, Lgj;->e(Ljava/lang/String;ZLub2;I)V

    .line 644
    .line 645
    .line 646
    if-eqz v15, :cond_f

    .line 647
    .line 648
    const v2, -0x5eec53f4

    .line 649
    .line 650
    .line 651
    invoke-virtual {v1, v2}, Lub2;->b0(I)V

    .line 652
    .line 653
    .line 654
    invoke-virtual {v1, v10}, Lub2;->g(Ljava/lang/Object;)Z

    .line 655
    .line 656
    .line 657
    move-result v2

    .line 658
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    move-result-object v3

    .line 662
    if-nez v2, :cond_d

    .line 663
    .line 664
    if-ne v3, v5, :cond_e

    .line 665
    .line 666
    :cond_d
    new-instance v3, Loo;

    .line 667
    .line 668
    invoke-direct {v3, v10, v6}, Loo;-><init>(Lfa2;B)V

    .line 669
    .line 670
    .line 671
    invoke-virtual {v1, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 672
    .line 673
    .line 674
    :cond_e
    move-object v2, v3

    .line 675
    check-cast v2, Lqa2;

    .line 676
    .line 677
    invoke-virtual {v1, v7}, Lub2;->r(Z)V

    .line 678
    .line 679
    .line 680
    :goto_7
    move-object v13, v2

    .line 681
    goto :goto_8

    .line 682
    :cond_f
    const v3, -0x5eeb0faa

    .line 683
    .line 684
    .line 685
    invoke-virtual {v1, v3}, Lub2;->b0(I)V

    .line 686
    .line 687
    .line 688
    invoke-virtual {v1, v7}, Lub2;->r(Z)V

    .line 689
    .line 690
    .line 691
    goto :goto_7

    .line 692
    :goto_8
    const/16 v18, 0x0

    .line 693
    .line 694
    const/16 v19, 0x34

    .line 695
    .line 696
    iget-boolean v12, v0, Lan;->k:Z

    .line 697
    .line 698
    const/4 v14, 0x0

    .line 699
    const/16 v16, 0x0

    .line 700
    .line 701
    move-object/from16 v17, v1

    .line 702
    .line 703
    invoke-static/range {v12 .. v19}, Llq;->b(ZLqa2;Li14;ZLwo0;Lub2;II)V

    .line 704
    .line 705
    .line 706
    move-object/from16 v0, v17

    .line 707
    .line 708
    invoke-virtual {v0, v9}, Lub2;->r(Z)V

    .line 709
    .line 710
    .line 711
    goto :goto_9

    .line 712
    :cond_10
    move-object v0, v1

    .line 713
    invoke-virtual {v0}, Lub2;->V()V

    .line 714
    .line 715
    .line 716
    :goto_9
    return-object v8

    .line 717
    :pswitch_5
    move-object v12, v11

    .line 718
    check-cast v12, Lck;

    .line 719
    .line 720
    iget-object v1, v12, Lck;->f:Ldy4;

    .line 721
    .line 722
    iget-object v2, v12, Lck;->g:Ldy4;

    .line 723
    .line 724
    iget-object v3, v12, Lck;->d:Ldy4;

    .line 725
    .line 726
    check-cast v10, Lnd7;

    .line 727
    .line 728
    move-object/from16 v4, p1

    .line 729
    .line 730
    check-cast v4, Lub2;

    .line 731
    .line 732
    move-object/from16 v11, p2

    .line 733
    .line 734
    check-cast v11, Ljava/lang/Integer;

    .line 735
    .line 736
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 737
    .line 738
    .line 739
    move-result v11

    .line 740
    and-int/lit8 v13, v11, 0x3

    .line 741
    .line 742
    if-eq v13, v6, :cond_11

    .line 743
    .line 744
    move v6, v9

    .line 745
    goto :goto_a

    .line 746
    :cond_11
    move v6, v7

    .line 747
    :goto_a
    and-int/2addr v11, v9

    .line 748
    invoke-virtual {v4, v11, v6}, Lub2;->S(IZ)Z

    .line 749
    .line 750
    .line 751
    move-result v6

    .line 752
    if-eqz v6, :cond_1c

    .line 753
    .line 754
    iget-object v6, v12, Lck;->c:Ldy4;

    .line 755
    .line 756
    invoke-virtual {v6}, Ldy4;->getValue()Ljava/lang/Object;

    .line 757
    .line 758
    .line 759
    move-result-object v6

    .line 760
    check-cast v6, Ljava/lang/Boolean;

    .line 761
    .line 762
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 763
    .line 764
    .line 765
    move-result v6

    .line 766
    if-eqz v6, :cond_1b

    .line 767
    .line 768
    const v6, 0x2127912f

    .line 769
    .line 770
    .line 771
    invoke-virtual {v4, v6}, Lub2;->b0(I)V

    .line 772
    .line 773
    .line 774
    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    .line 775
    .line 776
    .line 777
    move-result v6

    .line 778
    iget-boolean v10, v0, Lan;->j:Z

    .line 779
    .line 780
    iget-boolean v0, v0, Lan;->k:Z

    .line 781
    .line 782
    if-eqz v6, :cond_16

    .line 783
    .line 784
    if-ne v6, v9, :cond_15

    .line 785
    .line 786
    const v6, -0x59c49845

    .line 787
    .line 788
    .line 789
    invoke-virtual {v4, v6}, Lub2;->b0(I)V

    .line 790
    .line 791
    .line 792
    invoke-virtual {v3}, Ldy4;->getValue()Ljava/lang/Object;

    .line 793
    .line 794
    .line 795
    move-result-object v3

    .line 796
    check-cast v3, Ltp0;

    .line 797
    .line 798
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 799
    .line 800
    .line 801
    move-result-object v2

    .line 802
    check-cast v2, Ljava/lang/Boolean;

    .line 803
    .line 804
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 805
    .line 806
    .line 807
    move-result v2

    .line 808
    invoke-virtual {v1}, Ldy4;->getValue()Ljava/lang/Object;

    .line 809
    .line 810
    .line 811
    move-result-object v1

    .line 812
    check-cast v1, Ljava/util/List;

    .line 813
    .line 814
    invoke-virtual {v12}, Lck;->b()Ldk;

    .line 815
    .line 816
    .line 817
    move-result-object v18

    .line 818
    invoke-virtual {v4, v12}, Lub2;->i(Ljava/lang/Object;)Z

    .line 819
    .line 820
    .line 821
    move-result v6

    .line 822
    invoke-virtual {v4, v10}, Lub2;->h(Z)Z

    .line 823
    .line 824
    .line 825
    move-result v11

    .line 826
    or-int/2addr v6, v11

    .line 827
    invoke-virtual {v4}, Lub2;->N()Ljava/lang/Object;

    .line 828
    .line 829
    .line 830
    move-result-object v11

    .line 831
    if-nez v6, :cond_12

    .line 832
    .line 833
    if-ne v11, v5, :cond_13

    .line 834
    .line 835
    :cond_12
    new-instance v11, Ldn;

    .line 836
    .line 837
    invoke-direct {v11, v12, v10, v9}, Ldn;-><init>(Lck;ZB)V

    .line 838
    .line 839
    .line 840
    invoke-virtual {v4, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 841
    .line 842
    .line 843
    :cond_13
    move-object/from16 v19, v11

    .line 844
    .line 845
    check-cast v19, Lqa2;

    .line 846
    .line 847
    invoke-virtual {v4, v12}, Lub2;->i(Ljava/lang/Object;)Z

    .line 848
    .line 849
    .line 850
    move-result v6

    .line 851
    invoke-virtual {v4}, Lub2;->N()Ljava/lang/Object;

    .line 852
    .line 853
    .line 854
    move-result-object v9

    .line 855
    if-nez v6, :cond_14

    .line 856
    .line 857
    if-eq v9, v5, :cond_14

    .line 858
    .line 859
    move v5, v10

    .line 860
    goto :goto_b

    .line 861
    :cond_14
    move v15, v10

    .line 862
    new-instance v10, Lla;

    .line 863
    .line 864
    const/16 v16, 0x0

    .line 865
    .line 866
    const/16 v17, 0x2

    .line 867
    .line 868
    const/4 v11, 0x0

    .line 869
    const-class v13, Lck;

    .line 870
    .line 871
    const-string v14, "dismissDialog"

    .line 872
    .line 873
    move v5, v15

    .line 874
    const-string v15, "dismissDialog()V"

    .line 875
    .line 876
    invoke-direct/range {v10 .. v17}, Lla;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 877
    .line 878
    .line 879
    invoke-virtual {v4, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 880
    .line 881
    .line 882
    move-object v9, v10

    .line 883
    :goto_b
    check-cast v9, Le73;

    .line 884
    .line 885
    move-object/from16 v20, v9

    .line 886
    .line 887
    check-cast v20, Lfa2;

    .line 888
    .line 889
    sget v6, Ldk;->l:I

    .line 890
    .line 891
    const/16 v22, 0x0

    .line 892
    .line 893
    move/from16 v16, v0

    .line 894
    .line 895
    move-object/from16 v17, v1

    .line 896
    .line 897
    move v14, v2

    .line 898
    move-object v13, v3

    .line 899
    move-object/from16 v21, v4

    .line 900
    .line 901
    move v15, v5

    .line 902
    invoke-static/range {v13 .. v22}, Lb70;->d(Ltp0;ZZZLjava/util/List;Ldk;Lqa2;Lfa2;Lub2;I)V

    .line 903
    .line 904
    .line 905
    move-object/from16 v0, v21

    .line 906
    .line 907
    invoke-virtual {v0, v7}, Lub2;->r(Z)V

    .line 908
    .line 909
    .line 910
    goto/16 :goto_c

    .line 911
    .line 912
    :cond_15
    move-object v0, v4

    .line 913
    const v1, -0x59c4eacd

    .line 914
    .line 915
    .line 916
    invoke-static {v1, v0, v7}, Lxk6;->e(ILub2;Z)Lzy0;

    .line 917
    .line 918
    .line 919
    move-result-object v0

    .line 920
    throw v0

    .line 921
    :cond_16
    move v6, v0

    .line 922
    move-object v0, v4

    .line 923
    move v4, v10

    .line 924
    const v9, -0x59c4e722

    .line 925
    .line 926
    .line 927
    invoke-virtual {v0, v9}, Lub2;->b0(I)V

    .line 928
    .line 929
    .line 930
    invoke-virtual {v3}, Ldy4;->getValue()Ljava/lang/Object;

    .line 931
    .line 932
    .line 933
    move-result-object v3

    .line 934
    check-cast v3, Ltp0;

    .line 935
    .line 936
    invoke-virtual {v2}, Ldy4;->getValue()Ljava/lang/Object;

    .line 937
    .line 938
    .line 939
    move-result-object v2

    .line 940
    check-cast v2, Ljava/lang/Boolean;

    .line 941
    .line 942
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 943
    .line 944
    .line 945
    move-result v2

    .line 946
    invoke-virtual {v1}, Ldy4;->getValue()Ljava/lang/Object;

    .line 947
    .line 948
    .line 949
    move-result-object v1

    .line 950
    check-cast v1, Ljava/util/List;

    .line 951
    .line 952
    invoke-virtual {v12}, Lck;->b()Ldk;

    .line 953
    .line 954
    .line 955
    move-result-object v18

    .line 956
    invoke-virtual {v0, v12}, Lub2;->i(Ljava/lang/Object;)Z

    .line 957
    .line 958
    .line 959
    move-result v9

    .line 960
    invoke-virtual {v0, v4}, Lub2;->h(Z)Z

    .line 961
    .line 962
    .line 963
    move-result v10

    .line 964
    or-int/2addr v9, v10

    .line 965
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 966
    .line 967
    .line 968
    move-result-object v10

    .line 969
    if-nez v9, :cond_17

    .line 970
    .line 971
    if-ne v10, v5, :cond_18

    .line 972
    .line 973
    :cond_17
    new-instance v10, Ldn;

    .line 974
    .line 975
    invoke-direct {v10, v12, v4, v7}, Ldn;-><init>(Lck;ZB)V

    .line 976
    .line 977
    .line 978
    invoke-virtual {v0, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 979
    .line 980
    .line 981
    :cond_18
    move-object/from16 v19, v10

    .line 982
    .line 983
    check-cast v19, Lqa2;

    .line 984
    .line 985
    invoke-virtual {v0, v12}, Lub2;->i(Ljava/lang/Object;)Z

    .line 986
    .line 987
    .line 988
    move-result v9

    .line 989
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 990
    .line 991
    .line 992
    move-result-object v10

    .line 993
    if-nez v9, :cond_19

    .line 994
    .line 995
    if-ne v10, v5, :cond_1a

    .line 996
    .line 997
    :cond_19
    new-instance v10, Lla;

    .line 998
    .line 999
    const/16 v16, 0x0

    .line 1000
    .line 1001
    const/16 v17, 0x1

    .line 1002
    .line 1003
    const/4 v11, 0x0

    .line 1004
    const-class v13, Lck;

    .line 1005
    .line 1006
    const-string v14, "dismissDialog"

    .line 1007
    .line 1008
    const-string v15, "dismissDialog()V"

    .line 1009
    .line 1010
    invoke-direct/range {v10 .. v17}, Lla;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 1011
    .line 1012
    .line 1013
    invoke-virtual {v0, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1014
    .line 1015
    .line 1016
    :cond_1a
    check-cast v10, Le73;

    .line 1017
    .line 1018
    move-object/from16 v20, v10

    .line 1019
    .line 1020
    check-cast v20, Lfa2;

    .line 1021
    .line 1022
    sget v5, Ldk;->l:I

    .line 1023
    .line 1024
    const/16 v22, 0x0

    .line 1025
    .line 1026
    move-object/from16 v21, v0

    .line 1027
    .line 1028
    move-object/from16 v17, v1

    .line 1029
    .line 1030
    move v14, v2

    .line 1031
    move-object v13, v3

    .line 1032
    move v15, v4

    .line 1033
    move/from16 v16, v6

    .line 1034
    .line 1035
    invoke-static/range {v13 .. v22}, Ly60;->c(Ltp0;ZZZLjava/util/List;Ldk;Lqa2;Lfa2;Lub2;I)V

    .line 1036
    .line 1037
    .line 1038
    invoke-virtual {v0, v7}, Lub2;->r(Z)V

    .line 1039
    .line 1040
    .line 1041
    :goto_c
    invoke-virtual {v0, v7}, Lub2;->r(Z)V

    .line 1042
    .line 1043
    .line 1044
    goto :goto_d

    .line 1045
    :cond_1b
    move-object v0, v4

    .line 1046
    const v1, 0x213aa279

    .line 1047
    .line 1048
    .line 1049
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 1050
    .line 1051
    .line 1052
    invoke-virtual {v0, v7}, Lub2;->r(Z)V

    .line 1053
    .line 1054
    .line 1055
    goto :goto_d

    .line 1056
    :cond_1c
    move-object v0, v4

    .line 1057
    invoke-virtual {v0}, Lub2;->V()V

    .line 1058
    .line 1059
    .line 1060
    :goto_d
    return-object v8

    .line 1061
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
