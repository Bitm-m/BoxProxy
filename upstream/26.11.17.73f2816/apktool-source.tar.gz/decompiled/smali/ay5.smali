.class public final Lay5;
.super Lja1;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public i:Lgv;

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ley5;

.field public l:I


# direct methods
.method public constructor <init>(Ley5;Lja1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lay5;->k:Ley5;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lja1;-><init>(Lia1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iput-object p1, p0, Lay5;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lay5;->l:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lay5;->l:I

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    iget-object v0, p0, Lay5;->k:Ley5;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v5, 0x0

    .line 16
    move-object v1, p0

    .line 17
    invoke-virtual/range {v0 .. v5}, Ley5;->j(Lja1;Lf06;Ljava/lang/String;Ljava/lang/String;[B)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method
