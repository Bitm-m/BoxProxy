.class public final Lac4;
.super Lja1;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public i:Lbl5;

.field public j:Lbl5;

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ldc4;

.field public m:I


# direct methods
.method public constructor <init>(Ldc4;Lia1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lac4;->l:Ldc4;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lja1;-><init>(Lia1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lac4;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lac4;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lac4;->m:I

    .line 9
    .line 10
    iget-object p1, p0, Lac4;->l:Ldc4;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Ldc4;->b(Lia1;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
