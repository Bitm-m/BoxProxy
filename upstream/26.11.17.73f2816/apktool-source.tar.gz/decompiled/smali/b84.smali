.class public interface abstract Lb84;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# virtual methods
.method public abstract a(Llk3;)Li14;
.end method

.method public abstract b()Ls74;
.end method

.method public abstract c(Llk3;)F
.end method

.method public abstract d()F
.end method

.method public abstract e()Lz64;
.end method
