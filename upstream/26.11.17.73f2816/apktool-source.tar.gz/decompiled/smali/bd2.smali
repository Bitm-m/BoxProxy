.class public final synthetic Lbd2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Lfa2;

.field public final synthetic j:Li14;

.field public final synthetic k:Z

.field public final synthetic l:F

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:Lnf0;

.field public final synthetic p:J

.field public final synthetic q:Lxu4;

.field public final synthetic r:Lc01;

.field public final synthetic s:I

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lfa2;Li14;ZFFFLnf0;JLxu4;Lc01;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbd2;->i:Lfa2;

    .line 5
    .line 6
    iput-object p2, p0, Lbd2;->j:Li14;

    .line 7
    .line 8
    iput-boolean p3, p0, Lbd2;->k:Z

    .line 9
    .line 10
    iput p4, p0, Lbd2;->l:F

    .line 11
    .line 12
    iput p5, p0, Lbd2;->m:F

    .line 13
    .line 14
    iput p6, p0, Lbd2;->n:F

    .line 15
    .line 16
    iput-object p7, p0, Lbd2;->o:Lnf0;

    .line 17
    .line 18
    iput-wide p8, p0, Lbd2;->p:J

    .line 19
    .line 20
    iput-object p10, p0, Lbd2;->q:Lxu4;

    .line 21
    .line 22
    iput-object p11, p0, Lbd2;->r:Lc01;

    .line 23
    .line 24
    iput p12, p0, Lbd2;->s:I

    .line 25
    .line 26
    iput p13, p0, Lbd2;->t:I

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    move-object v11, p1

    .line 2
    check-cast v11, Lub2;

    .line 3
    .line 4
    move-object/from16 v0, p2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    iget v0, p0, Lbd2;->s:I

    .line 12
    .line 13
    or-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    invoke-static {v0}, Lub3;->b0(I)I

    .line 16
    .line 17
    .line 18
    move-result v12

    .line 19
    iget v0, p0, Lbd2;->t:I

    .line 20
    .line 21
    invoke-static {v0}, Lub3;->b0(I)I

    .line 22
    .line 23
    .line 24
    move-result v13

    .line 25
    iget-object v0, p0, Lbd2;->i:Lfa2;

    .line 26
    .line 27
    iget-object v1, p0, Lbd2;->j:Li14;

    .line 28
    .line 29
    iget-boolean v2, p0, Lbd2;->k:Z

    .line 30
    .line 31
    iget v3, p0, Lbd2;->l:F

    .line 32
    .line 33
    iget v4, p0, Lbd2;->m:F

    .line 34
    .line 35
    iget v5, p0, Lbd2;->n:F

    .line 36
    .line 37
    iget-object v6, p0, Lbd2;->o:Lnf0;

    .line 38
    .line 39
    iget-wide v7, p0, Lbd2;->p:J

    .line 40
    .line 41
    iget-object v9, p0, Lbd2;->q:Lxu4;

    .line 42
    .line 43
    iget-object v10, p0, Lbd2;->r:Lc01;

    .line 44
    .line 45
    invoke-static/range {v0 .. v13}, Lnm;->m(Lfa2;Li14;ZFFFLnf0;JLxu4;Lc01;Lub2;II)V

    .line 46
    .line 47
    .line 48
    sget-object p0, Lne7;->a:Lne7;

    .line 49
    .line 50
    return-object p0
.end method
