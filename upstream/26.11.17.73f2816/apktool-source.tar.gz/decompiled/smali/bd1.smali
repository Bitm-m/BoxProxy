.class public final Lbd1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lpe1;

.field public final synthetic k:Lw44;


# direct methods
.method public synthetic constructor <init>(Lpe1;Lw44;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lbd1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lbd1;->j:Lpe1;

    .line 4
    .line 5
    iput-object p2, p0, Lbd1;->k:Lw44;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lbd1;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    iget-object v2, p0, Lbd1;->j:Lpe1;

    .line 6
    .line 7
    iget-object p0, p0, Lbd1;->k:Lw44;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-interface {p0, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-object v1

    .line 16
    :pswitch_0
    invoke-interface {p0, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
