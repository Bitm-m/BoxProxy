.class public final Lac6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final a:Lfq5;

.field public final b:Lfq5;

.field public final c:Lfq5;

.field public final d:Lfq5;

.field public final e:Lfq5;

.field public final f:Lfq5;

.field public final g:Lfq5;

.field public final h:Lfq5;

.field public i:Lpj3;

.field public j:Lit3;

.field public k:Lit3;

.field public l:Lit3;

.field public m:Lit3;

.field public n:Let3;

.field public o:Let3;

.field public p:Let3;

.field public q:Let3;


# direct methods
.method public constructor <init>()V
    .locals 8

    .line 1
    sget-object v0, Lwb6;->a:Lfq5;

    .line 2
    .line 3
    sget-object v1, Lwb6;->b:Lfq5;

    .line 4
    .line 5
    sget-object v2, Lwb6;->c:Lfq5;

    .line 6
    .line 7
    sget-object v3, Lwb6;->d:Lfq5;

    .line 8
    .line 9
    sget-object v4, Lwb6;->f:Lfq5;

    .line 10
    .line 11
    sget-object v5, Lwb6;->e:Lfq5;

    .line 12
    .line 13
    sget-object v6, Lwb6;->g:Lfq5;

    .line 14
    .line 15
    sget-object v7, Lwb6;->h:Lfq5;

    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, Lac6;->a:Lfq5;

    .line 21
    .line 22
    iput-object v1, p0, Lac6;->b:Lfq5;

    .line 23
    .line 24
    iput-object v2, p0, Lac6;->c:Lfq5;

    .line 25
    .line 26
    iput-object v3, p0, Lac6;->d:Lfq5;

    .line 27
    .line 28
    iput-object v4, p0, Lac6;->e:Lfq5;

    .line 29
    .line 30
    iput-object v5, p0, Lac6;->f:Lfq5;

    .line 31
    .line 32
    iput-object v6, p0, Lac6;->g:Lfq5;

    .line 33
    .line 34
    iput-object v7, p0, Lac6;->h:Lfq5;

    .line 35
    .line 36
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lac6;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lac6;

    .line 8
    .line 9
    iget-object v0, p1, Lac6;->a:Lfq5;

    .line 10
    .line 11
    iget-object v1, p0, Lac6;->a:Lfq5;

    .line 12
    .line 13
    invoke-static {v1, v0}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p0, Lac6;->b:Lfq5;

    .line 20
    .line 21
    iget-object v1, p1, Lac6;->b:Lfq5;

    .line 22
    .line 23
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget-object v0, p0, Lac6;->c:Lfq5;

    .line 30
    .line 31
    iget-object v1, p1, Lac6;->c:Lfq5;

    .line 32
    .line 33
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    iget-object v0, p0, Lac6;->d:Lfq5;

    .line 40
    .line 41
    iget-object v1, p1, Lac6;->d:Lfq5;

    .line 42
    .line 43
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    iget-object v0, p0, Lac6;->e:Lfq5;

    .line 50
    .line 51
    iget-object v1, p1, Lac6;->e:Lfq5;

    .line 52
    .line 53
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_0

    .line 58
    .line 59
    iget-object v0, p0, Lac6;->f:Lfq5;

    .line 60
    .line 61
    iget-object v1, p1, Lac6;->f:Lfq5;

    .line 62
    .line 63
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_0

    .line 68
    .line 69
    iget-object v0, p0, Lac6;->g:Lfq5;

    .line 70
    .line 71
    iget-object v1, p1, Lac6;->g:Lfq5;

    .line 72
    .line 73
    invoke-static {v0, v1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-eqz v0, :cond_0

    .line 78
    .line 79
    iget-object p0, p0, Lac6;->h:Lfq5;

    .line 80
    .line 81
    iget-object p1, p1, Lac6;->h:Lfq5;

    .line 82
    .line 83
    invoke-static {p0, p1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result p0

    .line 87
    if-nez p0, :cond_1

    .line 88
    .line 89
    :cond_0
    const/4 p0, 0x0

    .line 90
    return p0

    .line 91
    :cond_1
    const/4 p0, 0x1

    .line 92
    return p0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, Lac6;->a:Lfq5;

    .line 2
    .line 3
    invoke-virtual {v0}, Lfq5;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Lac6;->b:Lfq5;

    .line 10
    .line 11
    invoke-virtual {v1}, Lfq5;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-object v0, p0, Lac6;->c:Lfq5;

    .line 19
    .line 20
    invoke-virtual {v0}, Lfq5;->hashCode()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    add-int/2addr v0, v1

    .line 25
    mul-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    iget-object v1, p0, Lac6;->d:Lfq5;

    .line 28
    .line 29
    invoke-virtual {v1}, Lfq5;->hashCode()I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    add-int/2addr v1, v0

    .line 34
    mul-int/lit8 v1, v1, 0x1f

    .line 35
    .line 36
    iget-object v0, p0, Lac6;->e:Lfq5;

    .line 37
    .line 38
    invoke-virtual {v0}, Lfq5;->hashCode()I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v0, v1

    .line 43
    mul-int/lit8 v0, v0, 0x1f

    .line 44
    .line 45
    iget-object v1, p0, Lac6;->f:Lfq5;

    .line 46
    .line 47
    invoke-virtual {v1}, Lfq5;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    add-int/2addr v1, v0

    .line 52
    mul-int/lit8 v1, v1, 0x1f

    .line 53
    .line 54
    iget-object v0, p0, Lac6;->g:Lfq5;

    .line 55
    .line 56
    invoke-virtual {v0}, Lfq5;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    add-int/2addr v0, v1

    .line 61
    mul-int/lit8 v0, v0, 0x1f

    .line 62
    .line 63
    iget-object p0, p0, Lac6;->h:Lfq5;

    .line 64
    .line 65
    invoke-virtual {p0}, Lfq5;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    add-int/2addr p0, v0

    .line 70
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Shapes(extraSmall="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lac6;->a:Lfq5;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", small="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lac6;->b:Lfq5;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", medium="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, Lac6;->c:Lfq5;

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, ", large="

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    iget-object v1, p0, Lac6;->d:Lfq5;

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, ", largeIncreased="

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget-object v1, p0, Lac6;->f:Lfq5;

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v1, ", extraLarge="

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    iget-object v1, p0, Lac6;->e:Lfq5;

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v1, ", extralargeIncreased="

    .line 64
    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    iget-object v1, p0, Lac6;->g:Lfq5;

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v1, ", extraExtraLarge="

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    iget-object p0, p0, Lac6;->h:Lfq5;

    .line 79
    .line 80
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    const-string p0, ")"

    .line 84
    .line 85
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    return-object p0
.end method
