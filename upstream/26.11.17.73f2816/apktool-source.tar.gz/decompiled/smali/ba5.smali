.class public final enum Lba5;
.super Ljava/lang/Enum;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final j:Lgl3;

.field public static final enum k:Lba5;

.field public static final enum l:Lba5;

.field public static final synthetic m:[Lba5;

.field public static final synthetic n:La02;


# instance fields
.field public final i:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lba5;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "auto"

    .line 5
    .line 6
    const-string v3, "Auto"

    .line 7
    .line 8
    invoke-direct {v0, v1, v3, v2}, Lba5;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    sput-object v0, Lba5;->k:Lba5;

    .line 12
    .line 13
    new-instance v1, Lba5;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    const-string v3, "fixed"

    .line 17
    .line 18
    const-string v4, "Fixed"

    .line 19
    .line 20
    invoke-direct {v1, v2, v4, v3}, Lba5;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    sput-object v1, Lba5;->l:Lba5;

    .line 24
    .line 25
    filled-new-array {v0, v1}, [Lba5;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    sput-object v0, Lba5;->m:[Lba5;

    .line 30
    .line 31
    new-instance v1, La02;

    .line 32
    .line 33
    invoke-direct {v1, v0}, La02;-><init>([Ljava/lang/Enum;)V

    .line 34
    .line 35
    .line 36
    sput-object v1, Lba5;->n:La02;

    .line 37
    .line 38
    new-instance v0, Lgl3;

    .line 39
    .line 40
    const/16 v1, 0x1a

    .line 41
    .line 42
    invoke-direct {v0, v1}, Lgl3;-><init>(B)V

    .line 43
    .line 44
    .line 45
    sput-object v0, Lba5;->j:Lgl3;

    .line 46
    .line 47
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lba5;->i:Ljava/lang/String;

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lba5;
    .locals 1

    .line 1
    const-class v0, Lba5;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lba5;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lba5;
    .locals 1

    .line 1
    sget-object v0, Lba5;->m:[Lba5;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lba5;

    .line 8
    .line 9
    return-object v0
.end method
