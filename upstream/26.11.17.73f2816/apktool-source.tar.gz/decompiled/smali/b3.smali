.class public abstract Lb3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lff1;


# instance fields
.field public final i:Lgf1;


# direct methods
.method public constructor <init>(Lgf1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb3;->i:Lgf1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge A(Lgf1;)Lhf1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llq;->L(Lff1;Lgf1;)Lhf1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getKey()Lgf1;
    .locals 0

    .line 1
    iget-object p0, p0, Lb3;->i:Lgf1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final bridge k(Lhf1;)Lhf1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llq;->N(Lff1;Lhf1;)Lhf1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge p(Lgf1;)Lff1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llq;->E(Lff1;Lgf1;)Lff1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final v(Lua2;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, Lua2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
