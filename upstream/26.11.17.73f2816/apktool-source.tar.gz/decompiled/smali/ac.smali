.class public final Lac;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lis3;


# static fields
.field public static final b:Lac;

.field public static final c:Lac;

.field public static final d:Lac;

.field public static final e:Lac;

.field public static final f:Lac;

.field public static final g:Lac;

.field public static final h:Lac;

.field public static final i:Lif1;

.field public static final j:Lac;

.field public static final k:Lac;

.field public static final l:Lac;

.field public static final m:Lac;

.field public static final n:Lac;


# instance fields
.field public final synthetic a:B


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lac;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lac;->b:Lac;

    .line 8
    .line 9
    new-instance v0, Lac;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lac;->c:Lac;

    .line 16
    .line 17
    new-instance v0, Lac;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Lac;->d:Lac;

    .line 24
    .line 25
    new-instance v0, Lac;

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 29
    .line 30
    .line 31
    sput-object v0, Lac;->e:Lac;

    .line 32
    .line 33
    new-instance v0, Lac;

    .line 34
    .line 35
    const/4 v1, 0x4

    .line 36
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lac;->f:Lac;

    .line 40
    .line 41
    new-instance v0, Lac;

    .line 42
    .line 43
    const/4 v1, 0x5

    .line 44
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lac;->g:Lac;

    .line 48
    .line 49
    new-instance v0, Lac;

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 53
    .line 54
    .line 55
    sput-object v0, Lac;->h:Lac;

    .line 56
    .line 57
    new-instance v0, Lif1;

    .line 58
    .line 59
    const/16 v1, 0xd

    .line 60
    .line 61
    invoke-direct {v0, v1}, Lif1;-><init>(B)V

    .line 62
    .line 63
    .line 64
    sput-object v0, Lac;->i:Lif1;

    .line 65
    .line 66
    new-instance v0, Lac;

    .line 67
    .line 68
    const/4 v1, 0x7

    .line 69
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 70
    .line 71
    .line 72
    sput-object v0, Lac;->j:Lac;

    .line 73
    .line 74
    new-instance v0, Lac;

    .line 75
    .line 76
    const/16 v1, 0x8

    .line 77
    .line 78
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 79
    .line 80
    .line 81
    sput-object v0, Lac;->k:Lac;

    .line 82
    .line 83
    new-instance v0, Lac;

    .line 84
    .line 85
    const/16 v1, 0x9

    .line 86
    .line 87
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 88
    .line 89
    .line 90
    sput-object v0, Lac;->l:Lac;

    .line 91
    .line 92
    new-instance v0, Lac;

    .line 93
    .line 94
    const/16 v1, 0xa

    .line 95
    .line 96
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 97
    .line 98
    .line 99
    sput-object v0, Lac;->m:Lac;

    .line 100
    .line 101
    new-instance v0, Lac;

    .line 102
    .line 103
    const/16 v1, 0xb

    .line 104
    .line 105
    invoke-direct {v0, v1}, Lac;-><init>(B)V

    .line 106
    .line 107
    .line 108
    sput-object v0, Lac;->n:Lac;

    .line 109
    .line 110
    return-void
.end method

.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lac;->a:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(Lks3;Ljava/util/List;J)Ljs3;
    .locals 27

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    move-wide/from16 v3, p3

    .line 8
    .line 9
    iget-byte v2, v2, Lac;->a:B

    .line 10
    .line 11
    const-string v9, "Collection contains no element matching the predicate."

    .line 12
    .line 13
    const/4 v10, 0x3

    .line 14
    const/4 v11, 0x1

    .line 15
    sget-object v12, Lly1;->i:Lly1;

    .line 16
    .line 17
    const/4 v13, 0x0

    .line 18
    packed-switch v2, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    invoke-static {v3, v4}, Lb81;->k(J)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    invoke-static {v3, v4}, Lb81;->j(J)I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    new-instance v3, Lkv6;

    .line 30
    .line 31
    const/16 v4, 0x18

    .line 32
    .line 33
    invoke-direct {v3, v4}, Lkv6;-><init>(B)V

    .line 34
    .line 35
    .line 36
    invoke-interface {v0, v1, v2, v12, v3}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0

    .line 41
    :pswitch_0
    invoke-static {v3, v4}, Lb81;->g(J)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-eqz v1, :cond_0

    .line 46
    .line 47
    invoke-static {v3, v4}, Lb81;->i(J)I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    goto :goto_0

    .line 52
    :cond_0
    move v1, v13

    .line 53
    :goto_0
    invoke-static {v3, v4}, Lb81;->f(J)Z

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    if-eqz v2, :cond_1

    .line 58
    .line 59
    invoke-static {v3, v4}, Lb81;->h(J)I

    .line 60
    .line 61
    .line 62
    move-result v13

    .line 63
    :cond_1
    new-instance v2, Lx76;

    .line 64
    .line 65
    const/16 v3, 0x15

    .line 66
    .line 67
    invoke-direct {v2, v3}, Lx76;-><init>(B)V

    .line 68
    .line 69
    .line 70
    invoke-interface {v0, v1, v13, v12, v2}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    return-object v0

    .line 75
    :pswitch_1
    new-instance v2, Ljava/util/ArrayList;

    .line 76
    .line 77
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 82
    .line 83
    .line 84
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 85
    .line 86
    .line 87
    move-result v5

    .line 88
    move v6, v13

    .line 89
    move v7, v6

    .line 90
    :goto_1
    if-ge v13, v5, :cond_2

    .line 91
    .line 92
    invoke-interface {v1, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v8

    .line 96
    check-cast v8, Lds3;

    .line 97
    .line 98
    invoke-interface {v8, v3, v4}, Lds3;->e(J)Lb15;

    .line 99
    .line 100
    .line 101
    move-result-object v8

    .line 102
    iget v9, v8, Lb15;->i:I

    .line 103
    .line 104
    invoke-static {v6, v9}, Ljava/lang/Math;->max(II)I

    .line 105
    .line 106
    .line 107
    move-result v6

    .line 108
    iget v9, v8, Lb15;->j:I

    .line 109
    .line 110
    invoke-static {v7, v9}, Ljava/lang/Math;->max(II)I

    .line 111
    .line 112
    .line 113
    move-result v7

    .line 114
    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    add-int/lit8 v13, v13, 0x1

    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_2
    new-instance v1, Lzb;

    .line 121
    .line 122
    const/4 v3, 0x7

    .line 123
    invoke-direct {v1, v2, v3}, Lzb;-><init>(Ljava/util/ArrayList;B)V

    .line 124
    .line 125
    .line 126
    invoke-interface {v0, v6, v7, v12, v1}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    return-object v0

    .line 131
    :pswitch_2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    invoke-interface {v1, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    move-object v9, v2

    .line 139
    check-cast v9, Lds3;

    .line 140
    .line 141
    const/4 v7, 0x0

    .line 142
    const/16 v8, 0xa

    .line 143
    .line 144
    const/4 v4, 0x0

    .line 145
    const/4 v5, 0x0

    .line 146
    const/4 v6, 0x0

    .line 147
    move-wide/from16 v2, p3

    .line 148
    .line 149
    invoke-static/range {v2 .. v8}, Lb81;->b(JIIIII)J

    .line 150
    .line 151
    .line 152
    move-result-wide v2

    .line 153
    invoke-interface {v9, v2, v3}, Lds3;->e(J)Lb15;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-interface {v1, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    check-cast v1, Lds3;

    .line 162
    .line 163
    iget v3, v2, Lb15;->i:I

    .line 164
    .line 165
    iget v4, v2, Lb15;->j:I

    .line 166
    .line 167
    if-ltz v3, :cond_3

    .line 168
    .line 169
    move v5, v11

    .line 170
    goto :goto_2

    .line 171
    :cond_3
    move v5, v13

    .line 172
    :goto_2
    if-gez v4, :cond_4

    .line 173
    .line 174
    move v11, v13

    .line 175
    :cond_4
    and-int/2addr v5, v11

    .line 176
    if-nez v5, :cond_5

    .line 177
    .line 178
    const-string v5, "width and height must be >= 0"

    .line 179
    .line 180
    invoke-static {v5}, Lyy2;->a(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    :cond_5
    invoke-static {v3, v3, v4, v4}, Lc81;->h(IIII)J

    .line 184
    .line 185
    .line 186
    move-result-wide v3

    .line 187
    invoke-interface {v1, v3, v4}, Lds3;->e(J)Lb15;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    iget v3, v2, Lb15;->i:I

    .line 192
    .line 193
    iget v4, v2, Lb15;->j:I

    .line 194
    .line 195
    new-instance v5, Ltz;

    .line 196
    .line 197
    invoke-direct {v5, v1, v2, v10}, Ltz;-><init>(Lb15;Lb15;B)V

    .line 198
    .line 199
    .line 200
    invoke-interface {v0, v3, v4, v12, v5}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    return-object v0

    .line 205
    :pswitch_3
    invoke-static/range {p3 .. p4}, Lb81;->k(J)I

    .line 206
    .line 207
    .line 208
    move-result v1

    .line 209
    invoke-static/range {p3 .. p4}, Lb81;->j(J)I

    .line 210
    .line 211
    .line 212
    move-result v2

    .line 213
    new-instance v3, Lxr2;

    .line 214
    .line 215
    invoke-direct {v3, v10}, Lxr2;-><init>(B)V

    .line 216
    .line 217
    .line 218
    invoke-interface {v0, v1, v2, v12, v3}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    return-object v0

    .line 223
    :pswitch_4
    invoke-static/range {p3 .. p4}, Lb81;->i(J)I

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    invoke-static/range {p3 .. p4}, Lb81;->h(J)I

    .line 228
    .line 229
    .line 230
    move-result v2

    .line 231
    sget-object v3, Lac;->i:Lif1;

    .line 232
    .line 233
    invoke-interface {v0, v1, v2, v12, v3}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    return-object v0

    .line 238
    :pswitch_5
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    .line 240
    .line 241
    const/high16 v2, 0x41000000    # 8.0f

    .line 242
    .line 243
    invoke-interface {v0, v2}, Lul1;->s0(F)I

    .line 244
    .line 245
    .line 246
    move-result v8

    .line 247
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 248
    .line 249
    .line 250
    move-result-object v2

    .line 251
    :cond_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 252
    .line 253
    .line 254
    move-result v3

    .line 255
    if-eqz v3, :cond_7

    .line 256
    .line 257
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v3

    .line 261
    move-object v4, v3

    .line 262
    check-cast v4, Lds3;

    .line 263
    .line 264
    invoke-static {v4}, Lr71;->v(Lds3;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    const-string v5, "start"

    .line 269
    .line 270
    invoke-static {v4, v5}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 271
    .line 272
    .line 273
    move-result v4

    .line 274
    if-eqz v4, :cond_6

    .line 275
    .line 276
    goto :goto_3

    .line 277
    :cond_7
    const/4 v3, 0x0

    .line 278
    :goto_3
    move-object v11, v3

    .line 279
    check-cast v11, Lds3;

    .line 280
    .line 281
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    :cond_8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 286
    .line 287
    .line 288
    move-result v3

    .line 289
    if-eqz v3, :cond_1f

    .line 290
    .line 291
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    move-result-object v3

    .line 295
    move-object v14, v3

    .line 296
    check-cast v14, Lds3;

    .line 297
    .line 298
    invoke-static {v14}, Lr71;->v(Lds3;)Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object v3

    .line 302
    const-string v4, "center"

    .line 303
    .line 304
    invoke-static {v3, v4}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 305
    .line 306
    .line 307
    move-result v3

    .line 308
    if-eqz v3, :cond_8

    .line 309
    .line 310
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 311
    .line 312
    .line 313
    move-result-object v1

    .line 314
    :cond_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 315
    .line 316
    .line 317
    move-result v2

    .line 318
    if-eqz v2, :cond_a

    .line 319
    .line 320
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v2

    .line 324
    move-object v3, v2

    .line 325
    check-cast v3, Lds3;

    .line 326
    .line 327
    invoke-static {v3}, Lr71;->v(Lds3;)Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    move-result-object v3

    .line 331
    const-string v4, "end"

    .line 332
    .line 333
    invoke-static {v3, v4}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 334
    .line 335
    .line 336
    move-result v3

    .line 337
    if-eqz v3, :cond_9

    .line 338
    .line 339
    goto :goto_4

    .line 340
    :cond_a
    const/4 v2, 0x0

    .line 341
    :goto_4
    move-object v9, v2

    .line 342
    check-cast v9, Lds3;

    .line 343
    .line 344
    invoke-static/range {p3 .. p4}, Lb81;->i(J)I

    .line 345
    .line 346
    .line 347
    move-result v15

    .line 348
    invoke-static/range {p3 .. p4}, Lb81;->h(J)I

    .line 349
    .line 350
    .line 351
    move-result v1

    .line 352
    invoke-static/range {p3 .. p4}, Lb81;->e(J)Z

    .line 353
    .line 354
    .line 355
    move-result v16

    .line 356
    const/4 v6, 0x0

    .line 357
    const/16 v7, 0xa

    .line 358
    .line 359
    const/4 v3, 0x0

    .line 360
    const/4 v4, 0x0

    .line 361
    const/4 v5, 0x0

    .line 362
    move v10, v1

    .line 363
    move-wide/from16 v1, p3

    .line 364
    .line 365
    invoke-static/range {v1 .. v7}, Lb81;->b(JIIIII)J

    .line 366
    .line 367
    .line 368
    move-result-wide v3

    .line 369
    if-eqz v11, :cond_b

    .line 370
    .line 371
    invoke-interface {v11, v3, v4}, Lds3;->e(J)Lb15;

    .line 372
    .line 373
    .line 374
    move-result-object v1

    .line 375
    goto :goto_5

    .line 376
    :cond_b
    const/4 v1, 0x0

    .line 377
    :goto_5
    if-eqz v1, :cond_c

    .line 378
    .line 379
    iget v2, v1, Lb15;->i:I

    .line 380
    .line 381
    goto :goto_6

    .line 382
    :cond_c
    move v2, v13

    .line 383
    :goto_6
    if-lez v2, :cond_d

    .line 384
    .line 385
    move/from16 v24, v8

    .line 386
    .line 387
    goto :goto_7

    .line 388
    :cond_d
    move/from16 v24, v13

    .line 389
    .line 390
    :goto_7
    sub-int v5, v15, v2

    .line 391
    .line 392
    sub-int v5, v5, v24

    .line 393
    .line 394
    if-gez v5, :cond_e

    .line 395
    .line 396
    move v5, v13

    .line 397
    :cond_e
    if-eqz v16, :cond_14

    .line 398
    .line 399
    if-eqz v9, :cond_f

    .line 400
    .line 401
    invoke-interface {v9, v10}, Lds3;->g0(I)I

    .line 402
    .line 403
    .line 404
    move-result v6

    .line 405
    goto :goto_8

    .line 406
    :cond_f
    move v6, v13

    .line 407
    :goto_8
    sub-int v7, v5, v8

    .line 408
    .line 409
    if-gez v7, :cond_10

    .line 410
    .line 411
    move v7, v13

    .line 412
    :cond_10
    mul-int/lit8 v7, v7, 0x6

    .line 413
    .line 414
    div-int/lit8 v7, v7, 0xa

    .line 415
    .line 416
    if-le v6, v7, :cond_11

    .line 417
    .line 418
    move/from16 v20, v7

    .line 419
    .line 420
    goto :goto_9

    .line 421
    :cond_11
    move/from16 v20, v6

    .line 422
    .line 423
    :goto_9
    if-eqz v9, :cond_12

    .line 424
    .line 425
    const/16 v22, 0x0

    .line 426
    .line 427
    const/16 v23, 0xd

    .line 428
    .line 429
    const/16 v19, 0x0

    .line 430
    .line 431
    const/16 v21, 0x0

    .line 432
    .line 433
    move-wide/from16 v17, v3

    .line 434
    .line 435
    invoke-static/range {v17 .. v23}, Lb81;->b(JIIIII)J

    .line 436
    .line 437
    .line 438
    move-result-wide v3

    .line 439
    move-wide/from16 v6, v17

    .line 440
    .line 441
    invoke-interface {v9, v3, v4}, Lds3;->e(J)Lb15;

    .line 442
    .line 443
    .line 444
    move-result-object v3

    .line 445
    goto :goto_a

    .line 446
    :cond_12
    move-wide v6, v3

    .line 447
    :cond_13
    const/4 v3, 0x0

    .line 448
    goto :goto_a

    .line 449
    :cond_14
    move-wide v6, v3

    .line 450
    if-eqz v9, :cond_13

    .line 451
    .line 452
    invoke-interface {v9, v6, v7}, Lds3;->e(J)Lb15;

    .line 453
    .line 454
    .line 455
    move-result-object v3

    .line 456
    :goto_a
    if-eqz v3, :cond_15

    .line 457
    .line 458
    iget v4, v3, Lb15;->i:I

    .line 459
    .line 460
    goto :goto_b

    .line 461
    :cond_15
    move v4, v13

    .line 462
    :goto_b
    if-gtz v4, :cond_16

    .line 463
    .line 464
    move v8, v13

    .line 465
    :cond_16
    if-eqz v16, :cond_18

    .line 466
    .line 467
    sub-int/2addr v5, v4

    .line 468
    sub-int/2addr v5, v8

    .line 469
    if-gez v5, :cond_17

    .line 470
    .line 471
    move/from16 v20, v13

    .line 472
    .line 473
    goto :goto_c

    .line 474
    :cond_17
    move/from16 v20, v5

    .line 475
    .line 476
    :goto_c
    const/16 v22, 0x0

    .line 477
    .line 478
    const/16 v23, 0xd

    .line 479
    .line 480
    const/16 v19, 0x0

    .line 481
    .line 482
    const/16 v21, 0x0

    .line 483
    .line 484
    move-wide/from16 v17, v6

    .line 485
    .line 486
    invoke-static/range {v17 .. v23}, Lb81;->b(JIIIII)J

    .line 487
    .line 488
    .line 489
    move-result-wide v5

    .line 490
    goto :goto_d

    .line 491
    :cond_18
    move-wide/from16 v17, v6

    .line 492
    .line 493
    move-wide/from16 v5, v17

    .line 494
    .line 495
    :goto_d
    invoke-interface {v14, v5, v6}, Lds3;->e(J)Lb15;

    .line 496
    .line 497
    .line 498
    move-result-object v5

    .line 499
    if-eqz v1, :cond_19

    .line 500
    .line 501
    iget v6, v1, Lb15;->j:I

    .line 502
    .line 503
    goto :goto_e

    .line 504
    :cond_19
    move v6, v13

    .line 505
    :goto_e
    if-eqz v3, :cond_1a

    .line 506
    .line 507
    iget v13, v3, Lb15;->j:I

    .line 508
    .line 509
    :cond_1a
    iget v7, v5, Lb15;->j:I

    .line 510
    .line 511
    invoke-static {v7, v13}, Ljava/lang/Math;->max(II)I

    .line 512
    .line 513
    .line 514
    move-result v7

    .line 515
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    .line 516
    .line 517
    .line 518
    move-result v7

    .line 519
    invoke-static/range {p3 .. p4}, Lb81;->j(J)I

    .line 520
    .line 521
    .line 522
    move-result v9

    .line 523
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 524
    .line 525
    .line 526
    move-result-object v11

    .line 527
    const v14, 0x7fffffff

    .line 528
    .line 529
    .line 530
    if-eq v10, v14, :cond_1b

    .line 531
    .line 532
    move-object v10, v11

    .line 533
    goto :goto_f

    .line 534
    :cond_1b
    const/4 v10, 0x0

    .line 535
    :goto_f
    if-eqz v10, :cond_1c

    .line 536
    .line 537
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 538
    .line 539
    .line 540
    move-result v10

    .line 541
    goto :goto_10

    .line 542
    :cond_1c
    move v10, v7

    .line 543
    :goto_10
    invoke-static {v7, v9, v10}, Lhb3;->C(III)I

    .line 544
    .line 545
    .line 546
    move-result v9

    .line 547
    if-nez v16, :cond_1e

    .line 548
    .line 549
    add-int v10, v2, v24

    .line 550
    .line 551
    iget v11, v5, Lb15;->i:I

    .line 552
    .line 553
    add-int/2addr v10, v11

    .line 554
    add-int/2addr v10, v8

    .line 555
    add-int/2addr v10, v4

    .line 556
    invoke-static/range {p3 .. p4}, Lb81;->k(J)I

    .line 557
    .line 558
    .line 559
    move-result v4

    .line 560
    if-ge v10, v4, :cond_1d

    .line 561
    .line 562
    move v15, v4

    .line 563
    goto :goto_11

    .line 564
    :cond_1d
    move v15, v10

    .line 565
    :cond_1e
    :goto_11
    move/from16 v26, v15

    .line 566
    .line 567
    new-instance v17, Lvz0;

    .line 568
    .line 569
    move-object/from16 v22, v1

    .line 570
    .line 571
    move/from16 v23, v2

    .line 572
    .line 573
    move-object/from16 v25, v3

    .line 574
    .line 575
    move-object/from16 v20, v5

    .line 576
    .line 577
    move/from16 v19, v6

    .line 578
    .line 579
    move/from16 v18, v7

    .line 580
    .line 581
    move/from16 v21, v13

    .line 582
    .line 583
    invoke-direct/range {v17 .. v26}, Lvz0;-><init>(IILb15;ILb15;IILb15;I)V

    .line 584
    .line 585
    .line 586
    move-object/from16 v1, v17

    .line 587
    .line 588
    move/from16 v15, v26

    .line 589
    .line 590
    invoke-interface {v0, v15, v9, v12, v1}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 591
    .line 592
    .line 593
    move-result-object v10

    .line 594
    goto :goto_12

    .line 595
    :cond_1f
    invoke-static {v9}, Lry4;->i(Ljava/lang/String;)V

    .line 596
    .line 597
    .line 598
    const/4 v10, 0x0

    .line 599
    :goto_12
    return-object v10

    .line 600
    :pswitch_6
    invoke-static/range {p3 .. p4}, Lb81;->k(J)I

    .line 601
    .line 602
    .line 603
    move-result v1

    .line 604
    invoke-static/range {p3 .. p4}, Lb81;->j(J)I

    .line 605
    .line 606
    .line 607
    move-result v2

    .line 608
    new-instance v3, Ldb0;

    .line 609
    .line 610
    const/16 v4, 0x9

    .line 611
    .line 612
    invoke-direct {v3, v4}, Ldb0;-><init>(B)V

    .line 613
    .line 614
    .line 615
    invoke-interface {v0, v1, v2, v12, v3}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 616
    .line 617
    .line 618
    move-result-object v0

    .line 619
    return-object v0

    .line 620
    :pswitch_7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 621
    .line 622
    .line 623
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 624
    .line 625
    .line 626
    move-result v2

    .line 627
    move v3, v13

    .line 628
    :goto_13
    if-ge v3, v2, :cond_23

    .line 629
    .line 630
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 631
    .line 632
    .line 633
    move-result-object v4

    .line 634
    move-object v10, v4

    .line 635
    check-cast v10, Lds3;

    .line 636
    .line 637
    invoke-static {v10}, Lr71;->v(Lds3;)Ljava/lang/Object;

    .line 638
    .line 639
    .line 640
    move-result-object v4

    .line 641
    const-string v5, "badge"

    .line 642
    .line 643
    invoke-static {v4, v5}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 644
    .line 645
    .line 646
    move-result v4

    .line 647
    if-eqz v4, :cond_22

    .line 648
    .line 649
    const/4 v7, 0x0

    .line 650
    const/16 v8, 0xb

    .line 651
    .line 652
    const/4 v4, 0x0

    .line 653
    const/4 v5, 0x0

    .line 654
    const/4 v6, 0x0

    .line 655
    move-wide/from16 v2, p3

    .line 656
    .line 657
    invoke-static/range {v2 .. v8}, Lb81;->b(JIIIII)J

    .line 658
    .line 659
    .line 660
    move-result-wide v4

    .line 661
    move-wide v6, v2

    .line 662
    invoke-interface {v10, v4, v5}, Lds3;->e(J)Lb15;

    .line 663
    .line 664
    .line 665
    move-result-object v2

    .line 666
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 667
    .line 668
    .line 669
    move-result v3

    .line 670
    move v4, v13

    .line 671
    :goto_14
    if-ge v4, v3, :cond_21

    .line 672
    .line 673
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 674
    .line 675
    .line 676
    move-result-object v5

    .line 677
    check-cast v5, Lds3;

    .line 678
    .line 679
    invoke-static {v5}, Lr71;->v(Lds3;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v8

    .line 683
    const-string v10, "anchor"

    .line 684
    .line 685
    invoke-static {v8, v10}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 686
    .line 687
    .line 688
    move-result v8

    .line 689
    if-eqz v8, :cond_20

    .line 690
    .line 691
    invoke-interface {v5, v6, v7}, Lds3;->e(J)Lb15;

    .line 692
    .line 693
    .line 694
    move-result-object v1

    .line 695
    sget-object v3, Lk8;->a:Lat2;

    .line 696
    .line 697
    invoke-virtual {v1, v3}, Lb15;->k0(Lh8;)I

    .line 698
    .line 699
    .line 700
    move-result v4

    .line 701
    sget-object v5, Lk8;->b:Lat2;

    .line 702
    .line 703
    invoke-virtual {v1, v5}, Lb15;->k0(Lh8;)I

    .line 704
    .line 705
    .line 706
    move-result v6

    .line 707
    iget v7, v1, Lb15;->i:I

    .line 708
    .line 709
    iget v8, v1, Lb15;->j:I

    .line 710
    .line 711
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 712
    .line 713
    .line 714
    move-result-object v4

    .line 715
    new-instance v9, Lkx4;

    .line 716
    .line 717
    invoke-direct {v9, v3, v4}, Lkx4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 718
    .line 719
    .line 720
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 721
    .line 722
    .line 723
    move-result-object v3

    .line 724
    new-instance v4, Lkx4;

    .line 725
    .line 726
    invoke-direct {v4, v5, v3}, Lkx4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 727
    .line 728
    .line 729
    filled-new-array {v9, v4}, [Lkx4;

    .line 730
    .line 731
    .line 732
    move-result-object v3

    .line 733
    invoke-static {v3}, Lcq3;->k0([Lkx4;)Ljava/util/Map;

    .line 734
    .line 735
    .line 736
    move-result-object v3

    .line 737
    new-instance v4, Ltz;

    .line 738
    .line 739
    invoke-direct {v4, v2, v1, v13}, Ltz;-><init>(Lb15;Lb15;B)V

    .line 740
    .line 741
    .line 742
    invoke-interface {v0, v7, v8, v3, v4}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 743
    .line 744
    .line 745
    move-result-object v0

    .line 746
    return-object v0

    .line 747
    :cond_20
    add-int/lit8 v4, v4, 0x1

    .line 748
    .line 749
    goto :goto_14

    .line 750
    :cond_21
    invoke-static {v9}, Lxk6;->B(Ljava/lang/String;)Lzy0;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    throw v0

    .line 755
    :cond_22
    add-int/lit8 v3, v3, 0x1

    .line 756
    .line 757
    goto/16 :goto_13

    .line 758
    .line 759
    :cond_23
    invoke-static {v9}, Lxk6;->B(Ljava/lang/String;)Lzy0;

    .line 760
    .line 761
    .line 762
    move-result-object v0

    .line 763
    throw v0

    .line 764
    :pswitch_8
    move-wide v6, v3

    .line 765
    new-instance v2, Ljava/util/ArrayList;

    .line 766
    .line 767
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 768
    .line 769
    .line 770
    move-result v3

    .line 771
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 772
    .line 773
    .line 774
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 775
    .line 776
    .line 777
    move-result v3

    .line 778
    :goto_15
    if-ge v13, v3, :cond_24

    .line 779
    .line 780
    invoke-interface {v1, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 781
    .line 782
    .line 783
    move-result-object v4

    .line 784
    check-cast v4, Lds3;

    .line 785
    .line 786
    invoke-interface {v4, v6, v7}, Lds3;->e(J)Lb15;

    .line 787
    .line 788
    .line 789
    move-result-object v4

    .line 790
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 791
    .line 792
    .line 793
    add-int/lit8 v13, v13, 0x1

    .line 794
    .line 795
    goto :goto_15

    .line 796
    :cond_24
    invoke-static {v6, v7}, Lb81;->i(J)I

    .line 797
    .line 798
    .line 799
    move-result v1

    .line 800
    invoke-static {v6, v7}, Lb81;->h(J)I

    .line 801
    .line 802
    .line 803
    move-result v3

    .line 804
    new-instance v4, Lzb;

    .line 805
    .line 806
    invoke-direct {v4, v2, v11}, Lzb;-><init>(Ljava/util/ArrayList;B)V

    .line 807
    .line 808
    .line 809
    invoke-interface {v0, v1, v3, v12, v4}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 810
    .line 811
    .line 812
    move-result-object v0

    .line 813
    return-object v0

    .line 814
    :pswitch_9
    move-wide v6, v3

    .line 815
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 816
    .line 817
    .line 818
    move-result v2

    .line 819
    if-eqz v2, :cond_27

    .line 820
    .line 821
    if-eq v2, v11, :cond_26

    .line 822
    .line 823
    new-instance v2, Ljava/util/ArrayList;

    .line 824
    .line 825
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 826
    .line 827
    .line 828
    move-result v3

    .line 829
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 830
    .line 831
    .line 832
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 833
    .line 834
    .line 835
    move-result v3

    .line 836
    move v4, v13

    .line 837
    move v5, v4

    .line 838
    move v8, v5

    .line 839
    :goto_16
    if-ge v4, v3, :cond_25

    .line 840
    .line 841
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 842
    .line 843
    .line 844
    move-result-object v9

    .line 845
    check-cast v9, Lds3;

    .line 846
    .line 847
    invoke-interface {v9, v6, v7}, Lds3;->e(J)Lb15;

    .line 848
    .line 849
    .line 850
    move-result-object v9

    .line 851
    iget v10, v9, Lb15;->i:I

    .line 852
    .line 853
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 854
    .line 855
    .line 856
    move-result v5

    .line 857
    iget v10, v9, Lb15;->j:I

    .line 858
    .line 859
    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    .line 860
    .line 861
    .line 862
    move-result v8

    .line 863
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 864
    .line 865
    .line 866
    add-int/lit8 v4, v4, 0x1

    .line 867
    .line 868
    goto :goto_16

    .line 869
    :cond_25
    new-instance v1, Lwd;

    .line 870
    .line 871
    invoke-direct {v1, v2, v13}, Lwd;-><init>(Ljava/util/ArrayList;B)V

    .line 872
    .line 873
    .line 874
    invoke-interface {v0, v5, v8, v12, v1}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 875
    .line 876
    .line 877
    move-result-object v0

    .line 878
    goto :goto_17

    .line 879
    :cond_26
    invoke-interface {v1, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 880
    .line 881
    .line 882
    move-result-object v1

    .line 883
    check-cast v1, Lds3;

    .line 884
    .line 885
    invoke-interface {v1, v6, v7}, Lds3;->e(J)Lb15;

    .line 886
    .line 887
    .line 888
    move-result-object v1

    .line 889
    iget v2, v1, Lb15;->i:I

    .line 890
    .line 891
    iget v3, v1, Lb15;->j:I

    .line 892
    .line 893
    new-instance v4, Lvd;

    .line 894
    .line 895
    invoke-direct {v4, v1, v13}, Lvd;-><init>(Ljava/lang/Object;B)V

    .line 896
    .line 897
    .line 898
    invoke-interface {v0, v2, v3, v12, v4}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 899
    .line 900
    .line 901
    move-result-object v0

    .line 902
    goto :goto_17

    .line 903
    :cond_27
    sget-object v1, Lud;->j:Lud;

    .line 904
    .line 905
    invoke-interface {v0, v13, v13, v12, v1}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 906
    .line 907
    .line 908
    move-result-object v0

    .line 909
    :goto_17
    return-object v0

    .line 910
    :pswitch_a
    move-wide v6, v3

    .line 911
    new-instance v2, Ljava/util/ArrayList;

    .line 912
    .line 913
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 914
    .line 915
    .line 916
    move-result v3

    .line 917
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 918
    .line 919
    .line 920
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 921
    .line 922
    .line 923
    move-result v3

    .line 924
    move v4, v13

    .line 925
    move v5, v4

    .line 926
    move v8, v5

    .line 927
    :goto_18
    if-ge v4, v3, :cond_28

    .line 928
    .line 929
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 930
    .line 931
    .line 932
    move-result-object v9

    .line 933
    check-cast v9, Lds3;

    .line 934
    .line 935
    invoke-interface {v9, v6, v7}, Lds3;->e(J)Lb15;

    .line 936
    .line 937
    .line 938
    move-result-object v9

    .line 939
    iget v10, v9, Lb15;->i:I

    .line 940
    .line 941
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 942
    .line 943
    .line 944
    move-result v5

    .line 945
    iget v10, v9, Lb15;->j:I

    .line 946
    .line 947
    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    .line 948
    .line 949
    .line 950
    move-result v8

    .line 951
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 952
    .line 953
    .line 954
    add-int/lit8 v4, v4, 0x1

    .line 955
    .line 956
    goto :goto_18

    .line 957
    :cond_28
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 958
    .line 959
    .line 960
    move-result v1

    .line 961
    if-eqz v1, :cond_29

    .line 962
    .line 963
    invoke-static {v6, v7}, Lb81;->k(J)I

    .line 964
    .line 965
    .line 966
    move-result v5

    .line 967
    invoke-static {v6, v7}, Lb81;->j(J)I

    .line 968
    .line 969
    .line 970
    move-result v8

    .line 971
    :cond_29
    new-instance v1, Lzb;

    .line 972
    .line 973
    invoke-direct {v1, v2, v13}, Lzb;-><init>(Ljava/util/ArrayList;B)V

    .line 974
    .line 975
    .line 976
    invoke-interface {v0, v5, v8, v12, v1}, Lks3;->P0(IILjava/util/Map;Lqa2;)Ljs3;

    .line 977
    .line 978
    .line 979
    move-result-object v0

    .line 980
    return-object v0

    .line 981
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
