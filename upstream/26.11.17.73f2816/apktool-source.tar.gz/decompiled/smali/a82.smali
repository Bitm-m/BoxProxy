.class public final La82;
.super Lil1;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lw86;
.implements Llh2;
.implements Lz21;
.implements Ldm4;
.implements Lca7;


# static fields
.field public static final E:Lv21;


# instance fields
.field public A:Lv62;

.field public B:Lkd3;

.field public C:Lij4;

.field public final D:Lv72;

.field public y:Lw34;

.field public final z:Lqa2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lv21;

    .line 2
    .line 3
    const/16 v1, 0xe

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lv21;-><init>(B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, La82;->E:Lv21;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Lw34;ILqa2;)V
    .locals 8

    .line 1
    invoke-direct {p0}, Lil1;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La82;->y:Lw34;

    .line 5
    .line 6
    iput-object p3, p0, La82;->z:Lqa2;

    .line 7
    .line 8
    new-instance v0, Lr72;

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    const/4 v7, 0x1

    .line 12
    const/4 v1, 0x2

    .line 13
    const-class v3, La82;

    .line 14
    .line 15
    const-string v4, "onFocusStateChange"

    .line 16
    .line 17
    const-string v5, "onFocusStateChange(Landroidx/compose/ui/focus/FocusState;Landroidx/compose/ui/focus/FocusState;)V"

    .line 18
    .line 19
    move-object v2, p0

    .line 20
    invoke-direct/range {v0 .. v7}, Lr72;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 21
    .line 22
    .line 23
    new-instance p0, Lv72;

    .line 24
    .line 25
    const/16 p1, 0xa

    .line 26
    .line 27
    invoke-direct {p0, p2, v0, p1}, Lv72;-><init>(ILua2;I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v2, p0}, Lil1;->G1(Lhl1;)V

    .line 31
    .line 32
    .line 33
    iput-object p0, v2, La82;->D:Lv72;

    .line 34
    .line 35
    return-void
.end method

.method public constructor <init>(Lw34;Lyx6;I)V
    .locals 0

    and-int/lit8 p3, p3, 0x4

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    const/4 p3, 0x1

    .line 36
    invoke-direct {p0, p1, p3, p2}, La82;-><init>(Lw34;ILqa2;)V

    return-void
.end method


# virtual methods
.method public final A1()V
    .locals 1

    .line 1
    iget-object v0, p0, La82;->B:Lkd3;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Lkd3;->b()V

    .line 6
    .line 7
    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, La82;->B:Lkd3;

    .line 10
    .line 11
    return-void
.end method

.method public final F(Lij4;)V
    .locals 1

    .line 1
    iput-object p1, p0, La82;->C:Lij4;

    .line 2
    .line 3
    iget-object v0, p0, La82;->D:Lv72;

    .line 4
    .line 5
    invoke-virtual {v0}, Lv72;->L1()Lp72;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Lp72;->b()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {p1}, Lij4;->z1()Lh14;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    iget-boolean p1, p1, Lh14;->v:Z

    .line 20
    .line 21
    if-eqz p1, :cond_1

    .line 22
    .line 23
    iget-object p1, p0, La82;->C:Lij4;

    .line 24
    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    invoke-virtual {p1}, Lij4;->z1()Lh14;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    iget-boolean p1, p1, Lh14;->v:Z

    .line 32
    .line 33
    if-eqz p1, :cond_0

    .line 34
    .line 35
    invoke-virtual {p0}, La82;->K1()V

    .line 36
    .line 37
    .line 38
    :cond_0
    return-void

    .line 39
    :cond_1
    invoke-virtual {p0}, La82;->K1()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final J1(Lw34;Lx62;)V
    .locals 7

    .line 1
    iget-boolean v0, p0, Lh14;->v:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-virtual {p0}, Lh14;->u1()Lrf1;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lga1;

    .line 10
    .line 11
    iget-object v0, v0, Lga1;->i:Lhf1;

    .line 12
    .line 13
    sget-object v1, Lyy1;->r:Lyy1;

    .line 14
    .line 15
    invoke-interface {v0, v1}, Lhf1;->p(Lgf1;)Lff1;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lf43;

    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    new-instance v1, Lk2;

    .line 25
    .line 26
    const/16 v2, 0x1a

    .line 27
    .line 28
    invoke-direct {v1, p1, p2, v2}, Lk2;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 29
    .line 30
    .line 31
    invoke-interface {v0, v1}, Lf43;->x(Lqa2;)Lvo1;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    move-object v4, v0

    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move-object v4, v5

    .line 38
    :goto_0
    invoke-virtual {p0}, Lh14;->u1()Lrf1;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    new-instance v1, Ln2;

    .line 43
    .line 44
    const/16 v6, 0x1c

    .line 45
    .line 46
    move-object v2, p1

    .line 47
    move-object v3, p2

    .line 48
    invoke-direct/range {v1 .. v6}, Ln2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 49
    .line 50
    .line 51
    const/4 p1, 0x3

    .line 52
    invoke-static {p0, v5, v5, v1, p1}, Lom;->Z(Lrf1;Lb3;Luf1;Lua2;I)Lcm6;

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_1
    move-object v2, p1

    .line 57
    move-object v3, p2

    .line 58
    invoke-virtual {v2, v3}, Lw34;->c(Lr13;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method public final K1()V
    .locals 10

    .line 1
    iget-boolean v0, p0, Lh14;->v:Z

    .line 2
    .line 3
    if-eqz v0, :cond_c

    .line 4
    .line 5
    iget-object v0, p0, Lh14;->i:Lh14;

    .line 6
    .line 7
    iget-boolean v0, v0, Lh14;->v:Z

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const-string v0, "visitAncestors called on an unattached node"

    .line 12
    .line 13
    invoke-static {v0}, Lwy2;->b(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, Lh14;->i:Lh14;

    .line 17
    .line 18
    iget-object v0, v0, Lh14;->m:Lh14;

    .line 19
    .line 20
    invoke-static {p0}, Lgj;->Z(Lhl1;)Lja3;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    :goto_0
    if-eqz p0, :cond_c

    .line 25
    .line 26
    iget-object v1, p0, Lja3;->N:Ll9;

    .line 27
    .line 28
    iget-object v1, v1, Ll9;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v1, Lh14;

    .line 31
    .line 32
    iget v1, v1, Lh14;->l:I

    .line 33
    .line 34
    const/high16 v2, 0x40000

    .line 35
    .line 36
    and-int/2addr v1, v2

    .line 37
    const/4 v3, 0x0

    .line 38
    if-eqz v1, :cond_a

    .line 39
    .line 40
    :goto_1
    if-eqz v0, :cond_a

    .line 41
    .line 42
    iget v1, v0, Lh14;->k:I

    .line 43
    .line 44
    and-int/2addr v1, v2

    .line 45
    if-eqz v1, :cond_9

    .line 46
    .line 47
    move-object v1, v0

    .line 48
    move-object v4, v3

    .line 49
    :cond_1
    :goto_2
    if-eqz v1, :cond_9

    .line 50
    .line 51
    instance-of v5, v1, Lca7;

    .line 52
    .line 53
    if-eqz v5, :cond_2

    .line 54
    .line 55
    move-object v5, v1

    .line 56
    check-cast v5, Lca7;

    .line 57
    .line 58
    invoke-interface {v5}, Lca7;->d()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    sget-object v6, Lb82;->w:Lv21;

    .line 63
    .line 64
    if-ne v6, v5, :cond_2

    .line 65
    .line 66
    return-void

    .line 67
    :cond_2
    iget v5, v1, Lh14;->k:I

    .line 68
    .line 69
    and-int/2addr v5, v2

    .line 70
    if-eqz v5, :cond_8

    .line 71
    .line 72
    instance-of v5, v1, Lil1;

    .line 73
    .line 74
    if-eqz v5, :cond_8

    .line 75
    .line 76
    move-object v5, v1

    .line 77
    check-cast v5, Lil1;

    .line 78
    .line 79
    iget-object v5, v5, Lil1;->x:Lh14;

    .line 80
    .line 81
    const/4 v6, 0x0

    .line 82
    move v7, v6

    .line 83
    :goto_3
    const/4 v8, 0x1

    .line 84
    if-eqz v5, :cond_7

    .line 85
    .line 86
    iget v9, v5, Lh14;->k:I

    .line 87
    .line 88
    and-int/2addr v9, v2

    .line 89
    if-eqz v9, :cond_6

    .line 90
    .line 91
    add-int/lit8 v7, v7, 0x1

    .line 92
    .line 93
    if-ne v7, v8, :cond_3

    .line 94
    .line 95
    move-object v1, v5

    .line 96
    goto :goto_4

    .line 97
    :cond_3
    if-nez v4, :cond_4

    .line 98
    .line 99
    new-instance v4, Ly44;

    .line 100
    .line 101
    const/16 v8, 0x10

    .line 102
    .line 103
    new-array v8, v8, [Lh14;

    .line 104
    .line 105
    invoke-direct {v4, v6, v8}, Ly44;-><init>(I[Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    :cond_4
    if-eqz v1, :cond_5

    .line 109
    .line 110
    invoke-virtual {v4, v1}, Ly44;->b(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    move-object v1, v3

    .line 114
    :cond_5
    invoke-virtual {v4, v5}, Ly44;->b(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_6
    :goto_4
    iget-object v5, v5, Lh14;->n:Lh14;

    .line 118
    .line 119
    goto :goto_3

    .line 120
    :cond_7
    if-eq v7, v8, :cond_1

    .line 121
    .line 122
    :cond_8
    invoke-static {v4}, Lgj;->N(Ly44;)Lh14;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    goto :goto_2

    .line 127
    :cond_9
    iget-object v0, v0, Lh14;->m:Lh14;

    .line 128
    .line 129
    goto :goto_1

    .line 130
    :cond_a
    invoke-virtual {p0}, Lja3;->u()Lja3;

    .line 131
    .line 132
    .line 133
    move-result-object p0

    .line 134
    if-eqz p0, :cond_b

    .line 135
    .line 136
    iget-object v0, p0, Lja3;->N:Ll9;

    .line 137
    .line 138
    if-eqz v0, :cond_b

    .line 139
    .line 140
    iget-object v0, v0, Ll9;->f:Ljava/lang/Object;

    .line 141
    .line 142
    check-cast v0, Lyu6;

    .line 143
    .line 144
    goto :goto_0

    .line 145
    :cond_b
    move-object v0, v3

    .line 146
    goto :goto_0

    .line 147
    :cond_c
    return-void
.end method

.method public final L1(Lw34;)V
    .locals 3

    .line 1
    iget-object v0, p0, La82;->y:Lw34;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    iget-object v0, p0, La82;->y:Lw34;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, La82;->A:Lv62;

    .line 14
    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    new-instance v2, Lw62;

    .line 18
    .line 19
    invoke-direct {v2, v1}, Lw62;-><init>(Lv62;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0, v2}, Lw34;->c(Lr13;)V

    .line 23
    .line 24
    .line 25
    :cond_0
    const/4 v0, 0x0

    .line 26
    iput-object v0, p0, La82;->A:Lv62;

    .line 27
    .line 28
    iput-object p1, p0, La82;->y:Lw34;

    .line 29
    .line 30
    :cond_1
    return-void
.end method

.method public final R0(Lf96;)V
    .locals 10

    .line 1
    iget-object v0, p0, La82;->D:Lv72;

    .line 2
    .line 3
    invoke-virtual {v0}, Lv72;->L1()Lp72;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lp72;->b()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    sget-object v1, Ld96;->a:[Lp73;

    .line 12
    .line 13
    sget-object v1, Lc96;->l:Le96;

    .line 14
    .line 15
    sget-object v2, Ld96;->a:[Lp73;

    .line 16
    .line 17
    const/4 v3, 0x4

    .line 18
    aget-object v2, v2, v3

    .line 19
    .line 20
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-interface {p1, v1, v0}, Lf96;->a(Le96;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    new-instance v2, Loh1;

    .line 31
    .line 32
    const/4 v8, 0x0

    .line 33
    const/16 v9, 0x8

    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    const-class v5, La82;

    .line 37
    .line 38
    const-string v6, "requestFocus"

    .line 39
    .line 40
    const-string v7, "requestFocus()Z"

    .line 41
    .line 42
    move-object v4, p0

    .line 43
    invoke-direct/range {v2 .. v9}, Loh1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 44
    .line 45
    .line 46
    sget-object p0, Ls86;->w:Le96;

    .line 47
    .line 48
    new-instance v0, Lp4;

    .line 49
    .line 50
    const/4 v1, 0x0

    .line 51
    invoke-direct {v0, v1, v2}, Lp4;-><init>(Ljava/lang/String;Lcb2;)V

    .line 52
    .line 53
    .line 54
    invoke-interface {p1, p0, v0}, Lf96;->a(Le96;Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final d()Ljava/lang/Object;
    .locals 0

    .line 1
    sget-object p0, La82;->E:Lv21;

    .line 2
    .line 3
    return-object p0
.end method

.method public final g0()V
    .locals 3

    .line 1
    new-instance v0, Lbl5;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lt72;

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-direct {v1, v0, p0, v2}, Lt72;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 10
    .line 11
    .line 12
    invoke-static {p0, v1}, Ltc3;->P(Lh14;Lfa2;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, v0, Lbl5;->i:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lkd3;

    .line 18
    .line 19
    iget-object v1, p0, La82;->D:Lv72;

    .line 20
    .line 21
    invoke-virtual {v1}, Lv72;->L1()Lp72;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v1}, Lp72;->b()Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_2

    .line 30
    .line 31
    iget-object v1, p0, La82;->B:Lkd3;

    .line 32
    .line 33
    if-eqz v1, :cond_0

    .line 34
    .line 35
    invoke-virtual {v1}, Lkd3;->b()V

    .line 36
    .line 37
    .line 38
    :cond_0
    if-eqz v0, :cond_1

    .line 39
    .line 40
    invoke-virtual {v0}, Lkd3;->a()Lkd3;

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    const/4 v0, 0x0

    .line 45
    :goto_0
    iput-object v0, p0, La82;->B:Lkd3;

    .line 46
    .line 47
    :cond_2
    return-void
.end method

.method public final v1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
