.class public interface abstract Lam0;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqs3;


# virtual methods
.method public abstract b()Lok0;
.end method

.method public abstract c()Ljava/lang/Double;
.end method

.method public abstract f()Lkl0;
.end method

.method public abstract i()Ljava/lang/Integer;
.end method

.method public abstract m()Ltl0;
.end method
