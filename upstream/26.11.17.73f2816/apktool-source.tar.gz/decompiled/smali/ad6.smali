.class public final synthetic Lad6;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljc6;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Ljava/lang/String;

.field public final synthetic m:Lmc6;


# direct methods
.method public synthetic constructor <init>(Ljc6;Ljava/lang/String;Ljava/lang/String;Lmc6;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lad6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lad6;->j:Ljc6;

    .line 4
    .line 5
    iput-object p2, p0, Lad6;->k:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lad6;->l:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p4, p0, Lad6;->m:Lmc6;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte v0, p0, Lad6;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    check-cast p1, Lce3;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    new-instance v5, Ltc6;

    .line 17
    .line 18
    const/4 v10, 0x2

    .line 19
    iget-object v6, p0, Lad6;->j:Ljc6;

    .line 20
    .line 21
    iget-object v7, p0, Lad6;->k:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v8, p0, Lad6;->l:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v9, p0, Lad6;->m:Lmc6;

    .line 26
    .line 27
    invoke-direct/range {v5 .. v10}, Ltc6;-><init>(Ljc6;Ljava/lang/String;Ljava/lang/String;Lmc6;B)V

    .line 28
    .line 29
    .line 30
    new-instance p0, Lc01;

    .line 31
    .line 32
    const v0, -0x44986733

    .line 33
    .line 34
    .line 35
    invoke-direct {p0, v0, v3, v5}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    invoke-static {p1, v4, p0, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 39
    .line 40
    .line 41
    return-object v1

    .line 42
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    new-instance v5, Ltc6;

    .line 46
    .line 47
    const/4 v10, 0x0

    .line 48
    iget-object v6, p0, Lad6;->j:Ljc6;

    .line 49
    .line 50
    iget-object v7, p0, Lad6;->k:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v8, p0, Lad6;->l:Ljava/lang/String;

    .line 53
    .line 54
    iget-object v9, p0, Lad6;->m:Lmc6;

    .line 55
    .line 56
    invoke-direct/range {v5 .. v10}, Ltc6;-><init>(Ljc6;Ljava/lang/String;Ljava/lang/String;Lmc6;B)V

    .line 57
    .line 58
    .line 59
    new-instance p0, Lc01;

    .line 60
    .line 61
    const v0, -0x3c51e7b4

    .line 62
    .line 63
    .line 64
    invoke-direct {p0, v0, v3, v5}, Lc01;-><init>(IZLjava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    invoke-static {p1, v4, p0, v2}, Lce3;->O(Lce3;Ljava/lang/String;Lva2;I)V

    .line 68
    .line 69
    .line 70
    return-object v1

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
