.class public final synthetic Lan3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Li14;

.field public final synthetic j:Lam3;

.field public final synthetic k:Z

.field public final synthetic l:Lfa2;

.field public final synthetic m:Lqa2;

.field public final synthetic n:Lwl3;

.field public final synthetic o:Ljava/lang/String;

.field public final synthetic p:J

.field public final synthetic q:Lpj0;


# direct methods
.method public synthetic constructor <init>(Li14;Lam3;ZLfa2;Lqa2;Lwl3;Ljava/lang/String;JLpj0;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lan3;->i:Li14;

    .line 5
    .line 6
    iput-object p2, p0, Lan3;->j:Lam3;

    .line 7
    .line 8
    iput-boolean p3, p0, Lan3;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Lan3;->l:Lfa2;

    .line 11
    .line 12
    iput-object p5, p0, Lan3;->m:Lqa2;

    .line 13
    .line 14
    iput-object p6, p0, Lan3;->n:Lwl3;

    .line 15
    .line 16
    iput-object p7, p0, Lan3;->o:Ljava/lang/String;

    .line 17
    .line 18
    iput-wide p8, p0, Lan3;->p:J

    .line 19
    .line 20
    iput-object p10, p0, Lan3;->q:Lpj0;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    move-object v10, p1

    .line 2
    check-cast v10, Lub2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x7

    .line 10
    invoke-static {p1}, Lub3;->b0(I)I

    .line 11
    .line 12
    .line 13
    move-result v11

    .line 14
    iget-object v0, p0, Lan3;->i:Li14;

    .line 15
    .line 16
    iget-object v1, p0, Lan3;->j:Lam3;

    .line 17
    .line 18
    iget-boolean v2, p0, Lan3;->k:Z

    .line 19
    .line 20
    iget-object v3, p0, Lan3;->l:Lfa2;

    .line 21
    .line 22
    iget-object v4, p0, Lan3;->m:Lqa2;

    .line 23
    .line 24
    iget-object v5, p0, Lan3;->n:Lwl3;

    .line 25
    .line 26
    iget-object v6, p0, Lan3;->o:Ljava/lang/String;

    .line 27
    .line 28
    iget-wide v7, p0, Lan3;->p:J

    .line 29
    .line 30
    iget-object v9, p0, Lan3;->q:Lpj0;

    .line 31
    .line 32
    invoke-static/range {v0 .. v11}, Ly60;->n(Li14;Lam3;ZLfa2;Lqa2;Lwl3;Ljava/lang/String;JLpj0;Lub2;I)V

    .line 33
    .line 34
    .line 35
    sget-object p0, Lne7;->a:Lne7;

    .line 36
    .line 37
    return-object p0
.end method
