.class public interface abstract Lab2;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lcb2;


# virtual methods
.method public abstract j(Ljava/lang/String;Ljava/lang/Boolean;Lca1;Ljava/lang/Object;Ljava/lang/Object;Lub2;Ljava/lang/Integer;)Ljava/lang/Object;
.end method
