.class final La03;
.super Lr14;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lr14;"
    }
.end annotation


# instance fields
.field public final i:Lkm7;


# direct methods
.method public constructor <init>(Lkm7;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La03;->i:Lkm7;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lh14;
    .locals 1

    .line 1
    new-instance v0, Lb03;

    .line 2
    .line 3
    iget-object p0, p0, La03;->i:Lkm7;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Lb03;-><init>(Lkm7;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final b(Lh14;)V
    .locals 1

    .line 1
    check-cast p1, Lb03;

    .line 2
    .line 3
    iget-object v0, p1, Lb03;->y:Lkm7;

    .line 4
    .line 5
    iget-object p0, p0, La03;->i:Lkm7;

    .line 6
    .line 7
    invoke-static {p0, v0}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iput-object p0, p1, Lb03;->y:Lkm7;

    .line 14
    .line 15
    invoke-virtual {p1}, Lb03;->H1()V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_0
    instance-of v0, p1, La03;

    .line 6
    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    check-cast p1, La03;

    .line 12
    .line 13
    iget-object p1, p1, La03;->i:Lkm7;

    .line 14
    .line 15
    iget-object p0, p0, La03;->i:Lkm7;

    .line 16
    .line 17
    invoke-static {p1, p0}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, La03;->i:Lkm7;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
