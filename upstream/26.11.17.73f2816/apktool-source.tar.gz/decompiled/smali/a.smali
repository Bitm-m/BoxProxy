.class public abstract La;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final a:[B


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lqh0;->l:Lqh0;

    .line 2
    .line 3
    const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    .line 4
    .line 5
    invoke-static {v0}, Ls9;->l(Ljava/lang/String;)Lqh0;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v0, v0, Lqh0;->i:[B

    .line 10
    .line 11
    sput-object v0, La;->a:[B

    .line 12
    .line 13
    const-string v0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    .line 14
    .line 15
    invoke-static {v0}, Ls9;->l(Ljava/lang/String;)Lqh0;

    .line 16
    .line 17
    .line 18
    return-void
.end method
