.class public final Lak1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lds3;


# instance fields
.field public final synthetic i:B

.field public final j:Lds3;

.field public final k:Ljava/lang/Enum;

.field public final l:Ljava/lang/Enum;


# direct methods
.method public synthetic constructor <init>(Lds3;Ljava/lang/Enum;Ljava/lang/Enum;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lak1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lak1;->j:Lds3;

    .line 4
    .line 5
    iput-object p2, p0, Lak1;->k:Ljava/lang/Enum;

    .line 6
    .line 7
    iput-object p3, p0, Lak1;->l:Ljava/lang/Enum;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final S(I)I
    .locals 1

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 7
    .line 8
    invoke-interface {p0, p1}, Lds3;->S(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 14
    .line 15
    invoke-interface {p0, p1}, Lds3;->S(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 21
    .line 22
    invoke-interface {p0, p1}, Lds3;->S(I)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final e(J)Lb15;
    .locals 6

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    iget-object v1, p0, Lak1;->k:Ljava/lang/Enum;

    .line 4
    .line 5
    iget-object v2, p0, Lak1;->l:Ljava/lang/Enum;

    .line 6
    .line 7
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 8
    .line 9
    const/16 v3, 0x7fff

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    check-cast v2, Lnj4;

    .line 15
    .line 16
    check-cast v1, Lmj4;

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    sget-object v4, Lnj4;->i:Lnj4;

    .line 20
    .line 21
    sget-object v5, Lmj4;->j:Lmj4;

    .line 22
    .line 23
    if-ne v2, v4, :cond_2

    .line 24
    .line 25
    if-ne v1, v5, :cond_0

    .line 26
    .line 27
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    invoke-interface {p0, v1}, Lds3;->g0(I)I

    .line 32
    .line 33
    .line 34
    move-result p0

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-interface {p0, v1}, Lds3;->S(I)I

    .line 41
    .line 42
    .line 43
    move-result p0

    .line 44
    :goto_0
    invoke-static {p1, p2}, Lb81;->d(J)Z

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-eqz v1, :cond_1

    .line 49
    .line 50
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    :cond_1
    new-instance p1, Lt32;

    .line 55
    .line 56
    invoke-direct {p1, p0, v3, v0}, Lt32;-><init>(IIB)V

    .line 57
    .line 58
    .line 59
    goto :goto_2

    .line 60
    :cond_2
    if-ne v1, v5, :cond_3

    .line 61
    .line 62
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    invoke-interface {p0, v1}, Lds3;->f(I)I

    .line 67
    .line 68
    .line 69
    move-result p0

    .line 70
    goto :goto_1

    .line 71
    :cond_3
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 72
    .line 73
    .line 74
    move-result v1

    .line 75
    invoke-interface {p0, v1}, Lds3;->h0(I)I

    .line 76
    .line 77
    .line 78
    move-result p0

    .line 79
    :goto_1
    invoke-static {p1, p2}, Lb81;->e(J)Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    if-eqz v1, :cond_4

    .line 84
    .line 85
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    :cond_4
    new-instance p1, Lt32;

    .line 90
    .line 91
    invoke-direct {p1, v3, p0, v0}, Lt32;-><init>(IIB)V

    .line 92
    .line 93
    .line 94
    :goto_2
    return-object p1

    .line 95
    :pswitch_0
    check-cast v2, Lss3;

    .line 96
    .line 97
    check-cast v1, Lrs3;

    .line 98
    .line 99
    const/4 v0, 0x1

    .line 100
    sget-object v4, Lss3;->i:Lss3;

    .line 101
    .line 102
    sget-object v5, Lrs3;->j:Lrs3;

    .line 103
    .line 104
    if-ne v2, v4, :cond_7

    .line 105
    .line 106
    if-ne v1, v5, :cond_5

    .line 107
    .line 108
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    invoke-interface {p0, v1}, Lds3;->g0(I)I

    .line 113
    .line 114
    .line 115
    move-result p0

    .line 116
    goto :goto_3

    .line 117
    :cond_5
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    invoke-interface {p0, v1}, Lds3;->S(I)I

    .line 122
    .line 123
    .line 124
    move-result p0

    .line 125
    :goto_3
    invoke-static {p1, p2}, Lb81;->d(J)Z

    .line 126
    .line 127
    .line 128
    move-result v1

    .line 129
    if-eqz v1, :cond_6

    .line 130
    .line 131
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 132
    .line 133
    .line 134
    move-result v3

    .line 135
    :cond_6
    new-instance p1, Lt32;

    .line 136
    .line 137
    invoke-direct {p1, p0, v3, v0}, Lt32;-><init>(IIB)V

    .line 138
    .line 139
    .line 140
    goto :goto_5

    .line 141
    :cond_7
    if-ne v1, v5, :cond_8

    .line 142
    .line 143
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 144
    .line 145
    .line 146
    move-result v1

    .line 147
    invoke-interface {p0, v1}, Lds3;->f(I)I

    .line 148
    .line 149
    .line 150
    move-result p0

    .line 151
    goto :goto_4

    .line 152
    :cond_8
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    invoke-interface {p0, v1}, Lds3;->h0(I)I

    .line 157
    .line 158
    .line 159
    move-result p0

    .line 160
    :goto_4
    invoke-static {p1, p2}, Lb81;->e(J)Z

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    if-eqz v1, :cond_9

    .line 165
    .line 166
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 167
    .line 168
    .line 169
    move-result v3

    .line 170
    :cond_9
    new-instance p1, Lt32;

    .line 171
    .line 172
    invoke-direct {p1, v3, p0, v0}, Lt32;-><init>(IIB)V

    .line 173
    .line 174
    .line 175
    :goto_5
    return-object p1

    .line 176
    :pswitch_1
    check-cast v2, Ls23;

    .line 177
    .line 178
    check-cast v1, Lo23;

    .line 179
    .line 180
    const/4 v0, 0x0

    .line 181
    sget-object v4, Ls23;->i:Ls23;

    .line 182
    .line 183
    sget-object v5, Lo23;->j:Lo23;

    .line 184
    .line 185
    if-ne v2, v4, :cond_c

    .line 186
    .line 187
    if-ne v1, v5, :cond_a

    .line 188
    .line 189
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    invoke-interface {p0, v1}, Lds3;->g0(I)I

    .line 194
    .line 195
    .line 196
    move-result p0

    .line 197
    goto :goto_6

    .line 198
    :cond_a
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 199
    .line 200
    .line 201
    move-result v1

    .line 202
    invoke-interface {p0, v1}, Lds3;->S(I)I

    .line 203
    .line 204
    .line 205
    move-result p0

    .line 206
    :goto_6
    invoke-static {p1, p2}, Lb81;->d(J)Z

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    if-eqz v1, :cond_b

    .line 211
    .line 212
    invoke-static {p1, p2}, Lb81;->h(J)I

    .line 213
    .line 214
    .line 215
    move-result v3

    .line 216
    :cond_b
    new-instance p1, Lt32;

    .line 217
    .line 218
    invoke-direct {p1, p0, v3, v0}, Lt32;-><init>(IIB)V

    .line 219
    .line 220
    .line 221
    goto :goto_8

    .line 222
    :cond_c
    if-ne v1, v5, :cond_d

    .line 223
    .line 224
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 225
    .line 226
    .line 227
    move-result v1

    .line 228
    invoke-interface {p0, v1}, Lds3;->f(I)I

    .line 229
    .line 230
    .line 231
    move-result p0

    .line 232
    goto :goto_7

    .line 233
    :cond_d
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    invoke-interface {p0, v1}, Lds3;->h0(I)I

    .line 238
    .line 239
    .line 240
    move-result p0

    .line 241
    :goto_7
    invoke-static {p1, p2}, Lb81;->e(J)Z

    .line 242
    .line 243
    .line 244
    move-result v1

    .line 245
    if-eqz v1, :cond_e

    .line 246
    .line 247
    invoke-static {p1, p2}, Lb81;->i(J)I

    .line 248
    .line 249
    .line 250
    move-result v3

    .line 251
    :cond_e
    new-instance p1, Lt32;

    .line 252
    .line 253
    invoke-direct {p1, v3, p0, v0}, Lt32;-><init>(IIB)V

    .line 254
    .line 255
    .line 256
    :goto_8
    return-object p1

    .line 257
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final f(I)I
    .locals 1

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 7
    .line 8
    invoke-interface {p0, p1}, Lds3;->f(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 14
    .line 15
    invoke-interface {p0, p1}, Lds3;->f(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 21
    .line 22
    invoke-interface {p0, p1}, Lds3;->f(I)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final g0(I)I
    .locals 1

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 7
    .line 8
    invoke-interface {p0, p1}, Lds3;->g0(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 14
    .line 15
    invoke-interface {p0, p1}, Lds3;->g0(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 21
    .line 22
    invoke-interface {p0, p1}, Lds3;->g0(I)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h0(I)I
    .locals 1

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 7
    .line 8
    invoke-interface {p0, p1}, Lds3;->h0(I)I

    .line 9
    .line 10
    .line 11
    move-result p0

    .line 12
    return p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 14
    .line 15
    invoke-interface {p0, p1}, Lds3;->h0(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 21
    .line 22
    invoke-interface {p0, p1}, Lds3;->h0(I)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final j()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte v0, p0, Lak1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 7
    .line 8
    invoke-interface {p0}, Lds3;->j()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :pswitch_0
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 14
    .line 15
    invoke-interface {p0}, Lds3;->j()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :pswitch_1
    iget-object p0, p0, Lak1;->j:Lds3;

    .line 21
    .line 22
    invoke-interface {p0}, Lds3;->j()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
