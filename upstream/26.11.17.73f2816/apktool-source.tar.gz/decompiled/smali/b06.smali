.class public final Lb06;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lqa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lw06;

.field public final synthetic k:Lg06;

.field public final synthetic l:Lv06;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lw06;Lg06;Lv06;Llp3;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lb06;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb06;->j:Lw06;

    .line 8
    .line 9
    iput-object p2, p0, Lb06;->k:Lg06;

    .line 10
    .line 11
    iput-object p3, p0, Lb06;->l:Lv06;

    .line 12
    .line 13
    iput-object p4, p0, Lb06;->m:Ljava/lang/Object;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>(Lw06;Lv06;Lg06;Ley5;)V
    .locals 1

    const/4 v0, 0x0

    iput-byte v0, p0, Lb06;->i:B

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb06;->j:Lw06;

    iput-object p2, p0, Lb06;->l:Lv06;

    iput-object p3, p0, Lb06;->k:Lg06;

    iput-object p4, p0, Lb06;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, Lb06;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    iget-object v2, p0, Lb06;->k:Lg06;

    .line 6
    .line 7
    iget-object v3, p0, Lb06;->m:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, Lb06;->l:Lv06;

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    iget-object p0, p0, Lb06;->j:Lw06;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast p1, Ljava/lang/Number;

    .line 18
    .line 19
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v5}, Lw06;->d(Lg06;)V

    .line 23
    .line 24
    .line 25
    check-cast v3, Llp3;

    .line 26
    .line 27
    iget-object p0, v4, Lv06;->b:Lw06;

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    iget-boolean p1, v2, Lg06;->c:Z

    .line 33
    .line 34
    if-nez p1, :cond_0

    .line 35
    .line 36
    invoke-virtual {p0}, Lw06;->c()Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    if-nez p1, :cond_0

    .line 41
    .line 42
    iget-object p0, p0, Lw06;->l:Lw44;

    .line 43
    .line 44
    invoke-interface {p0, v2}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object v5, v2, Lg06;->a:Ljava/lang/String;

    .line 48
    .line 49
    :cond_0
    if-eqz v5, :cond_1

    .line 50
    .line 51
    invoke-virtual {v3, v5}, Llp3;->Y(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_1
    return-object v1

    .line 55
    :pswitch_0
    check-cast p1, Ljava/lang/Number;

    .line 56
    .line 57
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 58
    .line 59
    .line 60
    invoke-virtual {p0, v5}, Lw06;->d(Lg06;)V

    .line 61
    .line 62
    .line 63
    check-cast v3, Ley5;

    .line 64
    .line 65
    invoke-virtual {v4, v2, v3}, Lv06;->k(Lg06;Ley5;)V

    .line 66
    .line 67
    .line 68
    return-object v1

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
