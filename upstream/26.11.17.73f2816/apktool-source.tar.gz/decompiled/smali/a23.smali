.class public final La23;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final a:Lrf1;

.field public final b:Leh0;

.field public final c:Lll6;

.field public final d:Lll6;

.field public final e:Lng;

.field public final f:Lng;

.field public g:J

.field public final h:Landroid/graphics/RuntimeShader;

.field public final i:Li14;

.field public final j:Li14;


# direct methods
.method public constructor <init>(Lrf1;Leh0;)V
    .locals 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La23;->a:Lrf1;

    .line 8
    .line 9
    iput-object p2, p0, La23;->b:Leh0;

    .line 10
    .line 11
    const p2, 0x3a83126f    # 0.001f

    .line 12
    .line 13
    .line 14
    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    new-instance v1, Lll6;

    .line 19
    .line 20
    const/high16 v2, 0x3f000000    # 0.5f

    .line 21
    .line 22
    const/high16 v3, 0x43960000    # 300.0f

    .line 23
    .line 24
    invoke-direct {v1, v2, v3, v0}, Lll6;-><init>(FFLjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iput-object v1, p0, La23;->c:Lll6;

    .line 28
    .line 29
    sget-object v0, Lgj7;->a:Ljava/util/Map;

    .line 30
    .line 31
    new-instance v0, Lfm4;

    .line 32
    .line 33
    const-wide v4, 0x3f8000003f800000L    # 0.007812501848093234

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    invoke-direct {v0, v4, v5}, Lfm4;-><init>(J)V

    .line 39
    .line 40
    .line 41
    new-instance v1, Lll6;

    .line 42
    .line 43
    invoke-direct {v1, v2, v3, v0}, Lll6;-><init>(FFLjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput-object v1, p0, La23;->d:Lll6;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    invoke-static {v0, p2}, Lrp7;->b(FF)Lng;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    iput-object p2, p0, La23;->e:Lng;

    .line 54
    .line 55
    new-instance p2, Lng;

    .line 56
    .line 57
    new-instance v0, Lfm4;

    .line 58
    .line 59
    const-wide/16 v1, 0x0

    .line 60
    .line 61
    invoke-direct {v0, v1, v2}, Lfm4;-><init>(J)V

    .line 62
    .line 63
    .line 64
    sget-object v3, Ljw;->U:Lsa7;

    .line 65
    .line 66
    new-instance v6, Lfm4;

    .line 67
    .line 68
    invoke-direct {v6, v4, v5}, Lfm4;-><init>(J)V

    .line 69
    .line 70
    .line 71
    const/16 v4, 0x8

    .line 72
    .line 73
    invoke-direct {p2, v0, v3, v6, v4}, Lng;-><init>(Ljava/lang/Object;Lsa7;Ljava/lang/Object;I)V

    .line 74
    .line 75
    .line 76
    iput-object p2, p0, La23;->f:Lng;

    .line 77
    .line 78
    iput-wide v1, p0, La23;->g:J

    .line 79
    .line 80
    invoke-static {}, Lw13;->f()V

    .line 81
    .line 82
    .line 83
    invoke-static {}, Lw13;->c()Landroid/graphics/RuntimeShader;

    .line 84
    .line 85
    .line 86
    move-result-object p2

    .line 87
    iput-object p2, p0, La23;->h:Landroid/graphics/RuntimeShader;

    .line 88
    .line 89
    new-instance p2, Lx13;

    .line 90
    .line 91
    const/4 v0, 0x0

    .line 92
    invoke-direct {p2, p0, v0}, Lx13;-><init>(La23;B)V

    .line 93
    .line 94
    .line 95
    sget-object v0, Lf14;->i:Lf14;

    .line 96
    .line 97
    invoke-static {v0, p2}, Lvv6;->w(Li14;Lqa2;)Li14;

    .line 98
    .line 99
    .line 100
    move-result-object p2

    .line 101
    iput-object p2, p0, La23;->i:Li14;

    .line 102
    .line 103
    new-instance p2, Lb4;

    .line 104
    .line 105
    const/4 v1, 0x3

    .line 106
    invoke-direct {p2, p0, v1}, Lb4;-><init>(Ljava/lang/Object;B)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0, p1, p2}, Lls6;->b(Li14;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Li14;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    iput-object p1, p0, La23;->j:Li14;

    .line 114
    .line 115
    return-void
.end method
