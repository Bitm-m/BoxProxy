.class public final Lad1;
.super Ljs6;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public i:Lyk1;

.field public j:Lqe1;

.field public k:B

.field public synthetic l:Ljava/lang/Object;

.field public final synthetic m:Lrj6;

.field public final synthetic n:Lpe1;

.field public final synthetic o:Lrj6;

.field public final synthetic p:Lrj6;

.field public final synthetic q:Lk96;

.field public final synthetic r:Lw44;

.field public final synthetic s:Lw44;


# direct methods
.method public constructor <init>(Lia1;Lpe1;Lw44;Lw44;Lk96;Lrj6;Lrj6;Lrj6;)V
    .locals 0

    .line 1
    iput-object p6, p0, Lad1;->m:Lrj6;

    .line 2
    .line 3
    iput-object p2, p0, Lad1;->n:Lpe1;

    .line 4
    .line 5
    iput-object p7, p0, Lad1;->o:Lrj6;

    .line 6
    .line 7
    iput-object p8, p0, Lad1;->p:Lrj6;

    .line 8
    .line 9
    iput-object p5, p0, Lad1;->q:Lk96;

    .line 10
    .line 11
    iput-object p3, p0, Lad1;->r:Lw44;

    .line 12
    .line 13
    iput-object p4, p0, Lad1;->s:Lw44;

    .line 14
    .line 15
    const/4 p2, 0x2

    .line 16
    invoke-direct {p0, p2, p1}, Ljs6;-><init>(ILia1;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lia1;)Lia1;
    .locals 9

    .line 1
    new-instance v0, Lad1;

    .line 2
    .line 3
    iget-object v3, p0, Lad1;->r:Lw44;

    .line 4
    .line 5
    iget-object v4, p0, Lad1;->s:Lw44;

    .line 6
    .line 7
    iget-object v2, p0, Lad1;->n:Lpe1;

    .line 8
    .line 9
    iget-object v5, p0, Lad1;->q:Lk96;

    .line 10
    .line 11
    iget-object v6, p0, Lad1;->m:Lrj6;

    .line 12
    .line 13
    iget-object v7, p0, Lad1;->o:Lrj6;

    .line 14
    .line 15
    iget-object v8, p0, Lad1;->p:Lrj6;

    .line 16
    .line 17
    move-object v1, p2

    .line 18
    invoke-direct/range {v0 .. v8}, Lad1;-><init>(Lia1;Lpe1;Lw44;Lw44;Lk96;Lrj6;Lrj6;Lrj6;)V

    .line 19
    .line 20
    .line 21
    iput-object p1, v0, Lad1;->l:Ljava/lang/Object;

    .line 22
    .line 23
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lrf1;

    .line 2
    .line 3
    check-cast p2, Lia1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lad1;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lad1;

    .line 10
    .line 11
    sget-object p1, Lne7;->a:Lne7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lad1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget-object v0, p0, Lad1;->n:Lpe1;

    .line 2
    .line 3
    iget-object v1, v0, Lpe1;->c:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, v0, Lpe1;->a:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v3, p0, Lad1;->l:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v3, Lrf1;

    .line 10
    .line 11
    iget-byte v4, p0, Lad1;->k:B

    .line 12
    .line 13
    iget-object v5, p0, Lad1;->p:Lrj6;

    .line 14
    .line 15
    iget-object v6, p0, Lad1;->s:Lw44;

    .line 16
    .line 17
    iget-object v7, p0, Lad1;->r:Lw44;

    .line 18
    .line 19
    const/4 v8, 0x2

    .line 20
    const/4 v9, 0x1

    .line 21
    const/4 v10, 0x0

    .line 22
    iget-object v11, p0, Lad1;->m:Lrj6;

    .line 23
    .line 24
    sget-object v12, Lsf1;->i:Lsf1;

    .line 25
    .line 26
    if-eqz v4, :cond_2

    .line 27
    .line 28
    if-eq v4, v9, :cond_1

    .line 29
    .line 30
    if-ne v4, v8, :cond_0

    .line 31
    .line 32
    iget-object v1, p0, Lad1;->j:Lqe1;

    .line 33
    .line 34
    iget-object v3, p0, Lad1;->i:Lyk1;

    .line 35
    .line 36
    :try_start_0
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-static {p0}, Lj02;->c(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    return-object v10

    .line 46
    :cond_1
    iget-object v3, p0, Lad1;->i:Lyk1;

    .line 47
    .line 48
    :try_start_1
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_2
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    new-instance p1, Lyu0;

    .line 56
    .line 57
    iget-object v4, p0, Lad1;->q:Lk96;

    .line 58
    .line 59
    invoke-direct {p1, v4, v0, v10, v9}, Lyu0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lia1;B)V

    .line 60
    .line 61
    .line 62
    const/4 v4, 0x3

    .line 63
    invoke-static {v3, v10, p1, v4}, Lom;->t(Lrf1;Lhf1;Lua2;I)Lyk1;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-virtual {v11, v2, v3}, Lrj6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    :try_start_2
    iput-object v10, p0, Lad1;->l:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object v3, p0, Lad1;->i:Lyk1;

    .line 73
    .line 74
    iput-byte v9, p0, Lad1;->k:B

    .line 75
    .line 76
    invoke-virtual {v3, p0}, Lm43;->y(Lia1;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    if-eq p1, v12, :cond_3

    .line 81
    .line 82
    :goto_0
    check-cast p1, Lqe1;

    .line 83
    .line 84
    invoke-interface {v7}, Lmm6;->getValue()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    check-cast v4, Ljava/util/Map;

    .line 89
    .line 90
    invoke-interface {v4, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    if-nez v4, :cond_5

    .line 95
    .line 96
    sget-object v4, Loe1;->a:Loe1;

    .line 97
    .line 98
    invoke-static {v1}, Lnm;->U(Ljava/lang/Object;)Ljava/util/List;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    iput-object v10, p0, Lad1;->l:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object v3, p0, Lad1;->i:Lyk1;

    .line 105
    .line 106
    iput-object p1, p0, Lad1;->j:Lqe1;

    .line 107
    .line 108
    iput-byte v8, p0, Lad1;->k:B

    .line 109
    .line 110
    invoke-static {v1, p0}, Loe1;->c(Ljava/util/List;Ljs6;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    if-ne v1, v12, :cond_4

    .line 115
    .line 116
    :cond_3
    return-object v12

    .line 117
    :cond_4
    move-object v13, v1

    .line 118
    move-object v1, p1

    .line 119
    move-object p1, v13

    .line 120
    :goto_1
    check-cast p1, Ljava/util/Map;

    .line 121
    .line 122
    goto :goto_2

    .line 123
    :cond_5
    sget-object v1, Lly1;->i:Lly1;

    .line 124
    .line 125
    move-object v13, v1

    .line 126
    move-object v1, p1

    .line 127
    move-object p1, v13

    .line 128
    :goto_2
    invoke-interface {v6}, Lmm6;->getValue()Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v4

    .line 132
    check-cast v4, Ljava/util/List;

    .line 133
    .line 134
    if-eqz v4, :cond_6

    .line 135
    .line 136
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 137
    .line 138
    .line 139
    move-result v8

    .line 140
    if-nez v8, :cond_8

    .line 141
    .line 142
    :cond_6
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 143
    .line 144
    .line 145
    move-result-object v4

    .line 146
    :cond_7
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 147
    .line 148
    .line 149
    move-result v8

    .line 150
    if-eqz v8, :cond_8

    .line 151
    .line 152
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v8

    .line 156
    check-cast v8, Lpe1;

    .line 157
    .line 158
    invoke-static {v8, v0}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    move-result v8

    .line 162
    if-eqz v8, :cond_7

    .line 163
    .line 164
    invoke-interface {v7}, Lmm6;->getValue()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v4

    .line 168
    check-cast v4, Ljava/util/Map;

    .line 169
    .line 170
    invoke-static {p1, v4}, Lcq3;->m0(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 171
    .line 172
    .line 173
    move-result-object p1

    .line 174
    invoke-interface {v7, p1}, Lw44;->setValue(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    iget-object p0, p0, Lad1;->o:Lrj6;

    .line 178
    .line 179
    invoke-virtual {p0, v2, v1}, Lrj6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    invoke-virtual {v5, v2}, Lrj6;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 183
    .line 184
    .line 185
    :cond_8
    invoke-virtual {v11, v2}, Lrj6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object p0

    .line 189
    if-ne p0, v3, :cond_c

    .line 190
    .line 191
    goto :goto_3

    .line 192
    :catch_0
    :try_start_3
    invoke-interface {v6}, Lmm6;->getValue()Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    check-cast p0, Ljava/util/List;

    .line 197
    .line 198
    if-eqz p0, :cond_9

    .line 199
    .line 200
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 201
    .line 202
    .line 203
    move-result p1

    .line 204
    if-nez p1, :cond_b

    .line 205
    .line 206
    :cond_9
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 207
    .line 208
    .line 209
    move-result-object p0

    .line 210
    :cond_a
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 211
    .line 212
    .line 213
    move-result p1

    .line 214
    if-eqz p1, :cond_b

    .line 215
    .line 216
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object p1

    .line 220
    check-cast p1, Lpe1;

    .line 221
    .line 222
    invoke-static {p1, v0}, Lv23;->h(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result p1

    .line 226
    if-eqz p1, :cond_a

    .line 227
    .line 228
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 229
    .line 230
    invoke-virtual {v5, v2, p0}, Lrj6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 231
    .line 232
    .line 233
    :cond_b
    invoke-virtual {v11, v2}, Lrj6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object p0

    .line 237
    if-ne p0, v3, :cond_c

    .line 238
    .line 239
    :goto_3
    invoke-virtual {v11, v2}, Lrj6;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    :cond_c
    sget-object p0, Lne7;->a:Lne7;

    .line 243
    .line 244
    return-object p0

    .line 245
    :catch_1
    move-exception p0

    .line 246
    :try_start_4
    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 247
    :catchall_0
    move-exception p0

    .line 248
    invoke-virtual {v11, v2}, Lrj6;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    if-ne p1, v3, :cond_d

    .line 253
    .line 254
    invoke-virtual {v11, v2}, Lrj6;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    :cond_d
    throw p0
.end method
