.class public final synthetic Lae1;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lva2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lw44;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Lcb2;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;

.field public final synthetic p:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lfa2;Lw44;Ljava/util/List;Ljava/util/List;Lua2;Lqa2;)V
    .locals 1

    .line 23
    const/4 v0, 0x1

    iput-byte v0, p0, Lae1;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lae1;->l:Ljava/lang/Object;

    iput-object p2, p0, Lae1;->m:Lcb2;

    iput-object p3, p0, Lae1;->j:Lw44;

    iput-object p4, p0, Lae1;->n:Ljava/lang/Object;

    iput-object p5, p0, Lae1;->o:Ljava/lang/Object;

    iput-object p6, p0, Lae1;->p:Ljava/lang/Object;

    iput-object p7, p0, Lae1;->k:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lqx5;Lfa2;Ll72;Lw44;Lw44;Lw44;Lw44;)V
    .locals 1

    .line 22
    const/4 v0, 0x2

    iput-byte v0, p0, Lae1;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lae1;->k:Ljava/lang/Object;

    iput-object p2, p0, Lae1;->m:Lcb2;

    iput-object p3, p0, Lae1;->n:Ljava/lang/Object;

    iput-object p4, p0, Lae1;->j:Lw44;

    iput-object p5, p0, Lae1;->l:Ljava/lang/Object;

    iput-object p6, p0, Lae1;->o:Ljava/lang/Object;

    iput-object p7, p0, Lae1;->p:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lw44;Lqa2;Lw44;Lqa2;Ljava/util/ArrayList;Ljava/util/ArrayList;Lay4;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lae1;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lae1;->j:Lw44;

    .line 8
    .line 9
    iput-object p2, p0, Lae1;->k:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lae1;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lae1;->m:Lcb2;

    .line 14
    .line 15
    iput-object p5, p0, Lae1;->n:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lae1;->o:Ljava/lang/Object;

    .line 18
    .line 19
    iput-object p7, p0, Lae1;->p:Ljava/lang/Object;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 40

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lae1;->i:B

    .line 4
    .line 5
    sget-object v2, Lja3;->a0:Lxg2;

    .line 6
    .line 7
    sget-object v3, Li21;->a:Ls9;

    .line 8
    .line 9
    iget-object v4, v0, Lae1;->j:Lw44;

    .line 10
    .line 11
    const/high16 v5, 0x3f800000    # 1.0f

    .line 12
    .line 13
    sget-object v6, Lne7;->a:Lne7;

    .line 14
    .line 15
    sget-object v7, Lf14;->i:Lf14;

    .line 16
    .line 17
    iget-object v9, v0, Lae1;->p:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v10, v0, Lae1;->o:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v11, v0, Lae1;->l:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v12, v0, Lae1;->n:Ljava/lang/Object;

    .line 24
    .line 25
    iget-object v13, v0, Lae1;->m:Lcb2;

    .line 26
    .line 27
    iget-object v14, v0, Lae1;->k:Ljava/lang/Object;

    .line 28
    .line 29
    const/16 v15, 0x10

    .line 30
    .line 31
    const/4 v8, 0x1

    .line 32
    packed-switch v1, :pswitch_data_0

    .line 33
    .line 34
    .line 35
    check-cast v14, Lqx5;

    .line 36
    .line 37
    check-cast v13, Lfa2;

    .line 38
    .line 39
    check-cast v12, Ll72;

    .line 40
    .line 41
    check-cast v11, Lw44;

    .line 42
    .line 43
    check-cast v10, Lw44;

    .line 44
    .line 45
    check-cast v9, Lw44;

    .line 46
    .line 47
    move-object/from16 v0, p1

    .line 48
    .line 49
    check-cast v0, Lvh;

    .line 50
    .line 51
    move-object/from16 v1, p2

    .line 52
    .line 53
    check-cast v1, Lub2;

    .line 54
    .line 55
    move-object/from16 v16, p3

    .line 56
    .line 57
    check-cast v16, Ljava/lang/Integer;

    .line 58
    .line 59
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Integer;->intValue()I

    .line 60
    .line 61
    .line 62
    move-result v16

    .line 63
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    and-int/lit8 v0, v16, 0x11

    .line 67
    .line 68
    if-eq v0, v15, :cond_0

    .line 69
    .line 70
    move v0, v8

    .line 71
    goto :goto_0

    .line 72
    :cond_0
    const/4 v0, 0x0

    .line 73
    :goto_0
    and-int/lit8 v15, v16, 0x1

    .line 74
    .line 75
    invoke-virtual {v1, v15, v0}, Lub2;->S(IZ)Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_11

    .line 80
    .line 81
    invoke-static {v7, v5}, Lch6;->d(Li14;F)Li14;

    .line 82
    .line 83
    .line 84
    move-result-object v16

    .line 85
    const/16 v21, 0x2

    .line 86
    .line 87
    const/high16 v17, 0x41400000    # 12.0f

    .line 88
    .line 89
    const/16 v18, 0x0

    .line 90
    .line 91
    const/high16 v20, 0x41000000    # 8.0f

    .line 92
    .line 93
    move/from16 v19, v17

    .line 94
    .line 95
    invoke-static/range {v16 .. v21}, Lmi1;->G(Li14;FFFFI)Li14;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    move/from16 v15, v20

    .line 100
    .line 101
    new-instance v5, Lvv;

    .line 102
    .line 103
    new-instance v8, Lj02;

    .line 104
    .line 105
    move-object/from16 v39, v6

    .line 106
    .line 107
    const/4 v6, 0x3

    .line 108
    invoke-direct {v8, v6}, Lj02;-><init>(B)V

    .line 109
    .line 110
    .line 111
    const/4 v6, 0x1

    .line 112
    invoke-direct {v5, v15, v6, v8}, Lvv;-><init>(FZLj02;)V

    .line 113
    .line 114
    .line 115
    sget-object v6, Lt6;->w:Lp20;

    .line 116
    .line 117
    const/4 v8, 0x6

    .line 118
    invoke-static {v5, v6, v1, v8}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 119
    .line 120
    .line 121
    move-result-object v5

    .line 122
    move-object v6, v9

    .line 123
    iget-wide v8, v1, Lub2;->T:J

    .line 124
    .line 125
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 126
    .line 127
    .line 128
    move-result v8

    .line 129
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 130
    .line 131
    .line 132
    move-result-object v9

    .line 133
    invoke-static {v1, v0}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    sget-object v17, La21;->d:Lt6;

    .line 138
    .line 139
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1}, Lub2;->e0()V

    .line 143
    .line 144
    .line 145
    iget-boolean v15, v1, Lub2;->S:Z

    .line 146
    .line 147
    if-eqz v15, :cond_1

    .line 148
    .line 149
    invoke-virtual {v1, v2}, Lub2;->l(Lfa2;)V

    .line 150
    .line 151
    .line 152
    goto :goto_1

    .line 153
    :cond_1
    invoke-virtual {v1}, Lub2;->n0()V

    .line 154
    .line 155
    .line 156
    :goto_1
    sget-object v15, Lt6;->S:Lf11;

    .line 157
    .line 158
    invoke-static {v15, v1, v5}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    sget-object v5, Lt6;->R:Lf11;

    .line 162
    .line 163
    invoke-static {v5, v1, v9}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 167
    .line 168
    .line 169
    move-result-object v8

    .line 170
    sget-object v9, Lt6;->T:Lf11;

    .line 171
    .line 172
    invoke-static {v9, v1, v8}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 173
    .line 174
    .line 175
    invoke-static {v1}, Les6;->l(Lub2;)V

    .line 176
    .line 177
    .line 178
    sget-object v8, Lt6;->Q:Lf11;

    .line 179
    .line 180
    invoke-static {v8, v1, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    const/high16 v0, 0x3f800000    # 1.0f

    .line 184
    .line 185
    invoke-static {v7, v0}, Lch6;->d(Li14;F)Li14;

    .line 186
    .line 187
    .line 188
    move-result-object v7

    .line 189
    new-instance v0, Lvv;

    .line 190
    .line 191
    move-object/from16 p1, v6

    .line 192
    .line 193
    new-instance v6, Lj02;

    .line 194
    .line 195
    move-object/from16 v17, v11

    .line 196
    .line 197
    const/4 v11, 0x3

    .line 198
    invoke-direct {v6, v11}, Lj02;-><init>(B)V

    .line 199
    .line 200
    .line 201
    move-object/from16 v31, v4

    .line 202
    .line 203
    const/high16 v4, 0x41000000    # 8.0f

    .line 204
    .line 205
    const/4 v11, 0x1

    .line 206
    invoke-direct {v0, v4, v11, v6}, Lvv;-><init>(FZLj02;)V

    .line 207
    .line 208
    .line 209
    sget-object v4, Lt6;->u:Lq20;

    .line 210
    .line 211
    const/16 v6, 0x36

    .line 212
    .line 213
    invoke-static {v0, v4, v1, v6}, Lsq5;->a(Luv;Lq20;Lub2;I)Ltq5;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    move-object v4, v10

    .line 218
    iget-wide v10, v1, Lub2;->T:J

    .line 219
    .line 220
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 221
    .line 222
    .line 223
    move-result v6

    .line 224
    invoke-virtual {v1}, Lub2;->m()Lh05;

    .line 225
    .line 226
    .line 227
    move-result-object v10

    .line 228
    invoke-static {v1, v7}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 229
    .line 230
    .line 231
    move-result-object v7

    .line 232
    invoke-virtual {v1}, Lub2;->e0()V

    .line 233
    .line 234
    .line 235
    iget-boolean v11, v1, Lub2;->S:Z

    .line 236
    .line 237
    if-eqz v11, :cond_2

    .line 238
    .line 239
    invoke-virtual {v1, v2}, Lub2;->l(Lfa2;)V

    .line 240
    .line 241
    .line 242
    goto :goto_2

    .line 243
    :cond_2
    invoke-virtual {v1}, Lub2;->n0()V

    .line 244
    .line 245
    .line 246
    :goto_2
    invoke-static {v15, v1, v0}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    invoke-static {v5, v1, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    invoke-static {v6, v1, v9, v1}, Lxk6;->y(ILub2;Lf11;Lub2;)V

    .line 253
    .line 254
    .line 255
    invoke-static {v8, v1, v7}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    invoke-interface/range {v31 .. v31}, Lmm6;->getValue()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    check-cast v0, Ljava/lang/String;

    .line 263
    .line 264
    invoke-virtual {v1, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 265
    .line 266
    .line 267
    move-result v2

    .line 268
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v5

    .line 272
    if-nez v2, :cond_3

    .line 273
    .line 274
    if-ne v5, v3, :cond_4

    .line 275
    .line 276
    :cond_3
    new-instance v5, Lyw5;

    .line 277
    .line 278
    const/4 v6, 0x1

    .line 279
    invoke-direct {v5, v14, v6}, Lyw5;-><init>(Lqx5;B)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {v1, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    :cond_4
    check-cast v5, Lqa2;

    .line 286
    .line 287
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v2

    .line 291
    if-ne v2, v3, :cond_5

    .line 292
    .line 293
    new-instance v2, Law5;

    .line 294
    .line 295
    const/4 v11, 0x3

    .line 296
    invoke-direct {v2, v11}, Law5;-><init>(B)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v1, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 300
    .line 301
    .line 302
    :cond_5
    move-object/from16 v18, v2

    .line 303
    .line 304
    check-cast v18, Lqa2;

    .line 305
    .line 306
    invoke-interface/range {v17 .. v17}, Lmm6;->getValue()Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v2

    .line 310
    check-cast v2, Ljava/lang/Boolean;

    .line 311
    .line 312
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 313
    .line 314
    .line 315
    move-result v19

    .line 316
    invoke-virtual {v1, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v6

    .line 324
    if-nez v2, :cond_6

    .line 325
    .line 326
    if-ne v6, v3, :cond_7

    .line 327
    .line 328
    :cond_6
    new-instance v6, Lr95;

    .line 329
    .line 330
    const/4 v2, 0x4

    .line 331
    invoke-direct {v6, v13, v2}, Lr95;-><init>(Lfa2;B)V

    .line 332
    .line 333
    .line 334
    invoke-virtual {v1, v6}, Lub2;->k0(Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    :cond_7
    move-object/from16 v20, v6

    .line 338
    .line 339
    check-cast v20, Lqa2;

    .line 340
    .line 341
    new-instance v2, Lcb3;

    .line 342
    .line 343
    const/high16 v6, 0x3f800000    # 1.0f

    .line 344
    .line 345
    const/4 v11, 0x1

    .line 346
    invoke-direct {v2, v6, v11}, Lcb3;-><init>(FZ)V

    .line 347
    .line 348
    .line 349
    invoke-static {v2, v12}, Lb70;->R(Li14;Ll72;)Li14;

    .line 350
    .line 351
    .line 352
    move-result-object v21

    .line 353
    const v2, 0x7f0f0448

    .line 354
    .line 355
    .line 356
    invoke-static {v2, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v22

    .line 360
    const/16 v29, 0x0

    .line 361
    .line 362
    const/16 v30, 0x1f80

    .line 363
    .line 364
    const/16 v23, 0x0

    .line 365
    .line 366
    const-wide/16 v24, 0x0

    .line 367
    .line 368
    const/16 v26, 0x0

    .line 369
    .line 370
    const/16 v28, 0x180

    .line 371
    .line 372
    move-object/from16 v16, v0

    .line 373
    .line 374
    move-object/from16 v27, v1

    .line 375
    .line 376
    move-object/from16 v17, v5

    .line 377
    .line 378
    invoke-static/range {v16 .. v30}, Lsc3;->d(Ljava/lang/String;Lqa2;Lqa2;ZLqa2;Li14;Ljava/lang/String;ZJLw34;Lub2;III)V

    .line 379
    .line 380
    .line 381
    move-object/from16 v0, v27

    .line 382
    .line 383
    invoke-virtual {v0, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 384
    .line 385
    .line 386
    move-result v1

    .line 387
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v2

    .line 391
    if-nez v1, :cond_8

    .line 392
    .line 393
    if-ne v2, v3, :cond_9

    .line 394
    .line 395
    :cond_8
    new-instance v16, Ldx5;

    .line 396
    .line 397
    const/16 v22, 0x0

    .line 398
    .line 399
    const/16 v23, 0x4

    .line 400
    .line 401
    const/16 v17, 0x0

    .line 402
    .line 403
    const-class v19, Lqx5;

    .line 404
    .line 405
    const-string v20, "goToPreviousMatch"

    .line 406
    .line 407
    const-string v21, "goToPreviousMatch()V"

    .line 408
    .line 409
    move-object/from16 v18, v14

    .line 410
    .line 411
    invoke-direct/range {v16 .. v23}, Ldx5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 412
    .line 413
    .line 414
    move-object/from16 v2, v16

    .line 415
    .line 416
    invoke-virtual {v0, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    :cond_9
    check-cast v2, Le73;

    .line 420
    .line 421
    move-object/from16 v16, v2

    .line 422
    .line 423
    check-cast v16, Lfa2;

    .line 424
    .line 425
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 426
    .line 427
    .line 428
    move-result-object v1

    .line 429
    check-cast v1, Ljava/lang/Number;

    .line 430
    .line 431
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 432
    .line 433
    .line 434
    move-result v1

    .line 435
    if-lez v1, :cond_a

    .line 436
    .line 437
    const/16 v18, 0x1

    .line 438
    .line 439
    goto :goto_3

    .line 440
    :cond_a
    const/16 v18, 0x0

    .line 441
    .line 442
    :goto_3
    new-instance v1, Lvb;

    .line 443
    .line 444
    const/16 v2, 0x14

    .line 445
    .line 446
    invoke-direct {v1, v4, v2}, Lvb;-><init>(Lw44;B)V

    .line 447
    .line 448
    .line 449
    const v2, -0x31c9e40a    # -7.6382144E8f

    .line 450
    .line 451
    .line 452
    invoke-static {v2, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 453
    .line 454
    .line 455
    move-result-object v25

    .line 456
    const/high16 v27, 0x6000000

    .line 457
    .line 458
    const/16 v28, 0xfa

    .line 459
    .line 460
    const/16 v17, 0x0

    .line 461
    .line 462
    const/16 v19, 0x0

    .line 463
    .line 464
    const-wide/16 v20, 0x0

    .line 465
    .line 466
    const/16 v22, 0x0

    .line 467
    .line 468
    const/16 v23, 0x0

    .line 469
    .line 470
    const/16 v24, 0x0

    .line 471
    .line 472
    move-object/from16 v26, v0

    .line 473
    .line 474
    invoke-static/range {v16 .. v28}, Lv04;->b(Lfa2;Li14;ZZJFFFLua2;Lub2;II)V

    .line 475
    .line 476
    .line 477
    invoke-virtual {v0, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 478
    .line 479
    .line 480
    move-result v1

    .line 481
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v2

    .line 485
    if-nez v1, :cond_b

    .line 486
    .line 487
    if-ne v2, v3, :cond_c

    .line 488
    .line 489
    :cond_b
    new-instance v16, Ldx5;

    .line 490
    .line 491
    const/16 v22, 0x0

    .line 492
    .line 493
    const/16 v23, 0x5

    .line 494
    .line 495
    const/16 v17, 0x0

    .line 496
    .line 497
    const-class v19, Lqx5;

    .line 498
    .line 499
    const-string v20, "goToNextMatch"

    .line 500
    .line 501
    const-string v21, "goToNextMatch()V"

    .line 502
    .line 503
    move-object/from16 v18, v14

    .line 504
    .line 505
    invoke-direct/range {v16 .. v23}, Ldx5;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 506
    .line 507
    .line 508
    move-object/from16 v2, v16

    .line 509
    .line 510
    invoke-virtual {v0, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 511
    .line 512
    .line 513
    :cond_c
    check-cast v2, Le73;

    .line 514
    .line 515
    move-object/from16 v16, v2

    .line 516
    .line 517
    check-cast v16, Lfa2;

    .line 518
    .line 519
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 520
    .line 521
    .line 522
    move-result-object v1

    .line 523
    check-cast v1, Ljava/lang/Number;

    .line 524
    .line 525
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 526
    .line 527
    .line 528
    move-result v1

    .line 529
    if-lez v1, :cond_d

    .line 530
    .line 531
    const/16 v18, 0x1

    .line 532
    .line 533
    goto :goto_4

    .line 534
    :cond_d
    const/16 v18, 0x0

    .line 535
    .line 536
    :goto_4
    new-instance v1, Lvb;

    .line 537
    .line 538
    const/16 v2, 0x15

    .line 539
    .line 540
    invoke-direct {v1, v4, v2}, Lvb;-><init>(Lw44;B)V

    .line 541
    .line 542
    .line 543
    const v2, 0x11d1cced

    .line 544
    .line 545
    .line 546
    invoke-static {v2, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 547
    .line 548
    .line 549
    move-result-object v25

    .line 550
    const/high16 v27, 0x6000000

    .line 551
    .line 552
    const/16 v28, 0xfa

    .line 553
    .line 554
    const/16 v17, 0x0

    .line 555
    .line 556
    const/16 v19, 0x0

    .line 557
    .line 558
    const-wide/16 v20, 0x0

    .line 559
    .line 560
    const/16 v22, 0x0

    .line 561
    .line 562
    const/16 v23, 0x0

    .line 563
    .line 564
    const/16 v24, 0x0

    .line 565
    .line 566
    move-object/from16 v26, v0

    .line 567
    .line 568
    invoke-static/range {v16 .. v28}, Lv04;->b(Lfa2;Li14;ZZJFFFLua2;Lub2;II)V

    .line 569
    .line 570
    .line 571
    const/4 v6, 0x1

    .line 572
    invoke-virtual {v0, v6}, Lub2;->r(Z)V

    .line 573
    .line 574
    .line 575
    invoke-interface/range {v31 .. v31}, Lmm6;->getValue()Ljava/lang/Object;

    .line 576
    .line 577
    .line 578
    move-result-object v1

    .line 579
    check-cast v1, Ljava/lang/String;

    .line 580
    .line 581
    invoke-static {v1}, Lyn6;->H0(Ljava/lang/CharSequence;)Z

    .line 582
    .line 583
    .line 584
    move-result v1

    .line 585
    if-nez v1, :cond_10

    .line 586
    .line 587
    const v1, -0x23b9cf8e

    .line 588
    .line 589
    .line 590
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 591
    .line 592
    .line 593
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 594
    .line 595
    .line 596
    move-result-object v1

    .line 597
    check-cast v1, Ljava/lang/Number;

    .line 598
    .line 599
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 600
    .line 601
    .line 602
    move-result v1

    .line 603
    if-gtz v1, :cond_e

    .line 604
    .line 605
    const-string v1, "0/0"

    .line 606
    .line 607
    :goto_5
    move-object/from16 v16, v1

    .line 608
    .line 609
    goto :goto_7

    .line 610
    :cond_e
    invoke-interface/range {p1 .. p1}, Lmm6;->getValue()Ljava/lang/Object;

    .line 611
    .line 612
    .line 613
    move-result-object v1

    .line 614
    check-cast v1, Ljava/lang/Number;

    .line 615
    .line 616
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 617
    .line 618
    .line 619
    move-result v1

    .line 620
    if-ltz v1, :cond_f

    .line 621
    .line 622
    invoke-interface/range {p1 .. p1}, Lmm6;->getValue()Ljava/lang/Object;

    .line 623
    .line 624
    .line 625
    move-result-object v1

    .line 626
    check-cast v1, Ljava/lang/Number;

    .line 627
    .line 628
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 629
    .line 630
    .line 631
    move-result v1

    .line 632
    const/16 v38, 0x1

    .line 633
    .line 634
    add-int/lit8 v1, v1, 0x1

    .line 635
    .line 636
    goto :goto_6

    .line 637
    :cond_f
    const/4 v1, 0x0

    .line 638
    :goto_6
    invoke-interface {v4}, Lmm6;->getValue()Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v2

    .line 642
    check-cast v2, Ljava/lang/Number;

    .line 643
    .line 644
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 645
    .line 646
    .line 647
    move-result v2

    .line 648
    new-instance v3, Ljava/lang/StringBuilder;

    .line 649
    .line 650
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 651
    .line 652
    .line 653
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 654
    .line 655
    .line 656
    const-string v1, "/"

    .line 657
    .line 658
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 659
    .line 660
    .line 661
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 662
    .line 663
    .line 664
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 665
    .line 666
    .line 667
    move-result-object v1

    .line 668
    goto :goto_5

    .line 669
    :goto_7
    sget-object v1, Lfx0;->a:Lyt1;

    .line 670
    .line 671
    invoke-virtual {v0, v1}, Lub2;->k(Lm75;)Ljava/lang/Object;

    .line 672
    .line 673
    .line 674
    move-result-object v1

    .line 675
    check-cast v1, Lex0;

    .line 676
    .line 677
    invoke-virtual {v1}, Lex0;->n()J

    .line 678
    .line 679
    .line 680
    move-result-wide v18

    .line 681
    const/16 v1, 0xd

    .line 682
    .line 683
    invoke-static {v1}, Lts6;->f(I)J

    .line 684
    .line 685
    .line 686
    move-result-wide v20

    .line 687
    const/16 v36, 0x0

    .line 688
    .line 689
    const v37, 0x3ffea

    .line 690
    .line 691
    .line 692
    const/16 v17, 0x0

    .line 693
    .line 694
    const/16 v22, 0x0

    .line 695
    .line 696
    const/16 v23, 0x0

    .line 697
    .line 698
    const-wide/16 v24, 0x0

    .line 699
    .line 700
    const/16 v26, 0x0

    .line 701
    .line 702
    const-wide/16 v27, 0x0

    .line 703
    .line 704
    const/16 v29, 0x0

    .line 705
    .line 706
    const/16 v30, 0x0

    .line 707
    .line 708
    const/16 v31, 0x0

    .line 709
    .line 710
    const/16 v32, 0x0

    .line 711
    .line 712
    const/16 v33, 0x0

    .line 713
    .line 714
    const/16 v35, 0x6000

    .line 715
    .line 716
    move-object/from16 v34, v0

    .line 717
    .line 718
    invoke-static/range {v16 .. v37}, Lzs6;->c(Ljava/lang/String;Li14;JJLc92;Le82;JLaw6;JIZIILk37;Lub2;III)V

    .line 719
    .line 720
    .line 721
    const/4 v1, 0x0

    .line 722
    invoke-virtual {v0, v1}, Lub2;->r(Z)V

    .line 723
    .line 724
    .line 725
    :goto_8
    const/4 v6, 0x1

    .line 726
    goto :goto_9

    .line 727
    :cond_10
    const/4 v1, 0x0

    .line 728
    const v2, -0x23afa9da

    .line 729
    .line 730
    .line 731
    invoke-virtual {v0, v2}, Lub2;->b0(I)V

    .line 732
    .line 733
    .line 734
    invoke-virtual {v0, v1}, Lub2;->r(Z)V

    .line 735
    .line 736
    .line 737
    goto :goto_8

    .line 738
    :goto_9
    invoke-virtual {v0, v6}, Lub2;->r(Z)V

    .line 739
    .line 740
    .line 741
    goto :goto_a

    .line 742
    :cond_11
    move-object v0, v1

    .line 743
    move-object/from16 v39, v6

    .line 744
    .line 745
    invoke-virtual {v0}, Lub2;->V()V

    .line 746
    .line 747
    .line 748
    :goto_a
    return-object v39

    .line 749
    :pswitch_0
    move-object/from16 v31, v4

    .line 750
    .line 751
    move-object/from16 v39, v6

    .line 752
    .line 753
    check-cast v11, Ljava/util/List;

    .line 754
    .line 755
    check-cast v13, Lfa2;

    .line 756
    .line 757
    move-object/from16 v18, v12

    .line 758
    .line 759
    check-cast v18, Ljava/util/List;

    .line 760
    .line 761
    move-object/from16 v19, v10

    .line 762
    .line 763
    check-cast v19, Ljava/util/List;

    .line 764
    .line 765
    check-cast v9, Lua2;

    .line 766
    .line 767
    check-cast v14, Lqa2;

    .line 768
    .line 769
    move-object/from16 v0, p1

    .line 770
    .line 771
    check-cast v0, Lzx0;

    .line 772
    .line 773
    move-object/from16 v1, p2

    .line 774
    .line 775
    check-cast v1, Lub2;

    .line 776
    .line 777
    move-object/from16 v4, p3

    .line 778
    .line 779
    check-cast v4, Ljava/lang/Integer;

    .line 780
    .line 781
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 782
    .line 783
    .line 784
    move-result v4

    .line 785
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 786
    .line 787
    .line 788
    and-int/lit8 v0, v4, 0x11

    .line 789
    .line 790
    if-eq v0, v15, :cond_12

    .line 791
    .line 792
    const/4 v0, 0x1

    .line 793
    :goto_b
    const/16 v38, 0x1

    .line 794
    .line 795
    goto :goto_c

    .line 796
    :cond_12
    const/4 v0, 0x0

    .line 797
    goto :goto_b

    .line 798
    :goto_c
    and-int/lit8 v4, v4, 0x1

    .line 799
    .line 800
    invoke-virtual {v1, v4, v0}, Lub2;->S(IZ)Z

    .line 801
    .line 802
    .line 803
    move-result v0

    .line 804
    if-eqz v0, :cond_1b

    .line 805
    .line 806
    const v0, 0x7f0f02b3

    .line 807
    .line 808
    .line 809
    invoke-static {v0, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 810
    .line 811
    .line 812
    move-result-object v20

    .line 813
    invoke-virtual {v1, v11}, Lub2;->i(Ljava/lang/Object;)Z

    .line 814
    .line 815
    .line 816
    move-result v0

    .line 817
    invoke-virtual {v1, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 818
    .line 819
    .line 820
    move-result v4

    .line 821
    or-int/2addr v0, v4

    .line 822
    invoke-virtual {v1}, Lub2;->N()Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v4

    .line 826
    if-nez v0, :cond_13

    .line 827
    .line 828
    if-eq v4, v3, :cond_13

    .line 829
    .line 830
    move-object/from16 v5, v31

    .line 831
    .line 832
    goto :goto_d

    .line 833
    :cond_13
    new-instance v4, Lrl;

    .line 834
    .line 835
    const/16 v0, 0x17

    .line 836
    .line 837
    move-object/from16 v5, v31

    .line 838
    .line 839
    invoke-direct {v4, v11, v13, v5, v0}, Lrl;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 840
    .line 841
    .line 842
    invoke-virtual {v1, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 843
    .line 844
    .line 845
    :goto_d
    move-object/from16 v21, v4

    .line 846
    .line 847
    check-cast v21, Lfa2;

    .line 848
    .line 849
    const v0, 0x7f0f02b5

    .line 850
    .line 851
    .line 852
    invoke-static {v0, v1}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 853
    .line 854
    .line 855
    move-result-object v24

    .line 856
    const/16 v27, 0x0

    .line 857
    .line 858
    const/16 v28, 0x2c

    .line 859
    .line 860
    const/16 v22, 0x0

    .line 861
    .line 862
    const/16 v23, 0x0

    .line 863
    .line 864
    const/16 v25, 0x0

    .line 865
    .line 866
    move-object/from16 v26, v1

    .line 867
    .line 868
    invoke-static/range {v20 .. v28}, Ltb3;->c(Ljava/lang/String;Lfa2;Li14;ZLjava/lang/String;Lua2;Lub2;II)V

    .line 869
    .line 870
    .line 871
    move-object/from16 v0, v26

    .line 872
    .line 873
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 874
    .line 875
    .line 876
    move-result-object v1

    .line 877
    const/4 v4, 0x0

    .line 878
    :goto_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 879
    .line 880
    .line 881
    move-result v6

    .line 882
    if-eqz v6, :cond_1c

    .line 883
    .line 884
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 885
    .line 886
    .line 887
    move-result-object v6

    .line 888
    add-int/lit8 v8, v4, 0x1

    .line 889
    .line 890
    if-ltz v4, :cond_1a

    .line 891
    .line 892
    move-object/from16 v16, v6

    .line 893
    .line 894
    check-cast v16, Lvf4;

    .line 895
    .line 896
    const v6, -0x6426bd0

    .line 897
    .line 898
    .line 899
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 900
    .line 901
    .line 902
    move-result-object v10

    .line 903
    invoke-virtual {v0, v6, v10}, Lub2;->Z(ILjava/lang/Object;)V

    .line 904
    .line 905
    .line 906
    invoke-interface {v5}, Lmm6;->getValue()Ljava/lang/Object;

    .line 907
    .line 908
    .line 909
    move-result-object v6

    .line 910
    check-cast v6, Ljava/lang/Integer;

    .line 911
    .line 912
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 913
    .line 914
    .line 915
    move-result-object v10

    .line 916
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 917
    .line 918
    .line 919
    move-result-object v11

    .line 920
    if-ne v11, v3, :cond_14

    .line 921
    .line 922
    new-instance v11, Lcw3;

    .line 923
    .line 924
    const/16 v12, 0x11

    .line 925
    .line 926
    invoke-direct {v11, v5, v12}, Lcw3;-><init>(Lw44;B)V

    .line 927
    .line 928
    .line 929
    invoke-virtual {v0, v11}, Lub2;->k0(Ljava/lang/Object;)V

    .line 930
    .line 931
    .line 932
    :cond_14
    check-cast v11, Lfa2;

    .line 933
    .line 934
    invoke-static {v7, v6, v10, v11, v0}, Llc3;->J(Li14;Ljava/lang/Number;Ljava/lang/Number;Lfa2;Lub2;)Li14;

    .line 935
    .line 936
    .line 937
    move-result-object v6

    .line 938
    sget-object v10, Lac7;->d:Ltv;

    .line 939
    .line 940
    sget-object v11, Lt6;->w:Lp20;

    .line 941
    .line 942
    const/4 v12, 0x0

    .line 943
    invoke-static {v10, v11, v0, v12}, Lwx0;->a(Lwv;Lp20;Lub2;I)Lyx0;

    .line 944
    .line 945
    .line 946
    move-result-object v10

    .line 947
    iget-wide v11, v0, Lub2;->T:J

    .line 948
    .line 949
    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    .line 950
    .line 951
    .line 952
    move-result v11

    .line 953
    invoke-virtual {v0}, Lub2;->m()Lh05;

    .line 954
    .line 955
    .line 956
    move-result-object v12

    .line 957
    invoke-static {v0, v6}, Lrm;->Q(Lub2;Li14;)Li14;

    .line 958
    .line 959
    .line 960
    move-result-object v6

    .line 961
    sget-object v13, La21;->d:Lt6;

    .line 962
    .line 963
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 964
    .line 965
    .line 966
    invoke-virtual {v0}, Lub2;->e0()V

    .line 967
    .line 968
    .line 969
    iget-boolean v13, v0, Lub2;->S:Z

    .line 970
    .line 971
    if-eqz v13, :cond_15

    .line 972
    .line 973
    invoke-virtual {v0, v2}, Lub2;->l(Lfa2;)V

    .line 974
    .line 975
    .line 976
    goto :goto_f

    .line 977
    :cond_15
    invoke-virtual {v0}, Lub2;->n0()V

    .line 978
    .line 979
    .line 980
    :goto_f
    sget-object v13, Lt6;->S:Lf11;

    .line 981
    .line 982
    invoke-static {v13, v0, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 983
    .line 984
    .line 985
    sget-object v10, Lt6;->R:Lf11;

    .line 986
    .line 987
    invoke-static {v10, v0, v12}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 988
    .line 989
    .line 990
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 991
    .line 992
    .line 993
    move-result-object v10

    .line 994
    sget-object v11, Lt6;->T:Lf11;

    .line 995
    .line 996
    invoke-static {v11, v0, v10}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 997
    .line 998
    .line 999
    invoke-static {v0}, Les6;->l(Lub2;)V

    .line 1000
    .line 1001
    .line 1002
    sget-object v10, Lt6;->Q:Lf11;

    .line 1003
    .line 1004
    invoke-static {v10, v0, v6}, Les6;->o(Lua2;Lub2;Ljava/lang/Object;)V

    .line 1005
    .line 1006
    .line 1007
    invoke-virtual {v0, v9}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1008
    .line 1009
    .line 1010
    move-result v6

    .line 1011
    invoke-virtual {v0, v4}, Lub2;->e(I)Z

    .line 1012
    .line 1013
    .line 1014
    move-result v10

    .line 1015
    or-int/2addr v6, v10

    .line 1016
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v10

    .line 1020
    if-nez v6, :cond_16

    .line 1021
    .line 1022
    if-ne v10, v3, :cond_17

    .line 1023
    .line 1024
    :cond_16
    new-instance v10, Let1;

    .line 1025
    .line 1026
    const/4 v6, 0x2

    .line 1027
    invoke-direct {v10, v9, v4, v6}, Let1;-><init>(Lua2;IB)V

    .line 1028
    .line 1029
    .line 1030
    invoke-virtual {v0, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1031
    .line 1032
    .line 1033
    :cond_17
    move-object/from16 v20, v10

    .line 1034
    .line 1035
    check-cast v20, Lqa2;

    .line 1036
    .line 1037
    invoke-virtual {v0, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 1038
    .line 1039
    .line 1040
    move-result v6

    .line 1041
    invoke-virtual {v0, v4}, Lub2;->e(I)Z

    .line 1042
    .line 1043
    .line 1044
    move-result v10

    .line 1045
    or-int/2addr v6, v10

    .line 1046
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 1047
    .line 1048
    .line 1049
    move-result-object v10

    .line 1050
    if-nez v6, :cond_18

    .line 1051
    .line 1052
    if-ne v10, v3, :cond_19

    .line 1053
    .line 1054
    :cond_18
    new-instance v10, Lnj;

    .line 1055
    .line 1056
    invoke-direct {v10, v14, v4, v15}, Lnj;-><init>(Lqa2;IB)V

    .line 1057
    .line 1058
    .line 1059
    invoke-virtual {v0, v10}, Lub2;->k0(Ljava/lang/Object;)V

    .line 1060
    .line 1061
    .line 1062
    :cond_19
    move-object/from16 v21, v10

    .line 1063
    .line 1064
    check-cast v21, Lfa2;

    .line 1065
    .line 1066
    sget-object v4, Lvf4;->d:Ljava/util/List;

    .line 1067
    .line 1068
    const/16 v23, 0x0

    .line 1069
    .line 1070
    const/16 v17, 0x0

    .line 1071
    .line 1072
    move-object/from16 v22, v0

    .line 1073
    .line 1074
    invoke-static/range {v16 .. v23}, Lip3;->I(Lvf4;ZLjava/util/List;Ljava/util/List;Lqa2;Lfa2;Lub2;I)V

    .line 1075
    .line 1076
    .line 1077
    const/4 v6, 0x1

    .line 1078
    invoke-virtual {v0, v6}, Lub2;->r(Z)V

    .line 1079
    .line 1080
    .line 1081
    const/4 v4, 0x0

    .line 1082
    invoke-virtual {v0, v4}, Lub2;->r(Z)V

    .line 1083
    .line 1084
    .line 1085
    move v4, v8

    .line 1086
    goto/16 :goto_e

    .line 1087
    .line 1088
    :cond_1a
    invoke-static {}, Lnm;->q0()V

    .line 1089
    .line 1090
    .line 1091
    const/4 v0, 0x0

    .line 1092
    throw v0

    .line 1093
    :cond_1b
    move-object v0, v1

    .line 1094
    invoke-virtual {v0}, Lub2;->V()V

    .line 1095
    .line 1096
    .line 1097
    :cond_1c
    return-object v39

    .line 1098
    :pswitch_1
    move-object/from16 v39, v6

    .line 1099
    .line 1100
    const/4 v4, 0x0

    .line 1101
    move-object v3, v14

    .line 1102
    check-cast v3, Lqa2;

    .line 1103
    .line 1104
    check-cast v11, Lw44;

    .line 1105
    .line 1106
    move-object v5, v13

    .line 1107
    check-cast v5, Lqa2;

    .line 1108
    .line 1109
    check-cast v12, Ljava/util/ArrayList;

    .line 1110
    .line 1111
    check-cast v10, Ljava/util/ArrayList;

    .line 1112
    .line 1113
    check-cast v9, Lay4;

    .line 1114
    .line 1115
    move-object/from16 v1, p1

    .line 1116
    .line 1117
    check-cast v1, Lzx0;

    .line 1118
    .line 1119
    move-object/from16 v8, p2

    .line 1120
    .line 1121
    check-cast v8, Lub2;

    .line 1122
    .line 1123
    move-object/from16 v2, p3

    .line 1124
    .line 1125
    check-cast v2, Ljava/lang/Integer;

    .line 1126
    .line 1127
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1128
    .line 1129
    .line 1130
    move-result v2

    .line 1131
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1132
    .line 1133
    .line 1134
    and-int/lit8 v1, v2, 0x11

    .line 1135
    .line 1136
    if-eq v1, v15, :cond_1d

    .line 1137
    .line 1138
    const/4 v4, 0x1

    .line 1139
    :cond_1d
    const/16 v38, 0x1

    .line 1140
    .line 1141
    and-int/lit8 v2, v2, 0x1

    .line 1142
    .line 1143
    invoke-virtual {v8, v2, v4}, Lub2;->S(IZ)Z

    .line 1144
    .line 1145
    .line 1146
    move-result v1

    .line 1147
    if-eqz v1, :cond_1e

    .line 1148
    .line 1149
    const/high16 v6, 0x3f800000    # 1.0f

    .line 1150
    .line 1151
    invoke-static {v7, v6}, Lch6;->d(Li14;F)Li14;

    .line 1152
    .line 1153
    .line 1154
    move-result-object v17

    .line 1155
    invoke-static {v8}, Ltb3;->p(Lub2;)Lpj0;

    .line 1156
    .line 1157
    .line 1158
    move-result-object v20

    .line 1159
    new-instance v1, Lll;

    .line 1160
    .line 1161
    const/16 v6, 0xe

    .line 1162
    .line 1163
    iget-object v2, v0, Lae1;->j:Lw44;

    .line 1164
    .line 1165
    move-object v4, v11

    .line 1166
    invoke-direct/range {v1 .. v6}, Lll;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1167
    .line 1168
    .line 1169
    const v0, -0x6558e05a

    .line 1170
    .line 1171
    .line 1172
    invoke-static {v0, v1, v8}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 1173
    .line 1174
    .line 1175
    move-result-object v26

    .line 1176
    const/16 v28, 0x6

    .line 1177
    .line 1178
    const/16 v29, 0x3f6

    .line 1179
    .line 1180
    const/16 v18, 0x0

    .line 1181
    .line 1182
    const/16 v19, 0x0

    .line 1183
    .line 1184
    const/16 v21, 0x0

    .line 1185
    .line 1186
    const/16 v22, 0x0

    .line 1187
    .line 1188
    const/16 v23, 0x0

    .line 1189
    .line 1190
    const/16 v24, 0x0

    .line 1191
    .line 1192
    const/16 v25, 0x0

    .line 1193
    .line 1194
    move-object/from16 v27, v8

    .line 1195
    .line 1196
    invoke-static/range {v17 .. v29}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 1197
    .line 1198
    .line 1199
    move-object/from16 v0, v27

    .line 1200
    .line 1201
    const/high16 v6, 0x3f800000    # 1.0f

    .line 1202
    .line 1203
    invoke-static {v7, v6}, Lch6;->d(Li14;F)Li14;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v17

    .line 1207
    invoke-static {v0}, Ltb3;->p(Lub2;)Lpj0;

    .line 1208
    .line 1209
    .line 1210
    move-result-object v20

    .line 1211
    new-instance v1, Lk;

    .line 1212
    .line 1213
    const/16 v2, 0x8

    .line 1214
    .line 1215
    invoke-direct {v1, v12, v10, v9, v2}, Lk;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1216
    .line 1217
    .line 1218
    const v2, 0x4a95ce4f    # 4908839.5f

    .line 1219
    .line 1220
    .line 1221
    invoke-static {v2, v1, v0}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 1222
    .line 1223
    .line 1224
    move-result-object v26

    .line 1225
    invoke-static/range {v17 .. v29}, Lnx3;->a(Li14;FLxu4;Lpj0;Lf55;ZLfa2;Lfa2;ZLc01;Lub2;II)V

    .line 1226
    .line 1227
    .line 1228
    goto :goto_10

    .line 1229
    :cond_1e
    move-object/from16 v27, v8

    .line 1230
    .line 1231
    invoke-virtual/range {v27 .. v27}, Lub2;->V()V

    .line 1232
    .line 1233
    .line 1234
    :goto_10
    return-object v39

    .line 1235
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
