.class public final Lac0;
.super Ljs6;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public j:Z

.field public final synthetic k:Lcom/box/app/notification/BoxPersistentNotificationService;


# direct methods
.method public synthetic constructor <init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lac0;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lac0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Ljs6;-><init>(ILia1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lia1;)Lia1;
    .locals 1

    .line 1
    iget-byte p1, p0, Lac0;->i:B

    .line 2
    .line 3
    iget-object p0, p0, Lac0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance p1, Lac0;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    invoke-direct {p1, p0, p2, v0}, Lac0;-><init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V

    .line 12
    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_0
    new-instance p1, Lac0;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-direct {p1, p0, p2, v0}, Lac0;-><init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lia1;B)V

    .line 19
    .line 20
    .line 21
    return-object p1

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lac0;->i:B

    .line 2
    .line 3
    sget-object v1, Lne7;->a:Lne7;

    .line 4
    .line 5
    check-cast p1, Lrf1;

    .line 6
    .line 7
    check-cast p2, Lia1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lac0;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lac0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lac0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Lac0;->create(Ljava/lang/Object;Lia1;)Lia1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lac0;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lac0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-byte v0, p0, Lac0;->i:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Lac0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    .line 8
    .line 9
    sget-object v5, Lsf1;->i:Lsf1;

    .line 10
    .line 11
    const/4 v6, 0x1

    .line 12
    packed-switch v0, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    iget-boolean v0, p0, Lac0;->j:Z

    .line 16
    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    if-ne v0, v6, :cond_0

    .line 20
    .line 21
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    invoke-static {v4}, Lj02;->c(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    goto :goto_1

    .line 29
    :cond_1
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iput-boolean v6, p0, Lac0;->j:Z

    .line 33
    .line 34
    invoke-static {v2, v1, p0, v6}, Lcom/box/app/notification/BoxPersistentNotificationService;->h(Lcom/box/app/notification/BoxPersistentNotificationService;ZLjs6;I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    if-ne p0, v5, :cond_2

    .line 39
    .line 40
    move-object v3, v5

    .line 41
    goto :goto_1

    .line 42
    :cond_2
    :goto_0
    sget-object v3, Lne7;->a:Lne7;

    .line 43
    .line 44
    :goto_1
    return-object v3

    .line 45
    :pswitch_0
    iget-boolean v0, p0, Lac0;->j:Z

    .line 46
    .line 47
    if-eqz v0, :cond_4

    .line 48
    .line 49
    if-ne v0, v6, :cond_3

    .line 50
    .line 51
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_3
    invoke-static {v4}, Lj02;->c(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    move-object p1, v3

    .line 59
    goto :goto_2

    .line 60
    :cond_4
    invoke-static {p1}, Loa3;->U(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    iput-boolean v6, p0, Lac0;->j:Z

    .line 64
    .line 65
    sget p1, Lcom/box/app/notification/BoxPersistentNotificationService;->r:I

    .line 66
    .line 67
    invoke-virtual {v2, v1, p0}, Lcom/box/app/notification/BoxPersistentNotificationService;->b(ZLja1;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-ne p1, v5, :cond_5

    .line 72
    .line 73
    move-object p1, v5

    .line 74
    :cond_5
    :goto_2
    return-object p1

    .line 75
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
