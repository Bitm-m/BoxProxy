.class public final Lal0;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Lp34;


# direct methods
.method public constructor <init>(Lil0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance p1, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lal0;->a:Ljava/util/ArrayList;

    .line 10
    .line 11
    new-instance p1, Lp34;

    .line 12
    .line 13
    invoke-direct {p1}, Lp34;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lal0;->b:Lp34;

    .line 17
    .line 18
    return-void
.end method
