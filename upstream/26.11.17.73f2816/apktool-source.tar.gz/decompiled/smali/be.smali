.class public final Lbe;
.super Lnm5;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final b:Landroid/graphics/RenderEffect;


# direct methods
.method public constructor <init>(Landroid/graphics/RenderEffect;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbe;->b:Landroid/graphics/RenderEffect;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final b()Landroid/graphics/RenderEffect;
    .locals 0

    .line 1
    iget-object p0, p0, Lbe;->b:Landroid/graphics/RenderEffect;

    .line 2
    .line 3
    return-object p0
.end method
