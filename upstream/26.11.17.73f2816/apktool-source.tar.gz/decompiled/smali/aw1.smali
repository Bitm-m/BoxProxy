.class public abstract Law1;
.super Lh02;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final c:Lmo0;

.field public final d:Landroid/view/MotionEvent;


# direct methods
.method public constructor <init>(Ldv0;Lmo0;Landroid/view/MotionEvent;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Lh02;-><init>(Ldv0;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Law1;->c:Lmo0;

    .line 5
    .line 6
    iput-object p3, p0, Law1;->d:Landroid/view/MotionEvent;

    .line 7
    .line 8
    return-void
.end method
