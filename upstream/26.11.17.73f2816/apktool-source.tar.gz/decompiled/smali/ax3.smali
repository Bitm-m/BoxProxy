.class public final synthetic Lax3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:Li14;

.field public final synthetic j:F

.field public final synthetic k:Lvv;

.field public final synthetic l:Lu46;

.field public final synthetic m:Lc01;

.field public final synthetic n:Lc01;

.field public final synthetic o:I

.field public final synthetic p:B


# direct methods
.method public synthetic constructor <init>(Li14;FLvv;Lu46;Lc01;Lc01;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lax3;->i:Li14;

    .line 5
    .line 6
    iput p2, p0, Lax3;->j:F

    .line 7
    .line 8
    iput-object p3, p0, Lax3;->k:Lvv;

    .line 9
    .line 10
    iput-object p4, p0, Lax3;->l:Lu46;

    .line 11
    .line 12
    iput-object p5, p0, Lax3;->m:Lc01;

    .line 13
    .line 14
    iput-object p6, p0, Lax3;->n:Lc01;

    .line 15
    .line 16
    iput p7, p0, Lax3;->o:I

    .line 17
    .line 18
    iput-byte p8, p0, Lax3;->p:B

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    move-object v6, p1

    .line 2
    check-cast v6, Lub2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lax3;->o:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lub3;->b0(I)I

    .line 14
    .line 15
    .line 16
    move-result v7

    .line 17
    iget-object v0, p0, Lax3;->i:Li14;

    .line 18
    .line 19
    iget v1, p0, Lax3;->j:F

    .line 20
    .line 21
    iget-object v2, p0, Lax3;->k:Lvv;

    .line 22
    .line 23
    iget-object v3, p0, Lax3;->l:Lu46;

    .line 24
    .line 25
    iget-object v4, p0, Lax3;->m:Lc01;

    .line 26
    .line 27
    iget-object v5, p0, Lax3;->n:Lc01;

    .line 28
    .line 29
    iget-byte v8, p0, Lax3;->p:B

    .line 30
    .line 31
    invoke-static/range {v0 .. v8}, Lkb3;->d(Li14;FLvv;Lu46;Lc01;Lc01;Lub2;II)V

    .line 32
    .line 33
    .line 34
    sget-object p0, Lne7;->a:Lne7;

    .line 35
    .line 36
    return-object p0
.end method
