.class public final synthetic Law3;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lua2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Lfa2;

.field public final synthetic l:Lfa2;

.field public final synthetic m:Lfa2;

.field public final synthetic n:Lfa2;

.field public final synthetic o:Lfa2;


# direct methods
.method public synthetic constructor <init>(BLfa2;Lfa2;Lfa2;Lfa2;Lfa2;Z)V
    .locals 0

    .line 1
    iput-byte p1, p0, Law3;->i:B

    .line 2
    .line 3
    iput-boolean p7, p0, Law3;->j:Z

    .line 4
    .line 5
    iput-object p2, p0, Law3;->k:Lfa2;

    .line 6
    .line 7
    iput-object p3, p0, Law3;->l:Lfa2;

    .line 8
    .line 9
    iput-object p4, p0, Law3;->m:Lfa2;

    .line 10
    .line 11
    iput-object p5, p0, Law3;->n:Lfa2;

    .line 12
    .line 13
    iput-object p6, p0, Law3;->o:Lfa2;

    .line 14
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Law3;->i:B

    .line 4
    .line 5
    const v4, 0x7f0f00ca

    .line 6
    .line 7
    .line 8
    const v5, 0x7f0f0459

    .line 9
    .line 10
    .line 11
    const v6, 0x7f0f00d6

    .line 12
    .line 13
    .line 14
    const v7, 0x7f0f037b

    .line 15
    .line 16
    .line 17
    sget-object v10, Li21;->a:Ls9;

    .line 18
    .line 19
    iget-object v11, v0, Law3;->o:Lfa2;

    .line 20
    .line 21
    iget-object v12, v0, Law3;->n:Lfa2;

    .line 22
    .line 23
    iget-object v13, v0, Law3;->m:Lfa2;

    .line 24
    .line 25
    iget-object v14, v0, Law3;->l:Lfa2;

    .line 26
    .line 27
    iget-object v15, v0, Law3;->k:Lfa2;

    .line 28
    .line 29
    iget-boolean v8, v0, Law3;->j:Z

    .line 30
    .line 31
    sget-object v16, Lne7;->a:Lne7;

    .line 32
    .line 33
    const/4 v9, 0x2

    .line 34
    const/4 v2, 0x0

    .line 35
    packed-switch v1, :pswitch_data_0

    .line 36
    .line 37
    .line 38
    move-object/from16 v0, p1

    .line 39
    .line 40
    check-cast v0, Lub2;

    .line 41
    .line 42
    move-object/from16 v1, p2

    .line 43
    .line 44
    check-cast v1, Ljava/lang/Integer;

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    const/16 v27, 0x1

    .line 51
    .line 52
    and-int/lit8 v3, v1, 0x3

    .line 53
    .line 54
    if-eq v3, v9, :cond_0

    .line 55
    .line 56
    move/from16 v3, v27

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_0
    move v3, v2

    .line 60
    :goto_0
    and-int/lit8 v1, v1, 0x1

    .line 61
    .line 62
    invoke-virtual {v0, v1, v3}, Lub2;->S(IZ)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    if-eqz v1, :cond_d

    .line 67
    .line 68
    if-eqz v8, :cond_1

    .line 69
    .line 70
    const/16 v18, 0x5

    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_1
    const/16 v18, 0x4

    .line 74
    .line 75
    :goto_1
    invoke-static {v7, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v17

    .line 79
    invoke-virtual {v0, v15}, Lub2;->g(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    if-nez v1, :cond_2

    .line 88
    .line 89
    if-ne v3, v10, :cond_3

    .line 90
    .line 91
    :cond_2
    new-instance v3, Loo;

    .line 92
    .line 93
    const/16 v1, 0x1c

    .line 94
    .line 95
    invoke-direct {v3, v15, v1}, Loo;-><init>(Lfa2;B)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    :cond_3
    move-object/from16 v23, v3

    .line 102
    .line 103
    check-cast v23, Lqa2;

    .line 104
    .line 105
    const/16 v25, 0x180

    .line 106
    .line 107
    const/16 v26, 0x70

    .line 108
    .line 109
    const/16 v19, 0x0

    .line 110
    .line 111
    const/16 v20, 0x0

    .line 112
    .line 113
    const/16 v21, 0x0

    .line 114
    .line 115
    const/16 v22, 0x0

    .line 116
    .line 117
    move-object/from16 v24, v0

    .line 118
    .line 119
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 120
    .line 121
    .line 122
    const/16 v20, 0x1

    .line 123
    .line 124
    if-eqz v8, :cond_6

    .line 125
    .line 126
    const v1, 0x1da9c29a

    .line 127
    .line 128
    .line 129
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 130
    .line 131
    .line 132
    invoke-static {v6, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v17

    .line 136
    invoke-virtual {v0, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v1

    .line 140
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    if-nez v1, :cond_4

    .line 145
    .line 146
    if-ne v3, v10, :cond_5

    .line 147
    .line 148
    :cond_4
    new-instance v3, Loo;

    .line 149
    .line 150
    const/16 v1, 0x1d

    .line 151
    .line 152
    invoke-direct {v3, v14, v1}, Loo;-><init>(Lfa2;B)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    :cond_5
    move-object/from16 v23, v3

    .line 159
    .line 160
    check-cast v23, Lqa2;

    .line 161
    .line 162
    const/16 v25, 0x180

    .line 163
    .line 164
    const/16 v26, 0x70

    .line 165
    .line 166
    const/16 v19, 0x0

    .line 167
    .line 168
    const/16 v21, 0x0

    .line 169
    .line 170
    const/16 v22, 0x0

    .line 171
    .line 172
    move-object/from16 v24, v0

    .line 173
    .line 174
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v0, v2}, Lub2;->r(Z)V

    .line 178
    .line 179
    .line 180
    move/from16 v20, v9

    .line 181
    .line 182
    goto :goto_2

    .line 183
    :cond_6
    const v1, 0x1daecdf2

    .line 184
    .line 185
    .line 186
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v0, v2}, Lub2;->r(Z)V

    .line 190
    .line 191
    .line 192
    :goto_2
    invoke-static {v5, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object v17

    .line 196
    add-int/lit8 v1, v20, 0x1

    .line 197
    .line 198
    invoke-virtual {v0, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 199
    .line 200
    .line 201
    move-result v3

    .line 202
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v5

    .line 206
    if-nez v3, :cond_7

    .line 207
    .line 208
    if-ne v5, v10, :cond_8

    .line 209
    .line 210
    :cond_7
    new-instance v5, Lr95;

    .line 211
    .line 212
    invoke-direct {v5, v13, v2}, Lr95;-><init>(Lfa2;B)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v0, v5}, Lub2;->k0(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    :cond_8
    move-object/from16 v23, v5

    .line 219
    .line 220
    check-cast v23, Lqa2;

    .line 221
    .line 222
    const/16 v25, 0x180

    .line 223
    .line 224
    const/16 v26, 0x70

    .line 225
    .line 226
    const/16 v19, 0x0

    .line 227
    .line 228
    const/16 v21, 0x0

    .line 229
    .line 230
    const/16 v22, 0x0

    .line 231
    .line 232
    move-object/from16 v24, v0

    .line 233
    .line 234
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 235
    .line 236
    .line 237
    invoke-static {v4, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object v17

    .line 241
    add-int/lit8 v2, v20, 0x2

    .line 242
    .line 243
    invoke-virtual {v0, v12}, Lub2;->g(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move-result v3

    .line 247
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v4

    .line 251
    if-nez v3, :cond_9

    .line 252
    .line 253
    if-ne v4, v10, :cond_a

    .line 254
    .line 255
    :cond_9
    new-instance v4, Lr95;

    .line 256
    .line 257
    move/from16 v3, v27

    .line 258
    .line 259
    invoke-direct {v4, v12, v3}, Lr95;-><init>(Lfa2;B)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v0, v4}, Lub2;->k0(Ljava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    :cond_a
    move-object/from16 v23, v4

    .line 266
    .line 267
    check-cast v23, Lqa2;

    .line 268
    .line 269
    const/16 v25, 0x180

    .line 270
    .line 271
    const/16 v26, 0x70

    .line 272
    .line 273
    const/16 v19, 0x0

    .line 274
    .line 275
    const/16 v21, 0x0

    .line 276
    .line 277
    const/16 v22, 0x0

    .line 278
    .line 279
    move-object/from16 v24, v0

    .line 280
    .line 281
    move/from16 v20, v1

    .line 282
    .line 283
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 284
    .line 285
    .line 286
    const v1, 0x7f0f00b6

    .line 287
    .line 288
    .line 289
    invoke-static {v1, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v17

    .line 293
    invoke-virtual {v0, v11}, Lub2;->g(Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    move-result v1

    .line 297
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v3

    .line 301
    if-nez v1, :cond_b

    .line 302
    .line 303
    if-ne v3, v10, :cond_c

    .line 304
    .line 305
    :cond_b
    new-instance v3, Lr95;

    .line 306
    .line 307
    invoke-direct {v3, v11, v9}, Lr95;-><init>(Lfa2;B)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    :cond_c
    move-object/from16 v23, v3

    .line 314
    .line 315
    check-cast v23, Lqa2;

    .line 316
    .line 317
    const/16 v25, 0x180

    .line 318
    .line 319
    const/16 v26, 0x70

    .line 320
    .line 321
    const/16 v19, 0x0

    .line 322
    .line 323
    const/16 v21, 0x0

    .line 324
    .line 325
    const/16 v22, 0x0

    .line 326
    .line 327
    move-object/from16 v24, v0

    .line 328
    .line 329
    move/from16 v20, v2

    .line 330
    .line 331
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 332
    .line 333
    .line 334
    goto :goto_3

    .line 335
    :cond_d
    move-object/from16 v24, v0

    .line 336
    .line 337
    invoke-virtual/range {v24 .. v24}, Lub2;->V()V

    .line 338
    .line 339
    .line 340
    :goto_3
    return-object v16

    .line 341
    :pswitch_0
    move-object/from16 v1, p1

    .line 342
    .line 343
    check-cast v1, Lub2;

    .line 344
    .line 345
    move-object/from16 v3, p2

    .line 346
    .line 347
    check-cast v3, Ljava/lang/Integer;

    .line 348
    .line 349
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 350
    .line 351
    .line 352
    move-result v3

    .line 353
    and-int/lit8 v4, v3, 0x3

    .line 354
    .line 355
    if-eq v4, v9, :cond_e

    .line 356
    .line 357
    const/4 v2, 0x1

    .line 358
    :cond_e
    const/16 v27, 0x1

    .line 359
    .line 360
    and-int/lit8 v3, v3, 0x1

    .line 361
    .line 362
    invoke-virtual {v1, v3, v2}, Lub2;->S(IZ)Z

    .line 363
    .line 364
    .line 365
    move-result v2

    .line 366
    if-eqz v2, :cond_f

    .line 367
    .line 368
    new-instance v3, Law3;

    .line 369
    .line 370
    const/4 v4, 0x3

    .line 371
    iget-object v5, v0, Law3;->k:Lfa2;

    .line 372
    .line 373
    iget-object v6, v0, Law3;->l:Lfa2;

    .line 374
    .line 375
    iget-object v7, v0, Law3;->m:Lfa2;

    .line 376
    .line 377
    iget-object v8, v0, Law3;->n:Lfa2;

    .line 378
    .line 379
    iget-object v9, v0, Law3;->o:Lfa2;

    .line 380
    .line 381
    iget-boolean v10, v0, Law3;->j:Z

    .line 382
    .line 383
    invoke-direct/range {v3 .. v10}, Law3;-><init>(BLfa2;Lfa2;Lfa2;Lfa2;Lfa2;Z)V

    .line 384
    .line 385
    .line 386
    const v0, 0x36b02850

    .line 387
    .line 388
    .line 389
    invoke-static {v0, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 390
    .line 391
    .line 392
    move-result-object v0

    .line 393
    const/4 v2, 0x6

    .line 394
    invoke-static {v0, v1, v2}, Lhy3;->f(Lc01;Lub2;I)V

    .line 395
    .line 396
    .line 397
    goto :goto_4

    .line 398
    :cond_f
    invoke-virtual {v1}, Lub2;->V()V

    .line 399
    .line 400
    .line 401
    :goto_4
    return-object v16

    .line 402
    :pswitch_1
    move-object/from16 v0, p1

    .line 403
    .line 404
    check-cast v0, Lub2;

    .line 405
    .line 406
    move-object/from16 v1, p2

    .line 407
    .line 408
    check-cast v1, Ljava/lang/Integer;

    .line 409
    .line 410
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 411
    .line 412
    .line 413
    move-result v1

    .line 414
    and-int/lit8 v3, v1, 0x3

    .line 415
    .line 416
    if-eq v3, v9, :cond_10

    .line 417
    .line 418
    const/4 v3, 0x1

    .line 419
    :goto_5
    const/16 v27, 0x1

    .line 420
    .line 421
    goto :goto_6

    .line 422
    :cond_10
    move v3, v2

    .line 423
    goto :goto_5

    .line 424
    :goto_6
    and-int/lit8 v1, v1, 0x1

    .line 425
    .line 426
    invoke-virtual {v0, v1, v3}, Lub2;->S(IZ)Z

    .line 427
    .line 428
    .line 429
    move-result v1

    .line 430
    if-eqz v1, :cond_1d

    .line 431
    .line 432
    if-eqz v8, :cond_11

    .line 433
    .line 434
    const/16 v18, 0x5

    .line 435
    .line 436
    goto :goto_7

    .line 437
    :cond_11
    const/16 v18, 0x4

    .line 438
    .line 439
    :goto_7
    invoke-static {v7, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 440
    .line 441
    .line 442
    move-result-object v17

    .line 443
    invoke-virtual {v0, v15}, Lub2;->g(Ljava/lang/Object;)Z

    .line 444
    .line 445
    .line 446
    move-result v1

    .line 447
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 448
    .line 449
    .line 450
    move-result-object v3

    .line 451
    if-nez v1, :cond_12

    .line 452
    .line 453
    if-ne v3, v10, :cond_13

    .line 454
    .line 455
    :cond_12
    new-instance v3, Loo;

    .line 456
    .line 457
    const/16 v1, 0xf

    .line 458
    .line 459
    invoke-direct {v3, v15, v1}, Loo;-><init>(Lfa2;B)V

    .line 460
    .line 461
    .line 462
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 463
    .line 464
    .line 465
    :cond_13
    move-object/from16 v23, v3

    .line 466
    .line 467
    check-cast v23, Lqa2;

    .line 468
    .line 469
    const/16 v25, 0x180

    .line 470
    .line 471
    const/16 v26, 0x70

    .line 472
    .line 473
    const/16 v19, 0x0

    .line 474
    .line 475
    const/16 v20, 0x0

    .line 476
    .line 477
    const/16 v21, 0x0

    .line 478
    .line 479
    const/16 v22, 0x0

    .line 480
    .line 481
    move-object/from16 v24, v0

    .line 482
    .line 483
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 484
    .line 485
    .line 486
    const/16 v20, 0x1

    .line 487
    .line 488
    if-eqz v8, :cond_16

    .line 489
    .line 490
    const v1, -0x657c2f03

    .line 491
    .line 492
    .line 493
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 494
    .line 495
    .line 496
    invoke-static {v6, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 497
    .line 498
    .line 499
    move-result-object v17

    .line 500
    invoke-virtual {v0, v14}, Lub2;->g(Ljava/lang/Object;)Z

    .line 501
    .line 502
    .line 503
    move-result v1

    .line 504
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    move-result-object v3

    .line 508
    if-nez v1, :cond_14

    .line 509
    .line 510
    if-ne v3, v10, :cond_15

    .line 511
    .line 512
    :cond_14
    new-instance v3, Loo;

    .line 513
    .line 514
    const/16 v1, 0x10

    .line 515
    .line 516
    invoke-direct {v3, v14, v1}, Loo;-><init>(Lfa2;B)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 520
    .line 521
    .line 522
    :cond_15
    move-object/from16 v23, v3

    .line 523
    .line 524
    check-cast v23, Lqa2;

    .line 525
    .line 526
    const/16 v25, 0x180

    .line 527
    .line 528
    const/16 v26, 0x70

    .line 529
    .line 530
    const/16 v19, 0x0

    .line 531
    .line 532
    const/16 v21, 0x0

    .line 533
    .line 534
    const/16 v22, 0x0

    .line 535
    .line 536
    move-object/from16 v24, v0

    .line 537
    .line 538
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 539
    .line 540
    .line 541
    invoke-virtual {v0, v2}, Lub2;->r(Z)V

    .line 542
    .line 543
    .line 544
    move/from16 v20, v9

    .line 545
    .line 546
    goto :goto_8

    .line 547
    :cond_16
    const v1, -0x657723ab

    .line 548
    .line 549
    .line 550
    invoke-virtual {v0, v1}, Lub2;->b0(I)V

    .line 551
    .line 552
    .line 553
    invoke-virtual {v0, v2}, Lub2;->r(Z)V

    .line 554
    .line 555
    .line 556
    :goto_8
    invoke-static {v5, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 557
    .line 558
    .line 559
    move-result-object v17

    .line 560
    add-int/lit8 v1, v20, 0x1

    .line 561
    .line 562
    invoke-virtual {v0, v13}, Lub2;->g(Ljava/lang/Object;)Z

    .line 563
    .line 564
    .line 565
    move-result v2

    .line 566
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 567
    .line 568
    .line 569
    move-result-object v3

    .line 570
    if-nez v2, :cond_17

    .line 571
    .line 572
    if-ne v3, v10, :cond_18

    .line 573
    .line 574
    :cond_17
    new-instance v3, Loo;

    .line 575
    .line 576
    const/16 v2, 0x11

    .line 577
    .line 578
    invoke-direct {v3, v13, v2}, Loo;-><init>(Lfa2;B)V

    .line 579
    .line 580
    .line 581
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 582
    .line 583
    .line 584
    :cond_18
    move-object/from16 v23, v3

    .line 585
    .line 586
    check-cast v23, Lqa2;

    .line 587
    .line 588
    const/16 v25, 0x180

    .line 589
    .line 590
    const/16 v26, 0x70

    .line 591
    .line 592
    const/16 v19, 0x0

    .line 593
    .line 594
    const/16 v21, 0x0

    .line 595
    .line 596
    const/16 v22, 0x0

    .line 597
    .line 598
    move-object/from16 v24, v0

    .line 599
    .line 600
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 601
    .line 602
    .line 603
    invoke-static {v4, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 604
    .line 605
    .line 606
    move-result-object v17

    .line 607
    add-int/lit8 v6, v20, 0x2

    .line 608
    .line 609
    invoke-virtual {v0, v12}, Lub2;->g(Ljava/lang/Object;)Z

    .line 610
    .line 611
    .line 612
    move-result v2

    .line 613
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 614
    .line 615
    .line 616
    move-result-object v3

    .line 617
    if-nez v2, :cond_19

    .line 618
    .line 619
    if-ne v3, v10, :cond_1a

    .line 620
    .line 621
    :cond_19
    new-instance v3, Loo;

    .line 622
    .line 623
    const/16 v2, 0x12

    .line 624
    .line 625
    invoke-direct {v3, v12, v2}, Loo;-><init>(Lfa2;B)V

    .line 626
    .line 627
    .line 628
    invoke-virtual {v0, v3}, Lub2;->k0(Ljava/lang/Object;)V

    .line 629
    .line 630
    .line 631
    :cond_1a
    move-object/from16 v23, v3

    .line 632
    .line 633
    check-cast v23, Lqa2;

    .line 634
    .line 635
    const/16 v25, 0x180

    .line 636
    .line 637
    const/16 v26, 0x70

    .line 638
    .line 639
    const/16 v19, 0x0

    .line 640
    .line 641
    const/16 v21, 0x0

    .line 642
    .line 643
    const/16 v22, 0x0

    .line 644
    .line 645
    move-object/from16 v24, v0

    .line 646
    .line 647
    move/from16 v20, v1

    .line 648
    .line 649
    invoke-static/range {v17 .. v26}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 650
    .line 651
    .line 652
    const v1, 0x7f0f00b6

    .line 653
    .line 654
    .line 655
    invoke-static {v1, v0}, Lkb3;->d0(ILub2;)Ljava/lang/String;

    .line 656
    .line 657
    .line 658
    move-result-object v3

    .line 659
    invoke-virtual {v0, v11}, Lub2;->g(Ljava/lang/Object;)Z

    .line 660
    .line 661
    .line 662
    move-result v1

    .line 663
    invoke-virtual {v0}, Lub2;->N()Ljava/lang/Object;

    .line 664
    .line 665
    .line 666
    move-result-object v2

    .line 667
    if-nez v1, :cond_1b

    .line 668
    .line 669
    if-ne v2, v10, :cond_1c

    .line 670
    .line 671
    :cond_1b
    new-instance v2, Loo;

    .line 672
    .line 673
    const/16 v1, 0x13

    .line 674
    .line 675
    invoke-direct {v2, v11, v1}, Loo;-><init>(Lfa2;B)V

    .line 676
    .line 677
    .line 678
    invoke-virtual {v0, v2}, Lub2;->k0(Ljava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    :cond_1c
    move-object v9, v2

    .line 682
    check-cast v9, Lqa2;

    .line 683
    .line 684
    const/16 v11, 0x180

    .line 685
    .line 686
    const/16 v12, 0x70

    .line 687
    .line 688
    const/4 v5, 0x0

    .line 689
    const/4 v7, 0x0

    .line 690
    const/4 v8, 0x0

    .line 691
    move-object v10, v0

    .line 692
    move/from16 v4, v18

    .line 693
    .line 694
    invoke-static/range {v3 .. v12}, Lhy3;->c(Ljava/lang/String;IZILct1;ZLqa2;Lub2;II)V

    .line 695
    .line 696
    .line 697
    goto :goto_9

    .line 698
    :cond_1d
    invoke-virtual {v0}, Lub2;->V()V

    .line 699
    .line 700
    .line 701
    :goto_9
    return-object v16

    .line 702
    :pswitch_2
    move-object/from16 v1, p1

    .line 703
    .line 704
    check-cast v1, Lub2;

    .line 705
    .line 706
    move-object/from16 v3, p2

    .line 707
    .line 708
    check-cast v3, Ljava/lang/Integer;

    .line 709
    .line 710
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 711
    .line 712
    .line 713
    move-result v3

    .line 714
    and-int/lit8 v4, v3, 0x3

    .line 715
    .line 716
    if-eq v4, v9, :cond_1e

    .line 717
    .line 718
    const/4 v2, 0x1

    .line 719
    :cond_1e
    const/16 v27, 0x1

    .line 720
    .line 721
    and-int/lit8 v3, v3, 0x1

    .line 722
    .line 723
    invoke-virtual {v1, v3, v2}, Lub2;->S(IZ)Z

    .line 724
    .line 725
    .line 726
    move-result v2

    .line 727
    if-eqz v2, :cond_1f

    .line 728
    .line 729
    new-instance v3, Law3;

    .line 730
    .line 731
    const/4 v4, 0x1

    .line 732
    iget-object v5, v0, Law3;->k:Lfa2;

    .line 733
    .line 734
    iget-object v6, v0, Law3;->l:Lfa2;

    .line 735
    .line 736
    iget-object v7, v0, Law3;->m:Lfa2;

    .line 737
    .line 738
    iget-object v8, v0, Law3;->n:Lfa2;

    .line 739
    .line 740
    iget-object v9, v0, Law3;->o:Lfa2;

    .line 741
    .line 742
    iget-boolean v10, v0, Law3;->j:Z

    .line 743
    .line 744
    invoke-direct/range {v3 .. v10}, Law3;-><init>(BLfa2;Lfa2;Lfa2;Lfa2;Lfa2;Z)V

    .line 745
    .line 746
    .line 747
    const v0, 0x73f86ccd

    .line 748
    .line 749
    .line 750
    invoke-static {v0, v3, v1}, Lwj;->N(ILcb2;Lub2;)Lc01;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    const/4 v2, 0x6

    .line 755
    invoke-static {v0, v1, v2}, Lhy3;->f(Lc01;Lub2;I)V

    .line 756
    .line 757
    .line 758
    goto :goto_a

    .line 759
    :cond_1f
    invoke-virtual {v1}, Lub2;->V()V

    .line 760
    .line 761
    .line 762
    :goto_a
    return-object v16

    .line 763
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
