.class public final La65;
.super Loa3;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final e:La65;

.field public static final f:La65;

.field public static final g:La65;

.field public static final h:La65;

.field public static final i:La65;

.field public static final j:La65;

.field public static final k:La65;

.field public static final l:La65;

.field public static final m:La65;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La65;

    .line 2
    .line 3
    invoke-direct {v0}, Loa3;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La65;->e:La65;

    .line 7
    .line 8
    new-instance v0, La65;

    .line 9
    .line 10
    invoke-direct {v0}, Loa3;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, La65;->f:La65;

    .line 14
    .line 15
    new-instance v0, La65;

    .line 16
    .line 17
    invoke-direct {v0}, Loa3;-><init>()V

    .line 18
    .line 19
    .line 20
    sput-object v0, La65;->g:La65;

    .line 21
    .line 22
    new-instance v0, La65;

    .line 23
    .line 24
    invoke-direct {v0}, Loa3;-><init>()V

    .line 25
    .line 26
    .line 27
    sput-object v0, La65;->h:La65;

    .line 28
    .line 29
    new-instance v0, La65;

    .line 30
    .line 31
    invoke-direct {v0}, Loa3;-><init>()V

    .line 32
    .line 33
    .line 34
    sput-object v0, La65;->i:La65;

    .line 35
    .line 36
    new-instance v0, La65;

    .line 37
    .line 38
    invoke-direct {v0}, Loa3;-><init>()V

    .line 39
    .line 40
    .line 41
    sput-object v0, La65;->j:La65;

    .line 42
    .line 43
    new-instance v0, La65;

    .line 44
    .line 45
    invoke-direct {v0}, Loa3;-><init>()V

    .line 46
    .line 47
    .line 48
    sput-object v0, La65;->k:La65;

    .line 49
    .line 50
    new-instance v0, La65;

    .line 51
    .line 52
    invoke-direct {v0}, Loa3;-><init>()V

    .line 53
    .line 54
    .line 55
    sput-object v0, La65;->l:La65;

    .line 56
    .line 57
    new-instance v0, La65;

    .line 58
    .line 59
    invoke-direct {v0}, Loa3;-><init>()V

    .line 60
    .line 61
    .line 62
    sput-object v0, La65;->m:La65;

    .line 63
    .line 64
    return-void
.end method
