.class public final enum Law0;
.super Ljava/lang/Enum;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# static fields
.field public static final enum i:Law0;

.field public static final enum j:Law0;

.field public static final enum k:Law0;

.field public static final enum l:Law0;

.field public static final enum m:Law0;

.field public static final synthetic n:[Law0;


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 1
    new-instance v0, Law0;

    .line 2
    .line 3
    const-string v1, "System"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Law0;->i:Law0;

    .line 10
    .line 11
    new-instance v1, Law0;

    .line 12
    .line 13
    const-string v2, "Light"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v1, Law0;->j:Law0;

    .line 20
    .line 21
    new-instance v2, Law0;

    .line 22
    .line 23
    const-string v3, "Dark"

    .line 24
    .line 25
    const/4 v4, 0x2

    .line 26
    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    sput-object v2, Law0;->k:Law0;

    .line 30
    .line 31
    new-instance v3, Law0;

    .line 32
    .line 33
    const-string v4, "MonetSystem"

    .line 34
    .line 35
    const/4 v5, 0x3

    .line 36
    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    new-instance v4, Law0;

    .line 40
    .line 41
    const-string v5, "MonetLight"

    .line 42
    .line 43
    const/4 v6, 0x4

    .line 44
    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 45
    .line 46
    .line 47
    sput-object v4, Law0;->l:Law0;

    .line 48
    .line 49
    new-instance v5, Law0;

    .line 50
    .line 51
    const-string v6, "MonetDark"

    .line 52
    .line 53
    const/4 v7, 0x5

    .line 54
    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 55
    .line 56
    .line 57
    sput-object v5, Law0;->m:Law0;

    .line 58
    .line 59
    filled-new-array/range {v0 .. v5}, [Law0;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    sput-object v0, Law0;->n:[Law0;

    .line 64
    .line 65
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Law0;
    .locals 1

    .line 1
    const-class v0, Law0;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Law0;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Law0;
    .locals 1

    .line 1
    sget-object v0, Law0;->n:[Law0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Law0;

    .line 8
    .line 9
    return-object v0
.end method
