.class public final Lb33;
.super Ljava/lang/Object;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"

# interfaces
.implements Lks3;
.implements Ln23;


# instance fields
.field public final synthetic i:Ln23;

.field public final j:Ls93;


# direct methods
.method public constructor <init>(Ln23;Ls93;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb33;->i:Ln23;

    .line 5
    .line 6
    iput-object p2, p0, Lb33;->j:Ls93;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final D()Z
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0}, Ln23;->D()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final G(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->G(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final H(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lul1;->H(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final H0(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lul1;->H0(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final J(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->J(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final O0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lul1;->O0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0}, Lul1;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final b0(J)I
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lul1;->b0(J)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final b1(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->b1(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final f0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lul1;->f0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final getLayoutDirection()Ls93;
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->j:Ls93;

    .line 2
    .line 3
    return-object p0
.end method

.method public final l1(I)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->l1(I)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final p1(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->p1(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final r0(IILjava/util/Map;Lqa2;Lqa2;)Ljs3;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    if-gez p1, :cond_0

    .line 3
    .line 4
    move p1, p0

    .line 5
    :cond_0
    if-gez p2, :cond_1

    .line 6
    .line 7
    move p2, p0

    .line 8
    :cond_1
    const/high16 p0, -0x1000000

    .line 9
    .line 10
    and-int p5, p1, p0

    .line 11
    .line 12
    if-nez p5, :cond_2

    .line 13
    .line 14
    and-int/2addr p0, p2

    .line 15
    if-eqz p0, :cond_3

    .line 16
    .line 17
    :cond_2
    new-instance p0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string p5, "Size("

    .line 20
    .line 21
    invoke-direct {p0, p5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string p5, " x "

    .line 28
    .line 29
    invoke-virtual {p0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string p5, ") is out of range. Each dimension must be between 0 and 16777215."

    .line 36
    .line 37
    invoke-virtual {p0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    invoke-static {p0}, Lwy2;->b(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    :cond_3
    new-instance p0, La33;

    .line 48
    .line 49
    invoke-direct {p0, p1, p2, p3, p4}, La33;-><init>(IILjava/util/Map;Lqa2;)V

    .line 50
    .line 51
    .line 52
    return-object p0
.end method

.method public final s0(F)I
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lul1;->s0(F)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final x()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb33;->i:Ln23;

    .line 2
    .line 3
    invoke-interface {p0}, Lul1;->x()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
