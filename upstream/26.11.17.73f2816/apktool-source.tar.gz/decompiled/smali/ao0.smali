.class public final Lao0;
.super Lwn0;
.source "r8-map-id-07d5dc3cb9342a8afaff92e7481745fb00c4837e8510e4e302c7a33b4524dc59"


# instance fields
.field public final m:Lva2;


# direct methods
.method public constructor <init>(Lva2;Lf52;Lhf1;ILwe0;)V
    .locals 0

    .line 1
    invoke-direct {p0, p2, p3, p4, p5}, Lwn0;-><init>(Lf52;Lhf1;ILwe0;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lao0;->m:Lva2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final g(Lhf1;ILwe0;)Lun0;
    .locals 6

    .line 1
    new-instance v0, Lao0;

    .line 2
    .line 3
    iget-object v1, p0, Lao0;->m:Lva2;

    .line 4
    .line 5
    iget-object v2, p0, Lwn0;->l:Lf52;

    .line 6
    .line 7
    move-object v3, p1

    .line 8
    move v4, p2

    .line 9
    move-object v5, p3

    .line 10
    invoke-direct/range {v0 .. v5}, Lao0;-><init>(Lva2;Lf52;Lhf1;ILwe0;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final j(Lg52;Lia1;)Ljava/lang/Object;
    .locals 2

    .line 1
    new-instance v0, Lyn0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, p1, v1}, Lyn0;-><init>(Lao0;Lg52;Lia1;)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0, p2}, Lgj;->p(Lua2;Lia1;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    sget-object p1, Lsf1;->i:Lsf1;

    .line 12
    .line 13
    if-ne p0, p1, :cond_0

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_0
    sget-object p0, Lne7;->a:Lne7;

    .line 17
    .line 18
    return-object p0
.end method
