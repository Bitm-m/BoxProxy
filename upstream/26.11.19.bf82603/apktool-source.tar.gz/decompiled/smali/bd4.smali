.class public final Lbd4;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public j:B

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lea1;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lbd4;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lbd4;->k:Ljava/lang/Object;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1, p2}, Lvr6;-><init>(ILea1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Lea1;)Lea1;
    .locals 2

    .line 1
    iget-byte v0, p0, Lbd4;->i:B

    .line 2
    .line 3
    iget-object p0, p0, Lbd4;->k:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v0, Lbd4;

    .line 9
    .line 10
    check-cast p0, Lbx6;

    .line 11
    .line 12
    const/4 v1, 0x2

    .line 13
    invoke-direct {v0, p0, p1, v1}, Lbd4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 14
    .line 15
    .line 16
    return-object v0

    .line 17
    :pswitch_0
    new-instance v0, Lbd4;

    .line 18
    .line 19
    check-cast p0, Lfw5;

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    invoke-direct {v0, p0, p1, v1}, Lbd4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 23
    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_1
    new-instance v0, Lbd4;

    .line 27
    .line 28
    check-cast p0, Lfd4;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    invoke-direct {v0, p0, p1, v1}, Lbd4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 32
    .line 33
    .line 34
    return-object v0

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lbd4;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    check-cast p1, Lea1;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1}, Lbd4;->create(Lea1;)Lea1;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, Lbd4;

    .line 15
    .line 16
    invoke-virtual {p0, v1}, Lbd4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :pswitch_0
    invoke-virtual {p0, p1}, Lbd4;->create(Lea1;)Lea1;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Lbd4;

    .line 26
    .line 27
    invoke-virtual {p0, v1}, Lbd4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    :pswitch_1
    invoke-virtual {p0, p1}, Lbd4;->create(Lea1;)Lea1;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    check-cast p0, Lbd4;

    .line 37
    .line 38
    invoke-virtual {p0, v1}, Lbd4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbd4;->i:B

    .line 4
    .line 5
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 6
    .line 7
    sget-object v3, Lof1;->i:Lof1;

    .line 8
    .line 9
    iget-object v4, v0, Lbd4;->k:Ljava/lang/Object;

    .line 10
    .line 11
    sget-object v5, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    const/4 v6, 0x1

    .line 14
    const/4 v7, 0x2

    .line 15
    packed-switch v1, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    check-cast v4, Lbx6;

    .line 19
    .line 20
    iget-byte v1, v0, Lbd4;->j:B

    .line 21
    .line 22
    if-eqz v1, :cond_2

    .line 23
    .line 24
    if-eq v1, v6, :cond_1

    .line 25
    .line 26
    if-ne v1, v7, :cond_0

    .line 27
    .line 28
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_0
    invoke-static {v2}, La02;->d(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    goto :goto_2

    .line 37
    :cond_1
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    iget-object v1, v4, Lbx6;->C:Liz6;

    .line 45
    .line 46
    iput-byte v6, v0, Lbd4;->j:B

    .line 47
    .line 48
    invoke-virtual {v1}, Liz6;->z()Lxc7;

    .line 49
    .line 50
    .line 51
    if-eq v5, v3, :cond_5

    .line 52
    .line 53
    :goto_0
    iget-object v1, v4, Lbx6;->I:Ls05;

    .line 54
    .line 55
    if-eqz v1, :cond_4

    .line 56
    .line 57
    iget-object v2, v4, Lbx6;->C:Liz6;

    .line 58
    .line 59
    iget-object v2, v2, Liz6;->a:Lw77;

    .line 60
    .line 61
    invoke-virtual {v2}, Lw77;->f()Lvw6;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    iget-object v2, v2, Lvw6;->k:Ljava/lang/CharSequence;

    .line 66
    .line 67
    iget-object v6, v4, Lbx6;->C:Liz6;

    .line 68
    .line 69
    iget-object v6, v6, Liz6;->a:Lw77;

    .line 70
    .line 71
    invoke-virtual {v6}, Lw77;->f()Lvw6;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    iget-wide v8, v6, Lvw6;->l:J

    .line 76
    .line 77
    iput-byte v7, v0, Lbd4;->j:B

    .line 78
    .line 79
    invoke-virtual {v1, v2, v8, v9, v0}, Ls05;->d(Ljava/lang/CharSequence;JLvr6;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-eq v0, v3, :cond_3

    .line 84
    .line 85
    move-object v0, v5

    .line 86
    :cond_3
    if-eq v0, v3, :cond_5

    .line 87
    .line 88
    :cond_4
    :goto_1
    iget-object v0, v4, Lbx6;->C:Liz6;

    .line 89
    .line 90
    iget-object v0, v0, Liz6;->t:Lgx4;

    .line 91
    .line 92
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 93
    .line 94
    invoke-virtual {v0, v1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    move-object v3, v5

    .line 98
    :cond_5
    :goto_2
    return-object v3

    .line 99
    :pswitch_0
    check-cast v4, Lfw5;

    .line 100
    .line 101
    iget-object v1, v4, Lfw5;->u:Lgx4;

    .line 102
    .line 103
    iget-object v9, v4, Lfw5;->x:Lgx4;

    .line 104
    .line 105
    iget-object v10, v4, Lfw5;->v:Lgx4;

    .line 106
    .line 107
    iget-object v11, v4, Lfw5;->f:Lfa2;

    .line 108
    .line 109
    iget-object v12, v4, Lfw5;->a:Ljava/lang/String;

    .line 110
    .line 111
    iget-object v13, v4, Lfw5;->r:Lgx4;

    .line 112
    .line 113
    iget-object v14, v4, Lfw5;->o:Lgx4;

    .line 114
    .line 115
    iget-byte v15, v0, Lbd4;->j:B

    .line 116
    .line 117
    if-eqz v15, :cond_8

    .line 118
    .line 119
    if-eq v15, v6, :cond_7

    .line 120
    .line 121
    if-ne v15, v7, :cond_6

    .line 122
    .line 123
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    move-object/from16 v0, p1

    .line 127
    .line 128
    goto :goto_4

    .line 129
    :cond_6
    invoke-static {v2}, La02;->d(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    const/4 v3, 0x0

    .line 133
    goto/16 :goto_9

    .line 134
    .line 135
    :cond_7
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    move-object/from16 v2, p1

    .line 139
    .line 140
    goto :goto_3

    .line 141
    :cond_8
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 142
    .line 143
    .line 144
    sget-object v2, Lfw5;->z:Lzu5;

    .line 145
    .line 146
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 147
    .line 148
    invoke-virtual {v13, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    const/4 v2, 0x0

    .line 152
    invoke-virtual {v4, v2}, Lfw5;->n(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    iget-boolean v15, v4, Lfw5;->j:Z

    .line 156
    .line 157
    if-eqz v15, :cond_a

    .line 158
    .line 159
    sget-object v15, Lao1;->a:Lck1;

    .line 160
    .line 161
    sget-object v15, Luj1;->k:Luj1;

    .line 162
    .line 163
    new-instance v7, Lv3;

    .line 164
    .line 165
    const/16 v8, 0x1b

    .line 166
    .line 167
    invoke-direct {v7, v4, v2, v8}, Lv3;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 168
    .line 169
    .line 170
    iput-byte v6, v0, Lbd4;->j:B

    .line 171
    .line 172
    invoke-static {v15, v7, v0}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    if-eq v2, v3, :cond_f

    .line 177
    .line 178
    :goto_3
    check-cast v2, Lxu5;

    .line 179
    .line 180
    if-eqz v2, :cond_9

    .line 181
    .line 182
    iget-object v7, v2, Lxu5;->b:Ljava/lang/String;

    .line 183
    .line 184
    sget-object v8, Lfw5;->z:Lzu5;

    .line 185
    .line 186
    invoke-virtual {v14, v7}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    iget-object v2, v2, Lxu5;->c:Ljava/lang/String;

    .line 190
    .line 191
    invoke-virtual {v4, v2}, Lfw5;->l(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    :cond_9
    const/4 v2, 0x0

    .line 195
    iput-boolean v2, v4, Lfw5;->j:Z

    .line 196
    .line 197
    :cond_a
    iget-object v7, v4, Lfw5;->b:Lja2;

    .line 198
    .line 199
    const/4 v8, 0x2

    .line 200
    iput-byte v8, v0, Lbd4;->j:B

    .line 201
    .line 202
    invoke-interface {v7, v12, v0}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    if-eq v0, v3, :cond_f

    .line 207
    .line 208
    :goto_4
    check-cast v0, Lgv;

    .line 209
    .line 210
    iget-object v3, v0, Lgv;->a:Ljava/lang/Object;

    .line 211
    .line 212
    check-cast v3, Laz5;

    .line 213
    .line 214
    if-eqz v3, :cond_e

    .line 215
    .line 216
    iget-object v0, v3, Laz5;->b:Ljava/lang/String;

    .line 217
    .line 218
    iget-object v7, v3, Laz5;->c:Lcz5;

    .line 219
    .line 220
    iget-object v3, v3, Laz5;->a:Lbz5;

    .line 221
    .line 222
    invoke-virtual {v4}, Lfw5;->b()Ljava/lang/String;

    .line 223
    .line 224
    .line 225
    move-result-object v8

    .line 226
    invoke-virtual {v14}, Lgx4;->getValue()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v12

    .line 230
    check-cast v12, Ljava/lang/String;

    .line 231
    .line 232
    invoke-static {v8, v12}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 233
    .line 234
    .line 235
    move-result v8

    .line 236
    iget-object v12, v3, Lbz5;->a:Ljava/lang/String;

    .line 237
    .line 238
    iget-object v15, v3, Lbz5;->b:Ljava/lang/String;

    .line 239
    .line 240
    iget-object v2, v4, Lfw5;->l:Lgx4;

    .line 241
    .line 242
    invoke-virtual {v2, v12}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 243
    .line 244
    .line 245
    iget-object v2, v4, Lfw5;->e:Lfa2;

    .line 246
    .line 247
    invoke-interface {v2, v15}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v2

    .line 251
    check-cast v2, Ljava/lang/String;

    .line 252
    .line 253
    iget-object v12, v4, Lfw5;->m:Lgx4;

    .line 254
    .line 255
    invoke-virtual {v12, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    move-object v2, v7

    .line 259
    iget-wide v6, v3, Lbz5;->c:J

    .line 260
    .line 261
    iget-object v12, v4, Lfw5;->n:Lgx4;

    .line 262
    .line 263
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 264
    .line 265
    .line 266
    move-result-object v6

    .line 267
    invoke-virtual {v12, v6}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    invoke-interface {v11, v15}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v6

    .line 274
    check-cast v6, Ljava/lang/String;

    .line 275
    .line 276
    invoke-virtual {v10, v6}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    invoke-virtual {v9, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 280
    .line 281
    .line 282
    iget-boolean v3, v3, Lbz5;->d:Z

    .line 283
    .line 284
    if-eqz v3, :cond_b

    .line 285
    .line 286
    if-eqz v0, :cond_b

    .line 287
    .line 288
    if-nez v2, :cond_b

    .line 289
    .line 290
    const/4 v6, 0x1

    .line 291
    goto :goto_5

    .line 292
    :cond_b
    const/4 v6, 0x0

    .line 293
    :goto_5
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 294
    .line 295
    .line 296
    move-result-object v2

    .line 297
    invoke-virtual {v1, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 298
    .line 299
    .line 300
    if-eqz v0, :cond_d

    .line 301
    .line 302
    invoke-virtual {v14, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 303
    .line 304
    .line 305
    if-eqz v8, :cond_c

    .line 306
    .line 307
    invoke-virtual {v4, v0}, Lfw5;->l(Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    :cond_c
    :goto_6
    const/4 v2, 0x0

    .line 311
    goto :goto_7

    .line 312
    :cond_d
    const-string v0, ""

    .line 313
    .line 314
    invoke-virtual {v14, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 315
    .line 316
    .line 317
    if-eqz v8, :cond_c

    .line 318
    .line 319
    invoke-virtual {v4, v0}, Lfw5;->l(Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    goto :goto_6

    .line 323
    :goto_7
    invoke-virtual {v4, v2}, Lfw5;->n(Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    goto :goto_8

    .line 327
    :cond_e
    const/4 v2, 0x0

    .line 328
    iget-object v0, v0, Lgv;->b:Ljava/lang/String;

    .line 329
    .line 330
    sget-object v3, Lfw5;->z:Lzu5;

    .line 331
    .line 332
    invoke-virtual {v4, v0}, Lfw5;->n(Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 336
    .line 337
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 338
    .line 339
    .line 340
    invoke-interface {v11, v12}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    check-cast v0, Ljava/lang/String;

    .line 345
    .line 346
    invoke-virtual {v10, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v9, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 350
    .line 351
    .line 352
    :goto_8
    sget-object v0, Lfw5;->z:Lzu5;

    .line 353
    .line 354
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 355
    .line 356
    invoke-virtual {v13, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 357
    .line 358
    .line 359
    invoke-virtual {v4}, Lfw5;->j()V

    .line 360
    .line 361
    .line 362
    move-object v3, v5

    .line 363
    :cond_f
    :goto_9
    return-object v3

    .line 364
    :pswitch_1
    check-cast v4, Lfd4;

    .line 365
    .line 366
    iget-object v1, v4, Lfd4;->e:Lmf4;

    .line 367
    .line 368
    iget-object v6, v4, Lfd4;->a:Lev3;

    .line 369
    .line 370
    iget-byte v7, v0, Lbd4;->j:B

    .line 371
    .line 372
    const/4 v8, 0x1

    .line 373
    if-eqz v7, :cond_12

    .line 374
    .line 375
    if-eq v7, v8, :cond_11

    .line 376
    .line 377
    const/4 v9, 0x2

    .line 378
    if-ne v7, v9, :cond_10

    .line 379
    .line 380
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 381
    .line 382
    .line 383
    move-object/from16 v0, p1

    .line 384
    .line 385
    const/4 v10, 0x0

    .line 386
    goto :goto_b

    .line 387
    :cond_10
    invoke-static {v2}, La02;->d(Ljava/lang/String;)V

    .line 388
    .line 389
    .line 390
    const/4 v3, 0x0

    .line 391
    goto/16 :goto_d

    .line 392
    .line 393
    :cond_11
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 394
    .line 395
    .line 396
    move-object/from16 v2, p1

    .line 397
    .line 398
    goto :goto_a

    .line 399
    :cond_12
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 400
    .line 401
    .line 402
    sget-object v2, Ldf4;->a:Ly44;

    .line 403
    .line 404
    iput-byte v8, v0, Lbd4;->j:B

    .line 405
    .line 406
    sget-object v2, Lao1;->a:Lck1;

    .line 407
    .line 408
    sget-object v2, Luj1;->k:Luj1;

    .line 409
    .line 410
    new-instance v7, Lmg0;

    .line 411
    .line 412
    const/4 v9, 0x2

    .line 413
    const/4 v10, 0x0

    .line 414
    invoke-direct {v7, v9, v10, v8}, Lmg0;-><init>(ILea1;B)V

    .line 415
    .line 416
    .line 417
    invoke-static {v2, v7, v0}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v2

    .line 421
    if-eq v2, v3, :cond_1a

    .line 422
    .line 423
    :goto_a
    check-cast v2, Laf4;

    .line 424
    .line 425
    iget-object v7, v2, Laf4;->b:Ljava/lang/String;

    .line 426
    .line 427
    if-eqz v7, :cond_13

    .line 428
    .line 429
    invoke-static {v7}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 430
    .line 431
    .line 432
    move-result v8

    .line 433
    if-eqz v8, :cond_14

    .line 434
    .line 435
    :cond_13
    const/4 v7, 0x0

    .line 436
    :cond_14
    iget-object v2, v2, Laf4;->a:Ljava/lang/Object;

    .line 437
    .line 438
    check-cast v2, Lze4;

    .line 439
    .line 440
    if-eqz v2, :cond_15

    .line 441
    .line 442
    iput-object v2, v4, Lfd4;->g:Lze4;

    .line 443
    .line 444
    iget-object v8, v4, Lfd4;->b:Lmd4;

    .line 445
    .line 446
    invoke-virtual {v8, v2}, Lmd4;->a(Lze4;)V

    .line 447
    .line 448
    .line 449
    :cond_15
    if-eqz v7, :cond_16

    .line 450
    .line 451
    sget-object v2, Lxb7;->a:Landroid/os/Handler;

    .line 452
    .line 453
    invoke-virtual {v6}, Lev3;->invoke()Ljava/lang/Object;

    .line 454
    .line 455
    .line 456
    move-result-object v2

    .line 457
    check-cast v2, Landroid/content/Context;

    .line 458
    .line 459
    invoke-static {v2, v7}, Lxb7;->b(Landroid/content/Context;Ljava/lang/String;)V

    .line 460
    .line 461
    .line 462
    :cond_16
    sget-object v2, Ldf4;->a:Ly44;

    .line 463
    .line 464
    const/4 v9, 0x2

    .line 465
    iput-byte v9, v0, Lbd4;->j:B

    .line 466
    .line 467
    sget-object v2, Lao1;->a:Lck1;

    .line 468
    .line 469
    sget-object v2, Luj1;->k:Luj1;

    .line 470
    .line 471
    new-instance v7, Lmg0;

    .line 472
    .line 473
    const/4 v10, 0x0

    .line 474
    invoke-direct {v7, v9, v10, v9}, Lmg0;-><init>(ILea1;B)V

    .line 475
    .line 476
    .line 477
    invoke-static {v2, v7, v0}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    move-result-object v0

    .line 481
    if-eq v0, v3, :cond_1a

    .line 482
    .line 483
    :goto_b
    check-cast v0, Laf4;

    .line 484
    .line 485
    sget-boolean v2, Lpf4;->b:Z

    .line 486
    .line 487
    if-nez v2, :cond_19

    .line 488
    .line 489
    iget-object v2, v0, Laf4;->a:Ljava/lang/Object;

    .line 490
    .line 491
    check-cast v2, Ljava/util/List;

    .line 492
    .line 493
    if-eqz v2, :cond_17

    .line 494
    .line 495
    iget-object v3, v1, Lmf4;->a:Lgx4;

    .line 496
    .line 497
    invoke-virtual {v3, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 498
    .line 499
    .line 500
    const/16 v16, 0x1

    .line 501
    .line 502
    sput-boolean v16, Lpf4;->b:Z

    .line 503
    .line 504
    :cond_17
    iget-object v0, v0, Laf4;->b:Ljava/lang/String;

    .line 505
    .line 506
    if-eqz v0, :cond_19

    .line 507
    .line 508
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 509
    .line 510
    .line 511
    move-result v2

    .line 512
    if-nez v2, :cond_18

    .line 513
    .line 514
    move-object v8, v0

    .line 515
    goto :goto_c

    .line 516
    :cond_18
    move-object v8, v10

    .line 517
    :goto_c
    if-eqz v8, :cond_19

    .line 518
    .line 519
    sget-object v0, Lxb7;->a:Landroid/os/Handler;

    .line 520
    .line 521
    invoke-virtual {v6}, Lev3;->invoke()Ljava/lang/Object;

    .line 522
    .line 523
    .line 524
    move-result-object v0

    .line 525
    check-cast v0, Landroid/content/Context;

    .line 526
    .line 527
    invoke-static {v0, v8}, Lxb7;->b(Landroid/content/Context;Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    :cond_19
    invoke-virtual {v1}, Lmf4;->a()Ljava/util/List;

    .line 531
    .line 532
    .line 533
    move-result-object v0

    .line 534
    iput-object v0, v4, Lfd4;->h:Ljava/util/List;

    .line 535
    .line 536
    iget-object v0, v4, Lfd4;->d:Lre4;

    .line 537
    .line 538
    iget-object v0, v0, Lre4;->a:Lj44;

    .line 539
    .line 540
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 541
    .line 542
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    move-object v3, v5

    .line 546
    :cond_1a
    :goto_d
    return-object v3

    .line 547
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
