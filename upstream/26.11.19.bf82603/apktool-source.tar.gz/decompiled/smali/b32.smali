.class public abstract Lb32;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lxc;

.field public static final b:Lj6;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Ljw;->x()Lxc;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sput-object v0, Lb32;->a:Lxc;

    .line 6
    .line 7
    new-instance v0, Lj6;

    .line 8
    .line 9
    const/16 v1, 0x14

    .line 10
    .line 11
    invoke-direct {v0, v1}, Lj6;-><init>(B)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lb32;->b:Lj6;

    .line 15
    .line 16
    return-void
.end method
