.class public final synthetic Lay3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Leh6;Lfa2;Lu92;)V
    .locals 1

    .line 1
    const/16 v0, 0x11

    .line 2
    .line 3
    iput-byte v0, p0, Lay3;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lay3;->k:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p2, p0, Lay3;->l:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p3, p0, Lay3;->j:Ljava/lang/Object;

    .line 13
    .line 14
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 15
    iput-byte p4, p0, Lay3;->i:B

    iput-object p1, p0, Lay3;->j:Ljava/lang/Object;

    iput-object p2, p0, Lay3;->k:Ljava/lang/Object;

    iput-object p3, p0, Lay3;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/Set;Lu92;Lu92;Lfa2;)V
    .locals 0

    .line 16
    const/16 p3, 0xf

    iput-byte p3, p0, Lay3;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lay3;->k:Ljava/lang/Object;

    iput-object p2, p0, Lay3;->j:Ljava/lang/Object;

    iput-object p4, p0, Lay3;->l:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-byte v2, v0, Lay3;->i:B

    .line 6
    .line 7
    const/high16 v3, 0x3f800000    # 1.0f

    .line 8
    .line 9
    const/16 v4, 0xa

    .line 10
    .line 11
    const/16 v5, 0x8

    .line 12
    .line 13
    const/4 v6, 0x7

    .line 14
    const/4 v7, 0x0

    .line 15
    const/4 v8, 0x0

    .line 16
    const/4 v9, 0x2

    .line 17
    const/4 v10, 0x0

    .line 18
    const/4 v11, 0x1

    .line 19
    packed-switch v2, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v2, Lfa2;

    .line 25
    .line 26
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v3, Lvi7;

    .line 29
    .line 30
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, Lj44;

    .line 33
    .line 34
    check-cast v1, Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 40
    .line 41
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {v2, v3}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    sget-object v0, Lxc7;->a:Lxc7;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_0
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v2, Le27;

    .line 53
    .line 54
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v3, Ljava/lang/String;

    .line 57
    .line 58
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, Lal6;

    .line 61
    .line 62
    check-cast v1, Ljava/lang/Throwable;

    .line 63
    .line 64
    iget-object v1, v2, Le27;->k:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v1, Ljava/util/LinkedHashMap;

    .line 67
    .line 68
    monitor-enter v1

    .line 69
    :try_start_0
    iget-object v4, v2, Le27;->k:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v4, Ljava/util/LinkedHashMap;

    .line 72
    .line 73
    invoke-virtual {v4, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    if-ne v4, v0, :cond_0

    .line 78
    .line 79
    iget-object v0, v2, Le27;->k:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 82
    .line 83
    invoke-interface {v0, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 84
    .line 85
    .line 86
    :cond_0
    monitor-exit v1

    .line 87
    sget-object v0, Lxc7;->a:Lxc7;

    .line 88
    .line 89
    return-object v0

    .line 90
    :catchall_0
    move-exception v0

    .line 91
    monitor-exit v1

    .line 92
    throw v0

    .line 93
    :pswitch_1
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v2, Lqj5;

    .line 96
    .line 97
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v3, Lv67;

    .line 100
    .line 101
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v0, Lqj5;

    .line 104
    .line 105
    check-cast v1, Lbi;

    .line 106
    .line 107
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    iget-object v4, v1, Lbi;->e:Lgx4;

    .line 111
    .line 112
    invoke-virtual {v4}, Lgx4;->getValue()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    check-cast v5, Ljava/lang/Number;

    .line 117
    .line 118
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 119
    .line 120
    .line 121
    move-result v5

    .line 122
    iget v6, v2, Lqj5;->i:F

    .line 123
    .line 124
    sub-float/2addr v5, v6

    .line 125
    iget-object v6, v3, Lv67;->e:Lcx4;

    .line 126
    .line 127
    invoke-virtual {v6}, Lcx4;->g()F

    .line 128
    .line 129
    .line 130
    move-result v6

    .line 131
    add-float v7, v6, v5

    .line 132
    .line 133
    invoke-virtual {v3, v7}, Lv67;->b(F)V

    .line 134
    .line 135
    .line 136
    iget-object v3, v3, Lv67;->e:Lcx4;

    .line 137
    .line 138
    invoke-virtual {v3}, Lcx4;->g()F

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    sub-float/2addr v6, v3

    .line 143
    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    invoke-virtual {v4}, Lgx4;->getValue()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v4

    .line 151
    check-cast v4, Ljava/lang/Number;

    .line 152
    .line 153
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    iput v4, v2, Lqj5;->i:F

    .line 158
    .line 159
    invoke-virtual {v1}, Lbi;->b()Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    check-cast v2, Ljava/lang/Number;

    .line 164
    .line 165
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 166
    .line 167
    .line 168
    move-result v2

    .line 169
    iput v2, v0, Lqj5;->i:F

    .line 170
    .line 171
    sub-float/2addr v5, v3

    .line 172
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    const/high16 v2, 0x3f000000    # 0.5f

    .line 177
    .line 178
    cmpl-float v0, v0, v2

    .line 179
    .line 180
    if-lez v0, :cond_1

    .line 181
    .line 182
    invoke-virtual {v1}, Lbi;->a()V

    .line 183
    .line 184
    .line 185
    :cond_1
    sget-object v0, Lxc7;->a:Lxc7;

    .line 186
    .line 187
    return-object v0

    .line 188
    :pswitch_2
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 189
    .line 190
    move-object v15, v2

    .line 191
    check-cast v15, Liz6;

    .line 192
    .line 193
    iget-object v2, v0, Lay3;->k:Ljava/lang/Object;

    .line 194
    .line 195
    check-cast v2, Lnf1;

    .line 196
    .line 197
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 198
    .line 199
    check-cast v0, Landroid/content/Context;

    .line 200
    .line 201
    check-cast v1, Lvv6;

    .line 202
    .line 203
    invoke-virtual {v1}, Lvv6;->a()V

    .line 204
    .line 205
    .line 206
    iget-object v3, v1, Lvv6;->a:Lv34;

    .line 207
    .line 208
    sget-object v4, Lfw6;->j:[Lfw6;

    .line 209
    .line 210
    iget-object v4, v15, Liz6;->a:Lw77;

    .line 211
    .line 212
    invoke-virtual {v4}, Lw77;->f()Lvw6;

    .line 213
    .line 214
    .line 215
    move-result-object v4

    .line 216
    iget-wide v7, v4, Lvw6;->l:J

    .line 217
    .line 218
    invoke-static {v7, v8}, Lc17;->b(J)Z

    .line 219
    .line 220
    .line 221
    move-result v4

    .line 222
    if-nez v4, :cond_2

    .line 223
    .line 224
    invoke-virtual {v15}, Liz6;->m()Z

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    if-eqz v4, :cond_2

    .line 229
    .line 230
    move v4, v11

    .line 231
    goto :goto_0

    .line 232
    :cond_2
    move v4, v10

    .line 233
    :goto_0
    new-instance v7, Lkz6;

    .line 234
    .line 235
    const/4 v14, 0x0

    .line 236
    invoke-direct {v7, v15, v14, v10}, Lkz6;-><init>(Liz6;Lea1;B)V

    .line 237
    .line 238
    .line 239
    new-instance v13, La50;

    .line 240
    .line 241
    invoke-direct {v13, v2, v7, v9}, La50;-><init>(Lnf1;Lfa2;B)V

    .line 242
    .line 243
    .line 244
    sget-object v16, Lc27;->i:Lc27;

    .line 245
    .line 246
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 247
    .line 248
    .line 249
    move-result-object v7

    .line 250
    new-instance v12, Lb2;

    .line 251
    .line 252
    const/16 v17, 0xf

    .line 253
    .line 254
    invoke-direct/range {v12 .. v17}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 255
    .line 256
    .line 257
    if-eqz v4, :cond_3

    .line 258
    .line 259
    sget-object v4, Lqf0;->c0:Ljava/lang/Object;

    .line 260
    .line 261
    const v8, 0x1040003

    .line 262
    .line 263
    .line 264
    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v7

    .line 268
    new-instance v8, Lew6;

    .line 269
    .line 270
    const v13, 0x1010311

    .line 271
    .line 272
    .line 273
    invoke-direct {v8, v4, v7, v13, v12}, Lew6;-><init>(Ljava/lang/Object;Ljava/lang/String;ILfa2;)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v3, v8}, Lv34;->a(Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    :cond_3
    sget-object v4, Lfw6;->j:[Lfw6;

    .line 280
    .line 281
    iget-object v4, v15, Liz6;->a:Lw77;

    .line 282
    .line 283
    invoke-virtual {v4}, Lw77;->f()Lvw6;

    .line 284
    .line 285
    .line 286
    move-result-object v4

    .line 287
    iget-wide v7, v4, Lvw6;->l:J

    .line 288
    .line 289
    invoke-static {v7, v8}, Lc17;->b(J)Z

    .line 290
    .line 291
    .line 292
    move-result v4

    .line 293
    new-instance v7, Lkz6;

    .line 294
    .line 295
    invoke-direct {v7, v15, v14, v11}, Lkz6;-><init>(Liz6;Lea1;B)V

    .line 296
    .line 297
    .line 298
    new-instance v13, La50;

    .line 299
    .line 300
    invoke-direct {v13, v2, v7, v9}, La50;-><init>(Lnf1;Lfa2;B)V

    .line 301
    .line 302
    .line 303
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 304
    .line 305
    .line 306
    move-result-object v7

    .line 307
    new-instance v12, Lb2;

    .line 308
    .line 309
    const/16 v17, 0xf

    .line 310
    .line 311
    invoke-direct/range {v12 .. v17}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 312
    .line 313
    .line 314
    if-nez v4, :cond_4

    .line 315
    .line 316
    sget-object v4, Lqf0;->d0:Ljava/lang/Object;

    .line 317
    .line 318
    const v8, 0x1040001

    .line 319
    .line 320
    .line 321
    invoke-virtual {v7, v8}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v7

    .line 325
    new-instance v8, Lew6;

    .line 326
    .line 327
    const v13, 0x1010312

    .line 328
    .line 329
    .line 330
    invoke-direct {v8, v4, v7, v13, v12}, Lew6;-><init>(Ljava/lang/Object;Ljava/lang/String;ILfa2;)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {v3, v8}, Lv34;->a(Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    :cond_4
    sget-object v4, Lfw6;->j:[Lfw6;

    .line 337
    .line 338
    invoke-virtual {v15}, Liz6;->m()Z

    .line 339
    .line 340
    .line 341
    move-result v4

    .line 342
    if-eqz v4, :cond_6

    .line 343
    .line 344
    iget-object v4, v15, Liz6;->y:Lwr0;

    .line 345
    .line 346
    iget-boolean v4, v4, Lwr0;->i:Z

    .line 347
    .line 348
    if-eqz v4, :cond_5

    .line 349
    .line 350
    move v4, v11

    .line 351
    goto :goto_1

    .line 352
    :cond_5
    iget-object v4, v15, Liz6;->m:Lgx6;

    .line 353
    .line 354
    if-eqz v4, :cond_6

    .line 355
    .line 356
    invoke-virtual {v4}, Lgx6;->invoke()Ljava/lang/Object;

    .line 357
    .line 358
    .line 359
    :cond_6
    move v4, v10

    .line 360
    :goto_1
    new-instance v7, Lkz6;

    .line 361
    .line 362
    invoke-direct {v7, v15, v14, v9}, Lkz6;-><init>(Liz6;Lea1;B)V

    .line 363
    .line 364
    .line 365
    new-instance v13, La50;

    .line 366
    .line 367
    invoke-direct {v13, v2, v7, v9}, La50;-><init>(Lnf1;Lfa2;B)V

    .line 368
    .line 369
    .line 370
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 371
    .line 372
    .line 373
    move-result-object v2

    .line 374
    new-instance v12, Lb2;

    .line 375
    .line 376
    const/16 v17, 0xf

    .line 377
    .line 378
    invoke-direct/range {v12 .. v17}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 379
    .line 380
    .line 381
    move-object v8, v14

    .line 382
    move-object/from16 v7, v16

    .line 383
    .line 384
    if-eqz v4, :cond_7

    .line 385
    .line 386
    sget-object v4, Lqf0;->e0:Ljava/lang/Object;

    .line 387
    .line 388
    const v9, 0x104000b

    .line 389
    .line 390
    .line 391
    invoke-virtual {v2, v9}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 392
    .line 393
    .line 394
    move-result-object v2

    .line 395
    new-instance v9, Lew6;

    .line 396
    .line 397
    const v13, 0x1010313

    .line 398
    .line 399
    .line 400
    invoke-direct {v9, v4, v2, v13, v12}, Lew6;-><init>(Ljava/lang/Object;Ljava/lang/String;ILfa2;)V

    .line 401
    .line 402
    .line 403
    invoke-virtual {v3, v9}, Lv34;->a(Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    :cond_7
    sget-object v2, Lfw6;->j:[Lfw6;

    .line 407
    .line 408
    iget-object v2, v15, Liz6;->a:Lw77;

    .line 409
    .line 410
    invoke-virtual {v2}, Lw77;->f()Lvw6;

    .line 411
    .line 412
    .line 413
    move-result-object v4

    .line 414
    iget-wide v12, v4, Lvw6;->l:J

    .line 415
    .line 416
    invoke-static {v12, v13}, Lc17;->c(J)I

    .line 417
    .line 418
    .line 419
    move-result v4

    .line 420
    invoke-static {v12, v13}, Lc17;->d(J)I

    .line 421
    .line 422
    .line 423
    move-result v9

    .line 424
    sub-int/2addr v4, v9

    .line 425
    invoke-virtual {v2}, Lw77;->f()Lvw6;

    .line 426
    .line 427
    .line 428
    move-result-object v2

    .line 429
    iget-object v2, v2, Lvw6;->k:Ljava/lang/CharSequence;

    .line 430
    .line 431
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    .line 432
    .line 433
    .line 434
    move-result v2

    .line 435
    if-eq v4, v2, :cond_8

    .line 436
    .line 437
    move v2, v11

    .line 438
    goto :goto_2

    .line 439
    :cond_8
    move v2, v10

    .line 440
    :goto_2
    sget-object v16, Lc27;->k:Lc27;

    .line 441
    .line 442
    new-instance v14, La10;

    .line 443
    .line 444
    invoke-direct {v14, v15, v6}, La10;-><init>(Liz6;B)V

    .line 445
    .line 446
    .line 447
    new-instance v13, La10;

    .line 448
    .line 449
    invoke-direct {v13, v15, v5}, La10;-><init>(Liz6;B)V

    .line 450
    .line 451
    .line 452
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 453
    .line 454
    .line 455
    move-result-object v4

    .line 456
    new-instance v12, Lb2;

    .line 457
    .line 458
    const/16 v17, 0xf

    .line 459
    .line 460
    invoke-direct/range {v12 .. v17}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 461
    .line 462
    .line 463
    if-eqz v2, :cond_9

    .line 464
    .line 465
    sget-object v2, Lqf0;->f0:Ljava/lang/Object;

    .line 466
    .line 467
    const v5, 0x104000d

    .line 468
    .line 469
    .line 470
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 471
    .line 472
    .line 473
    move-result-object v4

    .line 474
    new-instance v5, Lew6;

    .line 475
    .line 476
    const v6, 0x101037e

    .line 477
    .line 478
    .line 479
    invoke-direct {v5, v2, v4, v6, v12}, Lew6;-><init>(Ljava/lang/Object;Ljava/lang/String;ILfa2;)V

    .line 480
    .line 481
    .line 482
    invoke-virtual {v3, v5}, Lv34;->a(Ljava/lang/Object;)V

    .line 483
    .line 484
    .line 485
    :cond_9
    sget-object v2, Lfw6;->j:[Lfw6;

    .line 486
    .line 487
    invoke-virtual {v15}, Liz6;->m()Z

    .line 488
    .line 489
    .line 490
    move-result v2

    .line 491
    if-eqz v2, :cond_a

    .line 492
    .line 493
    iget-object v2, v15, Liz6;->a:Lw77;

    .line 494
    .line 495
    invoke-virtual {v2}, Lw77;->f()Lvw6;

    .line 496
    .line 497
    .line 498
    move-result-object v2

    .line 499
    iget-wide v4, v2, Lvw6;->l:J

    .line 500
    .line 501
    invoke-static {v4, v5}, Lc17;->b(J)Z

    .line 502
    .line 503
    .line 504
    move-result v2

    .line 505
    if-nez v2, :cond_b

    .line 506
    .line 507
    :cond_a
    move v11, v10

    .line 508
    :cond_b
    new-instance v13, La10;

    .line 509
    .line 510
    const/16 v2, 0x9

    .line 511
    .line 512
    invoke-direct {v13, v15, v2}, La10;-><init>(Liz6;B)V

    .line 513
    .line 514
    .line 515
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 516
    .line 517
    .line 518
    move-result-object v0

    .line 519
    new-instance v12, Lb2;

    .line 520
    .line 521
    const/16 v17, 0xf

    .line 522
    .line 523
    move-object/from16 v16, v7

    .line 524
    .line 525
    move-object v14, v8

    .line 526
    invoke-direct/range {v12 .. v17}, Lb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 527
    .line 528
    .line 529
    if-eqz v11, :cond_c

    .line 530
    .line 531
    sget-object v2, Lqf0;->g0:Ljava/lang/Object;

    .line 532
    .line 533
    const v4, 0x104001a

    .line 534
    .line 535
    .line 536
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object v0

    .line 540
    new-instance v4, Lew6;

    .line 541
    .line 542
    invoke-direct {v4, v2, v0, v10, v12}, Lew6;-><init>(Ljava/lang/Object;Ljava/lang/String;ILfa2;)V

    .line 543
    .line 544
    .line 545
    invoke-virtual {v3, v4}, Lv34;->a(Ljava/lang/Object;)V

    .line 546
    .line 547
    .line 548
    :cond_c
    invoke-virtual {v1}, Lvv6;->a()V

    .line 549
    .line 550
    .line 551
    sget-object v0, Lxc7;->a:Lxc7;

    .line 552
    .line 553
    return-object v0

    .line 554
    :pswitch_3
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 555
    .line 556
    check-cast v2, Ltr4;

    .line 557
    .line 558
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 559
    .line 560
    check-cast v3, Liz6;

    .line 561
    .line 562
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 563
    .line 564
    check-cast v0, Lgx6;

    .line 565
    .line 566
    check-cast v1, Lll4;

    .line 567
    .line 568
    invoke-virtual {v2}, Ltr4;->invoke()Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    iget-boolean v2, v3, Liz6;->i:Z

    .line 572
    .line 573
    iget-object v4, v3, Liz6;->b:Ll07;

    .line 574
    .line 575
    if-eqz v2, :cond_e

    .line 576
    .line 577
    iget-boolean v2, v3, Liz6;->h:Z

    .line 578
    .line 579
    if-eqz v2, :cond_e

    .line 580
    .line 581
    invoke-virtual {v0}, Lgx6;->invoke()Ljava/lang/Object;

    .line 582
    .line 583
    .line 584
    iget-object v0, v3, Liz6;->a:Lw77;

    .line 585
    .line 586
    invoke-virtual {v0}, Lw77;->f()Lvw6;

    .line 587
    .line 588
    .line 589
    move-result-object v0

    .line 590
    iget-object v0, v0, Lvw6;->k:Ljava/lang/CharSequence;

    .line 591
    .line 592
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 593
    .line 594
    .line 595
    move-result v0

    .line 596
    if-lez v0, :cond_d

    .line 597
    .line 598
    invoke-virtual {v3, v11}, Liz6;->w(Z)V

    .line 599
    .line 600
    .line 601
    :cond_d
    sget-object v0, Lc27;->i:Lc27;

    .line 602
    .line 603
    invoke-virtual {v3, v0}, Liz6;->x(Lc27;)V

    .line 604
    .line 605
    .line 606
    iget-wide v0, v1, Lll4;->a:J

    .line 607
    .line 608
    invoke-virtual {v4, v0, v1}, Ll07;->a(J)J

    .line 609
    .line 610
    .line 611
    move-result-wide v0

    .line 612
    invoke-static {v4, v0, v1}, Lur6;->o(Ll07;J)J

    .line 613
    .line 614
    .line 615
    move-result-wide v0

    .line 616
    invoke-virtual {v3, v0, v1}, Liz6;->u(J)Z

    .line 617
    .line 618
    .line 619
    :cond_e
    sget-object v0, Lxc7;->a:Lxc7;

    .line 620
    .line 621
    return-object v0

    .line 622
    :pswitch_4
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 623
    .line 624
    check-cast v2, Lsj5;

    .line 625
    .line 626
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 627
    .line 628
    check-cast v3, Liz6;

    .line 629
    .line 630
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 631
    .line 632
    check-cast v0, Lsj5;

    .line 633
    .line 634
    check-cast v1, Lll4;

    .line 635
    .line 636
    invoke-virtual {v3}, Liz6;->k()Lnj5;

    .line 637
    .line 638
    .line 639
    move-result-object v1

    .line 640
    invoke-virtual {v1}, Lnj5;->c()J

    .line 641
    .line 642
    .line 643
    move-result-wide v4

    .line 644
    invoke-static {v4, v5}, Lm66;->a(J)J

    .line 645
    .line 646
    .line 647
    move-result-wide v4

    .line 648
    iput-wide v4, v2, Lsj5;->i:J

    .line 649
    .line 650
    const-wide/16 v4, 0x0

    .line 651
    .line 652
    iput-wide v4, v0, Lsj5;->i:J

    .line 653
    .line 654
    invoke-virtual {v3, v11}, Liz6;->v(Z)V

    .line 655
    .line 656
    .line 657
    invoke-virtual {v3}, Liz6;->q()Lf93;

    .line 658
    .line 659
    .line 660
    move-result-object v0

    .line 661
    if-eqz v0, :cond_f

    .line 662
    .line 663
    invoke-interface {v0, v4, v5}, Lf93;->i(J)J

    .line 664
    .line 665
    .line 666
    move-result-wide v0

    .line 667
    goto :goto_3

    .line 668
    :cond_f
    const-wide v0, 0x7fc000007fc00000L    # 2.247117487993712E307

    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    :goto_3
    iget-object v4, v3, Liz6;->n:Lgx4;

    .line 674
    .line 675
    new-instance v5, Lll4;

    .line 676
    .line 677
    invoke-direct {v5, v0, v1}, Lll4;-><init>(J)V

    .line 678
    .line 679
    .line 680
    invoke-virtual {v4, v5}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 681
    .line 682
    .line 683
    sget-object v0, Lqi2;->i:Lqi2;

    .line 684
    .line 685
    iget-wide v1, v2, Lsj5;->i:J

    .line 686
    .line 687
    invoke-virtual {v3, v0, v1, v2}, Liz6;->A(Lqi2;J)V

    .line 688
    .line 689
    .line 690
    sget-object v0, Lxc7;->a:Lxc7;

    .line 691
    .line 692
    return-object v0

    .line 693
    :pswitch_5
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 694
    .line 695
    check-cast v2, Lpj5;

    .line 696
    .line 697
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 698
    .line 699
    check-cast v3, Lni;

    .line 700
    .line 701
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 702
    .line 703
    check-cast v0, Lnj6;

    .line 704
    .line 705
    check-cast v1, Lni;

    .line 706
    .line 707
    iget-boolean v4, v2, Lpj5;->i:Z

    .line 708
    .line 709
    if-eqz v4, :cond_11

    .line 710
    .line 711
    iget-object v4, v1, Lni;->a:Ljava/lang/Object;

    .line 712
    .line 713
    iget v5, v1, Lni;->c:I

    .line 714
    .line 715
    iget v6, v1, Lni;->b:I

    .line 716
    .line 717
    instance-of v4, v4, Lnj6;

    .line 718
    .line 719
    if-eqz v4, :cond_11

    .line 720
    .line 721
    iget v4, v3, Lni;->b:I

    .line 722
    .line 723
    if-ne v6, v4, :cond_11

    .line 724
    .line 725
    iget v4, v3, Lni;->c:I

    .line 726
    .line 727
    if-ne v5, v4, :cond_11

    .line 728
    .line 729
    new-instance v4, Lni;

    .line 730
    .line 731
    if-nez v0, :cond_10

    .line 732
    .line 733
    new-instance v7, Lnj6;

    .line 734
    .line 735
    const/16 v25, 0x0

    .line 736
    .line 737
    const v26, 0xffff

    .line 738
    .line 739
    .line 740
    const-wide/16 v8, 0x0

    .line 741
    .line 742
    const-wide/16 v10, 0x0

    .line 743
    .line 744
    const/4 v12, 0x0

    .line 745
    const/4 v13, 0x0

    .line 746
    const/4 v14, 0x0

    .line 747
    const/4 v15, 0x0

    .line 748
    const/16 v16, 0x0

    .line 749
    .line 750
    const-wide/16 v17, 0x0

    .line 751
    .line 752
    const/16 v19, 0x0

    .line 753
    .line 754
    const/16 v20, 0x0

    .line 755
    .line 756
    const/16 v21, 0x0

    .line 757
    .line 758
    const-wide/16 v22, 0x0

    .line 759
    .line 760
    const/16 v24, 0x0

    .line 761
    .line 762
    invoke-direct/range {v7 .. v26}, Lnj6;-><init>(JJLr82;Lp82;Lq82;Lt72;Ljava/lang/String;JLm00;Lvz6;Lqk3;JLnw6;Lja6;I)V

    .line 763
    .line 764
    .line 765
    move-object v0, v7

    .line 766
    :cond_10
    invoke-direct {v4, v6, v5, v0}, Lni;-><init>(IILjava/lang/Object;)V

    .line 767
    .line 768
    .line 769
    goto :goto_4

    .line 770
    :cond_11
    move-object v4, v1

    .line 771
    :goto_4
    invoke-virtual {v3, v1}, Lni;->equals(Ljava/lang/Object;)Z

    .line 772
    .line 773
    .line 774
    move-result v0

    .line 775
    iput-boolean v0, v2, Lpj5;->i:Z

    .line 776
    .line 777
    return-object v4

    .line 778
    :pswitch_6
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 779
    .line 780
    check-cast v2, Laq6;

    .line 781
    .line 782
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 783
    .line 784
    check-cast v3, Ltj0;

    .line 785
    .line 786
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 787
    .line 788
    check-cast v0, Lj44;

    .line 789
    .line 790
    check-cast v1, Lnd3;

    .line 791
    .line 792
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 793
    .line 794
    .line 795
    invoke-virtual {v2}, Laq6;->d()Ljava/util/List;

    .line 796
    .line 797
    .line 798
    move-result-object v4

    .line 799
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 800
    .line 801
    .line 802
    move-result v4

    .line 803
    new-instance v5, Liq6;

    .line 804
    .line 805
    invoke-direct {v5, v2, v11}, Liq6;-><init>(Laq6;B)V

    .line 806
    .line 807
    .line 808
    new-instance v6, Loq6;

    .line 809
    .line 810
    invoke-direct {v6, v2, v3, v0}, Loq6;-><init>(Laq6;Ltj0;Lj44;)V

    .line 811
    .line 812
    .line 813
    new-instance v0, Lyz0;

    .line 814
    .line 815
    const v2, -0x7079307f

    .line 816
    .line 817
    .line 818
    invoke-direct {v0, v2, v11, v6}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 819
    .line 820
    .line 821
    invoke-static {v1, v4, v5, v0}, Lnd3;->n0(Lnd3;ILfa2;Lyz0;)V

    .line 822
    .line 823
    .line 824
    sget-object v0, Lxc7;->a:Lxc7;

    .line 825
    .line 826
    return-object v0

    .line 827
    :pswitch_7
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 828
    .line 829
    check-cast v2, Lsj5;

    .line 830
    .line 831
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 832
    .line 833
    check-cast v3, Lfk6;

    .line 834
    .line 835
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 836
    .line 837
    check-cast v0, Lfa2;

    .line 838
    .line 839
    check-cast v1, Ljava/lang/Long;

    .line 840
    .line 841
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 842
    .line 843
    .line 844
    move-result-wide v4

    .line 845
    iget-wide v6, v2, Lsj5;->i:J

    .line 846
    .line 847
    const-wide/16 v8, -0x1

    .line 848
    .line 849
    cmp-long v1, v6, v8

    .line 850
    .line 851
    if-nez v1, :cond_12

    .line 852
    .line 853
    iput-wide v4, v2, Lsj5;->i:J

    .line 854
    .line 855
    goto/16 :goto_5

    .line 856
    .line 857
    :cond_12
    sub-long v6, v4, v6

    .line 858
    .line 859
    long-to-float v1, v6

    .line 860
    const v6, 0x4e6e6b28    # 1.0E9f

    .line 861
    .line 862
    .line 863
    div-float/2addr v1, v6

    .line 864
    iput-wide v4, v2, Lsj5;->i:J

    .line 865
    .line 866
    invoke-virtual {v3, v1}, Lfk6;->b(F)Z

    .line 867
    .line 868
    .line 869
    move-result v10

    .line 870
    iget-wide v1, v3, Lfk6;->c:D

    .line 871
    .line 872
    double-to-float v1, v1

    .line 873
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 874
    .line 875
    .line 876
    move-result-object v1

    .line 877
    invoke-interface {v0, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 878
    .line 879
    .line 880
    goto/16 :goto_5

    .line 881
    .line 882
    :pswitch_8
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 883
    .line 884
    check-cast v2, Leh6;

    .line 885
    .line 886
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 887
    .line 888
    check-cast v3, Lj44;

    .line 889
    .line 890
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 891
    .line 892
    check-cast v0, Lj44;

    .line 893
    .line 894
    check-cast v1, Lll4;

    .line 895
    .line 896
    invoke-interface {v3}, Lnl6;->getValue()Ljava/lang/Object;

    .line 897
    .line 898
    .line 899
    move-result-object v1

    .line 900
    check-cast v1, Lfa2;

    .line 901
    .line 902
    invoke-virtual {v2, v8, v1}, Leh6;->c(FLfa2;)V

    .line 903
    .line 904
    .line 905
    iget-object v1, v2, Leh6;->l:Lgx4;

    .line 906
    .line 907
    invoke-virtual {v1}, Lgx4;->getValue()Ljava/lang/Object;

    .line 908
    .line 909
    .line 910
    move-result-object v1

    .line 911
    check-cast v1, Ljava/lang/Boolean;

    .line 912
    .line 913
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 914
    .line 915
    .line 916
    move-result v1

    .line 917
    if-nez v1, :cond_13

    .line 918
    .line 919
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 920
    .line 921
    .line 922
    move-result-object v0

    .line 923
    check-cast v0, Lu92;

    .line 924
    .line 925
    if-eqz v0, :cond_13

    .line 926
    .line 927
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;

    .line 928
    .line 929
    .line 930
    :cond_13
    sget-object v0, Lxc7;->a:Lxc7;

    .line 931
    .line 932
    return-object v0

    .line 933
    :pswitch_9
    iget-object v2, v0, Lay3;->k:Ljava/lang/Object;

    .line 934
    .line 935
    check-cast v2, Leh6;

    .line 936
    .line 937
    iget-object v3, v0, Lay3;->l:Ljava/lang/Object;

    .line 938
    .line 939
    check-cast v3, Lfa2;

    .line 940
    .line 941
    iget-object v0, v0, Lay3;->j:Ljava/lang/Object;

    .line 942
    .line 943
    check-cast v0, Lu92;

    .line 944
    .line 945
    check-cast v1, Ljava/lang/Float;

    .line 946
    .line 947
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 948
    .line 949
    .line 950
    move-result v1

    .line 951
    iget-object v4, v2, Leh6;->a:Lyr0;

    .line 952
    .line 953
    iget v4, v4, Lyr0;->i:F

    .line 954
    .line 955
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 956
    .line 957
    .line 958
    move-result-object v4

    .line 959
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 960
    .line 961
    .line 962
    move-result v4

    .line 963
    iget-object v5, v2, Leh6;->a:Lyr0;

    .line 964
    .line 965
    iget v5, v5, Lyr0;->j:F

    .line 966
    .line 967
    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 968
    .line 969
    .line 970
    move-result-object v5

    .line 971
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 972
    .line 973
    .line 974
    move-result v5

    .line 975
    invoke-static {v1, v4, v5}, Lkb3;->A(FFF)F

    .line 976
    .line 977
    .line 978
    move-result v1

    .line 979
    iget-object v2, v2, Leh6;->b:Lcx4;

    .line 980
    .line 981
    invoke-virtual {v2}, Lcx4;->g()F

    .line 982
    .line 983
    .line 984
    move-result v2

    .line 985
    cmpg-float v2, v1, v2

    .line 986
    .line 987
    if-eqz v2, :cond_15

    .line 988
    .line 989
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 990
    .line 991
    .line 992
    move-result-object v1

    .line 993
    invoke-interface {v3, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 994
    .line 995
    .line 996
    if-eqz v0, :cond_14

    .line 997
    .line 998
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;

    .line 999
    .line 1000
    .line 1001
    :cond_14
    move v10, v11

    .line 1002
    :cond_15
    :goto_5
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v0

    .line 1006
    return-object v0

    .line 1007
    :pswitch_a
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1008
    .line 1009
    move-object v4, v2

    .line 1010
    check-cast v4, Luc6;

    .line 1011
    .line 1012
    iget-object v2, v0, Lay3;->k:Ljava/lang/Object;

    .line 1013
    .line 1014
    check-cast v2, Lbe6;

    .line 1015
    .line 1016
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1017
    .line 1018
    move-object v6, v0

    .line 1019
    check-cast v6, Landroid/net/Uri;

    .line 1020
    .line 1021
    move-object v5, v1

    .line 1022
    check-cast v5, Lgv;

    .line 1023
    .line 1024
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1025
    .line 1026
    .line 1027
    iget-object v0, v4, Luc6;->c:Le27;

    .line 1028
    .line 1029
    iget-object v1, v2, Lbe6;->a:Ljava/lang/String;

    .line 1030
    .line 1031
    const-string v2, "shell-script-document-export:"

    .line 1032
    .line 1033
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1034
    .line 1035
    .line 1036
    move-result-object v1

    .line 1037
    new-instance v3, Lfs;

    .line 1038
    .line 1039
    const/4 v7, 0x0

    .line 1040
    const/16 v8, 0x8

    .line 1041
    .line 1042
    invoke-direct/range {v3 .. v8}, Lfs;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 1043
    .line 1044
    .line 1045
    invoke-virtual {v0, v3, v1}, Le27;->f(Lfa2;Ljava/lang/String;)V

    .line 1046
    .line 1047
    .line 1048
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1049
    .line 1050
    return-object v0

    .line 1051
    :pswitch_b
    iget-object v2, v0, Lay3;->k:Ljava/lang/Object;

    .line 1052
    .line 1053
    check-cast v2, Ljava/util/Set;

    .line 1054
    .line 1055
    iget-object v3, v0, Lay3;->j:Ljava/lang/Object;

    .line 1056
    .line 1057
    check-cast v3, Lu92;

    .line 1058
    .line 1059
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1060
    .line 1061
    check-cast v0, Lfa2;

    .line 1062
    .line 1063
    check-cast v1, Lnc6;

    .line 1064
    .line 1065
    new-instance v4, Lmc6;

    .line 1066
    .line 1067
    invoke-direct {v4, v2, v3, v1, v0}, Lmc6;-><init>(Ljava/util/Set;Lu92;Lnc6;Lfa2;)V

    .line 1068
    .line 1069
    .line 1070
    return-object v4

    .line 1071
    :pswitch_c
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1072
    .line 1073
    check-cast v2, Ls14;

    .line 1074
    .line 1075
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1076
    .line 1077
    check-cast v3, Lr56;

    .line 1078
    .line 1079
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1080
    .line 1081
    check-cast v0, Lpj5;

    .line 1082
    .line 1083
    check-cast v1, Ll15;

    .line 1084
    .line 1085
    iget-wide v4, v1, Ll15;->c:J

    .line 1086
    .line 1087
    invoke-interface {v2, v4, v5, v3}, Ls14;->d(JLr56;)Z

    .line 1088
    .line 1089
    .line 1090
    move-result v2

    .line 1091
    if-eqz v2, :cond_16

    .line 1092
    .line 1093
    invoke-virtual {v1}, Ll15;->a()V

    .line 1094
    .line 1095
    .line 1096
    iput-boolean v11, v0, Lpj5;->i:Z

    .line 1097
    .line 1098
    :cond_16
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1099
    .line 1100
    return-object v0

    .line 1101
    :pswitch_d
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1102
    .line 1103
    check-cast v2, Lc06;

    .line 1104
    .line 1105
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1106
    .line 1107
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1108
    .line 1109
    check-cast v0, Lh06;

    .line 1110
    .line 1111
    check-cast v1, Lko1;

    .line 1112
    .line 1113
    iget-object v1, v2, Lc06;->j:Ld44;

    .line 1114
    .line 1115
    invoke-virtual {v1, v3}, Ld44;->b(Ljava/lang/Object;)Z

    .line 1116
    .line 1117
    .line 1118
    move-result v4

    .line 1119
    if-nez v4, :cond_17

    .line 1120
    .line 1121
    iget-object v4, v2, Lc06;->i:Ljava/util/Map;

    .line 1122
    .line 1123
    invoke-interface {v4, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1124
    .line 1125
    .line 1126
    invoke-virtual {v1, v3, v0}, Ld44;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1127
    .line 1128
    .line 1129
    new-instance v7, Lvg;

    .line 1130
    .line 1131
    const/4 v1, 0x5

    .line 1132
    invoke-direct {v7, v2, v3, v0, v1}, Lvg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1133
    .line 1134
    .line 1135
    goto :goto_6

    .line 1136
    :cond_17
    const-string v0, "Key "

    .line 1137
    .line 1138
    const-string v1, " was used multiple times "

    .line 1139
    .line 1140
    invoke-static {v0, v3, v1}, Lw91;->u(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1141
    .line 1142
    .line 1143
    :goto_6
    return-object v7

    .line 1144
    :pswitch_e
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1145
    .line 1146
    check-cast v2, Lorg/json/JSONObject;

    .line 1147
    .line 1148
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1149
    .line 1150
    check-cast v3, Lod5;

    .line 1151
    .line 1152
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1153
    .line 1154
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 1155
    .line 1156
    move-object v12, v1

    .line 1157
    check-cast v12, Ljava/lang/String;

    .line 1158
    .line 1159
    const-string v1, "smart"

    .line 1160
    .line 1161
    const-string v5, "fallback"

    .line 1162
    .line 1163
    const-string v6, "urltest"

    .line 1164
    .line 1165
    invoke-virtual {v2, v12}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v2

    .line 1169
    if-eqz v2, :cond_28

    .line 1170
    .line 1171
    const-string v8, "type"

    .line 1172
    .line 1173
    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1174
    .line 1175
    .line 1176
    move-result-object v8

    .line 1177
    invoke-static {v8}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1178
    .line 1179
    .line 1180
    move-result v9

    .line 1181
    if-eqz v9, :cond_18

    .line 1182
    .line 1183
    const-string v8, "--"

    .line 1184
    .line 1185
    :cond_18
    move-object v13, v8

    .line 1186
    const-string v8, "all"

    .line 1187
    .line 1188
    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 1189
    .line 1190
    .line 1191
    move-result-object v8

    .line 1192
    if-nez v8, :cond_19

    .line 1193
    .line 1194
    sget-object v8, Lby1;->i:Lby1;

    .line 1195
    .line 1196
    goto :goto_8

    .line 1197
    :cond_19
    invoke-static {}, Lgn;->C()Lgi3;

    .line 1198
    .line 1199
    .line 1200
    move-result-object v9

    .line 1201
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    .line 1202
    .line 1203
    .line 1204
    move-result v11

    .line 1205
    :goto_7
    if-ge v10, v11, :cond_1c

    .line 1206
    .line 1207
    invoke-virtual {v8, v10}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    .line 1208
    .line 1209
    .line 1210
    move-result-object v14

    .line 1211
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1212
    .line 1213
    .line 1214
    invoke-static {v14}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1215
    .line 1216
    .line 1217
    move-result v15

    .line 1218
    if-eqz v15, :cond_1a

    .line 1219
    .line 1220
    move-object v14, v7

    .line 1221
    :cond_1a
    if-eqz v14, :cond_1b

    .line 1222
    .line 1223
    invoke-virtual {v9, v14}, Lgi3;->add(Ljava/lang/Object;)Z

    .line 1224
    .line 1225
    .line 1226
    :cond_1b
    add-int/lit8 v10, v10, 0x1

    .line 1227
    .line 1228
    goto :goto_7

    .line 1229
    :cond_1c
    invoke-static {v9}, Lgn;->u(Lgi3;)Lgi3;

    .line 1230
    .line 1231
    .line 1232
    move-result-object v8

    .line 1233
    :goto_8
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    .line 1234
    .line 1235
    .line 1236
    move-result v9

    .line 1237
    if-nez v9, :cond_28

    .line 1238
    .line 1239
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1240
    .line 1241
    .line 1242
    const-string v9, "icon"

    .line 1243
    .line 1244
    invoke-virtual {v2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1245
    .line 1246
    .line 1247
    move-result-object v9

    .line 1248
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1249
    .line 1250
    .line 1251
    invoke-static {v9}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1252
    .line 1253
    .line 1254
    move-result-object v9

    .line 1255
    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1256
    .line 1257
    .line 1258
    move-result-object v9

    .line 1259
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 1260
    .line 1261
    .line 1262
    move-result v10

    .line 1263
    if-lez v10, :cond_1d

    .line 1264
    .line 1265
    move-object v14, v9

    .line 1266
    goto :goto_9

    .line 1267
    :cond_1d
    move-object v14, v7

    .line 1268
    :goto_9
    const-string v9, "testUrl"

    .line 1269
    .line 1270
    invoke-virtual {v2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1271
    .line 1272
    .line 1273
    move-result-object v9

    .line 1274
    invoke-static {v9}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1275
    .line 1276
    .line 1277
    move-result v10

    .line 1278
    if-eqz v10, :cond_1e

    .line 1279
    .line 1280
    const-string v9, "url"

    .line 1281
    .line 1282
    invoke-virtual {v2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1283
    .line 1284
    .line 1285
    move-result-object v9

    .line 1286
    :cond_1e
    invoke-static {v9}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1287
    .line 1288
    .line 1289
    move-result v10

    .line 1290
    if-eqz v10, :cond_1f

    .line 1291
    .line 1292
    const-string v9, "URL"

    .line 1293
    .line 1294
    invoke-virtual {v2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v9

    .line 1298
    :cond_1f
    invoke-static {v9}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1299
    .line 1300
    .line 1301
    move-result v10

    .line 1302
    if-eqz v10, :cond_20

    .line 1303
    .line 1304
    const-string v9, "test-url"

    .line 1305
    .line 1306
    invoke-virtual {v2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1307
    .line 1308
    .line 1309
    move-result-object v9

    .line 1310
    :cond_20
    invoke-static {v9}, Lx95;->e(Ljava/lang/String;)Ljava/lang/String;

    .line 1311
    .line 1312
    .line 1313
    move-result-object v9

    .line 1314
    invoke-virtual {v3, v9}, Lod5;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1315
    .line 1316
    .line 1317
    move-result-object v3

    .line 1318
    move-object v15, v3

    .line 1319
    check-cast v15, Ljava/lang/String;

    .line 1320
    .line 1321
    const-string v3, "now"

    .line 1322
    .line 1323
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1324
    .line 1325
    .line 1326
    move-result-object v3

    .line 1327
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1328
    .line 1329
    .line 1330
    move-result v9

    .line 1331
    if-eqz v9, :cond_21

    .line 1332
    .line 1333
    const-string v3, "Now"

    .line 1334
    .line 1335
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1336
    .line 1337
    .line 1338
    move-result-object v3

    .line 1339
    :cond_21
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1340
    .line 1341
    .line 1342
    move-result v9

    .line 1343
    if-nez v9, :cond_22

    .line 1344
    .line 1345
    move-object/from16 v16, v3

    .line 1346
    .line 1347
    goto :goto_a

    .line 1348
    :cond_22
    move-object/from16 v16, v7

    .line 1349
    .line 1350
    :goto_a
    const-string v3, "fixed"

    .line 1351
    .line 1352
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1353
    .line 1354
    .line 1355
    move-result-object v3

    .line 1356
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1357
    .line 1358
    .line 1359
    move-result v9

    .line 1360
    if-eqz v9, :cond_23

    .line 1361
    .line 1362
    const-string v3, "Fixed"

    .line 1363
    .line 1364
    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 1365
    .line 1366
    .line 1367
    move-result-object v3

    .line 1368
    :cond_23
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1369
    .line 1370
    .line 1371
    move-result v9

    .line 1372
    if-nez v9, :cond_24

    .line 1373
    .line 1374
    move-object/from16 v17, v3

    .line 1375
    .line 1376
    goto :goto_b

    .line 1377
    :cond_24
    move-object/from16 v17, v7

    .line 1378
    .line 1379
    :goto_b
    new-instance v3, Ljava/util/ArrayList;

    .line 1380
    .line 1381
    invoke-static {v8, v4}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 1382
    .line 1383
    .line 1384
    move-result v4

    .line 1385
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 1386
    .line 1387
    .line 1388
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1389
    .line 1390
    .line 1391
    move-result-object v4

    .line 1392
    :goto_c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1393
    .line 1394
    .line 1395
    move-result v9

    .line 1396
    if-eqz v9, :cond_26

    .line 1397
    .line 1398
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1399
    .line 1400
    .line 1401
    move-result-object v9

    .line 1402
    check-cast v9, Ljava/lang/String;

    .line 1403
    .line 1404
    invoke-virtual {v0, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1405
    .line 1406
    .line 1407
    move-result-object v10

    .line 1408
    check-cast v10, Lde5;

    .line 1409
    .line 1410
    if-nez v10, :cond_25

    .line 1411
    .line 1412
    new-instance v18, Lde5;

    .line 1413
    .line 1414
    const-string v21, "--"

    .line 1415
    .line 1416
    sget-object v26, Lcy1;->i:Lcy1;

    .line 1417
    .line 1418
    const/16 v28, 0x0

    .line 1419
    .line 1420
    const/16 v29, 0x0

    .line 1421
    .line 1422
    const/16 v22, 0x0

    .line 1423
    .line 1424
    const/16 v23, 0x0

    .line 1425
    .line 1426
    const/16 v24, 0x0

    .line 1427
    .line 1428
    const/16 v25, 0x0

    .line 1429
    .line 1430
    const/16 v27, 0x0

    .line 1431
    .line 1432
    move-object/from16 v20, v9

    .line 1433
    .line 1434
    move-object/from16 v19, v9

    .line 1435
    .line 1436
    invoke-direct/range {v18 .. v29}, Lde5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/util/Map;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;)V

    .line 1437
    .line 1438
    .line 1439
    move-object/from16 v10, v18

    .line 1440
    .line 1441
    :cond_25
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1442
    .line 1443
    .line 1444
    goto :goto_c

    .line 1445
    :cond_26
    const-string v0, "selector"

    .line 1446
    .line 1447
    filled-new-array {v0, v6, v5, v1}, [Ljava/lang/String;

    .line 1448
    .line 1449
    .line 1450
    move-result-object v0

    .line 1451
    invoke-static {v0}, Low;->o0([Ljava/lang/Object;)Ljava/util/Set;

    .line 1452
    .line 1453
    .line 1454
    move-result-object v0

    .line 1455
    invoke-static {v13}, Lt93;->z(Ljava/lang/String;)Ljava/lang/String;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v4

    .line 1459
    invoke-interface {v0, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1460
    .line 1461
    .line 1462
    move-result v20

    .line 1463
    const-string v0, "loadbalance"

    .line 1464
    .line 1465
    filled-new-array {v6, v5, v0, v1}, [Ljava/lang/String;

    .line 1466
    .line 1467
    .line 1468
    move-result-object v0

    .line 1469
    invoke-static {v0}, Low;->o0([Ljava/lang/Object;)Ljava/util/Set;

    .line 1470
    .line 1471
    .line 1472
    move-result-object v0

    .line 1473
    invoke-static {v13}, Lt93;->z(Ljava/lang/String;)Ljava/lang/String;

    .line 1474
    .line 1475
    .line 1476
    move-result-object v1

    .line 1477
    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1478
    .line 1479
    .line 1480
    move-result v21

    .line 1481
    const-string v0, "hidden"

    .line 1482
    .line 1483
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 1484
    .line 1485
    .line 1486
    move-result v1

    .line 1487
    if-eqz v1, :cond_27

    .line 1488
    .line 1489
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 1490
    .line 1491
    .line 1492
    move-result v1

    .line 1493
    if-nez v1, :cond_27

    .line 1494
    .line 1495
    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    .line 1496
    .line 1497
    .line 1498
    move-result v0

    .line 1499
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1500
    .line 1501
    .line 1502
    move-result-object v7

    .line 1503
    :cond_27
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1504
    .line 1505
    invoke-static {v7, v0}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1506
    .line 1507
    .line 1508
    move-result v22

    .line 1509
    new-instance v11, Lce5;

    .line 1510
    .line 1511
    move-object/from16 v19, v3

    .line 1512
    .line 1513
    move-object/from16 v18, v8

    .line 1514
    .line 1515
    invoke-direct/range {v11 .. v22}, Lce5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;ZZZ)V

    .line 1516
    .line 1517
    .line 1518
    move-object v7, v11

    .line 1519
    :cond_28
    return-object v7

    .line 1520
    :pswitch_f
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1521
    .line 1522
    check-cast v2, Lfa2;

    .line 1523
    .line 1524
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1525
    .line 1526
    check-cast v3, Lee5;

    .line 1527
    .line 1528
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1529
    .line 1530
    check-cast v0, Lj44;

    .line 1531
    .line 1532
    check-cast v1, Ljava/lang/Integer;

    .line 1533
    .line 1534
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1535
    .line 1536
    .line 1537
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1538
    .line 1539
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 1540
    .line 1541
    .line 1542
    invoke-interface {v2, v3}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1543
    .line 1544
    .line 1545
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1546
    .line 1547
    return-object v0

    .line 1548
    :pswitch_10
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1549
    .line 1550
    check-cast v2, Low4;

    .line 1551
    .line 1552
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1553
    .line 1554
    check-cast v3, Lij;

    .line 1555
    .line 1556
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1557
    .line 1558
    check-cast v0, Lyd3;

    .line 1559
    .line 1560
    check-cast v1, Lko1;

    .line 1561
    .line 1562
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1563
    .line 1564
    .line 1565
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1566
    .line 1567
    .line 1568
    iget-object v1, v2, Low4;->a:Ljava/util/LinkedHashMap;

    .line 1569
    .line 1570
    invoke-interface {v1, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1571
    .line 1572
    .line 1573
    new-instance v1, Lvg;

    .line 1574
    .line 1575
    const/4 v4, 0x3

    .line 1576
    invoke-direct {v1, v2, v3, v0, v4}, Lvg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1577
    .line 1578
    .line 1579
    return-object v1

    .line 1580
    :pswitch_11
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1581
    .line 1582
    check-cast v2, Ljava/lang/String;

    .line 1583
    .line 1584
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1585
    .line 1586
    check-cast v3, Lur4;

    .line 1587
    .line 1588
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1589
    .line 1590
    check-cast v0, Lj44;

    .line 1591
    .line 1592
    check-cast v1, Lnd3;

    .line 1593
    .line 1594
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1595
    .line 1596
    .line 1597
    if-eqz v2, :cond_29

    .line 1598
    .line 1599
    const-string v5, "status"

    .line 1600
    .line 1601
    new-instance v6, Lk;

    .line 1602
    .line 1603
    const/16 v7, 0x18

    .line 1604
    .line 1605
    invoke-direct {v6, v2, v3, v0, v7}, Lk;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1606
    .line 1607
    .line 1608
    new-instance v2, Lyz0;

    .line 1609
    .line 1610
    const v7, -0x37210b37

    .line 1611
    .line 1612
    .line 1613
    invoke-direct {v2, v7, v11, v6}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1614
    .line 1615
    .line 1616
    invoke-static {v1, v5, v2, v9}, Lnd3;->l0(Lnd3;Ljava/lang/String;Lka2;I)V

    .line 1617
    .line 1618
    .line 1619
    :cond_29
    iget-object v2, v3, Lur4;->b:Ljava/util/List;

    .line 1620
    .line 1621
    new-instance v5, Lzf4;

    .line 1622
    .line 1623
    const/16 v6, 0x15

    .line 1624
    .line 1625
    invoke-direct {v5, v6}, Lzf4;-><init>(B)V

    .line 1626
    .line 1627
    .line 1628
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 1629
    .line 1630
    .line 1631
    move-result v6

    .line 1632
    new-instance v7, Lc0;

    .line 1633
    .line 1634
    const/16 v8, 0x11

    .line 1635
    .line 1636
    invoke-direct {v7, v5, v2, v8}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1637
    .line 1638
    .line 1639
    new-instance v5, Ld0;

    .line 1640
    .line 1641
    invoke-direct {v5, v2, v4}, Ld0;-><init>(Ljava/util/List;B)V

    .line 1642
    .line 1643
    .line 1644
    new-instance v4, Lpr4;

    .line 1645
    .line 1646
    invoke-direct {v4, v2, v3, v0, v10}, Lpr4;-><init>(Ljava/util/List;Lur4;Ljava/lang/Object;B)V

    .line 1647
    .line 1648
    .line 1649
    new-instance v0, Lyz0;

    .line 1650
    .line 1651
    const v2, 0x2fd4df92

    .line 1652
    .line 1653
    .line 1654
    invoke-direct {v0, v2, v11, v4}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1655
    .line 1656
    .line 1657
    invoke-virtual {v1, v6, v7, v5, v0}, Lnd3;->m0(ILfa2;Lfa2;Lyz0;)V

    .line 1658
    .line 1659
    .line 1660
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1661
    .line 1662
    return-object v0

    .line 1663
    :pswitch_12
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1664
    .line 1665
    check-cast v2, Lcy6;

    .line 1666
    .line 1667
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1668
    .line 1669
    check-cast v3, Lzt4;

    .line 1670
    .line 1671
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1672
    .line 1673
    check-cast v0, Lr20;

    .line 1674
    .line 1675
    check-cast v1, Lca3;

    .line 1676
    .line 1677
    invoke-virtual {v2}, Lcy6;->get()Ljava/lang/Object;

    .line 1678
    .line 1679
    .line 1680
    move-result-object v2

    .line 1681
    check-cast v2, Luf6;

    .line 1682
    .line 1683
    iget-wide v4, v2, Luf6;->a:J

    .line 1684
    .line 1685
    const/16 v2, 0x20

    .line 1686
    .line 1687
    shr-long v6, v4, v2

    .line 1688
    .line 1689
    long-to-int v6, v6

    .line 1690
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1691
    .line 1692
    .line 1693
    move-result v6

    .line 1694
    cmpl-float v7, v6, v8

    .line 1695
    .line 1696
    if-lez v7, :cond_2c

    .line 1697
    .line 1698
    const/high16 v7, 0x40800000    # 4.0f

    .line 1699
    .line 1700
    invoke-virtual {v1, v7}, Lca3;->L(F)F

    .line 1701
    .line 1702
    .line 1703
    move-result v7

    .line 1704
    iget-object v9, v1, Lca3;->i:Lpj0;

    .line 1705
    .line 1706
    invoke-virtual {v1}, Lca3;->getLayoutDirection()Lh93;

    .line 1707
    .line 1708
    .line 1709
    move-result-object v10

    .line 1710
    invoke-virtual {v3, v10}, Lzt4;->a(Lh93;)F

    .line 1711
    .line 1712
    .line 1713
    move-result v10

    .line 1714
    invoke-virtual {v1, v10}, Lca3;->L(F)F

    .line 1715
    .line 1716
    .line 1717
    move-result v10

    .line 1718
    invoke-virtual {v1}, Lca3;->getLayoutDirection()Lh93;

    .line 1719
    .line 1720
    .line 1721
    move-result-object v11

    .line 1722
    invoke-virtual {v3, v11}, Lzt4;->b(Lh93;)F

    .line 1723
    .line 1724
    .line 1725
    move-result v3

    .line 1726
    invoke-virtual {v1, v3}, Lca3;->L(F)F

    .line 1727
    .line 1728
    .line 1729
    move-result v3

    .line 1730
    invoke-static {v6}, Lhr3;->M(F)I

    .line 1731
    .line 1732
    .line 1733
    move-result v11

    .line 1734
    invoke-interface {v9}, Lwr1;->b()J

    .line 1735
    .line 1736
    .line 1737
    move-result-wide v12

    .line 1738
    shr-long/2addr v12, v2

    .line 1739
    long-to-int v12, v12

    .line 1740
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1741
    .line 1742
    .line 1743
    move-result v12

    .line 1744
    sub-float/2addr v12, v10

    .line 1745
    sub-float/2addr v12, v3

    .line 1746
    invoke-static {v12}, Lhr3;->M(F)I

    .line 1747
    .line 1748
    .line 1749
    move-result v3

    .line 1750
    invoke-virtual {v1}, Lca3;->getLayoutDirection()Lh93;

    .line 1751
    .line 1752
    .line 1753
    move-result-object v12

    .line 1754
    invoke-virtual {v0, v11, v3, v12}, Lr20;->a(IILh93;)I

    .line 1755
    .line 1756
    .line 1757
    move-result v0

    .line 1758
    int-to-float v0, v0

    .line 1759
    add-float/2addr v0, v10

    .line 1760
    const/high16 v3, 0x40000000    # 2.0f

    .line 1761
    .line 1762
    div-float/2addr v6, v3

    .line 1763
    add-float/2addr v0, v6

    .line 1764
    sub-float v10, v0, v6

    .line 1765
    .line 1766
    sub-float/2addr v10, v7

    .line 1767
    cmpg-float v11, v10, v8

    .line 1768
    .line 1769
    if-gez v11, :cond_2a

    .line 1770
    .line 1771
    move v13, v8

    .line 1772
    goto :goto_d

    .line 1773
    :cond_2a
    move v13, v10

    .line 1774
    :goto_d
    add-float/2addr v0, v6

    .line 1775
    add-float/2addr v0, v7

    .line 1776
    invoke-interface {v9}, Lwr1;->b()J

    .line 1777
    .line 1778
    .line 1779
    move-result-wide v6

    .line 1780
    shr-long/2addr v6, v2

    .line 1781
    long-to-int v2, v6

    .line 1782
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1783
    .line 1784
    .line 1785
    move-result v2

    .line 1786
    cmpl-float v6, v0, v2

    .line 1787
    .line 1788
    if-lez v6, :cond_2b

    .line 1789
    .line 1790
    move v15, v2

    .line 1791
    goto :goto_e

    .line 1792
    :cond_2b
    move v15, v0

    .line 1793
    :goto_e
    const-wide v6, 0xffffffffL

    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    and-long/2addr v4, v6

    .line 1799
    long-to-int v0, v4

    .line 1800
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1801
    .line 1802
    .line 1803
    move-result v0

    .line 1804
    neg-float v2, v0

    .line 1805
    div-float v14, v2, v3

    .line 1806
    .line 1807
    div-float v16, v0, v3

    .line 1808
    .line 1809
    iget-object v2, v9, Lpj0;->j:Lw27;

    .line 1810
    .line 1811
    invoke-virtual {v2}, Lw27;->G()J

    .line 1812
    .line 1813
    .line 1814
    move-result-wide v3

    .line 1815
    invoke-virtual {v2}, Lw27;->u()Lnj0;

    .line 1816
    .line 1817
    .line 1818
    move-result-object v0

    .line 1819
    invoke-interface {v0}, Lnj0;->l()V

    .line 1820
    .line 1821
    .line 1822
    :try_start_1
    iget-object v0, v2, Lw27;->j:Ljava/lang/Object;

    .line 1823
    .line 1824
    move-object v12, v0

    .line 1825
    check-cast v12, Luh7;

    .line 1826
    .line 1827
    const/16 v17, 0x0

    .line 1828
    .line 1829
    invoke-virtual/range {v12 .. v17}, Luh7;->l(FFFFI)V

    .line 1830
    .line 1831
    .line 1832
    invoke-virtual {v1}, Lca3;->c()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 1833
    .line 1834
    .line 1835
    invoke-static {v2, v3, v4}, Luj6;->y(Lw27;J)V

    .line 1836
    .line 1837
    .line 1838
    goto :goto_f

    .line 1839
    :catchall_1
    move-exception v0

    .line 1840
    invoke-static {v2, v3, v4}, Luj6;->y(Lw27;J)V

    .line 1841
    .line 1842
    .line 1843
    throw v0

    .line 1844
    :cond_2c
    invoke-virtual {v1}, Lca3;->c()V

    .line 1845
    .line 1846
    .line 1847
    :goto_f
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1848
    .line 1849
    return-object v0

    .line 1850
    :pswitch_13
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1851
    .line 1852
    check-cast v2, Ljava/util/List;

    .line 1853
    .line 1854
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1855
    .line 1856
    check-cast v3, Ljava/lang/String;

    .line 1857
    .line 1858
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1859
    .line 1860
    check-cast v0, Ljava/lang/String;

    .line 1861
    .line 1862
    move-object v4, v1

    .line 1863
    check-cast v4, Lcf4;

    .line 1864
    .line 1865
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1866
    .line 1867
    .line 1868
    iget-object v1, v4, Lcf4;->d:Lld4;

    .line 1869
    .line 1870
    invoke-static {v1}, Ll46;->d0(Lld4;)Lld4;

    .line 1871
    .line 1872
    .line 1873
    move-result-object v1

    .line 1874
    invoke-static {v1, v2}, Ll46;->H(Lld4;Ljava/util/List;)Lid4;

    .line 1875
    .line 1876
    .line 1877
    move-result-object v5

    .line 1878
    if-eqz v5, :cond_2d

    .line 1879
    .line 1880
    iget-object v5, v5, Lid4;->b:Ljava/lang/String;

    .line 1881
    .line 1882
    invoke-static {v5, v3}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1883
    .line 1884
    .line 1885
    move-result v3

    .line 1886
    if-eqz v3, :cond_2d

    .line 1887
    .line 1888
    invoke-static {v1, v2, v0}, Ll46;->f0(Lld4;Ljava/util/List;Ljava/lang/String;)Lld4;

    .line 1889
    .line 1890
    .line 1891
    move-result-object v9

    .line 1892
    const/4 v10, 0x0

    .line 1893
    const/16 v11, 0x17

    .line 1894
    .line 1895
    const-wide/16 v5, 0x0

    .line 1896
    .line 1897
    const/4 v7, 0x0

    .line 1898
    const/4 v8, 0x0

    .line 1899
    invoke-static/range {v4 .. v11}, Lcf4;->a(Lcf4;JLjava/lang/String;ZLld4;Ljava/util/ArrayList;I)Lcf4;

    .line 1900
    .line 1901
    .line 1902
    move-result-object v4

    .line 1903
    :cond_2d
    return-object v4

    .line 1904
    :pswitch_14
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1905
    .line 1906
    check-cast v2, Ljava/util/List;

    .line 1907
    .line 1908
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1909
    .line 1910
    check-cast v3, Lfa2;

    .line 1911
    .line 1912
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1913
    .line 1914
    check-cast v0, Lld4;

    .line 1915
    .line 1916
    check-cast v1, Ljava/lang/Integer;

    .line 1917
    .line 1918
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1919
    .line 1920
    .line 1921
    move-result v1

    .line 1922
    invoke-static {v1, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 1923
    .line 1924
    .line 1925
    move-result-object v1

    .line 1926
    check-cast v1, Lse4;

    .line 1927
    .line 1928
    if-eqz v1, :cond_2e

    .line 1929
    .line 1930
    invoke-static {v0, v1}, Ll46;->i0(Lld4;Lse4;)Lld4;

    .line 1931
    .line 1932
    .line 1933
    move-result-object v0

    .line 1934
    invoke-interface {v3, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1935
    .line 1936
    .line 1937
    :cond_2e
    sget-object v0, Lxc7;->a:Lxc7;

    .line 1938
    .line 1939
    return-object v0

    .line 1940
    :pswitch_15
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1941
    .line 1942
    check-cast v2, Lq84;

    .line 1943
    .line 1944
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 1945
    .line 1946
    check-cast v3, Li11;

    .line 1947
    .line 1948
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1949
    .line 1950
    check-cast v0, Le84;

    .line 1951
    .line 1952
    check-cast v1, Lko1;

    .line 1953
    .line 1954
    iget-object v1, v2, Lq84;->e:Li11;

    .line 1955
    .line 1956
    if-nez v1, :cond_2f

    .line 1957
    .line 1958
    iput-object v3, v2, Lq84;->e:Li11;

    .line 1959
    .line 1960
    invoke-static {v0, v3}, Le84;->a(Le84;Li84;)V

    .line 1961
    .line 1962
    .line 1963
    new-instance v7, Lqu;

    .line 1964
    .line 1965
    const/16 v0, 0xc

    .line 1966
    .line 1967
    invoke-direct {v7, v3, v2, v0}, Lqu;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1968
    .line 1969
    .line 1970
    goto :goto_10

    .line 1971
    :cond_2f
    const-string v0, "NavigationEventState \'"

    .line 1972
    .line 1973
    const-string v1, "\' is already registered with a NavigationEventHandler \'"

    .line 1974
    .line 1975
    const-string v4, "\'."

    .line 1976
    .line 1977
    invoke-static {v0, v2, v1, v3, v4}, Lsl4;->k(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1978
    .line 1979
    .line 1980
    :goto_10
    return-object v7

    .line 1981
    :pswitch_16
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 1982
    .line 1983
    check-cast v2, Lt54;

    .line 1984
    .line 1985
    iget-object v4, v0, Lay3;->k:Ljava/lang/Object;

    .line 1986
    .line 1987
    check-cast v4, Lm74;

    .line 1988
    .line 1989
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 1990
    .line 1991
    check-cast v0, Lqj3;

    .line 1992
    .line 1993
    check-cast v1, Lyh2;

    .line 1994
    .line 1995
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1996
    .line 1997
    .line 1998
    iget v2, v2, Lt54;->d:F

    .line 1999
    .line 2000
    invoke-interface {v4, v0}, Lm74;->c(Lqj3;)F

    .line 2001
    .line 2002
    .line 2003
    move-result v0

    .line 2004
    invoke-static {v0, v8, v3}, Lkb3;->A(FFF)F

    .line 2005
    .line 2006
    .line 2007
    move-result v0

    .line 2008
    mul-float/2addr v0, v2

    .line 2009
    invoke-interface {v1, v0}, Lyh2;->y(F)V

    .line 2010
    .line 2011
    .line 2012
    sget-object v0, Lxc7;->a:Lxc7;

    .line 2013
    .line 2014
    return-object v0

    .line 2015
    :pswitch_17
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 2016
    .line 2017
    check-cast v2, Ls3;

    .line 2018
    .line 2019
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 2020
    .line 2021
    check-cast v3, [Lx90;

    .line 2022
    .line 2023
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 2024
    .line 2025
    check-cast v0, Ls62;

    .line 2026
    .line 2027
    check-cast v1, Lko1;

    .line 2028
    .line 2029
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2030
    .line 2031
    .line 2032
    invoke-static {v2}, Liv0;->F0(Ljava/util/List;)Ljava/lang/Object;

    .line 2033
    .line 2034
    .line 2035
    move-result-object v1

    .line 2036
    check-cast v1, Lx90;

    .line 2037
    .line 2038
    aget-object v2, v3, v10

    .line 2039
    .line 2040
    if-eqz v2, :cond_30

    .line 2041
    .line 2042
    invoke-virtual {v2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 2043
    .line 2044
    .line 2045
    move-result v2

    .line 2046
    if-nez v2, :cond_30

    .line 2047
    .line 2048
    invoke-static {v0}, Ls62;->a(Ls62;)V

    .line 2049
    .line 2050
    .line 2051
    :cond_30
    aput-object v1, v3, v10

    .line 2052
    .line 2053
    new-instance v0, Lrd;

    .line 2054
    .line 2055
    const/16 v1, 0xb

    .line 2056
    .line 2057
    invoke-direct {v0, v1}, Lrd;-><init>(B)V

    .line 2058
    .line 2059
    .line 2060
    return-object v0

    .line 2061
    :pswitch_18
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 2062
    .line 2063
    check-cast v2, Ljava/util/Set;

    .line 2064
    .line 2065
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 2066
    .line 2067
    check-cast v3, Lp24;

    .line 2068
    .line 2069
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 2070
    .line 2071
    check-cast v0, Ltj5;

    .line 2072
    .line 2073
    invoke-interface {v2, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 2074
    .line 2075
    .line 2076
    move-result v2

    .line 2077
    if-eqz v2, :cond_37

    .line 2078
    .line 2079
    iget-object v2, v3, Lp24;->c:Ld44;

    .line 2080
    .line 2081
    invoke-virtual {v2, v1}, Ld44;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2082
    .line 2083
    .line 2084
    move-result-object v1

    .line 2085
    if-eqz v1, :cond_37

    .line 2086
    .line 2087
    instance-of v2, v1, Le44;

    .line 2088
    .line 2089
    if-eqz v2, :cond_35

    .line 2090
    .line 2091
    check-cast v1, Le44;

    .line 2092
    .line 2093
    iget-object v2, v1, Le44;->b:[Ljava/lang/Object;

    .line 2094
    .line 2095
    iget-object v1, v1, Le44;->a:[J

    .line 2096
    .line 2097
    array-length v3, v1

    .line 2098
    sub-int/2addr v3, v9

    .line 2099
    if-ltz v3, :cond_37

    .line 2100
    .line 2101
    move v4, v10

    .line 2102
    :goto_11
    aget-wide v7, v1, v4

    .line 2103
    .line 2104
    not-long v11, v7

    .line 2105
    shl-long/2addr v11, v6

    .line 2106
    and-long/2addr v11, v7

    .line 2107
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    and-long/2addr v11, v13

    .line 2113
    cmp-long v9, v11, v13

    .line 2114
    .line 2115
    if-eqz v9, :cond_34

    .line 2116
    .line 2117
    sub-int v9, v4, v3

    .line 2118
    .line 2119
    not-int v9, v9

    .line 2120
    ushr-int/lit8 v9, v9, 0x1f

    .line 2121
    .line 2122
    rsub-int/lit8 v9, v9, 0x8

    .line 2123
    .line 2124
    move v11, v10

    .line 2125
    :goto_12
    if-ge v11, v9, :cond_33

    .line 2126
    .line 2127
    const-wide/16 v12, 0xff

    .line 2128
    .line 2129
    and-long/2addr v12, v7

    .line 2130
    const-wide/16 v14, 0x80

    .line 2131
    .line 2132
    cmp-long v12, v12, v14

    .line 2133
    .line 2134
    if-gez v12, :cond_32

    .line 2135
    .line 2136
    shl-int/lit8 v12, v4, 0x3

    .line 2137
    .line 2138
    add-int/2addr v12, v11

    .line 2139
    aget-object v12, v2, v12

    .line 2140
    .line 2141
    check-cast v12, Lg86;

    .line 2142
    .line 2143
    iget-object v13, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2144
    .line 2145
    if-nez v13, :cond_31

    .line 2146
    .line 2147
    new-instance v13, Ljava/util/ArrayList;

    .line 2148
    .line 2149
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 2150
    .line 2151
    .line 2152
    iput-object v13, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2153
    .line 2154
    :cond_31
    iget-object v13, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2155
    .line 2156
    check-cast v13, Ljava/util/List;

    .line 2157
    .line 2158
    invoke-interface {v13, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2159
    .line 2160
    .line 2161
    :cond_32
    shr-long/2addr v7, v5

    .line 2162
    add-int/lit8 v11, v11, 0x1

    .line 2163
    .line 2164
    goto :goto_12

    .line 2165
    :cond_33
    if-ne v9, v5, :cond_37

    .line 2166
    .line 2167
    :cond_34
    if-eq v4, v3, :cond_37

    .line 2168
    .line 2169
    add-int/lit8 v4, v4, 0x1

    .line 2170
    .line 2171
    goto :goto_11

    .line 2172
    :cond_35
    check-cast v1, Lg86;

    .line 2173
    .line 2174
    iget-object v2, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2175
    .line 2176
    if-nez v2, :cond_36

    .line 2177
    .line 2178
    new-instance v2, Ljava/util/ArrayList;

    .line 2179
    .line 2180
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2181
    .line 2182
    .line 2183
    iput-object v2, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2184
    .line 2185
    :cond_36
    iget-object v0, v0, Ltj5;->i:Ljava/lang/Object;

    .line 2186
    .line 2187
    check-cast v0, Ljava/util/List;

    .line 2188
    .line 2189
    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2190
    .line 2191
    .line 2192
    :cond_37
    sget-object v0, Lxc7;->a:Lxc7;

    .line 2193
    .line 2194
    return-object v0

    .line 2195
    :pswitch_19
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 2196
    .line 2197
    check-cast v2, Luy3;

    .line 2198
    .line 2199
    iget-object v3, v0, Lay3;->k:Ljava/lang/Object;

    .line 2200
    .line 2201
    check-cast v3, Lij;

    .line 2202
    .line 2203
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 2204
    .line 2205
    check-cast v0, Lyd3;

    .line 2206
    .line 2207
    check-cast v1, Lko1;

    .line 2208
    .line 2209
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2210
    .line 2211
    .line 2212
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2213
    .line 2214
    .line 2215
    iget-object v1, v2, Luy3;->a:Lqi6;

    .line 2216
    .line 2217
    invoke-virtual {v1, v3, v0}, Lqi6;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2218
    .line 2219
    .line 2220
    new-instance v1, Lvg;

    .line 2221
    .line 2222
    invoke-direct {v1, v2, v3, v0, v9}, Lvg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2223
    .line 2224
    .line 2225
    return-object v1

    .line 2226
    :pswitch_1a
    iget-object v2, v0, Lay3;->j:Ljava/lang/Object;

    .line 2227
    .line 2228
    check-cast v2, Lu92;

    .line 2229
    .line 2230
    iget-object v4, v0, Lay3;->k:Ljava/lang/Object;

    .line 2231
    .line 2232
    check-cast v4, Lu92;

    .line 2233
    .line 2234
    iget-object v0, v0, Lay3;->l:Ljava/lang/Object;

    .line 2235
    .line 2236
    check-cast v0, Lnl6;

    .line 2237
    .line 2238
    check-cast v1, Lyh2;

    .line 2239
    .line 2240
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2241
    .line 2242
    .line 2243
    if-eqz v2, :cond_38

    .line 2244
    .line 2245
    invoke-interface {v2}, Lu92;->invoke()Ljava/lang/Object;

    .line 2246
    .line 2247
    .line 2248
    move-result-object v0

    .line 2249
    check-cast v0, Ljava/lang/Number;

    .line 2250
    .line 2251
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 2252
    .line 2253
    .line 2254
    move-result v0

    .line 2255
    neg-float v0, v0

    .line 2256
    const/high16 v2, 0x42400000    # 48.0f

    .line 2257
    .line 2258
    invoke-interface {v1}, Lkl1;->a()F

    .line 2259
    .line 2260
    .line 2261
    move-result v5

    .line 2262
    mul-float/2addr v5, v2

    .line 2263
    div-float/2addr v0, v5

    .line 2264
    invoke-static {v0, v8, v3}, Lkb3;->A(FFF)F

    .line 2265
    .line 2266
    .line 2267
    move-result v0

    .line 2268
    goto :goto_13

    .line 2269
    :cond_38
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 2270
    .line 2271
    .line 2272
    move-result-object v0

    .line 2273
    check-cast v0, Ljava/lang/Number;

    .line 2274
    .line 2275
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 2276
    .line 2277
    .line 2278
    move-result v0

    .line 2279
    :goto_13
    invoke-interface {v4}, Lu92;->invoke()Ljava/lang/Object;

    .line 2280
    .line 2281
    .line 2282
    move-result-object v2

    .line 2283
    check-cast v2, Ljava/lang/Number;

    .line 2284
    .line 2285
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 2286
    .line 2287
    .line 2288
    move-result v2

    .line 2289
    invoke-static {v2, v8, v3}, Lkb3;->A(FFF)F

    .line 2290
    .line 2291
    .line 2292
    move-result v2

    .line 2293
    mul-float/2addr v2, v0

    .line 2294
    invoke-interface {v1, v2}, Lyh2;->y(F)V

    .line 2295
    .line 2296
    .line 2297
    sget-object v0, Lxc7;->a:Lxc7;

    .line 2298
    .line 2299
    return-object v0

    .line 2300
    nop

    .line 2301
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
