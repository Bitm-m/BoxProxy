.class final Lbe0;
.super Lf14;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lf14;"
    }
.end annotation


# instance fields
.field public final i:Lxf;


# direct methods
.method public constructor <init>(Lxf;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbe0;->i:Lxf;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lv04;
    .locals 1

    .line 1
    new-instance v0, Lee0;

    .line 2
    .line 3
    iget-object p0, p0, Lbe0;->i:Lxf;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Lee0;-><init>(Lxf;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final b(Lv04;)V
    .locals 1

    .line 1
    check-cast p1, Lee0;

    .line 2
    .line 3
    iget-object p0, p0, Lbe0;->i:Lxf;

    .line 4
    .line 5
    iput-object p0, p1, Lee0;->w:Lxf;

    .line 6
    .line 7
    iget-boolean v0, p1, Lv04;->v:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object p1, p1, Lee0;->x:Lde0;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lxf;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lbe0;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lbe0;

    .line 8
    .line 9
    iget-object p1, p1, Lbe0;->i:Lxf;

    .line 10
    .line 11
    iget-object p0, p0, Lbe0;->i:Lxf;

    .line 12
    .line 13
    if-eq p0, p1, :cond_1

    .line 14
    .line 15
    :cond_0
    const/4 p0, 0x0

    .line 16
    return p0

    .line 17
    :cond_1
    const/4 p0, 0x1

    .line 18
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lbe0;->i:Lxf;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
