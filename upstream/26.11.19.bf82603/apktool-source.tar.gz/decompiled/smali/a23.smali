.class public final La23;
.super Le23;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public x:Ld23;

.field public y:Z


# virtual methods
.method public final F1(Ljr3;J)J
    .locals 1

    .line 1
    iget-object p0, p0, La23;->x:Ld23;

    .line 2
    .line 3
    sget-object v0, Ld23;->i:Ld23;

    .line 4
    .line 5
    if-ne p0, v0, :cond_0

    .line 6
    .line 7
    invoke-static {p2, p3}, Lw71;->i(J)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    invoke-interface {p1, p0}, Ljr3;->e0(I)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-static {p2, p3}, Lw71;->i(J)I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    invoke-interface {p1, p0}, Ljr3;->f(I)I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    :goto_0
    const/4 p1, 0x0

    .line 25
    if-gez p0, :cond_1

    .line 26
    .line 27
    move p0, p1

    .line 28
    :cond_1
    if-gez p0, :cond_2

    .line 29
    .line 30
    const-string p2, "height must be >= 0"

    .line 31
    .line 32
    invoke-static {p2}, Lny2;->a(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :cond_2
    const p2, 0x7fffffff

    .line 36
    .line 37
    .line 38
    invoke-static {p1, p2, p0, p0}, Lx71;->h(IIII)J

    .line 39
    .line 40
    .line 41
    move-result-wide p0

    .line 42
    return-wide p0
.end method

.method public final G1()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, La23;->y:Z

    .line 2
    .line 3
    return p0
.end method

.method public final e(Lkn3;Ljr3;I)I
    .locals 0

    .line 1
    iget-object p0, p0, La23;->x:Ld23;

    .line 2
    .line 3
    sget-object p1, Ld23;->i:Ld23;

    .line 4
    .line 5
    if-ne p0, p1, :cond_0

    .line 6
    .line 7
    invoke-interface {p2, p3}, Ljr3;->e0(I)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    invoke-interface {p2, p3}, Ljr3;->f(I)I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method

.method public final i(Lkn3;Ljr3;I)I
    .locals 0

    .line 1
    iget-object p0, p0, La23;->x:Ld23;

    .line 2
    .line 3
    sget-object p1, Ld23;->i:Ld23;

    .line 4
    .line 5
    if-ne p0, p1, :cond_0

    .line 6
    .line 7
    invoke-interface {p2, p3}, Ljr3;->e0(I)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_0
    invoke-interface {p2, p3}, Ljr3;->f(I)I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    return p0
.end method
