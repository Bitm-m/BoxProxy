.class public final La65;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public a:F

.field public b:F

.field public c:F

.field public d:F

.field public e:Landroid/graphics/RenderEffect;

.field public f:Landroid/graphics/RenderEffect;

.field public g:Landroid/graphics/RenderEffect;

.field public h:Landroid/graphics/RenderEffect;
