.class public final synthetic Lab3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Lbi2;

.field public final synthetic j:Lw04;

.field public final synthetic k:Lyb3;

.field public final synthetic l:Lxt4;

.field public final synthetic m:Lwv;

.field public final synthetic n:Luv;

.field public final synthetic o:Lpj1;

.field public final synthetic p:Z

.field public final synthetic q:Lar4;

.field public final synthetic r:Lfa2;

.field public final synthetic s:I

.field public final synthetic t:S


# direct methods
.method public synthetic constructor <init>(Lbi2;Lw04;Lyb3;Lxt4;Lwv;Luv;Lpj1;ZLar4;Lfa2;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lab3;->i:Lbi2;

    .line 5
    .line 6
    iput-object p2, p0, Lab3;->j:Lw04;

    .line 7
    .line 8
    iput-object p3, p0, Lab3;->k:Lyb3;

    .line 9
    .line 10
    iput-object p4, p0, Lab3;->l:Lxt4;

    .line 11
    .line 12
    iput-object p5, p0, Lab3;->m:Lwv;

    .line 13
    .line 14
    iput-object p6, p0, Lab3;->n:Luv;

    .line 15
    .line 16
    iput-object p7, p0, Lab3;->o:Lpj1;

    .line 17
    .line 18
    iput-boolean p8, p0, Lab3;->p:Z

    .line 19
    .line 20
    iput-object p9, p0, Lab3;->q:Lar4;

    .line 21
    .line 22
    iput-object p10, p0, Lab3;->r:Lfa2;

    .line 23
    .line 24
    iput p11, p0, Lab3;->s:I

    .line 25
    .line 26
    iput-short p12, p0, Lab3;->t:S

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    move-object v10, p1

    .line 2
    check-cast v10, Lib2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lab3;->s:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lcc3;->X(I)I

    .line 14
    .line 15
    .line 16
    move-result v11

    .line 17
    iget-object v0, p0, Lab3;->i:Lbi2;

    .line 18
    .line 19
    iget-object v1, p0, Lab3;->j:Lw04;

    .line 20
    .line 21
    iget-object v2, p0, Lab3;->k:Lyb3;

    .line 22
    .line 23
    iget-object v3, p0, Lab3;->l:Lxt4;

    .line 24
    .line 25
    iget-object v4, p0, Lab3;->m:Lwv;

    .line 26
    .line 27
    iget-object v5, p0, Lab3;->n:Luv;

    .line 28
    .line 29
    iget-object v6, p0, Lab3;->o:Lpj1;

    .line 30
    .line 31
    iget-boolean v7, p0, Lab3;->p:Z

    .line 32
    .line 33
    iget-object v8, p0, Lab3;->q:Lar4;

    .line 34
    .line 35
    iget-object v9, p0, Lab3;->r:Lfa2;

    .line 36
    .line 37
    iget-short v12, p0, Lab3;->t:S

    .line 38
    .line 39
    invoke-static/range {v0 .. v12}, Lbb3;->c(Lbi2;Lw04;Lyb3;Lxt4;Lwv;Luv;Lpj1;ZLar4;Lfa2;Lib2;II)V

    .line 40
    .line 41
    .line 42
    sget-object p0, Lxc7;->a:Lxc7;

    .line 43
    .line 44
    return-object p0
.end method
