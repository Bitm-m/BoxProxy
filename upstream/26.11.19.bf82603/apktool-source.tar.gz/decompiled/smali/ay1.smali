.class public Lay1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Ld83;


# static fields
.field public static final a:Lqs6;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lqs6;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lqs6;-><init>(Lns6;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lay1;->a:Lqs6;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public a()Lu4;
    .locals 0

    .line 1
    sget-object p0, Lzx1;->c:Lzx1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final b()I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public c(Lp91;Lkn0;Lxy0;Landroid/os/Bundle;)V
    .locals 0

    .line 1
    return-void
.end method

.method public d()[Lai4;
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    new-array p0, p0, [Lai4;

    .line 3
    .line 4
    return-object p0
.end method

.method public destroy()V
    .locals 0

    .line 1
    return-void
.end method

.method public final e(Lp91;II)I
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final f()Lu6;
    .locals 0

    .line 1
    sget-object p0, Lu6;->i0:Lu6;

    .line 2
    .line 3
    return-object p0
.end method

.method public g()Lqs6;
    .locals 0

    .line 1
    sget-object p0, Lay1;->a:Lqs6;

    .line 2
    .line 3
    return-object p0
.end method

.method public h()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
