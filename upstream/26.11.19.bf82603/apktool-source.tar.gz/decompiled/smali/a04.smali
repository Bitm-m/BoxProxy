.class public final synthetic La04;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Z

.field public final synthetic k:J

.field public final synthetic l:Z

.field public final synthetic m:Ljava/lang/String;

.field public final synthetic n:Lw04;

.field public final synthetic o:Lw04;

.field public final synthetic p:Ljava/lang/String;

.field public final synthetic q:Lk12;

.field public final synthetic r:Lu92;

.field public final synthetic s:Z

.field public final synthetic t:J

.field public final synthetic u:Lu92;

.field public final synthetic v:Lyz0;

.field public final synthetic w:J

.field public final synthetic x:Lyz0;

.field public final synthetic y:Lyz0;

.field public final synthetic z:Lnl6;


# direct methods
.method public synthetic constructor <init>(ZZJZLjava/lang/String;Lw04;Lw04;Ljava/lang/String;Lk12;Lu92;ZJLu92;Lyz0;JLyz0;Lyz0;Lnl6;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, La04;->i:Z

    .line 5
    .line 6
    iput-boolean p2, p0, La04;->j:Z

    .line 7
    .line 8
    iput-wide p3, p0, La04;->k:J

    .line 9
    .line 10
    iput-boolean p5, p0, La04;->l:Z

    .line 11
    .line 12
    iput-object p6, p0, La04;->m:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p7, p0, La04;->n:Lw04;

    .line 15
    .line 16
    iput-object p8, p0, La04;->o:Lw04;

    .line 17
    .line 18
    iput-object p9, p0, La04;->p:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p10, p0, La04;->q:Lk12;

    .line 21
    .line 22
    iput-object p11, p0, La04;->r:Lu92;

    .line 23
    .line 24
    iput-boolean p12, p0, La04;->s:Z

    .line 25
    .line 26
    iput-wide p13, p0, La04;->t:J

    .line 27
    .line 28
    iput-object p15, p0, La04;->u:Lu92;

    .line 29
    .line 30
    move-object/from16 p1, p16

    .line 31
    .line 32
    iput-object p1, p0, La04;->v:Lyz0;

    .line 33
    .line 34
    move-wide/from16 p1, p17

    .line 35
    .line 36
    iput-wide p1, p0, La04;->w:J

    .line 37
    .line 38
    move-object/from16 p1, p19

    .line 39
    .line 40
    iput-object p1, p0, La04;->x:Lyz0;

    .line 41
    .line 42
    move-object/from16 p1, p20

    .line 43
    .line 44
    iput-object p1, p0, La04;->y:Lyz0;

    .line 45
    .line 46
    move-object/from16 p1, p21

    .line 47
    .line 48
    iput-object p1, p0, La04;->z:Lnl6;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lib2;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    and-int/lit8 v3, v2, 0x3

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    const/4 v5, 0x1

    .line 19
    if-eq v3, v4, :cond_0

    .line 20
    .line 21
    move v3, v5

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v3, 0x0

    .line 24
    :goto_0
    and-int/2addr v2, v5

    .line 25
    invoke-virtual {v1, v2, v3}, Lib2;->X(IZ)Z

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-eqz v2, :cond_7

    .line 30
    .line 31
    iget-boolean v2, v0, La04;->i:Z

    .line 32
    .line 33
    iget-boolean v3, v0, La04;->j:Z

    .line 34
    .line 35
    iget-object v4, v0, La04;->m:Ljava/lang/String;

    .line 36
    .line 37
    move v7, v3

    .line 38
    iget-object v3, v0, La04;->o:Lw04;

    .line 39
    .line 40
    iget-object v8, v0, La04;->p:Ljava/lang/String;

    .line 41
    .line 42
    iget-object v15, v0, La04;->q:Lk12;

    .line 43
    .line 44
    iget-boolean v9, v0, La04;->s:Z

    .line 45
    .line 46
    move-object/from16 v16, v3

    .line 47
    .line 48
    move-object v10, v4

    .line 49
    iget-wide v3, v0, La04;->t:J

    .line 50
    .line 51
    iget-object v11, v0, La04;->u:Lu92;

    .line 52
    .line 53
    iget-object v12, v0, La04;->v:Lyz0;

    .line 54
    .line 55
    iget-object v13, v0, La04;->x:Lyz0;

    .line 56
    .line 57
    iget-object v14, v0, La04;->y:Lyz0;

    .line 58
    .line 59
    if-eqz v2, :cond_6

    .line 60
    .line 61
    const v2, 0x7367383d

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1, v2}, Lib2;->g0(I)V

    .line 65
    .line 66
    .line 67
    invoke-static {v1}, Lzx3;->b(Lib2;)Lyx3;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    xor-int/2addr v5, v7

    .line 72
    iget-object v7, v0, La04;->z:Lnl6;

    .line 73
    .line 74
    invoke-interface {v7}, Lnl6;->getValue()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v17

    .line 78
    check-cast v17, Ljava/lang/Boolean;

    .line 79
    .line 80
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Boolean;->booleanValue()Z

    .line 81
    .line 82
    .line 83
    move-result v17

    .line 84
    iget-object v6, v2, Lyx3;->a:Lsd2;

    .line 85
    .line 86
    move/from16 p2, v5

    .line 87
    .line 88
    move-object/from16 v18, v6

    .line 89
    .line 90
    iget-wide v5, v2, Lyx3;->b:J

    .line 91
    .line 92
    move/from16 v20, v9

    .line 93
    .line 94
    new-instance v9, Lj67;

    .line 95
    .line 96
    move-wide/from16 v21, v5

    .line 97
    .line 98
    iget-wide v5, v0, La04;->k:J

    .line 99
    .line 100
    invoke-direct {v9, v5, v6}, Lj67;-><init>(J)V

    .line 101
    .line 102
    .line 103
    iget-boolean v2, v0, La04;->l:Z

    .line 104
    .line 105
    if-eqz v2, :cond_1

    .line 106
    .line 107
    const v2, 0x2d03ce9c

    .line 108
    .line 109
    .line 110
    invoke-virtual {v1, v2}, Lib2;->g0(I)V

    .line 111
    .line 112
    .line 113
    invoke-static {v1}, Lsx3;->c(Lib2;)Z

    .line 114
    .line 115
    .line 116
    move-result v2

    .line 117
    const/4 v5, 0x0

    .line 118
    invoke-virtual {v1, v5}, Lib2;->r(Z)V

    .line 119
    .line 120
    .line 121
    :goto_1
    move-object v6, v10

    .line 122
    goto :goto_2

    .line 123
    :cond_1
    const/4 v5, 0x0

    .line 124
    const v2, 0x737609b9

    .line 125
    .line 126
    .line 127
    invoke-virtual {v1, v2}, Lib2;->g0(I)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v1, v5}, Lib2;->r(Z)V

    .line 131
    .line 132
    .line 133
    move v2, v5

    .line 134
    goto :goto_1

    .line 135
    :goto_2
    if-eqz v2, :cond_2

    .line 136
    .line 137
    const/high16 v2, 0x41000000    # 8.0f

    .line 138
    .line 139
    goto :goto_3

    .line 140
    :cond_2
    const/4 v2, 0x0

    .line 141
    :goto_3
    invoke-virtual {v1, v3, v4}, Lib2;->f(J)Z

    .line 142
    .line 143
    .line 144
    move-result v19

    .line 145
    invoke-virtual {v1, v11}, Lib2;->g(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v23

    .line 149
    or-int v19, v19, v23

    .line 150
    .line 151
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v5

    .line 155
    sget-object v10, Lg21;->a:Ley0;

    .line 156
    .line 157
    if-nez v19, :cond_3

    .line 158
    .line 159
    if-ne v5, v10, :cond_4

    .line 160
    .line 161
    :cond_3
    new-instance v5, Lhf;

    .line 162
    .line 163
    invoke-direct {v5, v3, v4, v11}, Lhf;-><init>(JLu92;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v1, v5}, Lib2;->p0(Ljava/lang/Object;)V

    .line 167
    .line 168
    .line 169
    :cond_4
    check-cast v5, Lu92;

    .line 170
    .line 171
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v3

    .line 175
    if-ne v3, v10, :cond_5

    .line 176
    .line 177
    new-instance v3, Ljw3;

    .line 178
    .line 179
    const/16 v4, 0x10

    .line 180
    .line 181
    invoke-direct {v3, v4}, Ljw3;-><init>(B)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v1, v3}, Lib2;->p0(Ljava/lang/Object;)V

    .line 185
    .line 186
    .line 187
    :cond_5
    check-cast v3, Lu92;

    .line 188
    .line 189
    new-instance v4, Lcm;

    .line 190
    .line 191
    const/16 v10, 0xe

    .line 192
    .line 193
    invoke-direct {v4, v13, v10}, Lcm;-><init>(Lyz0;B)V

    .line 194
    .line 195
    .line 196
    const v10, 0x470a0502

    .line 197
    .line 198
    .line 199
    invoke-static {v10, v4, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 200
    .line 201
    .line 202
    move-result-object v25

    .line 203
    new-instance v4, Lvc1;

    .line 204
    .line 205
    const/16 v10, 0x17

    .line 206
    .line 207
    invoke-direct {v4, v14, v7, v10}, Lvc1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 208
    .line 209
    .line 210
    const v7, -0x13b1a087

    .line 211
    .line 212
    .line 213
    invoke-static {v7, v4, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 214
    .line 215
    .line 216
    move-result-object v26

    .line 217
    const/high16 v28, 0x30000

    .line 218
    .line 219
    move v11, v2

    .line 220
    iget-object v2, v0, La04;->n:Lw04;

    .line 221
    .line 222
    move-object/from16 v27, v1

    .line 223
    .line 224
    move/from16 v1, v17

    .line 225
    .line 226
    move-object/from16 v13, v18

    .line 227
    .line 228
    move-wide/from16 v17, v21

    .line 229
    .line 230
    move-object/from16 v22, v5

    .line 231
    .line 232
    const/4 v5, 0x0

    .line 233
    move-object v7, v8

    .line 234
    iget-object v8, v0, La04;->r:Lu92;

    .line 235
    .line 236
    move-object/from16 v24, v12

    .line 237
    .line 238
    const/4 v12, 0x0

    .line 239
    const/4 v14, 0x0

    .line 240
    move-object v0, v6

    .line 241
    move-object v6, v7

    .line 242
    move-object v7, v15

    .line 243
    const/4 v15, 0x0

    .line 244
    move-object/from16 v23, v3

    .line 245
    .line 246
    move-object/from16 v3, v16

    .line 247
    .line 248
    const/4 v10, 0x0

    .line 249
    const/16 v16, 0x0

    .line 250
    .line 251
    const/16 v19, 0x0

    .line 252
    .line 253
    move/from16 v21, v20

    .line 254
    .line 255
    const/16 v20, 0x0

    .line 256
    .line 257
    move/from16 v4, p2

    .line 258
    .line 259
    invoke-static/range {v0 .. v28}, Lwg2;->b(Ljava/lang/String;ZLw04;Lw04;ZLjava/lang/String;Ljava/lang/String;Lk12;Lu92;Lj67;FFLhg2;Lsd2;FFLgg2;JLeu1;Leg2;ZLu92;Lu92;Lyz0;Lyz0;Lyz0;Lib2;I)V

    .line 260
    .line 261
    .line 262
    move-object/from16 v1, v27

    .line 263
    .line 264
    const/4 v2, 0x0

    .line 265
    invoke-virtual {v1, v2}, Lib2;->r(Z)V

    .line 266
    .line 267
    .line 268
    goto :goto_4

    .line 269
    :cond_6
    move-object v2, v8

    .line 270
    move v8, v7

    .line 271
    move-object v7, v2

    .line 272
    move/from16 v20, v9

    .line 273
    .line 274
    move-object v6, v10

    .line 275
    move-object/from16 v24, v12

    .line 276
    .line 277
    const v9, 0x7383b481

    .line 278
    .line 279
    .line 280
    invoke-virtual {v1, v9}, Lib2;->g0(I)V

    .line 281
    .line 282
    .line 283
    sget-object v9, Lbx0;->a:Lnt1;

    .line 284
    .line 285
    invoke-virtual {v1, v9}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    move-result-object v10

    .line 289
    check-cast v10, Lax0;

    .line 290
    .line 291
    invoke-virtual {v10}, Lax0;->i()J

    .line 292
    .line 293
    .line 294
    move-result-wide v17

    .line 295
    invoke-virtual {v1, v9}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object v9

    .line 299
    check-cast v9, Lax0;

    .line 300
    .line 301
    invoke-virtual {v9}, Lax0;->n()J

    .line 302
    .line 303
    .line 304
    move-result-wide v9

    .line 305
    xor-int/2addr v5, v8

    .line 306
    const/high16 v25, 0x6030000

    .line 307
    .line 308
    const/16 v26, 0x4000

    .line 309
    .line 310
    move-wide/from16 v21, v3

    .line 311
    .line 312
    iget-wide v2, v0, La04;->w:J

    .line 313
    .line 314
    const/high16 v12, 0x41d00000    # 26.0f

    .line 315
    .line 316
    move-object/from16 v27, v1

    .line 317
    .line 318
    move-wide v1, v2

    .line 319
    move-wide/from16 v3, v21

    .line 320
    .line 321
    move-object/from16 v21, v11

    .line 322
    .line 323
    move-object v11, v13

    .line 324
    const/high16 v13, 0x41800000    # 16.0f

    .line 325
    .line 326
    move-object/from16 v22, v14

    .line 327
    .line 328
    const/high16 v14, 0x41800000    # 16.0f

    .line 329
    .line 330
    move-object v0, v6

    .line 331
    move-wide/from16 v29, v17

    .line 332
    .line 333
    move/from16 v17, v5

    .line 334
    .line 335
    move-wide/from16 v5, v29

    .line 336
    .line 337
    const/16 v18, 0x0

    .line 338
    .line 339
    const/16 v19, 0x0

    .line 340
    .line 341
    move-wide v8, v9

    .line 342
    move-object/from16 v10, v24

    .line 343
    .line 344
    const/high16 v24, 0xd80000

    .line 345
    .line 346
    move-object/from16 v23, v27

    .line 347
    .line 348
    invoke-static/range {v0 .. v26}, Lyq6;->d(Ljava/lang/String;JJJLjava/lang/String;JLja2;Lyz0;FFFLk12;Lw04;ZLjava/lang/String;FZLu92;Lja2;Lib2;III)V

    .line 349
    .line 350
    .line 351
    move-object/from16 v1, v23

    .line 352
    .line 353
    const/4 v2, 0x0

    .line 354
    invoke-virtual {v1, v2}, Lib2;->r(Z)V

    .line 355
    .line 356
    .line 357
    goto :goto_4

    .line 358
    :cond_7
    invoke-virtual {v1}, Lib2;->a0()V

    .line 359
    .line 360
    .line 361
    :goto_4
    sget-object v0, Lxc7;->a:Lxc7;

    .line 362
    .line 363
    return-object v0
.end method
