.class public final synthetic Lb56;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Lif6;

.field public final synthetic j:Z

.field public final synthetic k:Lu92;

.field public final synthetic l:Lma6;

.field public final synthetic m:Lw04;

.field public final synthetic n:Z

.field public final synthetic o:Lw46;

.field public final synthetic p:Lh40;

.field public final synthetic q:Lzt4;

.field public final synthetic r:Lyz0;

.field public final synthetic s:Lyz0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lif6;ZLu92;Lma6;Lw04;ZLw46;Lh40;Lzt4;Lyz0;Lyz0;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb56;->i:Lif6;

    .line 5
    .line 6
    iput-boolean p2, p0, Lb56;->j:Z

    .line 7
    .line 8
    iput-object p3, p0, Lb56;->k:Lu92;

    .line 9
    .line 10
    iput-object p4, p0, Lb56;->l:Lma6;

    .line 11
    .line 12
    iput-object p5, p0, Lb56;->m:Lw04;

    .line 13
    .line 14
    iput-boolean p6, p0, Lb56;->n:Z

    .line 15
    .line 16
    iput-object p7, p0, Lb56;->o:Lw46;

    .line 17
    .line 18
    iput-object p8, p0, Lb56;->p:Lh40;

    .line 19
    .line 20
    iput-object p9, p0, Lb56;->q:Lzt4;

    .line 21
    .line 22
    iput-object p10, p0, Lb56;->r:Lyz0;

    .line 23
    .line 24
    iput-object p11, p0, Lb56;->s:Lyz0;

    .line 25
    .line 26
    iput p12, p0, Lb56;->t:I

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13

    .line 1
    move-object v11, p1

    .line 2
    check-cast v11, Lib2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lb56;->t:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lcc3;->X(I)I

    .line 14
    .line 15
    .line 16
    move-result v12

    .line 17
    iget-object v0, p0, Lb56;->i:Lif6;

    .line 18
    .line 19
    iget-boolean v1, p0, Lb56;->j:Z

    .line 20
    .line 21
    iget-object v2, p0, Lb56;->k:Lu92;

    .line 22
    .line 23
    iget-object v3, p0, Lb56;->l:Lma6;

    .line 24
    .line 25
    iget-object v4, p0, Lb56;->m:Lw04;

    .line 26
    .line 27
    iget-boolean v5, p0, Lb56;->n:Z

    .line 28
    .line 29
    iget-object v6, p0, Lb56;->o:Lw46;

    .line 30
    .line 31
    iget-object v7, p0, Lb56;->p:Lh40;

    .line 32
    .line 33
    iget-object v8, p0, Lb56;->q:Lzt4;

    .line 34
    .line 35
    iget-object v9, p0, Lb56;->r:Lyz0;

    .line 36
    .line 37
    iget-object v10, p0, Lb56;->s:Lyz0;

    .line 38
    .line 39
    invoke-static/range {v0 .. v12}, Lfa3;->q(Lif6;ZLu92;Lma6;Lw04;ZLw46;Lh40;Lzt4;Lyz0;Lyz0;Lib2;I)V

    .line 40
    .line 41
    .line 42
    sget-object p0, Lxc7;->a:Lxc7;

    .line 43
    .line 44
    return-object p0
.end method
