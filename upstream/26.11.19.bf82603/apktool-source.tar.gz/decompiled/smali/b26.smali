.class public abstract Lb26;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Le44;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Le44;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Le44;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lb26;->a:Le44;

    .line 8
    .line 9
    return-void
.end method
