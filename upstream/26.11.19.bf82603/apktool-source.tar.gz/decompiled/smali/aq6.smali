.class public final Laq6;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Lnf1;

.field public final b:Llp6;

.field public final c:Lgx4;

.field public final d:Lgx4;

.field public final e:Lgx4;

.field public f:Lxq6;

.field public g:Ljava/util/List;


# direct methods
.method public constructor <init>(Lnf1;Llp6;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Laq6;->a:Lnf1;

    .line 8
    .line 9
    iput-object p2, p0, Laq6;->b:Llp6;

    .line 10
    .line 11
    sget-object p1, Lby1;->i:Lby1;

    .line 12
    .line 13
    invoke-static {p1}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    iput-object p2, p0, Laq6;->c:Lgx4;

    .line 18
    .line 19
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-static {p2}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, Laq6;->d:Lgx4;

    .line 26
    .line 27
    invoke-static {p2}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 28
    .line 29
    .line 30
    move-result-object p2

    .line 31
    iput-object p2, p0, Laq6;->e:Lgx4;

    .line 32
    .line 33
    iput-object p1, p0, Laq6;->g:Ljava/util/List;

    .line 34
    .line 35
    return-void
.end method

.method public static g(Laq6;)V
    .locals 18

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    new-instance v4, Lg96;

    .line 4
    .line 5
    const/16 v0, 0x15

    .line 6
    .line 7
    invoke-direct {v4, v0}, Lg96;-><init>(B)V

    .line 8
    .line 9
    .line 10
    iget-object v1, v2, Laq6;->b:Llp6;

    .line 11
    .line 12
    invoke-virtual {v2}, Laq6;->d()Ljava/util/List;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    invoke-virtual {v2}, Laq6;->e()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_f

    .line 21
    .line 22
    invoke-virtual {v2}, Laq6;->c()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-nez v0, :cond_f

    .line 27
    .line 28
    :try_start_0
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_0

    .line 37
    .line 38
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v5

    .line 42
    check-cast v5, Lwv3;

    .line 43
    .line 44
    new-instance v6, Ltq6;

    .line 45
    .line 46
    iget-object v7, v5, Lwv3;->a:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v8, v5, Lwv3;->b:Ljava/lang/String;

    .line 49
    .line 50
    iget-object v9, v5, Lwv3;->c:Ljava/lang/String;

    .line 51
    .line 52
    iget-boolean v10, v5, Lwv3;->d:Z

    .line 53
    .line 54
    iget-object v11, v5, Lwv3;->e:Lvq6;

    .line 55
    .line 56
    invoke-direct/range {v6 .. v11}, Ltq6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLvq6;)V

    .line 57
    .line 58
    .line 59
    invoke-static {v6, v10}, Luj5;->B(Ltq6;Z)V

    .line 60
    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    .line 64
    .line 65
    const/16 v5, 0xa

    .line 66
    .line 67
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 68
    .line 69
    .line 70
    move-result v6

    .line 71
    invoke-direct {v0, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 72
    .line 73
    .line 74
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 79
    .line 80
    .line 81
    move-result v7

    .line 82
    if-eqz v7, :cond_1

    .line 83
    .line 84
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v7

    .line 88
    check-cast v7, Lwv3;

    .line 89
    .line 90
    new-instance v8, Ltq6;

    .line 91
    .line 92
    iget-object v9, v7, Lwv3;->a:Ljava/lang/String;

    .line 93
    .line 94
    iget-object v10, v7, Lwv3;->b:Ljava/lang/String;

    .line 95
    .line 96
    iget-object v11, v7, Lwv3;->c:Ljava/lang/String;

    .line 97
    .line 98
    iget-boolean v12, v7, Lwv3;->d:Z

    .line 99
    .line 100
    iget-object v13, v7, Lwv3;->e:Lvq6;

    .line 101
    .line 102
    invoke-direct/range {v8 .. v13}, Ltq6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLvq6;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_1
    sget-object v6, Lby1;->i:Lby1;

    .line 110
    .line 111
    invoke-static {v0, v6}, Luj5;->f(Ljava/util/ArrayList;Ljava/util/List;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    new-instance v0, Ljava/util/ArrayList;

    .line 115
    .line 116
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 117
    .line 118
    .line 119
    move-result v6

    .line 120
    invoke-direct {v0, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 121
    .line 122
    .line 123
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 124
    .line 125
    .line 126
    move-result-object v6

    .line 127
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 128
    .line 129
    .line 130
    move-result v7
    :try_end_0
    .catch Lxp6; {:try_start_0 .. :try_end_0} :catch_0

    .line 131
    const-string v8, ".yml"

    .line 132
    .line 133
    const-string v9, ".yaml"

    .line 134
    .line 135
    if-eqz v7, :cond_2

    .line 136
    .line 137
    :try_start_1
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v7

    .line 141
    check-cast v7, Lwv3;

    .line 142
    .line 143
    iget-object v7, v7, Lwv3;->a:Ljava/lang/String;

    .line 144
    .line 145
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    invoke-static {v7}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 149
    .line 150
    .line 151
    move-result-object v7

    .line 152
    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v7

    .line 156
    invoke-static {v7, v9}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v7

    .line 160
    invoke-static {v7, v8}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v7

    .line 164
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_2
    new-instance v6, Ljava/util/ArrayList;

    .line 169
    .line 170
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    :cond_3
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 178
    .line 179
    .line 180
    move-result v7

    .line 181
    if-eqz v7, :cond_4

    .line 182
    .line 183
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object v7

    .line 187
    move-object v10, v7

    .line 188
    check-cast v10, Ljava/lang/String;

    .line 189
    .line 190
    invoke-static {v10}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 191
    .line 192
    .line 193
    move-result v10

    .line 194
    if-nez v10, :cond_3

    .line 195
    .line 196
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    goto :goto_3

    .line 200
    :cond_4
    invoke-static {v6}, Liv0;->Y0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    invoke-static {v0}, Liv0;->V0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 209
    .line 210
    .line 211
    move-result v0

    .line 212
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 213
    .line 214
    .line 215
    move-result v6
    :try_end_1
    .catch Lxp6; {:try_start_1 .. :try_end_1} :catch_0

    .line 216
    if-ne v0, v6, :cond_e

    .line 217
    .line 218
    iget-object v10, v2, Laq6;->f:Lxq6;

    .line 219
    .line 220
    if-eqz v10, :cond_f

    .line 221
    .line 222
    new-instance v12, Ljava/util/ArrayList;

    .line 223
    .line 224
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    invoke-direct {v12, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 229
    .line 230
    .line 231
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 232
    .line 233
    .line 234
    move-result-object v0

    .line 235
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 236
    .line 237
    .line 238
    move-result v1

    .line 239
    if-eqz v1, :cond_5

    .line 240
    .line 241
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    check-cast v1, Lwv3;

    .line 246
    .line 247
    iget-object v1, v1, Lwv3;->a:Ljava/lang/String;

    .line 248
    .line 249
    invoke-static {v1, v12}, Luj6;->A(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 250
    .line 251
    .line 252
    goto :goto_4

    .line 253
    :cond_5
    new-instance v11, Ljava/util/ArrayList;

    .line 254
    .line 255
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 256
    .line 257
    .line 258
    move-result v0

    .line 259
    invoke-direct {v11, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 260
    .line 261
    .line 262
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    :goto_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 267
    .line 268
    .line 269
    move-result v1

    .line 270
    if-eqz v1, :cond_6

    .line 271
    .line 272
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    check-cast v1, Lwv3;

    .line 277
    .line 278
    iget-object v1, v1, Lwv3;->b:Ljava/lang/String;

    .line 279
    .line 280
    invoke-static {v1, v11}, Luj6;->A(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 281
    .line 282
    .line 283
    goto :goto_5

    .line 284
    :cond_6
    new-instance v13, Ljava/util/ArrayList;

    .line 285
    .line 286
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 287
    .line 288
    .line 289
    move-result v0

    .line 290
    invoke-direct {v13, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 291
    .line 292
    .line 293
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 294
    .line 295
    .line 296
    move-result-object v0

    .line 297
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 298
    .line 299
    .line 300
    move-result v1

    .line 301
    if-eqz v1, :cond_7

    .line 302
    .line 303
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v1

    .line 307
    check-cast v1, Lwv3;

    .line 308
    .line 309
    iget-object v1, v1, Lwv3;->c:Ljava/lang/String;

    .line 310
    .line 311
    invoke-static {v1, v13}, Luj6;->A(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 312
    .line 313
    .line 314
    goto :goto_6

    .line 315
    :cond_7
    new-instance v14, Ljava/util/ArrayList;

    .line 316
    .line 317
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 318
    .line 319
    .line 320
    move-result v0

    .line 321
    invoke-direct {v14, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 322
    .line 323
    .line 324
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    :goto_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 329
    .line 330
    .line 331
    move-result v1

    .line 332
    if-eqz v1, :cond_8

    .line 333
    .line 334
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v1

    .line 338
    check-cast v1, Lwv3;

    .line 339
    .line 340
    iget-boolean v1, v1, Lwv3;->d:Z

    .line 341
    .line 342
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    invoke-virtual {v14, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 347
    .line 348
    .line 349
    goto :goto_7

    .line 350
    :cond_8
    new-instance v15, Ljava/util/ArrayList;

    .line 351
    .line 352
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    invoke-direct {v15, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 357
    .line 358
    .line 359
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 364
    .line 365
    .line 366
    move-result v1

    .line 367
    if-eqz v1, :cond_9

    .line 368
    .line 369
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v1

    .line 373
    check-cast v1, Lwv3;

    .line 374
    .line 375
    iget-object v1, v1, Lwv3;->e:Lvq6;

    .line 376
    .line 377
    invoke-virtual {v15, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    goto :goto_8

    .line 381
    :cond_9
    iget-object v0, v10, Lxq6;->m:Ljava/util/List;

    .line 382
    .line 383
    invoke-virtual {v2}, Laq6;->d()Ljava/util/List;

    .line 384
    .line 385
    .line 386
    move-result-object v1

    .line 387
    new-instance v6, Ljava/util/ArrayList;

    .line 388
    .line 389
    invoke-static {v1, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 390
    .line 391
    .line 392
    move-result v7

    .line 393
    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 394
    .line 395
    .line 396
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 401
    .line 402
    .line 403
    move-result v7

    .line 404
    if-eqz v7, :cond_a

    .line 405
    .line 406
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 407
    .line 408
    .line 409
    move-result-object v7

    .line 410
    check-cast v7, Lwv3;

    .line 411
    .line 412
    iget-object v7, v7, Lwv3;->a:Ljava/lang/String;

    .line 413
    .line 414
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 415
    .line 416
    .line 417
    invoke-static {v7}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 418
    .line 419
    .line 420
    move-result-object v7

    .line 421
    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    move-result-object v7

    .line 425
    invoke-static {v7, v9}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v7

    .line 429
    invoke-static {v7, v8}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 430
    .line 431
    .line 432
    move-result-object v7

    .line 433
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 434
    .line 435
    .line 436
    goto :goto_9

    .line 437
    :cond_a
    invoke-static {v0, v6}, Liv0;->J0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 438
    .line 439
    .line 440
    move-result-object v0

    .line 441
    new-instance v1, Ljava/util/ArrayList;

    .line 442
    .line 443
    invoke-static {v3, v5}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 444
    .line 445
    .line 446
    move-result v5

    .line 447
    invoke-direct {v1, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 448
    .line 449
    .line 450
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 451
    .line 452
    .line 453
    move-result-object v5

    .line 454
    :goto_a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 455
    .line 456
    .line 457
    move-result v6

    .line 458
    if-eqz v6, :cond_b

    .line 459
    .line 460
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 461
    .line 462
    .line 463
    move-result-object v6

    .line 464
    check-cast v6, Lwv3;

    .line 465
    .line 466
    iget-object v6, v6, Lwv3;->a:Ljava/lang/String;

    .line 467
    .line 468
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 469
    .line 470
    .line 471
    invoke-static {v6}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 472
    .line 473
    .line 474
    move-result-object v6

    .line 475
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 476
    .line 477
    .line 478
    move-result-object v6

    .line 479
    invoke-static {v6, v9}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 480
    .line 481
    .line 482
    move-result-object v6

    .line 483
    invoke-static {v6, v8}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 484
    .line 485
    .line 486
    move-result-object v6

    .line 487
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 488
    .line 489
    .line 490
    goto :goto_a

    .line 491
    :cond_b
    invoke-static {v0, v1}, Liv0;->J0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 492
    .line 493
    .line 494
    move-result-object v0

    .line 495
    new-instance v1, Ljava/util/ArrayList;

    .line 496
    .line 497
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 498
    .line 499
    .line 500
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 501
    .line 502
    .line 503
    move-result-object v0

    .line 504
    :cond_c
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 505
    .line 506
    .line 507
    move-result v5

    .line 508
    if-eqz v5, :cond_d

    .line 509
    .line 510
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 511
    .line 512
    .line 513
    move-result-object v5

    .line 514
    move-object v6, v5

    .line 515
    check-cast v6, Ljava/lang/String;

    .line 516
    .line 517
    invoke-static {v6}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 518
    .line 519
    .line 520
    move-result v6

    .line 521
    if-nez v6, :cond_c

    .line 522
    .line 523
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 524
    .line 525
    .line 526
    goto :goto_b

    .line 527
    :cond_d
    invoke-static {v1}, Liv0;->Y0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 528
    .line 529
    .line 530
    move-result-object v0

    .line 531
    invoke-static {v0}, Liv0;->V0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 532
    .line 533
    .line 534
    move-result-object v16

    .line 535
    const/16 v17, 0x3e3

    .line 536
    .line 537
    invoke-static/range {v10 .. v17}, Lxq6;->a(Lxq6;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/List;Ljava/util/ArrayList;Ljava/util/List;I)Lxq6;

    .line 538
    .line 539
    .line 540
    move-result-object v1

    .line 541
    const/4 v0, 0x1

    .line 542
    invoke-virtual {v2, v0}, Laq6;->h(Z)V

    .line 543
    .line 544
    .line 545
    sget-object v6, Ltr;->a:Lca1;

    .line 546
    .line 547
    sget-object v0, Lao1;->a:Lck1;

    .line 548
    .line 549
    sget-object v0, Lho3;->a:Lvi2;

    .line 550
    .line 551
    iget-object v7, v0, Lvi2;->n:Lvi2;

    .line 552
    .line 553
    new-instance v0, Luu0;

    .line 554
    .line 555
    const/4 v5, 0x0

    .line 556
    invoke-direct/range {v0 .. v5}, Luu0;-><init>(Lxq6;Laq6;Ljava/util/List;Lu92;Lea1;)V

    .line 557
    .line 558
    .line 559
    const/4 v1, 0x2

    .line 560
    const/4 v2, 0x0

    .line 561
    invoke-static {v6, v7, v2, v0, v1}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 562
    .line 563
    .line 564
    return-void

    .line 565
    :cond_e
    :try_start_2
    new-instance v0, Lxp6;

    .line 566
    .line 567
    const-string v2, "name"

    .line 568
    .line 569
    invoke-direct {v0, v2}, Lxp6;-><init>(Ljava/lang/String;)V

    .line 570
    .line 571
    .line 572
    throw v0
    :try_end_2
    .catch Lxp6; {:try_start_2 .. :try_end_2} :catch_0

    .line 573
    :catch_0
    move-exception v0

    .line 574
    sget-object v2, Lxb7;->a:Landroid/os/Handler;

    .line 575
    .line 576
    invoke-virtual {v1}, Llp6;->invoke()Ljava/lang/Object;

    .line 577
    .line 578
    .line 579
    move-result-object v2

    .line 580
    check-cast v2, Landroid/content/Context;

    .line 581
    .line 582
    invoke-virtual {v1}, Llp6;->invoke()Ljava/lang/Object;

    .line 583
    .line 584
    .line 585
    move-result-object v1

    .line 586
    check-cast v1, Landroid/content/Context;

    .line 587
    .line 588
    iget-object v0, v0, Lxp6;->i:Ljava/lang/String;

    .line 589
    .line 590
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 591
    .line 592
    .line 593
    move-result-object v0

    .line 594
    const v3, 0x7f0f04e0

    .line 595
    .line 596
    .line 597
    invoke-virtual {v1, v3, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 598
    .line 599
    .line 600
    move-result-object v0

    .line 601
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 602
    .line 603
    .line 604
    invoke-static {v2, v0}, Lxb7;->b(Landroid/content/Context;Ljava/lang/String;)V

    .line 605
    .line 606
    .line 607
    :cond_f
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Laq6;->d()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    new-instance v1, Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 11
    .line 12
    .line 13
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_1

    .line 22
    .line 23
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    move-object v3, v2

    .line 28
    check-cast v3, Lwv3;

    .line 29
    .line 30
    iget-object v3, v3, Lwv3;->e:Lvq6;

    .line 31
    .line 32
    iget-object v3, v3, Lvq6;->a:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {v3, p1}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    if-nez v3, :cond_0

    .line 39
    .line 40
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-virtual {p0, v1}, Laq6;->i(Ljava/util/ArrayList;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final b(Lwv3;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Laq6;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    const/4 v0, 0x1

    .line 9
    invoke-virtual {p0, v0}, Laq6;->h(Z)V

    .line 10
    .line 11
    .line 12
    new-instance v0, Ly56;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x3

    .line 16
    invoke-direct {v0, p1, p0, v1, v2}, Ly56;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 17
    .line 18
    .line 19
    iget-object p0, p0, Laq6;->a:Lnf1;

    .line 20
    .line 21
    invoke-static {p0, v1, v1, v0, v2}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final c()Z
    .locals 0

    .line 1
    iget-object p0, p0, Laq6;->e:Lgx4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final d()Ljava/util/List;
    .locals 0

    .line 1
    iget-object p0, p0, Laq6;->c:Lgx4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/util/List;

    .line 8
    .line 9
    return-object p0
.end method

.method public final e()Z
    .locals 0

    .line 1
    iget-object p0, p0, Laq6;->d:Lgx4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final f(Lfa1;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    instance-of v2, v1, Lzp6;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    move-object v2, v1

    .line 10
    check-cast v2, Lzp6;

    .line 11
    .line 12
    iget v3, v2, Lzp6;->k:I

    .line 13
    .line 14
    const/high16 v4, -0x80000000

    .line 15
    .line 16
    and-int v5, v3, v4

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Lzp6;->k:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v2, Lzp6;

    .line 25
    .line 26
    invoke-direct {v2, v0, v1}, Lzp6;-><init>(Laq6;Lfa1;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    iget-object v1, v2, Lzp6;->i:Ljava/lang/Object;

    .line 30
    .line 31
    iget v3, v2, Lzp6;->k:I

    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    sget-object v5, Lxc7;->a:Lxc7;

    .line 35
    .line 36
    const/4 v6, 0x1

    .line 37
    if-eqz v3, :cond_2

    .line 38
    .line 39
    if-ne v3, v6, :cond_1

    .line 40
    .line 41
    invoke-static {v1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-static {v0}, La02;->d(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-object v4

    .line 51
    :cond_2
    invoke-static {v1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Laq6;->e()Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    if-eqz v1, :cond_3

    .line 59
    .line 60
    return-object v5

    .line 61
    :cond_3
    iput v6, v2, Lzp6;->k:I

    .line 62
    .line 63
    sget-object v1, Lao1;->a:Lck1;

    .line 64
    .line 65
    sget-object v1, Luj1;->k:Luj1;

    .line 66
    .line 67
    new-instance v3, Llf;

    .line 68
    .line 69
    const/4 v6, 0x2

    .line 70
    const/16 v7, 0x17

    .line 71
    .line 72
    invoke-direct {v3, v6, v4, v7}, Llf;-><init>(ILea1;B)V

    .line 73
    .line 74
    .line 75
    invoke-static {v1, v3, v2}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    sget-object v2, Lof1;->i:Lof1;

    .line 80
    .line 81
    if-ne v1, v2, :cond_4

    .line 82
    .line 83
    return-object v2

    .line 84
    :cond_4
    :goto_1
    check-cast v1, Lwq6;

    .line 85
    .line 86
    iget-object v1, v1, Lwq6;->a:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v1, Lxq6;

    .line 89
    .line 90
    iget-object v2, v1, Lxq6;->d:Ljava/util/List;

    .line 91
    .line 92
    iget-object v3, v1, Lxq6;->c:Ljava/util/List;

    .line 93
    .line 94
    iput-object v1, v0, Laq6;->f:Lxq6;

    .line 95
    .line 96
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 97
    .line 98
    .line 99
    move-result v4

    .line 100
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 101
    .line 102
    .line 103
    move-result v6

    .line 104
    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    new-instance v6, Ljava/util/ArrayList;

    .line 109
    .line 110
    invoke-direct {v6, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 111
    .line 112
    .line 113
    const/4 v7, 0x0

    .line 114
    :goto_2
    if-ge v7, v4, :cond_c

    .line 115
    .line 116
    iget-object v8, v1, Lxq6;->l:Ljava/util/List;

    .line 117
    .line 118
    invoke-static {v7, v8}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v8

    .line 122
    check-cast v8, Lvq6;

    .line 123
    .line 124
    if-nez v8, :cond_5

    .line 125
    .line 126
    new-instance v9, Lvq6;

    .line 127
    .line 128
    const/16 v16, 0x0

    .line 129
    .line 130
    const v17, 0xfffff

    .line 131
    .line 132
    .line 133
    const/4 v10, 0x0

    .line 134
    const/4 v11, 0x0

    .line 135
    const/4 v12, 0x0

    .line 136
    const/4 v13, 0x0

    .line 137
    const/4 v14, 0x0

    .line 138
    const/4 v15, 0x0

    .line 139
    invoke-direct/range {v9 .. v17}, Lvq6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 140
    .line 141
    .line 142
    move-object v10, v9

    .line 143
    goto :goto_3

    .line 144
    :cond_5
    move-object v10, v8

    .line 145
    :goto_3
    invoke-static {v7, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v8

    .line 149
    check-cast v8, Ljava/lang/String;

    .line 150
    .line 151
    const-string v9, ""

    .line 152
    .line 153
    if-nez v8, :cond_6

    .line 154
    .line 155
    move-object v8, v9

    .line 156
    :cond_6
    invoke-static {v7, v3}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v11

    .line 160
    check-cast v11, Ljava/lang/String;

    .line 161
    .line 162
    if-nez v11, :cond_7

    .line 163
    .line 164
    move-object/from16 v28, v9

    .line 165
    .line 166
    goto :goto_4

    .line 167
    :cond_7
    move-object/from16 v28, v11

    .line 168
    .line 169
    :goto_4
    iget-object v11, v1, Lxq6;->e:Ljava/util/List;

    .line 170
    .line 171
    invoke-static {v7, v11}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v11

    .line 175
    check-cast v11, Ljava/lang/String;

    .line 176
    .line 177
    if-eqz v11, :cond_8

    .line 178
    .line 179
    move-object v9, v11

    .line 180
    :cond_8
    invoke-static {v9}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 181
    .line 182
    .line 183
    move-result v11

    .line 184
    if-eqz v11, :cond_9

    .line 185
    .line 186
    const-string v9, "DIRECT"

    .line 187
    .line 188
    :cond_9
    iget-object v11, v1, Lxq6;->k:Ljava/util/List;

    .line 189
    .line 190
    if-ltz v7, :cond_a

    .line 191
    .line 192
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 193
    .line 194
    .line 195
    move-result v12

    .line 196
    if-ge v7, v12, :cond_a

    .line 197
    .line 198
    invoke-interface {v11, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v11

    .line 202
    goto :goto_5

    .line 203
    :cond_a
    sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 204
    .line 205
    :goto_5
    check-cast v11, Ljava/lang/Boolean;

    .line 206
    .line 207
    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    .line 208
    .line 209
    .line 210
    move-result v29

    .line 211
    iget-object v11, v10, Lvq6;->e:Ljava/lang/String;

    .line 212
    .line 213
    invoke-static {v11}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 214
    .line 215
    .line 216
    move-result v12

    .line 217
    if-eqz v12, :cond_b

    .line 218
    .line 219
    iget-object v11, v10, Lvq6;->a:Ljava/lang/String;

    .line 220
    .line 221
    const-string v12, "./proxy_provider/"

    .line 222
    .line 223
    const-string v13, ".yaml"

    .line 224
    .line 225
    invoke-static {v12, v11, v13}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v11

    .line 229
    :cond_b
    move-object v15, v11

    .line 230
    const/16 v26, 0x0

    .line 231
    .line 232
    const v27, 0xfffef

    .line 233
    .line 234
    .line 235
    const/4 v11, 0x0

    .line 236
    const/4 v12, 0x0

    .line 237
    const/4 v13, 0x0

    .line 238
    const/4 v14, 0x0

    .line 239
    const/16 v16, 0x0

    .line 240
    .line 241
    const/16 v17, 0x0

    .line 242
    .line 243
    const/16 v18, 0x0

    .line 244
    .line 245
    const/16 v19, 0x0

    .line 246
    .line 247
    const/16 v20, 0x0

    .line 248
    .line 249
    const/16 v21, 0x0

    .line 250
    .line 251
    const/16 v22, 0x0

    .line 252
    .line 253
    const/16 v23, 0x0

    .line 254
    .line 255
    const/16 v24, 0x0

    .line 256
    .line 257
    const/16 v25, 0x0

    .line 258
    .line 259
    invoke-static/range {v10 .. v27}, Lvq6;->a(Lvq6;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lvq6;

    .line 260
    .line 261
    .line 262
    move-result-object v16

    .line 263
    new-instance v11, Lwv3;

    .line 264
    .line 265
    move-object v12, v8

    .line 266
    move-object v14, v9

    .line 267
    move-object/from16 v13, v28

    .line 268
    .line 269
    move/from16 v15, v29

    .line 270
    .line 271
    invoke-direct/range {v11 .. v16}, Lwv3;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLvq6;)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 275
    .line 276
    .line 277
    add-int/lit8 v7, v7, 0x1

    .line 278
    .line 279
    goto/16 :goto_2

    .line 280
    .line 281
    :cond_c
    iget-object v1, v0, Laq6;->c:Lgx4;

    .line 282
    .line 283
    invoke-virtual {v1, v6}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v0}, Laq6;->d()Ljava/util/List;

    .line 287
    .line 288
    .line 289
    move-result-object v1

    .line 290
    iput-object v1, v0, Laq6;->g:Ljava/util/List;

    .line 291
    .line 292
    iget-object v0, v0, Laq6;->d:Lgx4;

    .line 293
    .line 294
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 295
    .line 296
    invoke-virtual {v0, v1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    return-object v5
.end method

.method public final h(Z)V
    .locals 0

    .line 1
    iget-object p0, p0, Laq6;->e:Lgx4;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p0, p1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final i(Ljava/util/ArrayList;)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Laq6;->e()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Laq6;->c()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget-object p0, p0, Laq6;->c:Lgx4;

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final j(Lwv3;)V
    .locals 27

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    iget-object v7, v0, Lwv3;->e:Lvq6;

    .line 4
    .line 5
    invoke-virtual/range {p0 .. p0}, Laq6;->d()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    move-object v3, v2

    .line 24
    check-cast v3, Lwv3;

    .line 25
    .line 26
    iget-object v3, v3, Lwv3;->e:Lvq6;

    .line 27
    .line 28
    iget-object v3, v3, Lvq6;->a:Ljava/lang/String;

    .line 29
    .line 30
    iget-object v4, v7, Lvq6;->a:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v3, v4}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-eqz v3, :cond_0

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    const/4 v2, 0x0

    .line 40
    :goto_0
    move-object v8, v2

    .line 41
    check-cast v8, Lwv3;

    .line 42
    .line 43
    if-eqz v8, :cond_4

    .line 44
    .line 45
    iget-object v1, v8, Lwv3;->a:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v2, v0, Lwv3;->a:Ljava/lang/String;

    .line 48
    .line 49
    invoke-static {v1, v2}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-nez v2, :cond_4

    .line 54
    .line 55
    iget-object v9, v0, Lwv3;->e:Lvq6;

    .line 56
    .line 57
    iget-object v2, v8, Lwv3;->e:Lvq6;

    .line 58
    .line 59
    iget-object v2, v2, Lvq6;->c:Ljava/util/List;

    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    invoke-static {v1}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    const-string v3, ".yaml"

    .line 73
    .line 74
    invoke-static {v1, v3}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    const-string v3, ".yml"

    .line 79
    .line 80
    invoke-static {v1, v3}, Lbn6;->a1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    invoke-static {v2, v1}, Liv0;->K0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    new-instance v2, Ljava/util/ArrayList;

    .line 89
    .line 90
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    :cond_2
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 98
    .line 99
    .line 100
    move-result v3

    .line 101
    if-eqz v3, :cond_3

    .line 102
    .line 103
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    move-object v4, v3

    .line 108
    check-cast v4, Ljava/lang/String;

    .line 109
    .line 110
    invoke-static {v4}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    if-nez v4, :cond_2

    .line 115
    .line 116
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_3
    invoke-static {v2}, Liv0;->Y0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    invoke-static {v1}, Liv0;->V0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 125
    .line 126
    .line 127
    move-result-object v12

    .line 128
    const/16 v25, 0x0

    .line 129
    .line 130
    const v26, 0xffffb

    .line 131
    .line 132
    .line 133
    const/4 v10, 0x0

    .line 134
    const/4 v11, 0x0

    .line 135
    const/4 v13, 0x0

    .line 136
    const/4 v14, 0x0

    .line 137
    const/4 v15, 0x0

    .line 138
    const/16 v16, 0x0

    .line 139
    .line 140
    const/16 v17, 0x0

    .line 141
    .line 142
    const/16 v18, 0x0

    .line 143
    .line 144
    const/16 v19, 0x0

    .line 145
    .line 146
    const/16 v20, 0x0

    .line 147
    .line 148
    const/16 v21, 0x0

    .line 149
    .line 150
    const/16 v22, 0x0

    .line 151
    .line 152
    const/16 v23, 0x0

    .line 153
    .line 154
    const/16 v24, 0x0

    .line 155
    .line 156
    invoke-static/range {v9 .. v26}, Lvq6;->a(Lvq6;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lvq6;

    .line 157
    .line 158
    .line 159
    move-result-object v5

    .line 160
    const/16 v6, 0xf

    .line 161
    .line 162
    const/4 v1, 0x0

    .line 163
    const/4 v2, 0x0

    .line 164
    const/4 v3, 0x0

    .line 165
    const/4 v4, 0x0

    .line 166
    invoke-static/range {v0 .. v6}, Lwv3;->a(Lwv3;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLvq6;I)Lwv3;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    goto :goto_2

    .line 171
    :cond_4
    move-object/from16 v0, p1

    .line 172
    .line 173
    :goto_2
    invoke-virtual/range {p0 .. p0}, Laq6;->d()Ljava/util/List;

    .line 174
    .line 175
    .line 176
    move-result-object v1

    .line 177
    if-eqz v8, :cond_7

    .line 178
    .line 179
    new-instance v2, Ljava/util/ArrayList;

    .line 180
    .line 181
    const/16 v3, 0xa

    .line 182
    .line 183
    invoke-static {v1, v3}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 184
    .line 185
    .line 186
    move-result v3

    .line 187
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 188
    .line 189
    .line 190
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 195
    .line 196
    .line 197
    move-result v3

    .line 198
    if-eqz v3, :cond_6

    .line 199
    .line 200
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v3

    .line 204
    check-cast v3, Lwv3;

    .line 205
    .line 206
    iget-object v4, v3, Lwv3;->e:Lvq6;

    .line 207
    .line 208
    iget-object v4, v4, Lvq6;->a:Ljava/lang/String;

    .line 209
    .line 210
    iget-object v5, v7, Lvq6;->a:Ljava/lang/String;

    .line 211
    .line 212
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v4

    .line 216
    if-eqz v4, :cond_5

    .line 217
    .line 218
    move-object v3, v0

    .line 219
    :cond_5
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    goto :goto_3

    .line 223
    :cond_6
    :goto_4
    move-object/from16 v0, p0

    .line 224
    .line 225
    goto :goto_5

    .line 226
    :cond_7
    invoke-static {v1, v0}, Liv0;->K0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    goto :goto_4

    .line 231
    :goto_5
    invoke-virtual {v0, v2}, Laq6;->i(Ljava/util/ArrayList;)V

    .line 232
    .line 233
    .line 234
    return-void
.end method
