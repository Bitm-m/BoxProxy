.class public final synthetic Lal3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lal3;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Lal3;->i:B

    .line 4
    .line 5
    const/high16 v3, 0x41280000    # 10.5f

    .line 6
    .line 7
    const/high16 v4, 0x41880000    # 17.0f

    .line 8
    .line 9
    const/high16 v5, 0x41200000    # 10.0f

    .line 10
    .line 11
    const/high16 v8, 0x41ac0000    # 21.5f

    .line 12
    .line 13
    const/high16 v9, 0x40900000    # 4.5f

    .line 14
    .line 15
    const/high16 v10, 0x418c0000    # 17.5f

    .line 16
    .line 17
    const/high16 v11, 0x41400000    # 12.0f

    .line 18
    .line 19
    const/high16 v12, 0x41800000    # 16.0f

    .line 20
    .line 21
    const/high16 v13, 0x41c00000    # 24.0f

    .line 22
    .line 23
    const/high16 v15, 0x41a80000    # 21.0f

    .line 24
    .line 25
    const/16 p0, 0x2

    .line 26
    .line 27
    const/high16 v14, 0x40e00000    # 7.0f

    .line 28
    .line 29
    const/high16 v6, 0x41b80000    # 23.0f

    .line 30
    .line 31
    const/high16 v1, 0x40a00000    # 5.0f

    .line 32
    .line 33
    const/high16 v7, 0x41600000    # 14.0f

    .line 34
    .line 35
    const/4 v2, 0x1

    .line 36
    sget-object v19, Lxc7;->a:Lxc7;

    .line 37
    .line 38
    packed-switch v0, :pswitch_data_0

    .line 39
    .line 40
    .line 41
    move-object/from16 v0, p1

    .line 42
    .line 43
    check-cast v0, Lyx4;

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0, v1, v1}, Lyx4;->h(FF)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0, v6, v1}, Lyx4;->f(FF)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0, v7, v13}, Lyx4;->h(FF)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v7, v5}, Lyx4;->f(FF)V

    .line 58
    .line 59
    .line 60
    const/high16 v1, 0x41000000    # 8.0f

    .line 61
    .line 62
    invoke-virtual {v0, v1, v12}, Lyx4;->h(FF)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0, v7, v5}, Lyx4;->f(FF)V

    .line 66
    .line 67
    .line 68
    const/high16 v1, 0x41a00000    # 20.0f

    .line 69
    .line 70
    invoke-virtual {v0, v1, v12}, Lyx4;->f(FF)V

    .line 71
    .line 72
    .line 73
    return-object v19

    .line 74
    :pswitch_0
    move-object/from16 v0, p1

    .line 75
    .line 76
    check-cast v0, Lyx4;

    .line 77
    .line 78
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v0, v7, v1}, Lyx4;->h(FF)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0, v7, v6}, Lyx4;->f(FF)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0, v14, v12}, Lyx4;->h(FF)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, v7, v6}, Lyx4;->f(FF)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0, v15, v12}, Lyx4;->f(FF)V

    .line 94
    .line 95
    .line 96
    return-object v19

    .line 97
    :pswitch_1
    move-object/from16 v0, p1

    .line 98
    .line 99
    check-cast v0, Lyx4;

    .line 100
    .line 101
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0, v7, v6}, Lyx4;->h(FF)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v0, v7, v1}, Lyx4;->f(FF)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0, v14, v11}, Lyx4;->h(FF)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v0, v7, v1}, Lyx4;->f(FF)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0, v15, v11}, Lyx4;->f(FF)V

    .line 117
    .line 118
    .line 119
    return-object v19

    .line 120
    :pswitch_2
    move-object/from16 v0, p1

    .line 121
    .line 122
    check-cast v0, Lyx4;

    .line 123
    .line 124
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    .line 126
    .line 127
    const v1, 0x400ccccd    # 2.2f

    .line 128
    .line 129
    .line 130
    invoke-static {v0, v14, v15, v1}, Lep3;->y(Lyx4;FFF)V

    .line 131
    .line 132
    .line 133
    invoke-static {v0, v14, v14, v1}, Lep3;->y(Lyx4;FFF)V

    .line 134
    .line 135
    .line 136
    invoke-static {v0, v15, v14, v1}, Lep3;->y(Lyx4;FFF)V

    .line 137
    .line 138
    .line 139
    const v1, 0x41966666    # 18.8f

    .line 140
    .line 141
    .line 142
    invoke-virtual {v0, v14, v1}, Lyx4;->h(FF)V

    .line 143
    .line 144
    .line 145
    const v1, 0x41133333    # 9.2f

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v14, v1}, Lyx4;->f(FF)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v0, v14, v4}, Lyx4;->h(FF)V

    .line 152
    .line 153
    .line 154
    const/high16 v2, 0x41780000    # 15.5f

    .line 155
    .line 156
    invoke-virtual {v0, v14, v2}, Lyx4;->f(FF)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0, v14, v11, v3, v11}, Lyx4;->i(FFFF)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v0, v10, v11}, Lyx4;->f(FF)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v0, v15, v11, v15, v1}, Lyx4;->i(FFFF)V

    .line 166
    .line 167
    .line 168
    return-object v19

    .line 169
    :pswitch_3
    move-object/from16 v0, p1

    .line 170
    .line 171
    check-cast v0, Lyx4;

    .line 172
    .line 173
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v0, v1, v9}, Lyx4;->h(FF)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v0, v1, v8}, Lyx4;->f(FF)V

    .line 180
    .line 181
    .line 182
    const/high16 v2, 0x40d00000    # 6.5f

    .line 183
    .line 184
    invoke-virtual {v0, v1, v6, v2, v6}, Lyx4;->i(FFFF)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v0, v13, v6}, Lyx4;->f(FF)V

    .line 188
    .line 189
    .line 190
    const/high16 v1, 0x41940000    # 18.5f

    .line 191
    .line 192
    invoke-virtual {v0, v5, v1}, Lyx4;->h(FF)V

    .line 193
    .line 194
    .line 195
    const/high16 v2, 0x41500000    # 13.0f

    .line 196
    .line 197
    invoke-virtual {v0, v5, v2}, Lyx4;->f(FF)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v0, v12, v1}, Lyx4;->h(FF)V

    .line 201
    .line 202
    .line 203
    const/high16 v2, 0x40c00000    # 6.0f

    .line 204
    .line 205
    invoke-virtual {v0, v12, v2}, Lyx4;->f(FF)V

    .line 206
    .line 207
    .line 208
    const/high16 v2, 0x41b00000    # 22.0f

    .line 209
    .line 210
    invoke-virtual {v0, v2, v1}, Lyx4;->h(FF)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v0, v2, v5}, Lyx4;->f(FF)V

    .line 214
    .line 215
    .line 216
    return-object v19

    .line 217
    :pswitch_4
    move-object/from16 v0, p1

    .line 218
    .line 219
    check-cast v0, Lyx4;

    .line 220
    .line 221
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 222
    .line 223
    .line 224
    invoke-virtual {v0, v14, v9}, Lyx4;->h(FF)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v0, v15, v9}, Lyx4;->f(FF)V

    .line 228
    .line 229
    .line 230
    const/high16 v2, 0x40d00000    # 6.5f

    .line 231
    .line 232
    invoke-virtual {v0, v6, v9, v6, v2}, Lyx4;->i(FFFF)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v0, v6, v8}, Lyx4;->f(FF)V

    .line 236
    .line 237
    .line 238
    const/high16 v3, 0x41bc0000    # 23.5f

    .line 239
    .line 240
    invoke-virtual {v0, v6, v3, v15, v3}, Lyx4;->i(FFFF)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v0, v14, v3}, Lyx4;->f(FF)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {v0, v1, v3, v1, v8}, Lyx4;->i(FFFF)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v0, v1, v2}, Lyx4;->f(FF)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v0, v1, v9, v14, v9}, Lyx4;->i(FFFF)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {v0}, Lyx4;->a()V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v0, v1, v7}, Lyx4;->h(FF)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v0, v6, v7}, Lyx4;->f(FF)V

    .line 262
    .line 263
    .line 264
    const/high16 v1, 0x41100000    # 9.0f

    .line 265
    .line 266
    const v2, 0x4114cccd    # 9.3f

    .line 267
    .line 268
    .line 269
    const v3, 0x3f333333    # 0.7f

    .line 270
    .line 271
    .line 272
    invoke-static {v0, v1, v2, v3}, Lep3;->y(Lyx4;FFF)V

    .line 273
    .line 274
    .line 275
    const v4, 0x4195999a    # 18.7f

    .line 276
    .line 277
    .line 278
    invoke-static {v0, v1, v4, v3}, Lep3;->y(Lyx4;FFF)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v0, v7, v2}, Lyx4;->h(FF)V

    .line 282
    .line 283
    .line 284
    const/high16 v1, 0x41980000    # 19.0f

    .line 285
    .line 286
    invoke-virtual {v0, v1, v2}, Lyx4;->f(FF)V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v0, v7, v4}, Lyx4;->h(FF)V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v0, v1, v4}, Lyx4;->f(FF)V

    .line 293
    .line 294
    .line 295
    return-object v19

    .line 296
    :pswitch_5
    move-object/from16 v9, p1

    .line 297
    .line 298
    check-cast v9, Lyx4;

    .line 299
    .line 300
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    const/high16 v0, 0x40600000    # 3.5f

    .line 304
    .line 305
    const v1, 0x4119999a    # 9.6f

    .line 306
    .line 307
    .line 308
    invoke-virtual {v9, v0, v1}, Lyx4;->h(FF)V

    .line 309
    .line 310
    .line 311
    const/high16 v25, 0x41c40000    # 24.5f

    .line 312
    .line 313
    const v26, 0x4119999a    # 9.6f

    .line 314
    .line 315
    .line 316
    const/high16 v21, 0x41180000    # 9.5f

    .line 317
    .line 318
    const v22, 0x40933333    # 4.6f

    .line 319
    .line 320
    .line 321
    const/high16 v23, 0x41940000    # 18.5f

    .line 322
    .line 323
    const v24, 0x40933333    # 4.6f

    .line 324
    .line 325
    .line 326
    move-object/from16 v20, v9

    .line 327
    .line 328
    invoke-virtual/range {v20 .. v26}, Lyx4;->b(FFFFFF)V

    .line 329
    .line 330
    .line 331
    const v0, 0x4159999a    # 13.6f

    .line 332
    .line 333
    .line 334
    invoke-virtual {v9, v14, v0}, Lyx4;->h(FF)V

    .line 335
    .line 336
    .line 337
    const/high16 v25, 0x41a80000    # 21.0f

    .line 338
    .line 339
    const v26, 0x4159999a    # 13.6f

    .line 340
    .line 341
    .line 342
    const/high16 v21, 0x41300000    # 11.0f

    .line 343
    .line 344
    const v22, 0x41233333    # 10.2f

    .line 345
    .line 346
    .line 347
    const/high16 v23, 0x41880000    # 17.0f

    .line 348
    .line 349
    const v24, 0x41233333    # 10.2f

    .line 350
    .line 351
    .line 352
    invoke-virtual/range {v20 .. v26}, Lyx4;->b(FFFFFF)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v9, v3, v10}, Lyx4;->h(FF)V

    .line 356
    .line 357
    .line 358
    const/high16 v14, 0x418c0000    # 17.5f

    .line 359
    .line 360
    const/high16 v15, 0x418c0000    # 17.5f

    .line 361
    .line 362
    const v10, 0x41466666    # 12.4f

    .line 363
    .line 364
    .line 365
    const v11, 0x417e6666    # 15.9f

    .line 366
    .line 367
    .line 368
    const v12, 0x4179999a    # 15.6f

    .line 369
    .line 370
    .line 371
    const v13, 0x417e6666    # 15.9f

    .line 372
    .line 373
    .line 374
    invoke-virtual/range {v9 .. v15}, Lyx4;->b(FFFFFF)V

    .line 375
    .line 376
    .line 377
    const v3, 0x3f333333    # 0.7f

    .line 378
    .line 379
    .line 380
    invoke-static {v9, v7, v8, v3}, Lep3;->y(Lyx4;FFF)V

    .line 381
    .line 382
    .line 383
    return-object v19

    .line 384
    :pswitch_6
    move-object/from16 v10, p1

    .line 385
    .line 386
    check-cast v10, Lyx4;

    .line 387
    .line 388
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 389
    .line 390
    .line 391
    const v0, 0x40733333    # 3.8f

    .line 392
    .line 393
    .line 394
    invoke-virtual {v10, v7, v0}, Lyx4;->h(FF)V

    .line 395
    .line 396
    .line 397
    const/high16 v0, 0x41580000    # 13.5f

    .line 398
    .line 399
    invoke-virtual {v10, v7, v0}, Lyx4;->f(FF)V

    .line 400
    .line 401
    .line 402
    const/high16 v0, 0x41080000    # 8.5f

    .line 403
    .line 404
    const v1, 0x40d33333    # 6.6f

    .line 405
    .line 406
    .line 407
    invoke-virtual {v10, v0, v1}, Lyx4;->h(FF)V

    .line 408
    .line 409
    .line 410
    const/high16 v15, 0x41600000    # 14.0f

    .line 411
    .line 412
    const/high16 v16, 0x41bc0000    # 23.5f

    .line 413
    .line 414
    const v11, 0x3fa66666    # 1.3f

    .line 415
    .line 416
    .line 417
    const/high16 v12, 0x41380000    # 11.5f

    .line 418
    .line 419
    const/high16 v13, 0x40900000    # 4.5f

    .line 420
    .line 421
    const/high16 v14, 0x41bc0000    # 23.5f

    .line 422
    .line 423
    invoke-virtual/range {v10 .. v16}, Lyx4;->b(FFFFFF)V

    .line 424
    .line 425
    .line 426
    const/high16 v15, 0x419c0000    # 19.5f

    .line 427
    .line 428
    const v16, 0x40d33333    # 6.6f

    .line 429
    .line 430
    .line 431
    const/high16 v11, 0x41bc0000    # 23.5f

    .line 432
    .line 433
    const/high16 v12, 0x41bc0000    # 23.5f

    .line 434
    .line 435
    const v13, 0x41d5999a    # 26.7f

    .line 436
    .line 437
    .line 438
    const/high16 v14, 0x41380000    # 11.5f

    .line 439
    .line 440
    invoke-virtual/range {v10 .. v16}, Lyx4;->b(FFFFFF)V

    .line 441
    .line 442
    .line 443
    return-object v19

    .line 444
    :pswitch_7
    move-object/from16 v0, p1

    .line 445
    .line 446
    check-cast v0, Lyx4;

    .line 447
    .line 448
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 449
    .line 450
    .line 451
    const/high16 v1, 0x41180000    # 9.5f

    .line 452
    .line 453
    invoke-static {v0, v7, v7, v1}, Lep3;->y(Lyx4;FFF)V

    .line 454
    .line 455
    .line 456
    invoke-virtual {v0, v9, v7}, Lyx4;->h(FF)V

    .line 457
    .line 458
    .line 459
    const/high16 v3, 0x41bc0000    # 23.5f

    .line 460
    .line 461
    invoke-virtual {v0, v3, v7}, Lyx4;->f(FF)V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v0, v7, v9}, Lyx4;->h(FF)V

    .line 465
    .line 466
    .line 467
    const/high16 v5, 0x41600000    # 14.0f

    .line 468
    .line 469
    const/high16 v6, 0x41bc0000    # 23.5f

    .line 470
    .line 471
    const/high16 v1, 0x40f00000    # 7.5f

    .line 472
    .line 473
    const/high16 v2, 0x41200000    # 10.0f

    .line 474
    .line 475
    const/high16 v3, 0x40f00000    # 7.5f

    .line 476
    .line 477
    const/high16 v4, 0x41900000    # 18.0f

    .line 478
    .line 479
    invoke-virtual/range {v0 .. v6}, Lyx4;->b(FFFFFF)V

    .line 480
    .line 481
    .line 482
    const/high16 v6, 0x40900000    # 4.5f

    .line 483
    .line 484
    const/high16 v1, 0x41a40000    # 20.5f

    .line 485
    .line 486
    const/high16 v2, 0x41900000    # 18.0f

    .line 487
    .line 488
    const/high16 v3, 0x41a40000    # 20.5f

    .line 489
    .line 490
    const/high16 v4, 0x41200000    # 10.0f

    .line 491
    .line 492
    invoke-virtual/range {v0 .. v6}, Lyx4;->b(FFFFFF)V

    .line 493
    .line 494
    .line 495
    invoke-virtual {v0}, Lyx4;->a()V

    .line 496
    .line 497
    .line 498
    return-object v19

    .line 499
    :pswitch_8
    move-object/from16 v1, p1

    .line 500
    .line 501
    check-cast v1, Lyx4;

    .line 502
    .line 503
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 504
    .line 505
    .line 506
    const/high16 v0, 0x40800000    # 4.0f

    .line 507
    .line 508
    invoke-virtual {v1, v0, v11}, Lyx4;->h(FF)V

    .line 509
    .line 510
    .line 511
    const/high16 v0, 0x41480000    # 12.5f

    .line 512
    .line 513
    const v2, 0x40966666    # 4.7f

    .line 514
    .line 515
    .line 516
    invoke-virtual {v1, v0, v2}, Lyx4;->f(FF)V

    .line 517
    .line 518
    .line 519
    const/high16 v25, 0x41780000    # 15.5f

    .line 520
    .line 521
    const v26, 0x40966666    # 4.7f

    .line 522
    .line 523
    .line 524
    const v21, 0x41566666    # 13.4f

    .line 525
    .line 526
    .line 527
    const v22, 0x4079999a    # 3.9f

    .line 528
    .line 529
    .line 530
    const v23, 0x4169999a    # 14.6f

    .line 531
    .line 532
    .line 533
    const v24, 0x4079999a    # 3.9f

    .line 534
    .line 535
    .line 536
    move-object/from16 v20, v1

    .line 537
    .line 538
    invoke-virtual/range {v20 .. v26}, Lyx4;->b(FFFFFF)V

    .line 539
    .line 540
    .line 541
    invoke-virtual {v1, v13, v11}, Lyx4;->f(FF)V

    .line 542
    .line 543
    .line 544
    const v0, 0x40c66666    # 6.2f

    .line 545
    .line 546
    .line 547
    const v2, 0x4124cccd    # 10.3f

    .line 548
    .line 549
    .line 550
    invoke-virtual {v1, v0, v2}, Lyx4;->h(FF)V

    .line 551
    .line 552
    .line 553
    const v3, 0x41aa6666    # 21.3f

    .line 554
    .line 555
    .line 556
    invoke-virtual {v1, v0, v3}, Lyx4;->f(FF)V

    .line 557
    .line 558
    .line 559
    const v16, 0x41066666    # 8.4f

    .line 560
    .line 561
    .line 562
    const/high16 v17, 0x41bc0000    # 23.5f

    .line 563
    .line 564
    const v12, 0x40c66666    # 6.2f

    .line 565
    .line 566
    .line 567
    const v13, 0x41b66666    # 22.8f

    .line 568
    .line 569
    .line 570
    const v14, 0x40d9999a    # 6.8f

    .line 571
    .line 572
    .line 573
    const/high16 v15, 0x41bc0000    # 23.5f

    .line 574
    .line 575
    move-object v11, v1

    .line 576
    invoke-virtual/range {v11 .. v17}, Lyx4;->b(FFFFFF)V

    .line 577
    .line 578
    .line 579
    const/high16 v0, 0x41300000    # 11.0f

    .line 580
    .line 581
    const/high16 v3, 0x41bc0000    # 23.5f

    .line 582
    .line 583
    invoke-virtual {v1, v0, v3}, Lyx4;->f(FF)V

    .line 584
    .line 585
    .line 586
    invoke-virtual {v1, v0, v10}, Lyx4;->f(FF)V

    .line 587
    .line 588
    .line 589
    const/high16 v10, 0x41880000    # 17.0f

    .line 590
    .line 591
    const/high16 v11, 0x418c0000    # 17.5f

    .line 592
    .line 593
    const/high16 v6, 0x41300000    # 11.0f

    .line 594
    .line 595
    const/high16 v7, 0x41580000    # 13.5f

    .line 596
    .line 597
    const/high16 v8, 0x41880000    # 17.0f

    .line 598
    .line 599
    const/high16 v9, 0x41580000    # 13.5f

    .line 600
    .line 601
    move-object v5, v1

    .line 602
    invoke-virtual/range {v5 .. v11}, Lyx4;->b(FFFFFF)V

    .line 603
    .line 604
    .line 605
    invoke-virtual {v1, v4, v3}, Lyx4;->f(FF)V

    .line 606
    .line 607
    .line 608
    const v0, 0x419ccccd    # 19.6f

    .line 609
    .line 610
    .line 611
    invoke-virtual {v1, v0, v3}, Lyx4;->f(FF)V

    .line 612
    .line 613
    .line 614
    const v6, 0x41ae6666    # 21.8f

    .line 615
    .line 616
    .line 617
    const v7, 0x41aa6666    # 21.3f

    .line 618
    .line 619
    .line 620
    move v0, v2

    .line 621
    const v2, 0x41a9999a    # 21.2f

    .line 622
    .line 623
    .line 624
    const/high16 v3, 0x41bc0000    # 23.5f

    .line 625
    .line 626
    const v4, 0x41ae6666    # 21.8f

    .line 627
    .line 628
    .line 629
    const v5, 0x41b66666    # 22.8f

    .line 630
    .line 631
    .line 632
    invoke-virtual/range {v1 .. v7}, Lyx4;->b(FFFFFF)V

    .line 633
    .line 634
    .line 635
    const v2, 0x41ae6666    # 21.8f

    .line 636
    .line 637
    .line 638
    invoke-virtual {v1, v2, v0}, Lyx4;->f(FF)V

    .line 639
    .line 640
    .line 641
    return-object v19

    .line 642
    :pswitch_9
    move-object/from16 v0, p1

    .line 643
    .line 644
    check-cast v0, Ljava/lang/String;

    .line 645
    .line 646
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 647
    .line 648
    .line 649
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 650
    .line 651
    .line 652
    move-result v1

    .line 653
    if-lez v1, :cond_0

    .line 654
    .line 655
    sget-object v1, Lvv3;->a:Lvv3;

    .line 656
    .line 657
    const-string v1, "."

    .line 658
    .line 659
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 660
    .line 661
    .line 662
    move-result v1

    .line 663
    if-nez v1, :cond_0

    .line 664
    .line 665
    const-string v1, ".."

    .line 666
    .line 667
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 668
    .line 669
    .line 670
    move-result v1

    .line 671
    if-nez v1, :cond_0

    .line 672
    .line 673
    const/16 v1, 0x2f

    .line 674
    .line 675
    invoke-static {v0, v1}, Lbn6;->F0(Ljava/lang/CharSequence;C)Z

    .line 676
    .line 677
    .line 678
    move-result v1

    .line 679
    if-nez v1, :cond_0

    .line 680
    .line 681
    const/16 v1, 0x5c

    .line 682
    .line 683
    invoke-static {v0, v1}, Lbn6;->F0(Ljava/lang/CharSequence;C)Z

    .line 684
    .line 685
    .line 686
    move-result v1

    .line 687
    if-nez v1, :cond_0

    .line 688
    .line 689
    invoke-static {v0}, Lvv3;->g(Ljava/lang/String;)Z

    .line 690
    .line 691
    .line 692
    move-result v0

    .line 693
    if-eqz v0, :cond_0

    .line 694
    .line 695
    goto :goto_0

    .line 696
    :pswitch_a
    move-object/from16 v0, p1

    .line 697
    .line 698
    check-cast v0, Ljava/lang/String;

    .line 699
    .line 700
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 701
    .line 702
    .line 703
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 704
    .line 705
    .line 706
    move-result v1

    .line 707
    if-lez v1, :cond_0

    .line 708
    .line 709
    const-string v1, "#"

    .line 710
    .line 711
    const/4 v3, 0x0

    .line 712
    invoke-static {v0, v1, v3}, Lin6;->A0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 713
    .line 714
    .line 715
    move-result v0

    .line 716
    if-nez v0, :cond_0

    .line 717
    .line 718
    :goto_0
    move v7, v2

    .line 719
    goto :goto_1

    .line 720
    :cond_0
    const/4 v7, 0x0

    .line 721
    :goto_1
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 722
    .line 723
    .line 724
    move-result-object v0

    .line 725
    return-object v0

    .line 726
    :pswitch_b
    move-object/from16 v0, p1

    .line 727
    .line 728
    check-cast v0, Ljava/lang/String;

    .line 729
    .line 730
    return-object v19

    .line 731
    :pswitch_c
    move-object/from16 v0, p1

    .line 732
    .line 733
    check-cast v0, Ly76;

    .line 734
    .line 735
    const/4 v3, 0x0

    .line 736
    invoke-static {v0, v3}, Lw76;->k(Ly76;I)V

    .line 737
    .line 738
    .line 739
    return-object v19

    .line 740
    :pswitch_d
    move-object/from16 v0, p1

    .line 741
    .line 742
    check-cast v0, Ly76;

    .line 743
    .line 744
    const/4 v1, 0x3

    .line 745
    invoke-static {v0, v1}, Lw76;->k(Ly76;I)V

    .line 746
    .line 747
    .line 748
    return-object v19

    .line 749
    :pswitch_e
    move-object/from16 v0, p1

    .line 750
    .line 751
    check-cast v0, Ljt3;

    .line 752
    .line 753
    iget-object v1, v0, Ljt3;->a:Lq03;

    .line 754
    .line 755
    invoke-virtual {v1}, Lq03;->a()J

    .line 756
    .line 757
    .line 758
    move-result-wide v3

    .line 759
    const-wide v5, 0xffffffffL

    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    and-long/2addr v3, v5

    .line 765
    long-to-int v1, v3

    .line 766
    iget-wide v3, v0, Ljt3;->b:J

    .line 767
    .line 768
    and-long v7, v3, v5

    .line 769
    .line 770
    long-to-int v7, v7

    .line 771
    div-int/lit8 v7, v7, 0x2

    .line 772
    .line 773
    if-ge v1, v7, :cond_1

    .line 774
    .line 775
    sget-object v1, Lit3;->h:Lkk7;

    .line 776
    .line 777
    goto :goto_2

    .line 778
    :cond_1
    sget-object v1, Lit3;->i:Lkk7;

    .line 779
    .line 780
    :goto_2
    const/4 v7, 0x4

    .line 781
    new-array v7, v7, [Lht3;

    .line 782
    .line 783
    sget-object v8, Lit3;->e:Lq8;

    .line 784
    .line 785
    const/16 v18, 0x0

    .line 786
    .line 787
    aput-object v8, v7, v18

    .line 788
    .line 789
    sget-object v8, Lit3;->f:Lq8;

    .line 790
    .line 791
    aput-object v8, v7, v2

    .line 792
    .line 793
    sget-object v2, Lit3;->g:Lq8;

    .line 794
    .line 795
    aput-object v2, v7, p0

    .line 796
    .line 797
    const/16 v16, 0x3

    .line 798
    .line 799
    aput-object v1, v7, v16

    .line 800
    .line 801
    invoke-static {v7}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 802
    .line 803
    .line 804
    move-result-object v1

    .line 805
    iget-object v2, v0, Ljt3;->a:Lq03;

    .line 806
    .line 807
    iget-wide v7, v0, Ljt3;->c:J

    .line 808
    .line 809
    and-long/2addr v7, v5

    .line 810
    long-to-int v0, v7

    .line 811
    new-instance v5, Lg34;

    .line 812
    .line 813
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 814
    .line 815
    .line 816
    move-result v6

    .line 817
    invoke-direct {v5, v6}, Lg34;-><init>(I)V

    .line 818
    .line 819
    .line 820
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 821
    .line 822
    .line 823
    move-result v6

    .line 824
    const/4 v7, 0x0

    .line 825
    :goto_3
    if-ge v7, v6, :cond_2

    .line 826
    .line 827
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 828
    .line 829
    .line 830
    move-result-object v8

    .line 831
    check-cast v8, Lht3;

    .line 832
    .line 833
    invoke-interface {v8, v2, v3, v4, v0}, Lht3;->a(Lq03;JI)I

    .line 834
    .line 835
    .line 836
    move-result v8

    .line 837
    invoke-virtual {v5, v8}, Lg34;->a(I)V

    .line 838
    .line 839
    .line 840
    add-int/lit8 v7, v7, 0x1

    .line 841
    .line 842
    goto :goto_3

    .line 843
    :cond_2
    return-object v5

    .line 844
    :pswitch_f
    move-object/from16 v0, p1

    .line 845
    .line 846
    check-cast v0, Ljt3;

    .line 847
    .line 848
    iget-object v1, v0, Ljt3;->a:Lq03;

    .line 849
    .line 850
    invoke-virtual {v1}, Lq03;->a()J

    .line 851
    .line 852
    .line 853
    move-result-wide v3

    .line 854
    const/16 v1, 0x20

    .line 855
    .line 856
    shr-long/2addr v3, v1

    .line 857
    long-to-int v3, v3

    .line 858
    iget-wide v4, v0, Ljt3;->b:J

    .line 859
    .line 860
    shr-long/2addr v4, v1

    .line 861
    long-to-int v4, v4

    .line 862
    div-int/lit8 v4, v4, 0x2

    .line 863
    .line 864
    if-ge v3, v4, :cond_3

    .line 865
    .line 866
    sget-object v3, Lit3;->c:Ljk7;

    .line 867
    .line 868
    :goto_4
    const/4 v4, 0x3

    .line 869
    goto :goto_5

    .line 870
    :cond_3
    sget-object v3, Lit3;->d:Ljk7;

    .line 871
    .line 872
    goto :goto_4

    .line 873
    :goto_5
    new-array v4, v4, [Lgt3;

    .line 874
    .line 875
    sget-object v5, Lit3;->a:Lp8;

    .line 876
    .line 877
    const/16 v18, 0x0

    .line 878
    .line 879
    aput-object v5, v4, v18

    .line 880
    .line 881
    sget-object v5, Lit3;->b:Lp8;

    .line 882
    .line 883
    aput-object v5, v4, v2

    .line 884
    .line 885
    aput-object v3, v4, p0

    .line 886
    .line 887
    invoke-static {v4}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 888
    .line 889
    .line 890
    move-result-object v2

    .line 891
    iget-object v4, v0, Ljt3;->a:Lq03;

    .line 892
    .line 893
    iget-wide v5, v0, Ljt3;->b:J

    .line 894
    .line 895
    iget-wide v7, v0, Ljt3;->c:J

    .line 896
    .line 897
    shr-long/2addr v7, v1

    .line 898
    long-to-int v7, v7

    .line 899
    iget-object v8, v0, Ljt3;->d:Lh93;

    .line 900
    .line 901
    new-instance v0, Lg34;

    .line 902
    .line 903
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 904
    .line 905
    .line 906
    move-result v1

    .line 907
    invoke-direct {v0, v1}, Lg34;-><init>(I)V

    .line 908
    .line 909
    .line 910
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 911
    .line 912
    .line 913
    move-result v1

    .line 914
    move/from16 v9, v18

    .line 915
    .line 916
    :goto_6
    if-ge v9, v1, :cond_4

    .line 917
    .line 918
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 919
    .line 920
    .line 921
    move-result-object v3

    .line 922
    check-cast v3, Lgt3;

    .line 923
    .line 924
    invoke-interface/range {v3 .. v8}, Lgt3;->a(Lq03;JILh93;)I

    .line 925
    .line 926
    .line 927
    move-result v3

    .line 928
    invoke-virtual {v0, v3}, Lg34;->a(I)V

    .line 929
    .line 930
    .line 931
    add-int/lit8 v9, v9, 0x1

    .line 932
    .line 933
    goto :goto_6

    .line 934
    :cond_4
    return-object v0

    .line 935
    :pswitch_10
    move-object/from16 v0, p1

    .line 936
    .line 937
    check-cast v0, Ljava/lang/Long;

    .line 938
    .line 939
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 940
    .line 941
    .line 942
    return-object v19

    .line 943
    :pswitch_11
    move-object/from16 v0, p1

    .line 944
    .line 945
    check-cast v0, Le05;

    .line 946
    .line 947
    invoke-virtual {v0}, Le05;->N()Z

    .line 948
    .line 949
    .line 950
    move-result v1

    .line 951
    if-eqz v1, :cond_7

    .line 952
    .line 953
    iget-object v1, v0, Le05;->k:Lts2;

    .line 954
    .line 955
    if-eqz v1, :cond_7

    .line 956
    .line 957
    iget-object v0, v0, Le05;->j:Lkn3;

    .line 958
    .line 959
    iget-object v2, v0, Lkn3;->z:Ld44;

    .line 960
    .line 961
    if-eqz v2, :cond_5

    .line 962
    .line 963
    invoke-virtual {v2, v1}, Ld44;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 964
    .line 965
    .line 966
    move-result-object v2

    .line 967
    check-cast v2, Le44;

    .line 968
    .line 969
    goto :goto_7

    .line 970
    :cond_5
    const/4 v2, 0x0

    .line 971
    :goto_7
    if-eqz v2, :cond_7

    .line 972
    .line 973
    iget-object v3, v0, Lkn3;->y:Lip;

    .line 974
    .line 975
    if-eqz v3, :cond_6

    .line 976
    .line 977
    invoke-virtual {v3, v1}, Lip;->x(Lts2;)V

    .line 978
    .line 979
    .line 980
    :cond_6
    invoke-virtual {v0, v2}, Lkn3;->d1(Le44;)V

    .line 981
    .line 982
    .line 983
    invoke-virtual {v2}, Le44;->b()V

    .line 984
    .line 985
    .line 986
    :cond_7
    return-object v19

    .line 987
    :pswitch_12
    move-object/from16 v5, p1

    .line 988
    .line 989
    check-cast v5, Le05;

    .line 990
    .line 991
    invoke-virtual {v5}, Le05;->N()Z

    .line 992
    .line 993
    .line 994
    move-result v0

    .line 995
    if-eqz v0, :cond_a

    .line 996
    .line 997
    iget-object v4, v5, Le05;->j:Lkn3;

    .line 998
    .line 999
    iget-boolean v0, v4, Lkn3;->w:Z

    .line 1000
    .line 1001
    if-nez v0, :cond_a

    .line 1002
    .line 1003
    iget-object v0, v5, Le05;->i:Lpr3;

    .line 1004
    .line 1005
    invoke-interface {v0}, Lpr3;->f()Lfa2;

    .line 1006
    .line 1007
    .line 1008
    move-result-object v0

    .line 1009
    iget-object v1, v5, Le05;->i:Lpr3;

    .line 1010
    .line 1011
    invoke-interface {v1}, Lpr3;->e()Lja2;

    .line 1012
    .line 1013
    .line 1014
    move-result-object v1

    .line 1015
    if-eqz v1, :cond_8

    .line 1016
    .line 1017
    invoke-virtual {v4}, Lkn3;->f1()V

    .line 1018
    .line 1019
    .line 1020
    goto :goto_8

    .line 1021
    :cond_8
    const/4 v1, 0x0

    .line 1022
    if-nez v0, :cond_9

    .line 1023
    .line 1024
    iput-object v1, v4, Lkn3;->p:Lja2;

    .line 1025
    .line 1026
    iput-object v1, v4, Lkn3;->q:Lfa2;

    .line 1027
    .line 1028
    iput-object v1, v4, Lkn3;->o:Lfa2;

    .line 1029
    .line 1030
    invoke-virtual {v4}, Lkn3;->f1()V

    .line 1031
    .line 1032
    .line 1033
    goto :goto_8

    .line 1034
    :cond_9
    iput-object v1, v4, Lkn3;->p:Lja2;

    .line 1035
    .line 1036
    iput-object v1, v4, Lkn3;->q:Lfa2;

    .line 1037
    .line 1038
    const-wide v6, 0x7fffffff7fffffffL

    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    const-wide/16 v8, 0x0

    .line 1044
    .line 1045
    invoke-virtual/range {v4 .. v9}, Lkn3;->E0(Le05;JJ)V

    .line 1046
    .line 1047
    .line 1048
    iput-object v0, v4, Lkn3;->o:Lfa2;

    .line 1049
    .line 1050
    :cond_a
    :goto_8
    return-object v19

    .line 1051
    :pswitch_13
    move-object/from16 v0, p1

    .line 1052
    .line 1053
    check-cast v0, Ljava/lang/String;

    .line 1054
    .line 1055
    const-string v1, ".ru.log"

    .line 1056
    .line 1057
    invoke-static {v0, v1, v2}, Lin6;->s0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 1058
    .line 1059
    .line 1060
    move-result v0

    .line 1061
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v0

    .line 1065
    return-object v0

    .line 1066
    :pswitch_14
    move-object/from16 v0, p1

    .line 1067
    .line 1068
    check-cast v0, Ljava/lang/String;

    .line 1069
    .line 1070
    const-string v1, ".zh-TW.log"

    .line 1071
    .line 1072
    invoke-static {v0, v1, v2}, Lin6;->s0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 1073
    .line 1074
    .line 1075
    move-result v0

    .line 1076
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1077
    .line 1078
    .line 1079
    move-result-object v0

    .line 1080
    return-object v0

    .line 1081
    :pswitch_15
    move-object/from16 v0, p1

    .line 1082
    .line 1083
    check-cast v0, Ljava/lang/String;

    .line 1084
    .line 1085
    const-string v1, ".zh-CN.log"

    .line 1086
    .line 1087
    invoke-static {v0, v1, v2}, Lin6;->s0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 1088
    .line 1089
    .line 1090
    move-result v0

    .line 1091
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1092
    .line 1093
    .line 1094
    move-result-object v0

    .line 1095
    return-object v0

    .line 1096
    :pswitch_16
    move-object/from16 v0, p1

    .line 1097
    .line 1098
    check-cast v0, Ljava/lang/String;

    .line 1099
    .line 1100
    const-string v1, ".en.log"

    .line 1101
    .line 1102
    invoke-static {v0, v1, v2}, Lin6;->s0(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 1103
    .line 1104
    .line 1105
    move-result v0

    .line 1106
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1107
    .line 1108
    .line 1109
    move-result-object v0

    .line 1110
    return-object v0

    .line 1111
    :pswitch_17
    move-object/from16 v0, p1

    .line 1112
    .line 1113
    check-cast v0, Ljava/lang/String;

    .line 1114
    .line 1115
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1116
    .line 1117
    .line 1118
    move-result v0

    .line 1119
    xor-int/2addr v0, v2

    .line 1120
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1121
    .line 1122
    .line 1123
    move-result-object v0

    .line 1124
    return-object v0

    .line 1125
    :pswitch_18
    move-object/from16 v0, p1

    .line 1126
    .line 1127
    check-cast v0, Ljava/lang/String;

    .line 1128
    .line 1129
    invoke-static {v0}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1130
    .line 1131
    .line 1132
    move-result-object v0

    .line 1133
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1134
    .line 1135
    .line 1136
    move-result-object v0

    .line 1137
    return-object v0

    .line 1138
    :pswitch_19
    move-object/from16 v0, p1

    .line 1139
    .line 1140
    check-cast v0, Ljava/lang/String;

    .line 1141
    .line 1142
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1143
    .line 1144
    .line 1145
    return-object v19

    .line 1146
    :pswitch_1a
    move-object/from16 v0, p1

    .line 1147
    .line 1148
    check-cast v0, Ljava/lang/String;

    .line 1149
    .line 1150
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1151
    .line 1152
    .line 1153
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1154
    .line 1155
    .line 1156
    move-result v0

    .line 1157
    xor-int/2addr v0, v2

    .line 1158
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1159
    .line 1160
    .line 1161
    move-result-object v0

    .line 1162
    return-object v0

    .line 1163
    :pswitch_1b
    move-object/from16 v0, p1

    .line 1164
    .line 1165
    check-cast v0, Ljava/lang/String;

    .line 1166
    .line 1167
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1168
    .line 1169
    .line 1170
    invoke-static {v0}, Lbn6;->q1(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 1171
    .line 1172
    .line 1173
    move-result-object v0

    .line 1174
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v0

    .line 1178
    return-object v0

    .line 1179
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
