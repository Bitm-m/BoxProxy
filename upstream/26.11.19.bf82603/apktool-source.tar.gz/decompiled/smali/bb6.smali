.class public final Lbb6;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Lj44;

.field public final b:Lj44;

.field public final c:Lj44;

.field public final d:Lj44;

.field public final e:Lj44;


# direct methods
.method public constructor <init>(Lj44;Lj44;Lj44;Lj44;Lj44;)V
    .locals 0

    .line 1
    invoke-static {p1, p2, p3, p4, p5}, Lx35;->r(Lj44;Lj44;Lj44;Lj44;Lj44;)V

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lbb6;->a:Lj44;

    .line 8
    .line 9
    iput-object p2, p0, Lbb6;->b:Lj44;

    .line 10
    .line 11
    iput-object p3, p0, Lbb6;->c:Lj44;

    .line 12
    .line 13
    iput-object p4, p0, Lbb6;->d:Lj44;

    .line 14
    .line 15
    iput-object p5, p0, Lbb6;->e:Lj44;

    .line 16
    .line 17
    return-void
.end method
