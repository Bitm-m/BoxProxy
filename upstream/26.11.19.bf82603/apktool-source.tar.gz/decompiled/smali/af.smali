.class public final synthetic Laf;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lj44;


# direct methods
.method public synthetic constructor <init>(Lj44;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Laf;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Laf;->j:Lj44;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laf;->i:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    sget-object v4, Lxc7;->a:Lxc7;

    .line 8
    .line 9
    iget-object v0, v0, Laf;->j:Lj44;

    .line 10
    .line 11
    packed-switch v1, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    move-object/from16 v9, p1

    .line 15
    .line 16
    check-cast v9, Ljava/lang/String;

    .line 17
    .line 18
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    move-object v5, v1

    .line 26
    check-cast v5, Lle1;

    .line 27
    .line 28
    const/16 v18, 0x0

    .line 29
    .line 30
    const/16 v19, 0x1ff7

    .line 31
    .line 32
    const/4 v6, 0x0

    .line 33
    const/4 v7, 0x0

    .line 34
    const/4 v8, 0x0

    .line 35
    const/4 v10, 0x0

    .line 36
    const/4 v11, 0x0

    .line 37
    const/4 v12, 0x0

    .line 38
    const/4 v13, 0x0

    .line 39
    const/4 v14, 0x0

    .line 40
    const/4 v15, 0x0

    .line 41
    const/16 v16, 0x0

    .line 42
    .line 43
    const/16 v17, 0x0

    .line 44
    .line 45
    invoke-static/range {v5 .. v19}, Lle1;->a(Lle1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lwe1;ZI)Lle1;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v0, v1}, Lln;->y(Lj44;Lle1;)V

    .line 50
    .line 51
    .line 52
    return-object v4

    .line 53
    :pswitch_0
    move-object/from16 v8, p1

    .line 54
    .line 55
    check-cast v8, Ljava/lang/String;

    .line 56
    .line 57
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    move-object v5, v1

    .line 65
    check-cast v5, Lle1;

    .line 66
    .line 67
    const/16 v18, 0x0

    .line 68
    .line 69
    const/16 v19, 0x1ffb

    .line 70
    .line 71
    const/4 v6, 0x0

    .line 72
    const/4 v7, 0x0

    .line 73
    const/4 v9, 0x0

    .line 74
    const/4 v10, 0x0

    .line 75
    const/4 v11, 0x0

    .line 76
    const/4 v12, 0x0

    .line 77
    const/4 v13, 0x0

    .line 78
    const/4 v14, 0x0

    .line 79
    const/4 v15, 0x0

    .line 80
    const/16 v16, 0x0

    .line 81
    .line 82
    const/16 v17, 0x0

    .line 83
    .line 84
    invoke-static/range {v5 .. v19}, Lle1;->a(Lle1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lwe1;ZI)Lle1;

    .line 85
    .line 86
    .line 87
    move-result-object v1

    .line 88
    invoke-static {v0, v1}, Lln;->y(Lj44;Lle1;)V

    .line 89
    .line 90
    .line 91
    return-object v4

    .line 92
    :pswitch_1
    move-object/from16 v1, p1

    .line 93
    .line 94
    check-cast v1, Ljava/lang/String;

    .line 95
    .line 96
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    move-object v5, v2

    .line 104
    check-cast v5, Lle1;

    .line 105
    .line 106
    invoke-static {v1}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v16

    .line 114
    const/16 v18, 0x0

    .line 115
    .line 116
    const/16 v19, 0x1bff

    .line 117
    .line 118
    const/4 v6, 0x0

    .line 119
    const/4 v7, 0x0

    .line 120
    const/4 v8, 0x0

    .line 121
    const/4 v9, 0x0

    .line 122
    const/4 v10, 0x0

    .line 123
    const/4 v11, 0x0

    .line 124
    const/4 v12, 0x0

    .line 125
    const/4 v13, 0x0

    .line 126
    const/4 v14, 0x0

    .line 127
    const/4 v15, 0x0

    .line 128
    const/16 v17, 0x0

    .line 129
    .line 130
    invoke-static/range {v5 .. v19}, Lle1;->a(Lle1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lwe1;ZI)Lle1;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    return-object v4

    .line 138
    :pswitch_2
    move-object/from16 v7, p1

    .line 139
    .line 140
    check-cast v7, Ljava/lang/String;

    .line 141
    .line 142
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    .line 144
    .line 145
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    move-object v5, v1

    .line 150
    check-cast v5, Lle1;

    .line 151
    .line 152
    const/16 v18, 0x0

    .line 153
    .line 154
    const/16 v19, 0x1ffd

    .line 155
    .line 156
    const/4 v6, 0x0

    .line 157
    const/4 v8, 0x0

    .line 158
    const/4 v9, 0x0

    .line 159
    const/4 v10, 0x0

    .line 160
    const/4 v11, 0x0

    .line 161
    const/4 v12, 0x0

    .line 162
    const/4 v13, 0x0

    .line 163
    const/4 v14, 0x0

    .line 164
    const/4 v15, 0x0

    .line 165
    const/16 v16, 0x0

    .line 166
    .line 167
    const/16 v17, 0x0

    .line 168
    .line 169
    invoke-static/range {v5 .. v19}, Lle1;->a(Lle1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Lwe1;ZI)Lle1;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    return-object v4

    .line 177
    :pswitch_3
    move-object/from16 v1, p1

    .line 178
    .line 179
    check-cast v1, Ljava/lang/Boolean;

    .line 180
    .line 181
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 182
    .line 183
    .line 184
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    check-cast v0, Lfa2;

    .line 189
    .line 190
    invoke-interface {v0, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    return-object v4

    .line 194
    :pswitch_4
    move-object/from16 v1, p1

    .line 195
    .line 196
    check-cast v1, Ljava/lang/Boolean;

    .line 197
    .line 198
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 199
    .line 200
    .line 201
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    return-object v4

    .line 205
    :pswitch_5
    move-object/from16 v9, p1

    .line 206
    .line 207
    check-cast v9, Ljava/lang/String;

    .line 208
    .line 209
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 210
    .line 211
    .line 212
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    move-object v5, v1

    .line 217
    check-cast v5, Lwe1;

    .line 218
    .line 219
    const/4 v8, 0x0

    .line 220
    const/4 v10, 0x7

    .line 221
    const/4 v6, 0x0

    .line 222
    const/4 v7, 0x0

    .line 223
    invoke-static/range {v5 .. v10}, Lwe1;->a(Lwe1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lwe1;

    .line 224
    .line 225
    .line 226
    move-result-object v1

    .line 227
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    return-object v4

    .line 231
    :pswitch_6
    move-object/from16 v8, p1

    .line 232
    .line 233
    check-cast v8, Ljava/lang/String;

    .line 234
    .line 235
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 236
    .line 237
    .line 238
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v1

    .line 242
    move-object v5, v1

    .line 243
    check-cast v5, Lwe1;

    .line 244
    .line 245
    const/4 v9, 0x0

    .line 246
    const/16 v10, 0xb

    .line 247
    .line 248
    const/4 v6, 0x0

    .line 249
    const/4 v7, 0x0

    .line 250
    invoke-static/range {v5 .. v10}, Lwe1;->a(Lwe1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lwe1;

    .line 251
    .line 252
    .line 253
    move-result-object v1

    .line 254
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 255
    .line 256
    .line 257
    return-object v4

    .line 258
    :pswitch_7
    move-object/from16 v6, p1

    .line 259
    .line 260
    check-cast v6, Ljava/lang/String;

    .line 261
    .line 262
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 263
    .line 264
    .line 265
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v1

    .line 269
    move-object v5, v1

    .line 270
    check-cast v5, Lwe1;

    .line 271
    .line 272
    const/4 v9, 0x0

    .line 273
    const/16 v10, 0xe

    .line 274
    .line 275
    const/4 v7, 0x0

    .line 276
    const/4 v8, 0x0

    .line 277
    invoke-static/range {v5 .. v10}, Lwe1;->a(Lwe1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lwe1;

    .line 278
    .line 279
    .line 280
    move-result-object v1

    .line 281
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 282
    .line 283
    .line 284
    return-object v4

    .line 285
    :pswitch_8
    move-object/from16 v7, p1

    .line 286
    .line 287
    check-cast v7, Ljava/lang/String;

    .line 288
    .line 289
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 290
    .line 291
    .line 292
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    move-result-object v1

    .line 296
    move-object v5, v1

    .line 297
    check-cast v5, Lwe1;

    .line 298
    .line 299
    const/4 v9, 0x0

    .line 300
    const/16 v10, 0xd

    .line 301
    .line 302
    const/4 v6, 0x0

    .line 303
    const/4 v8, 0x0

    .line 304
    invoke-static/range {v5 .. v10}, Lwe1;->a(Lwe1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lwe1;

    .line 305
    .line 306
    .line 307
    move-result-object v1

    .line 308
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 309
    .line 310
    .line 311
    return-object v4

    .line 312
    :pswitch_9
    move-object/from16 v1, p1

    .line 313
    .line 314
    check-cast v1, Ljava/lang/String;

    .line 315
    .line 316
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 317
    .line 318
    .line 319
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    return-object v4

    .line 323
    :pswitch_a
    move-object/from16 v1, p1

    .line 324
    .line 325
    check-cast v1, Ljava/lang/String;

    .line 326
    .line 327
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 328
    .line 329
    .line 330
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 331
    .line 332
    .line 333
    return-object v4

    .line 334
    :pswitch_b
    move-object/from16 v1, p1

    .line 335
    .line 336
    check-cast v1, Ljava/lang/Boolean;

    .line 337
    .line 338
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 339
    .line 340
    .line 341
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 342
    .line 343
    .line 344
    return-object v4

    .line 345
    :pswitch_c
    move-object/from16 v1, p1

    .line 346
    .line 347
    check-cast v1, Ljava/lang/Integer;

    .line 348
    .line 349
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 350
    .line 351
    .line 352
    move-result v1

    .line 353
    sget-object v2, Lf41;->l:Lrz1;

    .line 354
    .line 355
    invoke-virtual {v2, v1}, Lrz1;->get(I)Ljava/lang/Object;

    .line 356
    .line 357
    .line 358
    move-result-object v1

    .line 359
    check-cast v1, Lf41;

    .line 360
    .line 361
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 362
    .line 363
    .line 364
    return-object v4

    .line 365
    :pswitch_d
    move-object/from16 v1, p1

    .line 366
    .line 367
    check-cast v1, Ljava/lang/String;

    .line 368
    .line 369
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 370
    .line 371
    .line 372
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    return-object v4

    .line 376
    :pswitch_e
    move-object/from16 v1, p1

    .line 377
    .line 378
    check-cast v1, Ljava/lang/String;

    .line 379
    .line 380
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 381
    .line 382
    .line 383
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    return-object v4

    .line 387
    :pswitch_f
    move-object/from16 v1, p1

    .line 388
    .line 389
    check-cast v1, Lm03;

    .line 390
    .line 391
    iget-wide v2, v1, Lm03;->a:J

    .line 392
    .line 393
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 394
    .line 395
    .line 396
    return-object v4

    .line 397
    :pswitch_10
    move-object/from16 v1, p1

    .line 398
    .line 399
    check-cast v1, Ljava/lang/Boolean;

    .line 400
    .line 401
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 402
    .line 403
    .line 404
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    return-object v4

    .line 408
    :pswitch_11
    move-object/from16 v1, p1

    .line 409
    .line 410
    check-cast v1, Lm03;

    .line 411
    .line 412
    iget-wide v2, v1, Lm03;->a:J

    .line 413
    .line 414
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 415
    .line 416
    .line 417
    return-object v4

    .line 418
    :pswitch_12
    move-object/from16 v1, p1

    .line 419
    .line 420
    check-cast v1, Ljava/lang/Boolean;

    .line 421
    .line 422
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 423
    .line 424
    .line 425
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 426
    .line 427
    .line 428
    return-object v4

    .line 429
    :pswitch_13
    move-object/from16 v1, p1

    .line 430
    .line 431
    check-cast v1, Ljava/lang/String;

    .line 432
    .line 433
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 434
    .line 435
    .line 436
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 437
    .line 438
    .line 439
    return-object v4

    .line 440
    :pswitch_14
    move-object/from16 v1, p1

    .line 441
    .line 442
    check-cast v1, Luq0;

    .line 443
    .line 444
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 445
    .line 446
    .line 447
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 448
    .line 449
    .line 450
    move-result-object v4

    .line 451
    check-cast v4, Ljava/lang/String;

    .line 452
    .line 453
    invoke-static {v4}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 454
    .line 455
    .line 456
    move-result v4

    .line 457
    if-nez v4, :cond_2

    .line 458
    .line 459
    iget-object v4, v1, Luq0;->b:Ltq0;

    .line 460
    .line 461
    invoke-virtual {v4}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object v4

    .line 465
    iget-object v1, v1, Luq0;->c:Ljava/lang/String;

    .line 466
    .line 467
    filled-new-array {v4, v1}, [Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v1

    .line 471
    invoke-static {v1}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 472
    .line 473
    .line 474
    move-result-object v1

    .line 475
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 476
    .line 477
    .line 478
    move-result v4

    .line 479
    if-nez v4, :cond_3

    .line 480
    .line 481
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 482
    .line 483
    .line 484
    move-result-object v1

    .line 485
    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 486
    .line 487
    .line 488
    move-result v4

    .line 489
    if-eqz v4, :cond_3

    .line 490
    .line 491
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 492
    .line 493
    .line 494
    move-result-object v4

    .line 495
    check-cast v4, Ljava/lang/String;

    .line 496
    .line 497
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v5

    .line 501
    check-cast v5, Ljava/lang/String;

    .line 502
    .line 503
    invoke-static {v4, v5, v3}, Lbn6;->E0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 504
    .line 505
    .line 506
    move-result v4

    .line 507
    if-eqz v4, :cond_0

    .line 508
    .line 509
    goto :goto_0

    .line 510
    :pswitch_15
    move-object/from16 v1, p1

    .line 511
    .line 512
    check-cast v1, Ljava/lang/String;

    .line 513
    .line 514
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 515
    .line 516
    .line 517
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 518
    .line 519
    .line 520
    return-object v4

    .line 521
    :pswitch_16
    move-object/from16 v1, p1

    .line 522
    .line 523
    check-cast v1, Luq0;

    .line 524
    .line 525
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 526
    .line 527
    .line 528
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 529
    .line 530
    .line 531
    move-result-object v4

    .line 532
    check-cast v4, Ljava/lang/String;

    .line 533
    .line 534
    invoke-static {v4}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 535
    .line 536
    .line 537
    move-result v4

    .line 538
    if-nez v4, :cond_2

    .line 539
    .line 540
    iget-object v4, v1, Luq0;->b:Ltq0;

    .line 541
    .line 542
    invoke-virtual {v4}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object v4

    .line 546
    iget-object v1, v1, Luq0;->c:Ljava/lang/String;

    .line 547
    .line 548
    filled-new-array {v4, v1}, [Ljava/lang/String;

    .line 549
    .line 550
    .line 551
    move-result-object v1

    .line 552
    invoke-static {v1}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 553
    .line 554
    .line 555
    move-result-object v1

    .line 556
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 557
    .line 558
    .line 559
    move-result v4

    .line 560
    if-nez v4, :cond_3

    .line 561
    .line 562
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 563
    .line 564
    .line 565
    move-result-object v1

    .line 566
    :cond_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 567
    .line 568
    .line 569
    move-result v4

    .line 570
    if-eqz v4, :cond_3

    .line 571
    .line 572
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 573
    .line 574
    .line 575
    move-result-object v4

    .line 576
    check-cast v4, Ljava/lang/String;

    .line 577
    .line 578
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 579
    .line 580
    .line 581
    move-result-object v5

    .line 582
    check-cast v5, Ljava/lang/String;

    .line 583
    .line 584
    invoke-static {v4, v5, v3}, Lbn6;->E0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 585
    .line 586
    .line 587
    move-result v4

    .line 588
    if-eqz v4, :cond_1

    .line 589
    .line 590
    :cond_2
    :goto_0
    move v2, v3

    .line 591
    :cond_3
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 592
    .line 593
    .line 594
    move-result-object v0

    .line 595
    return-object v0

    .line 596
    :pswitch_17
    move-object/from16 v1, p1

    .line 597
    .line 598
    check-cast v1, Ljava/util/List;

    .line 599
    .line 600
    if-eqz v0, :cond_4

    .line 601
    .line 602
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 603
    .line 604
    .line 605
    :cond_4
    return-object v4

    .line 606
    :pswitch_18
    move-object/from16 v1, p1

    .line 607
    .line 608
    check-cast v1, Lov6;

    .line 609
    .line 610
    iget-boolean v2, v1, Lov6;->c:Z

    .line 611
    .line 612
    if-eqz v2, :cond_5

    .line 613
    .line 614
    iget-object v1, v1, Lov6;->b:Loi;

    .line 615
    .line 616
    goto :goto_1

    .line 617
    :cond_5
    iget-object v1, v1, Lov6;->a:Loi;

    .line 618
    .line 619
    :goto_1
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 620
    .line 621
    .line 622
    return-object v4

    .line 623
    :pswitch_19
    move-object/from16 v1, p1

    .line 624
    .line 625
    check-cast v1, Lf93;

    .line 626
    .line 627
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 628
    .line 629
    .line 630
    return-object v4

    .line 631
    :pswitch_1a
    move-object/from16 v1, p1

    .line 632
    .line 633
    check-cast v1, Ljava/lang/Boolean;

    .line 634
    .line 635
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 636
    .line 637
    .line 638
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 639
    .line 640
    .line 641
    return-object v4

    .line 642
    :pswitch_1b
    move-object/from16 v1, p1

    .line 643
    .line 644
    check-cast v1, Ljava/lang/Boolean;

    .line 645
    .line 646
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 647
    .line 648
    .line 649
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 650
    .line 651
    .line 652
    return-object v4

    .line 653
    :pswitch_1c
    move-object/from16 v1, p1

    .line 654
    .line 655
    check-cast v1, Lf93;

    .line 656
    .line 657
    invoke-interface {v0, v1}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 658
    .line 659
    .line 660
    return-object v4

    .line 661
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
