.class public final synthetic Lau5;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic A:Ljava/util/List;

.field public final synthetic i:Lw83;

.field public final synthetic j:Z

.field public final synthetic k:Lwu5;

.field public final synthetic l:Z

.field public final synthetic m:Lou5;

.field public final synthetic n:Lkn;

.field public final synthetic o:F

.field public final synthetic p:Lrg5;

.field public final synthetic q:Ljava/util/List;

.field public final synthetic r:Lk12;

.field public final synthetic s:Lw04;

.field public final synthetic t:F

.field public final synthetic u:F

.field public final synthetic v:F

.field public final synthetic w:Lyd3;

.field public final synthetic x:I

.field public final synthetic y:Ltj0;

.field public final synthetic z:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lw83;ZLwu5;ZLou5;Lkn;FLrg5;Ljava/util/List;Lk12;Lw04;FFFLyd3;ILtj0;Ljava/util/List;Ljava/util/List;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lau5;->i:Lw83;

    .line 5
    .line 6
    iput-boolean p2, p0, Lau5;->j:Z

    .line 7
    .line 8
    iput-object p3, p0, Lau5;->k:Lwu5;

    .line 9
    .line 10
    iput-boolean p4, p0, Lau5;->l:Z

    .line 11
    .line 12
    iput-object p5, p0, Lau5;->m:Lou5;

    .line 13
    .line 14
    iput-object p6, p0, Lau5;->n:Lkn;

    .line 15
    .line 16
    iput p7, p0, Lau5;->o:F

    .line 17
    .line 18
    iput-object p8, p0, Lau5;->p:Lrg5;

    .line 19
    .line 20
    iput-object p9, p0, Lau5;->q:Ljava/util/List;

    .line 21
    .line 22
    iput-object p10, p0, Lau5;->r:Lk12;

    .line 23
    .line 24
    iput-object p11, p0, Lau5;->s:Lw04;

    .line 25
    .line 26
    iput p12, p0, Lau5;->t:F

    .line 27
    .line 28
    iput p13, p0, Lau5;->u:F

    .line 29
    .line 30
    iput p14, p0, Lau5;->v:F

    .line 31
    .line 32
    iput-object p15, p0, Lau5;->w:Lyd3;

    .line 33
    .line 34
    move/from16 p1, p16

    .line 35
    .line 36
    iput p1, p0, Lau5;->x:I

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lau5;->y:Ltj0;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lau5;->z:Ljava/util/List;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, Lau5;->A:Ljava/util/List;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p1

    .line 4
    .line 5
    check-cast v7, Lxt4;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Lib2;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 23
    .line 24
    if-nez v3, :cond_1

    .line 25
    .line 26
    invoke-virtual {v1, v7}, Lib2;->g(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_0

    .line 31
    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const/4 v3, 0x2

    .line 35
    :goto_0
    or-int/2addr v2, v3

    .line 36
    :cond_1
    and-int/lit8 v3, v2, 0x13

    .line 37
    .line 38
    const/16 v4, 0x12

    .line 39
    .line 40
    const/4 v5, 0x0

    .line 41
    const/4 v6, 0x1

    .line 42
    if-eq v3, v4, :cond_2

    .line 43
    .line 44
    move v3, v6

    .line 45
    goto :goto_1

    .line 46
    :cond_2
    move v3, v5

    .line 47
    :goto_1
    and-int/2addr v2, v6

    .line 48
    invoke-virtual {v1, v2, v3}, Lib2;->X(IZ)Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_c

    .line 53
    .line 54
    sget-object v2, Lag6;->c:La32;

    .line 55
    .line 56
    iget-boolean v3, v0, Lau5;->j:Z

    .line 57
    .line 58
    xor-int/lit8 v4, v3, 0x1

    .line 59
    .line 60
    iget-object v8, v0, Lau5;->i:Lw83;

    .line 61
    .line 62
    invoke-static {v2, v8, v4}, Lkw3;->b(Lw04;Lw83;Z)Lw04;

    .line 63
    .line 64
    .line 65
    move-result-object v4

    .line 66
    sget-object v8, Lu6;->k:Lt20;

    .line 67
    .line 68
    invoke-static {v8, v5}, Lnb0;->c(Lt20;Z)Lor3;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    iget-wide v9, v1, Lib2;->T:J

    .line 73
    .line 74
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 75
    .line 76
    .line 77
    move-result v9

    .line 78
    invoke-virtual {v1}, Lib2;->m()Liz4;

    .line 79
    .line 80
    .line 81
    move-result-object v10

    .line 82
    invoke-static {v1, v4}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    sget-object v11, Lx11;->d:Lu6;

    .line 87
    .line 88
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v1}, Lib2;->j0()V

    .line 92
    .line 93
    .line 94
    iget-boolean v11, v1, Lib2;->S:Z

    .line 95
    .line 96
    if-eqz v11, :cond_3

    .line 97
    .line 98
    sget-object v11, Laa3;->a0:Lg53;

    .line 99
    .line 100
    invoke-virtual {v1, v11}, Lib2;->l(Lu92;)V

    .line 101
    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_3
    invoke-virtual {v1}, Lib2;->s0()V

    .line 105
    .line 106
    .line 107
    :goto_2
    sget-object v11, Lu6;->S:Lc11;

    .line 108
    .line 109
    invoke-static {v11, v1, v8}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    sget-object v8, Lu6;->R:Lc11;

    .line 113
    .line 114
    invoke-static {v8, v1, v10}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    sget-object v9, Lu6;->T:Lc11;

    .line 122
    .line 123
    invoke-static {v9, v1, v8}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    invoke-static {v1}, Lwt6;->m(Lib2;)V

    .line 127
    .line 128
    .line 129
    sget-object v8, Lu6;->Q:Lc11;

    .line 130
    .line 131
    invoke-static {v8, v1, v4}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    iget-object v10, v0, Lau5;->k:Lwu5;

    .line 135
    .line 136
    invoke-virtual {v10}, Lwu5;->d()Z

    .line 137
    .line 138
    .line 139
    move-result v4

    .line 140
    if-nez v4, :cond_4

    .line 141
    .line 142
    invoke-virtual {v10}, Lwu5;->a()Z

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    if-nez v4, :cond_4

    .line 147
    .line 148
    invoke-virtual {v10}, Lwu5;->c()Z

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-eqz v4, :cond_5

    .line 153
    .line 154
    invoke-virtual {v10}, Lwu5;->b()Luq5;

    .line 155
    .line 156
    .line 157
    move-result-object v4

    .line 158
    iget-object v4, v4, Luq5;->b:Ljava/util/List;

    .line 159
    .line 160
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 161
    .line 162
    .line 163
    move-result v4

    .line 164
    if-eqz v4, :cond_5

    .line 165
    .line 166
    invoke-virtual {v10}, Lwu5;->b()Luq5;

    .line 167
    .line 168
    .line 169
    move-result-object v4

    .line 170
    iget-object v4, v4, Luq5;->c:Ljava/util/List;

    .line 171
    .line 172
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 173
    .line 174
    .line 175
    move-result v4

    .line 176
    if-eqz v4, :cond_5

    .line 177
    .line 178
    :cond_4
    iget-boolean v4, v0, Lau5;->l:Z

    .line 179
    .line 180
    if-nez v4, :cond_5

    .line 181
    .line 182
    move v4, v6

    .line 183
    goto :goto_3

    .line 184
    :cond_5
    move v4, v5

    .line 185
    :goto_3
    iget-object v14, v0, Lau5;->m:Lou5;

    .line 186
    .line 187
    invoke-virtual {v1, v14}, Lib2;->g(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v8

    .line 191
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v9

    .line 195
    sget-object v11, Lg21;->a:Ley0;

    .line 196
    .line 197
    if-nez v8, :cond_6

    .line 198
    .line 199
    if-ne v9, v11, :cond_7

    .line 200
    .line 201
    :cond_6
    new-instance v9, Lst5;

    .line 202
    .line 203
    const/4 v8, 0x0

    .line 204
    invoke-direct {v9, v14, v8, v6}, Lst5;-><init>(Lou5;Lea1;B)V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v1, v9}, Lib2;->p0(Ljava/lang/Object;)V

    .line 208
    .line 209
    .line 210
    :cond_7
    check-cast v9, Lfa2;

    .line 211
    .line 212
    iget-object v8, v0, Lau5;->n:Lkn;

    .line 213
    .line 214
    iget-boolean v12, v8, Lkn;->b:Z

    .line 215
    .line 216
    if-nez v12, :cond_8

    .line 217
    .line 218
    iget-boolean v8, v8, Lkn;->a:Z

    .line 219
    .line 220
    if-eqz v8, :cond_8

    .line 221
    .line 222
    move v8, v6

    .line 223
    goto :goto_4

    .line 224
    :cond_8
    move v8, v5

    .line 225
    :goto_4
    invoke-static {v4, v9, v8, v1, v5}, Lg93;->a0(ZLfa2;ZLib2;I)Llf5;

    .line 226
    .line 227
    .line 228
    move-result-object v4

    .line 229
    iget-boolean v5, v4, Llf5;->a:Z

    .line 230
    .line 231
    if-eqz v3, :cond_9

    .line 232
    .line 233
    iget v8, v0, Lau5;->o:F

    .line 234
    .line 235
    goto :goto_5

    .line 236
    :cond_9
    invoke-interface {v7}, Lxt4;->d()F

    .line 237
    .line 238
    .line 239
    move-result v8

    .line 240
    :goto_5
    const/16 v9, 0xd

    .line 241
    .line 242
    const/4 v12, 0x0

    .line 243
    invoke-static {v12, v8, v12, v12, v9}, Lm71;->m(FFFFI)Lzt4;

    .line 244
    .line 245
    .line 246
    move-result-object v16

    .line 247
    invoke-virtual {v1, v4}, Lib2;->g(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v8

    .line 251
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v9

    .line 255
    if-nez v8, :cond_a

    .line 256
    .line 257
    if-ne v9, v11, :cond_b

    .line 258
    .line 259
    :cond_a
    new-instance v9, Ltk2;

    .line 260
    .line 261
    const/4 v8, 0x5

    .line 262
    invoke-direct {v9, v4, v8}, Ltk2;-><init>(Llf5;B)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v1, v9}, Lib2;->p0(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    :cond_b
    move-object/from16 v17, v9

    .line 269
    .line 270
    check-cast v17, Lu92;

    .line 271
    .line 272
    move-object/from16 v19, v1

    .line 273
    .line 274
    new-instance v1, Lcu5;

    .line 275
    .line 276
    move-object v4, v2

    .line 277
    iget-object v2, v0, Lau5;->r:Lk12;

    .line 278
    .line 279
    move-object v8, v4

    .line 280
    iget-object v4, v0, Lau5;->s:Lw04;

    .line 281
    .line 282
    move v9, v5

    .line 283
    iget v5, v0, Lau5;->t:F

    .line 284
    .line 285
    iget v6, v0, Lau5;->u:F

    .line 286
    .line 287
    move-object v12, v8

    .line 288
    iget v8, v0, Lau5;->v:F

    .line 289
    .line 290
    move v13, v9

    .line 291
    iget-object v9, v0, Lau5;->w:Lyd3;

    .line 292
    .line 293
    iget v11, v0, Lau5;->x:I

    .line 294
    .line 295
    move-object/from16 v18, v12

    .line 296
    .line 297
    iget-object v12, v0, Lau5;->y:Ltj0;

    .line 298
    .line 299
    move/from16 v20, v13

    .line 300
    .line 301
    iget-object v13, v0, Lau5;->z:Ljava/util/List;

    .line 302
    .line 303
    iget-object v15, v0, Lau5;->A:Ljava/util/List;

    .line 304
    .line 305
    move-object/from16 v0, v19

    .line 306
    .line 307
    invoke-direct/range {v1 .. v15}, Lcu5;-><init>(Lk12;ZLw04;FFLxt4;FLyd3;Lwu5;ILtj0;Ljava/util/List;Lou5;Ljava/util/List;)V

    .line 308
    .line 309
    .line 310
    const v2, 0x44f51872

    .line 311
    .line 312
    .line 313
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 314
    .line 315
    .line 316
    move-result-object v1

    .line 317
    move/from16 v13, v20

    .line 318
    .line 319
    const/16 v20, 0x1180

    .line 320
    .line 321
    move-object/from16 v2, p0

    .line 322
    .line 323
    iget-object v11, v2, Lau5;->p:Lrg5;

    .line 324
    .line 325
    move v8, v13

    .line 326
    const-wide/16 v13, 0x0

    .line 327
    .line 328
    const/4 v15, 0x0

    .line 329
    iget-object v2, v2, Lau5;->q:Ljava/util/List;

    .line 330
    .line 331
    move-object/from16 v9, v17

    .line 332
    .line 333
    const/16 v17, 0x0

    .line 334
    .line 335
    move-object/from16 v12, v16

    .line 336
    .line 337
    move-object/from16 v10, v18

    .line 338
    .line 339
    move-object/from16 v18, v1

    .line 340
    .line 341
    move-object/from16 v16, v2

    .line 342
    .line 343
    invoke-static/range {v8 .. v20}, Leg5;->a(ZLu92;Lw04;Lrg5;Lxt4;JFLjava/util/List;Lx17;Lyz0;Lib2;I)V

    .line 344
    .line 345
    .line 346
    const/4 v15, 0x1

    .line 347
    invoke-virtual {v0, v15}, Lib2;->r(Z)V

    .line 348
    .line 349
    .line 350
    goto :goto_6

    .line 351
    :cond_c
    move-object v0, v1

    .line 352
    invoke-virtual {v0}, Lib2;->a0()V

    .line 353
    .line 354
    .line 355
    :goto_6
    sget-object v0, Lxc7;->a:Lxc7;

    .line 356
    .line 357
    return-object v0
.end method
