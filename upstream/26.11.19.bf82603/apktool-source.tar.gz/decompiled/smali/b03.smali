.class public final Lb03;
.super Ldj2;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final n:[I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ldj2;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lb03;->n:[I

    .line 6
    .line 7
    return-void
.end method

.method public constructor <init>(ILdj2;Lqc7;[ILdj2;)V
    .locals 0

    .line 8
    invoke-direct {p0, p1, p2, p3, p5}, Ldj2;-><init>(ILdj2;Ljava/lang/Object;Ldj2;)V

    .line 9
    iput-object p4, p0, Lb03;->n:[I

    return-void
.end method
