.class public final Lae;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Loi5;


# direct methods
.method public constructor <init>(Loi5;)V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-object p1, p0, Lae;->a:Loi5;

    return-void
.end method

.method public constructor <init>(Loi5;Lae;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae;->a:Loi5;

    .line 5
    .line 6
    return-void
.end method

.method public static a(Law2;)Lkf3;
    .locals 1

    .line 1
    iget-object v0, p0, Law2;->c:Loq;

    .line 2
    .line 3
    iget-object p0, p0, Law2;->a:Landroid/content/Context;

    .line 4
    .line 5
    :goto_0
    instance-of v0, p0, Lhf3;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    check-cast p0, Lhf3;

    .line 10
    .line 11
    invoke-interface {p0}, Lhf3;->h()Lkf3;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :cond_0
    instance-of v0, p0, Landroid/content/ContextWrapper;

    .line 17
    .line 18
    if-nez v0, :cond_1

    .line 19
    .line 20
    const/4 p0, 0x0

    .line 21
    return-object p0

    .line 22
    :cond_1
    check-cast p0, Landroid/content/ContextWrapper;

    .line 23
    .line 24
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    goto :goto_0
.end method

.method public static c(Law2;Landroid/graphics/Bitmap$Config;)Z
    .locals 2

    .line 1
    sget-object v0, Landroid/graphics/Bitmap$Config;->HARDWARE:Landroid/graphics/Bitmap$Config;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne p1, v0, :cond_1

    .line 5
    .line 6
    sget-object p1, Ldw2;->g:Lj5;

    .line 7
    .line 8
    invoke-static {p0, p1}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Ljava/lang/Boolean;

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    if-nez p1, :cond_0

    .line 19
    .line 20
    const/4 p0, 0x0

    .line 21
    return p0

    .line 22
    :cond_0
    iget-object p0, p0, Law2;->c:Loq;

    .line 23
    .line 24
    :cond_1
    return v1
.end method


# virtual methods
.method public final b(Law2;Lbs3;Ltf6;Lu16;)Lcs3;
    .locals 16

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    iget-object v3, v0, Law2;->i:Lfi0;

    .line 8
    .line 9
    iget-object v4, v0, Law2;->n:Lk35;

    .line 10
    .line 11
    iget-boolean v3, v3, Lfi0;->i:Z

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    if-eqz v3, :cond_1d

    .line 15
    .line 16
    move-object/from16 v3, p0

    .line 17
    .line 18
    iget-object v3, v3, Lae;->a:Loi5;

    .line 19
    .line 20
    invoke-virtual {v3}, Loi5;->c()Lsi5;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    const/4 v6, 0x0

    .line 25
    if-eqz v3, :cond_8

    .line 26
    .line 27
    iget-object v7, v3, Lsi5;->c:Ljava/lang/Object;

    .line 28
    .line 29
    monitor-enter v7

    .line 30
    :try_start_0
    iget-object v8, v3, Lsi5;->a:Lxn3;

    .line 31
    .line 32
    iget-object v8, v8, Lxn3;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v8, Lxi5;

    .line 35
    .line 36
    iget-object v8, v8, Lxi5;->k:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v8, Ljava/util/LinkedHashMap;

    .line 39
    .line 40
    invoke-virtual {v8, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v8

    .line 44
    check-cast v8, Lwi5;

    .line 45
    .line 46
    if-eqz v8, :cond_0

    .line 47
    .line 48
    new-instance v9, Lcs3;

    .line 49
    .line 50
    iget-object v10, v8, Lwi5;->a:Lpv2;

    .line 51
    .line 52
    iget-object v8, v8, Lwi5;->b:Ljava/util/Map;

    .line 53
    .line 54
    invoke-direct {v9, v10, v8}, Lcs3;-><init>(Lpv2;Ljava/util/Map;)V

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_0
    move-object v9, v5

    .line 59
    :goto_0
    if-nez v9, :cond_5

    .line 60
    .line 61
    iget-object v8, v3, Lsi5;->b:Lr7;

    .line 62
    .line 63
    iget-object v9, v8, Lr7;->c:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v9, Ljava/util/LinkedHashMap;

    .line 66
    .line 67
    invoke-virtual {v9, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v9

    .line 71
    check-cast v9, Ljava/util/ArrayList;

    .line 72
    .line 73
    if-nez v9, :cond_1

    .line 74
    .line 75
    move-object v9, v5

    .line 76
    goto :goto_3

    .line 77
    :cond_1
    invoke-interface {v9}, Ljava/util/Collection;->size()I

    .line 78
    .line 79
    .line 80
    move-result v10

    .line 81
    move v11, v6

    .line 82
    :goto_1
    if-ge v11, v10, :cond_3

    .line 83
    .line 84
    invoke-interface {v9, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v12

    .line 88
    check-cast v12, Lzi5;

    .line 89
    .line 90
    iget-object v13, v12, Lzi5;->a:Ljava/lang/ref/WeakReference;

    .line 91
    .line 92
    invoke-virtual {v13}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v13

    .line 96
    check-cast v13, Lpv2;

    .line 97
    .line 98
    if-eqz v13, :cond_2

    .line 99
    .line 100
    new-instance v14, Lcs3;

    .line 101
    .line 102
    iget-object v12, v12, Lzi5;->b:Ljava/util/Map;

    .line 103
    .line 104
    invoke-direct {v14, v13, v12}, Lcs3;-><init>(Lpv2;Ljava/util/Map;)V

    .line 105
    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_2
    move-object v14, v5

    .line 109
    :goto_2
    if-nez v14, :cond_4

    .line 110
    .line 111
    add-int/lit8 v11, v11, 0x1

    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_3
    move-object v14, v5

    .line 115
    :cond_4
    invoke-virtual {v8}, Lr7;->d()V

    .line 116
    .line 117
    .line 118
    move-object v9, v14

    .line 119
    :cond_5
    :goto_3
    if-eqz v9, :cond_7

    .line 120
    .line 121
    iget-object v8, v9, Lcs3;->a:Lpv2;

    .line 122
    .line 123
    invoke-interface {v8}, Lpv2;->c()Z

    .line 124
    .line 125
    .line 126
    move-result v8

    .line 127
    if-nez v8, :cond_7

    .line 128
    .line 129
    iget-object v8, v3, Lsi5;->c:Ljava/lang/Object;

    .line 130
    .line 131
    monitor-enter v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 132
    :try_start_1
    iget-object v10, v3, Lsi5;->a:Lxn3;

    .line 133
    .line 134
    iget-object v10, v10, Lxn3;->c:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v10, Lxi5;

    .line 137
    .line 138
    iget-object v11, v10, Lxi5;->k:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v11, Ljava/util/LinkedHashMap;

    .line 141
    .line 142
    invoke-interface {v11, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v11

    .line 146
    if-eqz v11, :cond_6

    .line 147
    .line 148
    invoke-virtual {v10}, Lxi5;->d()J

    .line 149
    .line 150
    .line 151
    move-result-wide v12

    .line 152
    invoke-virtual {v10, v1, v11}, Lxi5;->h(Ljava/lang/Object;Ljava/lang/Object;)J

    .line 153
    .line 154
    .line 155
    move-result-wide v14

    .line 156
    sub-long/2addr v12, v14

    .line 157
    iput-wide v12, v10, Lxi5;->j:J

    .line 158
    .line 159
    invoke-virtual {v10, v1, v11, v5}, Lxi5;->b(Ljava/lang/Object;Ljava/lang/Object;Lwi5;)V

    .line 160
    .line 161
    .line 162
    :cond_6
    iget-object v3, v3, Lsi5;->b:Lr7;

    .line 163
    .line 164
    iget-object v3, v3, Lr7;->c:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast v3, Ljava/util/LinkedHashMap;

    .line 167
    .line 168
    invoke-virtual {v3, v1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 169
    .line 170
    .line 171
    :try_start_2
    monitor-exit v8

    .line 172
    goto :goto_4

    .line 173
    :catchall_0
    move-exception v0

    .line 174
    monitor-exit v8

    .line 175
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 176
    :cond_7
    :goto_4
    monitor-exit v7

    .line 177
    goto :goto_5

    .line 178
    :catchall_1
    move-exception v0

    .line 179
    monitor-exit v7

    .line 180
    throw v0

    .line 181
    :cond_8
    move-object v9, v5

    .line 182
    :goto_5
    if-eqz v9, :cond_1d

    .line 183
    .line 184
    iget-object v3, v9, Lcs3;->a:Lpv2;

    .line 185
    .line 186
    instance-of v7, v3, Ld30;

    .line 187
    .line 188
    if-eqz v7, :cond_9

    .line 189
    .line 190
    move-object v8, v3

    .line 191
    check-cast v8, Ld30;

    .line 192
    .line 193
    goto :goto_6

    .line 194
    :cond_9
    move-object v8, v5

    .line 195
    :goto_6
    if-nez v8, :cond_a

    .line 196
    .line 197
    const/4 v8, 0x1

    .line 198
    goto :goto_7

    .line 199
    :cond_a
    iget-object v8, v8, Ld30;->a:Landroid/graphics/Bitmap;

    .line 200
    .line 201
    invoke-virtual {v8}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 202
    .line 203
    .line 204
    move-result-object v8

    .line 205
    if-nez v8, :cond_b

    .line 206
    .line 207
    sget-object v8, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 208
    .line 209
    :cond_b
    invoke-static {v0, v8}, Lae;->c(Law2;Landroid/graphics/Bitmap$Config;)Z

    .line 210
    .line 211
    .line 212
    move-result v8

    .line 213
    :goto_7
    if-eqz v8, :cond_1d

    .line 214
    .line 215
    iget-object v1, v1, Lbs3;->b:Ljava/util/Map;

    .line 216
    .line 217
    const-string v8, "coil#size"

    .line 218
    .line 219
    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    check-cast v1, Ljava/lang/String;

    .line 224
    .line 225
    if-eqz v1, :cond_c

    .line 226
    .line 227
    invoke-virtual {v2}, Ltf6;->toString()Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    if-eqz v0, :cond_1d

    .line 236
    .line 237
    goto/16 :goto_13

    .line 238
    .line 239
    :cond_c
    iget-object v1, v9, Lcs3;->b:Ljava/util/Map;

    .line 240
    .line 241
    const-string v8, "coil#is_sampled"

    .line 242
    .line 243
    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    instance-of v8, v1, Ljava/lang/Boolean;

    .line 248
    .line 249
    if-eqz v8, :cond_d

    .line 250
    .line 251
    check-cast v1, Ljava/lang/Boolean;

    .line 252
    .line 253
    goto :goto_8

    .line 254
    :cond_d
    move-object v1, v5

    .line 255
    :goto_8
    if-eqz v1, :cond_e

    .line 256
    .line 257
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 258
    .line 259
    .line 260
    move-result v6

    .line 261
    :cond_e
    if-nez v6, :cond_f

    .line 262
    .line 263
    sget-object v1, Ltf6;->c:Ltf6;

    .line 264
    .line 265
    invoke-static {v2, v1}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 266
    .line 267
    .line 268
    move-result v1

    .line 269
    if-nez v1, :cond_1c

    .line 270
    .line 271
    sget-object v1, Lk35;->j:Lk35;

    .line 272
    .line 273
    if-eq v4, v1, :cond_1c

    .line 274
    .line 275
    :cond_f
    invoke-interface {v3}, Lpv2;->b()I

    .line 276
    .line 277
    .line 278
    move-result v1

    .line 279
    invoke-interface {v3}, Lpv2;->a()I

    .line 280
    .line 281
    .line 282
    move-result v3

    .line 283
    if-eqz v7, :cond_10

    .line 284
    .line 285
    sget-object v6, Lcw2;->b:Lj5;

    .line 286
    .line 287
    invoke-static {v0, v6}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    check-cast v0, Ltf6;

    .line 292
    .line 293
    goto :goto_9

    .line 294
    :cond_10
    sget-object v0, Ltf6;->c:Ltf6;

    .line 295
    .line 296
    :goto_9
    iget-object v6, v2, Ltf6;->a:Lfn1;

    .line 297
    .line 298
    instance-of v7, v6, Ldn1;

    .line 299
    .line 300
    const v8, 0x7fffffff

    .line 301
    .line 302
    .line 303
    if-eqz v7, :cond_11

    .line 304
    .line 305
    check-cast v6, Ldn1;

    .line 306
    .line 307
    iget v6, v6, Ldn1;->a:I

    .line 308
    .line 309
    goto :goto_a

    .line 310
    :cond_11
    move v6, v8

    .line 311
    :goto_a
    iget-object v7, v0, Ltf6;->a:Lfn1;

    .line 312
    .line 313
    instance-of v11, v7, Ldn1;

    .line 314
    .line 315
    if-eqz v11, :cond_12

    .line 316
    .line 317
    check-cast v7, Ldn1;

    .line 318
    .line 319
    iget v7, v7, Ldn1;->a:I

    .line 320
    .line 321
    goto :goto_b

    .line 322
    :cond_12
    move v7, v8

    .line 323
    :goto_b
    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    .line 324
    .line 325
    .line 326
    move-result v6

    .line 327
    iget-object v2, v2, Ltf6;->b:Lfn1;

    .line 328
    .line 329
    instance-of v7, v2, Ldn1;

    .line 330
    .line 331
    if-eqz v7, :cond_13

    .line 332
    .line 333
    check-cast v2, Ldn1;

    .line 334
    .line 335
    iget v2, v2, Ldn1;->a:I

    .line 336
    .line 337
    goto :goto_c

    .line 338
    :cond_13
    move v2, v8

    .line 339
    :goto_c
    iget-object v0, v0, Ltf6;->b:Lfn1;

    .line 340
    .line 341
    instance-of v7, v0, Ldn1;

    .line 342
    .line 343
    if-eqz v7, :cond_14

    .line 344
    .line 345
    check-cast v0, Ldn1;

    .line 346
    .line 347
    iget v0, v0, Ldn1;->a:I

    .line 348
    .line 349
    goto :goto_d

    .line 350
    :cond_14
    move v0, v8

    .line 351
    :goto_d
    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    int-to-double v11, v6

    .line 356
    int-to-double v13, v1

    .line 357
    div-double/2addr v11, v13

    .line 358
    int-to-double v13, v0

    .line 359
    move-wide/from16 p1, v11

    .line 360
    .line 361
    int-to-double v10, v3

    .line 362
    div-double/2addr v13, v10

    .line 363
    if-eq v6, v8, :cond_15

    .line 364
    .line 365
    if-eq v0, v8, :cond_15

    .line 366
    .line 367
    move-object/from16 v2, p4

    .line 368
    .line 369
    goto :goto_e

    .line 370
    :cond_15
    sget-object v2, Lu16;->j:Lu16;

    .line 371
    .line 372
    :goto_e
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 373
    .line 374
    .line 375
    move-result v2

    .line 376
    if-eqz v2, :cond_18

    .line 377
    .line 378
    const/4 v7, 0x1

    .line 379
    if-ne v2, v7, :cond_17

    .line 380
    .line 381
    cmpg-double v2, p1, v13

    .line 382
    .line 383
    if-gez v2, :cond_16

    .line 384
    .line 385
    sub-int/2addr v6, v1

    .line 386
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 387
    .line 388
    .line 389
    move-result v0

    .line 390
    :goto_f
    move-wide/from16 v11, p1

    .line 391
    .line 392
    :goto_10
    const/4 v7, 0x1

    .line 393
    goto :goto_12

    .line 394
    :cond_16
    sub-int/2addr v0, v3

    .line 395
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 396
    .line 397
    .line 398
    move-result v0

    .line 399
    :goto_11
    move-wide v11, v13

    .line 400
    goto :goto_10

    .line 401
    :cond_17
    invoke-static {}, Lw91;->a()V

    .line 402
    .line 403
    .line 404
    return-object v5

    .line 405
    :cond_18
    cmpl-double v2, p1, v13

    .line 406
    .line 407
    if-lez v2, :cond_19

    .line 408
    .line 409
    sub-int/2addr v6, v1

    .line 410
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    goto :goto_f

    .line 415
    :cond_19
    sub-int/2addr v0, v3

    .line 416
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 417
    .line 418
    .line 419
    move-result v0

    .line 420
    goto :goto_11

    .line 421
    :goto_12
    if-le v0, v7, :cond_1c

    .line 422
    .line 423
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 424
    .line 425
    .line 426
    move-result v0

    .line 427
    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    .line 428
    .line 429
    if-eqz v0, :cond_1b

    .line 430
    .line 431
    if-ne v0, v7, :cond_1a

    .line 432
    .line 433
    cmpg-double v0, v11, v1

    .line 434
    .line 435
    if-gtz v0, :cond_1d

    .line 436
    .line 437
    goto :goto_13

    .line 438
    :cond_1a
    invoke-static {}, Lw91;->a()V

    .line 439
    .line 440
    .line 441
    return-object v5

    .line 442
    :cond_1b
    cmpg-double v0, v11, v1

    .line 443
    .line 444
    if-nez v0, :cond_1d

    .line 445
    .line 446
    :cond_1c
    :goto_13
    return-object v9

    .line 447
    :cond_1d
    return-object v5
.end method

.method public final d(Law2;Ljava/lang/Object;Ldp4;Lpy1;)Lbs3;
    .locals 7

    .line 1
    iget-object p4, p1, Law2;->i:Lfi0;

    .line 2
    .line 3
    iget-object v0, p1, Law2;->d:Ljava/util/Map;

    .line 4
    .line 5
    sget-object v1, Lfi0;->l:Lfi0;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eq p4, v1, :cond_6

    .line 9
    .line 10
    iget-object p0, p0, Lae;->a:Loi5;

    .line 11
    .line 12
    iget-object p0, p0, Loi5;->d:Lvz0;

    .line 13
    .line 14
    iget-object p0, p0, Lvz0;->c:Ljava/util/List;

    .line 15
    .line 16
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 17
    .line 18
    .line 19
    move-result p4

    .line 20
    const/4 v1, 0x0

    .line 21
    :goto_0
    if-ge v1, p4, :cond_4

    .line 22
    .line 23
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    check-cast v3, Lnw4;

    .line 28
    .line 29
    iget-object v4, v3, Lnw4;->i:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v4, Lbe;

    .line 32
    .line 33
    iget-object v3, v3, Lnw4;->j:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v3, Lgr0;

    .line 36
    .line 37
    invoke-virtual {v3, p2}, Lgr0;->d(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_3

    .line 42
    .line 43
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    iget-byte v3, v4, Lbe;->a:B

    .line 47
    .line 48
    packed-switch v3, :pswitch_data_0

    .line 49
    .line 50
    .line 51
    move-object v3, p2

    .line 52
    check-cast v3, Lpd7;

    .line 53
    .line 54
    iget-object v3, v3, Lpd7;->a:Ljava/lang/String;

    .line 55
    .line 56
    goto/16 :goto_1

    .line 57
    .line 58
    :pswitch_0
    move-object v3, p2

    .line 59
    check-cast v3, Lpd7;

    .line 60
    .line 61
    iget-object v4, v3, Lpd7;->c:Ljava/lang/String;

    .line 62
    .line 63
    const-string v5, "file"

    .line 64
    .line 65
    if-eqz v4, :cond_0

    .line 66
    .line 67
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-eqz v4, :cond_2

    .line 72
    .line 73
    :cond_0
    iget-object v4, v3, Lpd7;->e:Ljava/lang/String;

    .line 74
    .line 75
    if-eqz v4, :cond_2

    .line 76
    .line 77
    sget-object v4, Lyd7;->a:[Landroid/graphics/Bitmap$Config;

    .line 78
    .line 79
    iget-object v4, v3, Lpd7;->c:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v4

    .line 85
    if-eqz v4, :cond_1

    .line 86
    .line 87
    invoke-static {v3}, Liu6;->m(Lpd7;)Ljava/util/List;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    invoke-static {v4}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    const-string v5, "android_asset"

    .line 96
    .line 97
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    if-nez v4, :cond_2

    .line 102
    .line 103
    :cond_1
    sget-object v4, Lcw2;->c:Lj5;

    .line 104
    .line 105
    invoke-static {p3, v4}, Lmm;->P(Ldp4;Lj5;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    check-cast v4, Ljava/lang/Boolean;

    .line 110
    .line 111
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    if-eqz v4, :cond_2

    .line 116
    .line 117
    invoke-static {v3}, Liu6;->k(Lpd7;)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    if-eqz v4, :cond_2

    .line 122
    .line 123
    iget-object v5, p3, Ldp4;->e:Lo22;

    .line 124
    .line 125
    sget-object v6, Lxx4;->j:Ljava/lang/String;

    .line 126
    .line 127
    invoke-static {v4}, Lie3;->u(Ljava/lang/String;)Lxx4;

    .line 128
    .line 129
    .line 130
    move-result-object v4

    .line 131
    invoke-virtual {v5, v4}, Lo22;->j(Lxx4;)Lj22;

    .line 132
    .line 133
    .line 134
    move-result-object v4

    .line 135
    iget-object v4, v4, Lj22;->g:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v4, Ljava/lang/Long;

    .line 138
    .line 139
    new-instance v5, Ljava/lang/StringBuilder;

    .line 140
    .line 141
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 145
    .line 146
    .line 147
    const-string v3, "-"

    .line 148
    .line 149
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    goto :goto_1

    .line 160
    :pswitch_1
    move-object v3, p2

    .line 161
    check-cast v3, Lpd7;

    .line 162
    .line 163
    iget-object v4, v3, Lpd7;->c:Ljava/lang/String;

    .line 164
    .line 165
    const-string v5, "android.resource"

    .line 166
    .line 167
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v4

    .line 171
    if-eqz v4, :cond_2

    .line 172
    .line 173
    iget-object v4, p3, Ldp4;->a:Landroid/content/Context;

    .line 174
    .line 175
    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 176
    .line 177
    .line 178
    move-result-object v4

    .line 179
    invoke-virtual {v4}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 180
    .line 181
    .line 182
    move-result-object v4

    .line 183
    sget-object v5, Lyd7;->a:[Landroid/graphics/Bitmap$Config;

    .line 184
    .line 185
    iget v4, v4, Landroid/content/res/Configuration;->uiMode:I

    .line 186
    .line 187
    and-int/lit8 v4, v4, 0x30

    .line 188
    .line 189
    new-instance v5, Ljava/lang/StringBuilder;

    .line 190
    .line 191
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 195
    .line 196
    .line 197
    const-string v3, ":"

    .line 198
    .line 199
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v3

    .line 209
    goto :goto_1

    .line 210
    :cond_2
    move-object v3, v2

    .line 211
    :goto_1
    if-nez v3, :cond_5

    .line 212
    .line 213
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 214
    .line 215
    goto/16 :goto_0

    .line 216
    .line 217
    :cond_4
    move-object v3, v2

    .line 218
    :cond_5
    if-nez v3, :cond_7

    .line 219
    .line 220
    :cond_6
    return-object v2

    .line 221
    :cond_7
    sget-object p0, Lcw2;->a:Lj5;

    .line 222
    .line 223
    invoke-static {p1, p0}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object p0

    .line 227
    check-cast p0, Ljava/util/List;

    .line 228
    .line 229
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 230
    .line 231
    .line 232
    move-result p0

    .line 233
    if-nez p0, :cond_8

    .line 234
    .line 235
    new-instance p0, Ljava/util/LinkedHashMap;

    .line 236
    .line 237
    invoke-direct {p0, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    .line 238
    .line 239
    .line 240
    iget-object p1, p3, Ldp4;->b:Ltf6;

    .line 241
    .line 242
    invoke-virtual {p1}, Ltf6;->toString()Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    const-string p2, "coil#size"

    .line 247
    .line 248
    invoke-interface {p0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    new-instance p1, Lbs3;

    .line 252
    .line 253
    invoke-direct {p1, v3, p0}, Lbs3;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    .line 254
    .line 255
    .line 256
    return-object p1

    .line 257
    :cond_8
    new-instance p0, Lbs3;

    .line 258
    .line 259
    invoke-direct {p0, v3, v0}, Lbs3;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    .line 260
    .line 261
    .line 262
    return-object p0

    .line 263
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final e(Law2;Ltf6;)Ldp4;
    .locals 18

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v1, Ldp4;

    .line 4
    .line 5
    move-object v2, v1

    .line 6
    iget-object v1, v0, Law2;->a:Landroid/content/Context;

    .line 7
    .line 8
    iget-object v3, v0, Law2;->m:Lu16;

    .line 9
    .line 10
    iget-object v4, v0, Law2;->n:Lk35;

    .line 11
    .line 12
    iget-object v5, v0, Law2;->e:Lo22;

    .line 13
    .line 14
    iget-object v6, v0, Law2;->i:Lfi0;

    .line 15
    .line 16
    iget-object v7, v0, Law2;->j:Lfi0;

    .line 17
    .line 18
    iget-object v8, v0, Law2;->k:Lfi0;

    .line 19
    .line 20
    sget-object v9, Ldw2;->b:Lj5;

    .line 21
    .line 22
    invoke-static {v0, v9}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v10

    .line 26
    check-cast v10, Landroid/graphics/Bitmap$Config;

    .line 27
    .line 28
    sget-object v11, Ldw2;->h:Lj5;

    .line 29
    .line 30
    invoke-static {v0, v11}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v12

    .line 34
    check-cast v12, Ljava/lang/Boolean;

    .line 35
    .line 36
    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    .line 37
    .line 38
    .line 39
    move-result v12

    .line 40
    sget-object v13, Lcw2;->a:Lj5;

    .line 41
    .line 42
    invoke-static {v0, v13}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v14

    .line 46
    check-cast v14, Ljava/util/List;

    .line 47
    .line 48
    invoke-interface {v14}, Ljava/util/List;->isEmpty()Z

    .line 49
    .line 50
    .line 51
    move-result v14

    .line 52
    const/16 v16, 0x0

    .line 53
    .line 54
    if-nez v14, :cond_0

    .line 55
    .line 56
    sget-object v14, Lyd7;->a:[Landroid/graphics/Bitmap$Config;

    .line 57
    .line 58
    invoke-static {v0, v9}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v17

    .line 62
    move-object/from16 v15, v17

    .line 63
    .line 64
    check-cast v15, Landroid/graphics/Bitmap$Config;

    .line 65
    .line 66
    invoke-static {v14, v15}, Low;->P([Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v14

    .line 70
    if-nez v14, :cond_0

    .line 71
    .line 72
    move/from16 v14, v16

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_0
    const/4 v14, 0x1

    .line 76
    :goto_0
    invoke-static {v0, v9}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v15

    .line 80
    check-cast v15, Landroid/graphics/Bitmap$Config;

    .line 81
    .line 82
    move-object/from16 v17, v1

    .line 83
    .line 84
    sget-object v1, Landroid/graphics/Bitmap$Config;->HARDWARE:Landroid/graphics/Bitmap$Config;

    .line 85
    .line 86
    if-ne v15, v1, :cond_1

    .line 87
    .line 88
    invoke-static {v0, v9}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    check-cast v1, Landroid/graphics/Bitmap$Config;

    .line 93
    .line 94
    invoke-static {v0, v1}, Lae;->c(Law2;Landroid/graphics/Bitmap$Config;)Z

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    if-nez v1, :cond_1

    .line 99
    .line 100
    move/from16 v1, v16

    .line 101
    .line 102
    goto :goto_1

    .line 103
    :cond_1
    const/4 v1, 0x1

    .line 104
    :goto_1
    if-eqz v14, :cond_2

    .line 105
    .line 106
    if-nez v1, :cond_3

    .line 107
    .line 108
    :cond_2
    sget-object v10, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 109
    .line 110
    :cond_3
    if-eqz v12, :cond_4

    .line 111
    .line 112
    invoke-static {v0, v13}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    check-cast v1, Ljava/util/List;

    .line 117
    .line 118
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-eqz v1, :cond_4

    .line 123
    .line 124
    sget-object v1, Landroid/graphics/Bitmap$Config;->ALPHA_8:Landroid/graphics/Bitmap$Config;

    .line 125
    .line 126
    if-eq v10, v1, :cond_4

    .line 127
    .line 128
    const/4 v15, 0x1

    .line 129
    goto :goto_2

    .line 130
    :cond_4
    move/from16 v15, v16

    .line 131
    .line 132
    :goto_2
    iget-object v1, v0, Law2;->q:Lyv2;

    .line 133
    .line 134
    iget-object v1, v1, Lyv2;->e:Lr12;

    .line 135
    .line 136
    iget-object v1, v1, Lr12;->a:Ljava/util/Map;

    .line 137
    .line 138
    iget-object v12, v0, Law2;->o:Lr12;

    .line 139
    .line 140
    iget-object v12, v12, Lr12;->a:Ljava/util/Map;

    .line 141
    .line 142
    invoke-static {v1, v12}, Lep3;->V(Ljava/util/Map;Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    new-instance v12, Ljava/util/LinkedHashMap;

    .line 147
    .line 148
    invoke-direct {v12, v1}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    .line 149
    .line 150
    .line 151
    invoke-static {v0, v9}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    check-cast v1, Landroid/graphics/Bitmap$Config;

    .line 156
    .line 157
    if-eq v10, v1, :cond_6

    .line 158
    .line 159
    if-eqz v10, :cond_5

    .line 160
    .line 161
    invoke-interface {v12, v9, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    goto :goto_3

    .line 165
    :cond_5
    invoke-interface {v12, v9}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    :cond_6
    :goto_3
    invoke-static {v0, v11}, Lmm;->O(Law2;Lj5;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    check-cast v0, Ljava/lang/Boolean;

    .line 173
    .line 174
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    if-eq v15, v0, :cond_7

    .line 179
    .line 180
    invoke-static {v15}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    invoke-interface {v12, v11, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    :cond_7
    new-instance v9, Lr12;

    .line 188
    .line 189
    invoke-static {v12}, Ljn;->d0(Ljava/util/Map;)Ljava/util/Map;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    invoke-direct {v9, v0}, Lr12;-><init>(Ljava/util/Map;)V

    .line 194
    .line 195
    .line 196
    move-object v0, v2

    .line 197
    move-object/from16 v1, v17

    .line 198
    .line 199
    move-object/from16 v2, p2

    .line 200
    .line 201
    invoke-direct/range {v0 .. v9}, Ldp4;-><init>(Landroid/content/Context;Ltf6;Lu16;Lk35;Lo22;Lfi0;Lfi0;Lfi0;Lr12;)V

    .line 202
    .line 203
    .line 204
    return-object v0
.end method
