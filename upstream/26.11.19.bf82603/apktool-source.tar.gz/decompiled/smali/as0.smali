.class public interface abstract Las0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# virtual methods
.method public abstract b()Ljava/lang/Comparable;
.end method

.method public abstract c()Ljava/lang/Comparable;
.end method

.method public abstract isEmpty()Z
.end method
