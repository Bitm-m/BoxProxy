.class public final La64;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public i:Z

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ll64;

.field public final synthetic l:Lo64;

.field public final synthetic m:F

.field public final synthetic n:F


# direct methods
.method public constructor <init>(Ll64;Lo64;FFLea1;)V
    .locals 0

    .line 1
    iput-object p1, p0, La64;->k:Ll64;

    .line 2
    .line 3
    iput-object p2, p0, La64;->l:Lo64;

    .line 4
    .line 5
    iput p3, p0, La64;->m:F

    .line 6
    .line 7
    iput p4, p0, La64;->n:F

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p5}, Lvr6;-><init>(ILea1;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 6

    .line 1
    new-instance v0, La64;

    .line 2
    .line 3
    iget v3, p0, La64;->m:F

    .line 4
    .line 5
    iget v4, p0, La64;->n:F

    .line 6
    .line 7
    iget-object v1, p0, La64;->k:Ll64;

    .line 8
    .line 9
    iget-object v2, p0, La64;->l:Lo64;

    .line 10
    .line 11
    move-object v5, p2

    .line 12
    invoke-direct/range {v0 .. v5}, La64;-><init>(Ll64;Lo64;FFLea1;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, v0, La64;->j:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lu92;

    .line 2
    .line 3
    check-cast p2, Lea1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La64;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, La64;

    .line 10
    .line 11
    sget-object p1, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, La64;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget-object v0, p0, La64;->j:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v5, v0

    .line 4
    check-cast v5, Lu92;

    .line 5
    .line 6
    iget-boolean v0, p0, La64;->i:Z

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    if-ne v0, v2, :cond_0

    .line 13
    .line 14
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-static {p0}, La02;->d(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-object v1

    .line 24
    :cond_1
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, La64;->k:Ll64;

    .line 28
    .line 29
    iget-object v0, p1, Ll64;->a:Lw64;

    .line 30
    .line 31
    iget-object v0, p0, La64;->l:Lo64;

    .line 32
    .line 33
    iget-object v3, v0, Lo64;->a:Lmg;

    .line 34
    .line 35
    invoke-virtual {v3}, Lmg;->e()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    check-cast v3, Ljava/lang/Number;

    .line 40
    .line 41
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    iget v4, p0, La64;->m:F

    .line 46
    .line 47
    sub-float/2addr v3, v4

    .line 48
    const/4 v4, 0x0

    .line 49
    cmpg-float v6, v3, v4

    .line 50
    .line 51
    if-lez v6, :cond_2

    .line 52
    .line 53
    const v4, -0x3ebeabd8

    .line 54
    .line 55
    .line 56
    mul-float/2addr v4, v3

    .line 57
    :cond_2
    iget-object v0, v0, Lo64;->a:Lmg;

    .line 58
    .line 59
    iget-object v3, p1, Ll64;->a:Lw64;

    .line 60
    .line 61
    iget p1, p0, La64;->n:F

    .line 62
    .line 63
    cmpg-float v6, p1, v4

    .line 64
    .line 65
    if-ltz v6, :cond_3

    .line 66
    .line 67
    move v4, p1

    .line 68
    :cond_3
    iput-object v1, p0, La64;->j:Ljava/lang/Object;

    .line 69
    .line 70
    iput-boolean v2, p0, La64;->i:Z

    .line 71
    .line 72
    iget v2, p0, La64;->m:F

    .line 73
    .line 74
    move-object v6, p0

    .line 75
    move-object v1, v0

    .line 76
    invoke-static/range {v1 .. v6}, Lra3;->T(Lmg;FLw64;FLu92;Lfa1;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    sget-object p1, Lof1;->i:Lof1;

    .line 81
    .line 82
    if-ne p0, p1, :cond_4

    .line 83
    .line 84
    return-object p1

    .line 85
    :cond_4
    :goto_0
    sget-object p0, Lxc7;->a:Lxc7;

    .line 86
    .line 87
    return-object p0
.end method
