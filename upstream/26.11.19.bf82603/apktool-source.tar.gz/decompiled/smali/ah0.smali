.class public final synthetic Lah0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lfa2;

.field public final synthetic k:Lqu1;

.field public final synthetic l:Lj44;


# direct methods
.method public synthetic constructor <init>(Lfa2;Lqu1;Lj44;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lah0;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lah0;->j:Lfa2;

    .line 4
    .line 5
    iput-object p2, p0, Lah0;->k:Lqu1;

    .line 6
    .line 7
    iput-object p3, p0, Lah0;->l:Lj44;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-byte v0, p0, Lah0;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    iget-object v2, p0, Lah0;->l:Lj44;

    .line 6
    .line 7
    iget-object v3, p0, Lah0;->k:Lqu1;

    .line 8
    .line 9
    iget-object p0, p0, Lah0;->j:Lfa2;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    invoke-interface {v2}, Lnl6;->getValue()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Ljava/util/List;

    .line 19
    .line 20
    iget-wide v2, v3, Lqu1;->a:J

    .line 21
    .line 22
    invoke-static {v0, v2, v3}, Lef4;->d(Ljava/util/List;J)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-interface {p0, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    return-object v1

    .line 30
    :pswitch_0
    invoke-interface {v2}, Lnl6;->getValue()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Ljava/util/List;

    .line 35
    .line 36
    iget-wide v2, v3, Lqu1;->a:J

    .line 37
    .line 38
    invoke-static {v0, v2, v3}, Lef4;->d(Ljava/util/List;J)Ljava/util/List;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-interface {p0, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    return-object v1

    .line 46
    :pswitch_1
    invoke-interface {v2}, Lnl6;->getValue()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Ljava/util/List;

    .line 51
    .line 52
    iget-wide v2, v3, Lqu1;->a:J

    .line 53
    .line 54
    invoke-static {v0, v2, v3}, Lef4;->d(Ljava/util/List;J)Ljava/util/List;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-interface {p0, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    return-object v1

    .line 62
    :pswitch_2
    invoke-interface {v2}, Lnl6;->getValue()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    check-cast v0, Ljava/util/List;

    .line 67
    .line 68
    iget-wide v2, v3, Lqu1;->a:J

    .line 69
    .line 70
    invoke-static {v0, v2, v3}, Lef4;->d(Ljava/util/List;J)Ljava/util/List;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-interface {p0, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    return-object v1

    .line 78
    nop

    .line 79
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
