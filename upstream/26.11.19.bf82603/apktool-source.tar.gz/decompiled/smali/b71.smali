.class public final synthetic Lb71;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lfa2;

.field public final synthetic k:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lfa2;Ljava/util/List;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lb71;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lb71;->j:Lfa2;

    .line 4
    .line 5
    iput-object p2, p0, Lb71;->k:Ljava/util/List;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lb71;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    iget-object v2, p0, Lb71;->k:Ljava/util/List;

    .line 6
    .line 7
    iget-object p0, p0, Lb71;->j:Lfa2;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-interface {p0, v2}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    return-object v1

    .line 16
    :pswitch_0
    invoke-interface {p0, v2}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    return-object v1

    .line 20
    nop

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
