.class public abstract La05;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lnt1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Leg4;

    .line 2
    .line 3
    const/16 v1, 0x18

    .line 4
    .line 5
    invoke-direct {v0, v1}, Leg4;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lnt1;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-direct {v1, v0, v2}, Lnt1;-><init>(Lu92;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, La05;->a:Lnt1;

    .line 15
    .line 16
    return-void
.end method
