.class public final synthetic Lag5;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Lrg5;

.field public final synthetic j:F

.field public final synthetic k:J

.field public final synthetic l:Lw04;

.field public final synthetic m:I


# direct methods
.method public synthetic constructor <init>(Lrg5;FJLw04;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lag5;->i:Lrg5;

    .line 5
    .line 6
    iput p2, p0, Lag5;->j:F

    .line 7
    .line 8
    iput-wide p3, p0, Lag5;->k:J

    .line 9
    .line 10
    iput-object p5, p0, Lag5;->l:Lw04;

    .line 11
    .line 12
    iput p6, p0, Lag5;->m:I

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, Lib2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lag5;->m:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lcc3;->X(I)I

    .line 14
    .line 15
    .line 16
    move-result v6

    .line 17
    iget-object v0, p0, Lag5;->i:Lrg5;

    .line 18
    .line 19
    iget v1, p0, Lag5;->j:F

    .line 20
    .line 21
    iget-wide v2, p0, Lag5;->k:J

    .line 22
    .line 23
    iget-object v4, p0, Lag5;->l:Lw04;

    .line 24
    .line 25
    invoke-static/range {v0 .. v6}, Leg5;->c(Lrg5;FJLw04;Lib2;I)V

    .line 26
    .line 27
    .line 28
    sget-object p0, Lxc7;->a:Lxc7;

    .line 29
    .line 30
    return-object p0
.end method
