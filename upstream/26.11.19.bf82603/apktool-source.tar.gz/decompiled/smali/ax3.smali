.class public final synthetic Lax3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lfa2;Ljava/util/List;Lxw3;ZLfa2;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lax3;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lax3;->k:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lax3;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lax3;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lax3;->o:Ljava/lang/Object;

    .line 14
    .line 15
    iput-boolean p5, p0, Lax3;->j:Z

    .line 16
    .line 17
    iput-object p6, p0, Lax3;->n:Ljava/lang/Object;

    .line 18
    .line 19
    return-void
.end method

.method public synthetic constructor <init>(ZLx26;Lx26;La02;Lik6;Lik6;)V
    .locals 1

    .line 20
    const/4 v0, 0x1

    iput-byte v0, p0, Lax3;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lax3;->j:Z

    iput-object p2, p0, Lax3;->k:Ljava/lang/Object;

    iput-object p3, p0, Lax3;->l:Ljava/lang/Object;

    iput-object p4, p0, Lax3;->m:Ljava/lang/Object;

    iput-object p5, p0, Lax3;->n:Ljava/lang/Object;

    iput-object p6, p0, Lax3;->o:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 15

    .line 1
    iget-byte v0, p0, Lax3;->i:B

    .line 2
    .line 3
    iget-object v1, p0, Lax3;->o:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lax3;->n:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, Lax3;->m:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, Lax3;->l:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v5, p0, Lax3;->k:Ljava/lang/Object;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    move-object v8, v5

    .line 17
    check-cast v8, Lx26;

    .line 18
    .line 19
    move-object v9, v4

    .line 20
    check-cast v9, Lx26;

    .line 21
    .line 22
    move-object v10, v3

    .line 23
    check-cast v10, La02;

    .line 24
    .line 25
    move-object v11, v2

    .line 26
    check-cast v11, Lik6;

    .line 27
    .line 28
    move-object v12, v1

    .line 29
    check-cast v12, Lik6;

    .line 30
    .line 31
    new-instance v6, Lqf7;

    .line 32
    .line 33
    const/4 v13, 0x0

    .line 34
    const/4 v14, 0x0

    .line 35
    iget-boolean v7, p0, Lax3;->j:Z

    .line 36
    .line 37
    invoke-direct/range {v6 .. v14}, Lqf7;-><init>(ZLx26;Lx26;La02;Lci;Lci;FZ)V

    .line 38
    .line 39
    .line 40
    return-object v6

    .line 41
    :pswitch_0
    check-cast v5, Ljava/util/List;

    .line 42
    .line 43
    check-cast v3, Lfa2;

    .line 44
    .line 45
    check-cast v4, Ljava/util/List;

    .line 46
    .line 47
    check-cast v1, Lxw3;

    .line 48
    .line 49
    check-cast v2, Lfa2;

    .line 50
    .line 51
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_0

    .line 56
    .line 57
    invoke-interface {v3, v4}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    :cond_0
    invoke-virtual {v1, v4, v3}, Lxw3;->a(Ljava/util/List;Lfa2;)I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    iget-boolean p0, p0, Lax3;->j:Z

    .line 65
    .line 66
    if-eqz p0, :cond_1

    .line 67
    .line 68
    if-eqz v2, :cond_1

    .line 69
    .line 70
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    invoke-interface {v2, p0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    :cond_1
    sget-object p0, Lxc7;->a:Lxc7;

    .line 78
    .line 79
    return-object p0

    .line 80
    nop

    .line 81
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
