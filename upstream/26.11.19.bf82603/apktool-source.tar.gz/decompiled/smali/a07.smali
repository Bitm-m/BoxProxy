.class public final La07;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Landroid/view/View;

.field public final b:Lw27;

.field public final c:Lea;

.field public final d:Ll44;

.field public e:Lx2;


# direct methods
.method public constructor <init>(Landroid/view/View;Lsa;Lea;)V
    .locals 1

    .line 1
    new-instance p2, Lw27;

    .line 2
    .line 3
    invoke-direct {p2, p1}, Lw27;-><init>(Landroid/view/View;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, La07;->a:Landroid/view/View;

    .line 10
    .line 11
    iput-object p2, p0, La07;->b:Lw27;

    .line 12
    .line 13
    iput-object p3, p0, La07;->c:Lea;

    .line 14
    .line 15
    sget-wide p1, Lc17;->b:J

    .line 16
    .line 17
    new-instance p3, Loi;

    .line 18
    .line 19
    const-string v0, ""

    .line 20
    .line 21
    invoke-direct {p3, v0}, Loi;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-object p3, p3, Loi;->j:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    .line 27
    .line 28
    .line 29
    move-result p3

    .line 30
    invoke-static {p3, p1, p2}, Lrs6;->c(IJ)J

    .line 31
    .line 32
    .line 33
    sget p1, Lqw2;->g:I

    .line 34
    .line 35
    new-instance p1, Ljava/util/ArrayList;

    .line 36
    .line 37
    new-instance p1, Lzz5;

    .line 38
    .line 39
    const/16 p2, 0x11

    .line 40
    .line 41
    invoke-direct {p1, p0, p2}, Lzz5;-><init>(Ljava/lang/Object;B)V

    .line 42
    .line 43
    .line 44
    sget-object p2, Lee3;->j:Lee3;

    .line 45
    .line 46
    invoke-static {p2, p1}, Lcc3;->L(Lee3;Lu92;)Lwa3;

    .line 47
    .line 48
    .line 49
    new-instance p1, Landroid/view/inputmethod/CursorAnchorInfo$Builder;

    .line 50
    .line 51
    new-instance p1, Landroid/graphics/Matrix;

    .line 52
    .line 53
    new-instance p1, Ll44;

    .line 54
    .line 55
    const/16 p2, 0x10

    .line 56
    .line 57
    new-array p2, p2, [Lzz6;

    .line 58
    .line 59
    const/4 p3, 0x0

    .line 60
    invoke-direct {p1, p3, p2}, Ll44;-><init>(I[Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    iput-object p1, p0, La07;->d:Ll44;

    .line 64
    .line 65
    return-void
.end method


# virtual methods
.method public final a(Lzz6;)V
    .locals 1

    .line 1
    iget-object v0, p0, La07;->d:Ll44;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ll44;->b(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, La07;->e:Lx2;

    .line 7
    .line 8
    if-nez p1, :cond_0

    .line 9
    .line 10
    new-instance p1, Lx2;

    .line 11
    .line 12
    const/16 v0, 0x15

    .line 13
    .line 14
    invoke-direct {p1, p0, v0}, Lx2;-><init>(Ljava/lang/Object;B)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, La07;->c:Lea;

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Lea;->execute(Ljava/lang/Runnable;)V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, La07;->e:Lx2;

    .line 23
    .line 24
    :cond_0
    return-void
.end method
