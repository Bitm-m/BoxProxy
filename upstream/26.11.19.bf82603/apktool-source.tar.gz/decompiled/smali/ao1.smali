.class public abstract Lao1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lck1;

.field public static final b:Lac7;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lck1;->l:Lck1;

    .line 2
    .line 3
    sput-object v0, Lao1;->a:Lck1;

    .line 4
    .line 5
    sget-object v0, Lac7;->k:Lac7;

    .line 6
    .line 7
    sput-object v0, Lao1;->b:Lac7;

    .line 8
    .line 9
    return-void
.end method
