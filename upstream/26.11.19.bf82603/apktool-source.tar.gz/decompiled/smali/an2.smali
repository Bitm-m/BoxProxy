.class public final synthetic Lan2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lfa2;

.field public final synthetic k:Lj44;

.field public final synthetic l:Z


# direct methods
.method public synthetic constructor <init>(Lfa2;Lj44;ZB)V
    .locals 0

    .line 14
    iput-byte p4, p0, Lan2;->i:B

    iput-object p1, p0, Lan2;->j:Lfa2;

    iput-object p2, p0, Lan2;->k:Lj44;

    iput-boolean p3, p0, Lan2;->l:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLfa2;Lj44;)V
    .locals 1

    .line 1
    const/4 v0, 0x3

    .line 2
    iput-byte v0, p0, Lan2;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-boolean p1, p0, Lan2;->l:Z

    .line 8
    .line 9
    iput-object p2, p0, Lan2;->j:Lfa2;

    .line 10
    .line 11
    iput-object p3, p0, Lan2;->k:Lj44;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lan2;->i:B

    .line 4
    .line 5
    sget-object v2, Lg21;->a:Ley0;

    .line 6
    .line 7
    sget-object v3, Lxc7;->a:Lxc7;

    .line 8
    .line 9
    iget-object v4, v0, Lan2;->k:Lj44;

    .line 10
    .line 11
    iget-object v5, v0, Lan2;->j:Lfa2;

    .line 12
    .line 13
    iget-boolean v0, v0, Lan2;->l:Z

    .line 14
    .line 15
    const/4 v6, 0x0

    .line 16
    const/4 v7, 0x2

    .line 17
    const/4 v8, 0x1

    .line 18
    packed-switch v1, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    move-object/from16 v1, p1

    .line 22
    .line 23
    check-cast v1, Lib2;

    .line 24
    .line 25
    move-object/from16 v9, p2

    .line 26
    .line 27
    check-cast v9, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 30
    .line 31
    .line 32
    move-result v9

    .line 33
    and-int/lit8 v10, v9, 0x3

    .line 34
    .line 35
    if-eq v10, v7, :cond_0

    .line 36
    .line 37
    move v6, v8

    .line 38
    :cond_0
    and-int/2addr v9, v8

    .line 39
    invoke-virtual {v1, v9, v6}, Lib2;->X(IZ)Z

    .line 40
    .line 41
    .line 42
    move-result v6

    .line 43
    if-eqz v6, :cond_3

    .line 44
    .line 45
    xor-int/lit8 v11, v0, 0x1

    .line 46
    .line 47
    invoke-virtual {v1, v5}, Lib2;->g(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-virtual {v1, v4}, Lib2;->g(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    or-int/2addr v0, v6

    .line 56
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    if-nez v0, :cond_1

    .line 61
    .line 62
    if-ne v6, v2, :cond_2

    .line 63
    .line 64
    :cond_1
    new-instance v6, Lzk;

    .line 65
    .line 66
    const/16 v0, 0x14

    .line 67
    .line 68
    invoke-direct {v6, v5, v4, v0}, Lzk;-><init>(Lfa2;Lj44;B)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v1, v6}, Lib2;->p0(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    :cond_2
    move-object v9, v6

    .line 75
    check-cast v9, Lu92;

    .line 76
    .line 77
    sget-object v15, Lhb;->H:Lyz0;

    .line 78
    .line 79
    const/high16 v17, 0x30000000

    .line 80
    .line 81
    const/16 v18, 0x1fa

    .line 82
    .line 83
    const/4 v10, 0x0

    .line 84
    const/4 v12, 0x0

    .line 85
    const/4 v13, 0x0

    .line 86
    const/4 v14, 0x0

    .line 87
    move-object/from16 v16, v1

    .line 88
    .line 89
    invoke-static/range {v9 .. v18}, Ljq;->t(Lu92;Lw04;ZLma6;Lsf0;Lzt4;Lka2;Lib2;II)V

    .line 90
    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_3
    move-object/from16 v16, v1

    .line 94
    .line 95
    invoke-virtual/range {v16 .. v16}, Lib2;->a0()V

    .line 96
    .line 97
    .line 98
    :goto_0
    return-object v3

    .line 99
    :pswitch_0
    move-object/from16 v1, p1

    .line 100
    .line 101
    check-cast v1, Lib2;

    .line 102
    .line 103
    move-object/from16 v9, p2

    .line 104
    .line 105
    check-cast v9, Ljava/lang/Integer;

    .line 106
    .line 107
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 108
    .line 109
    .line 110
    move-result v9

    .line 111
    and-int/lit8 v10, v9, 0x3

    .line 112
    .line 113
    if-eq v10, v7, :cond_4

    .line 114
    .line 115
    move v6, v8

    .line 116
    :cond_4
    and-int/2addr v9, v8

    .line 117
    invoke-virtual {v1, v9, v6}, Lib2;->X(IZ)Z

    .line 118
    .line 119
    .line 120
    move-result v6

    .line 121
    if-eqz v6, :cond_7

    .line 122
    .line 123
    invoke-virtual {v1, v5}, Lib2;->g(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    if-nez v6, :cond_5

    .line 132
    .line 133
    if-ne v7, v2, :cond_6

    .line 134
    .line 135
    :cond_5
    new-instance v7, Lzk;

    .line 136
    .line 137
    const/16 v2, 0xb

    .line 138
    .line 139
    invoke-direct {v7, v5, v4, v2}, Lzk;-><init>(Lfa2;Lj44;B)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1, v7}, Lib2;->p0(Ljava/lang/Object;)V

    .line 143
    .line 144
    .line 145
    :cond_6
    move-object/from16 v18, v7

    .line 146
    .line 147
    check-cast v18, Lu92;

    .line 148
    .line 149
    sget-object v23, Lhr3;->y:Lyz0;

    .line 150
    .line 151
    new-instance v2, Lnk;

    .line 152
    .line 153
    const/16 v4, 0x9

    .line 154
    .line 155
    invoke-direct {v2, v4, v0}, Lnk;-><init>(BZ)V

    .line 156
    .line 157
    .line 158
    const v0, -0x6fdd6cc3

    .line 159
    .line 160
    .line 161
    invoke-static {v0, v2, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 162
    .line 163
    .line 164
    move-result-object v26

    .line 165
    const/16 v29, 0x6

    .line 166
    .line 167
    const/16 v30, 0x37d

    .line 168
    .line 169
    const/16 v17, 0x0

    .line 170
    .line 171
    const/16 v19, 0x0

    .line 172
    .line 173
    const/16 v20, 0x0

    .line 174
    .line 175
    const/16 v21, 0x0

    .line 176
    .line 177
    const/16 v22, 0x0

    .line 178
    .line 179
    const/16 v24, 0x0

    .line 180
    .line 181
    const/16 v25, 0x0

    .line 182
    .line 183
    const/high16 v28, 0xc00000

    .line 184
    .line 185
    move-object/from16 v27, v1

    .line 186
    .line 187
    invoke-static/range {v17 .. v30}, Lvq3;->e(Lw04;Lu92;Lu92;ZLii3;Lj34;Lja2;Lyz0;Lyz0;Lja2;Lib2;III)V

    .line 188
    .line 189
    .line 190
    goto :goto_1

    .line 191
    :cond_7
    move-object/from16 v27, v1

    .line 192
    .line 193
    invoke-virtual/range {v27 .. v27}, Lib2;->a0()V

    .line 194
    .line 195
    .line 196
    :goto_1
    return-object v3

    .line 197
    :pswitch_1
    move-object/from16 v14, p1

    .line 198
    .line 199
    check-cast v14, Lib2;

    .line 200
    .line 201
    move-object/from16 v1, p2

    .line 202
    .line 203
    check-cast v1, Ljava/lang/Integer;

    .line 204
    .line 205
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 206
    .line 207
    .line 208
    move-result v1

    .line 209
    and-int/lit8 v9, v1, 0x3

    .line 210
    .line 211
    if-eq v9, v7, :cond_8

    .line 212
    .line 213
    move v6, v8

    .line 214
    :cond_8
    and-int/2addr v1, v8

    .line 215
    invoke-virtual {v14, v1, v6}, Lib2;->X(IZ)Z

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    if-eqz v1, :cond_b

    .line 220
    .line 221
    invoke-virtual {v14, v5}, Lib2;->g(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v1

    .line 225
    invoke-virtual {v14}, Lib2;->S()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v6

    .line 229
    if-nez v1, :cond_9

    .line 230
    .line 231
    if-ne v6, v2, :cond_a

    .line 232
    .line 233
    :cond_9
    new-instance v6, Lzk;

    .line 234
    .line 235
    const/16 v1, 0xa

    .line 236
    .line 237
    invoke-direct {v6, v5, v4, v1}, Lzk;-><init>(Lfa2;Lj44;B)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v14, v6}, Lib2;->p0(Ljava/lang/Object;)V

    .line 241
    .line 242
    .line 243
    :cond_a
    move-object v5, v6

    .line 244
    check-cast v5, Lu92;

    .line 245
    .line 246
    sget-object v10, Lhr3;->x:Lyz0;

    .line 247
    .line 248
    new-instance v1, Lnk;

    .line 249
    .line 250
    const/16 v2, 0x8

    .line 251
    .line 252
    invoke-direct {v1, v2, v0}, Lnk;-><init>(BZ)V

    .line 253
    .line 254
    .line 255
    const v0, -0x75f91984

    .line 256
    .line 257
    .line 258
    invoke-static {v0, v1, v14}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 259
    .line 260
    .line 261
    move-result-object v13

    .line 262
    const/16 v16, 0x6

    .line 263
    .line 264
    const/16 v17, 0x37d

    .line 265
    .line 266
    const/4 v4, 0x0

    .line 267
    const/4 v6, 0x0

    .line 268
    const/4 v7, 0x0

    .line 269
    const/4 v8, 0x0

    .line 270
    const/4 v9, 0x0

    .line 271
    const/4 v11, 0x0

    .line 272
    const/4 v12, 0x0

    .line 273
    const/high16 v15, 0xc00000

    .line 274
    .line 275
    invoke-static/range {v4 .. v17}, Lvq3;->e(Lw04;Lu92;Lu92;ZLii3;Lj34;Lja2;Lyz0;Lyz0;Lja2;Lib2;III)V

    .line 276
    .line 277
    .line 278
    goto :goto_2

    .line 279
    :cond_b
    invoke-virtual {v14}, Lib2;->a0()V

    .line 280
    .line 281
    .line 282
    :goto_2
    return-object v3

    .line 283
    :pswitch_2
    move-object/from16 v1, p1

    .line 284
    .line 285
    check-cast v1, Lib2;

    .line 286
    .line 287
    move-object/from16 v2, p2

    .line 288
    .line 289
    check-cast v2, Ljava/lang/Integer;

    .line 290
    .line 291
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 292
    .line 293
    .line 294
    move-result v2

    .line 295
    and-int/lit8 v9, v2, 0x3

    .line 296
    .line 297
    if-eq v9, v7, :cond_c

    .line 298
    .line 299
    move v9, v8

    .line 300
    goto :goto_3

    .line 301
    :cond_c
    move v9, v6

    .line 302
    :goto_3
    and-int/2addr v2, v8

    .line 303
    invoke-virtual {v1, v2, v9}, Lib2;->X(IZ)Z

    .line 304
    .line 305
    .line 306
    move-result v2

    .line 307
    if-eqz v2, :cond_d

    .line 308
    .line 309
    sget-object v2, Lt04;->i:Lt04;

    .line 310
    .line 311
    const/high16 v9, 0x3f800000    # 1.0f

    .line 312
    .line 313
    invoke-static {v2, v9}, Lag6;->e(Lw04;F)Lw04;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    new-instance v9, Lan2;

    .line 318
    .line 319
    invoke-direct {v9, v5, v4, v0, v8}, Lan2;-><init>(Lfa2;Lj44;ZB)V

    .line 320
    .line 321
    .line 322
    const v10, -0x618f500

    .line 323
    .line 324
    .line 325
    invoke-static {v10, v9, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 326
    .line 327
    .line 328
    move-result-object v9

    .line 329
    new-instance v10, Lan2;

    .line 330
    .line 331
    invoke-direct {v10, v5, v4, v0, v7}, Lan2;-><init>(Lfa2;Lj44;ZB)V

    .line 332
    .line 333
    .line 334
    const v0, 0x2b7c1

    .line 335
    .line 336
    .line 337
    invoke-static {v0, v10, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    new-array v4, v7, [Lja2;

    .line 342
    .line 343
    aput-object v9, v4, v6

    .line 344
    .line 345
    aput-object v0, v4, v8

    .line 346
    .line 347
    invoke-static {v4}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 348
    .line 349
    .line 350
    move-result-object v7

    .line 351
    const/16 v9, 0xc06

    .line 352
    .line 353
    const/16 v10, 0x16

    .line 354
    .line 355
    const/4 v5, 0x0

    .line 356
    const/4 v6, 0x0

    .line 357
    move-object v8, v1

    .line 358
    move-object v4, v2

    .line 359
    invoke-static/range {v4 .. v10}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 360
    .line 361
    .line 362
    goto :goto_4

    .line 363
    :cond_d
    move-object v8, v1

    .line 364
    invoke-virtual {v8}, Lib2;->a0()V

    .line 365
    .line 366
    .line 367
    :goto_4
    return-object v3

    .line 368
    nop

    .line 369
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
