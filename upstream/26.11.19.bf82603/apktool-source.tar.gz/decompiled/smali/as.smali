.class public final synthetic Las;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Lcs;

.field public final synthetic j:Lw04;

.field public final synthetic k:Z

.field public final synthetic l:Lu92;

.field public final synthetic m:S

.field public final synthetic n:B


# direct methods
.method public synthetic constructor <init>(Lcs;Lw04;ZLu92;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Las;->i:Lcs;

    .line 5
    .line 6
    iput-object p2, p0, Las;->j:Lw04;

    .line 7
    .line 8
    iput-boolean p3, p0, Las;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Las;->l:Lu92;

    .line 11
    .line 12
    iput-short p5, p0, Las;->m:S

    .line 13
    .line 14
    iput-byte p6, p0, Las;->n:B

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    move-object v4, p1

    .line 2
    check-cast v4, Lib2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-short p1, p0, Las;->m:S

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lcc3;->X(I)I

    .line 14
    .line 15
    .line 16
    move-result v5

    .line 17
    iget-object v0, p0, Las;->i:Lcs;

    .line 18
    .line 19
    iget-object v1, p0, Las;->j:Lw04;

    .line 20
    .line 21
    iget-boolean v2, p0, Las;->k:Z

    .line 22
    .line 23
    iget-object v3, p0, Las;->l:Lu92;

    .line 24
    .line 25
    iget-byte v6, p0, Las;->n:B

    .line 26
    .line 27
    invoke-static/range {v0 .. v6}, Lm71;->a(Lcs;Lw04;ZLu92;Lib2;II)V

    .line 28
    .line 29
    .line 30
    sget-object p0, Lxc7;->a:Lxc7;

    .line 31
    .line 32
    return-object p0
.end method
