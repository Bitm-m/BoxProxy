.class public final Lb77;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lat1;


# instance fields
.field public final i:Lbt1;

.field public final j:J


# direct methods
.method public constructor <init>(Lbt1;J)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb77;->i:Lbt1;

    .line 8
    .line 9
    iput-wide p2, p0, Lb77;->j:J

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final h()J
    .locals 2

    .line 1
    iget-object p0, p0, Lb77;->i:Lbt1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lbt1;->h()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final o(JJLq03;Lh93;)J
    .locals 8

    .line 1
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget p6, p5, Lq03;->a:I

    .line 8
    .line 9
    iget-wide v0, p0, Lb77;->j:J

    .line 10
    .line 11
    const/16 p0, 0x20

    .line 12
    .line 13
    shr-long v2, v0, p0

    .line 14
    .line 15
    long-to-int v2, v2

    .line 16
    add-int/2addr p6, v2

    .line 17
    iget p5, p5, Lq03;->b:I

    .line 18
    .line 19
    const-wide v2, 0xffffffffL

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    and-long/2addr v0, v2

    .line 25
    long-to-int v0, v0

    .line 26
    add-int/2addr p5, v0

    .line 27
    add-int/lit8 v0, p5, 0x8

    .line 28
    .line 29
    and-long v4, p3, v2

    .line 30
    .line 31
    long-to-int v1, v4

    .line 32
    sub-int/2addr p5, v1

    .line 33
    const/16 v4, 0x8

    .line 34
    .line 35
    sub-int/2addr p5, v4

    .line 36
    add-int v5, v0, v1

    .line 37
    .line 38
    and-long v6, p1, v2

    .line 39
    .line 40
    long-to-int v6, v6

    .line 41
    add-int/lit8 v7, v6, -0x8

    .line 42
    .line 43
    if-le v5, v7, :cond_0

    .line 44
    .line 45
    move v0, p5

    .line 46
    :cond_0
    shr-long/2addr p3, p0

    .line 47
    long-to-int p3, p3

    .line 48
    div-int/lit8 p4, p3, 0x2

    .line 49
    .line 50
    sub-int/2addr p6, p4

    .line 51
    shr-long/2addr p1, p0

    .line 52
    long-to-int p1, p1

    .line 53
    sub-int/2addr p1, p3

    .line 54
    sub-int/2addr p1, v4

    .line 55
    if-ge p1, v4, :cond_1

    .line 56
    .line 57
    move p1, v4

    .line 58
    :cond_1
    invoke-static {p6, v4, p1}, Lkb3;->B(III)I

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    sub-int/2addr v6, v1

    .line 63
    sub-int/2addr v6, v4

    .line 64
    if-ge v6, v4, :cond_2

    .line 65
    .line 66
    move v6, v4

    .line 67
    :cond_2
    invoke-static {v0, v4, v6}, Lkb3;->B(III)I

    .line 68
    .line 69
    .line 70
    move-result p2

    .line 71
    int-to-long p3, p1

    .line 72
    shl-long/2addr p3, p0

    .line 73
    int-to-long p0, p2

    .line 74
    and-long/2addr p0, v2

    .line 75
    or-long/2addr p3, p0

    .line 76
    return-wide p3
.end method
