.class public final Laa5;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public i:Ljava/lang/String;

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lw27;

.field public l:I


# direct methods
.method public constructor <init>(Lw27;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laa5;->k:Lw27;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Laa5;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Laa5;->l:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Laa5;->l:I

    .line 9
    .line 10
    iget-object p1, p0, Laa5;->k:Lw27;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, p0}, Lw27;->P(Ljava/lang/String;Ljava/util/Map;Lfa1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
