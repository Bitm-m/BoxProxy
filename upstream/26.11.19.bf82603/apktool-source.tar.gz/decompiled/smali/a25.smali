.class public final synthetic La25;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/ArrayList;

.field public final synthetic k:Lfa2;


# direct methods
.method public synthetic constructor <init>(Lfa2;Ljava/util/ArrayList;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, La25;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La25;->k:Lfa2;

    .line 8
    .line 9
    iput-object p2, p0, La25;->j:Ljava/util/ArrayList;

    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/ArrayList;Lfa2;B)V
    .locals 0

    .line 12
    iput-byte p3, p0, La25;->i:B

    iput-object p1, p0, La25;->j:Ljava/util/ArrayList;

    iput-object p2, p0, La25;->k:Lfa2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget-byte v0, p0, La25;->i:B

    .line 2
    .line 3
    const v1, -0x73c450aa

    .line 4
    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    sget-object v3, Lxc7;->a:Lxc7;

    .line 8
    .line 9
    iget-object v4, p0, La25;->j:Ljava/util/ArrayList;

    .line 10
    .line 11
    iget-object p0, p0, La25;->k:Lfa2;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast p1, Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-interface {p0, p1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :pswitch_0
    check-cast p1, Ldb3;

    .line 31
    .line 32
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    new-instance v0, Ljs4;

    .line 36
    .line 37
    const/4 v5, 0x3

    .line 38
    invoke-direct {v0, v5}, Ljs4;-><init>(B)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    new-instance v6, Lc0;

    .line 46
    .line 47
    const/16 v7, 0x14

    .line 48
    .line 49
    invoke-direct {v6, v0, v4, v7}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Lud;

    .line 53
    .line 54
    const/16 v7, 0xc

    .line 55
    .line 56
    invoke-direct {v0, v4, v7}, Lud;-><init>(Ljava/util/ArrayList;B)V

    .line 57
    .line 58
    .line 59
    new-instance v7, Lf25;

    .line 60
    .line 61
    invoke-direct {v7, v4, p0, v2}, Lf25;-><init>(Ljava/util/ArrayList;Lfa2;B)V

    .line 62
    .line 63
    .line 64
    new-instance p0, Lyz0;

    .line 65
    .line 66
    invoke-direct {p0, v1, v2, v7}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    iget-object p1, p1, Ldb3;->e:Lww2;

    .line 70
    .line 71
    new-instance v1, Lcb3;

    .line 72
    .line 73
    invoke-direct {v1, v6, v0, p0}, Lcb3;-><init>(Lfa2;Lfa2;Lyz0;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1, v5, v1}, Lww2;->c(ILjc3;)V

    .line 77
    .line 78
    .line 79
    return-object v3

    .line 80
    :pswitch_1
    check-cast p1, Ldb3;

    .line 81
    .line 82
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    new-instance v0, Ljs4;

    .line 86
    .line 87
    const/4 v5, 0x2

    .line 88
    invoke-direct {v0, v5}, Ljs4;-><init>(B)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    new-instance v6, Lc0;

    .line 96
    .line 97
    const/16 v7, 0x13

    .line 98
    .line 99
    invoke-direct {v6, v0, v4, v7}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 100
    .line 101
    .line 102
    new-instance v0, Lud;

    .line 103
    .line 104
    const/16 v7, 0xb

    .line 105
    .line 106
    invoke-direct {v0, v4, v7}, Lud;-><init>(Ljava/util/ArrayList;B)V

    .line 107
    .line 108
    .line 109
    new-instance v7, Lf25;

    .line 110
    .line 111
    const/4 v8, 0x0

    .line 112
    invoke-direct {v7, v4, p0, v8}, Lf25;-><init>(Ljava/util/ArrayList;Lfa2;B)V

    .line 113
    .line 114
    .line 115
    new-instance p0, Lyz0;

    .line 116
    .line 117
    invoke-direct {p0, v1, v2, v7}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    iget-object p1, p1, Ldb3;->e:Lww2;

    .line 121
    .line 122
    new-instance v1, Lcb3;

    .line 123
    .line 124
    invoke-direct {v1, v6, v0, p0}, Lcb3;-><init>(Lfa2;Lfa2;Lyz0;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p1, v5, v1}, Lww2;->c(ILjc3;)V

    .line 128
    .line 129
    .line 130
    return-object v3

    .line 131
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
