.class public interface abstract Lar4;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# virtual methods
.method public abstract a(JILfa2;)J
.end method

.method public abstract b()Lal1;
.end method

.method public abstract c()Z
.end method

.method public abstract d(JLja2;Lfa1;)Ljava/lang/Object;
.end method
