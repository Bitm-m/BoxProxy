.class public final Lb62;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Le24;
.implements Lhp5;


# instance fields
.field public final a:Luv;

.field public final b:Lwv;

.field public final c:F

.field public final d:Lxf1;

.field public final e:F

.field public final f:Lz52;


# direct methods
.method public constructor <init>(Luv;Lwv;FLxf1;FLz52;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb62;->a:Luv;

    .line 5
    .line 6
    iput-object p2, p0, Lb62;->b:Lwv;

    .line 7
    .line 8
    iput p3, p0, Lb62;->c:F

    .line 9
    .line 10
    iput-object p4, p0, Lb62;->d:Lxf1;

    .line 11
    .line 12
    iput p5, p0, Lb62;->e:F

    .line 13
    .line 14
    iput-object p6, p0, Lb62;->f:Lz52;

    .line 15
    .line 16
    return-void
.end method

.method public static k(Ljava/util/List;IIILz52;)I
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-static {v2, v2}, Lg03;->a(II)J

    .line 7
    .line 8
    .line 9
    move-result-wide v3

    .line 10
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 11
    .line 12
    .line 13
    move-result v5

    .line 14
    if-nez v5, :cond_b

    .line 15
    .line 16
    const v5, 0x7fffffff

    .line 17
    .line 18
    .line 19
    invoke-static {v2, v1, v2, v5}, Lx71;->a(IIII)J

    .line 20
    .line 21
    .line 22
    move-result-wide v8

    .line 23
    new-instance v10, Lw52;

    .line 24
    .line 25
    move/from16 v11, p3

    .line 26
    .line 27
    move-object/from16 v7, p4

    .line 28
    .line 29
    move-object v6, v10

    .line 30
    move/from16 v10, p2

    .line 31
    .line 32
    invoke-direct/range {v6 .. v11}, Lw52;-><init>(Lz52;JII)V

    .line 33
    .line 34
    .line 35
    move-object v10, v6

    .line 36
    invoke-static {v2, v0}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v6

    .line 40
    check-cast v6, Ljr3;

    .line 41
    .line 42
    if-eqz v6, :cond_0

    .line 43
    .line 44
    invoke-interface {v6, v1}, Ljr3;->e0(I)I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    invoke-interface {v6, v7}, Ljr3;->M(I)I

    .line 49
    .line 50
    .line 51
    move-result v8

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move v7, v2

    .line 54
    move v8, v7

    .line 55
    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 56
    .line 57
    .line 58
    move-result v9

    .line 59
    const/4 v11, 0x1

    .line 60
    if-le v9, v11, :cond_1

    .line 61
    .line 62
    move v9, v11

    .line 63
    goto :goto_1

    .line 64
    :cond_1
    move v9, v11

    .line 65
    move v11, v2

    .line 66
    :goto_1
    invoke-static {v1, v5}, Lg03;->a(II)J

    .line 67
    .line 68
    .line 69
    move-result-wide v13

    .line 70
    const/16 v21, 0x0

    .line 71
    .line 72
    move-wide/from16 v22, v3

    .line 73
    .line 74
    if-nez v6, :cond_2

    .line 75
    .line 76
    move-object/from16 v15, v21

    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_2
    invoke-static {v8, v7}, Lg03;->a(II)J

    .line 80
    .line 81
    .line 82
    move-result-wide v2

    .line 83
    new-instance v4, Lg03;

    .line 84
    .line 85
    invoke-direct {v4, v2, v3}, Lg03;-><init>(J)V

    .line 86
    .line 87
    .line 88
    move-object v15, v4

    .line 89
    :goto_2
    const/16 v19, 0x0

    .line 90
    .line 91
    const/16 v20, 0x0

    .line 92
    .line 93
    const/4 v12, 0x0

    .line 94
    const/16 v16, 0x0

    .line 95
    .line 96
    const/16 v17, 0x0

    .line 97
    .line 98
    const/16 v18, 0x0

    .line 99
    .line 100
    invoke-virtual/range {v10 .. v20}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    iget-boolean v2, v2, Lv52;->c:Z

    .line 105
    .line 106
    if-eqz v2, :cond_3

    .line 107
    .line 108
    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    move-wide/from16 v3, v22

    .line 112
    .line 113
    goto/16 :goto_b

    .line 114
    .line 115
    :cond_3
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    move v11, v1

    .line 120
    move/from16 v13, v16

    .line 121
    .line 122
    move/from16 v3, v18

    .line 123
    .line 124
    const/4 v4, 0x0

    .line 125
    const/4 v12, 0x0

    .line 126
    const/16 v22, 0x0

    .line 127
    .line 128
    :goto_3
    if-ge v4, v2, :cond_a

    .line 129
    .line 130
    sub-int v8, v11, v8

    .line 131
    .line 132
    add-int/lit8 v11, v4, 0x1

    .line 133
    .line 134
    invoke-static {v3, v7}, Ljava/lang/Math;->max(II)I

    .line 135
    .line 136
    .line 137
    move-result v18

    .line 138
    invoke-static {v11, v0}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v3

    .line 142
    check-cast v3, Ljr3;

    .line 143
    .line 144
    if-eqz v3, :cond_4

    .line 145
    .line 146
    invoke-interface {v3, v1}, Ljr3;->e0(I)I

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    invoke-interface {v3, v7}, Ljr3;->M(I)I

    .line 151
    .line 152
    .line 153
    move-result v12

    .line 154
    add-int v12, v12, p2

    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_4
    const/4 v7, 0x0

    .line 158
    const/4 v12, 0x0

    .line 159
    :goto_4
    add-int/lit8 v4, v4, 0x2

    .line 160
    .line 161
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 162
    .line 163
    .line 164
    move-result v14

    .line 165
    if-ge v4, v14, :cond_5

    .line 166
    .line 167
    move v4, v11

    .line 168
    move v11, v9

    .line 169
    goto :goto_5

    .line 170
    :cond_5
    move v4, v11

    .line 171
    const/4 v11, 0x0

    .line 172
    :goto_5
    sub-int v16, v4, v22

    .line 173
    .line 174
    move/from16 v15, v16

    .line 175
    .line 176
    move/from16 v16, v13

    .line 177
    .line 178
    invoke-static {v8, v5}, Lg03;->a(II)J

    .line 179
    .line 180
    .line 181
    move-result-wide v13

    .line 182
    if-nez v3, :cond_6

    .line 183
    .line 184
    move-object/from16 v9, v21

    .line 185
    .line 186
    goto :goto_6

    .line 187
    :cond_6
    invoke-static {v12, v7}, Lg03;->a(II)J

    .line 188
    .line 189
    .line 190
    move-result-wide v5

    .line 191
    new-instance v9, Lg03;

    .line 192
    .line 193
    invoke-direct {v9, v5, v6}, Lg03;-><init>(J)V

    .line 194
    .line 195
    .line 196
    :goto_6
    const/16 v19, 0x0

    .line 197
    .line 198
    const/16 v20, 0x0

    .line 199
    .line 200
    move v6, v12

    .line 201
    move v12, v15

    .line 202
    move-object v15, v9

    .line 203
    invoke-virtual/range {v10 .. v20}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 204
    .line 205
    .line 206
    move-result-object v11

    .line 207
    iget-boolean v5, v11, Lv52;->b:Z

    .line 208
    .line 209
    if-eqz v5, :cond_9

    .line 210
    .line 211
    add-int v18, v18, p3

    .line 212
    .line 213
    add-int v14, v18, v17

    .line 214
    .line 215
    move/from16 v13, v16

    .line 216
    .line 217
    move/from16 v16, v12

    .line 218
    .line 219
    if-eqz v3, :cond_7

    .line 220
    .line 221
    const/4 v12, 0x1

    .line 222
    :goto_7
    move v15, v8

    .line 223
    goto :goto_8

    .line 224
    :cond_7
    const/4 v12, 0x0

    .line 225
    goto :goto_7

    .line 226
    :goto_8
    invoke-virtual/range {v10 .. v16}, Lw52;->a(Lv52;ZIIII)Llm;

    .line 227
    .line 228
    .line 229
    move/from16 v16, v13

    .line 230
    .line 231
    sub-int v12, v6, p2

    .line 232
    .line 233
    add-int/lit8 v13, v16, 0x1

    .line 234
    .line 235
    iget-boolean v3, v11, Lv52;->c:Z

    .line 236
    .line 237
    if-eqz v3, :cond_8

    .line 238
    .line 239
    move v12, v4

    .line 240
    move/from16 v17, v14

    .line 241
    .line 242
    goto :goto_a

    .line 243
    :cond_8
    move v11, v1

    .line 244
    move/from16 v22, v4

    .line 245
    .line 246
    move v8, v12

    .line 247
    move/from16 v17, v14

    .line 248
    .line 249
    const/4 v3, 0x0

    .line 250
    goto :goto_9

    .line 251
    :cond_9
    move v15, v8

    .line 252
    move v8, v6

    .line 253
    move v11, v15

    .line 254
    move/from16 v13, v16

    .line 255
    .line 256
    move/from16 v3, v18

    .line 257
    .line 258
    :goto_9
    move v12, v4

    .line 259
    const v5, 0x7fffffff

    .line 260
    .line 261
    .line 262
    const/4 v9, 0x1

    .line 263
    goto/16 :goto_3

    .line 264
    .line 265
    :cond_a
    :goto_a
    sub-int v0, v17, p3

    .line 266
    .line 267
    invoke-static {v0, v12}, Lg03;->a(II)J

    .line 268
    .line 269
    .line 270
    move-result-wide v3

    .line 271
    :cond_b
    :goto_b
    const/16 v0, 0x20

    .line 272
    .line 273
    shr-long/2addr v3, v0

    .line 274
    long-to-int v0, v3

    .line 275
    return v0
.end method


# virtual methods
.method public final a(Lb23;Ljava/util/List;I)I
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ljr3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Ljr3;

    .line 33
    .line 34
    :cond_1
    const/16 v2, 0xd

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-static {v3, p3, v3, v3, v2}, Lx71;->b(IIIII)J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    iget-object v4, p0, Lb62;->f:Lz52;

    .line 42
    .line 43
    invoke-virtual {v4, v0, v1, v2, v3}, Lz52;->a(Ljr3;Ljr3;J)V

    .line 44
    .line 45
    .line 46
    invoke-static {p2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    check-cast p2, Ljava/util/List;

    .line 51
    .line 52
    if-nez p2, :cond_2

    .line 53
    .line 54
    sget-object p2, Lby1;->i:Lby1;

    .line 55
    .line 56
    :cond_2
    iget v0, p0, Lb62;->c:F

    .line 57
    .line 58
    invoke-interface {p1, v0}, Lkl1;->s0(F)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iget p0, p0, Lb62;->e:F

    .line 63
    .line 64
    invoke-interface {p1, p0}, Lkl1;->s0(F)I

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    invoke-static {p2, p3, v0, p0, v4}, Lb62;->k(Ljava/util/List;IIILz52;)I

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    return p0
.end method

.method public final b(Lb23;Ljava/util/List;I)I
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ljr3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Ljr3;

    .line 33
    .line 34
    :cond_1
    const/4 v2, 0x7

    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {v3, v3, v3, p3, v2}, Lx71;->b(IIIII)J

    .line 37
    .line 38
    .line 39
    move-result-wide v4

    .line 40
    iget-object v2, p0, Lb62;->f:Lz52;

    .line 41
    .line 42
    invoke-virtual {v2, v0, v1, v4, v5}, Lz52;->a(Ljr3;Ljr3;J)V

    .line 43
    .line 44
    .line 45
    invoke-static {p2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    check-cast p2, Ljava/util/List;

    .line 50
    .line 51
    if-nez p2, :cond_2

    .line 52
    .line 53
    sget-object p2, Lby1;->i:Lby1;

    .line 54
    .line 55
    :cond_2
    iget p0, p0, Lb62;->c:F

    .line 56
    .line 57
    invoke-interface {p1, p0}, Lkl1;->s0(F)I

    .line 58
    .line 59
    .line 60
    move-result p0

    .line 61
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    move v0, v3

    .line 66
    move v1, v0

    .line 67
    move v2, v1

    .line 68
    move v4, v2

    .line 69
    :goto_1
    if-ge v0, p1, :cond_4

    .line 70
    .line 71
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v5

    .line 75
    check-cast v5, Ljr3;

    .line 76
    .line 77
    invoke-interface {v5, p3}, Ljr3;->b0(I)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    add-int/2addr v5, p0

    .line 82
    add-int/lit8 v6, v0, 0x1

    .line 83
    .line 84
    sub-int v7, v6, v2

    .line 85
    .line 86
    const v8, 0x7fffffff

    .line 87
    .line 88
    .line 89
    if-eq v7, v8, :cond_3

    .line 90
    .line 91
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 92
    .line 93
    .line 94
    move-result v7

    .line 95
    if-eq v6, v7, :cond_3

    .line 96
    .line 97
    add-int/2addr v4, v5

    .line 98
    goto :goto_2

    .line 99
    :cond_3
    add-int/2addr v4, v5

    .line 100
    sub-int/2addr v4, p0

    .line 101
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    move v2, v0

    .line 106
    move v4, v3

    .line 107
    :goto_2
    move v0, v6

    .line 108
    goto :goto_1

    .line 109
    :cond_4
    return v1
.end method

.method public final c(Lqr3;Ljava/util/List;J)Lpr3;
    .locals 62

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v6, p1

    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    move-wide/from16 v2, p3

    .line 8
    .line 9
    move-object v4, v1

    .line 10
    check-cast v4, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    sget-object v13, Lcy1;->i:Lcy1;

    .line 17
    .line 18
    const/4 v14, 0x0

    .line 19
    if-nez v4, :cond_0

    .line 20
    .line 21
    invoke-static {v2, v3}, Lw71;->h(J)I

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    iget-object v5, v0, Lb62;->f:Lz52;

    .line 26
    .line 27
    if-nez v4, :cond_1

    .line 28
    .line 29
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    :cond_0
    move-object v1, v13

    .line 33
    goto/16 :goto_1e

    .line 34
    .line 35
    :cond_1
    invoke-static {v1}, Liv0;->w0(Ljava/util/List;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    check-cast v4, Ljava/util/List;

    .line 40
    .line 41
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    if-eqz v7, :cond_2

    .line 46
    .line 47
    new-instance v0, Lef1;

    .line 48
    .line 49
    const/16 v1, 0x17

    .line 50
    .line 51
    invoke-direct {v0, v1}, Lef1;-><init>(B)V

    .line 52
    .line 53
    .line 54
    invoke-interface {v6, v14, v14, v13, v0}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    return-object v0

    .line 59
    :cond_2
    const/4 v15, 0x1

    .line 60
    invoke-static {v15, v1}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    check-cast v7, Ljava/util/List;

    .line 65
    .line 66
    if-eqz v7, :cond_3

    .line 67
    .line 68
    invoke-static {v7}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    check-cast v7, Ljr3;

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    const/4 v7, 0x0

    .line 76
    :goto_0
    const/4 v9, 0x2

    .line 77
    invoke-static {v9, v1}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    check-cast v1, Ljava/util/List;

    .line 82
    .line 83
    if-eqz v1, :cond_4

    .line 84
    .line 85
    invoke-static {v1}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    check-cast v1, Ljr3;

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :cond_4
    const/4 v1, 0x0

    .line 93
    :goto_1
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    sget-object v5, Lqa3;->i:Lqa3;

    .line 100
    .line 101
    invoke-static {v2, v3, v5}, Lg93;->D(JLqa3;)J

    .line 102
    .line 103
    .line 104
    move-result-wide v10

    .line 105
    const/16 v12, 0xa

    .line 106
    .line 107
    invoke-static {v12, v10, v11}, Lg93;->E(IJ)J

    .line 108
    .line 109
    .line 110
    move-result-wide v10

    .line 111
    invoke-static {v10, v11}, Lg93;->g0(J)J

    .line 112
    .line 113
    .line 114
    move-result-wide v10

    .line 115
    move/from16 v16, v15

    .line 116
    .line 117
    const v15, 0x7fffffff

    .line 118
    .line 119
    .line 120
    const/16 v17, 0x0

    .line 121
    .line 122
    if-eqz v7, :cond_6

    .line 123
    .line 124
    invoke-static {v7}, Lcc3;->H(Ljr3;)Lip5;

    .line 125
    .line 126
    .line 127
    move-result-object v18

    .line 128
    invoke-static/range {v18 .. v18}, Lcc3;->I(Lip5;)F

    .line 129
    .line 130
    .line 131
    move-result v18

    .line 132
    cmpg-float v18, v18, v17

    .line 133
    .line 134
    if-nez v18, :cond_5

    .line 135
    .line 136
    invoke-static {v7}, Lcc3;->H(Ljr3;)Lip5;

    .line 137
    .line 138
    .line 139
    invoke-interface {v7, v10, v11}, Ljr3;->e(J)Lc05;

    .line 140
    .line 141
    .line 142
    move-result-object v7

    .line 143
    invoke-virtual {v7}, Lc05;->k0()I

    .line 144
    .line 145
    .line 146
    invoke-virtual {v7}, Lc05;->h0()I

    .line 147
    .line 148
    .line 149
    invoke-virtual {v7}, Lc05;->k0()I

    .line 150
    .line 151
    .line 152
    invoke-virtual {v7}, Lc05;->h0()I

    .line 153
    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_5
    move/from16 v18, v9

    .line 157
    .line 158
    invoke-interface {v7, v15}, Ljr3;->M(I)I

    .line 159
    .line 160
    .line 161
    move-result v9

    .line 162
    invoke-interface {v7, v9}, Ljr3;->e0(I)I

    .line 163
    .line 164
    .line 165
    goto :goto_3

    .line 166
    :cond_6
    :goto_2
    move/from16 v18, v9

    .line 167
    .line 168
    :goto_3
    if-eqz v1, :cond_8

    .line 169
    .line 170
    invoke-static {v1}, Lcc3;->H(Ljr3;)Lip5;

    .line 171
    .line 172
    .line 173
    move-result-object v7

    .line 174
    invoke-static {v7}, Lcc3;->I(Lip5;)F

    .line 175
    .line 176
    .line 177
    move-result v7

    .line 178
    cmpg-float v7, v7, v17

    .line 179
    .line 180
    if-nez v7, :cond_7

    .line 181
    .line 182
    invoke-static {v1}, Lcc3;->H(Ljr3;)Lip5;

    .line 183
    .line 184
    .line 185
    invoke-interface {v1, v10, v11}, Ljr3;->e(J)Lc05;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    invoke-virtual {v1}, Lc05;->k0()I

    .line 190
    .line 191
    .line 192
    invoke-virtual {v1}, Lc05;->h0()I

    .line 193
    .line 194
    .line 195
    invoke-virtual {v1}, Lc05;->k0()I

    .line 196
    .line 197
    .line 198
    invoke-virtual {v1}, Lc05;->h0()I

    .line 199
    .line 200
    .line 201
    goto :goto_4

    .line 202
    :cond_7
    invoke-interface {v1, v15}, Ljr3;->M(I)I

    .line 203
    .line 204
    .line 205
    move-result v7

    .line 206
    invoke-interface {v1, v7}, Ljr3;->e0(I)I

    .line 207
    .line 208
    .line 209
    :cond_8
    :goto_4
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 210
    .line 211
    .line 212
    move-result-object v1

    .line 213
    invoke-static {v2, v3, v5}, Lg93;->D(JLqa3;)J

    .line 214
    .line 215
    .line 216
    move-result-wide v21

    .line 217
    new-instance v2, Ll44;

    .line 218
    .line 219
    const/16 v3, 0x10

    .line 220
    .line 221
    new-array v4, v3, [Lpr3;

    .line 222
    .line 223
    invoke-direct {v2, v14, v4}, Ll44;-><init>(I[Ljava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    invoke-static/range {v21 .. v22}, Lw71;->i(J)I

    .line 227
    .line 228
    .line 229
    move-result v4

    .line 230
    invoke-static/range {v21 .. v22}, Lw71;->k(J)I

    .line 231
    .line 232
    .line 233
    move-result v5

    .line 234
    invoke-static/range {v21 .. v22}, Lw71;->h(J)I

    .line 235
    .line 236
    .line 237
    move-result v7

    .line 238
    sget-object v9, Ll03;->a:Lh34;

    .line 239
    .line 240
    new-instance v9, Lh34;

    .line 241
    .line 242
    invoke-direct {v9}, Lh34;-><init>()V

    .line 243
    .line 244
    .line 245
    new-instance v10, Ljava/util/ArrayList;

    .line 246
    .line 247
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 248
    .line 249
    .line 250
    iget v11, v0, Lb62;->c:F

    .line 251
    .line 252
    invoke-interface {v6, v11}, Lkl1;->L(F)F

    .line 253
    .line 254
    .line 255
    move-result v11

    .line 256
    move-object/from16 v30, v13

    .line 257
    .line 258
    float-to-double v12, v11

    .line 259
    invoke-static {v12, v13}, Ljava/lang/Math;->ceil(D)D

    .line 260
    .line 261
    .line 262
    move-result-wide v11

    .line 263
    double-to-float v11, v11

    .line 264
    float-to-int v11, v11

    .line 265
    iget v12, v0, Lb62;->e:F

    .line 266
    .line 267
    invoke-interface {v6, v12}, Lkl1;->L(F)F

    .line 268
    .line 269
    .line 270
    move-result v12

    .line 271
    float-to-double v12, v12

    .line 272
    invoke-static {v12, v13}, Ljava/lang/Math;->ceil(D)D

    .line 273
    .line 274
    .line 275
    move-result-wide v12

    .line 276
    double-to-float v12, v12

    .line 277
    float-to-int v12, v12

    .line 278
    move-object/from16 p3, v9

    .line 279
    .line 280
    invoke-static {v14, v4, v14, v7}, Lx71;->a(IIII)J

    .line 281
    .line 282
    .line 283
    move-result-wide v8

    .line 284
    const/16 v13, 0xe

    .line 285
    .line 286
    invoke-static {v13, v8, v9}, Lg93;->E(IJ)J

    .line 287
    .line 288
    .line 289
    move-result-wide v19

    .line 290
    move/from16 v28, v4

    .line 291
    .line 292
    invoke-static/range {v19 .. v20}, Lg93;->g0(J)J

    .line 293
    .line 294
    .line 295
    move-result-wide v3

    .line 296
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 297
    .line 298
    .line 299
    move-result v19

    .line 300
    if-nez v19, :cond_9

    .line 301
    .line 302
    const/4 v13, 0x0

    .line 303
    goto :goto_6

    .line 304
    :cond_9
    :try_start_0
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object v19

    .line 308
    check-cast v19, Ljr3;
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    .line 309
    .line 310
    goto :goto_5

    .line 311
    :catch_0
    const/16 v19, 0x0

    .line 312
    .line 313
    :goto_5
    move-object/from16 v13, v19

    .line 314
    .line 315
    :goto_6
    if-eqz v13, :cond_b

    .line 316
    .line 317
    invoke-static {v13}, Lcc3;->H(Ljr3;)Lip5;

    .line 318
    .line 319
    .line 320
    move-result-object v19

    .line 321
    invoke-static/range {v19 .. v19}, Lcc3;->I(Lip5;)F

    .line 322
    .line 323
    .line 324
    move-result v19

    .line 325
    cmpg-float v19, v19, v17

    .line 326
    .line 327
    if-nez v19, :cond_a

    .line 328
    .line 329
    invoke-static {v13}, Lcc3;->H(Ljr3;)Lip5;

    .line 330
    .line 331
    .line 332
    invoke-interface {v13, v3, v4}, Ljr3;->e(J)Lc05;

    .line 333
    .line 334
    .line 335
    move-result-object v19

    .line 336
    invoke-virtual/range {v19 .. v19}, Lc05;->k0()I

    .line 337
    .line 338
    .line 339
    move-result v14

    .line 340
    invoke-virtual/range {v19 .. v19}, Lc05;->h0()I

    .line 341
    .line 342
    .line 343
    move-result v15

    .line 344
    invoke-static {v14, v15}, Lg03;->a(II)J

    .line 345
    .line 346
    .line 347
    move-result-wide v14

    .line 348
    :goto_7
    move-object/from16 v33, v1

    .line 349
    .line 350
    goto :goto_8

    .line 351
    :cond_a
    move v14, v15

    .line 352
    invoke-interface {v13, v14}, Ljr3;->M(I)I

    .line 353
    .line 354
    .line 355
    move-result v15

    .line 356
    invoke-interface {v13, v15}, Ljr3;->e0(I)I

    .line 357
    .line 358
    .line 359
    move-result v14

    .line 360
    invoke-static {v15, v14}, Lg03;->a(II)J

    .line 361
    .line 362
    .line 363
    move-result-wide v14

    .line 364
    const/16 v19, 0x0

    .line 365
    .line 366
    goto :goto_7

    .line 367
    :goto_8
    new-instance v1, Lg03;

    .line 368
    .line 369
    invoke-direct {v1, v14, v15}, Lg03;-><init>(J)V

    .line 370
    .line 371
    .line 372
    move-object/from16 v14, v19

    .line 373
    .line 374
    goto :goto_9

    .line 375
    :cond_b
    move-object/from16 v33, v1

    .line 376
    .line 377
    const/4 v1, 0x0

    .line 378
    const/4 v14, 0x0

    .line 379
    :goto_9
    const/16 v15, 0x20

    .line 380
    .line 381
    const-wide v45, 0xffffffffL

    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    if-eqz v1, :cond_c

    .line 387
    .line 388
    move/from16 v47, v5

    .line 389
    .line 390
    iget-wide v5, v1, Lg03;->a:J

    .line 391
    .line 392
    move-object/from16 v39, v1

    .line 393
    .line 394
    move-object/from16 v48, v2

    .line 395
    .line 396
    shr-long v1, v5, v15

    .line 397
    .line 398
    long-to-int v1, v1

    .line 399
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 400
    .line 401
    .line 402
    move-result-object v1

    .line 403
    and-long v5, v5, v45

    .line 404
    .line 405
    long-to-int v2, v5

    .line 406
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 407
    .line 408
    .line 409
    move-result-object v2

    .line 410
    :goto_a
    const/16 v5, 0x10

    .line 411
    .line 412
    goto :goto_b

    .line 413
    :cond_c
    move-object/from16 v39, v1

    .line 414
    .line 415
    move-object/from16 v48, v2

    .line 416
    .line 417
    move/from16 v47, v5

    .line 418
    .line 419
    const/4 v1, 0x0

    .line 420
    const/4 v2, 0x0

    .line 421
    goto :goto_a

    .line 422
    :goto_b
    new-array v6, v5, [I

    .line 423
    .line 424
    new-array v5, v5, [I

    .line 425
    .line 426
    move/from16 v49, v15

    .line 427
    .line 428
    new-instance v15, Li34;

    .line 429
    .line 430
    move-object/from16 v50, v1

    .line 431
    .line 432
    const/4 v1, 0x0

    .line 433
    invoke-direct {v15, v1}, Li34;-><init>(Ljava/lang/Object;)V

    .line 434
    .line 435
    .line 436
    new-instance v51, Lw52;

    .line 437
    .line 438
    iget-object v1, v0, Lb62;->f:Lz52;

    .line 439
    .line 440
    move-object/from16 v20, v1

    .line 441
    .line 442
    move/from16 v23, v11

    .line 443
    .line 444
    move/from16 v24, v12

    .line 445
    .line 446
    move-object/from16 v19, v51

    .line 447
    .line 448
    invoke-direct/range {v19 .. v24}, Lw52;-><init>(Lz52;JII)V

    .line 449
    .line 450
    .line 451
    move-object v11, v5

    .line 452
    move/from16 v5, v23

    .line 453
    .line 454
    move/from16 v1, v24

    .line 455
    .line 456
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 457
    .line 458
    .line 459
    move-result v35

    .line 460
    move/from16 v12, v28

    .line 461
    .line 462
    invoke-static {v12, v7}, Lg03;->a(II)J

    .line 463
    .line 464
    .line 465
    move-result-wide v37

    .line 466
    const/16 v43, 0x0

    .line 467
    .line 468
    const/16 v44, 0x0

    .line 469
    .line 470
    const/16 v36, 0x0

    .line 471
    .line 472
    const/16 v40, 0x0

    .line 473
    .line 474
    const/16 v41, 0x0

    .line 475
    .line 476
    const/16 v42, 0x0

    .line 477
    .line 478
    move-object/from16 v34, v51

    .line 479
    .line 480
    invoke-virtual/range {v34 .. v44}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 481
    .line 482
    .line 483
    move-result-object v0

    .line 484
    move/from16 v19, v1

    .line 485
    .line 486
    iget-boolean v1, v0, Lv52;->c:Z

    .line 487
    .line 488
    if-eqz v1, :cond_e

    .line 489
    .line 490
    if-eqz v39, :cond_d

    .line 491
    .line 492
    move/from16 v25, v16

    .line 493
    .line 494
    goto :goto_c

    .line 495
    :cond_d
    const/16 v25, 0x0

    .line 496
    .line 497
    :goto_c
    const/16 v27, 0x0

    .line 498
    .line 499
    const/16 v29, 0x0

    .line 500
    .line 501
    const/16 v26, -0x1

    .line 502
    .line 503
    move-object/from16 v24, v0

    .line 504
    .line 505
    move/from16 v28, v12

    .line 506
    .line 507
    move-object/from16 v23, v51

    .line 508
    .line 509
    invoke-virtual/range {v23 .. v29}, Lw52;->a(Lv52;ZIIII)Llm;

    .line 510
    .line 511
    .line 512
    goto :goto_d

    .line 513
    :cond_e
    move-object/from16 v24, v0

    .line 514
    .line 515
    :goto_d
    move/from16 v26, v5

    .line 516
    .line 517
    move/from16 v29, v7

    .line 518
    .line 519
    move-wide/from16 v34, v8

    .line 520
    .line 521
    move/from16 v27, v12

    .line 522
    .line 523
    move-object v1, v13

    .line 524
    move-object/from16 v0, v24

    .line 525
    .line 526
    move-object/from16 v23, v50

    .line 527
    .line 528
    const/4 v5, 0x0

    .line 529
    const/4 v8, 0x0

    .line 530
    const/4 v9, 0x0

    .line 531
    const/16 v25, 0x0

    .line 532
    .line 533
    const/16 v28, 0x0

    .line 534
    .line 535
    const/16 v54, 0x0

    .line 536
    .line 537
    const/16 v58, 0x0

    .line 538
    .line 539
    move-object/from16 v24, v2

    .line 540
    .line 541
    move-object v13, v11

    .line 542
    move-object v2, v14

    .line 543
    move/from16 v11, v47

    .line 544
    .line 545
    move-object v14, v6

    .line 546
    const/4 v6, 0x0

    .line 547
    :goto_e
    iget-boolean v0, v0, Lv52;->c:Z

    .line 548
    .line 549
    if-nez v0, :cond_19

    .line 550
    .line 551
    if-eqz v1, :cond_19

    .line 552
    .line 553
    invoke-virtual/range {v23 .. v23}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 554
    .line 555
    .line 556
    invoke-virtual/range {v23 .. v23}, Ljava/lang/Integer;->intValue()I

    .line 557
    .line 558
    .line 559
    move-result v0

    .line 560
    invoke-virtual/range {v24 .. v24}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 561
    .line 562
    .line 563
    move/from16 v23, v0

    .line 564
    .line 565
    invoke-virtual/range {v24 .. v24}, Ljava/lang/Integer;->intValue()I

    .line 566
    .line 567
    .line 568
    move-result v0

    .line 569
    move-object/from16 v24, v15

    .line 570
    .line 571
    add-int v15, v25, v23

    .line 572
    .line 573
    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    .line 574
    .line 575
    .line 576
    move-result v59

    .line 577
    sub-int v0, v27, v23

    .line 578
    .line 579
    add-int/lit8 v5, v6, 0x1

    .line 580
    .line 581
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 582
    .line 583
    .line 584
    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 585
    .line 586
    .line 587
    move-object/from16 v23, v1

    .line 588
    .line 589
    move-object/from16 v1, p3

    .line 590
    .line 591
    invoke-virtual {v1, v6, v2}, Lh34;->i(ILjava/lang/Object;)V

    .line 592
    .line 593
    .line 594
    invoke-interface/range {v23 .. v23}, Ljr3;->j()Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    sub-int v53, v5, v28

    .line 598
    .line 599
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 600
    .line 601
    .line 602
    move-result v2

    .line 603
    if-eqz v2, :cond_f

    .line 604
    .line 605
    :try_start_1
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 606
    .line 607
    .line 608
    move-result-object v2

    .line 609
    check-cast v2, Ljr3;
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_1

    .line 610
    .line 611
    goto :goto_f

    .line 612
    :catch_1
    :cond_f
    const/4 v2, 0x0

    .line 613
    :goto_f
    if-eqz v2, :cond_11

    .line 614
    .line 615
    invoke-static {v2}, Lcc3;->H(Ljr3;)Lip5;

    .line 616
    .line 617
    .line 618
    move-result-object v6

    .line 619
    invoke-static {v6}, Lcc3;->I(Lip5;)F

    .line 620
    .line 621
    .line 622
    move-result v6

    .line 623
    cmpg-float v6, v6, v17

    .line 624
    .line 625
    if-nez v6, :cond_10

    .line 626
    .line 627
    invoke-static {v2}, Lcc3;->H(Ljr3;)Lip5;

    .line 628
    .line 629
    .line 630
    invoke-interface {v2, v3, v4}, Ljr3;->e(J)Lc05;

    .line 631
    .line 632
    .line 633
    move-result-object v6

    .line 634
    move-wide/from16 v36, v3

    .line 635
    .line 636
    invoke-virtual {v6}, Lc05;->k0()I

    .line 637
    .line 638
    .line 639
    move-result v3

    .line 640
    invoke-virtual {v6}, Lc05;->h0()I

    .line 641
    .line 642
    .line 643
    move-result v4

    .line 644
    invoke-static {v3, v4}, Lg03;->a(II)J

    .line 645
    .line 646
    .line 647
    move-result-wide v3

    .line 648
    :goto_10
    move-object/from16 p3, v2

    .line 649
    .line 650
    goto :goto_11

    .line 651
    :cond_10
    move-wide/from16 v36, v3

    .line 652
    .line 653
    const v3, 0x7fffffff

    .line 654
    .line 655
    .line 656
    invoke-interface {v2, v3}, Ljr3;->M(I)I

    .line 657
    .line 658
    .line 659
    move-result v4

    .line 660
    invoke-interface {v2, v4}, Ljr3;->e0(I)I

    .line 661
    .line 662
    .line 663
    move-result v3

    .line 664
    invoke-static {v4, v3}, Lg03;->a(II)J

    .line 665
    .line 666
    .line 667
    move-result-wide v3

    .line 668
    const/4 v6, 0x0

    .line 669
    goto :goto_10

    .line 670
    :goto_11
    new-instance v2, Lg03;

    .line 671
    .line 672
    invoke-direct {v2, v3, v4}, Lg03;-><init>(J)V

    .line 673
    .line 674
    .line 675
    goto :goto_12

    .line 676
    :cond_11
    move-object/from16 p3, v2

    .line 677
    .line 678
    move-wide/from16 v36, v3

    .line 679
    .line 680
    const/4 v2, 0x0

    .line 681
    const/4 v6, 0x0

    .line 682
    :goto_12
    if-eqz v2, :cond_12

    .line 683
    .line 684
    iget-wide v3, v2, Lg03;->a:J

    .line 685
    .line 686
    move-object/from16 v23, v2

    .line 687
    .line 688
    move-wide/from16 v38, v3

    .line 689
    .line 690
    shr-long v2, v38, v49

    .line 691
    .line 692
    long-to-int v2, v2

    .line 693
    add-int v2, v2, v26

    .line 694
    .line 695
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 696
    .line 697
    .line 698
    move-result-object v2

    .line 699
    and-long v3, v38, v45

    .line 700
    .line 701
    long-to-int v3, v3

    .line 702
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 703
    .line 704
    .line 705
    move-result-object v3

    .line 706
    goto :goto_13

    .line 707
    :cond_12
    move-object/from16 v23, v2

    .line 708
    .line 709
    const/4 v2, 0x0

    .line 710
    const/4 v3, 0x0

    .line 711
    :goto_13
    invoke-interface/range {v33 .. v33}, Ljava/util/Iterator;->hasNext()Z

    .line 712
    .line 713
    .line 714
    move-result v52

    .line 715
    move/from16 v57, v54

    .line 716
    .line 717
    invoke-static {v0, v7}, Lg03;->a(II)J

    .line 718
    .line 719
    .line 720
    move-result-wide v54

    .line 721
    if-nez v23, :cond_13

    .line 722
    .line 723
    move/from16 v25, v0

    .line 724
    .line 725
    move-object/from16 v27, v2

    .line 726
    .line 727
    move-object/from16 v38, v3

    .line 728
    .line 729
    const/16 v56, 0x0

    .line 730
    .line 731
    goto :goto_14

    .line 732
    :cond_13
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 733
    .line 734
    .line 735
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 736
    .line 737
    .line 738
    move-result v4

    .line 739
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 740
    .line 741
    .line 742
    move/from16 v25, v0

    .line 743
    .line 744
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 745
    .line 746
    .line 747
    move-result v0

    .line 748
    move-object/from16 v27, v2

    .line 749
    .line 750
    move-object/from16 v38, v3

    .line 751
    .line 752
    invoke-static {v4, v0}, Lg03;->a(II)J

    .line 753
    .line 754
    .line 755
    move-result-wide v2

    .line 756
    new-instance v0, Lg03;

    .line 757
    .line 758
    invoke-direct {v0, v2, v3}, Lg03;-><init>(J)V

    .line 759
    .line 760
    .line 761
    move-object/from16 v56, v0

    .line 762
    .line 763
    :goto_14
    const/16 v60, 0x0

    .line 764
    .line 765
    const/16 v61, 0x0

    .line 766
    .line 767
    invoke-virtual/range {v51 .. v61}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 768
    .line 769
    .line 770
    move-result-object v0

    .line 771
    iget-boolean v2, v0, Lv52;->b:Z

    .line 772
    .line 773
    if-eqz v2, :cond_18

    .line 774
    .line 775
    invoke-static {v11, v15}, Ljava/lang/Math;->max(II)I

    .line 776
    .line 777
    .line 778
    move-result v2

    .line 779
    invoke-static {v2, v12}, Ljava/lang/Math;->min(II)I

    .line 780
    .line 781
    .line 782
    move-result v2

    .line 783
    add-int v55, v58, v59

    .line 784
    .line 785
    move/from16 v54, v57

    .line 786
    .line 787
    move/from16 v57, v53

    .line 788
    .line 789
    if-eqz v23, :cond_14

    .line 790
    .line 791
    move/from16 v53, v16

    .line 792
    .line 793
    :goto_15
    move-object/from16 v52, v0

    .line 794
    .line 795
    move/from16 v56, v25

    .line 796
    .line 797
    goto :goto_16

    .line 798
    :cond_14
    const/16 v53, 0x0

    .line 799
    .line 800
    goto :goto_15

    .line 801
    :goto_16
    invoke-virtual/range {v51 .. v57}, Lw52;->a(Lv52;ZIIII)Llm;

    .line 802
    .line 803
    .line 804
    move/from16 v57, v54

    .line 805
    .line 806
    add-int/lit8 v0, v9, 0x1

    .line 807
    .line 808
    array-length v3, v13

    .line 809
    if-ge v3, v0, :cond_15

    .line 810
    .line 811
    array-length v3, v13

    .line 812
    mul-int/lit8 v3, v3, 0x3

    .line 813
    .line 814
    div-int/lit8 v3, v3, 0x2

    .line 815
    .line 816
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 817
    .line 818
    .line 819
    move-result v0

    .line 820
    invoke-static {v13, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 821
    .line 822
    .line 823
    move-result-object v13

    .line 824
    :cond_15
    aput v59, v13, v9

    .line 825
    .line 826
    add-int/lit8 v9, v9, 0x1

    .line 827
    .line 828
    sub-int v7, v29, v55

    .line 829
    .line 830
    sub-int v7, v7, v19

    .line 831
    .line 832
    add-int/lit8 v0, v8, 0x1

    .line 833
    .line 834
    array-length v3, v14

    .line 835
    if-ge v3, v0, :cond_16

    .line 836
    .line 837
    array-length v3, v14

    .line 838
    mul-int/lit8 v3, v3, 0x3

    .line 839
    .line 840
    div-int/lit8 v3, v3, 0x2

    .line 841
    .line 842
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 843
    .line 844
    .line 845
    move-result v0

    .line 846
    invoke-static {v14, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 847
    .line 848
    .line 849
    move-result-object v14

    .line 850
    :cond_16
    aput v5, v14, v8

    .line 851
    .line 852
    add-int/lit8 v8, v8, 0x1

    .line 853
    .line 854
    if-eqz v27, :cond_17

    .line 855
    .line 856
    invoke-virtual/range {v27 .. v27}, Ljava/lang/Integer;->intValue()I

    .line 857
    .line 858
    .line 859
    move-result v0

    .line 860
    sub-int v0, v0, v26

    .line 861
    .line 862
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 863
    .line 864
    .line 865
    move-result-object v0

    .line 866
    goto :goto_17

    .line 867
    :cond_17
    const/4 v0, 0x0

    .line 868
    :goto_17
    add-int/lit8 v54, v57, 0x1

    .line 869
    .line 870
    add-int v58, v55, v19

    .line 871
    .line 872
    move-object/from16 v23, v0

    .line 873
    .line 874
    move v11, v2

    .line 875
    move/from16 v28, v5

    .line 876
    .line 877
    move/from16 v27, v12

    .line 878
    .line 879
    const/16 v25, 0x0

    .line 880
    .line 881
    const/16 v59, 0x0

    .line 882
    .line 883
    goto :goto_18

    .line 884
    :cond_18
    move-object/from16 v52, v0

    .line 885
    .line 886
    move/from16 v56, v25

    .line 887
    .line 888
    move/from16 v25, v15

    .line 889
    .line 890
    move-object/from16 v23, v27

    .line 891
    .line 892
    move/from16 v27, v56

    .line 893
    .line 894
    move/from16 v54, v57

    .line 895
    .line 896
    :goto_18
    move-object v0, v1

    .line 897
    move-object/from16 v1, p3

    .line 898
    .line 899
    move-object/from16 p3, v0

    .line 900
    .line 901
    move-object v2, v6

    .line 902
    move-object/from16 v15, v24

    .line 903
    .line 904
    move-wide/from16 v3, v36

    .line 905
    .line 906
    move-object/from16 v24, v38

    .line 907
    .line 908
    move-object/from16 v0, v52

    .line 909
    .line 910
    move v6, v5

    .line 911
    move/from16 v5, v59

    .line 912
    .line 913
    goto/16 :goto_e

    .line 914
    .line 915
    :cond_19
    move-object/from16 v1, p3

    .line 916
    .line 917
    move-object/from16 v24, v15

    .line 918
    .line 919
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 920
    .line 921
    .line 922
    move-result v0

    .line 923
    new-array v2, v0, [Lc05;

    .line 924
    .line 925
    const/4 v3, 0x0

    .line 926
    :goto_19
    if-ge v3, v0, :cond_1a

    .line 927
    .line 928
    invoke-virtual {v1, v3}, Lk03;->b(I)Ljava/lang/Object;

    .line 929
    .line 930
    .line 931
    move-result-object v4

    .line 932
    aput-object v4, v2, v3

    .line 933
    .line 934
    add-int/lit8 v3, v3, 0x1

    .line 935
    .line 936
    goto :goto_19

    .line 937
    :cond_1a
    new-array v0, v8, [I

    .line 938
    .line 939
    new-array v15, v8, [I

    .line 940
    .line 941
    move v1, v11

    .line 942
    const/4 v3, 0x0

    .line 943
    const/4 v12, 0x0

    .line 944
    const/16 v17, 0x0

    .line 945
    .line 946
    :goto_1a
    if-ge v12, v8, :cond_1e

    .line 947
    .line 948
    move-object v7, v10

    .line 949
    aget v10, v14, v12

    .line 950
    .line 951
    if-ltz v12, :cond_1d

    .line 952
    .line 953
    if-ge v12, v9, :cond_1d

    .line 954
    .line 955
    aget v4, v13, v12

    .line 956
    .line 957
    move-object/from16 v5, v24

    .line 958
    .line 959
    invoke-virtual {v5, v12}, Li34;->c(I)Z

    .line 960
    .line 961
    .line 962
    move-result v6

    .line 963
    if-eqz v6, :cond_1b

    .line 964
    .line 965
    :goto_1b
    move v11, v8

    .line 966
    move-object v8, v2

    .line 967
    goto :goto_1c

    .line 968
    :cond_1b
    invoke-static/range {v34 .. v35}, Lw71;->h(J)I

    .line 969
    .line 970
    .line 971
    move-result v4

    .line 972
    const v6, 0x7fffffff

    .line 973
    .line 974
    .line 975
    if-ne v4, v6, :cond_1c

    .line 976
    .line 977
    move v4, v6

    .line 978
    goto :goto_1b

    .line 979
    :cond_1c
    invoke-static/range {v34 .. v35}, Lw71;->h(J)I

    .line 980
    .line 981
    .line 982
    move-result v4

    .line 983
    sub-int v4, v4, v17

    .line 984
    .line 985
    goto :goto_1b

    .line 986
    :goto_1c
    invoke-static/range {v34 .. v35}, Lw71;->j(J)I

    .line 987
    .line 988
    .line 989
    move-result v2

    .line 990
    move/from16 v18, v9

    .line 991
    .line 992
    move v9, v3

    .line 993
    invoke-static/range {v34 .. v35}, Lw71;->i(J)I

    .line 994
    .line 995
    .line 996
    move-result v3

    .line 997
    move-object/from16 v24, v5

    .line 998
    .line 999
    move-object/from16 v19, v13

    .line 1000
    .line 1001
    move-object/from16 v23, v14

    .line 1002
    .line 1003
    move/from16 v20, v18

    .line 1004
    .line 1005
    move/from16 v5, v26

    .line 1006
    .line 1007
    move-object/from16 v13, v48

    .line 1008
    .line 1009
    move-object/from16 v6, p1

    .line 1010
    .line 1011
    move/from16 v18, v11

    .line 1012
    .line 1013
    move-object v11, v0

    .line 1014
    move-object/from16 v0, p0

    .line 1015
    .line 1016
    invoke-static/range {v0 .. v12}, Lm46;->R(Lhp5;IIIIILqr3;Ljava/util/List;[Lc05;II[II)Lpr3;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v2

    .line 1020
    invoke-interface {v2}, Lpr3;->b()I

    .line 1021
    .line 1022
    .line 1023
    move-result v3

    .line 1024
    invoke-interface {v2}, Lpr3;->a()I

    .line 1025
    .line 1026
    .line 1027
    move-result v4

    .line 1028
    aput v4, v15, v12

    .line 1029
    .line 1030
    add-int v17, v17, v4

    .line 1031
    .line 1032
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 1033
    .line 1034
    .line 1035
    move-result v1

    .line 1036
    invoke-virtual {v13, v2}, Ll44;->b(Ljava/lang/Object;)V

    .line 1037
    .line 1038
    .line 1039
    add-int/lit8 v12, v12, 0x1

    .line 1040
    .line 1041
    move-object v2, v8

    .line 1042
    move v3, v10

    .line 1043
    move-object v0, v11

    .line 1044
    move/from16 v8, v18

    .line 1045
    .line 1046
    move-object/from16 v13, v19

    .line 1047
    .line 1048
    move/from16 v9, v20

    .line 1049
    .line 1050
    move-object/from16 v14, v23

    .line 1051
    .line 1052
    move-object v10, v7

    .line 1053
    goto :goto_1a

    .line 1054
    :cond_1d
    const/16 v25, 0x0

    .line 1055
    .line 1056
    const-string v0, "Index must be between 0 and size"

    .line 1057
    .line 1058
    invoke-static {v0}, Lw91;->m(Ljava/lang/String;)V

    .line 1059
    .line 1060
    .line 1061
    return-object v25

    .line 1062
    :cond_1e
    move-object/from16 v6, p1

    .line 1063
    .line 1064
    move-object v11, v0

    .line 1065
    move-object/from16 v13, v48

    .line 1066
    .line 1067
    const/16 v14, 0xa

    .line 1068
    .line 1069
    move-object/from16 v0, p0

    .line 1070
    .line 1071
    iget v2, v13, Ll44;->k:I

    .line 1072
    .line 1073
    if-nez v2, :cond_1f

    .line 1074
    .line 1075
    const/4 v1, 0x0

    .line 1076
    const/16 v31, 0x0

    .line 1077
    .line 1078
    goto :goto_1d

    .line 1079
    :cond_1f
    move/from16 v31, v17

    .line 1080
    .line 1081
    :goto_1d
    iget-object v0, v0, Lb62;->b:Lwv;

    .line 1082
    .line 1083
    invoke-interface {v0}, Lwv;->a()F

    .line 1084
    .line 1085
    .line 1086
    move-result v2

    .line 1087
    invoke-interface {v6, v2}, Lkl1;->s0(F)I

    .line 1088
    .line 1089
    .line 1090
    move-result v2

    .line 1091
    iget v3, v13, Ll44;->k:I

    .line 1092
    .line 1093
    add-int/lit8 v3, v3, -0x1

    .line 1094
    .line 1095
    mul-int/2addr v3, v2

    .line 1096
    add-int v3, v3, v31

    .line 1097
    .line 1098
    invoke-static/range {v21 .. v22}, Lw71;->j(J)I

    .line 1099
    .line 1100
    .line 1101
    move-result v2

    .line 1102
    invoke-static/range {v21 .. v22}, Lw71;->h(J)I

    .line 1103
    .line 1104
    .line 1105
    move-result v4

    .line 1106
    if-ge v3, v2, :cond_20

    .line 1107
    .line 1108
    move v3, v2

    .line 1109
    :cond_20
    if-gt v3, v4, :cond_21

    .line 1110
    .line 1111
    move v4, v3

    .line 1112
    :cond_21
    invoke-interface {v0, v6, v4, v15, v11}, Lwv;->f(Lkl1;I[I[I)V

    .line 1113
    .line 1114
    .line 1115
    invoke-static/range {v21 .. v22}, Lw71;->k(J)I

    .line 1116
    .line 1117
    .line 1118
    move-result v0

    .line 1119
    invoke-static/range {v21 .. v22}, Lw71;->i(J)I

    .line 1120
    .line 1121
    .line 1122
    move-result v2

    .line 1123
    if-ge v1, v0, :cond_22

    .line 1124
    .line 1125
    move v1, v0

    .line 1126
    :cond_22
    if-gt v1, v2, :cond_23

    .line 1127
    .line 1128
    move v2, v1

    .line 1129
    :cond_23
    new-instance v0, Lde0;

    .line 1130
    .line 1131
    invoke-direct {v0, v13, v14}, Lde0;-><init>(Ljava/lang/Object;B)V

    .line 1132
    .line 1133
    .line 1134
    move-object/from16 v1, v30

    .line 1135
    .line 1136
    invoke-interface {v6, v2, v4, v1, v0}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 1137
    .line 1138
    .line 1139
    move-result-object v0

    .line 1140
    return-object v0

    .line 1141
    :goto_1e
    new-instance v0, Lef1;

    .line 1142
    .line 1143
    const/16 v2, 0x16

    .line 1144
    .line 1145
    invoke-direct {v0, v2}, Lef1;-><init>(B)V

    .line 1146
    .line 1147
    .line 1148
    const/4 v2, 0x0

    .line 1149
    invoke-interface {v6, v2, v2, v1, v0}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 1150
    .line 1151
    .line 1152
    move-result-object v0

    .line 1153
    return-object v0
.end method

.method public final d(Lb23;Ljava/util/List;I)I
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    check-cast v0, Ljava/util/List;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-static {v0}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Ljr3;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    move-object v0, v1

    .line 19
    :goto_0
    const/4 v2, 0x2

    .line 20
    invoke-static {v2, p2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/util/List;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    invoke-static {v2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Ljr3;

    .line 33
    .line 34
    :cond_1
    const/16 v2, 0xd

    .line 35
    .line 36
    const/4 v3, 0x0

    .line 37
    invoke-static {v3, p3, v3, v3, v2}, Lx71;->b(IIIII)J

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    iget-object v4, p0, Lb62;->f:Lz52;

    .line 42
    .line 43
    invoke-virtual {v4, v0, v1, v2, v3}, Lz52;->a(Ljr3;Ljr3;J)V

    .line 44
    .line 45
    .line 46
    invoke-static {p2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    check-cast p2, Ljava/util/List;

    .line 51
    .line 52
    if-nez p2, :cond_2

    .line 53
    .line 54
    sget-object p2, Lby1;->i:Lby1;

    .line 55
    .line 56
    :cond_2
    iget v0, p0, Lb62;->c:F

    .line 57
    .line 58
    invoke-interface {p1, v0}, Lkl1;->s0(F)I

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    iget p0, p0, Lb62;->e:F

    .line 63
    .line 64
    invoke-interface {p1, p0}, Lkl1;->s0(F)I

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    invoke-static {p2, p3, v0, p0, v4}, Lb62;->k(Ljava/util/List;IIILz52;)I

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    return p0
.end method

.method public final e(Lb23;Ljava/util/List;I)I
    .locals 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    invoke-static {v4, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v5

    .line 14
    check-cast v5, Ljava/util/List;

    .line 15
    .line 16
    if-eqz v5, :cond_0

    .line 17
    .line 18
    invoke-static {v5}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    check-cast v5, Ljr3;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v5, 0x0

    .line 26
    :goto_0
    const/4 v7, 0x2

    .line 27
    invoke-static {v7, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v8

    .line 31
    check-cast v8, Ljava/util/List;

    .line 32
    .line 33
    if-eqz v8, :cond_1

    .line 34
    .line 35
    invoke-static {v8}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    check-cast v8, Ljr3;

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :cond_1
    const/4 v8, 0x0

    .line 43
    :goto_1
    const/4 v9, 0x7

    .line 44
    const/4 v10, 0x0

    .line 45
    invoke-static {v10, v10, v10, v3, v9}, Lx71;->b(IIIII)J

    .line 46
    .line 47
    .line 48
    move-result-wide v11

    .line 49
    iget-object v9, v0, Lb62;->f:Lz52;

    .line 50
    .line 51
    invoke-virtual {v9, v5, v8, v11, v12}, Lz52;->a(Ljr3;Ljr3;J)V

    .line 52
    .line 53
    .line 54
    invoke-static {v2}, Liv0;->y0(Ljava/util/List;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    check-cast v2, Ljava/util/List;

    .line 59
    .line 60
    if-nez v2, :cond_2

    .line 61
    .line 62
    sget-object v2, Lby1;->i:Lby1;

    .line 63
    .line 64
    :cond_2
    iget v5, v0, Lb62;->c:F

    .line 65
    .line 66
    invoke-interface {v1, v5}, Lkl1;->s0(F)I

    .line 67
    .line 68
    .line 69
    move-result v15

    .line 70
    iget v5, v0, Lb62;->e:F

    .line 71
    .line 72
    invoke-interface {v1, v5}, Lkl1;->s0(F)I

    .line 73
    .line 74
    .line 75
    move-result v16

    .line 76
    invoke-static {v10, v10}, Lg03;->a(II)J

    .line 77
    .line 78
    .line 79
    move-result-wide v8

    .line 80
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-eqz v1, :cond_3

    .line 85
    .line 86
    return v10

    .line 87
    :cond_3
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    new-array v5, v1, [I

    .line 92
    .line 93
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 94
    .line 95
    .line 96
    move-result v11

    .line 97
    new-array v12, v11, [I

    .line 98
    .line 99
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 100
    .line 101
    .line 102
    move-result v13

    .line 103
    move v14, v10

    .line 104
    :goto_2
    if-ge v14, v13, :cond_4

    .line 105
    .line 106
    invoke-interface {v2, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v17

    .line 110
    move-object/from16 v6, v17

    .line 111
    .line 112
    check-cast v6, Ljr3;

    .line 113
    .line 114
    move/from16 v17, v7

    .line 115
    .line 116
    invoke-interface {v6, v3}, Ljr3;->M(I)I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    aput v7, v5, v14

    .line 121
    .line 122
    invoke-interface {v6, v7}, Ljr3;->e0(I)I

    .line 123
    .line 124
    .line 125
    move-result v6

    .line 126
    aput v6, v12, v14

    .line 127
    .line 128
    add-int/lit8 v14, v14, 0x1

    .line 129
    .line 130
    move/from16 v7, v17

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_4
    move/from16 v17, v7

    .line 134
    .line 135
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 136
    .line 137
    .line 138
    move-result v6

    .line 139
    iget-object v0, v0, Lb62;->f:Lz52;

    .line 140
    .line 141
    const v7, 0x7fffffff

    .line 142
    .line 143
    .line 144
    if-ge v7, v6, :cond_5

    .line 145
    .line 146
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    :cond_5
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    if-lt v7, v6, :cond_6

    .line 154
    .line 155
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    :cond_6
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 159
    .line 160
    .line 161
    move-result v6

    .line 162
    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    .line 163
    .line 164
    .line 165
    move-result v6

    .line 166
    move v13, v10

    .line 167
    move v14, v13

    .line 168
    :goto_3
    if-ge v13, v1, :cond_7

    .line 169
    .line 170
    aget v18, v5, v13

    .line 171
    .line 172
    add-int v14, v14, v18

    .line 173
    .line 174
    add-int/lit8 v13, v13, 0x1

    .line 175
    .line 176
    goto :goto_3

    .line 177
    :cond_7
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 178
    .line 179
    .line 180
    move-result v13

    .line 181
    sub-int/2addr v13, v4

    .line 182
    mul-int/2addr v13, v15

    .line 183
    add-int/2addr v13, v14

    .line 184
    if-eqz v11, :cond_1e

    .line 185
    .line 186
    aget v14, v12, v10

    .line 187
    .line 188
    sub-int/2addr v11, v4

    .line 189
    if-gt v4, v11, :cond_9

    .line 190
    .line 191
    move v7, v4

    .line 192
    move/from16 v18, v10

    .line 193
    .line 194
    :goto_4
    aget v10, v12, v7

    .line 195
    .line 196
    if-ge v14, v10, :cond_8

    .line 197
    .line 198
    move v14, v10

    .line 199
    :cond_8
    if-eq v7, v11, :cond_a

    .line 200
    .line 201
    add-int/lit8 v7, v7, 0x1

    .line 202
    .line 203
    goto :goto_4

    .line 204
    :cond_9
    move/from16 v18, v10

    .line 205
    .line 206
    :cond_a
    if-eqz v1, :cond_1d

    .line 207
    .line 208
    aget v7, v5, v18

    .line 209
    .line 210
    sub-int/2addr v1, v4

    .line 211
    if-gt v4, v1, :cond_c

    .line 212
    .line 213
    move v10, v4

    .line 214
    :goto_5
    aget v11, v5, v10

    .line 215
    .line 216
    if-ge v7, v11, :cond_b

    .line 217
    .line 218
    move v7, v11

    .line 219
    :cond_b
    if-eq v10, v1, :cond_c

    .line 220
    .line 221
    add-int/lit8 v10, v10, 0x1

    .line 222
    .line 223
    goto :goto_5

    .line 224
    :cond_c
    move v1, v13

    .line 225
    :goto_6
    if-gt v7, v1, :cond_1c

    .line 226
    .line 227
    if-eq v14, v3, :cond_1c

    .line 228
    .line 229
    add-int v10, v7, v1

    .line 230
    .line 231
    div-int/lit8 v10, v10, 0x2

    .line 232
    .line 233
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 234
    .line 235
    .line 236
    move-result v11

    .line 237
    if-eqz v11, :cond_d

    .line 238
    .line 239
    move v4, v1

    .line 240
    move-object v11, v2

    .line 241
    move-object/from16 p1, v12

    .line 242
    .line 243
    move-object v12, v0

    .line 244
    :goto_7
    move-wide v0, v8

    .line 245
    goto/16 :goto_15

    .line 246
    .line 247
    :cond_d
    move/from16 v11, v18

    .line 248
    .line 249
    const v13, 0x7fffffff

    .line 250
    .line 251
    .line 252
    invoke-static {v11, v10, v11, v13}, Lx71;->a(IIII)J

    .line 253
    .line 254
    .line 255
    move-result-wide v18

    .line 256
    new-instance v20, Lw52;

    .line 257
    .line 258
    move-object v4, v12

    .line 259
    move-object v12, v0

    .line 260
    move-object v0, v4

    .line 261
    move v4, v11

    .line 262
    move-wide/from16 v13, v18

    .line 263
    .line 264
    move-object/from16 v11, v20

    .line 265
    .line 266
    invoke-direct/range {v11 .. v16}, Lw52;-><init>(Lz52;JII)V

    .line 267
    .line 268
    .line 269
    invoke-static {v4, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v11

    .line 273
    check-cast v11, Ljr3;

    .line 274
    .line 275
    if-eqz v11, :cond_e

    .line 276
    .line 277
    aget v13, v0, v4

    .line 278
    .line 279
    aget v14, v5, v4

    .line 280
    .line 281
    goto :goto_8

    .line 282
    :cond_e
    const/4 v13, 0x0

    .line 283
    const/4 v14, 0x0

    .line 284
    :goto_8
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 285
    .line 286
    .line 287
    move-result v4

    .line 288
    move-object/from16 p1, v0

    .line 289
    .line 290
    const/4 v0, 0x1

    .line 291
    if-le v4, v0, :cond_f

    .line 292
    .line 293
    move/from16 v21, v0

    .line 294
    .line 295
    :goto_9
    const v4, 0x7fffffff

    .line 296
    .line 297
    .line 298
    goto :goto_a

    .line 299
    :cond_f
    const/16 v21, 0x0

    .line 300
    .line 301
    goto :goto_9

    .line 302
    :goto_a
    invoke-static {v10, v4}, Lg03;->a(II)J

    .line 303
    .line 304
    .line 305
    move-result-wide v23

    .line 306
    move v4, v1

    .line 307
    if-nez v11, :cond_10

    .line 308
    .line 309
    const/16 v25, 0x0

    .line 310
    .line 311
    goto :goto_b

    .line 312
    :cond_10
    invoke-static {v14, v13}, Lg03;->a(II)J

    .line 313
    .line 314
    .line 315
    move-result-wide v0

    .line 316
    new-instance v11, Lg03;

    .line 317
    .line 318
    invoke-direct {v11, v0, v1}, Lg03;-><init>(J)V

    .line 319
    .line 320
    .line 321
    move-object/from16 v25, v11

    .line 322
    .line 323
    :goto_b
    const/16 v29, 0x0

    .line 324
    .line 325
    const/16 v30, 0x0

    .line 326
    .line 327
    const/16 v22, 0x0

    .line 328
    .line 329
    const/16 v26, 0x0

    .line 330
    .line 331
    const/16 v27, 0x0

    .line 332
    .line 333
    const/16 v28, 0x0

    .line 334
    .line 335
    invoke-virtual/range {v20 .. v30}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    iget-boolean v0, v0, Lv52;->c:Z

    .line 340
    .line 341
    if-eqz v0, :cond_11

    .line 342
    .line 343
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 344
    .line 345
    .line 346
    move-object v11, v2

    .line 347
    goto :goto_7

    .line 348
    :cond_11
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 349
    .line 350
    .line 351
    move-result v0

    .line 352
    move/from16 v22, v10

    .line 353
    .line 354
    move/from16 v21, v14

    .line 355
    .line 356
    move/from16 v23, v26

    .line 357
    .line 358
    move/from16 v1, v28

    .line 359
    .line 360
    const/16 p2, 0x0

    .line 361
    .line 362
    const/4 v11, 0x0

    .line 363
    move v14, v13

    .line 364
    const/4 v13, 0x0

    .line 365
    :goto_c
    if-ge v11, v0, :cond_18

    .line 366
    .line 367
    sub-int v13, v22, v21

    .line 368
    .line 369
    move/from16 v31, v0

    .line 370
    .line 371
    add-int/lit8 v0, v11, 0x1

    .line 372
    .line 373
    invoke-static {v1, v14}, Ljava/lang/Math;->max(II)I

    .line 374
    .line 375
    .line 376
    move-result v28

    .line 377
    invoke-static {v0, v2}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    check-cast v1, Ljr3;

    .line 382
    .line 383
    if-eqz v1, :cond_12

    .line 384
    .line 385
    aget v14, p1, v0

    .line 386
    .line 387
    aget v21, v5, v0

    .line 388
    .line 389
    add-int v21, v21, v15

    .line 390
    .line 391
    move/from16 v32, v0

    .line 392
    .line 393
    move v0, v14

    .line 394
    move/from16 v14, v21

    .line 395
    .line 396
    goto :goto_d

    .line 397
    :cond_12
    move/from16 v32, v0

    .line 398
    .line 399
    const/4 v0, 0x0

    .line 400
    const/4 v14, 0x0

    .line 401
    :goto_d
    add-int/lit8 v11, v11, 0x2

    .line 402
    .line 403
    move-object/from16 v33, v1

    .line 404
    .line 405
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 406
    .line 407
    .line 408
    move-result v1

    .line 409
    if-ge v11, v1, :cond_13

    .line 410
    .line 411
    const/16 v21, 0x1

    .line 412
    .line 413
    goto :goto_e

    .line 414
    :cond_13
    const/16 v21, 0x0

    .line 415
    .line 416
    :goto_e
    sub-int v22, v32, p2

    .line 417
    .line 418
    move/from16 v26, v23

    .line 419
    .line 420
    const v1, 0x7fffffff

    .line 421
    .line 422
    .line 423
    invoke-static {v13, v1}, Lg03;->a(II)J

    .line 424
    .line 425
    .line 426
    move-result-wide v23

    .line 427
    if-nez v33, :cond_14

    .line 428
    .line 429
    move/from16 v34, v0

    .line 430
    .line 431
    move-object v11, v2

    .line 432
    const/16 v25, 0x0

    .line 433
    .line 434
    goto :goto_f

    .line 435
    :cond_14
    move-object v11, v2

    .line 436
    invoke-static {v14, v0}, Lg03;->a(II)J

    .line 437
    .line 438
    .line 439
    move-result-wide v1

    .line 440
    move/from16 v34, v0

    .line 441
    .line 442
    new-instance v0, Lg03;

    .line 443
    .line 444
    invoke-direct {v0, v1, v2}, Lg03;-><init>(J)V

    .line 445
    .line 446
    .line 447
    move-object/from16 v25, v0

    .line 448
    .line 449
    :goto_f
    const/16 v29, 0x0

    .line 450
    .line 451
    const/16 v30, 0x0

    .line 452
    .line 453
    invoke-virtual/range {v20 .. v30}, Lw52;->b(ZIJLg03;IIIZZ)Lv52;

    .line 454
    .line 455
    .line 456
    move-result-object v0

    .line 457
    iget-boolean v1, v0, Lv52;->b:Z

    .line 458
    .line 459
    if-eqz v1, :cond_17

    .line 460
    .line 461
    add-int v28, v28, v16

    .line 462
    .line 463
    add-int v24, v28, v27

    .line 464
    .line 465
    move/from16 v23, v26

    .line 466
    .line 467
    move/from16 v26, v22

    .line 468
    .line 469
    if-eqz v33, :cond_15

    .line 470
    .line 471
    const/16 v22, 0x1

    .line 472
    .line 473
    :goto_10
    move-object/from16 v21, v0

    .line 474
    .line 475
    move/from16 v25, v13

    .line 476
    .line 477
    goto :goto_11

    .line 478
    :cond_15
    const/16 v22, 0x0

    .line 479
    .line 480
    goto :goto_10

    .line 481
    :goto_11
    invoke-virtual/range {v20 .. v26}, Lw52;->a(Lv52;ZIIII)Llm;

    .line 482
    .line 483
    .line 484
    move-object/from16 v0, v21

    .line 485
    .line 486
    move/from16 v26, v23

    .line 487
    .line 488
    sub-int/2addr v14, v15

    .line 489
    add-int/lit8 v23, v26, 0x1

    .line 490
    .line 491
    iget-boolean v0, v0, Lv52;->c:Z

    .line 492
    .line 493
    if-eqz v0, :cond_16

    .line 494
    .line 495
    move/from16 v27, v24

    .line 496
    .line 497
    move/from16 v13, v32

    .line 498
    .line 499
    goto :goto_14

    .line 500
    :cond_16
    move/from16 v22, v10

    .line 501
    .line 502
    move/from16 v27, v24

    .line 503
    .line 504
    move/from16 v0, v32

    .line 505
    .line 506
    const/4 v1, 0x0

    .line 507
    :goto_12
    move/from16 v21, v14

    .line 508
    .line 509
    goto :goto_13

    .line 510
    :cond_17
    move/from16 v25, v13

    .line 511
    .line 512
    move/from16 v0, p2

    .line 513
    .line 514
    move/from16 v22, v25

    .line 515
    .line 516
    move/from16 v23, v26

    .line 517
    .line 518
    move/from16 v1, v28

    .line 519
    .line 520
    goto :goto_12

    .line 521
    :goto_13
    move/from16 p2, v0

    .line 522
    .line 523
    move-object v2, v11

    .line 524
    move/from16 v0, v31

    .line 525
    .line 526
    move/from16 v11, v32

    .line 527
    .line 528
    move v13, v11

    .line 529
    move/from16 v14, v34

    .line 530
    .line 531
    goto/16 :goto_c

    .line 532
    .line 533
    :cond_18
    move-object v11, v2

    .line 534
    :goto_14
    sub-int v0, v27, v16

    .line 535
    .line 536
    invoke-static {v0, v13}, Lg03;->a(II)J

    .line 537
    .line 538
    .line 539
    move-result-wide v0

    .line 540
    :goto_15
    const/16 v2, 0x20

    .line 541
    .line 542
    shr-long v13, v0, v2

    .line 543
    .line 544
    long-to-int v14, v13

    .line 545
    const-wide v20, 0xffffffffL

    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    and-long v0, v0, v20

    .line 551
    .line 552
    long-to-int v0, v0

    .line 553
    if-gt v14, v3, :cond_1a

    .line 554
    .line 555
    if-lt v0, v6, :cond_1a

    .line 556
    .line 557
    if-ge v14, v3, :cond_19

    .line 558
    .line 559
    add-int/lit8 v1, v10, -0x1

    .line 560
    .line 561
    :goto_16
    move v13, v10

    .line 562
    move-object v2, v11

    .line 563
    move-object v0, v12

    .line 564
    const/16 v18, 0x0

    .line 565
    .line 566
    move-object/from16 v12, p1

    .line 567
    .line 568
    goto/16 :goto_6

    .line 569
    .line 570
    :cond_19
    return v10

    .line 571
    :cond_1a
    add-int/lit8 v7, v10, 0x1

    .line 572
    .line 573
    if-le v7, v4, :cond_1b

    .line 574
    .line 575
    return v7

    .line 576
    :cond_1b
    move v1, v4

    .line 577
    goto :goto_16

    .line 578
    :cond_1c
    return v13

    .line 579
    :cond_1d
    invoke-static {}, Lw91;->p()V

    .line 580
    .line 581
    .line 582
    const/16 v18, 0x0

    .line 583
    .line 584
    return v18

    .line 585
    :cond_1e
    move/from16 v18, v10

    .line 586
    .line 587
    invoke-static {}, Lw91;->p()V

    .line 588
    .line 589
    .line 590
    return v18
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-eq p0, p1, :cond_1

    .line 2
    .line 3
    instance-of v0, p1, Lb62;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast p1, Lb62;

    .line 8
    .line 9
    iget-object v0, p0, Lb62;->a:Luv;

    .line 10
    .line 11
    iget-object v1, p1, Lb62;->a:Luv;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-object v0, p0, Lb62;->b:Lwv;

    .line 20
    .line 21
    iget-object v1, p1, Lb62;->b:Lwv;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    iget v0, p0, Lb62;->c:F

    .line 30
    .line 31
    iget v1, p1, Lb62;->c:F

    .line 32
    .line 33
    invoke-static {v0, v1}, Lmp1;->b(FF)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    iget-object v0, p0, Lb62;->d:Lxf1;

    .line 40
    .line 41
    iget-object v1, p1, Lb62;->d:Lxf1;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Lxf1;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    iget v0, p0, Lb62;->e:F

    .line 50
    .line 51
    iget v1, p1, Lb62;->e:F

    .line 52
    .line 53
    invoke-static {v0, v1}, Lmp1;->b(FF)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_0

    .line 58
    .line 59
    iget-object p0, p0, Lb62;->f:Lz52;

    .line 60
    .line 61
    iget-object p1, p1, Lb62;->f:Lz52;

    .line 62
    .line 63
    invoke-static {p0, p1}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-nez p0, :cond_1

    .line 68
    .line 69
    :cond_0
    const/4 p0, 0x0

    .line 70
    return p0

    .line 71
    :cond_1
    const/4 p0, 0x1

    .line 72
    return p0
.end method

.method public final f(I[I[ILqr3;)V
    .locals 6

    .line 1
    iget-object v0, p0, Lb62;->a:Luv;

    .line 2
    .line 3
    invoke-interface {p4}, Lb23;->getLayoutDirection()Lh93;

    .line 4
    .line 5
    .line 6
    move-result-object v4

    .line 7
    move v2, p1

    .line 8
    move-object v3, p2

    .line 9
    move-object v5, p3

    .line 10
    move-object v1, p4

    .line 11
    invoke-interface/range {v0 .. v5}, Luv;->e(Lkl1;I[ILh93;[I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final g(IIIZ)J
    .locals 0

    .line 1
    sget-object p0, Llp5;->a:Lmp5;

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    if-nez p4, :cond_0

    .line 5
    .line 6
    invoke-static {p1, p2, p0, p3}, Lx71;->a(IIII)J

    .line 7
    .line 8
    .line 9
    move-result-wide p0

    .line 10
    return-wide p0

    .line 11
    :cond_0
    invoke-static {p1, p2, p0, p3}, Lln;->L(IIII)J

    .line 12
    .line 13
    .line 14
    move-result-wide p0

    .line 15
    return-wide p0
.end method

.method public final h(Lc05;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lc05;->h0()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lb62;->a:Luv;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const v1, 0x9511

    .line 8
    .line 9
    .line 10
    add-int/2addr v0, v1

    .line 11
    const/16 v1, 0x1f

    .line 12
    .line 13
    mul-int/2addr v0, v1

    .line 14
    iget-object v2, p0, Lb62;->b:Lwv;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    add-int/2addr v2, v0

    .line 21
    mul-int/2addr v2, v1

    .line 22
    iget v0, p0, Lb62;->c:F

    .line 23
    .line 24
    invoke-static {v0, v2, v1}, Lmz1;->c(FII)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v2, p0, Lb62;->d:Lxf1;

    .line 29
    .line 30
    invoke-virtual {v2}, Lxf1;->hashCode()I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    add-int/2addr v2, v0

    .line 35
    mul-int/2addr v2, v1

    .line 36
    iget v0, p0, Lb62;->e:F

    .line 37
    .line 38
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    add-int/2addr v0, v2

    .line 43
    mul-int/2addr v0, v1

    .line 44
    const v2, 0x7fffffff

    .line 45
    .line 46
    .line 47
    add-int/2addr v0, v2

    .line 48
    mul-int/2addr v0, v1

    .line 49
    add-int/2addr v0, v2

    .line 50
    mul-int/2addr v0, v1

    .line 51
    iget-object p0, p0, Lb62;->f:Lz52;

    .line 52
    .line 53
    invoke-virtual {p0}, Lz52;->hashCode()I

    .line 54
    .line 55
    .line 56
    move-result p0

    .line 57
    add-int/2addr p0, v0

    .line 58
    return p0
.end method

.method public final i(Lc05;)I
    .locals 0

    .line 1
    invoke-virtual {p1}, Lc05;->k0()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final j([Lc05;Lqr3;[III[IIII)Lpr3;
    .locals 10

    .line 1
    new-instance v0, La62;

    .line 2
    .line 3
    sget-object v8, Lh93;->i:Lh93;

    .line 4
    .line 5
    move-object v6, p0

    .line 6
    move-object v5, p1

    .line 7
    move-object v9, p3

    .line 8
    move v7, p5

    .line 9
    move-object/from16 v1, p6

    .line 10
    .line 11
    move/from16 v2, p7

    .line 12
    .line 13
    move/from16 v3, p8

    .line 14
    .line 15
    move/from16 v4, p9

    .line 16
    .line 17
    invoke-direct/range {v0 .. v9}, La62;-><init>([IIII[Lc05;Lb62;ILh93;[I)V

    .line 18
    .line 19
    .line 20
    sget-object p0, Lcy1;->i:Lcy1;

    .line 21
    .line 22
    invoke-interface {p2, p4, p5, p0, v0}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, Lb62;->c:F

    .line 2
    .line 3
    invoke-static {v0}, Lmp1;->c(F)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget v1, p0, Lb62;->e:F

    .line 8
    .line 9
    invoke-static {v1}, Lmp1;->c(F)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    new-instance v2, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v3, "FlowMeasurePolicy(isHorizontal=true, horizontalArrangement="

    .line 16
    .line 17
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    iget-object v3, p0, Lb62;->a:Luv;

    .line 21
    .line 22
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v3, ", verticalArrangement="

    .line 26
    .line 27
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget-object v3, p0, Lb62;->b:Lwv;

    .line 31
    .line 32
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string v3, ", mainAxisSpacing="

    .line 36
    .line 37
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v0, ", crossAxisAlignment="

    .line 44
    .line 45
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget-object v0, p0, Lb62;->d:Lxf1;

    .line 49
    .line 50
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v0, ", crossAxisArrangementSpacing="

    .line 54
    .line 55
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v0, ", maxItemsInMainAxis=2147483647, maxLines=2147483647, overflow="

    .line 62
    .line 63
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    iget-object p0, p0, Lb62;->f:Lz52;

    .line 67
    .line 68
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string p0, ")"

    .line 72
    .line 73
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0
.end method
