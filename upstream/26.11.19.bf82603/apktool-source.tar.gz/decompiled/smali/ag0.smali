.class public final synthetic Lag0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:Ljava/lang/String;

.field public final synthetic j:Lu92;

.field public final synthetic k:Lw04;

.field public final synthetic l:Z

.field public final synthetic m:F

.field public final synthetic n:F

.field public final synthetic o:F

.field public final synthetic p:Lrv6;

.field public final synthetic q:Lzt4;

.field public final synthetic r:Lx17;

.field public final synthetic s:Lix2;

.field public final synthetic t:I

.field public final synthetic u:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lu92;Lw04;ZFFFLrv6;Lzt4;Lx17;Lix2;II)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lag0;->i:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lag0;->j:Lu92;

    .line 7
    .line 8
    iput-object p3, p0, Lag0;->k:Lw04;

    .line 9
    .line 10
    iput-boolean p4, p0, Lag0;->l:Z

    .line 11
    .line 12
    iput p5, p0, Lag0;->m:F

    .line 13
    .line 14
    iput p6, p0, Lag0;->n:F

    .line 15
    .line 16
    iput p7, p0, Lag0;->o:F

    .line 17
    .line 18
    iput-object p8, p0, Lag0;->p:Lrv6;

    .line 19
    .line 20
    iput-object p9, p0, Lag0;->q:Lzt4;

    .line 21
    .line 22
    iput-object p10, p0, Lag0;->r:Lx17;

    .line 23
    .line 24
    iput-object p11, p0, Lag0;->s:Lix2;

    .line 25
    .line 26
    iput p12, p0, Lag0;->t:I

    .line 27
    .line 28
    iput p13, p0, Lag0;->u:I

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    move-object v11, p1

    .line 2
    check-cast v11, Lib2;

    .line 3
    .line 4
    move-object/from16 v0, p2

    .line 5
    .line 6
    check-cast v0, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    iget v0, p0, Lag0;->t:I

    .line 12
    .line 13
    or-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    invoke-static {v0}, Lcc3;->X(I)I

    .line 16
    .line 17
    .line 18
    move-result v12

    .line 19
    iget v0, p0, Lag0;->u:I

    .line 20
    .line 21
    invoke-static {v0}, Lcc3;->X(I)I

    .line 22
    .line 23
    .line 24
    move-result v13

    .line 25
    iget-object v0, p0, Lag0;->i:Ljava/lang/String;

    .line 26
    .line 27
    iget-object v1, p0, Lag0;->j:Lu92;

    .line 28
    .line 29
    iget-object v2, p0, Lag0;->k:Lw04;

    .line 30
    .line 31
    iget-boolean v3, p0, Lag0;->l:Z

    .line 32
    .line 33
    iget v4, p0, Lag0;->m:F

    .line 34
    .line 35
    iget v5, p0, Lag0;->n:F

    .line 36
    .line 37
    iget v6, p0, Lag0;->o:F

    .line 38
    .line 39
    iget-object v7, p0, Lag0;->p:Lrv6;

    .line 40
    .line 41
    iget-object v8, p0, Lag0;->q:Lzt4;

    .line 42
    .line 43
    iget-object v9, p0, Lag0;->r:Lx17;

    .line 44
    .line 45
    iget-object v10, p0, Lag0;->s:Lix2;

    .line 46
    .line 47
    invoke-static/range {v0 .. v13}, Lnn;->j(Ljava/lang/String;Lu92;Lw04;ZFFFLrv6;Lzt4;Lx17;Lix2;Lib2;II)V

    .line 48
    .line 49
    .line 50
    sget-object p0, Lxc7;->a:Lxc7;

    .line 51
    .line 52
    return-object p0
.end method
