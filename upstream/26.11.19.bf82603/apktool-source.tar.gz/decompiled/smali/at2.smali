.class public final Lat2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lf13;


# instance fields
.field public final a:Lzs2;


# direct methods
.method public constructor <init>(Lzs2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lat2;->a:Lzs2;

    .line 5
    .line 6
    return-void
.end method
