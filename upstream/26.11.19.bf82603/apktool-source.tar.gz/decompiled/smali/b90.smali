.class public final Lb90;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# virtual methods
.method public final serializer()Le73;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Le73;"
        }
    .end annotation

    .line 1
    sget-object p0, La90;->a:La90;

    .line 2
    .line 3
    return-object p0
.end method
