.class public final Las6;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lbs6;

.field public k:I


# direct methods
.method public constructor <init>(Lbs6;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Las6;->j:Lbs6;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iput-object p1, p0, Las6;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Las6;->k:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Las6;->k:I

    .line 9
    .line 10
    const-wide/16 v0, 0x0

    .line 11
    .line 12
    const/4 p1, 0x0

    .line 13
    iget-object v2, p0, Las6;->j:Lbs6;

    .line 14
    .line 15
    invoke-virtual {v2, v0, v1, p1, p0}, Lbs6;->i(JLja2;Lfa1;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method
