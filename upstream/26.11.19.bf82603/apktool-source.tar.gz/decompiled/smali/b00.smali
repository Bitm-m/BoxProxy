.class public final Lb00;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Lpl0;

.field public final b:Lpl0;


# direct methods
.method public constructor <init>(Lpl0;Lpl0;)V
    .locals 0

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb00;->a:Lpl0;

    .line 8
    .line 9
    iput-object p2, p0, Lb00;->b:Lpl0;

    .line 10
    .line 11
    return-void
.end method
