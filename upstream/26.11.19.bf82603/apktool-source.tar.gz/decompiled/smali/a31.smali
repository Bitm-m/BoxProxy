.class public final synthetic La31;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, La31;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, La31;->i:B

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v2, ""

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    const/4 v4, 0x0

    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0

    .line 18
    :pswitch_0
    new-instance v0, Ln42;

    .line 19
    .line 20
    invoke-direct {v0, v1}, Ln42;-><init>(B)V

    .line 21
    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_1
    new-instance v0, Landroid/os/Handler;

    .line 25
    .line 26
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 31
    .line 32
    .line 33
    return-object v0

    .line 34
    :pswitch_2
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 35
    .line 36
    return-object v0

    .line 37
    :pswitch_3
    return-object v4

    .line 38
    :pswitch_4
    sget-object v0, Lxc7;->a:Lxc7;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_5
    sget-object v0, Lxc7;->a:Lxc7;

    .line 42
    .line 43
    return-object v0

    .line 44
    :pswitch_6
    sget-object v0, Lxc7;->a:Lxc7;

    .line 45
    .line 46
    return-object v0

    .line 47
    :pswitch_7
    sget-object v0, Lxc7;->a:Lxc7;

    .line 48
    .line 49
    return-object v0

    .line 50
    :pswitch_8
    const-string v5, "core_update_monitor"

    .line 51
    .line 52
    new-instance v6, Ljd1;

    .line 53
    .line 54
    sget-object v7, Lqd1;->a:Lca1;

    .line 55
    .line 56
    new-instance v8, Lvw0;

    .line 57
    .line 58
    const/16 v0, 0x1c

    .line 59
    .line 60
    invoke-direct {v8, v0}, Lvw0;-><init>(B)V

    .line 61
    .line 62
    .line 63
    const-string v9, "{}"

    .line 64
    .line 65
    sget-object v0, Lne1;->a:Lne1;

    .line 66
    .line 67
    invoke-static {}, Lne1;->d()Ljava/util/ArrayList;

    .line 68
    .line 69
    .line 70
    move-result-object v10

    .line 71
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    .line 72
    .line 73
    sget-object v11, Lcom/box/app/AppApplication;->i:Landroid/content/Context;

    .line 74
    .line 75
    invoke-static {}, Lnn;->t()Landroid/content/Context;

    .line 76
    .line 77
    .line 78
    move-result-object v11

    .line 79
    invoke-virtual {v11, v5, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 80
    .line 81
    .line 82
    move-result-object v11

    .line 83
    const-string v12, "cache"

    .line 84
    .line 85
    invoke-interface {v11, v12, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v11

    .line 89
    if-nez v11, :cond_0

    .line 90
    .line 91
    move-object v11, v2

    .line 92
    :cond_0
    invoke-direct {v0, v11}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :catchall_0
    move-exception v0

    .line 97
    new-instance v11, Lrm5;

    .line 98
    .line 99
    invoke-direct {v11, v0}, Lrm5;-><init>(Ljava/lang/Throwable;)V

    .line 100
    .line 101
    .line 102
    move-object v0, v11

    .line 103
    :goto_0
    new-instance v11, Lorg/json/JSONObject;

    .line 104
    .line 105
    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    .line 106
    .line 107
    .line 108
    instance-of v12, v0, Lrm5;

    .line 109
    .line 110
    if-eqz v12, :cond_1

    .line 111
    .line 112
    move-object v0, v11

    .line 113
    :cond_1
    move-object v11, v0

    .line 114
    check-cast v11, Lorg/json/JSONObject;

    .line 115
    .line 116
    new-instance v12, Ljava/util/ArrayList;

    .line 117
    .line 118
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 122
    .line 123
    .line 124
    move-result-object v13

    .line 125
    :goto_1
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_8

    .line 130
    .line 131
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    move-object v15, v0

    .line 136
    check-cast v15, Lle1;

    .line 137
    .line 138
    :try_start_1
    iget-object v0, v15, Lle1;->a:Ljava/lang/String;

    .line 139
    .line 140
    invoke-virtual {v11, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    if-nez v0, :cond_3

    .line 145
    .line 146
    move/from16 p0, v1

    .line 147
    .line 148
    :cond_2
    move-object/from16 v23, v2

    .line 149
    .line 150
    move-object v0, v4

    .line 151
    move-object/from16 v22, v0

    .line 152
    .line 153
    goto/16 :goto_5

    .line 154
    .line 155
    :cond_3
    const-string v14, "source"

    .line 156
    .line 157
    invoke-virtual {v0, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v14
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    .line 161
    move/from16 p0, v1

    .line 162
    .line 163
    :try_start_2
    invoke-static {v15}, Lrq;->T(Lle1;)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    invoke-static {v14, v1}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    if-eqz v1, :cond_2

    .line 172
    .line 173
    const-string v1, "asset"

    .line 174
    .line 175
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 176
    .line 177
    .line 178
    move-result-object v1

    .line 179
    if-eqz v1, :cond_5

    .line 180
    .line 181
    const-string v14, "version"

    .line 182
    .line 183
    invoke-virtual {v0, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v14

    .line 187
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 188
    .line 189
    .line 190
    move-object/from16 v22, v4

    .line 191
    .line 192
    :try_start_3
    const-string v4, "name"

    .line 193
    .line 194
    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v4

    .line 198
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 199
    .line 200
    .line 201
    const-string v3, "url"

    .line 202
    .line 203
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v3

    .line 207
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 208
    .line 209
    .line 210
    move-object/from16 v23, v2

    .line 211
    .line 212
    :try_start_4
    const-string v2, "sha256"

    .line 213
    .line 214
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    invoke-static {v1}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 219
    .line 220
    .line 221
    move-result v2

    .line 222
    if-eqz v2, :cond_4

    .line 223
    .line 224
    move-object/from16 v1, v22

    .line 225
    .line 226
    :cond_4
    new-instance v2, Lpb1;

    .line 227
    .line 228
    invoke-direct {v2, v4, v3, v1}, Lpb1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    new-instance v1, Lme1;

    .line 232
    .line 233
    invoke-direct {v1, v15, v14, v2}, Lme1;-><init>(Lle1;Ljava/lang/String;Lpb1;)V

    .line 234
    .line 235
    .line 236
    move-object/from16 v16, v1

    .line 237
    .line 238
    goto :goto_2

    .line 239
    :catchall_1
    move-exception v0

    .line 240
    move-object/from16 v23, v2

    .line 241
    .line 242
    goto :goto_4

    .line 243
    :cond_5
    move-object/from16 v23, v2

    .line 244
    .line 245
    move-object/from16 v22, v4

    .line 246
    .line 247
    move-object/from16 v16, v22

    .line 248
    .line 249
    :goto_2
    iget-object v1, v15, Lle1;->a:Ljava/lang/String;

    .line 250
    .line 251
    new-instance v14, Lka1;

    .line 252
    .line 253
    const-string v2, "failed"

    .line 254
    .line 255
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    .line 256
    .line 257
    .line 258
    move-result v17

    .line 259
    const-string v2, "time"

    .line 260
    .line 261
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    .line 262
    .line 263
    .line 264
    move-result-wide v18

    .line 265
    const/16 v20, 0x0

    .line 266
    .line 267
    const/16 v21, 0x24

    .line 268
    .line 269
    invoke-direct/range {v14 .. v21}, Lka1;-><init>(Lle1;Lme1;ZJLjava/lang/String;I)V

    .line 270
    .line 271
    .line 272
    new-instance v0, Lnw4;

    .line 273
    .line 274
    invoke-direct {v0, v1, v14}, Lnw4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 275
    .line 276
    .line 277
    goto :goto_5

    .line 278
    :catchall_2
    move-exception v0

    .line 279
    goto :goto_4

    .line 280
    :catchall_3
    move-exception v0

    .line 281
    :goto_3
    move-object/from16 v23, v2

    .line 282
    .line 283
    move-object/from16 v22, v4

    .line 284
    .line 285
    goto :goto_4

    .line 286
    :catchall_4
    move-exception v0

    .line 287
    move/from16 p0, v1

    .line 288
    .line 289
    goto :goto_3

    .line 290
    :goto_4
    new-instance v1, Lrm5;

    .line 291
    .line 292
    invoke-direct {v1, v0}, Lrm5;-><init>(Ljava/lang/Throwable;)V

    .line 293
    .line 294
    .line 295
    move-object v0, v1

    .line 296
    :goto_5
    instance-of v1, v0, Lrm5;

    .line 297
    .line 298
    if-eqz v1, :cond_6

    .line 299
    .line 300
    move-object/from16 v0, v22

    .line 301
    .line 302
    :cond_6
    check-cast v0, Lnw4;

    .line 303
    .line 304
    if-eqz v0, :cond_7

    .line 305
    .line 306
    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    :cond_7
    move/from16 v1, p0

    .line 310
    .line 311
    move-object/from16 v4, v22

    .line 312
    .line 313
    move-object/from16 v2, v23

    .line 314
    .line 315
    goto/16 :goto_1

    .line 316
    .line 317
    :cond_8
    move/from16 p0, v1

    .line 318
    .line 319
    move-object/from16 v23, v2

    .line 320
    .line 321
    invoke-static {v12}, Lep3;->q0(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    :try_start_5
    new-instance v0, Lorg/json/JSONObject;

    .line 326
    .line 327
    sget-object v2, Lcom/box/app/AppApplication;->i:Landroid/content/Context;

    .line 328
    .line 329
    invoke-static {}, Lnn;->t()Landroid/content/Context;

    .line 330
    .line 331
    .line 332
    move-result-object v2

    .line 333
    const/4 v3, 0x0

    .line 334
    invoke-virtual {v2, v5, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 335
    .line 336
    .line 337
    move-result-object v2

    .line 338
    const-string v3, "ignored_versions"

    .line 339
    .line 340
    invoke-interface {v2, v3, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v2

    .line 344
    if-nez v2, :cond_9

    .line 345
    .line 346
    move-object/from16 v2, v23

    .line 347
    .line 348
    :cond_9
    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 349
    .line 350
    .line 351
    goto :goto_6

    .line 352
    :catchall_5
    move-exception v0

    .line 353
    new-instance v2, Lrm5;

    .line 354
    .line 355
    invoke-direct {v2, v0}, Lrm5;-><init>(Ljava/lang/Throwable;)V

    .line 356
    .line 357
    .line 358
    move-object v0, v2

    .line 359
    :goto_6
    new-instance v2, Lorg/json/JSONObject;

    .line 360
    .line 361
    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 362
    .line 363
    .line 364
    instance-of v3, v0, Lrm5;

    .line 365
    .line 366
    if-eqz v3, :cond_a

    .line 367
    .line 368
    move-object v0, v2

    .line 369
    :cond_a
    check-cast v0, Lorg/json/JSONObject;

    .line 370
    .line 371
    invoke-virtual {v0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    .line 372
    .line 373
    .line 374
    move-result-object v2

    .line 375
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 376
    .line 377
    .line 378
    invoke-static {v2}, Lm86;->i0(Ljava/util/Iterator;)Li86;

    .line 379
    .line 380
    .line 381
    move-result-object v2

    .line 382
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 383
    .line 384
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 385
    .line 386
    .line 387
    check-cast v2, Lv71;

    .line 388
    .line 389
    invoke-virtual {v2}, Lv71;->iterator()Ljava/util/Iterator;

    .line 390
    .line 391
    .line 392
    move-result-object v2

    .line 393
    :goto_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 394
    .line 395
    .line 396
    move-result v4

    .line 397
    if-eqz v4, :cond_b

    .line 398
    .line 399
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 400
    .line 401
    .line 402
    move-result-object v4

    .line 403
    move-object v5, v4

    .line 404
    check-cast v5, Ljava/lang/String;

    .line 405
    .line 406
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 407
    .line 408
    .line 409
    move-result-object v5

    .line 410
    invoke-interface {v3, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 411
    .line 412
    .line 413
    goto :goto_7

    .line 414
    :cond_b
    new-instance v11, Lrd1;

    .line 415
    .line 416
    sget-object v14, Lcy1;->i:Lcy1;

    .line 417
    .line 418
    const/16 v0, 0x14

    .line 419
    .line 420
    and-int/lit8 v2, v0, 0x1

    .line 421
    .line 422
    if-eqz v2, :cond_c

    .line 423
    .line 424
    sget-object v10, Lby1;->i:Lby1;

    .line 425
    .line 426
    :cond_c
    move-object v12, v10

    .line 427
    and-int/lit8 v2, v0, 0x2

    .line 428
    .line 429
    if-eqz v2, :cond_d

    .line 430
    .line 431
    move-object v13, v14

    .line 432
    goto :goto_8

    .line 433
    :cond_d
    move-object v13, v1

    .line 434
    :goto_8
    and-int/lit8 v0, v0, 0x8

    .line 435
    .line 436
    if-eqz v0, :cond_e

    .line 437
    .line 438
    move-object v15, v14

    .line 439
    goto :goto_9

    .line 440
    :cond_e
    move-object v15, v3

    .line 441
    :goto_9
    move-object/from16 v16, v14

    .line 442
    .line 443
    invoke-direct/range {v11 .. v16}, Lrd1;-><init>(Ljava/util/List;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V

    .line 444
    .line 445
    .line 446
    invoke-direct {v6, v7, v8, v11}, Ljd1;-><init>(Lca1;Lvw0;Lrd1;)V

    .line 447
    .line 448
    .line 449
    return-object v6

    .line 450
    :pswitch_9
    sget-object v0, Lxc7;->a:Lxc7;

    .line 451
    .line 452
    return-object v0

    .line 453
    :pswitch_a
    sget-object v0, Lxc7;->a:Lxc7;

    .line 454
    .line 455
    return-object v0

    .line 456
    :pswitch_b
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 457
    .line 458
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 459
    .line 460
    .line 461
    move-result-object v0

    .line 462
    return-object v0

    .line 463
    :pswitch_c
    sget-object v0, Lxc7;->a:Lxc7;

    .line 464
    .line 465
    return-object v0

    .line 466
    :pswitch_d
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 467
    .line 468
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 469
    .line 470
    .line 471
    move-result-object v0

    .line 472
    return-object v0

    .line 473
    :pswitch_e
    sget-object v0, Lxc7;->a:Lxc7;

    .line 474
    .line 475
    return-object v0

    .line 476
    :pswitch_f
    move-object/from16 v23, v2

    .line 477
    .line 478
    invoke-static/range {v23 .. v23}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 479
    .line 480
    .line 481
    move-result-object v0

    .line 482
    return-object v0

    .line 483
    :pswitch_10
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 484
    .line 485
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 486
    .line 487
    .line 488
    move-result-object v0

    .line 489
    return-object v0

    .line 490
    :pswitch_11
    sget-object v0, Lxc7;->a:Lxc7;

    .line 491
    .line 492
    return-object v0

    .line 493
    :pswitch_12
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 494
    .line 495
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 496
    .line 497
    .line 498
    move-result-object v0

    .line 499
    return-object v0

    .line 500
    :pswitch_13
    move-object/from16 v23, v2

    .line 501
    .line 502
    invoke-static/range {v23 .. v23}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 503
    .line 504
    .line 505
    move-result-object v0

    .line 506
    return-object v0

    .line 507
    :pswitch_14
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 508
    .line 509
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 510
    .line 511
    .line 512
    move-result-object v0

    .line 513
    return-object v0

    .line 514
    :pswitch_15
    sget-object v0, Lxc7;->a:Lxc7;

    .line 515
    .line 516
    return-object v0

    .line 517
    :pswitch_16
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 518
    .line 519
    .line 520
    move-result-object v0

    .line 521
    invoke-static {v0}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 522
    .line 523
    .line 524
    move-result-object v0

    .line 525
    return-object v0

    .line 526
    :pswitch_17
    const-string v0, "Unexpected call to default provider"

    .line 527
    .line 528
    invoke-static {v0}, Lm21;->b(Ljava/lang/String;)Ljava/lang/Void;

    .line 529
    .line 530
    .line 531
    new-instance v0, Luy0;

    .line 532
    .line 533
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 534
    .line 535
    .line 536
    throw v0

    .line 537
    :pswitch_18
    move-object/from16 v22, v4

    .line 538
    .line 539
    const-string v0, "LocalTextToolbar"

    .line 540
    .line 541
    invoke-static {v0}, Lc31;->b(Ljava/lang/String;)V

    .line 542
    .line 543
    .line 544
    throw v22

    .line 545
    :pswitch_19
    move-object/from16 v22, v4

    .line 546
    .line 547
    return-object v22

    .line 548
    :pswitch_1a
    move-object/from16 v22, v4

    .line 549
    .line 550
    const-string v0, "LocalProvidableLocaleList"

    .line 551
    .line 552
    invoke-static {v0}, Lc31;->b(Ljava/lang/String;)V

    .line 553
    .line 554
    .line 555
    throw v22

    .line 556
    :pswitch_1b
    move-object/from16 v22, v4

    .line 557
    .line 558
    const-string v0, "LocalLayoutDirection"

    .line 559
    .line 560
    invoke-static {v0}, Lc31;->b(Ljava/lang/String;)V

    .line 561
    .line 562
    .line 563
    throw v22

    .line 564
    nop

    .line 565
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
