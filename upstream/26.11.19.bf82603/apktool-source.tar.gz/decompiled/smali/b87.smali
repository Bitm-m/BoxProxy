.class public interface abstract Lb87;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lbj4;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lbj4;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lb87;->a:Lbj4;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public abstract a(Lew2;)Lf87;
.end method
