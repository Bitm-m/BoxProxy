.class public final Lam2;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public j:Lqm0;

.field public k:I

.field public l:I

.field public m:I

.field public n:B

.field public synthetic o:Ljava/lang/Object;

.field public p:Ljava/util/List;

.field public q:Lra2;

.field public r:Ljava/io/Serializable;

.field public final synthetic s:Lra2;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lxl2;Lea1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lam2;->i:B

    .line 3
    .line 4
    iput-object p1, p0, Lam2;->r:Ljava/io/Serializable;

    .line 5
    .line 6
    iput-object p2, p0, Lam2;->s:Lra2;

    .line 7
    .line 8
    const/4 p1, 0x2

    .line 9
    invoke-direct {p0, p1, p3}, Lvr6;-><init>(ILea1;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>(Ljava/util/List;Lja2;Lea1;)V
    .locals 1

    const/4 v0, 0x1

    iput-byte v0, p0, Lam2;->i:B

    .line 13
    iput-object p1, p0, Lam2;->p:Ljava/util/List;

    iput-object p2, p0, Lam2;->s:Lra2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lvr6;-><init>(ILea1;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 2

    .line 1
    iget-byte v0, p0, Lam2;->i:B

    .line 2
    .line 3
    iget-object v1, p0, Lam2;->s:Lra2;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v0, Lam2;

    .line 9
    .line 10
    iget-object p0, p0, Lam2;->p:Ljava/util/List;

    .line 11
    .line 12
    check-cast v1, Lja2;

    .line 13
    .line 14
    invoke-direct {v0, p0, v1, p2}, Lam2;-><init>(Ljava/util/List;Lja2;Lea1;)V

    .line 15
    .line 16
    .line 17
    iput-object p1, v0, Lam2;->o:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_0
    new-instance v0, Lam2;

    .line 21
    .line 22
    iget-object p0, p0, Lam2;->r:Ljava/io/Serializable;

    .line 23
    .line 24
    check-cast p0, Ljava/util/ArrayList;

    .line 25
    .line 26
    check-cast v1, Lxl2;

    .line 27
    .line 28
    invoke-direct {v0, p0, v1, p2}, Lam2;-><init>(Ljava/util/ArrayList;Lxl2;Lea1;)V

    .line 29
    .line 30
    .line 31
    iput-object p1, v0, Lam2;->o:Ljava/lang/Object;

    .line 32
    .line 33
    return-object v0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lam2;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    check-cast p1, Lnf1;

    .line 6
    .line 7
    check-cast p2, Lea1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lam2;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lam2;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lam2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Lam2;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lam2;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lam2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lam2;->i:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object v3, v0, Lam2;->s:Lra2;

    .line 7
    .line 8
    const/16 v4, 0xa

    .line 9
    .line 10
    const/4 v5, 0x6

    .line 11
    const-string v6, "call to \'resume\' before \'invoke\' with coroutine"

    .line 12
    .line 13
    sget-object v7, Lof1;->i:Lof1;

    .line 14
    .line 15
    const/4 v8, 0x1

    .line 16
    const/4 v9, 0x2

    .line 17
    const/4 v10, 0x0

    .line 18
    packed-switch v1, :pswitch_data_0

    .line 19
    .line 20
    .line 21
    iget-object v1, v0, Lam2;->p:Ljava/util/List;

    .line 22
    .line 23
    iget-object v11, v0, Lam2;->o:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v11, Lnf1;

    .line 26
    .line 27
    iget-byte v12, v0, Lam2;->n:B

    .line 28
    .line 29
    if-eqz v12, :cond_2

    .line 30
    .line 31
    if-eq v12, v8, :cond_1

    .line 32
    .line 33
    if-ne v12, v9, :cond_0

    .line 34
    .line 35
    iget v1, v0, Lam2;->l:I

    .line 36
    .line 37
    iget v2, v0, Lam2;->k:I

    .line 38
    .line 39
    iget-object v3, v0, Lam2;->q:Lra2;

    .line 40
    .line 41
    check-cast v3, Lvr6;

    .line 42
    .line 43
    check-cast v3, Lja2;

    .line 44
    .line 45
    iget-object v4, v0, Lam2;->j:Lqm0;

    .line 46
    .line 47
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    move-object v5, v4

    .line 51
    move-object v4, v3

    .line 52
    goto/16 :goto_3

    .line 53
    .line 54
    :cond_0
    invoke-static {v6}, La02;->d(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    move-object v7, v10

    .line 58
    goto/16 :goto_4

    .line 59
    .line 60
    :cond_1
    iget v1, v0, Lam2;->m:I

    .line 61
    .line 62
    iget v2, v0, Lam2;->l:I

    .line 63
    .line 64
    iget v3, v0, Lam2;->k:I

    .line 65
    .line 66
    iget-object v4, v0, Lam2;->r:Ljava/io/Serializable;

    .line 67
    .line 68
    check-cast v4, Lvr6;

    .line 69
    .line 70
    check-cast v4, Lja2;

    .line 71
    .line 72
    iget-object v5, v0, Lam2;->q:Lra2;

    .line 73
    .line 74
    check-cast v5, Lvr6;

    .line 75
    .line 76
    check-cast v5, Lja2;

    .line 77
    .line 78
    iget-object v6, v0, Lam2;->j:Lqm0;

    .line 79
    .line 80
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    move v11, v2

    .line 84
    move v2, v1

    .line 85
    move v1, v11

    .line 86
    move-object v11, v6

    .line 87
    move-object v6, v4

    .line 88
    move v4, v3

    .line 89
    move-object/from16 v3, p1

    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    const v6, 0x7fffffff

    .line 96
    .line 97
    .line 98
    invoke-static {v6, v5, v10}, Lfj;->h(IILaf0;)Lff0;

    .line 99
    .line 100
    .line 101
    move-result-object v5

    .line 102
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 107
    .line 108
    .line 109
    move-result v12

    .line 110
    if-eqz v12, :cond_3

    .line 111
    .line 112
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v12

    .line 116
    check-cast v12, Lib4;

    .line 117
    .line 118
    sget-object v13, Lao1;->a:Lck1;

    .line 119
    .line 120
    sget-object v13, Luj1;->k:Luj1;

    .line 121
    .line 122
    new-instance v14, La4;

    .line 123
    .line 124
    invoke-direct {v14, v5, v12, v10, v4}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 125
    .line 126
    .line 127
    invoke-static {v11, v13, v10, v14, v9}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 128
    .line 129
    .line 130
    goto :goto_0

    .line 131
    :cond_3
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    check-cast v3, Lja2;

    .line 136
    .line 137
    move-object v4, v3

    .line 138
    :goto_1
    if-ge v2, v1, :cond_4

    .line 139
    .line 140
    iput-object v10, v0, Lam2;->o:Ljava/lang/Object;

    .line 141
    .line 142
    iput-object v5, v0, Lam2;->j:Lqm0;

    .line 143
    .line 144
    move-object v3, v4

    .line 145
    check-cast v3, Lvr6;

    .line 146
    .line 147
    iput-object v3, v0, Lam2;->q:Lra2;

    .line 148
    .line 149
    iput-object v3, v0, Lam2;->r:Ljava/io/Serializable;

    .line 150
    .line 151
    iput v1, v0, Lam2;->k:I

    .line 152
    .line 153
    iput v2, v0, Lam2;->l:I

    .line 154
    .line 155
    iput v2, v0, Lam2;->m:I

    .line 156
    .line 157
    iput-byte v8, v0, Lam2;->n:B

    .line 158
    .line 159
    invoke-interface {v5, v0}, Lqm0;->r(Lea1;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    if-eq v3, v7, :cond_5

    .line 164
    .line 165
    move-object v6, v4

    .line 166
    move-object v11, v5

    .line 167
    move v4, v1

    .line 168
    move v1, v2

    .line 169
    move-object v5, v6

    .line 170
    :goto_2
    iput-object v10, v0, Lam2;->o:Ljava/lang/Object;

    .line 171
    .line 172
    iput-object v11, v0, Lam2;->j:Lqm0;

    .line 173
    .line 174
    move-object v12, v5

    .line 175
    check-cast v12, Lvr6;

    .line 176
    .line 177
    iput-object v12, v0, Lam2;->q:Lra2;

    .line 178
    .line 179
    iput-object v10, v0, Lam2;->r:Ljava/io/Serializable;

    .line 180
    .line 181
    iput v4, v0, Lam2;->k:I

    .line 182
    .line 183
    iput v1, v0, Lam2;->l:I

    .line 184
    .line 185
    iput v2, v0, Lam2;->m:I

    .line 186
    .line 187
    iput-byte v9, v0, Lam2;->n:B

    .line 188
    .line 189
    invoke-interface {v6, v3, v0}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    if-eq v2, v7, :cond_5

    .line 194
    .line 195
    move v2, v4

    .line 196
    move-object v4, v5

    .line 197
    move-object v5, v11

    .line 198
    :goto_3
    add-int/2addr v1, v8

    .line 199
    move/from16 v16, v2

    .line 200
    .line 201
    move v2, v1

    .line 202
    move/from16 v1, v16

    .line 203
    .line 204
    goto :goto_1

    .line 205
    :cond_4
    invoke-interface {v5, v10}, Lg86;->d(Ljava/lang/Throwable;)Z

    .line 206
    .line 207
    .line 208
    move-result v0

    .line 209
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 210
    .line 211
    .line 212
    move-result-object v7

    .line 213
    :cond_5
    :goto_4
    return-object v7

    .line 214
    :pswitch_0
    iget-object v1, v0, Lam2;->r:Ljava/io/Serializable;

    .line 215
    .line 216
    check-cast v1, Ljava/util/ArrayList;

    .line 217
    .line 218
    iget-object v11, v0, Lam2;->o:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v11, Lnf1;

    .line 221
    .line 222
    iget-byte v12, v0, Lam2;->n:B

    .line 223
    .line 224
    if-eqz v12, :cond_8

    .line 225
    .line 226
    if-eq v12, v8, :cond_7

    .line 227
    .line 228
    if-ne v12, v9, :cond_6

    .line 229
    .line 230
    iget v1, v0, Lam2;->l:I

    .line 231
    .line 232
    iget v2, v0, Lam2;->k:I

    .line 233
    .line 234
    iget-object v3, v0, Lam2;->q:Lra2;

    .line 235
    .line 236
    check-cast v3, Lka2;

    .line 237
    .line 238
    iget-object v5, v0, Lam2;->p:Ljava/util/List;

    .line 239
    .line 240
    iget-object v6, v0, Lam2;->j:Lqm0;

    .line 241
    .line 242
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 243
    .line 244
    .line 245
    move-object v11, v5

    .line 246
    move-object v5, v6

    .line 247
    goto/16 :goto_9

    .line 248
    .line 249
    :cond_6
    invoke-static {v6}, La02;->d(Ljava/lang/String;)V

    .line 250
    .line 251
    .line 252
    move-object v7, v10

    .line 253
    goto/16 :goto_b

    .line 254
    .line 255
    :cond_7
    iget v1, v0, Lam2;->m:I

    .line 256
    .line 257
    iget v2, v0, Lam2;->l:I

    .line 258
    .line 259
    iget v3, v0, Lam2;->k:I

    .line 260
    .line 261
    iget-object v5, v0, Lam2;->q:Lra2;

    .line 262
    .line 263
    check-cast v5, Lka2;

    .line 264
    .line 265
    iget-object v6, v0, Lam2;->p:Ljava/util/List;

    .line 266
    .line 267
    iget-object v11, v0, Lam2;->j:Lqm0;

    .line 268
    .line 269
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 270
    .line 271
    .line 272
    move v12, v2

    .line 273
    move v2, v1

    .line 274
    move v1, v12

    .line 275
    move-object v12, v11

    .line 276
    move-object v11, v6

    .line 277
    move-object/from16 v6, p1

    .line 278
    .line 279
    goto :goto_8

    .line 280
    :cond_8
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 284
    .line 285
    .line 286
    move-result v6

    .line 287
    invoke-static {v6, v5, v10}, Lfj;->h(IILaf0;)Lff0;

    .line 288
    .line 289
    .line 290
    move-result-object v5

    .line 291
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 292
    .line 293
    .line 294
    move-result-object v6

    .line 295
    move v12, v2

    .line 296
    :goto_5
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 297
    .line 298
    .line 299
    move-result v13

    .line 300
    if-eqz v13, :cond_a

    .line 301
    .line 302
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v13

    .line 306
    add-int/lit8 v14, v12, 0x1

    .line 307
    .line 308
    if-ltz v12, :cond_9

    .line 309
    .line 310
    check-cast v13, Lh83;

    .line 311
    .line 312
    new-instance v15, Lzl2;

    .line 313
    .line 314
    invoke-direct {v15, v5, v12, v13, v10}, Lzl2;-><init>(Lff0;ILh83;Lea1;)V

    .line 315
    .line 316
    .line 317
    const/4 v12, 0x3

    .line 318
    invoke-static {v11, v10, v10, v15, v12}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 319
    .line 320
    .line 321
    move v12, v14

    .line 322
    goto :goto_5

    .line 323
    :cond_9
    invoke-static {}, Lgn;->e0()V

    .line 324
    .line 325
    .line 326
    throw v10

    .line 327
    :cond_a
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 328
    .line 329
    .line 330
    move-result v6

    .line 331
    new-instance v11, Ljava/util/ArrayList;

    .line 332
    .line 333
    invoke-direct {v11, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 334
    .line 335
    .line 336
    move v12, v2

    .line 337
    :goto_6
    if-ge v12, v6, :cond_b

    .line 338
    .line 339
    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 340
    .line 341
    .line 342
    add-int/lit8 v12, v12, 0x1

    .line 343
    .line 344
    goto :goto_6

    .line 345
    :cond_b
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 346
    .line 347
    .line 348
    move-result v1

    .line 349
    check-cast v3, Lxl2;

    .line 350
    .line 351
    :goto_7
    if-ge v2, v1, :cond_c

    .line 352
    .line 353
    iput-object v10, v0, Lam2;->o:Ljava/lang/Object;

    .line 354
    .line 355
    iput-object v5, v0, Lam2;->j:Lqm0;

    .line 356
    .line 357
    iput-object v11, v0, Lam2;->p:Ljava/util/List;

    .line 358
    .line 359
    iput-object v3, v0, Lam2;->q:Lra2;

    .line 360
    .line 361
    iput v1, v0, Lam2;->k:I

    .line 362
    .line 363
    iput v2, v0, Lam2;->l:I

    .line 364
    .line 365
    iput v2, v0, Lam2;->m:I

    .line 366
    .line 367
    iput-byte v8, v0, Lam2;->n:B

    .line 368
    .line 369
    invoke-interface {v5, v0}, Lqm0;->r(Lea1;)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v6

    .line 373
    if-eq v6, v7, :cond_e

    .line 374
    .line 375
    move-object v12, v5

    .line 376
    move-object v5, v3

    .line 377
    move v3, v1

    .line 378
    move v1, v2

    .line 379
    :goto_8
    check-cast v6, Lnw4;

    .line 380
    .line 381
    iget-object v13, v6, Lnw4;->i:Ljava/lang/Object;

    .line 382
    .line 383
    check-cast v13, Ljava/lang/Number;

    .line 384
    .line 385
    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    .line 386
    .line 387
    .line 388
    move-result v13

    .line 389
    iget-object v6, v6, Lnw4;->j:Ljava/lang/Object;

    .line 390
    .line 391
    check-cast v6, Lvl2;

    .line 392
    .line 393
    invoke-interface {v11, v13, v6}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    new-instance v14, Ljava/lang/Integer;

    .line 397
    .line 398
    invoke-direct {v14, v13}, Ljava/lang/Integer;-><init>(I)V

    .line 399
    .line 400
    .line 401
    iput-object v10, v0, Lam2;->o:Ljava/lang/Object;

    .line 402
    .line 403
    iput-object v12, v0, Lam2;->j:Lqm0;

    .line 404
    .line 405
    iput-object v11, v0, Lam2;->p:Ljava/util/List;

    .line 406
    .line 407
    iput-object v5, v0, Lam2;->q:Lra2;

    .line 408
    .line 409
    iput v3, v0, Lam2;->k:I

    .line 410
    .line 411
    iput v1, v0, Lam2;->l:I

    .line 412
    .line 413
    iput v2, v0, Lam2;->m:I

    .line 414
    .line 415
    iput-byte v9, v0, Lam2;->n:B

    .line 416
    .line 417
    invoke-interface {v5, v14, v6, v0}, Lka2;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v2

    .line 421
    if-eq v2, v7, :cond_e

    .line 422
    .line 423
    move v2, v3

    .line 424
    move-object v3, v5

    .line 425
    move-object v5, v12

    .line 426
    :goto_9
    add-int/2addr v1, v8

    .line 427
    move/from16 v16, v2

    .line 428
    .line 429
    move v2, v1

    .line 430
    move/from16 v1, v16

    .line 431
    .line 432
    goto :goto_7

    .line 433
    :cond_c
    invoke-interface {v5, v10}, Lg86;->d(Ljava/lang/Throwable;)Z

    .line 434
    .line 435
    .line 436
    new-instance v7, Ljava/util/ArrayList;

    .line 437
    .line 438
    invoke-static {v11, v4}, Ljv0;->h0(Ljava/lang/Iterable;I)I

    .line 439
    .line 440
    .line 441
    move-result v0

    .line 442
    invoke-direct {v7, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 443
    .line 444
    .line 445
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 446
    .line 447
    .line 448
    move-result-object v0

    .line 449
    :goto_a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 450
    .line 451
    .line 452
    move-result v1

    .line 453
    if-eqz v1, :cond_e

    .line 454
    .line 455
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v1

    .line 459
    check-cast v1, Lvl2;

    .line 460
    .line 461
    if-nez v1, :cond_d

    .line 462
    .line 463
    sget-object v1, Ltl2;->a:Ltl2;

    .line 464
    .line 465
    :cond_d
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 466
    .line 467
    .line 468
    goto :goto_a

    .line 469
    :cond_e
    :goto_b
    return-object v7

    .line 470
    nop

    .line 471
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
