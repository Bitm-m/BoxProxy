.class public final synthetic Lao6;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lj44;

.field public final synthetic k:Lj44;

.field public final synthetic l:Ljava/util/ArrayList;

.field public final synthetic m:Lai7;


# direct methods
.method public synthetic constructor <init>(Lj44;Lj44;Ljava/util/ArrayList;Lai7;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lao6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lao6;->j:Lj44;

    .line 4
    .line 5
    iput-object p2, p0, Lao6;->k:Lj44;

    .line 6
    .line 7
    iput-object p3, p0, Lao6;->l:Ljava/util/ArrayList;

    .line 8
    .line 9
    iput-object p4, p0, Lao6;->m:Lai7;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lao6;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    sget-object v3, Lg21;->a:Ley0;

    .line 8
    .line 9
    const v4, 0x7f0f0551

    .line 10
    .line 11
    .line 12
    const/16 v5, 0x10

    .line 13
    .line 14
    iget-object v6, v0, Lao6;->m:Lai7;

    .line 15
    .line 16
    iget-object v7, v0, Lao6;->l:Ljava/util/ArrayList;

    .line 17
    .line 18
    iget-object v8, v0, Lao6;->k:Lj44;

    .line 19
    .line 20
    iget-object v0, v0, Lao6;->j:Lj44;

    .line 21
    .line 22
    const/4 v9, 0x1

    .line 23
    const/4 v10, 0x0

    .line 24
    packed-switch v1, :pswitch_data_0

    .line 25
    .line 26
    .line 27
    move-object/from16 v1, p1

    .line 28
    .line 29
    check-cast v1, Lbc3;

    .line 30
    .line 31
    move-object/from16 v14, p2

    .line 32
    .line 33
    check-cast v14, Lib2;

    .line 34
    .line 35
    move-object/from16 v11, p3

    .line 36
    .line 37
    check-cast v11, Ljava/lang/Integer;

    .line 38
    .line 39
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 40
    .line 41
    .line 42
    move-result v11

    .line 43
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    and-int/lit8 v1, v11, 0x11

    .line 47
    .line 48
    if-eq v1, v5, :cond_0

    .line 49
    .line 50
    move v10, v9

    .line 51
    :cond_0
    and-int/2addr v11, v9

    .line 52
    invoke-virtual {v14, v11, v10}, Lib2;->X(IZ)Z

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_3

    .line 57
    .line 58
    invoke-static {v4, v14}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v11

    .line 62
    invoke-virtual {v14, v0}, Lib2;->g(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    invoke-virtual {v14, v8}, Lib2;->g(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    or-int/2addr v1, v4

    .line 71
    invoke-virtual {v14}, Lib2;->S()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    if-nez v1, :cond_1

    .line 76
    .line 77
    if-ne v4, v3, :cond_2

    .line 78
    .line 79
    :cond_1
    new-instance v4, Lmi7;

    .line 80
    .line 81
    const/4 v1, 0x2

    .line 82
    invoke-direct {v4, v0, v8, v1}, Lmi7;-><init>(Lj44;Lj44;B)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v14, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    :cond_2
    move-object v12, v4

    .line 89
    check-cast v12, Lu92;

    .line 90
    .line 91
    new-instance v1, Lbo6;

    .line 92
    .line 93
    invoke-direct {v1, v7, v6, v0, v9}, Lbo6;-><init>(Ljava/util/ArrayList;Lai7;Lj44;B)V

    .line 94
    .line 95
    .line 96
    const v0, 0x14c01bc5

    .line 97
    .line 98
    .line 99
    invoke-static {v0, v1, v14}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 100
    .line 101
    .line 102
    move-result-object v13

    .line 103
    const/16 v15, 0x180

    .line 104
    .line 105
    const/16 v16, 0x0

    .line 106
    .line 107
    invoke-static/range {v11 .. v16}, Lcq6;->b(Ljava/lang/String;Lu92;Lyz0;Lib2;II)V

    .line 108
    .line 109
    .line 110
    goto :goto_0

    .line 111
    :cond_3
    invoke-virtual {v14}, Lib2;->a0()V

    .line 112
    .line 113
    .line 114
    :goto_0
    return-object v2

    .line 115
    :pswitch_0
    move-object/from16 v1, p1

    .line 116
    .line 117
    check-cast v1, Lbc3;

    .line 118
    .line 119
    move-object/from16 v14, p2

    .line 120
    .line 121
    check-cast v14, Lib2;

    .line 122
    .line 123
    move-object/from16 v11, p3

    .line 124
    .line 125
    check-cast v11, Ljava/lang/Integer;

    .line 126
    .line 127
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 128
    .line 129
    .line 130
    move-result v11

    .line 131
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    and-int/lit8 v1, v11, 0x11

    .line 135
    .line 136
    if-eq v1, v5, :cond_4

    .line 137
    .line 138
    move v1, v9

    .line 139
    goto :goto_1

    .line 140
    :cond_4
    move v1, v10

    .line 141
    :goto_1
    and-int/2addr v11, v9

    .line 142
    invoke-virtual {v14, v11, v1}, Lib2;->X(IZ)Z

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    if-eqz v1, :cond_7

    .line 147
    .line 148
    invoke-static {v4, v14}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v11

    .line 152
    invoke-virtual {v14, v0}, Lib2;->g(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    invoke-virtual {v14, v8}, Lib2;->g(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v4

    .line 160
    or-int/2addr v1, v4

    .line 161
    invoke-virtual {v14}, Lib2;->S()Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v4

    .line 165
    if-nez v1, :cond_5

    .line 166
    .line 167
    if-ne v4, v3, :cond_6

    .line 168
    .line 169
    :cond_5
    new-instance v4, Lwp0;

    .line 170
    .line 171
    const/16 v1, 0x1a

    .line 172
    .line 173
    invoke-direct {v4, v0, v8, v1}, Lwp0;-><init>(Lj44;Lj44;B)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v14, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_6
    move-object v12, v4

    .line 180
    check-cast v12, Lu92;

    .line 181
    .line 182
    new-instance v1, Lbo6;

    .line 183
    .line 184
    invoke-direct {v1, v7, v6, v0, v10}, Lbo6;-><init>(Ljava/util/ArrayList;Lai7;Lj44;B)V

    .line 185
    .line 186
    .line 187
    const v0, 0x201d8dff

    .line 188
    .line 189
    .line 190
    invoke-static {v0, v1, v14}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 191
    .line 192
    .line 193
    move-result-object v13

    .line 194
    const/16 v15, 0x180

    .line 195
    .line 196
    const/16 v16, 0x0

    .line 197
    .line 198
    invoke-static/range {v11 .. v16}, Lcq6;->b(Ljava/lang/String;Lu92;Lyz0;Lib2;II)V

    .line 199
    .line 200
    .line 201
    goto :goto_2

    .line 202
    :cond_7
    invoke-virtual {v14}, Lib2;->a0()V

    .line 203
    .line 204
    .line 205
    :goto_2
    return-object v2

    .line 206
    nop

    .line 207
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
