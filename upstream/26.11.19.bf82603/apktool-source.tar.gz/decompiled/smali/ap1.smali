.class public final Lap1;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:I

.field public synthetic k:Ljava/lang/Object;


# direct methods
.method public constructor <init>(JLea1;)V
    .locals 1

    const/4 v0, 0x0

    iput-byte v0, p0, Lap1;->i:B

    long-to-int p1, p1

    .line 13
    iput p1, p0, Lap1;->j:I

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lvr6;-><init>(ILea1;)V

    return-void
.end method

.method public constructor <init>(Lyb3;ILea1;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lap1;->i:B

    .line 3
    .line 4
    iput-object p1, p0, Lap1;->k:Ljava/lang/Object;

    .line 5
    .line 6
    iput p2, p0, Lap1;->j:I

    .line 7
    .line 8
    const/4 p1, 0x2

    .line 9
    invoke-direct {p0, p1, p3}, Lvr6;-><init>(ILea1;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 3

    .line 1
    iget-byte v0, p0, Lap1;->i:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p1, Lap1;

    .line 7
    .line 8
    iget-object v0, p0, Lap1;->k:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lyb3;

    .line 11
    .line 12
    iget p0, p0, Lap1;->j:I

    .line 13
    .line 14
    invoke-direct {p1, v0, p0, p2}, Lap1;-><init>(Lyb3;ILea1;)V

    .line 15
    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_0
    new-instance v0, Lap1;

    .line 19
    .line 20
    iget p0, p0, Lap1;->j:I

    .line 21
    .line 22
    int-to-long v1, p0

    .line 23
    invoke-direct {v0, v1, v2, p2}, Lap1;-><init>(JLea1;)V

    .line 24
    .line 25
    .line 26
    iput-object p1, v0, Lap1;->k:Ljava/lang/Object;

    .line 27
    .line 28
    return-object v0

    .line 29
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lap1;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lo36;

    .line 9
    .line 10
    check-cast p2, Lea1;

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lap1;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lap1;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lap1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    check-cast p1, Ljava/io/InputStream;

    .line 23
    .line 24
    check-cast p2, Lea1;

    .line 25
    .line 26
    invoke-virtual {p0, p1, p2}, Lap1;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lap1;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, Lap1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lap1;->i:B

    .line 2
    .line 3
    iget v1, p0, Lap1;->j:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p0, p0, Lap1;->k:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Lyb3;

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    const/4 v0, 0x1

    .line 17
    invoke-virtual {p0, v1, p1, v0}, Lyb3;->i(IIZ)V

    .line 18
    .line 19
    .line 20
    sget-object p0, Lxc7;->a:Lxc7;

    .line 21
    .line 22
    return-object p0

    .line 23
    :pswitch_0
    iget-object p0, p0, Lap1;->k:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p0, Ljava/io/InputStream;

    .line 26
    .line 27
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    int-to-long v0, v1

    .line 31
    const/4 p1, 0x0

    .line 32
    invoke-static {p0, v0, v1, p1}, Lpm;->H(Ljava/io/InputStream;JLt81;)[B

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
