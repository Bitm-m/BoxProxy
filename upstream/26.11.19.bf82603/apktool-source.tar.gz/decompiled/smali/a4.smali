.class public final La4;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public j:B

.field public k:Ljava/lang/Object;

.field public l:Ljava/lang/Object;

.field public m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILea1;B)V
    .locals 0

    .line 13
    iput-byte p3, p0, La4;->i:B

    invoke-direct {p0, p1, p2}, Lvr6;-><init>(ILea1;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lea1;B)V
    .locals 0

    .line 12
    iput-byte p3, p0, La4;->i:B

    iput-object p1, p0, La4;->m:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lvr6;-><init>(ILea1;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, La4;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La4;->l:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, La4;->m:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lvr6;-><init>(ILea1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method private final m(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget-byte v0, p0, La4;->j:B

    .line 2
    .line 3
    const-wide/32 v1, 0xea60

    .line 4
    .line 5
    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    sget-object v6, Lof1;->i:Lof1;

    .line 10
    .line 11
    if-eqz v0, :cond_2

    .line 12
    .line 13
    if-eq v0, v4, :cond_1

    .line 14
    .line 15
    if-ne v0, v3, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v0, Ljava/io/File;

    .line 20
    .line 21
    iget-object p0, p0, La4;->k:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Ljava/lang/String;

    .line 24
    .line 25
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    move-object v10, p0

    .line 29
    goto/16 :goto_3

    .line 30
    .line 31
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 32
    .line 33
    invoke-static {p0}, La02;->d(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const/4 p0, 0x0

    .line 37
    return-object p0

    .line 38
    :cond_1
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v0, Ljava/io/File;

    .line 41
    .line 42
    iget-object v4, p0, La4;->k:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v4, Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    move-object v7, v0

    .line 50
    move-object v0, p1

    .line 51
    move-object p1, v4

    .line 52
    goto :goto_0

    .line 53
    :cond_2
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object p1, Ljz5;->a:Ljz5;

    .line 57
    .line 58
    iget-object p1, p0, La4;->m:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p1, Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {p1}, Ljz5;->k(Ljava/lang/String;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-static {p1}, Ljz5;->o(Ljava/lang/String;)Lgv;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    iget-object v7, v0, Lgv;->a:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v7, Ljava/io/File;

    .line 73
    .line 74
    if-nez v7, :cond_4

    .line 75
    .line 76
    new-instance v8, Lgv;

    .line 77
    .line 78
    iget-object p0, v0, Lgv;->b:Ljava/lang/String;

    .line 79
    .line 80
    if-nez p0, :cond_3

    .line 81
    .line 82
    const p0, 0x7f0f00c9

    .line 83
    .line 84
    .line 85
    new-array p1, v5, [Ljava/lang/Object;

    .line 86
    .line 87
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    :cond_3
    move-object v10, p0

    .line 92
    const/4 v12, 0x0

    .line 93
    const/16 v13, 0xd

    .line 94
    .line 95
    const/4 v9, 0x0

    .line 96
    const/4 v11, 0x0

    .line 97
    invoke-direct/range {v8 .. v13}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 98
    .line 99
    .line 100
    return-object v8

    .line 101
    :cond_4
    sget-object v0, Lto5;->a:Lto5;

    .line 102
    .line 103
    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    invoke-static {v0}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 119
    .line 120
    .line 121
    invoke-static {v8}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v8

    .line 125
    const-string v9, " ]; then echo file; elif [ -d "

    .line 126
    .line 127
    const-string v10, " ]; then echo dir; else echo missing; fi"

    .line 128
    .line 129
    const-string v11, "if [ -f "

    .line 130
    .line 131
    invoke-static {v11, v0, v9, v8, v10}, Lmz1;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    iput-object p1, p0, La4;->k:Ljava/lang/Object;

    .line 136
    .line 137
    iput-object v7, p0, La4;->l:Ljava/lang/Object;

    .line 138
    .line 139
    iput-byte v4, p0, La4;->j:B

    .line 140
    .line 141
    invoke-static {v1, v2, p0, v0}, Lto5;->f(JLea1;Ljava/lang/String;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    if-eq v0, v6, :cond_a

    .line 146
    .line 147
    :goto_0
    check-cast v0, Lko5;

    .line 148
    .line 149
    invoke-virtual {v0}, Lko5;->a()Z

    .line 150
    .line 151
    .line 152
    move-result v4

    .line 153
    iget-object v8, v0, Lko5;->a:Ljava/lang/String;

    .line 154
    .line 155
    if-nez v4, :cond_7

    .line 156
    .line 157
    iget-object p0, v0, Lko5;->b:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {p0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 160
    .line 161
    .line 162
    move-result p1

    .line 163
    if-nez p1, :cond_5

    .line 164
    .line 165
    move-object v8, p0

    .line 166
    :cond_5
    invoke-static {v8}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 167
    .line 168
    .line 169
    move-result p0

    .line 170
    if-eqz p0, :cond_6

    .line 171
    .line 172
    const p0, 0x7f0f0446

    .line 173
    .line 174
    .line 175
    new-array p1, v5, [Ljava/lang/Object;

    .line 176
    .line 177
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v8

    .line 181
    :cond_6
    move-object v2, v8

    .line 182
    new-instance v0, Lgv;

    .line 183
    .line 184
    const/4 v1, 0x0

    .line 185
    const/4 v3, 0x0

    .line 186
    const/4 v4, 0x0

    .line 187
    const/16 v5, 0xd

    .line 188
    .line 189
    invoke-direct/range {v0 .. v5}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 190
    .line 191
    .line 192
    return-object v0

    .line 193
    :cond_7
    invoke-static {v8}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    const v8, 0x1848d

    .line 206
    .line 207
    .line 208
    if-eq v4, v8, :cond_10

    .line 209
    .line 210
    const v8, 0x2ff57c

    .line 211
    .line 212
    .line 213
    if-eq v4, v8, :cond_9

    .line 214
    .line 215
    const p0, 0x3fbe8166

    .line 216
    .line 217
    .line 218
    if-ne v4, p0, :cond_11

    .line 219
    .line 220
    const-string p0, "missing"

    .line 221
    .line 222
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result p0

    .line 226
    if-eqz p0, :cond_11

    .line 227
    .line 228
    new-instance v6, Lgv;

    .line 229
    .line 230
    sget-object p0, Ljz5;->a:Ljz5;

    .line 231
    .line 232
    invoke-static {p1}, Ljz5;->i(Ljava/lang/String;)Z

    .line 233
    .line 234
    .line 235
    move-result p0

    .line 236
    if-eqz p0, :cond_8

    .line 237
    .line 238
    const p0, 0x7f0f04c0

    .line 239
    .line 240
    .line 241
    new-array p1, v5, [Ljava/lang/Object;

    .line 242
    .line 243
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p0

    .line 247
    :goto_1
    move-object v8, p0

    .line 248
    goto :goto_2

    .line 249
    :cond_8
    const p0, 0x7f0f044a

    .line 250
    .line 251
    .line 252
    new-array p1, v5, [Ljava/lang/Object;

    .line 253
    .line 254
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object p0

    .line 258
    goto :goto_1

    .line 259
    :goto_2
    const/4 v10, 0x0

    .line 260
    const/16 v11, 0xd

    .line 261
    .line 262
    const/4 v7, 0x0

    .line 263
    const/4 v9, 0x0

    .line 264
    invoke-direct/range {v6 .. v11}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 265
    .line 266
    .line 267
    return-object v6

    .line 268
    :cond_9
    const-string v4, "file"

    .line 269
    .line 270
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 271
    .line 272
    .line 273
    move-result v0

    .line 274
    if-eqz v0, :cond_11

    .line 275
    .line 276
    sget-object v0, Lto5;->a:Lto5;

    .line 277
    .line 278
    sget-object v0, Ljz5;->a:Ljz5;

    .line 279
    .line 280
    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 285
    .line 286
    .line 287
    invoke-static {v0}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    const-string v4, "wc -c < "

    .line 292
    .line 293
    const-string v8, " 2>/dev/null"

    .line 294
    .line 295
    invoke-static {v4, v0, v8}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    iput-object p1, p0, La4;->k:Ljava/lang/Object;

    .line 300
    .line 301
    iput-object v7, p0, La4;->l:Ljava/lang/Object;

    .line 302
    .line 303
    iput-byte v3, p0, La4;->j:B

    .line 304
    .line 305
    invoke-static {v1, v2, p0, v0}, Lto5;->f(JLea1;Ljava/lang/String;)Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object p0

    .line 309
    if-ne p0, v6, :cond_b

    .line 310
    .line 311
    :cond_a
    return-object v6

    .line 312
    :cond_b
    move-object v10, p1

    .line 313
    move-object v0, v7

    .line 314
    move-object p1, p0

    .line 315
    :goto_3
    check-cast p1, Lko5;

    .line 316
    .line 317
    invoke-virtual {p1}, Lko5;->a()Z

    .line 318
    .line 319
    .line 320
    move-result p0

    .line 321
    iget-object v1, p1, Lko5;->a:Ljava/lang/String;

    .line 322
    .line 323
    if-nez p0, :cond_e

    .line 324
    .line 325
    iget-object p0, p1, Lko5;->b:Ljava/lang/String;

    .line 326
    .line 327
    invoke-static {p0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 328
    .line 329
    .line 330
    move-result p1

    .line 331
    if-nez p1, :cond_c

    .line 332
    .line 333
    move-object v1, p0

    .line 334
    :cond_c
    invoke-static {v1}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 335
    .line 336
    .line 337
    move-result p0

    .line 338
    if-eqz p0, :cond_d

    .line 339
    .line 340
    const p0, 0x7f0f0453

    .line 341
    .line 342
    .line 343
    new-array p1, v5, [Ljava/lang/Object;

    .line 344
    .line 345
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object v1

    .line 349
    :cond_d
    move-object v4, v1

    .line 350
    new-instance v2, Lgv;

    .line 351
    .line 352
    const/4 v3, 0x0

    .line 353
    const/4 v5, 0x0

    .line 354
    const/4 v6, 0x0

    .line 355
    const/16 v7, 0xd

    .line 356
    .line 357
    invoke-direct/range {v2 .. v7}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 358
    .line 359
    .line 360
    return-object v2

    .line 361
    :cond_e
    invoke-static {v1}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 362
    .line 363
    .line 364
    move-result-object p0

    .line 365
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object p0

    .line 369
    invoke-static {p0}, Lin6;->D0(Ljava/lang/String;)Ljava/lang/Long;

    .line 370
    .line 371
    .line 372
    move-result-object p0

    .line 373
    if-eqz p0, :cond_f

    .line 374
    .line 375
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    .line 376
    .line 377
    .line 378
    move-result-wide v11

    .line 379
    new-instance v1, Lgv;

    .line 380
    .line 381
    new-instance v2, Lbz5;

    .line 382
    .line 383
    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object v9

    .line 387
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 388
    .line 389
    .line 390
    sget-object p0, Ljz5;->a:Ljz5;

    .line 391
    .line 392
    invoke-static {v10}, Ljz5;->k(Ljava/lang/String;)Ljava/lang/String;

    .line 393
    .line 394
    .line 395
    move-result-object p0

    .line 396
    const/16 p1, 0x2e

    .line 397
    .line 398
    const-string v0, ""

    .line 399
    .line 400
    invoke-static {p0, p1, v0}, Lbn6;->j1(Ljava/lang/String;CLjava/lang/String;)Ljava/lang/String;

    .line 401
    .line 402
    .line 403
    move-result-object p0

    .line 404
    sget-object p1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 405
    .line 406
    invoke-virtual {p0, p1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 407
    .line 408
    .line 409
    move-result-object p0

    .line 410
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 411
    .line 412
    .line 413
    sget-object p1, Ljz5;->b:Ljava/util/Set;

    .line 414
    .line 415
    invoke-interface {p1, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 416
    .line 417
    .line 418
    move-result v13

    .line 419
    move-object v8, v2

    .line 420
    invoke-direct/range {v8 .. v13}, Lbz5;-><init>(Ljava/lang/String;Ljava/lang/String;JZ)V

    .line 421
    .line 422
    .line 423
    const/4 v5, 0x0

    .line 424
    const/16 v6, 0xe

    .line 425
    .line 426
    const/4 v3, 0x0

    .line 427
    const/4 v4, 0x0

    .line 428
    invoke-direct/range {v1 .. v6}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 429
    .line 430
    .line 431
    return-object v1

    .line 432
    :cond_f
    new-instance v2, Lgv;

    .line 433
    .line 434
    const p0, 0x7f0f0451

    .line 435
    .line 436
    .line 437
    new-array p1, v5, [Ljava/lang/Object;

    .line 438
    .line 439
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 440
    .line 441
    .line 442
    move-result-object v4

    .line 443
    const/4 v6, 0x0

    .line 444
    const/16 v7, 0xd

    .line 445
    .line 446
    const/4 v3, 0x0

    .line 447
    const/4 v5, 0x0

    .line 448
    invoke-direct/range {v2 .. v7}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 449
    .line 450
    .line 451
    return-object v2

    .line 452
    :cond_10
    const-string p0, "dir"

    .line 453
    .line 454
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 455
    .line 456
    .line 457
    move-result p0

    .line 458
    if-nez p0, :cond_12

    .line 459
    .line 460
    :cond_11
    new-instance v6, Lgv;

    .line 461
    .line 462
    const p0, 0x7f0f0458

    .line 463
    .line 464
    .line 465
    new-array p1, v5, [Ljava/lang/Object;

    .line 466
    .line 467
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 468
    .line 469
    .line 470
    move-result-object v8

    .line 471
    const/4 v10, 0x0

    .line 472
    const/16 v11, 0xd

    .line 473
    .line 474
    const/4 v7, 0x0

    .line 475
    const/4 v9, 0x0

    .line 476
    invoke-direct/range {v6 .. v11}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 477
    .line 478
    .line 479
    return-object v6

    .line 480
    :cond_12
    new-instance v0, Lgv;

    .line 481
    .line 482
    const p0, 0x7f0f0457

    .line 483
    .line 484
    .line 485
    new-array p1, v5, [Ljava/lang/Object;

    .line 486
    .line 487
    invoke-static {p0, p1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 488
    .line 489
    .line 490
    move-result-object v2

    .line 491
    const/4 v4, 0x0

    .line 492
    const/16 v5, 0xd

    .line 493
    .line 494
    const/4 v1, 0x0

    .line 495
    const/4 v3, 0x0

    .line 496
    invoke-direct/range {v0 .. v5}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 497
    .line 498
    .line 499
    return-object v0
.end method

.method private final n(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La4;->k:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lnf1;

    .line 6
    .line 7
    iget-byte v2, v0, La4;->j:B

    .line 8
    .line 9
    const v3, 0x7f0f00bb

    .line 10
    .line 11
    .line 12
    const-wide/32 v4, 0x400000

    .line 13
    .line 14
    .line 15
    const/4 v6, 0x2

    .line 16
    const/4 v7, 0x1

    .line 17
    const/4 v8, 0x0

    .line 18
    const/4 v9, 0x0

    .line 19
    sget-object v10, Lof1;->i:Lof1;

    .line 20
    .line 21
    if-eqz v2, :cond_2

    .line 22
    .line 23
    if-eq v2, v7, :cond_1

    .line 24
    .line 25
    if-ne v2, v6, :cond_0

    .line 26
    .line 27
    iget-object v0, v0, La4;->l:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v0, Lbz5;

    .line 30
    .line 31
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    move-object v7, v0

    .line 35
    move-object/from16 v0, p1

    .line 36
    .line 37
    goto/16 :goto_1

    .line 38
    .line 39
    :cond_0
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    invoke-static {v0}, La02;->d(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v8

    .line 45
    :cond_1
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    move-object/from16 v2, p1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    sget-object v2, Ljz5;->a:Ljz5;

    .line 55
    .line 56
    iget-object v2, v0, La4;->m:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v2, Ljava/lang/String;

    .line 59
    .line 60
    iput-object v1, v0, La4;->k:Ljava/lang/Object;

    .line 61
    .line 62
    iput-byte v7, v0, La4;->j:B

    .line 63
    .line 64
    sget-object v7, Lao1;->a:Lck1;

    .line 65
    .line 66
    sget-object v7, Luj1;->k:Luj1;

    .line 67
    .line 68
    new-instance v11, La4;

    .line 69
    .line 70
    const/16 v12, 0xd

    .line 71
    .line 72
    invoke-direct {v11, v2, v8, v12}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 73
    .line 74
    .line 75
    invoke-static {v7, v11, v0}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    if-eq v2, v10, :cond_9

    .line 80
    .line 81
    :goto_0
    check-cast v2, Lgv;

    .line 82
    .line 83
    iget-object v7, v2, Lgv;->a:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v7, Lbz5;

    .line 86
    .line 87
    if-nez v7, :cond_4

    .line 88
    .line 89
    new-instance v11, Lgv;

    .line 90
    .line 91
    iget-object v0, v2, Lgv;->b:Ljava/lang/String;

    .line 92
    .line 93
    if-nez v0, :cond_3

    .line 94
    .line 95
    const v0, 0x7f0f0448

    .line 96
    .line 97
    .line 98
    new-array v1, v9, [Ljava/lang/Object;

    .line 99
    .line 100
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    :cond_3
    move-object v13, v0

    .line 105
    const/4 v15, 0x0

    .line 106
    const/16 v16, 0xd

    .line 107
    .line 108
    const/4 v12, 0x0

    .line 109
    const/4 v14, 0x0

    .line 110
    invoke-direct/range {v11 .. v16}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 111
    .line 112
    .line 113
    return-object v11

    .line 114
    :cond_4
    iget-object v2, v7, Lbz5;->b:Ljava/lang/String;

    .line 115
    .line 116
    iget-wide v11, v7, Lbz5;->c:J

    .line 117
    .line 118
    cmp-long v11, v11, v4

    .line 119
    .line 120
    if-lez v11, :cond_5

    .line 121
    .line 122
    new-instance v12, Lgv;

    .line 123
    .line 124
    new-array v0, v9, [Ljava/lang/Object;

    .line 125
    .line 126
    invoke-static {v3, v0}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v14

    .line 130
    const/16 v16, 0x0

    .line 131
    .line 132
    const/16 v17, 0xd

    .line 133
    .line 134
    const/4 v13, 0x0

    .line 135
    const/4 v15, 0x0

    .line 136
    invoke-direct/range {v12 .. v17}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 137
    .line 138
    .line 139
    return-object v12

    .line 140
    :cond_5
    iget-boolean v11, v7, Lbz5;->d:Z

    .line 141
    .line 142
    if-nez v11, :cond_6

    .line 143
    .line 144
    sget-object v11, Ljz5;->a:Ljz5;

    .line 145
    .line 146
    invoke-static {v2}, Ljz5;->i(Ljava/lang/String;)Z

    .line 147
    .line 148
    .line 149
    move-result v11

    .line 150
    if-nez v11, :cond_6

    .line 151
    .line 152
    new-instance v12, Lgv;

    .line 153
    .line 154
    new-instance v13, Laz5;

    .line 155
    .line 156
    sget-object v0, Lcz5;->i:Lcz5;

    .line 157
    .line 158
    invoke-direct {v13, v7, v8, v0, v6}, Laz5;-><init>(Lbz5;Ljava/lang/String;Lcz5;I)V

    .line 159
    .line 160
    .line 161
    const/16 v16, 0x0

    .line 162
    .line 163
    const/16 v17, 0xe

    .line 164
    .line 165
    const/4 v14, 0x0

    .line 166
    const/4 v15, 0x0

    .line 167
    invoke-direct/range {v12 .. v17}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 168
    .line 169
    .line 170
    return-object v12

    .line 171
    :cond_6
    sget-object v11, Ljz5;->a:Ljz5;

    .line 172
    .line 173
    invoke-static {v2}, Ljz5;->o(Ljava/lang/String;)Lgv;

    .line 174
    .line 175
    .line 176
    move-result-object v2

    .line 177
    iget-object v11, v2, Lgv;->a:Ljava/lang/Object;

    .line 178
    .line 179
    check-cast v11, Ljava/io/File;

    .line 180
    .line 181
    if-nez v11, :cond_8

    .line 182
    .line 183
    new-instance v12, Lgv;

    .line 184
    .line 185
    iget-object v0, v2, Lgv;->b:Ljava/lang/String;

    .line 186
    .line 187
    if-nez v0, :cond_7

    .line 188
    .line 189
    const v0, 0x7f0f00c9

    .line 190
    .line 191
    .line 192
    new-array v1, v9, [Ljava/lang/Object;

    .line 193
    .line 194
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    :cond_7
    move-object v14, v0

    .line 199
    const/16 v16, 0x0

    .line 200
    .line 201
    const/16 v17, 0xd

    .line 202
    .line 203
    const/4 v13, 0x0

    .line 204
    const/4 v15, 0x0

    .line 205
    invoke-direct/range {v12 .. v17}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 206
    .line 207
    .line 208
    return-object v12

    .line 209
    :cond_8
    sget-object v2, Lto5;->a:Lto5;

    .line 210
    .line 211
    invoke-virtual {v11}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 216
    .line 217
    .line 218
    invoke-static {v2}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v2

    .line 222
    const-string v11, "(set -o pipefail; head -c 4194305 "

    .line 223
    .line 224
    const-string v12, " | base64)"

    .line 225
    .line 226
    invoke-static {v11, v2, v12}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    iput-object v1, v0, La4;->k:Ljava/lang/Object;

    .line 231
    .line 232
    iput-object v7, v0, La4;->l:Ljava/lang/Object;

    .line 233
    .line 234
    iput-byte v6, v0, La4;->j:B

    .line 235
    .line 236
    const-wide/32 v11, 0xea60

    .line 237
    .line 238
    .line 239
    invoke-static {v11, v12, v0, v2}, Lto5;->f(JLea1;Ljava/lang/String;)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    if-ne v0, v10, :cond_a

    .line 244
    .line 245
    :cond_9
    return-object v10

    .line 246
    :cond_a
    :goto_1
    check-cast v0, Lko5;

    .line 247
    .line 248
    invoke-virtual {v0}, Lko5;->a()Z

    .line 249
    .line 250
    .line 251
    move-result v1

    .line 252
    iget-object v2, v0, Lko5;->a:Ljava/lang/String;

    .line 253
    .line 254
    if-nez v1, :cond_d

    .line 255
    .line 256
    iget-object v0, v0, Lko5;->b:Ljava/lang/String;

    .line 257
    .line 258
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 259
    .line 260
    .line 261
    move-result v1

    .line 262
    if-nez v1, :cond_b

    .line 263
    .line 264
    move-object v2, v0

    .line 265
    :cond_b
    invoke-static {v2}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 266
    .line 267
    .line 268
    move-result v0

    .line 269
    if-eqz v0, :cond_c

    .line 270
    .line 271
    const v0, 0x7f0f0452

    .line 272
    .line 273
    .line 274
    new-array v1, v9, [Ljava/lang/Object;

    .line 275
    .line 276
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    :cond_c
    move-object v5, v2

    .line 281
    new-instance v3, Lgv;

    .line 282
    .line 283
    const/4 v4, 0x0

    .line 284
    const/4 v6, 0x0

    .line 285
    const/4 v7, 0x0

    .line 286
    const/16 v8, 0xd

    .line 287
    .line 288
    invoke-direct/range {v3 .. v8}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 289
    .line 290
    .line 291
    return-object v3

    .line 292
    :cond_d
    :try_start_0
    invoke-static {v2, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 293
    .line 294
    .line 295
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 296
    goto :goto_2

    .line 297
    :catchall_0
    move-exception v0

    .line 298
    new-instance v1, Lrm5;

    .line 299
    .line 300
    invoke-direct {v1, v0}, Lrm5;-><init>(Ljava/lang/Throwable;)V

    .line 301
    .line 302
    .line 303
    move-object v0, v1

    .line 304
    :goto_2
    instance-of v1, v0, Lrm5;

    .line 305
    .line 306
    if-eqz v1, :cond_e

    .line 307
    .line 308
    move-object v0, v8

    .line 309
    :cond_e
    check-cast v0, [B

    .line 310
    .line 311
    if-nez v0, :cond_f

    .line 312
    .line 313
    new-instance v10, Lgv;

    .line 314
    .line 315
    const v0, 0x7f0f0436

    .line 316
    .line 317
    .line 318
    new-array v1, v9, [Ljava/lang/Object;

    .line 319
    .line 320
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 321
    .line 322
    .line 323
    move-result-object v12

    .line 324
    const/4 v14, 0x0

    .line 325
    const/16 v15, 0xd

    .line 326
    .line 327
    const/4 v11, 0x0

    .line 328
    const/4 v13, 0x0

    .line 329
    invoke-direct/range {v10 .. v15}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 330
    .line 331
    .line 332
    return-object v10

    .line 333
    :cond_f
    array-length v1, v0

    .line 334
    int-to-long v1, v1

    .line 335
    cmp-long v1, v1, v4

    .line 336
    .line 337
    if-lez v1, :cond_10

    .line 338
    .line 339
    new-instance v10, Lgv;

    .line 340
    .line 341
    new-array v0, v9, [Ljava/lang/Object;

    .line 342
    .line 343
    invoke-static {v3, v0}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 344
    .line 345
    .line 346
    move-result-object v12

    .line 347
    const/4 v14, 0x0

    .line 348
    const/16 v15, 0xd

    .line 349
    .line 350
    const/4 v11, 0x0

    .line 351
    const/4 v13, 0x0

    .line 352
    invoke-direct/range {v10 .. v15}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 353
    .line 354
    .line 355
    return-object v10

    .line 356
    :cond_10
    sget-object v1, Ljz5;->a:Ljz5;

    .line 357
    .line 358
    array-length v1, v0

    .line 359
    if-eqz v1, :cond_16

    .line 360
    .line 361
    array-length v1, v0

    .line 362
    const/16 v2, 0x1000

    .line 363
    .line 364
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 365
    .line 366
    .line 367
    move-result v1

    .line 368
    move v2, v9

    .line 369
    :goto_3
    if-ge v9, v1, :cond_14

    .line 370
    .line 371
    aget-byte v3, v0, v9

    .line 372
    .line 373
    and-int/lit16 v3, v3, 0xff

    .line 374
    .line 375
    if-eqz v3, :cond_15

    .line 376
    .line 377
    const/16 v4, 0x9

    .line 378
    .line 379
    if-lt v3, v4, :cond_12

    .line 380
    .line 381
    const/16 v4, 0xe

    .line 382
    .line 383
    if-gt v4, v3, :cond_11

    .line 384
    .line 385
    const/16 v4, 0x20

    .line 386
    .line 387
    if-lt v3, v4, :cond_12

    .line 388
    .line 389
    :cond_11
    const/16 v4, 0x7f

    .line 390
    .line 391
    if-ne v3, v4, :cond_13

    .line 392
    .line 393
    :cond_12
    add-int/lit8 v2, v2, 0x1

    .line 394
    .line 395
    :cond_13
    add-int/lit8 v9, v9, 0x1

    .line 396
    .line 397
    goto :goto_3

    .line 398
    :cond_14
    mul-int/lit8 v2, v2, 0x5

    .line 399
    .line 400
    if-le v2, v1, :cond_16

    .line 401
    .line 402
    :cond_15
    new-instance v9, Lgv;

    .line 403
    .line 404
    new-instance v10, Laz5;

    .line 405
    .line 406
    sget-object v0, Lcz5;->j:Lcz5;

    .line 407
    .line 408
    invoke-direct {v10, v7, v8, v0, v6}, Laz5;-><init>(Lbz5;Ljava/lang/String;Lcz5;I)V

    .line 409
    .line 410
    .line 411
    const/4 v13, 0x0

    .line 412
    const/16 v14, 0xe

    .line 413
    .line 414
    const/4 v11, 0x0

    .line 415
    const/4 v12, 0x0

    .line 416
    invoke-direct/range {v9 .. v14}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 417
    .line 418
    .line 419
    return-object v9

    .line 420
    :cond_16
    new-instance v1, Lgv;

    .line 421
    .line 422
    move-object v2, v1

    .line 423
    new-instance v1, Laz5;

    .line 424
    .line 425
    new-instance v3, Ljava/lang/String;

    .line 426
    .line 427
    sget-object v4, Lpn0;->a:Ljava/nio/charset/Charset;

    .line 428
    .line 429
    invoke-direct {v3, v0, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 430
    .line 431
    .line 432
    const/4 v0, 0x4

    .line 433
    invoke-direct {v1, v7, v3, v8, v0}, Laz5;-><init>(Lbz5;Ljava/lang/String;Lcz5;I)V

    .line 434
    .line 435
    .line 436
    const/4 v4, 0x0

    .line 437
    const/16 v5, 0xe

    .line 438
    .line 439
    move-object v0, v2

    .line 440
    const/4 v2, 0x0

    .line 441
    const/4 v3, 0x0

    .line 442
    invoke-direct/range {v0 .. v5}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 443
    .line 444
    .line 445
    return-object v0
.end method

.method private final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, La4;->l:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ljava/lang/String;

    .line 6
    .line 7
    iget-byte v2, v0, La4;->j:B

    .line 8
    .line 9
    const/4 v3, 0x2

    .line 10
    const/4 v4, 0x1

    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x0

    .line 13
    sget-object v7, Lof1;->i:Lof1;

    .line 14
    .line 15
    if-eqz v2, :cond_2

    .line 16
    .line 17
    if-eq v2, v4, :cond_1

    .line 18
    .line 19
    if-ne v2, v3, :cond_0

    .line 20
    .line 21
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    return-object p1

    .line 25
    :cond_0
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 26
    .line 27
    invoke-static {v0}, La02;->d(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-object v5

    .line 31
    :cond_1
    iget-object v1, v0, La4;->k:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v1, [B

    .line 34
    .line 35
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    move-object/from16 v2, p1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    int-to-long v8, v2

    .line 49
    const-wide/32 v10, 0x400000

    .line 50
    .line 51
    .line 52
    cmp-long v2, v8, v10

    .line 53
    .line 54
    const v8, 0x7f0f00bb

    .line 55
    .line 56
    .line 57
    if-lez v2, :cond_3

    .line 58
    .line 59
    new-instance v12, Lgv;

    .line 60
    .line 61
    new-array v0, v6, [Ljava/lang/Object;

    .line 62
    .line 63
    invoke-static {v8, v0}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v14

    .line 67
    const/16 v16, 0x0

    .line 68
    .line 69
    const/16 v17, 0xd

    .line 70
    .line 71
    const/4 v13, 0x0

    .line 72
    const/4 v15, 0x0

    .line 73
    invoke-direct/range {v12 .. v17}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 74
    .line 75
    .line 76
    return-object v12

    .line 77
    :cond_3
    sget-object v2, Lpn0;->a:Ljava/nio/charset/Charset;

    .line 78
    .line 79
    invoke-virtual {v1, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    array-length v2, v1

    .line 87
    int-to-long v12, v2

    .line 88
    cmp-long v2, v12, v10

    .line 89
    .line 90
    if-lez v2, :cond_4

    .line 91
    .line 92
    new-instance v9, Lgv;

    .line 93
    .line 94
    new-array v0, v6, [Ljava/lang/Object;

    .line 95
    .line 96
    invoke-static {v8, v0}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v11

    .line 100
    const/4 v13, 0x0

    .line 101
    const/16 v14, 0xd

    .line 102
    .line 103
    const/4 v10, 0x0

    .line 104
    const/4 v12, 0x0

    .line 105
    invoke-direct/range {v9 .. v14}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 106
    .line 107
    .line 108
    return-object v9

    .line 109
    :cond_4
    sget-object v2, Ljz5;->a:Ljz5;

    .line 110
    .line 111
    iget-object v2, v0, La4;->m:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v2, Ljava/lang/String;

    .line 114
    .line 115
    iput-object v1, v0, La4;->k:Ljava/lang/Object;

    .line 116
    .line 117
    iput-byte v4, v0, La4;->j:B

    .line 118
    .line 119
    sget-object v4, Lao1;->a:Lck1;

    .line 120
    .line 121
    sget-object v4, Luj1;->k:Luj1;

    .line 122
    .line 123
    new-instance v8, La4;

    .line 124
    .line 125
    const/16 v9, 0xd

    .line 126
    .line 127
    invoke-direct {v8, v2, v5, v9}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 128
    .line 129
    .line 130
    invoke-static {v4, v8, v0}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    if-eq v2, v7, :cond_a

    .line 135
    .line 136
    :goto_0
    check-cast v2, Lgv;

    .line 137
    .line 138
    iget-object v4, v2, Lgv;->a:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast v4, Lbz5;

    .line 141
    .line 142
    if-nez v4, :cond_6

    .line 143
    .line 144
    new-instance v8, Lgv;

    .line 145
    .line 146
    iget-object v0, v2, Lgv;->b:Ljava/lang/String;

    .line 147
    .line 148
    if-nez v0, :cond_5

    .line 149
    .line 150
    const v0, 0x7f0f0448

    .line 151
    .line 152
    .line 153
    new-array v1, v6, [Ljava/lang/Object;

    .line 154
    .line 155
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    :cond_5
    move-object v10, v0

    .line 160
    const/4 v12, 0x0

    .line 161
    const/16 v13, 0xd

    .line 162
    .line 163
    const/4 v9, 0x0

    .line 164
    const/4 v11, 0x0

    .line 165
    invoke-direct/range {v8 .. v13}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 166
    .line 167
    .line 168
    return-object v8

    .line 169
    :cond_6
    iget-object v2, v4, Lbz5;->b:Ljava/lang/String;

    .line 170
    .line 171
    iget-boolean v4, v4, Lbz5;->d:Z

    .line 172
    .line 173
    if-nez v4, :cond_7

    .line 174
    .line 175
    sget-object v4, Ljz5;->a:Ljz5;

    .line 176
    .line 177
    invoke-static {v2}, Ljz5;->i(Ljava/lang/String;)Z

    .line 178
    .line 179
    .line 180
    move-result v4

    .line 181
    if-nez v4, :cond_7

    .line 182
    .line 183
    new-instance v8, Lgv;

    .line 184
    .line 185
    const v0, 0x7f0f043f

    .line 186
    .line 187
    .line 188
    new-array v1, v6, [Ljava/lang/Object;

    .line 189
    .line 190
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v10

    .line 194
    const/4 v12, 0x0

    .line 195
    const/16 v13, 0xd

    .line 196
    .line 197
    const/4 v9, 0x0

    .line 198
    const/4 v11, 0x0

    .line 199
    invoke-direct/range {v8 .. v13}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 200
    .line 201
    .line 202
    return-object v8

    .line 203
    :cond_7
    sget-object v4, Ljz5;->a:Ljz5;

    .line 204
    .line 205
    invoke-static {v2}, Ljz5;->o(Ljava/lang/String;)Lgv;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    iget-object v8, v2, Lgv;->a:Ljava/lang/Object;

    .line 210
    .line 211
    check-cast v8, Ljava/io/File;

    .line 212
    .line 213
    if-nez v8, :cond_9

    .line 214
    .line 215
    new-instance v9, Lgv;

    .line 216
    .line 217
    iget-object v0, v2, Lgv;->b:Ljava/lang/String;

    .line 218
    .line 219
    if-nez v0, :cond_8

    .line 220
    .line 221
    const v0, 0x7f0f00c9

    .line 222
    .line 223
    .line 224
    new-array v1, v6, [Ljava/lang/Object;

    .line 225
    .line 226
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    :cond_8
    move-object v11, v0

    .line 231
    const/4 v13, 0x0

    .line 232
    const/16 v14, 0xd

    .line 233
    .line 234
    const/4 v10, 0x0

    .line 235
    const/4 v12, 0x0

    .line 236
    invoke-direct/range {v9 .. v14}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 237
    .line 238
    .line 239
    return-object v9

    .line 240
    :cond_9
    iput-object v5, v0, La4;->k:Ljava/lang/Object;

    .line 241
    .line 242
    iput-byte v3, v0, La4;->j:B

    .line 243
    .line 244
    const v2, 0x7f0f00d4

    .line 245
    .line 246
    .line 247
    invoke-virtual {v4, v1, v8, v2, v0}, Ljz5;->t([BLjava/io/File;ILfa1;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    if-ne v0, v7, :cond_b

    .line 252
    .line 253
    :cond_a
    return-object v7

    .line 254
    :cond_b
    return-object v0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 3

    .line 1
    iget-byte v0, p0, La4;->i:B

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    packed-switch v0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    new-instance p1, La4;

    .line 8
    .line 9
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lmw6;

    .line 12
    .line 13
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p0, Lgw6;

    .line 16
    .line 17
    const/16 v1, 0x12

    .line 18
    .line 19
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 20
    .line 21
    .line 22
    return-object p1

    .line 23
    :pswitch_0
    new-instance v0, La4;

    .line 24
    .line 25
    iget-object v1, p0, La4;->l:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v1, Ls33;

    .line 28
    .line 29
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast p0, Lja2;

    .line 32
    .line 33
    const/16 v2, 0x11

    .line 34
    .line 35
    invoke-direct {v0, v1, p0, p2, v2}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 36
    .line 37
    .line 38
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 39
    .line 40
    return-object v0

    .line 41
    :pswitch_1
    new-instance p1, La4;

    .line 42
    .line 43
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v0, Ljava/lang/String;

    .line 46
    .line 47
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p0, Ljava/lang/String;

    .line 50
    .line 51
    const/16 v1, 0x10

    .line 52
    .line 53
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 54
    .line 55
    .line 56
    return-object p1

    .line 57
    :pswitch_2
    new-instance v0, La4;

    .line 58
    .line 59
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 60
    .line 61
    check-cast p0, Ljava/lang/String;

    .line 62
    .line 63
    const/16 v1, 0xf

    .line 64
    .line 65
    invoke-direct {v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 66
    .line 67
    .line 68
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_3
    new-instance p1, La4;

    .line 72
    .line 73
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 74
    .line 75
    check-cast p0, Ljava/lang/String;

    .line 76
    .line 77
    const/16 v0, 0xe

    .line 78
    .line 79
    invoke-direct {p1, p0, p2, v0}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 80
    .line 81
    .line 82
    return-object p1

    .line 83
    :pswitch_4
    new-instance p1, La4;

    .line 84
    .line 85
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast p0, Ljava/lang/String;

    .line 88
    .line 89
    const/16 v0, 0xd

    .line 90
    .line 91
    invoke-direct {p1, p0, p2, v0}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 92
    .line 93
    .line 94
    return-object p1

    .line 95
    :pswitch_5
    new-instance p0, La4;

    .line 96
    .line 97
    const/16 v0, 0xc

    .line 98
    .line 99
    invoke-direct {p0, v1, p2, v0}, La4;-><init>(ILea1;B)V

    .line 100
    .line 101
    .line 102
    iput-object p1, p0, La4;->k:Ljava/lang/Object;

    .line 103
    .line 104
    return-object p0

    .line 105
    :pswitch_6
    new-instance v0, La4;

    .line 106
    .line 107
    iget-object v1, p0, La4;->l:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast v1, Lal6;

    .line 110
    .line 111
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast p0, Lhd1;

    .line 114
    .line 115
    const/16 v2, 0xb

    .line 116
    .line 117
    invoke-direct {v0, v1, p0, p2, v2}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 118
    .line 119
    .line 120
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 121
    .line 122
    return-object v0

    .line 123
    :pswitch_7
    new-instance p1, La4;

    .line 124
    .line 125
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast v0, Lff0;

    .line 128
    .line 129
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast p0, Lib4;

    .line 132
    .line 133
    const/16 v1, 0xa

    .line 134
    .line 135
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 136
    .line 137
    .line 138
    return-object p1

    .line 139
    :pswitch_8
    new-instance v0, La4;

    .line 140
    .line 141
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 142
    .line 143
    check-cast p0, Ljp3;

    .line 144
    .line 145
    const/16 v1, 0x9

    .line 146
    .line 147
    invoke-direct {v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 148
    .line 149
    .line 150
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 151
    .line 152
    return-object v0

    .line 153
    :pswitch_9
    new-instance p0, La4;

    .line 154
    .line 155
    const/16 p1, 0x8

    .line 156
    .line 157
    invoke-direct {p0, v1, p2, p1}, La4;-><init>(ILea1;B)V

    .line 158
    .line 159
    .line 160
    return-object p0

    .line 161
    :pswitch_a
    new-instance p1, La4;

    .line 162
    .line 163
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast p0, Lqo2;

    .line 166
    .line 167
    const/4 v0, 0x7

    .line 168
    invoke-direct {p1, p0, p2, v0}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 169
    .line 170
    .line 171
    return-object p1

    .line 172
    :pswitch_b
    new-instance v0, La4;

    .line 173
    .line 174
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 175
    .line 176
    check-cast p0, Li41;

    .line 177
    .line 178
    const/4 v1, 0x6

    .line 179
    invoke-direct {v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 180
    .line 181
    .line 182
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 183
    .line 184
    return-object v0

    .line 185
    :pswitch_c
    new-instance p1, La4;

    .line 186
    .line 187
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 188
    .line 189
    check-cast p0, Lcom/box/app/tile/BoxServiceTileService;

    .line 190
    .line 191
    const/4 v0, 0x5

    .line 192
    invoke-direct {p1, p0, p2, v0}, La4;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 193
    .line 194
    .line 195
    return-object p1

    .line 196
    :pswitch_d
    new-instance v0, La4;

    .line 197
    .line 198
    iget-object v1, p0, La4;->l:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v1, Lu92;

    .line 201
    .line 202
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast p0, Lmg;

    .line 205
    .line 206
    const/4 v2, 0x4

    .line 207
    invoke-direct {v0, v1, p0, p2, v2}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 208
    .line 209
    .line 210
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 211
    .line 212
    return-object v0

    .line 213
    :pswitch_e
    new-instance p1, La4;

    .line 214
    .line 215
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v0, Lqm0;

    .line 218
    .line 219
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 220
    .line 221
    check-cast p0, Lmg;

    .line 222
    .line 223
    const/4 v1, 0x3

    .line 224
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 225
    .line 226
    .line 227
    return-object p1

    .line 228
    :pswitch_f
    new-instance p1, La4;

    .line 229
    .line 230
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v0, Lql6;

    .line 233
    .line 234
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast p0, Li67;

    .line 237
    .line 238
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 239
    .line 240
    .line 241
    return-object p1

    .line 242
    :pswitch_10
    new-instance p1, La4;

    .line 243
    .line 244
    iget-object v0, p0, La4;->l:Ljava/lang/Object;

    .line 245
    .line 246
    check-cast v0, Lix;

    .line 247
    .line 248
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 249
    .line 250
    check-cast p0, Lcx;

    .line 251
    .line 252
    const/4 v1, 0x1

    .line 253
    invoke-direct {p1, v0, p0, p2, v1}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 254
    .line 255
    .line 256
    return-object p1

    .line 257
    :pswitch_11
    new-instance v0, La4;

    .line 258
    .line 259
    iget-object v1, p0, La4;->l:Ljava/lang/Object;

    .line 260
    .line 261
    check-cast v1, Lal6;

    .line 262
    .line 263
    iget-object p0, p0, La4;->m:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast p0, Lja2;

    .line 266
    .line 267
    const/4 v2, 0x0

    .line 268
    invoke-direct {v0, v1, p0, p2, v2}, La4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 269
    .line 270
    .line 271
    iput-object p1, v0, La4;->k:Ljava/lang/Object;

    .line 272
    .line 273
    return-object v0

    .line 274
    nop

    .line 275
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, La4;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lnf1;

    .line 9
    .line 10
    check-cast p2, Lea1;

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, La4;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lnf1;

    .line 24
    .line 25
    check-cast p2, Lea1;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, La4;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_1
    check-cast p1, Lnf1;

    .line 39
    .line 40
    check-cast p2, Lea1;

    .line 41
    .line 42
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, La4;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_2
    check-cast p1, Lnf1;

    .line 54
    .line 55
    check-cast p2, Lea1;

    .line 56
    .line 57
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    check-cast p0, La4;

    .line 62
    .line 63
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_3
    check-cast p1, Lnf1;

    .line 69
    .line 70
    check-cast p2, Lea1;

    .line 71
    .line 72
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    check-cast p0, La4;

    .line 77
    .line 78
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    return-object p0

    .line 83
    :pswitch_4
    check-cast p1, Lnf1;

    .line 84
    .line 85
    check-cast p2, Lea1;

    .line 86
    .line 87
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    check-cast p0, La4;

    .line 92
    .line 93
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0

    .line 98
    :pswitch_5
    check-cast p1, Lnf1;

    .line 99
    .line 100
    check-cast p2, Lea1;

    .line 101
    .line 102
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    check-cast p0, La4;

    .line 107
    .line 108
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    return-object p0

    .line 113
    :pswitch_6
    check-cast p1, Lnf1;

    .line 114
    .line 115
    check-cast p2, Lea1;

    .line 116
    .line 117
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    check-cast p0, La4;

    .line 122
    .line 123
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    return-object p0

    .line 128
    :pswitch_7
    check-cast p1, Lnf1;

    .line 129
    .line 130
    check-cast p2, Lea1;

    .line 131
    .line 132
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    check-cast p0, La4;

    .line 137
    .line 138
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object p0

    .line 142
    return-object p0

    .line 143
    :pswitch_8
    check-cast p1, Ljava/lang/Float;

    .line 144
    .line 145
    check-cast p2, Lea1;

    .line 146
    .line 147
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    check-cast p0, La4;

    .line 152
    .line 153
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object p0

    .line 157
    return-object p0

    .line 158
    :pswitch_9
    check-cast p1, Lnf1;

    .line 159
    .line 160
    check-cast p2, Lea1;

    .line 161
    .line 162
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 163
    .line 164
    .line 165
    move-result-object p0

    .line 166
    check-cast p0, La4;

    .line 167
    .line 168
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    return-object p0

    .line 173
    :pswitch_a
    check-cast p1, Lnf1;

    .line 174
    .line 175
    check-cast p2, Lea1;

    .line 176
    .line 177
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    check-cast p0, La4;

    .line 182
    .line 183
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    return-object p0

    .line 188
    :pswitch_b
    check-cast p1, Lf55;

    .line 189
    .line 190
    check-cast p2, Lea1;

    .line 191
    .line 192
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    check-cast p0, La4;

    .line 197
    .line 198
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object p0

    .line 202
    return-object p0

    .line 203
    :pswitch_c
    check-cast p1, Lnf1;

    .line 204
    .line 205
    check-cast p2, Lea1;

    .line 206
    .line 207
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 208
    .line 209
    .line 210
    move-result-object p0

    .line 211
    check-cast p0, La4;

    .line 212
    .line 213
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 214
    .line 215
    .line 216
    move-result-object p0

    .line 217
    return-object p0

    .line 218
    :pswitch_d
    check-cast p1, Lw42;

    .line 219
    .line 220
    check-cast p2, Lea1;

    .line 221
    .line 222
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 223
    .line 224
    .line 225
    move-result-object p0

    .line 226
    check-cast p0, La4;

    .line 227
    .line 228
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object p0

    .line 232
    return-object p0

    .line 233
    :pswitch_e
    check-cast p1, Lnf1;

    .line 234
    .line 235
    check-cast p2, Lea1;

    .line 236
    .line 237
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 238
    .line 239
    .line 240
    move-result-object p0

    .line 241
    check-cast p0, La4;

    .line 242
    .line 243
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object p0

    .line 247
    return-object p0

    .line 248
    :pswitch_f
    check-cast p1, Lnf1;

    .line 249
    .line 250
    check-cast p2, Lea1;

    .line 251
    .line 252
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 253
    .line 254
    .line 255
    move-result-object p0

    .line 256
    check-cast p0, La4;

    .line 257
    .line 258
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object p0

    .line 262
    return-object p0

    .line 263
    :pswitch_10
    check-cast p1, Lnf1;

    .line 264
    .line 265
    check-cast p2, Lea1;

    .line 266
    .line 267
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 268
    .line 269
    .line 270
    move-result-object p0

    .line 271
    check-cast p0, La4;

    .line 272
    .line 273
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object p0

    .line 277
    return-object p0

    .line 278
    :pswitch_11
    check-cast p1, Lnf1;

    .line 279
    .line 280
    check-cast p2, Lea1;

    .line 281
    .line 282
    invoke-virtual {p0, p1, p2}, La4;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 283
    .line 284
    .line 285
    move-result-object p0

    .line 286
    check-cast p0, La4;

    .line 287
    .line 288
    invoke-virtual {p0, v1}, La4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object p0

    .line 292
    return-object p0

    .line 293
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v5, p0

    .line 2
    .line 3
    iget-byte v0, v5, La4;->i:B

    .line 4
    .line 5
    const/4 v7, 0x0

    .line 6
    const/16 v1, 0xa

    .line 7
    .line 8
    const/4 v8, 0x3

    .line 9
    const/4 v9, 0x4

    .line 10
    const/4 v2, 0x0

    .line 11
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 12
    .line 13
    const/4 v4, 0x2

    .line 14
    const/4 v6, 0x1

    .line 15
    const/4 v10, 0x0

    .line 16
    packed-switch v0, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    sget-object v1, Lxc7;->a:Lxc7;

    .line 20
    .line 21
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 22
    .line 23
    move-object v2, v0

    .line 24
    check-cast v2, Lmw6;

    .line 25
    .line 26
    sget-object v7, Lof1;->i:Lof1;

    .line 27
    .line 28
    iget-byte v0, v5, La4;->j:B

    .line 29
    .line 30
    if-eqz v0, :cond_4

    .line 31
    .line 32
    if-eq v0, v6, :cond_3

    .line 33
    .line 34
    if-eq v0, v4, :cond_2

    .line 35
    .line 36
    if-eq v0, v8, :cond_1

    .line 37
    .line 38
    if-eq v0, v9, :cond_0

    .line 39
    .line 40
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    goto :goto_3

    .line 44
    :cond_0
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, Ljava/lang/Throwable;

    .line 47
    .line 48
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    goto :goto_4

    .line 52
    :cond_1
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_2
    :try_start_0
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_3
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 61
    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_4
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :try_start_1
    iget-object v0, v2, Lmw6;->z:Lfa2;

    .line 68
    .line 69
    if-eqz v0, :cond_5

    .line 70
    .line 71
    iput-byte v6, v5, La4;->j:B

    .line 72
    .line 73
    invoke-interface {v0, v5}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-eq v0, v7, :cond_7

    .line 78
    .line 79
    :cond_5
    :goto_0
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Lgw6;

    .line 82
    .line 83
    iput-byte v4, v5, La4;->j:B

    .line 84
    .line 85
    invoke-interface {v0, v2, v5}, Lgw6;->a(Lyv6;Lvr6;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 89
    if-eq v0, v7, :cond_7

    .line 90
    .line 91
    :goto_1
    iget-object v0, v2, Lmw6;->A:Llg;

    .line 92
    .line 93
    if-eqz v0, :cond_6

    .line 94
    .line 95
    iput-byte v8, v5, La4;->j:B

    .line 96
    .line 97
    invoke-virtual {v0, v5}, Llg;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    if-eq v1, v7, :cond_7

    .line 101
    .line 102
    :cond_6
    :goto_2
    move-object v10, v1

    .line 103
    goto :goto_3

    .line 104
    :catchall_0
    move-exception v0

    .line 105
    iget-object v2, v2, Lmw6;->A:Llg;

    .line 106
    .line 107
    if-eqz v2, :cond_8

    .line 108
    .line 109
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 110
    .line 111
    iput-byte v9, v5, La4;->j:B

    .line 112
    .line 113
    invoke-virtual {v2, v5}, Llg;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    if-ne v1, v7, :cond_8

    .line 117
    .line 118
    :cond_7
    move-object v10, v7

    .line 119
    :goto_3
    return-object v10

    .line 120
    :cond_8
    :goto_4
    throw v0

    .line 121
    :pswitch_0
    sget-object v0, Lof1;->i:Lof1;

    .line 122
    .line 123
    iget-byte v1, v5, La4;->j:B

    .line 124
    .line 125
    if-eqz v1, :cond_b

    .line 126
    .line 127
    if-eq v1, v6, :cond_a

    .line 128
    .line 129
    if-ne v1, v4, :cond_9

    .line 130
    .line 131
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    goto :goto_6

    .line 135
    :cond_9
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    goto :goto_7

    .line 139
    :cond_a
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v1, Lnf1;

    .line 142
    .line 143
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    goto :goto_5

    .line 147
    :cond_b
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v1, Lnf1;

    .line 153
    .line 154
    iget-object v2, v5, La4;->l:Ljava/lang/Object;

    .line 155
    .line 156
    check-cast v2, Ls33;

    .line 157
    .line 158
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 159
    .line 160
    iput-byte v6, v5, La4;->j:B

    .line 161
    .line 162
    invoke-interface {v2, v5}, Ls33;->G(Lea1;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    if-eq v2, v0, :cond_c

    .line 167
    .line 168
    :goto_5
    iget-object v2, v5, La4;->m:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast v2, Lja2;

    .line 171
    .line 172
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 173
    .line 174
    iput-byte v4, v5, La4;->j:B

    .line 175
    .line 176
    invoke-interface {v2, v1, v5}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    if-ne v1, v0, :cond_d

    .line 181
    .line 182
    :cond_c
    move-object v10, v0

    .line 183
    goto :goto_7

    .line 184
    :cond_d
    :goto_6
    sget-object v10, Lxc7;->a:Lxc7;

    .line 185
    .line 186
    :goto_7
    return-object v10

    .line 187
    :pswitch_1
    invoke-direct/range {p0 .. p1}, La4;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    return-object v0

    .line 192
    :pswitch_2
    invoke-direct/range {p0 .. p1}, La4;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    return-object v0

    .line 197
    :pswitch_3
    sget-object v0, Lof1;->i:Lof1;

    .line 198
    .line 199
    iget-byte v1, v5, La4;->j:B

    .line 200
    .line 201
    const-wide/32 v7, 0xea60

    .line 202
    .line 203
    .line 204
    const-string v11, "find "

    .line 205
    .line 206
    if-eqz v1, :cond_10

    .line 207
    .line 208
    if-eq v1, v6, :cond_f

    .line 209
    .line 210
    if-ne v1, v4, :cond_e

    .line 211
    .line 212
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 213
    .line 214
    check-cast v0, Lko5;

    .line 215
    .line 216
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 217
    .line 218
    .line 219
    move-object/from16 v3, p1

    .line 220
    .line 221
    goto/16 :goto_a

    .line 222
    .line 223
    :cond_e
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 224
    .line 225
    .line 226
    goto/16 :goto_b

    .line 227
    .line 228
    :cond_f
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v1, Ljava/io/File;

    .line 231
    .line 232
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    move-object v3, v1

    .line 236
    move-object/from16 v1, p1

    .line 237
    .line 238
    goto :goto_8

    .line 239
    :cond_10
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 240
    .line 241
    .line 242
    sget-object v1, Lvc0;->a:Lvc0;

    .line 243
    .line 244
    invoke-static {}, Lvc0;->e()V

    .line 245
    .line 246
    .line 247
    sget-object v1, Ljz5;->a:Ljz5;

    .line 248
    .line 249
    iget-object v1, v5, La4;->m:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v1, Ljava/lang/String;

    .line 252
    .line 253
    invoke-static {v1}, Ljz5;->o(Ljava/lang/String;)Lgv;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    iget-object v3, v1, Lgv;->a:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v3, Ljava/io/File;

    .line 260
    .line 261
    if-nez v3, :cond_12

    .line 262
    .line 263
    new-instance v12, Lgv;

    .line 264
    .line 265
    iget-object v0, v1, Lgv;->b:Ljava/lang/String;

    .line 266
    .line 267
    if-nez v0, :cond_11

    .line 268
    .line 269
    const v0, 0x7f0f00c9

    .line 270
    .line 271
    .line 272
    new-array v1, v2, [Ljava/lang/Object;

    .line 273
    .line 274
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object v0

    .line 278
    :cond_11
    move-object v14, v0

    .line 279
    const/16 v16, 0x0

    .line 280
    .line 281
    const/16 v17, 0xd

    .line 282
    .line 283
    const/4 v13, 0x0

    .line 284
    const/4 v15, 0x0

    .line 285
    invoke-direct/range {v12 .. v17}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 286
    .line 287
    .line 288
    move-object v10, v12

    .line 289
    goto/16 :goto_b

    .line 290
    .line 291
    :cond_12
    sget-object v1, Lto5;->a:Lto5;

    .line 292
    .line 293
    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 294
    .line 295
    .line 296
    move-result-object v1

    .line 297
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 298
    .line 299
    .line 300
    invoke-static {v1}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v1

    .line 304
    const-string v12, " -maxdepth 1 -mindepth 1 -type d 2>/dev/null"

    .line 305
    .line 306
    invoke-static {v11, v1, v12}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    iput-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 311
    .line 312
    iput-byte v6, v5, La4;->j:B

    .line 313
    .line 314
    invoke-static {v7, v8, v5, v1}, Lto5;->f(JLea1;Ljava/lang/String;)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v1

    .line 318
    if-eq v1, v0, :cond_13

    .line 319
    .line 320
    :goto_8
    check-cast v1, Lko5;

    .line 321
    .line 322
    sget-object v12, Lto5;->a:Lto5;

    .line 323
    .line 324
    sget-object v12, Ljz5;->a:Ljz5;

    .line 325
    .line 326
    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 327
    .line 328
    .line 329
    move-result-object v3

    .line 330
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 331
    .line 332
    .line 333
    invoke-static {v3}, Ljz5;->q(Ljava/lang/String;)Ljava/lang/String;

    .line 334
    .line 335
    .line 336
    move-result-object v3

    .line 337
    const-string v12, " -maxdepth 1 -mindepth 1 -type f 2>/dev/null"

    .line 338
    .line 339
    invoke-static {v11, v3, v12}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v3

    .line 343
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 344
    .line 345
    iput-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 346
    .line 347
    iput-byte v4, v5, La4;->j:B

    .line 348
    .line 349
    invoke-static {v7, v8, v5, v3}, Lto5;->f(JLea1;Ljava/lang/String;)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v3

    .line 353
    if-ne v3, v0, :cond_14

    .line 354
    .line 355
    :cond_13
    :goto_9
    move-object v10, v0

    .line 356
    goto/16 :goto_b

    .line 357
    .line 358
    :cond_14
    move-object v0, v1

    .line 359
    :goto_a
    check-cast v3, Lko5;

    .line 360
    .line 361
    invoke-virtual {v0}, Lko5;->a()Z

    .line 362
    .line 363
    .line 364
    move-result v1

    .line 365
    if-eqz v1, :cond_15

    .line 366
    .line 367
    invoke-virtual {v3}, Lko5;->a()Z

    .line 368
    .line 369
    .line 370
    move-result v1

    .line 371
    if-eqz v1, :cond_15

    .line 372
    .line 373
    iget-object v0, v0, Lko5;->a:Ljava/lang/String;

    .line 374
    .line 375
    new-instance v1, Lqw;

    .line 376
    .line 377
    invoke-direct {v1, v0, v9}, Lqw;-><init>(Ljava/lang/Object;B)V

    .line 378
    .line 379
    .line 380
    new-instance v0, Lmu5;

    .line 381
    .line 382
    const/16 v5, 0xe

    .line 383
    .line 384
    invoke-direct {v0, v5}, Lmu5;-><init>(B)V

    .line 385
    .line 386
    .line 387
    invoke-static {v1, v0}, Lm86;->p0(Li86;Lfa2;)Le32;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    new-instance v1, Lmu5;

    .line 392
    .line 393
    const/16 v5, 0xf

    .line 394
    .line 395
    invoke-direct {v1, v5}, Lmu5;-><init>(B)V

    .line 396
    .line 397
    .line 398
    invoke-static {v0, v1}, Lm86;->p0(Li86;Lfa2;)Le32;

    .line 399
    .line 400
    .line 401
    move-result-object v0

    .line 402
    invoke-static {v0}, Lm86;->q0(Li86;)Ljava/util/List;

    .line 403
    .line 404
    .line 405
    move-result-object v0

    .line 406
    iget-object v1, v3, Lko5;->a:Ljava/lang/String;

    .line 407
    .line 408
    new-instance v3, Lqw;

    .line 409
    .line 410
    invoke-direct {v3, v1, v9}, Lqw;-><init>(Ljava/lang/Object;B)V

    .line 411
    .line 412
    .line 413
    new-instance v1, Lmu5;

    .line 414
    .line 415
    const/16 v5, 0x10

    .line 416
    .line 417
    invoke-direct {v1, v5}, Lmu5;-><init>(B)V

    .line 418
    .line 419
    .line 420
    invoke-static {v3, v1}, Lm86;->p0(Li86;Lfa2;)Le32;

    .line 421
    .line 422
    .line 423
    move-result-object v1

    .line 424
    new-instance v3, Lmu5;

    .line 425
    .line 426
    const/16 v5, 0x11

    .line 427
    .line 428
    invoke-direct {v3, v5}, Lmu5;-><init>(B)V

    .line 429
    .line 430
    .line 431
    invoke-static {v1, v3}, Lm86;->p0(Li86;Lfa2;)Le32;

    .line 432
    .line 433
    .line 434
    move-result-object v1

    .line 435
    invoke-static {v1}, Lm86;->q0(Li86;)Ljava/util/List;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    new-instance v7, Lgv;

    .line 440
    .line 441
    invoke-static {v0, v1}, Liv0;->J0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    new-instance v1, Lmu5;

    .line 446
    .line 447
    const/16 v3, 0x12

    .line 448
    .line 449
    invoke-direct {v1, v3}, Lmu5;-><init>(B)V

    .line 450
    .line 451
    .line 452
    new-instance v3, Lmu5;

    .line 453
    .line 454
    const/16 v5, 0x13

    .line 455
    .line 456
    invoke-direct {v3, v5}, Lmu5;-><init>(B)V

    .line 457
    .line 458
    .line 459
    new-array v4, v4, [Lfa2;

    .line 460
    .line 461
    aput-object v1, v4, v2

    .line 462
    .line 463
    aput-object v3, v4, v6

    .line 464
    .line 465
    invoke-static {v4}, Lmm0;->B([Lfa2;)Lmy0;

    .line 466
    .line 467
    .line 468
    move-result-object v1

    .line 469
    invoke-static {v0, v1}, Liv0;->O0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 470
    .line 471
    .line 472
    move-result-object v8

    .line 473
    const/4 v11, 0x0

    .line 474
    const/16 v12, 0xe

    .line 475
    .line 476
    const/4 v9, 0x0

    .line 477
    const/4 v10, 0x0

    .line 478
    invoke-direct/range {v7 .. v12}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 479
    .line 480
    .line 481
    move-object v10, v7

    .line 482
    goto :goto_b

    .line 483
    :cond_15
    iget-object v0, v0, Lko5;->b:Ljava/lang/String;

    .line 484
    .line 485
    iget-object v1, v3, Lko5;->b:Ljava/lang/String;

    .line 486
    .line 487
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    invoke-static {v0}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 492
    .line 493
    .line 494
    move-result-object v0

    .line 495
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 496
    .line 497
    .line 498
    move-result-object v0

    .line 499
    :cond_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 500
    .line 501
    .line 502
    move-result v1

    .line 503
    if-eqz v1, :cond_17

    .line 504
    .line 505
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v1

    .line 509
    move-object v3, v1

    .line 510
    check-cast v3, Ljava/lang/String;

    .line 511
    .line 512
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 513
    .line 514
    .line 515
    move-result v3

    .line 516
    if-nez v3, :cond_16

    .line 517
    .line 518
    move-object v10, v1

    .line 519
    :cond_17
    check-cast v10, Ljava/lang/String;

    .line 520
    .line 521
    if-nez v10, :cond_18

    .line 522
    .line 523
    const v0, 0x7f0f0447

    .line 524
    .line 525
    .line 526
    new-array v1, v2, [Ljava/lang/Object;

    .line 527
    .line 528
    invoke-static {v0, v1}, Lgn;->r(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 529
    .line 530
    .line 531
    move-result-object v10

    .line 532
    :cond_18
    move-object v2, v10

    .line 533
    new-instance v0, Lgv;

    .line 534
    .line 535
    const/4 v1, 0x0

    .line 536
    const/4 v3, 0x0

    .line 537
    const/4 v4, 0x0

    .line 538
    const/16 v5, 0xd

    .line 539
    .line 540
    invoke-direct/range {v0 .. v5}, Lgv;-><init>(Ljava/lang/Object;Ljava/lang/String;Lxo4;Ljava/lang/Throwable;I)V

    .line 541
    .line 542
    .line 543
    goto/16 :goto_9

    .line 544
    .line 545
    :goto_b
    return-object v10

    .line 546
    :pswitch_4
    invoke-direct/range {p0 .. p1}, La4;->m(Ljava/lang/Object;)Ljava/lang/Object;

    .line 547
    .line 548
    .line 549
    move-result-object v0

    .line 550
    return-object v0

    .line 551
    :pswitch_5
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 552
    .line 553
    check-cast v0, Lnf1;

    .line 554
    .line 555
    sget-object v2, Lof1;->i:Lof1;

    .line 556
    .line 557
    iget-byte v7, v5, La4;->j:B

    .line 558
    .line 559
    if-eqz v7, :cond_1b

    .line 560
    .line 561
    if-eq v7, v6, :cond_1a

    .line 562
    .line 563
    if-ne v7, v4, :cond_19

    .line 564
    .line 565
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 566
    .line 567
    check-cast v0, Lorg/json/JSONObject;

    .line 568
    .line 569
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 570
    .line 571
    .line 572
    move-object v1, v0

    .line 573
    move-object/from16 v0, p1

    .line 574
    .line 575
    goto :goto_d

    .line 576
    :cond_19
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 577
    .line 578
    .line 579
    goto :goto_e

    .line 580
    :cond_1a
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 581
    .line 582
    check-cast v0, Lrk1;

    .line 583
    .line 584
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 585
    .line 586
    .line 587
    move-object/from16 v1, p1

    .line 588
    .line 589
    goto :goto_c

    .line 590
    :cond_1b
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 591
    .line 592
    .line 593
    new-instance v3, Lcn;

    .line 594
    .line 595
    const/16 v7, 0xb

    .line 596
    .line 597
    invoke-direct {v3, v4, v10, v7}, Lcn;-><init>(ILea1;B)V

    .line 598
    .line 599
    .line 600
    invoke-static {v0, v10, v3, v8}, Lpm;->i(Lnf1;Ldf1;Lja2;I)Lrk1;

    .line 601
    .line 602
    .line 603
    move-result-object v3

    .line 604
    new-instance v7, Lcn;

    .line 605
    .line 606
    invoke-direct {v7, v4, v10, v1}, Lcn;-><init>(ILea1;B)V

    .line 607
    .line 608
    .line 609
    invoke-static {v0, v10, v7, v8}, Lpm;->i(Lnf1;Ldf1;Lja2;I)Lrk1;

    .line 610
    .line 611
    .line 612
    move-result-object v0

    .line 613
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 614
    .line 615
    iput-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 616
    .line 617
    iput-byte v6, v5, La4;->j:B

    .line 618
    .line 619
    invoke-virtual {v3, v5}, Lz33;->y(Lea1;)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    move-result-object v1

    .line 623
    if-eq v1, v2, :cond_1c

    .line 624
    .line 625
    :goto_c
    check-cast v1, Lorg/json/JSONObject;

    .line 626
    .line 627
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 628
    .line 629
    iput-object v10, v5, La4;->l:Ljava/lang/Object;

    .line 630
    .line 631
    iput-object v1, v5, La4;->m:Ljava/lang/Object;

    .line 632
    .line 633
    iput-byte v4, v5, La4;->j:B

    .line 634
    .line 635
    invoke-interface {v0, v5}, Lqk1;->m(Lea1;)Ljava/lang/Object;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    if-ne v0, v2, :cond_1d

    .line 640
    .line 641
    :cond_1c
    move-object v10, v2

    .line 642
    goto :goto_e

    .line 643
    :cond_1d
    :goto_d
    check-cast v0, Lorg/json/JSONObject;

    .line 644
    .line 645
    invoke-static {v1, v0}, Lya3;->L(Lorg/json/JSONObject;Lorg/json/JSONObject;)Lso3;

    .line 646
    .line 647
    .line 648
    move-result-object v10

    .line 649
    :goto_e
    return-object v10

    .line 650
    :pswitch_6
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 651
    .line 652
    check-cast v0, Lnf1;

    .line 653
    .line 654
    sget-object v1, Lof1;->i:Lof1;

    .line 655
    .line 656
    iget-byte v2, v5, La4;->j:B

    .line 657
    .line 658
    if-eqz v2, :cond_20

    .line 659
    .line 660
    if-eq v2, v6, :cond_1f

    .line 661
    .line 662
    if-ne v2, v4, :cond_1e

    .line 663
    .line 664
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 665
    .line 666
    .line 667
    goto :goto_10

    .line 668
    :cond_1e
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 669
    .line 670
    .line 671
    goto :goto_11

    .line 672
    :cond_1f
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 673
    .line 674
    .line 675
    goto :goto_f

    .line 676
    :cond_20
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 677
    .line 678
    .line 679
    iget-object v2, v5, La4;->l:Ljava/lang/Object;

    .line 680
    .line 681
    check-cast v2, Lal6;

    .line 682
    .line 683
    if-eqz v2, :cond_21

    .line 684
    .line 685
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 686
    .line 687
    iput-byte v6, v5, La4;->j:B

    .line 688
    .line 689
    invoke-virtual {v2, v5}, Lz33;->G(Lea1;)Ljava/lang/Object;

    .line 690
    .line 691
    .line 692
    move-result-object v2

    .line 693
    if-eq v2, v1, :cond_22

    .line 694
    .line 695
    :cond_21
    :goto_f
    iget-object v2, v5, La4;->m:Ljava/lang/Object;

    .line 696
    .line 697
    check-cast v2, Lhd1;

    .line 698
    .line 699
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 700
    .line 701
    iput-byte v4, v5, La4;->j:B

    .line 702
    .line 703
    invoke-virtual {v2, v0, v5}, Lhd1;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 704
    .line 705
    .line 706
    move-result-object v0

    .line 707
    if-ne v0, v1, :cond_23

    .line 708
    .line 709
    :cond_22
    move-object v10, v1

    .line 710
    goto :goto_11

    .line 711
    :cond_23
    :goto_10
    sget-object v10, Lxc7;->a:Lxc7;

    .line 712
    .line 713
    :goto_11
    return-object v10

    .line 714
    :pswitch_7
    sget-object v0, Lof1;->i:Lof1;

    .line 715
    .line 716
    iget-byte v1, v5, La4;->j:B

    .line 717
    .line 718
    if-eqz v1, :cond_26

    .line 719
    .line 720
    if-eq v1, v6, :cond_25

    .line 721
    .line 722
    if-ne v1, v4, :cond_24

    .line 723
    .line 724
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 725
    .line 726
    .line 727
    goto :goto_13

    .line 728
    :cond_24
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 729
    .line 730
    .line 731
    goto :goto_14

    .line 732
    :cond_25
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 733
    .line 734
    check-cast v1, Lff0;

    .line 735
    .line 736
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 737
    .line 738
    .line 739
    move-object/from16 v2, p1

    .line 740
    .line 741
    goto :goto_12

    .line 742
    :cond_26
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 743
    .line 744
    .line 745
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 746
    .line 747
    check-cast v1, Lff0;

    .line 748
    .line 749
    iget-object v2, v5, La4;->m:Ljava/lang/Object;

    .line 750
    .line 751
    check-cast v2, Lib4;

    .line 752
    .line 753
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 754
    .line 755
    iput-byte v6, v5, La4;->j:B

    .line 756
    .line 757
    sget-object v3, Ldb4;->a:Ljava/util/List;

    .line 758
    .line 759
    sget-object v3, Lao1;->a:Lck1;

    .line 760
    .line 761
    sget-object v3, Luj1;->k:Luj1;

    .line 762
    .line 763
    new-instance v6, Lon;

    .line 764
    .line 765
    const/16 v7, 0xc

    .line 766
    .line 767
    invoke-direct {v6, v2, v10, v7}, Lon;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 768
    .line 769
    .line 770
    invoke-static {v3, v6, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 771
    .line 772
    .line 773
    move-result-object v2

    .line 774
    if-eq v2, v0, :cond_27

    .line 775
    .line 776
    :goto_12
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 777
    .line 778
    iput-byte v4, v5, La4;->j:B

    .line 779
    .line 780
    invoke-interface {v1, v5, v2}, Lg86;->a(Lea1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 781
    .line 782
    .line 783
    move-result-object v1

    .line 784
    if-ne v1, v0, :cond_28

    .line 785
    .line 786
    :cond_27
    move-object v10, v0

    .line 787
    goto :goto_14

    .line 788
    :cond_28
    :goto_13
    sget-object v10, Lxc7;->a:Lxc7;

    .line 789
    .line 790
    :goto_14
    return-object v10

    .line 791
    :pswitch_8
    sget-object v11, Lxc7;->a:Lxc7;

    .line 792
    .line 793
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 794
    .line 795
    check-cast v0, Ljp3;

    .line 796
    .line 797
    iget-object v12, v0, Ljp3;->H:Lmg;

    .line 798
    .line 799
    sget-object v13, Lof1;->i:Lof1;

    .line 800
    .line 801
    iget-byte v1, v5, La4;->j:B

    .line 802
    .line 803
    if-eqz v1, :cond_2f

    .line 804
    .line 805
    if-eq v1, v6, :cond_2d

    .line 806
    .line 807
    if-eq v1, v4, :cond_2c

    .line 808
    .line 809
    if-eq v1, v8, :cond_2a

    .line 810
    .line 811
    if-eq v1, v9, :cond_29

    .line 812
    .line 813
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 814
    .line 815
    .line 816
    goto/16 :goto_19

    .line 817
    .line 818
    :cond_29
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 819
    .line 820
    check-cast v0, Ljava/lang/Throwable;

    .line 821
    .line 822
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 823
    .line 824
    .line 825
    goto/16 :goto_1a

    .line 826
    .line 827
    :cond_2a
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 828
    .line 829
    .line 830
    :cond_2b
    move-object v10, v11

    .line 831
    goto/16 :goto_19

    .line 832
    .line 833
    :cond_2c
    :try_start_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 834
    .line 835
    .line 836
    move-object/from16 v0, p1

    .line 837
    .line 838
    goto/16 :goto_17

    .line 839
    .line 840
    :cond_2d
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 841
    .line 842
    check-cast v1, Lci;

    .line 843
    .line 844
    iget-object v2, v5, La4;->k:Ljava/lang/Object;

    .line 845
    .line 846
    check-cast v2, Ljava/lang/Float;

    .line 847
    .line 848
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 849
    .line 850
    .line 851
    :cond_2e
    move-object/from16 v28, v2

    .line 852
    .line 853
    move-object v2, v1

    .line 854
    move-object/from16 v1, v28

    .line 855
    .line 856
    goto :goto_16

    .line 857
    :cond_2f
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 858
    .line 859
    .line 860
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 861
    .line 862
    move-object v2, v1

    .line 863
    check-cast v2, Ljava/lang/Float;

    .line 864
    .line 865
    if-eqz v2, :cond_2b

    .line 866
    .line 867
    iget-byte v1, v0, Ljp3;->w:B

    .line 868
    .line 869
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 870
    .line 871
    .line 872
    move-result v3

    .line 873
    iget-short v14, v0, Ljp3;->y:S

    .line 874
    .line 875
    iget-short v15, v0, Ljp3;->x:S

    .line 876
    .line 877
    iget v9, v0, Ljp3;->z:F

    .line 878
    .line 879
    invoke-static {v0}, Lpm;->Q(Lal1;)Laa3;

    .line 880
    .line 881
    .line 882
    move-result-object v8

    .line 883
    iget-object v8, v8, Laa3;->G:Lkl1;

    .line 884
    .line 885
    invoke-interface {v8, v9}, Lkl1;->L(F)F

    .line 886
    .line 887
    .line 888
    move-result v8

    .line 889
    invoke-static {v8}, Ljava/lang/Math;->abs(F)F

    .line 890
    .line 891
    .line 892
    move-result v8

    .line 893
    const/high16 v9, 0x447a0000    # 1000.0f

    .line 894
    .line 895
    div-float/2addr v8, v9

    .line 896
    div-float/2addr v3, v8

    .line 897
    float-to-double v8, v3

    .line 898
    invoke-static {v8, v9}, Ljava/lang/Math;->ceil(D)D

    .line 899
    .line 900
    .line 901
    move-result-wide v8

    .line 902
    double-to-float v3, v8

    .line 903
    float-to-int v3, v3

    .line 904
    sget-object v8, Lwt1;->d:Lw91;

    .line 905
    .line 906
    new-instance v9, Lb97;

    .line 907
    .line 908
    invoke-direct {v9, v3, v15, v8}, Lb97;-><init>(IILut1;)V

    .line 909
    .line 910
    .line 911
    neg-int v3, v15

    .line 912
    add-int/2addr v3, v14

    .line 913
    mul-int/lit8 v3, v3, -0x1

    .line 914
    .line 915
    int-to-long v14, v3

    .line 916
    const v3, 0x7fffffff

    .line 917
    .line 918
    .line 919
    if-ne v1, v3, :cond_30

    .line 920
    .line 921
    invoke-static {v9, v10, v14, v15, v4}, Lfv6;->A(Lft1;Ljl5;JI)Lwx2;

    .line 922
    .line 923
    .line 924
    move-result-object v1

    .line 925
    goto :goto_15

    .line 926
    :cond_30
    new-instance v3, Lll5;

    .line 927
    .line 928
    invoke-direct {v3, v1, v9, v14, v15}, Lll5;-><init>(ILb97;J)V

    .line 929
    .line 930
    .line 931
    move-object v1, v3

    .line 932
    :goto_15
    new-instance v3, Ljava/lang/Float;

    .line 933
    .line 934
    invoke-direct {v3, v7}, Ljava/lang/Float;-><init>(F)V

    .line 935
    .line 936
    .line 937
    iput-object v2, v5, La4;->k:Ljava/lang/Object;

    .line 938
    .line 939
    iput-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 940
    .line 941
    iput-byte v6, v5, La4;->j:B

    .line 942
    .line 943
    invoke-virtual {v12, v5, v3}, Lmg;->h(Lea1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 944
    .line 945
    .line 946
    move-result-object v3

    .line 947
    if-ne v3, v13, :cond_2e

    .line 948
    .line 949
    goto :goto_18

    .line 950
    :goto_16
    :try_start_3
    iget-object v0, v0, Ljp3;->H:Lmg;

    .line 951
    .line 952
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 953
    .line 954
    iput-object v10, v5, La4;->l:Ljava/lang/Object;

    .line 955
    .line 956
    iput-byte v4, v5, La4;->j:B

    .line 957
    .line 958
    const/4 v3, 0x0

    .line 959
    const/4 v4, 0x0

    .line 960
    const/16 v6, 0xc

    .line 961
    .line 962
    invoke-static/range {v0 .. v6}, Lmg;->b(Lmg;Ljava/lang/Object;Lci;Ljava/lang/Float;Lfa2;Lea1;I)Ljava/lang/Object;

    .line 963
    .line 964
    .line 965
    move-result-object v0

    .line 966
    if-eq v0, v13, :cond_31

    .line 967
    .line 968
    :goto_17
    check-cast v0, Lai;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 969
    .line 970
    new-instance v0, Ljava/lang/Float;

    .line 971
    .line 972
    invoke-direct {v0, v7}, Ljava/lang/Float;-><init>(F)V

    .line 973
    .line 974
    .line 975
    const/4 v1, 0x3

    .line 976
    iput-byte v1, v5, La4;->j:B

    .line 977
    .line 978
    invoke-virtual {v12, v5, v0}, Lmg;->h(Lea1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 979
    .line 980
    .line 981
    move-result-object v0

    .line 982
    if-ne v0, v13, :cond_2b

    .line 983
    .line 984
    goto :goto_18

    .line 985
    :catchall_1
    move-exception v0

    .line 986
    new-instance v1, Ljava/lang/Float;

    .line 987
    .line 988
    invoke-direct {v1, v7}, Ljava/lang/Float;-><init>(F)V

    .line 989
    .line 990
    .line 991
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 992
    .line 993
    iput-object v10, v5, La4;->l:Ljava/lang/Object;

    .line 994
    .line 995
    const/4 v2, 0x4

    .line 996
    iput-byte v2, v5, La4;->j:B

    .line 997
    .line 998
    invoke-virtual {v12, v5, v1}, Lmg;->h(Lea1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 999
    .line 1000
    .line 1001
    move-result-object v1

    .line 1002
    if-ne v1, v13, :cond_32

    .line 1003
    .line 1004
    :cond_31
    :goto_18
    move-object v10, v13

    .line 1005
    :goto_19
    return-object v10

    .line 1006
    :cond_32
    :goto_1a
    throw v0

    .line 1007
    :pswitch_9
    sget-object v0, Lof1;->i:Lof1;

    .line 1008
    .line 1009
    iget-byte v1, v5, La4;->j:B

    .line 1010
    .line 1011
    const v7, 0x7f0f01f2

    .line 1012
    .line 1013
    .line 1014
    if-eqz v1, :cond_37

    .line 1015
    .line 1016
    if-eq v1, v6, :cond_36

    .line 1017
    .line 1018
    if-eq v1, v4, :cond_35

    .line 1019
    .line 1020
    const/4 v4, 0x3

    .line 1021
    if-eq v1, v4, :cond_34

    .line 1022
    .line 1023
    const/4 v4, 0x4

    .line 1024
    if-ne v1, v4, :cond_33

    .line 1025
    .line 1026
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 1027
    .line 1028
    check-cast v0, Ljava/lang/String;

    .line 1029
    .line 1030
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 1031
    .line 1032
    check-cast v1, Lmm5;

    .line 1033
    .line 1034
    iget-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 1035
    .line 1036
    check-cast v3, Ljava/io/Closeable;

    .line 1037
    .line 1038
    :try_start_4
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_6

    .line 1039
    .line 1040
    .line 1041
    goto/16 :goto_1e

    .line 1042
    .line 1043
    :cond_33
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 1044
    .line 1045
    .line 1046
    goto/16 :goto_23

    .line 1047
    .line 1048
    :cond_34
    iget-object v1, v5, La4;->m:Ljava/lang/Object;

    .line 1049
    .line 1050
    check-cast v1, Ljava/lang/String;

    .line 1051
    .line 1052
    iget-object v3, v5, La4;->l:Ljava/lang/Object;

    .line 1053
    .line 1054
    check-cast v3, Lmm5;

    .line 1055
    .line 1056
    iget-object v4, v5, La4;->k:Ljava/lang/Object;

    .line 1057
    .line 1058
    check-cast v4, Ljava/io/Closeable;

    .line 1059
    .line 1060
    :try_start_5
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 1061
    .line 1062
    .line 1063
    goto/16 :goto_1d

    .line 1064
    .line 1065
    :cond_35
    :try_start_6
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 1066
    .line 1067
    .line 1068
    move-object/from16 v1, p1

    .line 1069
    .line 1070
    goto/16 :goto_1c

    .line 1071
    .line 1072
    :cond_36
    :try_start_7
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1

    .line 1073
    .line 1074
    .line 1075
    move-object/from16 v1, p1

    .line 1076
    .line 1077
    goto :goto_1b

    .line 1078
    :cond_37
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1079
    .line 1080
    .line 1081
    :try_start_8
    sget-object v1, Lxo0;->a:Lxo0;

    .line 1082
    .line 1083
    iput-byte v6, v5, La4;->j:B

    .line 1084
    .line 1085
    sget-object v1, Lao1;->a:Lck1;

    .line 1086
    .line 1087
    sget-object v1, Luj1;->k:Luj1;

    .line 1088
    .line 1089
    new-instance v3, Lso0;

    .line 1090
    .line 1091
    invoke-direct {v3, v6, v10}, Lso0;-><init>(ZLea1;)V

    .line 1092
    .line 1093
    .line 1094
    invoke-static {v1, v3, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1095
    .line 1096
    .line 1097
    move-result-object v1

    .line 1098
    if-eq v1, v0, :cond_3a

    .line 1099
    .line 1100
    :goto_1b
    check-cast v1, Lpo0;

    .line 1101
    .line 1102
    iget-object v1, v1, Lpo0;->a:Ljava/lang/Object;

    .line 1103
    .line 1104
    check-cast v1, Loo0;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1

    .line 1105
    .line 1106
    if-nez v1, :cond_38

    .line 1107
    .line 1108
    new-instance v10, Lcq2;

    .line 1109
    .line 1110
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1111
    .line 1112
    new-array v0, v2, [Ljava/lang/Object;

    .line 1113
    .line 1114
    invoke-static {v7, v0}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v0

    .line 1118
    invoke-direct {v10, v0, v2}, Lcq2;-><init>(Ljava/lang/String;Z)V

    .line 1119
    .line 1120
    .line 1121
    goto/16 :goto_23

    .line 1122
    .line 1123
    :cond_38
    iget-object v3, v1, Loo0;->d:Ljava/lang/String;

    .line 1124
    .line 1125
    iget-object v6, v1, Loo0;->b:Ljava/lang/String;

    .line 1126
    .line 1127
    invoke-static {v6}, Llm;->z(Ljava/lang/String;)Ljava/lang/String;

    .line 1128
    .line 1129
    .line 1130
    move-result-object v6

    .line 1131
    new-instance v7, Lsh2;

    .line 1132
    .line 1133
    const/16 v8, 0x8

    .line 1134
    .line 1135
    invoke-direct {v7, v8}, Lsh2;-><init>(B)V

    .line 1136
    .line 1137
    .line 1138
    iget v1, v1, Loo0;->c:I

    .line 1139
    .line 1140
    const-string v8, ":"

    .line 1141
    .line 1142
    const-string v9, "/configs?force=true"

    .line 1143
    .line 1144
    const-string v11, "http://"

    .line 1145
    .line 1146
    invoke-static {v1, v11, v6, v8, v9}, Luj6;->l(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1147
    .line 1148
    .line 1149
    move-result-object v1

    .line 1150
    invoke-virtual {v7, v1}, Lsh2;->z(Ljava/lang/String;)V

    .line 1151
    .line 1152
    .line 1153
    sget-object v1, Lsl5;->a:Lql5;

    .line 1154
    .line 1155
    sget-object v1, Lzr3;->c:Lsk5;

    .line 1156
    .line 1157
    const-string v1, "application/json; charset=utf-8"

    .line 1158
    .line 1159
    invoke-static {v1}, Ln93;->P(Ljava/lang/String;)Lzr3;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v1

    .line 1163
    const-string v6, "{}"

    .line 1164
    .line 1165
    invoke-static {v6, v1}, Lpd5;->f(Ljava/lang/String;Lzr3;)Lrl5;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v1

    .line 1169
    const-string v6, "PUT"

    .line 1170
    .line 1171
    invoke-virtual {v7, v6, v1}, Lsh2;->u(Ljava/lang/String;Lsl5;)V

    .line 1172
    .line 1173
    .line 1174
    if-eqz v3, :cond_39

    .line 1175
    .line 1176
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1177
    .line 1178
    .line 1179
    move-result v1

    .line 1180
    if-nez v1, :cond_39

    .line 1181
    .line 1182
    const-string v1, "Bearer "

    .line 1183
    .line 1184
    invoke-virtual {v1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1185
    .line 1186
    .line 1187
    move-result-object v1

    .line 1188
    const-string v3, "Authorization"

    .line 1189
    .line 1190
    invoke-virtual {v7, v3, v1}, Lsh2;->r(Ljava/lang/String;Ljava/lang/String;)V

    .line 1191
    .line 1192
    .line 1193
    :cond_39
    :try_start_9
    sget-object v1, Lgq2;->b:Lul4;

    .line 1194
    .line 1195
    new-instance v3, Lpl5;

    .line 1196
    .line 1197
    invoke-direct {v3, v7}, Lpl5;-><init>(Lsh2;)V

    .line 1198
    .line 1199
    .line 1200
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1201
    .line 1202
    .line 1203
    new-instance v6, Lfi5;

    .line 1204
    .line 1205
    invoke-direct {v6, v1, v3, v2}, Lfi5;-><init>(Lul4;Lpl5;Z)V

    .line 1206
    .line 1207
    .line 1208
    iput-byte v4, v5, La4;->j:B

    .line 1209
    .line 1210
    invoke-static {v6, v5}, Lmm;->w(Lfi5;Lea1;)Ljava/lang/Object;

    .line 1211
    .line 1212
    .line 1213
    move-result-object v1

    .line 1214
    if-eq v1, v0, :cond_3a

    .line 1215
    .line 1216
    :goto_1c
    move-object v3, v1

    .line 1217
    check-cast v3, Ljava/io/Closeable;
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0

    .line 1218
    .line 1219
    :try_start_a
    move-object v1, v3

    .line 1220
    check-cast v1, Lmm5;

    .line 1221
    .line 1222
    iget-object v4, v1, Lmm5;->o:Lom5;

    .line 1223
    .line 1224
    invoke-virtual {v4}, Lom5;->c()J

    .line 1225
    .line 1226
    .line 1227
    move-result-wide v6

    .line 1228
    const-wide/32 v8, 0x100000

    .line 1229
    .line 1230
    .line 1231
    cmp-long v6, v6, v8

    .line 1232
    .line 1233
    if-gtz v6, :cond_3e

    .line 1234
    .line 1235
    invoke-virtual {v4}, Lom5;->b()Ljava/io/InputStream;

    .line 1236
    .line 1237
    .line 1238
    move-result-object v4
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    .line 1239
    :try_start_b
    invoke-static {v4, v8, v9}, Lpm;->K(Ljava/io/InputStream;J)Ljava/lang/String;

    .line 1240
    .line 1241
    .line 1242
    move-result-object v6

    .line 1243
    invoke-static {v6}, Lbn6;->o1(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 1244
    .line 1245
    .line 1246
    move-result-object v6

    .line 1247
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 1248
    .line 1249
    .line 1250
    move-result-object v6
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 1251
    :try_start_c
    invoke-interface {v4}, Ljava/io/Closeable;->close()V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .line 1252
    .line 1253
    .line 1254
    :try_start_d
    sget-object v4, Lcom/box/app/AppApplication;->i:Landroid/content/Context;

    .line 1255
    .line 1256
    invoke-static {}, Lnn;->t()Landroid/content/Context;

    .line 1257
    .line 1258
    .line 1259
    move-result-object v4

    .line 1260
    new-instance v7, Landroid/content/ComponentName;

    .line 1261
    .line 1262
    invoke-static {}, Lnn;->t()Landroid/content/Context;

    .line 1263
    .line 1264
    .line 1265
    move-result-object v8

    .line 1266
    const-class v9, Lcom/box/app/tile/BoxServiceTileService;

    .line 1267
    .line 1268
    invoke-direct {v7, v8, v9}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1269
    .line 1270
    .line 1271
    invoke-static {v4, v7}, Landroid/service/quicksettings/TileService;->requestListeningState(Landroid/content/Context;Landroid/content/ComponentName;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    .line 1272
    .line 1273
    .line 1274
    :catchall_2
    :try_start_e
    sget-object v4, Lzb0;->a:Lzb0;

    .line 1275
    .line 1276
    sget-object v7, Lcom/box/app/AppApplication;->i:Landroid/content/Context;

    .line 1277
    .line 1278
    invoke-static {}, Lnn;->t()Landroid/content/Context;

    .line 1279
    .line 1280
    .line 1281
    move-result-object v7

    .line 1282
    iget-boolean v8, v1, Lmm5;->x:Z

    .line 1283
    .line 1284
    iput-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 1285
    .line 1286
    iput-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 1287
    .line 1288
    iput-object v6, v5, La4;->m:Ljava/lang/Object;

    .line 1289
    .line 1290
    const/4 v9, 0x3

    .line 1291
    iput-byte v9, v5, La4;->j:B

    .line 1292
    .line 1293
    invoke-virtual {v4, v7, v8, v5}, Lzb0;->c(Landroid/content/Context;ZLfa1;)Ljava/lang/Object;

    .line 1294
    .line 1295
    .line 1296
    move-result-object v4
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    .line 1297
    if-eq v4, v0, :cond_3a

    .line 1298
    .line 1299
    move-object v4, v3

    .line 1300
    move-object v3, v1

    .line 1301
    move-object v1, v6

    .line 1302
    :goto_1d
    :try_start_f
    sget-object v6, Lvc0;->a:Lvc0;

    .line 1303
    .line 1304
    iput-object v4, v5, La4;->k:Ljava/lang/Object;

    .line 1305
    .line 1306
    iput-object v3, v5, La4;->l:Ljava/lang/Object;

    .line 1307
    .line 1308
    iput-object v1, v5, La4;->m:Ljava/lang/Object;

    .line 1309
    .line 1310
    const/4 v7, 0x4

    .line 1311
    iput-byte v7, v5, La4;->j:B

    .line 1312
    .line 1313
    invoke-virtual {v6, v5}, Lvc0;->u(Lfa1;)Ljava/lang/Object;

    .line 1314
    .line 1315
    .line 1316
    move-result-object v5
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_3

    .line 1317
    if-ne v5, v0, :cond_3b

    .line 1318
    .line 1319
    :cond_3a
    move-object v10, v0

    .line 1320
    goto/16 :goto_23

    .line 1321
    .line 1322
    :cond_3b
    move-object v0, v1

    .line 1323
    move-object v1, v3

    .line 1324
    move-object v3, v4

    .line 1325
    :goto_1e
    :try_start_10
    iget-boolean v4, v1, Lmm5;->x:Z

    .line 1326
    .line 1327
    if-eqz v4, :cond_3c

    .line 1328
    .line 1329
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1330
    .line 1331
    .line 1332
    move-result v1

    .line 1333
    if-eqz v1, :cond_3d

    .line 1334
    .line 1335
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1336
    .line 1337
    new-array v0, v2, [Ljava/lang/Object;

    .line 1338
    .line 1339
    const v1, 0x7f0f01f3

    .line 1340
    .line 1341
    .line 1342
    invoke-static {v1, v0}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1343
    .line 1344
    .line 1345
    move-result-object v0

    .line 1346
    goto :goto_20

    .line 1347
    :cond_3c
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1348
    .line 1349
    .line 1350
    move-result v5

    .line 1351
    if-eqz v5, :cond_3d

    .line 1352
    .line 1353
    iget-object v0, v1, Lmm5;->k:Ljava/lang/String;

    .line 1354
    .line 1355
    invoke-static {v0}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1356
    .line 1357
    .line 1358
    move-result v5

    .line 1359
    if-eqz v5, :cond_3d

    .line 1360
    .line 1361
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1362
    .line 1363
    iget v0, v1, Lmm5;->l:I

    .line 1364
    .line 1365
    new-instance v1, Ljava/lang/Integer;

    .line 1366
    .line 1367
    invoke-direct {v1, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 1368
    .line 1369
    .line 1370
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 1371
    .line 1372
    .line 1373
    move-result-object v0

    .line 1374
    const v1, 0x7f0f00c5

    .line 1375
    .line 1376
    .line 1377
    invoke-static {v1, v0}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1378
    .line 1379
    .line 1380
    move-result-object v0

    .line 1381
    goto :goto_20

    .line 1382
    :goto_1f
    move-object v1, v0

    .line 1383
    goto :goto_21

    .line 1384
    :cond_3d
    :goto_20
    new-instance v1, Lcq2;

    .line 1385
    .line 1386
    invoke-direct {v1, v0, v4}, Lcq2;-><init>(Ljava/lang/String;Z)V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    .line 1387
    .line 1388
    .line 1389
    :try_start_11
    invoke-static {v3, v10}, Lrq;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_0

    .line 1390
    .line 1391
    .line 1392
    move-object v10, v1

    .line 1393
    goto :goto_23

    .line 1394
    :catchall_3
    move-exception v0

    .line 1395
    move-object v1, v0

    .line 1396
    move-object v3, v4

    .line 1397
    goto :goto_21

    .line 1398
    :catchall_4
    move-exception v0

    .line 1399
    move-object v1, v0

    .line 1400
    :try_start_12
    throw v1
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    .line 1401
    :catchall_5
    move-exception v0

    .line 1402
    :try_start_13
    invoke-static {v4, v1}, Lrq;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1403
    .line 1404
    .line 1405
    throw v0

    .line 1406
    :cond_3e
    new-instance v0, Ls91;

    .line 1407
    .line 1408
    invoke-direct {v0, v8, v9}, Ls91;-><init>(J)V

    .line 1409
    .line 1410
    .line 1411
    throw v0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_6

    .line 1412
    :catchall_6
    move-exception v0

    .line 1413
    goto :goto_1f

    .line 1414
    :goto_21
    :try_start_14
    throw v1
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_7

    .line 1415
    :catchall_7
    move-exception v0

    .line 1416
    :try_start_15
    invoke-static {v3, v1}, Lrq;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1417
    .line 1418
    .line 1419
    throw v0
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_0

    .line 1420
    :catch_0
    move-exception v0

    .line 1421
    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    .line 1422
    .line 1423
    if-nez v1, :cond_41

    .line 1424
    .line 1425
    new-instance v10, Lcq2;

    .line 1426
    .line 1427
    instance-of v1, v0, Ls91;

    .line 1428
    .line 1429
    if-eqz v1, :cond_3f

    .line 1430
    .line 1431
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1432
    .line 1433
    const v0, 0x7f0f00bb

    .line 1434
    .line 1435
    .line 1436
    new-array v1, v2, [Ljava/lang/Object;

    .line 1437
    .line 1438
    invoke-static {v0, v1}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1439
    .line 1440
    .line 1441
    move-result-object v0

    .line 1442
    goto :goto_22

    .line 1443
    :cond_3f
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1444
    .line 1445
    .line 1446
    move-result-object v0

    .line 1447
    if-nez v0, :cond_40

    .line 1448
    .line 1449
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1450
    .line 1451
    const v0, 0x7f0f01f4

    .line 1452
    .line 1453
    .line 1454
    new-array v1, v2, [Ljava/lang/Object;

    .line 1455
    .line 1456
    invoke-static {v0, v1}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1457
    .line 1458
    .line 1459
    move-result-object v0

    .line 1460
    :cond_40
    :goto_22
    invoke-direct {v10, v0, v2}, Lcq2;-><init>(Ljava/lang/String;Z)V

    .line 1461
    .line 1462
    .line 1463
    goto :goto_23

    .line 1464
    :cond_41
    throw v0

    .line 1465
    :catch_1
    move-exception v0

    .line 1466
    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    .line 1467
    .line 1468
    if-nez v1, :cond_43

    .line 1469
    .line 1470
    new-instance v10, Lcq2;

    .line 1471
    .line 1472
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1473
    .line 1474
    .line 1475
    move-result-object v0

    .line 1476
    if-nez v0, :cond_42

    .line 1477
    .line 1478
    sget-object v0, Lgq2;->a:Lgq2;

    .line 1479
    .line 1480
    new-array v0, v2, [Ljava/lang/Object;

    .line 1481
    .line 1482
    invoke-static {v7, v0}, Lgq2;->c(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 1483
    .line 1484
    .line 1485
    move-result-object v0

    .line 1486
    :cond_42
    invoke-direct {v10, v0, v2}, Lcq2;-><init>(Ljava/lang/String;Z)V

    .line 1487
    .line 1488
    .line 1489
    :goto_23
    return-object v10

    .line 1490
    :cond_43
    throw v0

    .line 1491
    :pswitch_a
    sget-object v0, Lof1;->i:Lof1;

    .line 1492
    .line 1493
    iget-byte v1, v5, La4;->j:B

    .line 1494
    .line 1495
    if-eqz v1, :cond_46

    .line 1496
    .line 1497
    if-eq v1, v6, :cond_45

    .line 1498
    .line 1499
    if-ne v1, v4, :cond_44

    .line 1500
    .line 1501
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 1502
    .line 1503
    check-cast v0, Ly44;

    .line 1504
    .line 1505
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 1506
    .line 1507
    check-cast v1, Ly44;

    .line 1508
    .line 1509
    :try_start_16
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_8

    .line 1510
    .line 1511
    .line 1512
    move-object v3, v1

    .line 1513
    move-object v1, v0

    .line 1514
    goto :goto_25

    .line 1515
    :catchall_8
    move-exception v0

    .line 1516
    goto/16 :goto_28

    .line 1517
    .line 1518
    :cond_44
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 1519
    .line 1520
    .line 1521
    goto/16 :goto_27

    .line 1522
    .line 1523
    :cond_45
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 1524
    .line 1525
    check-cast v1, Lqo2;

    .line 1526
    .line 1527
    iget-object v3, v5, La4;->l:Ljava/lang/Object;

    .line 1528
    .line 1529
    check-cast v3, Ly44;

    .line 1530
    .line 1531
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1532
    .line 1533
    .line 1534
    goto :goto_24

    .line 1535
    :cond_46
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1536
    .line 1537
    .line 1538
    sget-object v1, Lzo2;->j:Ly44;

    .line 1539
    .line 1540
    iget-object v3, v5, La4;->m:Ljava/lang/Object;

    .line 1541
    .line 1542
    check-cast v3, Lqo2;

    .line 1543
    .line 1544
    iput-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 1545
    .line 1546
    iput-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 1547
    .line 1548
    iput-byte v6, v5, La4;->j:B

    .line 1549
    .line 1550
    invoke-virtual {v1, v5}, Ly44;->e(Lea1;)Ljava/lang/Object;

    .line 1551
    .line 1552
    .line 1553
    move-result-object v6

    .line 1554
    if-eq v6, v0, :cond_47

    .line 1555
    .line 1556
    move-object/from16 v28, v3

    .line 1557
    .line 1558
    move-object v3, v1

    .line 1559
    move-object/from16 v1, v28

    .line 1560
    .line 1561
    :goto_24
    :try_start_17
    sget-wide v6, Lzo2;->A:J

    .line 1562
    .line 1563
    iget-wide v8, v1, Lqo2;->a:J

    .line 1564
    .line 1565
    cmp-long v6, v6, v8

    .line 1566
    .line 1567
    if-nez v6, :cond_49

    .line 1568
    .line 1569
    sget-wide v6, Lzo2;->y:J

    .line 1570
    .line 1571
    iget-wide v8, v1, Lqo2;->b:J

    .line 1572
    .line 1573
    cmp-long v1, v6, v8

    .line 1574
    .line 1575
    if-nez v1, :cond_49

    .line 1576
    .line 1577
    sget-object v1, Lzo2;->i:Ly44;

    .line 1578
    .line 1579
    iput-object v3, v5, La4;->l:Ljava/lang/Object;

    .line 1580
    .line 1581
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 1582
    .line 1583
    iput-byte v4, v5, La4;->j:B

    .line 1584
    .line 1585
    invoke-virtual {v1, v5}, Ly44;->e(Lea1;)Ljava/lang/Object;

    .line 1586
    .line 1587
    .line 1588
    move-result-object v4
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_a

    .line 1589
    if-ne v4, v0, :cond_48

    .line 1590
    .line 1591
    :cond_47
    move-object v10, v0

    .line 1592
    goto :goto_27

    .line 1593
    :cond_48
    :goto_25
    :try_start_18
    sget-object v0, Lzo2;->c:Lql6;

    .line 1594
    .line 1595
    invoke-virtual {v0}, Lql6;->getValue()Ljava/lang/Object;

    .line 1596
    .line 1597
    .line 1598
    move-result-object v4

    .line 1599
    move-object v11, v4

    .line 1600
    check-cast v11, Lpo2;

    .line 1601
    .line 1602
    const/16 v26, 0x0

    .line 1603
    .line 1604
    const/16 v27, 0x3fff

    .line 1605
    .line 1606
    const/4 v12, 0x0

    .line 1607
    const-wide/16 v13, 0x0

    .line 1608
    .line 1609
    const-wide/16 v15, 0x0

    .line 1610
    .line 1611
    const/16 v17, 0x0

    .line 1612
    .line 1613
    const/16 v18, 0x0

    .line 1614
    .line 1615
    const/16 v19, 0x0

    .line 1616
    .line 1617
    const/16 v20, 0x0

    .line 1618
    .line 1619
    const/16 v21, 0x0

    .line 1620
    .line 1621
    const/16 v22, 0x0

    .line 1622
    .line 1623
    const/16 v23, 0x0

    .line 1624
    .line 1625
    const/16 v24, 0x0

    .line 1626
    .line 1627
    const/16 v25, 0x0

    .line 1628
    .line 1629
    invoke-static/range {v11 .. v27}, Lpo2;->a(Lpo2;ZJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;ZI)Lpo2;

    .line 1630
    .line 1631
    .line 1632
    move-result-object v4

    .line 1633
    invoke-virtual {v0, v10, v4}, Lql6;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1634
    .line 1635
    .line 1636
    sget-object v0, Lzo2;->g:Lql6;

    .line 1637
    .line 1638
    invoke-virtual {v0}, Lql6;->getValue()Ljava/lang/Object;

    .line 1639
    .line 1640
    .line 1641
    move-result-object v4

    .line 1642
    check-cast v4, Lmo2;

    .line 1643
    .line 1644
    const/16 v5, 0x7e

    .line 1645
    .line 1646
    invoke-static {v4, v2, v10, v2, v5}, Lmo2;->a(Lmo2;ZLjava/lang/String;ZI)Lmo2;

    .line 1647
    .line 1648
    .line 1649
    move-result-object v2

    .line 1650
    invoke-virtual {v0, v10, v2}, Lql6;->m(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_9

    .line 1651
    .line 1652
    .line 1653
    :try_start_19
    invoke-virtual {v1, v10}, Ly44;->g(Ljava/lang/Object;)V

    .line 1654
    .line 1655
    .line 1656
    goto :goto_26

    .line 1657
    :catchall_9
    move-exception v0

    .line 1658
    invoke-virtual {v1, v10}, Ly44;->g(Ljava/lang/Object;)V

    .line 1659
    .line 1660
    .line 1661
    throw v0
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_a

    .line 1662
    :cond_49
    :goto_26
    invoke-virtual {v3, v10}, Ly44;->g(Ljava/lang/Object;)V

    .line 1663
    .line 1664
    .line 1665
    sget-object v10, Lxc7;->a:Lxc7;

    .line 1666
    .line 1667
    :goto_27
    return-object v10

    .line 1668
    :catchall_a
    move-exception v0

    .line 1669
    move-object v1, v3

    .line 1670
    :goto_28
    invoke-virtual {v1, v10}, Ly44;->g(Ljava/lang/Object;)V

    .line 1671
    .line 1672
    .line 1673
    throw v0

    .line 1674
    :pswitch_b
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 1675
    .line 1676
    check-cast v0, Lf55;

    .line 1677
    .line 1678
    sget-object v2, Lof1;->i:Lof1;

    .line 1679
    .line 1680
    iget-byte v7, v5, La4;->j:B

    .line 1681
    .line 1682
    if-eqz v7, :cond_4c

    .line 1683
    .line 1684
    if-eq v7, v6, :cond_4b

    .line 1685
    .line 1686
    if-ne v7, v4, :cond_4a

    .line 1687
    .line 1688
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 1689
    .line 1690
    check-cast v0, Lf55;

    .line 1691
    .line 1692
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1693
    .line 1694
    .line 1695
    move-object/from16 v1, p1

    .line 1696
    .line 1697
    goto :goto_2a

    .line 1698
    :cond_4a
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 1699
    .line 1700
    .line 1701
    goto :goto_2b

    .line 1702
    :cond_4b
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1703
    .line 1704
    .line 1705
    goto :goto_29

    .line 1706
    :cond_4c
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1707
    .line 1708
    .line 1709
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 1710
    .line 1711
    iput-byte v6, v5, La4;->j:B

    .line 1712
    .line 1713
    const-wide/16 v6, 0xfa

    .line 1714
    .line 1715
    invoke-static {v6, v7, v5}, Lmm;->H(JLea1;)Ljava/lang/Object;

    .line 1716
    .line 1717
    .line 1718
    move-result-object v3

    .line 1719
    if-eq v3, v2, :cond_4d

    .line 1720
    .line 1721
    :goto_29
    sget-object v3, Lao1;->a:Lck1;

    .line 1722
    .line 1723
    new-instance v6, Lon;

    .line 1724
    .line 1725
    iget-object v7, v5, La4;->m:Ljava/lang/Object;

    .line 1726
    .line 1727
    check-cast v7, Li41;

    .line 1728
    .line 1729
    invoke-direct {v6, v7, v10, v1}, Lon;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 1730
    .line 1731
    .line 1732
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 1733
    .line 1734
    iput-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 1735
    .line 1736
    iput-byte v4, v5, La4;->j:B

    .line 1737
    .line 1738
    invoke-static {v3, v6, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1739
    .line 1740
    .line 1741
    move-result-object v1

    .line 1742
    if-ne v1, v2, :cond_4e

    .line 1743
    .line 1744
    :cond_4d
    move-object v10, v2

    .line 1745
    goto :goto_2b

    .line 1746
    :cond_4e
    :goto_2a
    invoke-virtual {v0, v1}, Lf55;->setValue(Ljava/lang/Object;)V

    .line 1747
    .line 1748
    .line 1749
    sget-object v10, Lxc7;->a:Lxc7;

    .line 1750
    .line 1751
    :goto_2b
    return-object v10

    .line 1752
    :pswitch_c
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 1753
    .line 1754
    check-cast v0, Lcom/box/app/tile/BoxServiceTileService;

    .line 1755
    .line 1756
    sget-object v1, Lof1;->i:Lof1;

    .line 1757
    .line 1758
    iget-byte v7, v5, La4;->j:B

    .line 1759
    .line 1760
    if-eqz v7, :cond_53

    .line 1761
    .line 1762
    if-eq v7, v6, :cond_52

    .line 1763
    .line 1764
    if-eq v7, v4, :cond_51

    .line 1765
    .line 1766
    const/4 v4, 0x3

    .line 1767
    if-eq v7, v4, :cond_50

    .line 1768
    .line 1769
    const/4 v4, 0x4

    .line 1770
    if-ne v7, v4, :cond_4f

    .line 1771
    .line 1772
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 1773
    .line 1774
    check-cast v1, Lcom/box/app/tile/BoxServiceTileService;

    .line 1775
    .line 1776
    iget-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 1777
    .line 1778
    check-cast v3, Lcq2;

    .line 1779
    .line 1780
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1781
    .line 1782
    .line 1783
    move-object/from16 v4, p1

    .line 1784
    .line 1785
    goto/16 :goto_30

    .line 1786
    .line 1787
    :cond_4f
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 1788
    .line 1789
    .line 1790
    goto/16 :goto_31

    .line 1791
    .line 1792
    :cond_50
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1793
    .line 1794
    .line 1795
    move-object/from16 v3, p1

    .line 1796
    .line 1797
    goto :goto_2e

    .line 1798
    :cond_51
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1799
    .line 1800
    .line 1801
    move-object/from16 v3, p1

    .line 1802
    .line 1803
    goto :goto_2d

    .line 1804
    :cond_52
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1805
    .line 1806
    .line 1807
    move-object/from16 v3, p1

    .line 1808
    .line 1809
    goto :goto_2c

    .line 1810
    :cond_53
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1811
    .line 1812
    .line 1813
    iput-byte v6, v5, La4;->j:B

    .line 1814
    .line 1815
    sget-object v3, Lao1;->a:Lck1;

    .line 1816
    .line 1817
    sget-object v3, Luj1;->k:Luj1;

    .line 1818
    .line 1819
    new-instance v7, Ldd0;

    .line 1820
    .line 1821
    invoke-direct {v7, v6, v6, v6, v10}, Ldd0;-><init>(ZZZLea1;)V

    .line 1822
    .line 1823
    .line 1824
    invoke-static {v3, v7, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1825
    .line 1826
    .line 1827
    move-result-object v3

    .line 1828
    if-eq v3, v1, :cond_55

    .line 1829
    .line 1830
    :goto_2c
    check-cast v3, Lad0;

    .line 1831
    .line 1832
    iget-object v3, v3, Lad0;->a:Lcd0;

    .line 1833
    .line 1834
    iget-boolean v3, v3, Lcd0;->a:Z

    .line 1835
    .line 1836
    if-ne v3, v6, :cond_54

    .line 1837
    .line 1838
    sget-object v3, Lgq2;->a:Lgq2;

    .line 1839
    .line 1840
    iput-byte v4, v5, La4;->j:B

    .line 1841
    .line 1842
    sget-object v3, Lao1;->a:Lck1;

    .line 1843
    .line 1844
    sget-object v3, Luj1;->k:Luj1;

    .line 1845
    .line 1846
    new-instance v7, Leq2;

    .line 1847
    .line 1848
    invoke-direct {v7, v4, v10, v4}, Leq2;-><init>(ILea1;B)V

    .line 1849
    .line 1850
    .line 1851
    invoke-static {v3, v7, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1852
    .line 1853
    .line 1854
    move-result-object v3

    .line 1855
    if-eq v3, v1, :cond_55

    .line 1856
    .line 1857
    :goto_2d
    check-cast v3, Lcq2;

    .line 1858
    .line 1859
    goto :goto_2f

    .line 1860
    :cond_54
    sget-object v3, Lgq2;->a:Lgq2;

    .line 1861
    .line 1862
    const/4 v9, 0x3

    .line 1863
    iput-byte v9, v5, La4;->j:B

    .line 1864
    .line 1865
    sget-object v3, Lao1;->a:Lck1;

    .line 1866
    .line 1867
    sget-object v3, Luj1;->k:Luj1;

    .line 1868
    .line 1869
    new-instance v7, Leq2;

    .line 1870
    .line 1871
    invoke-direct {v7, v4, v10, v6}, Leq2;-><init>(ILea1;B)V

    .line 1872
    .line 1873
    .line 1874
    invoke-static {v3, v7, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1875
    .line 1876
    .line 1877
    move-result-object v3

    .line 1878
    if-eq v3, v1, :cond_55

    .line 1879
    .line 1880
    :goto_2e
    check-cast v3, Lcq2;

    .line 1881
    .line 1882
    :goto_2f
    iput-object v3, v5, La4;->k:Ljava/lang/Object;

    .line 1883
    .line 1884
    iput-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 1885
    .line 1886
    const/4 v4, 0x4

    .line 1887
    iput-byte v4, v5, La4;->j:B

    .line 1888
    .line 1889
    sget-object v4, Lao1;->a:Lck1;

    .line 1890
    .line 1891
    sget-object v4, Luj1;->k:Luj1;

    .line 1892
    .line 1893
    new-instance v7, Ldd0;

    .line 1894
    .line 1895
    invoke-direct {v7, v6, v6, v6, v10}, Ldd0;-><init>(ZZZLea1;)V

    .line 1896
    .line 1897
    .line 1898
    invoke-static {v4, v7, v5}, Lpm;->U(Ldf1;Lja2;Lea1;)Ljava/lang/Object;

    .line 1899
    .line 1900
    .line 1901
    move-result-object v4

    .line 1902
    if-ne v4, v1, :cond_56

    .line 1903
    .line 1904
    :cond_55
    move-object v10, v1

    .line 1905
    goto :goto_31

    .line 1906
    :cond_56
    move-object v1, v0

    .line 1907
    :goto_30
    check-cast v4, Lad0;

    .line 1908
    .line 1909
    iget-object v4, v4, Lad0;->a:Lcd0;

    .line 1910
    .line 1911
    iget-boolean v4, v4, Lcd0;->a:Z

    .line 1912
    .line 1913
    if-eq v4, v6, :cond_57

    .line 1914
    .line 1915
    move v6, v2

    .line 1916
    :cond_57
    sget v4, Lcom/box/app/tile/BoxServiceTileService;->j:I

    .line 1917
    .line 1918
    invoke-virtual {v1, v6}, Lcom/box/app/tile/BoxServiceTileService;->a(Z)V

    .line 1919
    .line 1920
    .line 1921
    iget-boolean v1, v3, Lcq2;->a:Z

    .line 1922
    .line 1923
    if-nez v1, :cond_59

    .line 1924
    .line 1925
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1926
    .line 1927
    .line 1928
    move-result-object v1

    .line 1929
    iget-object v3, v3, Lcq2;->b:Ljava/lang/String;

    .line 1930
    .line 1931
    invoke-static {v3}, Lbn6;->Q0(Ljava/lang/CharSequence;)Z

    .line 1932
    .line 1933
    .line 1934
    move-result v4

    .line 1935
    if-eqz v4, :cond_58

    .line 1936
    .line 1937
    const v3, 0x7f0f01ed

    .line 1938
    .line 1939
    .line 1940
    invoke-virtual {v0, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1941
    .line 1942
    .line 1943
    move-result-object v3

    .line 1944
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1945
    .line 1946
    .line 1947
    :cond_58
    invoke-static {v1, v3, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 1948
    .line 1949
    .line 1950
    move-result-object v0

    .line 1951
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 1952
    .line 1953
    .line 1954
    :cond_59
    sget-object v10, Lxc7;->a:Lxc7;

    .line 1955
    .line 1956
    :goto_31
    return-object v10

    .line 1957
    :pswitch_d
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 1958
    .line 1959
    check-cast v0, Lw42;

    .line 1960
    .line 1961
    sget-object v8, Lof1;->i:Lof1;

    .line 1962
    .line 1963
    iget-byte v1, v5, La4;->j:B

    .line 1964
    .line 1965
    if-eqz v1, :cond_5c

    .line 1966
    .line 1967
    if-eq v1, v6, :cond_5b

    .line 1968
    .line 1969
    if-ne v1, v4, :cond_5a

    .line 1970
    .line 1971
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1972
    .line 1973
    .line 1974
    goto :goto_33

    .line 1975
    :cond_5a
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 1976
    .line 1977
    .line 1978
    goto :goto_34

    .line 1979
    :cond_5b
    :try_start_1a
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_1a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1a .. :try_end_1a} :catch_2

    .line 1980
    .line 1981
    .line 1982
    goto :goto_32

    .line 1983
    :cond_5c
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 1984
    .line 1985
    .line 1986
    :try_start_1b
    new-instance v1, Lu60;

    .line 1987
    .line 1988
    iget-object v3, v5, La4;->m:Ljava/lang/Object;

    .line 1989
    .line 1990
    check-cast v3, Lmg;

    .line 1991
    .line 1992
    invoke-direct {v1, v3, v2}, Lu60;-><init>(Lmg;B)V

    .line 1993
    .line 1994
    .line 1995
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 1996
    .line 1997
    iput-byte v6, v5, La4;->j:B

    .line 1998
    .line 1999
    invoke-interface {v0, v1, v5}, Lw42;->a(Lx42;Lea1;)Ljava/lang/Object;

    .line 2000
    .line 2001
    .line 2002
    move-result-object v0

    .line 2003
    if-eq v0, v8, :cond_5d

    .line 2004
    .line 2005
    :goto_32
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 2006
    .line 2007
    check-cast v0, Lu92;

    .line 2008
    .line 2009
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;
    :try_end_1b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1b .. :try_end_1b} :catch_2

    .line 2010
    .line 2011
    .line 2012
    goto :goto_33

    .line 2013
    :catch_2
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 2014
    .line 2015
    check-cast v0, Lmg;

    .line 2016
    .line 2017
    new-instance v1, Ljava/lang/Float;

    .line 2018
    .line 2019
    invoke-direct {v1, v7}, Ljava/lang/Float;-><init>(F)V

    .line 2020
    .line 2021
    .line 2022
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 2023
    .line 2024
    iput-byte v4, v5, La4;->j:B

    .line 2025
    .line 2026
    const/4 v2, 0x0

    .line 2027
    const/4 v3, 0x0

    .line 2028
    const/4 v4, 0x0

    .line 2029
    const/16 v6, 0xe

    .line 2030
    .line 2031
    invoke-static/range {v0 .. v6}, Lmg;->b(Lmg;Ljava/lang/Object;Lci;Ljava/lang/Float;Lfa2;Lea1;I)Ljava/lang/Object;

    .line 2032
    .line 2033
    .line 2034
    move-result-object v0

    .line 2035
    if-ne v0, v8, :cond_5e

    .line 2036
    .line 2037
    :cond_5d
    move-object v10, v8

    .line 2038
    goto :goto_34

    .line 2039
    :cond_5e
    :goto_33
    sget-object v10, Lxc7;->a:Lxc7;

    .line 2040
    .line 2041
    :goto_34
    return-object v10

    .line 2042
    :pswitch_e
    sget-object v0, Lof1;->i:Lof1;

    .line 2043
    .line 2044
    iget-byte v1, v5, La4;->j:B

    .line 2045
    .line 2046
    if-eqz v1, :cond_61

    .line 2047
    .line 2048
    if-eq v1, v6, :cond_60

    .line 2049
    .line 2050
    if-ne v1, v4, :cond_5f

    .line 2051
    .line 2052
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 2053
    .line 2054
    check-cast v1, Lcf0;

    .line 2055
    .line 2056
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2057
    .line 2058
    .line 2059
    goto :goto_35

    .line 2060
    :cond_5f
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 2061
    .line 2062
    .line 2063
    goto :goto_37

    .line 2064
    :cond_60
    iget-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 2065
    .line 2066
    check-cast v1, Lcf0;

    .line 2067
    .line 2068
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2069
    .line 2070
    .line 2071
    move-object/from16 v2, p1

    .line 2072
    .line 2073
    goto :goto_36

    .line 2074
    :cond_61
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2075
    .line 2076
    .line 2077
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 2078
    .line 2079
    check-cast v1, Lqm0;

    .line 2080
    .line 2081
    invoke-interface {v1}, Lqm0;->iterator()Lcf0;

    .line 2082
    .line 2083
    .line 2084
    move-result-object v1

    .line 2085
    :cond_62
    :goto_35
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 2086
    .line 2087
    iput-byte v6, v5, La4;->j:B

    .line 2088
    .line 2089
    invoke-virtual {v1, v5}, Lcf0;->b(Lea1;)Ljava/lang/Object;

    .line 2090
    .line 2091
    .line 2092
    move-result-object v2

    .line 2093
    if-eq v2, v0, :cond_63

    .line 2094
    .line 2095
    :goto_36
    check-cast v2, Ljava/lang/Boolean;

    .line 2096
    .line 2097
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 2098
    .line 2099
    .line 2100
    move-result v2

    .line 2101
    if-eqz v2, :cond_64

    .line 2102
    .line 2103
    invoke-virtual {v1}, Lcf0;->c()Ljava/lang/Object;

    .line 2104
    .line 2105
    .line 2106
    move-result-object v2

    .line 2107
    check-cast v2, Ljava/lang/Number;

    .line 2108
    .line 2109
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 2110
    .line 2111
    .line 2112
    move-result v2

    .line 2113
    iget-object v3, v5, La4;->m:Ljava/lang/Object;

    .line 2114
    .line 2115
    check-cast v3, Lmg;

    .line 2116
    .line 2117
    new-instance v7, Ljava/lang/Float;

    .line 2118
    .line 2119
    invoke-direct {v7, v2}, Ljava/lang/Float;-><init>(F)V

    .line 2120
    .line 2121
    .line 2122
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 2123
    .line 2124
    iput-byte v4, v5, La4;->j:B

    .line 2125
    .line 2126
    invoke-virtual {v3, v5, v7}, Lmg;->h(Lea1;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2127
    .line 2128
    .line 2129
    move-result-object v2

    .line 2130
    if-ne v2, v0, :cond_62

    .line 2131
    .line 2132
    :cond_63
    move-object v10, v0

    .line 2133
    goto :goto_37

    .line 2134
    :cond_64
    sget-object v10, Lxc7;->a:Lxc7;

    .line 2135
    .line 2136
    :goto_37
    return-object v10

    .line 2137
    :pswitch_f
    iget-object v0, v5, La4;->l:Ljava/lang/Object;

    .line 2138
    .line 2139
    move-object v1, v0

    .line 2140
    check-cast v1, Lql6;

    .line 2141
    .line 2142
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 2143
    .line 2144
    move-object v2, v0

    .line 2145
    check-cast v2, Li67;

    .line 2146
    .line 2147
    sget-object v7, Lof1;->i:Lof1;

    .line 2148
    .line 2149
    iget-byte v0, v5, La4;->j:B

    .line 2150
    .line 2151
    if-eqz v0, :cond_68

    .line 2152
    .line 2153
    if-eq v0, v6, :cond_67

    .line 2154
    .line 2155
    if-eq v0, v4, :cond_66

    .line 2156
    .line 2157
    const/4 v4, 0x3

    .line 2158
    if-eq v0, v4, :cond_65

    .line 2159
    .line 2160
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 2161
    .line 2162
    .line 2163
    goto :goto_3a

    .line 2164
    :cond_65
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 2165
    .line 2166
    check-cast v0, Ljava/lang/Throwable;

    .line 2167
    .line 2168
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2169
    .line 2170
    .line 2171
    goto :goto_3b

    .line 2172
    :cond_66
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2173
    .line 2174
    .line 2175
    goto :goto_39

    .line 2176
    :cond_67
    :try_start_1c
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_b

    .line 2177
    .line 2178
    .line 2179
    goto :goto_38

    .line 2180
    :cond_68
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2181
    .line 2182
    .line 2183
    :try_start_1d
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 2184
    .line 2185
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2186
    .line 2187
    .line 2188
    invoke-virtual {v1, v10, v0}, Lql6;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2189
    .line 2190
    .line 2191
    sget-object v0, Lp44;->k:Lp44;

    .line 2192
    .line 2193
    iput-byte v6, v5, La4;->j:B

    .line 2194
    .line 2195
    invoke-virtual {v2, v0, v5}, Li67;->c(Lp44;Lvr6;)Ljava/lang/Object;

    .line 2196
    .line 2197
    .line 2198
    move-result-object v0
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_b

    .line 2199
    if-eq v0, v7, :cond_6a

    .line 2200
    .line 2201
    :goto_38
    invoke-virtual {v2}, Li67;->b()Z

    .line 2202
    .line 2203
    .line 2204
    move-result v0

    .line 2205
    if-eqz v0, :cond_69

    .line 2206
    .line 2207
    new-instance v0, Lw10;

    .line 2208
    .line 2209
    invoke-direct {v0, v2, v10, v6}, Lw10;-><init>(Li67;Lea1;B)V

    .line 2210
    .line 2211
    .line 2212
    iput-byte v4, v5, La4;->j:B

    .line 2213
    .line 2214
    invoke-static {v1, v0, v5}, Lej;->G(Lw42;Lja2;Lvr6;)Ljava/lang/Object;

    .line 2215
    .line 2216
    .line 2217
    move-result-object v0

    .line 2218
    if-eq v0, v7, :cond_6a

    .line 2219
    .line 2220
    :cond_69
    :goto_39
    sget-object v10, Lxc7;->a:Lxc7;

    .line 2221
    .line 2222
    goto :goto_3a

    .line 2223
    :catchall_b
    move-exception v0

    .line 2224
    invoke-virtual {v2}, Li67;->b()Z

    .line 2225
    .line 2226
    .line 2227
    move-result v3

    .line 2228
    if-eqz v3, :cond_6b

    .line 2229
    .line 2230
    new-instance v3, Lw10;

    .line 2231
    .line 2232
    invoke-direct {v3, v2, v10, v6}, Lw10;-><init>(Li67;Lea1;B)V

    .line 2233
    .line 2234
    .line 2235
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 2236
    .line 2237
    const/4 v4, 0x3

    .line 2238
    iput-byte v4, v5, La4;->j:B

    .line 2239
    .line 2240
    invoke-static {v1, v3, v5}, Lej;->G(Lw42;Lja2;Lvr6;)Ljava/lang/Object;

    .line 2241
    .line 2242
    .line 2243
    move-result-object v1

    .line 2244
    if-ne v1, v7, :cond_6b

    .line 2245
    .line 2246
    :cond_6a
    move-object v10, v7

    .line 2247
    :goto_3a
    return-object v10

    .line 2248
    :cond_6b
    :goto_3b
    throw v0

    .line 2249
    :pswitch_10
    iget-object v0, v5, La4;->m:Ljava/lang/Object;

    .line 2250
    .line 2251
    check-cast v0, Lcx;

    .line 2252
    .line 2253
    iget-object v1, v5, La4;->l:Ljava/lang/Object;

    .line 2254
    .line 2255
    check-cast v1, Lix;

    .line 2256
    .line 2257
    sget-object v7, Lof1;->i:Lof1;

    .line 2258
    .line 2259
    iget-byte v8, v5, La4;->j:B

    .line 2260
    .line 2261
    if-eqz v8, :cond_6e

    .line 2262
    .line 2263
    if-eq v8, v6, :cond_6d

    .line 2264
    .line 2265
    if-ne v8, v4, :cond_6c

    .line 2266
    .line 2267
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 2268
    .line 2269
    check-cast v0, Lix;

    .line 2270
    .line 2271
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2272
    .line 2273
    .line 2274
    move-object v2, v0

    .line 2275
    move-object/from16 v0, p1

    .line 2276
    .line 2277
    goto :goto_3d

    .line 2278
    :cond_6c
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 2279
    .line 2280
    .line 2281
    goto/16 :goto_40

    .line 2282
    .line 2283
    :cond_6d
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2284
    .line 2285
    .line 2286
    move-object/from16 v0, p1

    .line 2287
    .line 2288
    goto :goto_3c

    .line 2289
    :cond_6e
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2290
    .line 2291
    .line 2292
    iget-object v3, v1, Lix;->v:Lkx;

    .line 2293
    .line 2294
    if-eqz v3, :cond_6f

    .line 2295
    .line 2296
    iget-object v2, v0, Lcx;->b:Law2;

    .line 2297
    .line 2298
    invoke-virtual {v1, v2, v6}, Lix;->m(Law2;Z)Law2;

    .line 2299
    .line 2300
    .line 2301
    move-result-object v2

    .line 2302
    iget-object v0, v0, Lcx;->a:Luv2;

    .line 2303
    .line 2304
    iput-byte v6, v5, La4;->j:B

    .line 2305
    .line 2306
    invoke-virtual {v3, v0, v2, v5}, Lkx;->a(Luv2;Law2;Lfa1;)Ljava/lang/Object;

    .line 2307
    .line 2308
    .line 2309
    move-result-object v0

    .line 2310
    if-eq v0, v7, :cond_70

    .line 2311
    .line 2312
    :goto_3c
    check-cast v0, Lhx;

    .line 2313
    .line 2314
    goto :goto_3f

    .line 2315
    :cond_6f
    iget-object v3, v0, Lcx;->b:Law2;

    .line 2316
    .line 2317
    invoke-virtual {v1, v3, v2}, Lix;->m(Law2;Z)Law2;

    .line 2318
    .line 2319
    .line 2320
    move-result-object v2

    .line 2321
    iget-object v0, v0, Lcx;->a:Luv2;

    .line 2322
    .line 2323
    iput-object v1, v5, La4;->k:Ljava/lang/Object;

    .line 2324
    .line 2325
    iput-byte v4, v5, La4;->j:B

    .line 2326
    .line 2327
    check-cast v0, Loi5;

    .line 2328
    .line 2329
    invoke-virtual {v0, v2, v5}, Loi5;->b(Law2;Lfa1;)Ljava/lang/Object;

    .line 2330
    .line 2331
    .line 2332
    move-result-object v0

    .line 2333
    if-ne v0, v7, :cond_71

    .line 2334
    .line 2335
    :cond_70
    move-object v10, v7

    .line 2336
    goto :goto_40

    .line 2337
    :cond_71
    move-object v2, v1

    .line 2338
    :goto_3d
    check-cast v0, Lew2;

    .line 2339
    .line 2340
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2341
    .line 2342
    .line 2343
    instance-of v2, v0, Ldr6;

    .line 2344
    .line 2345
    if-eqz v2, :cond_72

    .line 2346
    .line 2347
    new-instance v2, Lgx;

    .line 2348
    .line 2349
    check-cast v0, Ldr6;

    .line 2350
    .line 2351
    iget-object v3, v0, Ldr6;->a:Lpv2;

    .line 2352
    .line 2353
    iget-object v4, v0, Ldr6;->b:Law2;

    .line 2354
    .line 2355
    iget-object v4, v4, Law2;->a:Landroid/content/Context;

    .line 2356
    .line 2357
    invoke-static {v3, v4}, Lej;->F(Lpv2;Landroid/content/Context;)Lkw4;

    .line 2358
    .line 2359
    .line 2360
    move-result-object v3

    .line 2361
    invoke-direct {v2, v3, v0}, Lgx;-><init>(Lkw4;Ldr6;)V

    .line 2362
    .line 2363
    .line 2364
    :goto_3e
    move-object v0, v2

    .line 2365
    goto :goto_3f

    .line 2366
    :cond_72
    instance-of v2, v0, Lwz1;

    .line 2367
    .line 2368
    if-eqz v2, :cond_74

    .line 2369
    .line 2370
    new-instance v2, Lex;

    .line 2371
    .line 2372
    check-cast v0, Lwz1;

    .line 2373
    .line 2374
    iget-object v3, v0, Lwz1;->a:Lpv2;

    .line 2375
    .line 2376
    if-eqz v3, :cond_73

    .line 2377
    .line 2378
    iget-object v4, v0, Lwz1;->b:Law2;

    .line 2379
    .line 2380
    iget-object v4, v4, Law2;->a:Landroid/content/Context;

    .line 2381
    .line 2382
    invoke-static {v3, v4}, Lej;->F(Lpv2;Landroid/content/Context;)Lkw4;

    .line 2383
    .line 2384
    .line 2385
    move-result-object v10

    .line 2386
    :cond_73
    invoke-direct {v2, v10, v0}, Lex;-><init>(Lkw4;Lwz1;)V

    .line 2387
    .line 2388
    .line 2389
    goto :goto_3e

    .line 2390
    :goto_3f
    invoke-virtual {v1, v0}, Lix;->n(Lhx;)V

    .line 2391
    .line 2392
    .line 2393
    sget-object v10, Lxc7;->a:Lxc7;

    .line 2394
    .line 2395
    goto :goto_40

    .line 2396
    :cond_74
    invoke-static {}, Lw91;->a()V

    .line 2397
    .line 2398
    .line 2399
    :goto_40
    return-object v10

    .line 2400
    :pswitch_11
    iget-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 2401
    .line 2402
    check-cast v0, Lnf1;

    .line 2403
    .line 2404
    sget-object v1, Lof1;->i:Lof1;

    .line 2405
    .line 2406
    iget-byte v2, v5, La4;->j:B

    .line 2407
    .line 2408
    if-eqz v2, :cond_77

    .line 2409
    .line 2410
    if-eq v2, v6, :cond_76

    .line 2411
    .line 2412
    if-ne v2, v4, :cond_75

    .line 2413
    .line 2414
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2415
    .line 2416
    .line 2417
    goto :goto_42

    .line 2418
    :cond_75
    invoke-static {v3}, La02;->d(Ljava/lang/String;)V

    .line 2419
    .line 2420
    .line 2421
    goto :goto_43

    .line 2422
    :cond_76
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2423
    .line 2424
    .line 2425
    goto :goto_41

    .line 2426
    :cond_77
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 2427
    .line 2428
    .line 2429
    iget-object v2, v5, La4;->l:Ljava/lang/Object;

    .line 2430
    .line 2431
    check-cast v2, Lal6;

    .line 2432
    .line 2433
    iput-object v0, v5, La4;->k:Ljava/lang/Object;

    .line 2434
    .line 2435
    iput-byte v6, v5, La4;->j:B

    .line 2436
    .line 2437
    invoke-virtual {v2, v5}, Lz33;->G(Lea1;)Ljava/lang/Object;

    .line 2438
    .line 2439
    .line 2440
    move-result-object v2

    .line 2441
    if-eq v2, v1, :cond_78

    .line 2442
    .line 2443
    :goto_41
    iget-object v2, v5, La4;->m:Ljava/lang/Object;

    .line 2444
    .line 2445
    check-cast v2, Lja2;

    .line 2446
    .line 2447
    iput-object v10, v5, La4;->k:Ljava/lang/Object;

    .line 2448
    .line 2449
    iput-byte v4, v5, La4;->j:B

    .line 2450
    .line 2451
    invoke-interface {v2, v0, v5}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2452
    .line 2453
    .line 2454
    move-result-object v0

    .line 2455
    if-ne v0, v1, :cond_79

    .line 2456
    .line 2457
    :cond_78
    move-object v10, v1

    .line 2458
    goto :goto_43

    .line 2459
    :cond_79
    :goto_42
    sget-object v10, Lxc7;->a:Lxc7;

    .line 2460
    .line 2461
    :goto_43
    return-object v10

    .line 2462
    nop

    .line 2463
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
