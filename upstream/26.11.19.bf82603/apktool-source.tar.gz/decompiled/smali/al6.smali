.class public Lal6;
.super La3;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# virtual methods
.method public final Q(Ljava/lang/Throwable;)Z
    .locals 0

    .line 1
    iget-object p0, p0, La3;->k:Ldf1;

    .line 2
    .line 3
    invoke-static {p0, p1}, Lgn;->L(Ldf1;Ljava/lang/Throwable;)V

    .line 4
    .line 5
    .line 6
    const/4 p0, 0x1

    .line 7
    return p0
.end method
