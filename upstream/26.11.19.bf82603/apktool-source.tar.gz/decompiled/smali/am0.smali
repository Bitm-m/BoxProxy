.class public interface abstract Lam0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lzl0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Lzl0;->a:Lzl0;

    .line 2
    .line 3
    sput-object v0, Lam0;->a:Lzl0;

    .line 4
    .line 5
    return-void
.end method


# virtual methods
.method public abstract a(DDLc34;)D
.end method

.method public b(DLc34;)D
    .locals 0

    .line 1
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-wide p1
.end method

.method public c(DLc34;)D
    .locals 0

    .line 1
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-wide p1
.end method

.method public abstract d(DDLc34;)D
.end method
