.class public final synthetic Lac1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/util/ArrayList;

.field public final synthetic k:Z

.field public final synthetic l:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(Ljava/util/ArrayList;ZLjava/util/ArrayList;B)V
    .locals 0

    .line 1
    iput-byte p4, p0, Lac1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lac1;->j:Ljava/util/ArrayList;

    .line 4
    .line 5
    iput-boolean p2, p0, Lac1;->k:Z

    .line 6
    .line 7
    iput-object p3, p0, Lac1;->l:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lac1;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    iget-object v5, v0, Lac1;->l:Ljava/util/ArrayList;

    .line 11
    .line 12
    iget-boolean v6, v0, Lac1;->k:Z

    .line 13
    .line 14
    iget-object v0, v0, Lac1;->j:Ljava/util/ArrayList;

    .line 15
    .line 16
    const/4 v7, 0x1

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lvx0;

    .line 23
    .line 24
    move-object/from16 v14, p2

    .line 25
    .line 26
    check-cast v14, Lib2;

    .line 27
    .line 28
    move-object/from16 v8, p3

    .line 29
    .line 30
    check-cast v8, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v8

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v8, 0x11

    .line 40
    .line 41
    if-eq v1, v3, :cond_0

    .line 42
    .line 43
    move v1, v7

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v1, v4

    .line 46
    :goto_0
    and-int/2addr v8, v7

    .line 47
    invoke-virtual {v14, v8, v1}, Lib2;->X(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_2

    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_3

    .line 62
    .line 63
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    add-int/lit8 v3, v4, 0x1

    .line 68
    .line 69
    if-ltz v4, :cond_1

    .line 70
    .line 71
    check-cast v1, Ljava/lang/Number;

    .line 72
    .line 73
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    invoke-static {v1, v14}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v8

    .line 81
    xor-int/lit8 v13, v6, 0x1

    .line 82
    .line 83
    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    move-object v12, v1

    .line 88
    check-cast v12, Lu92;

    .line 89
    .line 90
    const/4 v15, 0x0

    .line 91
    const/16 v16, 0x5fe

    .line 92
    .line 93
    const/4 v9, 0x0

    .line 94
    const/4 v10, 0x0

    .line 95
    const/4 v11, 0x0

    .line 96
    invoke-static/range {v8 .. v16}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 97
    .line 98
    .line 99
    move v4, v3

    .line 100
    goto :goto_1

    .line 101
    :cond_1
    invoke-static {}, Lgn;->e0()V

    .line 102
    .line 103
    .line 104
    const/4 v0, 0x0

    .line 105
    throw v0

    .line 106
    :cond_2
    invoke-virtual {v14}, Lib2;->a0()V

    .line 107
    .line 108
    .line 109
    :cond_3
    return-object v2

    .line 110
    :pswitch_0
    move-object/from16 v1, p1

    .line 111
    .line 112
    check-cast v1, Lvx0;

    .line 113
    .line 114
    move-object/from16 v8, p2

    .line 115
    .line 116
    check-cast v8, Lib2;

    .line 117
    .line 118
    move-object/from16 v9, p3

    .line 119
    .line 120
    check-cast v9, Ljava/lang/Integer;

    .line 121
    .line 122
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 123
    .line 124
    .line 125
    move-result v9

    .line 126
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 127
    .line 128
    .line 129
    and-int/lit8 v1, v9, 0x11

    .line 130
    .line 131
    if-eq v1, v3, :cond_4

    .line 132
    .line 133
    move v4, v7

    .line 134
    :cond_4
    and-int/2addr v9, v7

    .line 135
    invoke-virtual {v8, v9, v4}, Lib2;->X(IZ)Z

    .line 136
    .line 137
    .line 138
    move-result v1

    .line 139
    if-eqz v1, :cond_5

    .line 140
    .line 141
    sget-object v1, Lt04;->i:Lt04;

    .line 142
    .line 143
    const/high16 v3, 0x3f800000    # 1.0f

    .line 144
    .line 145
    invoke-static {v1, v3}, Lag6;->e(Lw04;F)Lw04;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    invoke-static {v8}, Lkb3;->x(Lib2;)Ltj0;

    .line 150
    .line 151
    .line 152
    move-result-object v11

    .line 153
    new-instance v3, Lac1;

    .line 154
    .line 155
    invoke-direct {v3, v0, v6, v5, v7}, Lac1;-><init>(Ljava/util/ArrayList;ZLjava/util/ArrayList;B)V

    .line 156
    .line 157
    .line 158
    const v0, 0x56e12386

    .line 159
    .line 160
    .line 161
    invoke-static {v0, v3, v8}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 162
    .line 163
    .line 164
    move-result-object v17

    .line 165
    const/16 v19, 0x6

    .line 166
    .line 167
    const/16 v20, 0x3f6

    .line 168
    .line 169
    const/4 v9, 0x0

    .line 170
    const/4 v10, 0x0

    .line 171
    const/4 v12, 0x0

    .line 172
    const/4 v13, 0x0

    .line 173
    const/4 v14, 0x0

    .line 174
    const/4 v15, 0x0

    .line 175
    const/16 v16, 0x0

    .line 176
    .line 177
    move-object/from16 v18, v8

    .line 178
    .line 179
    move-object v8, v1

    .line 180
    invoke-static/range {v8 .. v20}, Ltw3;->a(Lw04;FLzt4;Ltj0;Lb45;ZLu92;Lu92;ZLyz0;Lib2;II)V

    .line 181
    .line 182
    .line 183
    goto :goto_2

    .line 184
    :cond_5
    move-object/from16 v18, v8

    .line 185
    .line 186
    invoke-virtual/range {v18 .. v18}, Lib2;->a0()V

    .line 187
    .line 188
    .line 189
    :goto_2
    return-object v2

    .line 190
    nop

    .line 191
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
