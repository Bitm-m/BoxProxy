.class public final Laj5;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:S

.field public final b:Luh0;

.field public final c:J


# direct methods
.method public constructor <init>(IJLuh0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-short p1, p0, Laj5;->a:S

    .line 5
    .line 6
    iput-object p4, p0, Laj5;->b:Luh0;

    .line 7
    .line 8
    iput-wide p2, p0, Laj5;->c:J

    .line 9
    .line 10
    return-void
.end method
