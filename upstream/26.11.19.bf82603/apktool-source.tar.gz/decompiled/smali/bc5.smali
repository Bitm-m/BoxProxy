.class public final synthetic Lbc5;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lne5;

.field public final synthetic k:Lce5;


# direct methods
.method public synthetic constructor <init>(Lne5;Lce5;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lbc5;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lbc5;->j:Lne5;

    .line 4
    .line 5
    iput-object p2, p0, Lbc5;->k:Lce5;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget-byte v0, p0, Lbc5;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    iget-object v2, p0, Lbc5;->k:Lce5;

    .line 6
    .line 7
    iget-object p0, p0, Lbc5;->j:Lne5;

    .line 8
    .line 9
    check-cast p1, Lde5;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, v2, Lce5;->a:Ljava/lang/String;

    .line 18
    .line 19
    iget-object p1, p1, Lde5;->a:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {p0, v0, p1}, Lne5;->q(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object v1

    .line 25
    :pswitch_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    iget-object v0, v2, Lce5;->a:Ljava/lang/String;

    .line 29
    .line 30
    iget-object p1, p1, Lde5;->a:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {p0, v0, p1}, Lne5;->q(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
