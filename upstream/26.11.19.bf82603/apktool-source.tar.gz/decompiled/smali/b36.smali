.class final Lb36;
.super Lf14;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lf14;"
    }
.end annotation


# virtual methods
.method public final a()Lv04;
    .locals 1

    .line 1
    new-instance p0, Ld36;

    .line 2
    .line 3
    invoke-direct {p0}, Lbl1;-><init>()V

    .line 4
    .line 5
    .line 6
    const/16 v0, 0x9

    .line 7
    .line 8
    iput-byte v0, p0, Ld36;->y:B

    .line 9
    .line 10
    sget-object v0, Lc36;->i:Lc36;

    .line 11
    .line 12
    iput-object v0, p0, Ld36;->z:Lc36;

    .line 13
    .line 14
    return-object p0
.end method

.method public final b(Lv04;)V
    .locals 0

    .line 1
    check-cast p1, Ld36;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const/16 p0, 0x9

    .line 7
    .line 8
    iput-byte p0, p1, Ld36;->y:B

    .line 9
    .line 10
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of p0, p1, Lb36;

    .line 6
    .line 7
    if-nez p0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    return v0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    const/16 p0, 0x9

    .line 2
    .line 3
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    .line 1
    const/16 p0, 0x9

    .line 2
    .line 3
    invoke-static {p0}, Lbj2;->a(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const-string v0, "ScrollEndHapticElement(hapticFeedbackType="

    .line 8
    .line 9
    const-string v1, ")"

    .line 10
    .line 11
    invoke-static {v0, p0, v1}, Lmz1;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method
