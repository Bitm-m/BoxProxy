.class public abstract La27;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lnt1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lg96;

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lg96;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lnt1;

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-direct {v1, v0, v2}, Lnt1;-><init>(Lu92;B)V

    .line 12
    .line 13
    .line 14
    sput-object v1, La27;->a:Lnt1;

    .line 15
    .line 16
    return-void
.end method

.method public static final a(Lz17;Lz17;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p1}, Lz17;->e()Lx17;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Lz17;->a:Lgx4;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p1, Lz17;->b:Lgx4;

    .line 20
    .line 21
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Lx17;

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lz17;->b:Lgx4;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p1}, Lz17;->b()Lx17;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, Lz17;->c:Lgx4;

    .line 43
    .line 44
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1}, Lz17;->c()Lx17;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    iget-object v1, p0, Lz17;->d:Lgx4;

    .line 55
    .line 56
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    iget-object v0, p1, Lz17;->e:Lgx4;

    .line 60
    .line 61
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    check-cast v0, Lx17;

    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-object v1, p0, Lz17;->e:Lgx4;

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p1}, Lz17;->d()Lx17;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    iget-object v1, p0, Lz17;->f:Lgx4;

    .line 83
    .line 84
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    iget-object v0, p1, Lz17;->g:Lgx4;

    .line 88
    .line 89
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    check-cast v0, Lx17;

    .line 94
    .line 95
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    .line 97
    .line 98
    iget-object v1, p0, Lz17;->g:Lgx4;

    .line 99
    .line 100
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    iget-object v0, p1, Lz17;->h:Lgx4;

    .line 104
    .line 105
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Lx17;

    .line 110
    .line 111
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    .line 113
    .line 114
    iget-object v1, p0, Lz17;->h:Lgx4;

    .line 115
    .line 116
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    iget-object v0, p1, Lz17;->i:Lgx4;

    .line 120
    .line 121
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    check-cast v0, Lx17;

    .line 126
    .line 127
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    iget-object v1, p0, Lz17;->i:Lgx4;

    .line 131
    .line 132
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    iget-object v0, p1, Lz17;->j:Lgx4;

    .line 136
    .line 137
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    check-cast v0, Lx17;

    .line 142
    .line 143
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    iget-object v1, p0, Lz17;->j:Lgx4;

    .line 147
    .line 148
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    iget-object v0, p1, Lz17;->k:Lgx4;

    .line 152
    .line 153
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    check-cast v0, Lx17;

    .line 158
    .line 159
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 160
    .line 161
    .line 162
    iget-object v1, p0, Lz17;->k:Lgx4;

    .line 163
    .line 164
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    iget-object v0, p1, Lz17;->l:Lgx4;

    .line 168
    .line 169
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    check-cast v0, Lx17;

    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    iget-object v1, p0, Lz17;->l:Lgx4;

    .line 179
    .line 180
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    iget-object v0, p1, Lz17;->m:Lgx4;

    .line 184
    .line 185
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    check-cast v0, Lx17;

    .line 190
    .line 191
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 192
    .line 193
    .line 194
    iget-object v1, p0, Lz17;->m:Lgx4;

    .line 195
    .line 196
    invoke-virtual {v1, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {p1}, Lz17;->f()Lx17;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 204
    .line 205
    .line 206
    iget-object p0, p0, Lz17;->n:Lgx4;

    .line 207
    .line 208
    invoke-virtual {p0, p1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    return-void
.end method
