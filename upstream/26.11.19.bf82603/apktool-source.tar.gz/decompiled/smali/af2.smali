.class public final synthetic Laf2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:J

.field public final synthetic j:Lu92;

.field public final synthetic k:Lu92;

.field public final synthetic l:Lu92;

.field public final synthetic m:Ljava/lang/String;

.field public final synthetic n:S


# direct methods
.method public synthetic constructor <init>(JLu92;Lu92;Lu92;Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Laf2;->i:J

    .line 5
    .line 6
    iput-object p3, p0, Laf2;->j:Lu92;

    .line 7
    .line 8
    iput-object p4, p0, Laf2;->k:Lu92;

    .line 9
    .line 10
    iput-object p5, p0, Laf2;->l:Lu92;

    .line 11
    .line 12
    iput-object p6, p0, Laf2;->m:Ljava/lang/String;

    .line 13
    .line 14
    iput-short p7, p0, Laf2;->n:S

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    move-object v6, p1

    .line 2
    check-cast v6, Lib2;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-short p1, p0, Laf2;->n:S

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lcc3;->X(I)I

    .line 14
    .line 15
    .line 16
    move-result v7

    .line 17
    iget-wide v0, p0, Laf2;->i:J

    .line 18
    .line 19
    iget-object v2, p0, Laf2;->j:Lu92;

    .line 20
    .line 21
    iget-object v3, p0, Laf2;->k:Lu92;

    .line 22
    .line 23
    iget-object v4, p0, Laf2;->l:Lu92;

    .line 24
    .line 25
    iget-object v5, p0, Laf2;->m:Ljava/lang/String;

    .line 26
    .line 27
    invoke-static/range {v0 .. v7}, Lhf2;->f(JLu92;Lu92;Lu92;Ljava/lang/String;Lib2;I)V

    .line 28
    .line 29
    .line 30
    sget-object p0, Lxc7;->a:Lxc7;

    .line 31
    .line 32
    return-object p0
.end method
