.class public final synthetic Lb80;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Ljo3;Z)V
    .locals 1

    .line 14
    const/4 v0, 0x0

    iput-byte v0, p0, Lb80;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb80;->k:Ljava/lang/Object;

    iput-object p2, p0, Lb80;->l:Ljava/lang/Object;

    iput-boolean p3, p0, Lb80;->j:Z

    return-void
.end method

.method public synthetic constructor <init>(Lpz6;Ljava/lang/String;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x6

    .line 2
    iput-byte v0, p0, Lb80;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lb80;->k:Ljava/lang/Object;

    .line 8
    .line 9
    iput-boolean p3, p0, Lb80;->j:Z

    .line 10
    .line 11
    iput-object p1, p0, Lb80;->l:Ljava/lang/Object;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(ZLjava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 15
    iput-byte p4, p0, Lb80;->i:B

    iput-boolean p1, p0, Lb80;->j:Z

    iput-object p2, p0, Lb80;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb80;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-byte v0, p0, Lb80;->i:B

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lb80;->k:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Ljava/lang/String;

    .line 12
    .line 13
    iget-boolean v1, p0, Lb80;->j:Z

    .line 14
    .line 15
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p0, Lpz6;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    sget-object p0, Lb83;->i:Lb83;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    if-eqz v1, :cond_1

    .line 29
    .line 30
    invoke-virtual {p0}, Lpz6;->c()Lvw6;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v0, v0, Lvw6;->k:Ljava/lang/CharSequence;

    .line 35
    .line 36
    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-lez v0, :cond_1

    .line 41
    .line 42
    sget-object p0, Lb83;->j:Lb83;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    invoke-virtual {p0}, Lpz6;->c()Lvw6;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    iget-object p0, p0, Lvw6;->k:Ljava/lang/CharSequence;

    .line 50
    .line 51
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 52
    .line 53
    .line 54
    move-result p0

    .line 55
    if-lez p0, :cond_2

    .line 56
    .line 57
    sget-object p0, Lb83;->l:Lb83;

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_2
    sget-object p0, Lb83;->k:Lb83;

    .line 61
    .line 62
    :goto_0
    return-object p0

    .line 63
    :pswitch_0
    iget-boolean v0, p0, Lb80;->j:Z

    .line 64
    .line 65
    iget-object v1, p0, Lb80;->k:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v1, Ljava/lang/String;

    .line 68
    .line 69
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast p0, Lj44;

    .line 72
    .line 73
    if-nez v0, :cond_4

    .line 74
    .line 75
    invoke-interface {p0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {v0, v1}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-nez v0, :cond_3

    .line 86
    .line 87
    move-object v3, v1

    .line 88
    :cond_3
    invoke-interface {p0, v3}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_4
    sget-object p0, Lxc7;->a:Lxc7;

    .line 92
    .line 93
    return-object p0

    .line 94
    :pswitch_1
    iget-boolean v0, p0, Lb80;->j:Z

    .line 95
    .line 96
    iget-object v3, p0, Lb80;->k:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v3, Ldi;

    .line 99
    .line 100
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast p0, Le87;

    .line 103
    .line 104
    if-eqz v0, :cond_5

    .line 105
    .line 106
    iget-object v0, v3, Ldi;->j:Lgx4;

    .line 107
    .line 108
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    check-cast v0, Ljava/lang/Number;

    .line 113
    .line 114
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 115
    .line 116
    .line 117
    :cond_5
    iget-object p0, p0, Le87;->p:Lgx4;

    .line 118
    .line 119
    invoke-virtual {p0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    check-cast p0, Ljava/lang/Number;

    .line 124
    .line 125
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 126
    .line 127
    .line 128
    move-result p0

    .line 129
    iget-object v0, v3, Ldi;->j:Lgx4;

    .line 130
    .line 131
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Ljava/lang/Number;

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    invoke-static {p0, v0}, Lgn;->U(FF)F

    .line 142
    .line 143
    .line 144
    move-result p0

    .line 145
    const v0, 0x3f7fbe77    # 0.999f

    .line 146
    .line 147
    .line 148
    cmpg-float p0, p0, v0

    .line 149
    .line 150
    if-ltz p0, :cond_6

    .line 151
    .line 152
    move v1, v2

    .line 153
    :cond_6
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 154
    .line 155
    .line 156
    move-result-object p0

    .line 157
    return-object p0

    .line 158
    :pswitch_2
    iget-boolean v0, p0, Lb80;->j:Z

    .line 159
    .line 160
    iget-object v1, p0, Lb80;->k:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v1, Lbr2;

    .line 163
    .line 164
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast p0, Ljava/lang/String;

    .line 167
    .line 168
    if-eqz v0, :cond_7

    .line 169
    .line 170
    iget-object v0, v1, Lbr2;->j:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v0, Lp06;

    .line 173
    .line 174
    iget-object v1, v0, Lp06;->c:Lpd5;

    .line 175
    .line 176
    monitor-enter v1

    .line 177
    :try_start_0
    iget-object v0, v0, Lp06;->d:Ljava/util/LinkedHashMap;

    .line 178
    .line 179
    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object p0

    .line 183
    check-cast p0, Lo06;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 184
    .line 185
    monitor-exit v1

    .line 186
    goto :goto_1

    .line 187
    :catchall_0
    move-exception p0

    .line 188
    monitor-exit v1

    .line 189
    throw p0

    .line 190
    :cond_7
    :goto_1
    sget-object p0, Lxc7;->a:Lxc7;

    .line 191
    .line 192
    return-object p0

    .line 193
    :pswitch_3
    iget-boolean v0, p0, Lb80;->j:Z

    .line 194
    .line 195
    iget-object v1, p0, Lb80;->k:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v1, Lmg;

    .line 198
    .line 199
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 200
    .line 201
    check-cast p0, Lmg;

    .line 202
    .line 203
    const/high16 v2, 0x3f800000    # 1.0f

    .line 204
    .line 205
    if-eqz v0, :cond_8

    .line 206
    .line 207
    invoke-virtual {v1}, Lmg;->e()Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    check-cast v0, Ljava/lang/Number;

    .line 212
    .line 213
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    const v1, 0x3e4ccccd    # 0.2f

    .line 218
    .line 219
    .line 220
    mul-float/2addr v0, v1

    .line 221
    const v3, 0x3f4ccccd    # 0.8f

    .line 222
    .line 223
    .line 224
    add-float/2addr v0, v3

    .line 225
    invoke-virtual {p0}, Lmg;->e()Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object p0

    .line 229
    check-cast p0, Ljava/lang/Number;

    .line 230
    .line 231
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 232
    .line 233
    .line 234
    move-result p0

    .line 235
    mul-float/2addr p0, v1

    .line 236
    sub-float/2addr v2, p0

    .line 237
    mul-float/2addr v2, v0

    .line 238
    :cond_8
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 239
    .line 240
    .line 241
    move-result-object p0

    .line 242
    return-object p0

    .line 243
    :pswitch_4
    iget-boolean v0, p0, Lb80;->j:Z

    .line 244
    .line 245
    iget-object v1, p0, Lb80;->k:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v1, Lfa2;

    .line 248
    .line 249
    iget-object p0, p0, Lb80;->l:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast p0, Li41;

    .line 252
    .line 253
    if-eqz v0, :cond_9

    .line 254
    .line 255
    invoke-interface {v1, p0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    :cond_9
    sget-object p0, Lxc7;->a:Lxc7;

    .line 259
    .line 260
    return-object p0

    .line 261
    :pswitch_5
    iget-object v0, p0, Lb80;->k:Ljava/lang/Object;

    .line 262
    .line 263
    check-cast v0, Ljava/util/List;

    .line 264
    .line 265
    iget-object v4, p0, Lb80;->l:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast v4, Ljo3;

    .line 268
    .line 269
    iget-boolean p0, p0, Lb80;->j:Z

    .line 270
    .line 271
    iget-object v4, v4, Ljo3;->c:Ldx4;

    .line 272
    .line 273
    invoke-virtual {v4}, Ldx4;->g()I

    .line 274
    .line 275
    .line 276
    move-result v4

    .line 277
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 278
    .line 279
    .line 280
    invoke-static {v4, v0}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    check-cast v0, Li40;

    .line 285
    .line 286
    if-nez v0, :cond_a

    .line 287
    .line 288
    sget-object v0, Li40;->m:Li40;

    .line 289
    .line 290
    :cond_a
    if-eqz p0, :cond_b

    .line 291
    .line 292
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 293
    .line 294
    .line 295
    move-result p0

    .line 296
    if-eqz p0, :cond_b

    .line 297
    .line 298
    if-eq p0, v1, :cond_c

    .line 299
    .line 300
    const/4 v0, 0x2

    .line 301
    if-eq p0, v0, :cond_c

    .line 302
    .line 303
    const/4 v0, 0x3

    .line 304
    if-eq p0, v0, :cond_c

    .line 305
    .line 306
    invoke-static {}, Lw91;->a()V

    .line 307
    .line 308
    .line 309
    goto :goto_2

    .line 310
    :cond_b
    move v1, v2

    .line 311
    :cond_c
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 312
    .line 313
    .line 314
    move-result-object v3

    .line 315
    :goto_2
    return-object v3

    .line 316
    nop

    .line 317
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
