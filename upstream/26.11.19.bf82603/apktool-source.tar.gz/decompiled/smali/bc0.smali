.class public final Lbc0;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public i:Lac0;

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lcom/box/app/notification/BoxPersistentNotificationService;

.field public l:I


# direct methods
.method public constructor <init>(Lcom/box/app/notification/BoxPersistentNotificationService;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lbc0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lbc0;->j:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lbc0;->l:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lbc0;->l:I

    .line 9
    .line 10
    sget p1, Lcom/box/app/notification/BoxPersistentNotificationService;->r:I

    .line 11
    .line 12
    iget-object p1, p0, Lbc0;->k:Lcom/box/app/notification/BoxPersistentNotificationService;

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-virtual {p1, v0, v0, p0}, Lcom/box/app/notification/BoxPersistentNotificationService;->a(ZZLfa1;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method
