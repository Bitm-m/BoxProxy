.class public final Lae2;
.super Lqm5;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic A:Ldx4;

.field public final synthetic B:Lmg;

.field public final synthetic C:Lmg;

.field public final synthetic D:Lnf1;

.field public final synthetic E:Lj44;

.field public final synthetic F:Ldx4;

.field public j:Ll15;

.field public k:F

.field public l:F

.field public m:F

.field public n:F

.field public o:F

.field public p:F

.field public q:F

.field public r:I

.field public s:B

.field public synthetic t:Lea1;

.field public final synthetic u:F

.field public final synthetic v:F

.field public final synthetic w:Ljava/util/ArrayList;

.field public final synthetic x:F

.field public final synthetic y:Lj44;

.field public final synthetic z:Lh93;


# direct methods
.method public constructor <init>(FFLjava/util/ArrayList;FLj44;Lh93;Ldx4;Lmg;Lmg;Lnf1;Lj44;Ldx4;Lea1;)V
    .locals 0

    .line 1
    iput p1, p0, Lae2;->u:F

    .line 2
    .line 3
    iput p2, p0, Lae2;->v:F

    .line 4
    .line 5
    iput-object p3, p0, Lae2;->w:Ljava/util/ArrayList;

    .line 6
    .line 7
    iput p4, p0, Lae2;->x:F

    .line 8
    .line 9
    iput-object p5, p0, Lae2;->y:Lj44;

    .line 10
    .line 11
    iput-object p6, p0, Lae2;->z:Lh93;

    .line 12
    .line 13
    iput-object p7, p0, Lae2;->A:Ldx4;

    .line 14
    .line 15
    iput-object p8, p0, Lae2;->B:Lmg;

    .line 16
    .line 17
    iput-object p9, p0, Lae2;->C:Lmg;

    .line 18
    .line 19
    iput-object p10, p0, Lae2;->D:Lnf1;

    .line 20
    .line 21
    iput-object p11, p0, Lae2;->E:Lj44;

    .line 22
    .line 23
    iput-object p12, p0, Lae2;->F:Ldx4;

    .line 24
    .line 25
    const/4 p1, 0x2

    .line 26
    invoke-direct {p0, p1, p13}, Lqm5;-><init>(ILea1;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static final m(FFLjava/util/ArrayList;F)I
    .locals 0

    .line 1
    sub-float/2addr p3, p0

    .line 2
    div-float/2addr p3, p1

    .line 3
    float-to-int p0, p3

    .line 4
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    add-int/lit8 p1, p1, -0x1

    .line 9
    .line 10
    const/4 p2, 0x0

    .line 11
    invoke-static {p0, p2, p1}, Lkb3;->B(III)I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    return p0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 14

    .line 1
    new-instance v0, Lae2;

    .line 2
    .line 3
    iget-object v11, p0, Lae2;->E:Lj44;

    .line 4
    .line 5
    iget-object v12, p0, Lae2;->F:Ldx4;

    .line 6
    .line 7
    iget v1, p0, Lae2;->u:F

    .line 8
    .line 9
    iget v2, p0, Lae2;->v:F

    .line 10
    .line 11
    iget-object v3, p0, Lae2;->w:Ljava/util/ArrayList;

    .line 12
    .line 13
    iget v4, p0, Lae2;->x:F

    .line 14
    .line 15
    iget-object v5, p0, Lae2;->y:Lj44;

    .line 16
    .line 17
    iget-object v6, p0, Lae2;->z:Lh93;

    .line 18
    .line 19
    iget-object v7, p0, Lae2;->A:Ldx4;

    .line 20
    .line 21
    iget-object v8, p0, Lae2;->B:Lmg;

    .line 22
    .line 23
    iget-object v9, p0, Lae2;->C:Lmg;

    .line 24
    .line 25
    iget-object v10, p0, Lae2;->D:Lnf1;

    .line 26
    .line 27
    move-object/from16 v13, p2

    .line 28
    .line 29
    invoke-direct/range {v0 .. v13}, Lae2;-><init>(FFLjava/util/ArrayList;FLj44;Lh93;Ldx4;Lmg;Lmg;Lnf1;Lj44;Ldx4;Lea1;)V

    .line 30
    .line 31
    .line 32
    check-cast p1, Lea1;

    .line 33
    .line 34
    iput-object p1, v0, Lae2;->t:Lea1;

    .line 35
    .line 36
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lbs6;

    .line 2
    .line 3
    check-cast p2, Lea1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lae2;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lae2;

    .line 10
    .line 11
    sget-object p1, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lae2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 41

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lae2;->t:Lea1;

    .line 4
    .line 5
    check-cast v1, Lbs6;

    .line 6
    .line 7
    iget-byte v2, v0, Lae2;->s:B

    .line 8
    .line 9
    sget-object v3, Lh93;->j:Lh93;

    .line 10
    .line 11
    sget-object v6, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    const/4 v7, 0x2

    .line 14
    iget-object v9, v0, Lae2;->y:Lj44;

    .line 15
    .line 16
    iget v10, v0, Lae2;->x:F

    .line 17
    .line 18
    iget v11, v0, Lae2;->v:F

    .line 19
    .line 20
    iget-object v12, v0, Lae2;->F:Ldx4;

    .line 21
    .line 22
    iget-object v13, v0, Lae2;->z:Lh93;

    .line 23
    .line 24
    iget-object v14, v0, Lae2;->A:Ldx4;

    .line 25
    .line 26
    iget-object v15, v0, Lae2;->w:Ljava/util/ArrayList;

    .line 27
    .line 28
    const/high16 v16, 0x40000000    # 2.0f

    .line 29
    .line 30
    const/4 v5, 0x1

    .line 31
    const/16 v17, 0x0

    .line 32
    .line 33
    iget v8, v0, Lae2;->u:F

    .line 34
    .line 35
    const/16 v18, 0x20

    .line 36
    .line 37
    sget-object v4, Lof1;->i:Lof1;

    .line 38
    .line 39
    if-eqz v2, :cond_2

    .line 40
    .line 41
    if-eq v2, v5, :cond_1

    .line 42
    .line 43
    if-ne v2, v7, :cond_0

    .line 44
    .line 45
    iget v2, v0, Lae2;->q:F

    .line 46
    .line 47
    iget v7, v0, Lae2;->p:F

    .line 48
    .line 49
    iget v5, v0, Lae2;->r:I

    .line 50
    .line 51
    move/from16 v20, v2

    .line 52
    .line 53
    iget v2, v0, Lae2;->o:F

    .line 54
    .line 55
    move/from16 v21, v2

    .line 56
    .line 57
    iget v2, v0, Lae2;->n:F

    .line 58
    .line 59
    move/from16 v22, v2

    .line 60
    .line 61
    iget v2, v0, Lae2;->m:F

    .line 62
    .line 63
    move/from16 v23, v2

    .line 64
    .line 65
    iget v2, v0, Lae2;->l:F

    .line 66
    .line 67
    move/from16 v24, v2

    .line 68
    .line 69
    iget v2, v0, Lae2;->k:F

    .line 70
    .line 71
    move/from16 v25, v2

    .line 72
    .line 73
    iget-object v2, v0, Lae2;->j:Ll15;

    .line 74
    .line 75
    :try_start_0
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 76
    .line 77
    .line 78
    move/from16 v26, v20

    .line 79
    .line 80
    move-object/from16 v20, v6

    .line 81
    .line 82
    move/from16 v6, v25

    .line 83
    .line 84
    move-object/from16 v25, v14

    .line 85
    .line 86
    move/from16 v14, v26

    .line 87
    .line 88
    move/from16 v26, v7

    .line 89
    .line 90
    move/from16 v7, v24

    .line 91
    .line 92
    move-object/from16 v24, v9

    .line 93
    .line 94
    move/from16 v9, v23

    .line 95
    .line 96
    move-object/from16 v23, v12

    .line 97
    .line 98
    move/from16 v12, v22

    .line 99
    .line 100
    move/from16 v22, v11

    .line 101
    .line 102
    move/from16 v11, v21

    .line 103
    .line 104
    move/from16 v21, v10

    .line 105
    .line 106
    move v10, v5

    .line 107
    move-object v5, v2

    .line 108
    move-object/from16 v2, p1

    .line 109
    .line 110
    goto/16 :goto_4

    .line 111
    .line 112
    :catchall_0
    move-exception v0

    .line 113
    move-object v1, v9

    .line 114
    move-object v2, v12

    .line 115
    move-object v9, v14

    .line 116
    :goto_0
    const/4 v3, -0x1

    .line 117
    goto/16 :goto_e

    .line 118
    .line 119
    :cond_0
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 120
    .line 121
    invoke-static {v0}, La02;->d(Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    return-object v17

    .line 125
    :cond_1
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    move-object/from16 v5, p1

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    iput-object v1, v0, Lae2;->t:Lea1;

    .line 135
    .line 136
    const/4 v2, 0x1

    .line 137
    iput-byte v2, v0, Lae2;->s:B

    .line 138
    .line 139
    const/4 v2, 0x2

    .line 140
    invoke-static {v1, v0, v2}, Lvu6;->b(Lbs6;Lea1;I)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    if-eq v5, v4, :cond_5

    .line 145
    .line 146
    :goto_1
    check-cast v5, Ll15;

    .line 147
    .line 148
    iget-object v2, v1, Lbs6;->m:Lcs6;

    .line 149
    .line 150
    move-object/from16 v20, v6

    .line 151
    .line 152
    iget-wide v6, v2, Lcs6;->G:J

    .line 153
    .line 154
    shr-long v6, v6, v18

    .line 155
    .line 156
    long-to-int v2, v6

    .line 157
    int-to-float v2, v2

    .line 158
    add-float v6, v8, v11

    .line 159
    .line 160
    cmpg-float v6, v2, v6

    .line 161
    .line 162
    if-gtz v6, :cond_3

    .line 163
    .line 164
    return-object v20

    .line 165
    :cond_3
    sub-float v6, v2, v8

    .line 166
    .line 167
    sub-float/2addr v6, v11

    .line 168
    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    .line 169
    .line 170
    .line 171
    move-result v7

    .line 172
    int-to-float v7, v7

    .line 173
    div-float/2addr v6, v7

    .line 174
    sub-float v7, v8, v10

    .line 175
    .line 176
    move/from16 v21, v10

    .line 177
    .line 178
    move/from16 v22, v11

    .line 179
    .line 180
    iget-wide v10, v5, Ll15;->c:J

    .line 181
    .line 182
    shr-long v10, v10, v18

    .line 183
    .line 184
    long-to-int v10, v10

    .line 185
    invoke-static {v10}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 186
    .line 187
    .line 188
    move-result v10

    .line 189
    if-ne v13, v3, :cond_4

    .line 190
    .line 191
    iget-object v11, v1, Lbs6;->m:Lcs6;

    .line 192
    .line 193
    move-object/from16 v23, v1

    .line 194
    .line 195
    move/from16 v24, v2

    .line 196
    .line 197
    iget-wide v1, v11, Lcs6;->G:J

    .line 198
    .line 199
    shr-long v1, v1, v18

    .line 200
    .line 201
    long-to-int v1, v1

    .line 202
    int-to-float v1, v1

    .line 203
    sub-float v10, v1, v10

    .line 204
    .line 205
    goto :goto_2

    .line 206
    :cond_4
    move-object/from16 v23, v1

    .line 207
    .line 208
    move/from16 v24, v2

    .line 209
    .line 210
    :goto_2
    invoke-static {v8, v6, v15, v10}, Lae2;->m(FFLjava/util/ArrayList;F)I

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    invoke-virtual {v14, v1}, Ldx4;->h(I)V

    .line 215
    .line 216
    .line 217
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 218
    .line 219
    invoke-interface {v9, v2}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 220
    .line 221
    .line 222
    int-to-float v2, v1

    .line 223
    mul-float/2addr v2, v6

    .line 224
    add-float/2addr v2, v7

    .line 225
    add-float v11, v2, v6

    .line 226
    .line 227
    mul-float v25, v21, v16

    .line 228
    .line 229
    add-float v11, v25, v11

    .line 230
    .line 231
    move/from16 p1, v1

    .line 232
    .line 233
    iget-object v1, v0, Lae2;->B:Lmg;

    .line 234
    .line 235
    move-object/from16 v25, v5

    .line 236
    .line 237
    iget-object v5, v0, Lae2;->C:Lmg;

    .line 238
    .line 239
    move/from16 v26, v6

    .line 240
    .line 241
    iget-object v6, v0, Lae2;->D:Lnf1;

    .line 242
    .line 243
    invoke-static {v1, v5, v6, v2, v11}, Lfj;->r(Lmg;Lmg;Lnf1;FF)V

    .line 244
    .line 245
    .line 246
    const/high16 v1, 0x7fc00000    # Float.NaN

    .line 247
    .line 248
    move-object v5, v12

    .line 249
    move v12, v1

    .line 250
    move-object/from16 v1, v23

    .line 251
    .line 252
    move-object/from16 v23, v5

    .line 253
    .line 254
    move-object v5, v14

    .line 255
    move v14, v2

    .line 256
    move-object/from16 v2, v25

    .line 257
    .line 258
    move-object/from16 v25, v5

    .line 259
    .line 260
    move v11, v10

    .line 261
    move/from16 v5, v24

    .line 262
    .line 263
    move/from16 v6, v26

    .line 264
    .line 265
    move-object/from16 v24, v9

    .line 266
    .line 267
    move/from16 v9, p1

    .line 268
    .line 269
    :goto_3
    :try_start_1
    iput-object v1, v0, Lae2;->t:Lea1;

    .line 270
    .line 271
    iput-object v2, v0, Lae2;->j:Ll15;

    .line 272
    .line 273
    iput v5, v0, Lae2;->k:F

    .line 274
    .line 275
    iput v6, v0, Lae2;->l:F

    .line 276
    .line 277
    iput v7, v0, Lae2;->m:F

    .line 278
    .line 279
    iput v10, v0, Lae2;->n:F

    .line 280
    .line 281
    iput v11, v0, Lae2;->o:F

    .line 282
    .line 283
    iput v9, v0, Lae2;->r:I

    .line 284
    .line 285
    iput v14, v0, Lae2;->p:F

    .line 286
    .line 287
    iput v12, v0, Lae2;->q:F

    .line 288
    .line 289
    move-object/from16 v26, v2

    .line 290
    .line 291
    const/4 v2, 0x2

    .line 292
    iput-byte v2, v0, Lae2;->s:B

    .line 293
    .line 294
    sget-object v2, Le15;->j:Le15;

    .line 295
    .line 296
    invoke-virtual {v1, v2, v0}, Lbs6;->c(Le15;Lea1;)Ljava/lang/Object;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    if-ne v2, v4, :cond_6

    .line 301
    .line 302
    :cond_5
    return-object v4

    .line 303
    :cond_6
    move/from16 v40, v6

    .line 304
    .line 305
    move v6, v5

    .line 306
    move-object/from16 v5, v26

    .line 307
    .line 308
    move/from16 v26, v14

    .line 309
    .line 310
    move v14, v12

    .line 311
    move v12, v10

    .line 312
    move v10, v9

    .line 313
    move v9, v7

    .line 314
    move/from16 v7, v40

    .line 315
    .line 316
    :goto_4
    check-cast v2, Ld15;

    .line 317
    .line 318
    iget-object v2, v2, Ld15;->a:Ljava/util/List;

    .line 319
    .line 320
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 321
    .line 322
    .line 323
    move-result-object v2

    .line 324
    :goto_5
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 325
    .line 326
    .line 327
    move-result v27

    .line 328
    if-eqz v27, :cond_7

    .line 329
    .line 330
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v27

    .line 334
    move-object/from16 p1, v2

    .line 335
    .line 336
    move-object/from16 v2, v27

    .line 337
    .line 338
    check-cast v2, Ll15;

    .line 339
    .line 340
    move/from16 v28, v11

    .line 341
    .line 342
    move/from16 v29, v12

    .line 343
    .line 344
    iget-wide v11, v2, Ll15;->a:J

    .line 345
    .line 346
    move v2, v9

    .line 347
    move/from16 v30, v10

    .line 348
    .line 349
    iget-wide v9, v5, Ll15;->a:J

    .line 350
    .line 351
    invoke-static {v11, v12, v9, v10}, Lk15;->b(JJ)Z

    .line 352
    .line 353
    .line 354
    move-result v9

    .line 355
    if-nez v9, :cond_8

    .line 356
    .line 357
    move v9, v2

    .line 358
    move/from16 v11, v28

    .line 359
    .line 360
    move/from16 v12, v29

    .line 361
    .line 362
    move/from16 v10, v30

    .line 363
    .line 364
    move-object/from16 v2, p1

    .line 365
    .line 366
    goto :goto_5

    .line 367
    :cond_7
    move v2, v9

    .line 368
    move/from16 v30, v10

    .line 369
    .line 370
    move/from16 v28, v11

    .line 371
    .line 372
    move/from16 v29, v12

    .line 373
    .line 374
    move-object/from16 v27, v17

    .line 375
    .line 376
    :cond_8
    move-object/from16 v9, v27

    .line 377
    .line 378
    check-cast v9, Ll15;

    .line 379
    .line 380
    if-eqz v9, :cond_13

    .line 381
    .line 382
    iget-wide v10, v9, Ll15;->g:J

    .line 383
    .line 384
    move-object v12, v4

    .line 385
    move-object/from16 v27, v5

    .line 386
    .line 387
    iget-wide v4, v9, Ll15;->c:J

    .line 388
    .line 389
    invoke-virtual {v9}, Ll15;->c()Z

    .line 390
    .line 391
    .line 392
    move-result v31
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 393
    if-nez v31, :cond_13

    .line 394
    .line 395
    move/from16 p1, v2

    .line 396
    .line 397
    :try_start_2
    iget-boolean v2, v9, Ll15;->d:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 398
    .line 399
    if-nez v2, :cond_a

    .line 400
    .line 401
    :try_start_3
    invoke-static {v9}, Lcc3;->y(Ll15;)Z

    .line 402
    .line 403
    .line 404
    move-result v1

    .line 405
    if-eqz v1, :cond_13

    .line 406
    .line 407
    shr-long v4, v4, v18

    .line 408
    .line 409
    long-to-int v1, v4

    .line 410
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 411
    .line 412
    .line 413
    move-result v1

    .line 414
    shr-long v10, v10, v18

    .line 415
    .line 416
    long-to-int v2, v10

    .line 417
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    sub-float/2addr v1, v2

    .line 422
    if-ne v13, v3, :cond_9

    .line 423
    .line 424
    neg-float v1, v1

    .line 425
    :cond_9
    add-float v11, v28, v1

    .line 426
    .line 427
    iget-object v0, v0, Lae2;->E:Lj44;

    .line 428
    .line 429
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    check-cast v0, Lfa2;

    .line 434
    .line 435
    invoke-static {v8, v7, v15, v11}, Lae2;->m(FFLjava/util/ArrayList;F)I

    .line 436
    .line 437
    .line 438
    move-result v1

    .line 439
    new-instance v2, Ljava/lang/Integer;

    .line 440
    .line 441
    invoke-direct {v2, v1}, Ljava/lang/Integer;-><init>(I)V

    .line 442
    .line 443
    .line 444
    invoke-interface {v0, v2}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    invoke-virtual {v9}, Ll15;->a()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 448
    .line 449
    .line 450
    goto/16 :goto_d

    .line 451
    .line 452
    :cond_a
    :try_start_4
    iget-object v2, v1, Lbs6;->m:Lcs6;

    .line 453
    .line 454
    move-wide/from16 v31, v4

    .line 455
    .line 456
    iget-wide v4, v2, Lcs6;->G:J

    .line 457
    .line 458
    shr-long v4, v4, v18

    .line 459
    .line 460
    long-to-int v2, v4

    .line 461
    int-to-float v2, v2

    .line 462
    sub-float v4, v2, v8

    .line 463
    .line 464
    sub-float v4, v4, v22

    .line 465
    .line 466
    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    .line 467
    .line 468
    .line 469
    move-result v5

    .line 470
    int-to-float v5, v5

    .line 471
    div-float/2addr v4, v5

    .line 472
    const/4 v5, 0x0

    .line 473
    cmpg-float v33, v4, v5

    .line 474
    .line 475
    if-gez v33, :cond_b

    .line 476
    .line 477
    move v4, v5

    .line 478
    :cond_b
    mul-float v5, v21, v16

    .line 479
    .line 480
    add-float v34, v5, v4

    .line 481
    .line 482
    sub-float v4, v8, v22

    .line 483
    .line 484
    sub-float v5, v2, v34

    .line 485
    .line 486
    cmpg-float v33, v5, v4

    .line 487
    .line 488
    if-gez v33, :cond_c

    .line 489
    .line 490
    move v5, v4

    .line 491
    :cond_c
    move-wide/from16 v35, v10

    .line 492
    .line 493
    move-object v11, v9

    .line 494
    shr-long v9, v31, v18

    .line 495
    .line 496
    long-to-int v9, v9

    .line 497
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 498
    .line 499
    .line 500
    move-result v10
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 501
    if-ne v13, v3, :cond_d

    .line 502
    .line 503
    move/from16 v31, v2

    .line 504
    .line 505
    :try_start_5
    iget-object v2, v1, Lbs6;->m:Lcs6;

    .line 506
    .line 507
    move-object/from16 v32, v1

    .line 508
    .line 509
    iget-wide v1, v2, Lcs6;->G:J
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 510
    .line 511
    shr-long v1, v1, v18

    .line 512
    .line 513
    long-to-int v1, v1

    .line 514
    int-to-float v1, v1

    .line 515
    sub-float v10, v1, v10

    .line 516
    .line 517
    goto :goto_7

    .line 518
    :goto_6
    move-object/from16 v2, v23

    .line 519
    .line 520
    move-object/from16 v1, v24

    .line 521
    .line 522
    move-object/from16 v9, v25

    .line 523
    .line 524
    goto/16 :goto_0

    .line 525
    .line 526
    :cond_d
    move-object/from16 v32, v1

    .line 527
    .line 528
    move/from16 v31, v2

    .line 529
    .line 530
    :goto_7
    :try_start_6
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 531
    .line 532
    .line 533
    move-result v1

    .line 534
    move v9, v1

    .line 535
    shr-long v1, v35, v18

    .line 536
    .line 537
    long-to-int v1, v1

    .line 538
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 539
    .line 540
    .line 541
    move-result v1

    .line 542
    sub-float v1, v9, v1

    .line 543
    .line 544
    if-ne v13, v3, :cond_e

    .line 545
    .line 546
    neg-float v1, v1

    .line 547
    :cond_e
    move/from16 v37, v1

    .line 548
    .line 549
    add-float v1, v28, v37

    .line 550
    .line 551
    invoke-static {v14}, Ljava/lang/Float;->isNaN(F)Z

    .line 552
    .line 553
    .line 554
    move-result v2

    .line 555
    if-eqz v2, :cond_10

    .line 556
    .line 557
    sub-float v2, v1, v29

    .line 558
    .line 559
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 560
    .line 561
    .line 562
    move-result v2

    .line 563
    invoke-virtual/range {v32 .. v32}, Lbs6;->e()Ljg7;

    .line 564
    .line 565
    .line 566
    move-result-object v9

    .line 567
    invoke-interface {v9}, Ljg7;->d()F

    .line 568
    .line 569
    .line 570
    move-result v9

    .line 571
    cmpg-float v2, v2, v9

    .line 572
    .line 573
    if-gez v2, :cond_f

    .line 574
    .line 575
    invoke-static {v8, v7, v15, v1}, Lae2;->m(FFLjava/util/ArrayList;F)I

    .line 576
    .line 577
    .line 578
    move-result v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 579
    move-object/from16 v9, v25

    .line 580
    .line 581
    :try_start_7
    invoke-virtual {v9, v2}, Ldx4;->h(I)V

    .line 582
    .line 583
    .line 584
    move v11, v1

    .line 585
    move v5, v6

    .line 586
    move v6, v7

    .line 587
    move-object/from16 v25, v9

    .line 588
    .line 589
    move-object v4, v12

    .line 590
    move v12, v14

    .line 591
    move/from16 v14, v26

    .line 592
    .line 593
    move-object/from16 v2, v27

    .line 594
    .line 595
    move/from16 v10, v29

    .line 596
    .line 597
    move/from16 v9, v30

    .line 598
    .line 599
    move-object/from16 v1, v32

    .line 600
    .line 601
    move/from16 v7, p1

    .line 602
    .line 603
    goto/16 :goto_3

    .line 604
    .line 605
    :cond_f
    move-object/from16 v9, v25

    .line 606
    .line 607
    sub-float v2, v29, v26

    .line 608
    .line 609
    move v14, v2

    .line 610
    goto :goto_8

    .line 611
    :cond_10
    move-object/from16 v9, v25

    .line 612
    .line 613
    :goto_8
    sub-float/2addr v10, v14

    .line 614
    invoke-static {v10, v4, v5}, Lkb3;->A(FFF)F

    .line 615
    .line 616
    .line 617
    move-result v33

    .line 618
    invoke-static {v8, v7, v15, v1}, Lae2;->m(FFLjava/util/ArrayList;F)I

    .line 619
    .line 620
    .line 621
    move-result v2

    .line 622
    move/from16 v5, v30

    .line 623
    .line 624
    if-eq v2, v5, :cond_11

    .line 625
    .line 626
    const/16 v38, 0x1

    .line 627
    .line 628
    :goto_9
    move/from16 v35, v4

    .line 629
    .line 630
    move/from16 v36, v31

    .line 631
    .line 632
    goto :goto_a

    .line 633
    :cond_11
    const/4 v5, 0x0

    .line 634
    move/from16 v38, v5

    .line 635
    .line 636
    goto :goto_9

    .line 637
    :goto_a
    invoke-static/range {v33 .. v38}, Lcc3;->N(FFFFFZ)Lc84;

    .line 638
    .line 639
    .line 640
    move-result-object v4

    .line 641
    iget-object v5, v0, Lae2;->B:Lmg;

    .line 642
    .line 643
    iget-object v10, v0, Lae2;->C:Lmg;

    .line 644
    .line 645
    move/from16 v25, v1

    .line 646
    .line 647
    iget-object v1, v0, Lae2;->D:Lnf1;

    .line 648
    .line 649
    iget v0, v4, Lc84;->a:F

    .line 650
    .line 651
    move/from16 v36, v0

    .line 652
    .line 653
    iget v0, v4, Lc84;->b:F

    .line 654
    .line 655
    invoke-virtual {v4}, Lc84;->a()Lik6;

    .line 656
    .line 657
    .line 658
    move-result-object v38

    .line 659
    move/from16 v37, v0

    .line 660
    .line 661
    iget-boolean v0, v4, Lc84;->c:Z

    .line 662
    .line 663
    if-eqz v0, :cond_12

    .line 664
    .line 665
    const/high16 v0, 0x3f800000    # 1.0f

    .line 666
    .line 667
    const v4, 0x3e19999a    # 0.15f

    .line 668
    .line 669
    .line 670
    invoke-static {v0, v4}, Lej;->i0(FF)Lik6;

    .line 671
    .line 672
    .line 673
    move-result-object v0

    .line 674
    goto :goto_b

    .line 675
    :cond_12
    iget-boolean v0, v4, Lc84;->d:Z

    .line 676
    .line 677
    invoke-static {v0}, Lej;->L(Z)Lik6;

    .line 678
    .line 679
    .line 680
    move-result-object v0

    .line 681
    :goto_b
    move-object/from16 v39, v0

    .line 682
    .line 683
    move-object/from16 v35, v1

    .line 684
    .line 685
    move-object/from16 v33, v5

    .line 686
    .line 687
    move-object/from16 v34, v10

    .line 688
    .line 689
    invoke-static/range {v33 .. v39}, Lfj;->q(Lmg;Lmg;Lnf1;FFLik6;Lik6;)V

    .line 690
    .line 691
    .line 692
    invoke-virtual {v9, v2}, Ldx4;->h(I)V

    .line 693
    .line 694
    .line 695
    invoke-virtual {v11}, Ll15;->a()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 696
    .line 697
    .line 698
    move-object/from16 v0, p0

    .line 699
    .line 700
    move v5, v6

    .line 701
    move v6, v7

    .line 702
    move-object v4, v12

    .line 703
    move v12, v14

    .line 704
    move/from16 v11, v25

    .line 705
    .line 706
    move/from16 v14, v26

    .line 707
    .line 708
    move/from16 v10, v29

    .line 709
    .line 710
    move-object/from16 v1, v32

    .line 711
    .line 712
    move/from16 v7, p1

    .line 713
    .line 714
    move-object/from16 v25, v9

    .line 715
    .line 716
    move v9, v2

    .line 717
    move-object/from16 v2, v27

    .line 718
    .line 719
    goto/16 :goto_3

    .line 720
    .line 721
    :catchall_1
    move-exception v0

    .line 722
    :goto_c
    move-object/from16 v2, v23

    .line 723
    .line 724
    move-object/from16 v1, v24

    .line 725
    .line 726
    goto/16 :goto_0

    .line 727
    .line 728
    :catchall_2
    move-exception v0

    .line 729
    move-object/from16 v9, v25

    .line 730
    .line 731
    goto :goto_c

    .line 732
    :cond_13
    :goto_d
    move-object/from16 v9, v25

    .line 733
    .line 734
    const/4 v1, -0x1

    .line 735
    invoke-virtual {v9, v1}, Ldx4;->h(I)V

    .line 736
    .line 737
    .line 738
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 739
    .line 740
    move-object/from16 v1, v24

    .line 741
    .line 742
    invoke-interface {v1, v0}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 743
    .line 744
    .line 745
    invoke-virtual/range {v23 .. v23}, Ldx4;->g()I

    .line 746
    .line 747
    .line 748
    move-result v0

    .line 749
    const/16 v19, 0x1

    .line 750
    .line 751
    add-int/lit8 v0, v0, 0x1

    .line 752
    .line 753
    move-object/from16 v2, v23

    .line 754
    .line 755
    invoke-virtual {v2, v0}, Ldx4;->h(I)V

    .line 756
    .line 757
    .line 758
    return-object v20

    .line 759
    :catchall_3
    move-exception v0

    .line 760
    goto/16 :goto_6

    .line 761
    .line 762
    :goto_e
    invoke-virtual {v9, v3}, Ldx4;->h(I)V

    .line 763
    .line 764
    .line 765
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 766
    .line 767
    invoke-interface {v1, v3}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 768
    .line 769
    .line 770
    invoke-virtual {v2}, Ldx4;->g()I

    .line 771
    .line 772
    .line 773
    move-result v1

    .line 774
    const/16 v19, 0x1

    .line 775
    .line 776
    add-int/lit8 v1, v1, 0x1

    .line 777
    .line 778
    invoke-virtual {v2, v1}, Ldx4;->h(I)V

    .line 779
    .line 780
    .line 781
    throw v0
.end method
