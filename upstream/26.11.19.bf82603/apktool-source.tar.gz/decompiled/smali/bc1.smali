.class public final synthetic Lbc1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lj44;

.field public final synthetic k:Lj44;


# direct methods
.method public synthetic constructor <init>(Lj44;Lj44;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lbc1;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lbc1;->j:Lj44;

    .line 4
    .line 5
    iput-object p2, p0, Lbc1;->k:Lj44;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lbc1;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    sget-object v4, Lg21;->a:Ley0;

    .line 9
    .line 10
    iget-object v5, v0, Lbc1;->k:Lj44;

    .line 11
    .line 12
    iget-object v0, v0, Lbc1;->j:Lj44;

    .line 13
    .line 14
    const/16 v6, 0x10

    .line 15
    .line 16
    const/4 v7, 0x0

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    move-object/from16 v1, p1

    .line 21
    .line 22
    check-cast v1, Lvh;

    .line 23
    .line 24
    move-object/from16 v8, p2

    .line 25
    .line 26
    check-cast v8, Lib2;

    .line 27
    .line 28
    move-object/from16 v9, p3

    .line 29
    .line 30
    check-cast v9, Ljava/lang/Integer;

    .line 31
    .line 32
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    and-int/lit8 v1, v9, 0x11

    .line 40
    .line 41
    if-eq v1, v6, :cond_0

    .line 42
    .line 43
    move v1, v3

    .line 44
    goto :goto_0

    .line 45
    :cond_0
    move v1, v7

    .line 46
    :goto_0
    and-int/2addr v9, v3

    .line 47
    invoke-virtual {v8, v9, v1}, Lib2;->X(IZ)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_6

    .line 52
    .line 53
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    check-cast v1, Ljava/lang/String;

    .line 58
    .line 59
    invoke-virtual {v8, v0}, Lib2;->g(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    invoke-virtual {v8}, Lib2;->S()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v9

    .line 67
    if-nez v3, :cond_1

    .line 68
    .line 69
    if-ne v9, v4, :cond_2

    .line 70
    .line 71
    :cond_1
    new-instance v9, Lg75;

    .line 72
    .line 73
    invoke-direct {v9, v0, v6}, Lg75;-><init>(Lj44;B)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v8, v9}, Lib2;->p0(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    :cond_2
    check-cast v9, Lfa2;

    .line 80
    .line 81
    invoke-virtual {v8}, Lib2;->S()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    if-ne v3, v4, :cond_3

    .line 86
    .line 87
    new-instance v3, Lcd5;

    .line 88
    .line 89
    invoke-direct {v3, v7}, Lcd5;-><init>(B)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v8, v3}, Lib2;->p0(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :cond_3
    move-object v10, v3

    .line 96
    check-cast v10, Lfa2;

    .line 97
    .line 98
    invoke-interface {v5}, Lnl6;->getValue()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v3

    .line 102
    check-cast v3, Ljava/lang/Boolean;

    .line 103
    .line 104
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 105
    .line 106
    .line 107
    move-result v11

    .line 108
    invoke-virtual {v8, v5}, Lib2;->g(Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v3

    .line 112
    invoke-virtual {v8, v0}, Lib2;->g(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v6

    .line 116
    or-int/2addr v3, v6

    .line 117
    invoke-virtual {v8}, Lib2;->S()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    if-nez v3, :cond_4

    .line 122
    .line 123
    if-ne v6, v4, :cond_5

    .line 124
    .line 125
    :cond_4
    new-instance v6, Lbu0;

    .line 126
    .line 127
    const/16 v3, 0x8

    .line 128
    .line 129
    invoke-direct {v6, v5, v0, v3}, Lbu0;-><init>(Lj44;Lj44;B)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v8, v6}, Lib2;->p0(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    :cond_5
    move-object v12, v6

    .line 136
    check-cast v12, Lfa2;

    .line 137
    .line 138
    sget-object v0, Lt04;->i:Lt04;

    .line 139
    .line 140
    const/high16 v3, 0x3f800000    # 1.0f

    .line 141
    .line 142
    invoke-static {v0, v3}, Lag6;->e(Lw04;F)Lw04;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    const/high16 v3, 0x41400000    # 12.0f

    .line 147
    .line 148
    const/high16 v4, 0x41000000    # 8.0f

    .line 149
    .line 150
    invoke-static {v0, v3, v4}, Lm71;->B(Lw04;FF)Lw04;

    .line 151
    .line 152
    .line 153
    move-result-object v13

    .line 154
    const v0, 0x7f0f03db

    .line 155
    .line 156
    .line 157
    invoke-static {v0, v8}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v14

    .line 161
    sget-object v0, Lbx0;->a:Lnt1;

    .line 162
    .line 163
    invoke-virtual {v8, v0}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    check-cast v0, Lax0;

    .line 168
    .line 169
    invoke-virtual {v0}, Lax0;->v()J

    .line 170
    .line 171
    .line 172
    move-result-wide v16

    .line 173
    const/16 v22, 0x0

    .line 174
    .line 175
    const/16 v23, 0x3d80

    .line 176
    .line 177
    const/4 v15, 0x0

    .line 178
    const/16 v18, 0x0

    .line 179
    .line 180
    const/16 v19, 0x0

    .line 181
    .line 182
    const v21, 0x30180

    .line 183
    .line 184
    .line 185
    move-object/from16 v20, v8

    .line 186
    .line 187
    move-object v8, v1

    .line 188
    invoke-static/range {v8 .. v23}, Lcc3;->h(Ljava/lang/String;Lfa2;Lfa2;ZLfa2;Lw04;Ljava/lang/String;ZJLj34;La02;Lib2;III)V

    .line 189
    .line 190
    .line 191
    goto :goto_1

    .line 192
    :cond_6
    move-object/from16 v20, v8

    .line 193
    .line 194
    invoke-virtual/range {v20 .. v20}, Lib2;->a0()V

    .line 195
    .line 196
    .line 197
    :goto_1
    return-object v2

    .line 198
    :pswitch_0
    move-object/from16 v1, p1

    .line 199
    .line 200
    check-cast v1, Lvx0;

    .line 201
    .line 202
    move-object/from16 v14, p2

    .line 203
    .line 204
    check-cast v14, Lib2;

    .line 205
    .line 206
    move-object/from16 v8, p3

    .line 207
    .line 208
    check-cast v8, Ljava/lang/Integer;

    .line 209
    .line 210
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 211
    .line 212
    .line 213
    move-result v8

    .line 214
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 215
    .line 216
    .line 217
    and-int/lit8 v1, v8, 0x11

    .line 218
    .line 219
    if-eq v1, v6, :cond_7

    .line 220
    .line 221
    move v7, v3

    .line 222
    :cond_7
    and-int/2addr v8, v3

    .line 223
    invoke-virtual {v14, v8, v7}, Lib2;->X(IZ)Z

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    if-eqz v1, :cond_a

    .line 228
    .line 229
    const v1, 0x7f0f015e

    .line 230
    .line 231
    .line 232
    invoke-static {v1, v14}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object v8

    .line 236
    invoke-interface {v5}, Lnl6;->getValue()Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v1

    .line 240
    check-cast v1, Lle1;

    .line 241
    .line 242
    iget-object v1, v1, Lle1;->l:Lwe1;

    .line 243
    .line 244
    iget-object v1, v1, Lwe1;->a:Ljava/lang/String;

    .line 245
    .line 246
    invoke-static {v1}, Lmm;->F(Ljava/lang/String;)I

    .line 247
    .line 248
    .line 249
    move-result v1

    .line 250
    invoke-static {v1, v14}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v9

    .line 254
    invoke-virtual {v14, v0}, Lib2;->g(Ljava/lang/Object;)Z

    .line 255
    .line 256
    .line 257
    move-result v1

    .line 258
    invoke-virtual {v14}, Lib2;->S()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v3

    .line 262
    if-nez v1, :cond_8

    .line 263
    .line 264
    if-ne v3, v4, :cond_9

    .line 265
    .line 266
    :cond_8
    new-instance v3, Lma1;

    .line 267
    .line 268
    const/4 v1, 0x5

    .line 269
    invoke-direct {v3, v0, v1}, Lma1;-><init>(Lj44;B)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {v14, v3}, Lib2;->p0(Ljava/lang/Object;)V

    .line 273
    .line 274
    .line 275
    :cond_9
    move-object v12, v3

    .line 276
    check-cast v12, Lu92;

    .line 277
    .line 278
    const/4 v15, 0x0

    .line 279
    const/16 v16, 0xdf6

    .line 280
    .line 281
    const/4 v10, 0x0

    .line 282
    const/4 v11, 0x0

    .line 283
    const/4 v13, 0x0

    .line 284
    invoke-static/range {v8 .. v16}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 285
    .line 286
    .line 287
    goto :goto_2

    .line 288
    :cond_a
    invoke-virtual {v14}, Lib2;->a0()V

    .line 289
    .line 290
    .line 291
    :goto_2
    return-object v2

    .line 292
    nop

    .line 293
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
