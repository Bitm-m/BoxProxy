.class public interface abstract Landroidx/window/reflection/Predicate2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Landroidx/window/extensions/core/util/function/Predicate;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Landroidx/window/extensions/core/util/function/Predicate<",
        "TT;>;"
    }
.end annotation


# virtual methods
.method public abstract test(Ljava/lang/Object;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation
.end method
