.class public final Lb91;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public i:Z

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lod7;

.field public final synthetic l:Ld91;

.field public final synthetic m:Loe0;

.field public final synthetic n:J

.field public final synthetic o:Ls33;


# direct methods
.method public constructor <init>(Lod7;Ld91;Loe0;JLs33;Lea1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lb91;->k:Lod7;

    .line 2
    .line 3
    iput-object p2, p0, Lb91;->l:Ld91;

    .line 4
    .line 5
    iput-object p3, p0, Lb91;->m:Loe0;

    .line 6
    .line 7
    iput-wide p4, p0, Lb91;->n:J

    .line 8
    .line 9
    iput-object p6, p0, Lb91;->o:Ls33;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p7}, Lvr6;-><init>(ILea1;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 8

    .line 1
    new-instance v0, Lb91;

    .line 2
    .line 3
    iget-wide v4, p0, Lb91;->n:J

    .line 4
    .line 5
    iget-object v6, p0, Lb91;->o:Ls33;

    .line 6
    .line 7
    iget-object v1, p0, Lb91;->k:Lod7;

    .line 8
    .line 9
    iget-object v2, p0, Lb91;->l:Ld91;

    .line 10
    .line 11
    iget-object v3, p0, Lb91;->m:Loe0;

    .line 12
    .line 13
    move-object v7, p2

    .line 14
    invoke-direct/range {v0 .. v7}, Lb91;-><init>(Lod7;Ld91;Loe0;JLs33;Lea1;)V

    .line 15
    .line 16
    .line 17
    iput-object p1, v0, Lb91;->j:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lf46;

    .line 2
    .line 3
    check-cast p2, Lea1;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lb91;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lb91;

    .line 10
    .line 11
    sget-object p1, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lb91;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-boolean v0, p0, Lb91;->i:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    invoke-static {p0}, La02;->d(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_1
    invoke-static {p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p0, Lb91;->j:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p1, Lf46;

    .line 25
    .line 26
    iget-wide v2, p0, Lb91;->n:J

    .line 27
    .line 28
    iget-object v0, p0, Lb91;->l:Ld91;

    .line 29
    .line 30
    iget-object v4, p0, Lb91;->m:Loe0;

    .line 31
    .line 32
    invoke-virtual {v0, v4, v2, v3}, Ld91;->F1(Loe0;J)F

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    iget-object v3, p0, Lb91;->k:Lod7;

    .line 37
    .line 38
    iput v2, v3, Lod7;->e:F

    .line 39
    .line 40
    new-instance v2, Lvf;

    .line 41
    .line 42
    iget-object v5, p0, Lb91;->o:Ls33;

    .line 43
    .line 44
    invoke-direct {v2, v0, v3, v5, p1}, Lvf;-><init>(Ld91;Lod7;Ls33;Lf46;)V

    .line 45
    .line 46
    .line 47
    new-instance p1, Lql;

    .line 48
    .line 49
    const/16 v5, 0xe

    .line 50
    .line 51
    invoke-direct {p1, v0, v3, v4, v5}, Lql;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 52
    .line 53
    .line 54
    iput-boolean v1, p0, Lb91;->i:Z

    .line 55
    .line 56
    invoke-virtual {v3, v2, p1, p0}, Lod7;->a(Lvf;Lql;Lfa1;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    sget-object p1, Lof1;->i:Lof1;

    .line 61
    .line 62
    if-ne p0, p1, :cond_2

    .line 63
    .line 64
    return-object p1

    .line 65
    :cond_2
    :goto_0
    sget-object p0, Lxc7;->a:Lxc7;

    .line 66
    .line 67
    return-object p0
.end method
