.class public final La40;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Le73;


# static fields
.field public static final a:La40;

.field public static final b:Lx45;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, La40;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La40;->a:La40;

    .line 7
    .line 8
    new-instance v0, Lx45;

    .line 9
    .line 10
    const-string v1, "kotlin.Boolean"

    .line 11
    .line 12
    sget-object v2, Lw45;->g:Lw45;

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, Lx45;-><init>(Ljava/lang/String;Lw45;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, La40;->b:Lx45;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final b(Lli1;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1}, Lli1;->e()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final c()Lp86;
    .locals 0

    .line 1
    sget-object p0, La40;->b:Lx45;

    .line 2
    .line 3
    return-object p0
.end method

.method public final d(Lsm6;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Ljava/lang/Boolean;

    .line 2
    .line 3
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    invoke-virtual {p1, p0}, Lsm6;->b(Z)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
