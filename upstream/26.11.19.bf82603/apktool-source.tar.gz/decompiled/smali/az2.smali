.class public final Laz2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Ldf;

.field public final b:Lid;

.field public final c:Ljava/lang/Object;

.field public final d:Ll44;

.field public e:Z


# direct methods
.method public constructor <init>(Ldf;Lid;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Laz2;->a:Ldf;

    .line 5
    .line 6
    iput-object p2, p0, Laz2;->b:Lid;

    .line 7
    .line 8
    new-instance p1, Ljava/lang/Object;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Laz2;->c:Ljava/lang/Object;

    .line 14
    .line 15
    new-instance p1, Ll44;

    .line 16
    .line 17
    const/16 p2, 0x10

    .line 18
    .line 19
    new-array p2, p2, [Lsh7;

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    invoke-direct {p1, v0, p2}, Ll44;-><init>(I[Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Laz2;->d:Ll44;

    .line 26
    .line 27
    return-void
.end method
