.class public final synthetic La66;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lb66;


# direct methods
.method public synthetic constructor <init>(Lb66;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, La66;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La66;->j:Lb66;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte v0, p0, La66;->i:B

    .line 2
    .line 3
    iget-object p0, p0, La66;->j:Lb66;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lb66;->d:Lw27;

    .line 9
    .line 10
    iget-object p0, p0, Lw27;->j:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Loi4;

    .line 13
    .line 14
    return-object p0

    .line 15
    :pswitch_0
    iget-object p0, p0, Lb66;->d:Lw27;

    .line 16
    .line 17
    iget-object p0, p0, Lw27;->l:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Lvc3;

    .line 20
    .line 21
    return-object p0

    .line 22
    :pswitch_1
    iget-object p0, p0, Lb66;->d:Lw27;

    .line 23
    .line 24
    iget-object p0, p0, Lw27;->k:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p0, Lk07;

    .line 27
    .line 28
    return-object p0

    .line 29
    :pswitch_2
    iget-object p0, p0, Lb66;->d:Lw27;

    .line 30
    .line 31
    iget-object p0, p0, Lw27;->j:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p0, Loi4;

    .line 34
    .line 35
    return-object p0

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
