.class public final synthetic Lba6;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lu92;

.field public final synthetic k:Lu92;


# direct methods
.method public synthetic constructor <init>(Lu92;Lu92;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lba6;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lba6;->j:Lu92;

    .line 4
    .line 5
    iput-object p2, p0, Lba6;->k:Lu92;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14

    .line 1
    iget-byte v0, p0, Lba6;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    const/16 v2, 0x10

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    check-cast p1, Lvx0;

    .line 10
    .line 11
    move-object/from16 v11, p2

    .line 12
    .line 13
    check-cast v11, Lib2;

    .line 14
    .line 15
    packed-switch v0, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    move-object/from16 v0, p3

    .line 19
    .line 20
    check-cast v0, Ljava/lang/Integer;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    and-int/lit8 p1, v0, 0x11

    .line 30
    .line 31
    if-eq p1, v2, :cond_0

    .line 32
    .line 33
    move v3, v4

    .line 34
    :cond_0
    and-int/2addr v0, v4

    .line 35
    invoke-virtual {v11, v0, v3}, Lib2;->X(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    if-eqz p1, :cond_1

    .line 40
    .line 41
    const p1, 0x7f0f0527

    .line 42
    .line 43
    .line 44
    invoke-static {p1, v11}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    sget-object v7, Lgi1;->P:Lyz0;

    .line 49
    .line 50
    const/high16 v12, 0x30000

    .line 51
    .line 52
    const/16 v13, 0xdde

    .line 53
    .line 54
    const/4 v6, 0x0

    .line 55
    const/4 v8, 0x0

    .line 56
    iget-object v9, p0, Lba6;->j:Lu92;

    .line 57
    .line 58
    const/4 v10, 0x0

    .line 59
    invoke-static/range {v5 .. v13}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 60
    .line 61
    .line 62
    const p1, 0x7f0f0529

    .line 63
    .line 64
    .line 65
    invoke-static {p1, v11}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    sget-object v7, Lgi1;->Q:Lyz0;

    .line 70
    .line 71
    iget-object v9, p0, Lba6;->k:Lu92;

    .line 72
    .line 73
    invoke-static/range {v5 .. v13}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_1
    invoke-virtual {v11}, Lib2;->a0()V

    .line 78
    .line 79
    .line 80
    :goto_0
    return-object v1

    .line 81
    :pswitch_0
    move-object/from16 v0, p3

    .line 82
    .line 83
    check-cast v0, Ljava/lang/Integer;

    .line 84
    .line 85
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    and-int/lit8 p1, v0, 0x11

    .line 93
    .line 94
    if-eq p1, v2, :cond_2

    .line 95
    .line 96
    move v3, v4

    .line 97
    :cond_2
    and-int/2addr v0, v4

    .line 98
    invoke-virtual {v11, v0, v3}, Lib2;->X(IZ)Z

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-eqz p1, :cond_3

    .line 103
    .line 104
    const p1, 0x7f0f036d

    .line 105
    .line 106
    .line 107
    invoke-static {p1, v11}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    sget-object v7, Lm71;->T:Lyz0;

    .line 112
    .line 113
    const/high16 v12, 0x30000

    .line 114
    .line 115
    const/16 v13, 0xdde

    .line 116
    .line 117
    const/4 v6, 0x0

    .line 118
    const/4 v8, 0x0

    .line 119
    iget-object v9, p0, Lba6;->j:Lu92;

    .line 120
    .line 121
    const/4 v10, 0x0

    .line 122
    invoke-static/range {v5 .. v13}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 123
    .line 124
    .line 125
    const p1, 0x7f0f0348

    .line 126
    .line 127
    .line 128
    invoke-static {p1, v11}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    sget-object v7, Lm71;->U:Lyz0;

    .line 133
    .line 134
    iget-object v9, p0, Lba6;->k:Lu92;

    .line 135
    .line 136
    invoke-static/range {v5 .. v13}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_3
    invoke-virtual {v11}, Lib2;->a0()V

    .line 141
    .line 142
    .line 143
    :goto_1
    return-object v1

    .line 144
    nop

    .line 145
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
