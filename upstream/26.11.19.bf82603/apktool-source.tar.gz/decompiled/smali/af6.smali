.class public final Laf6;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public i:Lorg/json/JSONObject;

.field public j:Ljava/lang/String;

.field public k:Lye6;

.field public l:Lw27;

.field public m:Lfa2;

.field public n:Ljava/lang/String;

.field public o:Ljava/util/ArrayList;

.field public p:Ljava/util/Iterator;

.field public q:Lcf6;

.field public r:Ljava/util/ArrayList;

.field public s:I

.field public t:I

.field public synthetic u:Ljava/lang/Object;

.field public final synthetic v:Lcf6;

.field public w:I


# direct methods
.method public constructor <init>(Lcf6;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laf6;->v:Lcf6;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 1
    iput-object p1, p0, Laf6;->u:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Laf6;->w:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Laf6;->w:I

    .line 9
    .line 10
    const/4 v6, 0x0

    .line 11
    const/4 v7, 0x0

    .line 12
    iget-object v0, p0, Laf6;->v:Lcf6;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x0

    .line 16
    const/4 v3, 0x0

    .line 17
    const/4 v4, 0x0

    .line 18
    const/4 v5, 0x0

    .line 19
    move-object v8, p0

    .line 20
    invoke-virtual/range {v0 .. v8}, Lcf6;->f(Lorg/json/JSONObject;Ljava/lang/String;ILye6;Lw27;Lfa2;ILfa1;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method
