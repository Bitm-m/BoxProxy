.class public final Lbc;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lor3;


# static fields
.field public static final b:Lbc;

.field public static final c:Lbc;

.field public static final d:Lbc;

.field public static final e:Lbc;

.field public static final f:Lbc;

.field public static final g:Lbc;

.field public static final h:Lbc;

.field public static final i:Lef1;

.field public static final j:Lbc;

.field public static final k:Lbc;

.field public static final l:Lbc;

.field public static final m:Lbc;

.field public static final n:Lbc;


# instance fields
.field public final synthetic a:B


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lbc;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lbc;->b:Lbc;

    .line 8
    .line 9
    new-instance v0, Lbc;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lbc;->c:Lbc;

    .line 16
    .line 17
    new-instance v0, Lbc;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Lbc;->d:Lbc;

    .line 24
    .line 25
    new-instance v0, Lbc;

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 29
    .line 30
    .line 31
    sput-object v0, Lbc;->e:Lbc;

    .line 32
    .line 33
    new-instance v0, Lbc;

    .line 34
    .line 35
    const/4 v1, 0x4

    .line 36
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lbc;->f:Lbc;

    .line 40
    .line 41
    new-instance v0, Lbc;

    .line 42
    .line 43
    const/4 v1, 0x5

    .line 44
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Lbc;->g:Lbc;

    .line 48
    .line 49
    new-instance v0, Lbc;

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 53
    .line 54
    .line 55
    sput-object v0, Lbc;->h:Lbc;

    .line 56
    .line 57
    new-instance v0, Lef1;

    .line 58
    .line 59
    const/16 v1, 0xd

    .line 60
    .line 61
    invoke-direct {v0, v1}, Lef1;-><init>(B)V

    .line 62
    .line 63
    .line 64
    sput-object v0, Lbc;->i:Lef1;

    .line 65
    .line 66
    new-instance v0, Lbc;

    .line 67
    .line 68
    const/4 v1, 0x7

    .line 69
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 70
    .line 71
    .line 72
    sput-object v0, Lbc;->j:Lbc;

    .line 73
    .line 74
    new-instance v0, Lbc;

    .line 75
    .line 76
    const/16 v1, 0x8

    .line 77
    .line 78
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 79
    .line 80
    .line 81
    sput-object v0, Lbc;->k:Lbc;

    .line 82
    .line 83
    new-instance v0, Lbc;

    .line 84
    .line 85
    const/16 v1, 0x9

    .line 86
    .line 87
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 88
    .line 89
    .line 90
    sput-object v0, Lbc;->l:Lbc;

    .line 91
    .line 92
    new-instance v0, Lbc;

    .line 93
    .line 94
    const/16 v1, 0xa

    .line 95
    .line 96
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 97
    .line 98
    .line 99
    sput-object v0, Lbc;->m:Lbc;

    .line 100
    .line 101
    new-instance v0, Lbc;

    .line 102
    .line 103
    const/16 v1, 0xb

    .line 104
    .line 105
    invoke-direct {v0, v1}, Lbc;-><init>(B)V

    .line 106
    .line 107
    .line 108
    sput-object v0, Lbc;->n:Lbc;

    .line 109
    .line 110
    return-void
.end method

.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lbc;->a:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(Lqr3;Ljava/util/List;J)Lpr3;
    .locals 28

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    move-wide/from16 v3, p3

    .line 8
    .line 9
    iget-byte v2, v2, Lbc;->a:B

    .line 10
    .line 11
    const-string v9, "Collection contains no element matching the predicate."

    .line 12
    .line 13
    const/4 v8, 0x6

    .line 14
    const/4 v5, 0x7

    .line 15
    const/4 v10, 0x1

    .line 16
    sget-object v11, Lcy1;->i:Lcy1;

    .line 17
    .line 18
    const/4 v12, 0x0

    .line 19
    packed-switch v2, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    invoke-static {v3, v4}, Lw71;->k(J)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-static {v3, v4}, Lw71;->j(J)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    new-instance v3, Lqk6;

    .line 31
    .line 32
    const/16 v4, 0x13

    .line 33
    .line 34
    invoke-direct {v3, v4}, Lqk6;-><init>(B)V

    .line 35
    .line 36
    .line 37
    invoke-interface {v0, v1, v2, v11, v3}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    return-object v0

    .line 42
    :pswitch_0
    invoke-static {v3, v4}, Lw71;->g(J)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    if-eqz v1, :cond_0

    .line 47
    .line 48
    invoke-static {v3, v4}, Lw71;->i(J)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    goto :goto_0

    .line 53
    :cond_0
    move v1, v12

    .line 54
    :goto_0
    invoke-static {v3, v4}, Lw71;->f(J)Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-eqz v2, :cond_1

    .line 59
    .line 60
    invoke-static {v3, v4}, Lw71;->h(J)I

    .line 61
    .line 62
    .line 63
    move-result v12

    .line 64
    :cond_1
    new-instance v2, Lp36;

    .line 65
    .line 66
    const/16 v3, 0x1d

    .line 67
    .line 68
    invoke-direct {v2, v3}, Lp36;-><init>(B)V

    .line 69
    .line 70
    .line 71
    invoke-interface {v0, v1, v12, v11, v2}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    return-object v0

    .line 76
    :pswitch_1
    new-instance v2, Ljava/util/ArrayList;

    .line 77
    .line 78
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 79
    .line 80
    .line 81
    move-result v6

    .line 82
    invoke-direct {v2, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 83
    .line 84
    .line 85
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 86
    .line 87
    .line 88
    move-result v6

    .line 89
    move v7, v12

    .line 90
    move v8, v7

    .line 91
    :goto_1
    if-ge v12, v6, :cond_2

    .line 92
    .line 93
    invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    check-cast v9, Ljr3;

    .line 98
    .line 99
    invoke-interface {v9, v3, v4}, Ljr3;->e(J)Lc05;

    .line 100
    .line 101
    .line 102
    move-result-object v9

    .line 103
    iget v10, v9, Lc05;->i:I

    .line 104
    .line 105
    invoke-static {v7, v10}, Ljava/lang/Math;->max(II)I

    .line 106
    .line 107
    .line 108
    move-result v7

    .line 109
    iget v10, v9, Lc05;->j:I

    .line 110
    .line 111
    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    .line 112
    .line 113
    .line 114
    move-result v8

    .line 115
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    add-int/lit8 v12, v12, 0x1

    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_2
    new-instance v1, Lac;

    .line 122
    .line 123
    invoke-direct {v1, v2, v5}, Lac;-><init>(Ljava/util/ArrayList;B)V

    .line 124
    .line 125
    .line 126
    invoke-interface {v0, v7, v8, v11, v1}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    return-object v0

    .line 131
    :pswitch_2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    invoke-interface {v1, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    move-object v9, v2

    .line 139
    check-cast v9, Ljr3;

    .line 140
    .line 141
    const/4 v7, 0x0

    .line 142
    const/16 v8, 0xa

    .line 143
    .line 144
    const/4 v4, 0x0

    .line 145
    const/4 v5, 0x0

    .line 146
    const/4 v6, 0x0

    .line 147
    move-wide/from16 v2, p3

    .line 148
    .line 149
    invoke-static/range {v2 .. v8}, Lw71;->b(JIIIII)J

    .line 150
    .line 151
    .line 152
    move-result-wide v2

    .line 153
    invoke-interface {v9, v2, v3}, Ljr3;->e(J)Lc05;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    check-cast v1, Ljr3;

    .line 162
    .line 163
    iget v3, v2, Lc05;->i:I

    .line 164
    .line 165
    iget v4, v2, Lc05;->j:I

    .line 166
    .line 167
    if-ltz v3, :cond_3

    .line 168
    .line 169
    move v5, v10

    .line 170
    goto :goto_2

    .line 171
    :cond_3
    move v5, v12

    .line 172
    :goto_2
    if-gez v4, :cond_4

    .line 173
    .line 174
    move v10, v12

    .line 175
    :cond_4
    and-int/2addr v5, v10

    .line 176
    if-nez v5, :cond_5

    .line 177
    .line 178
    const-string v5, "width and height must be >= 0"

    .line 179
    .line 180
    invoke-static {v5}, Lny2;->a(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    :cond_5
    invoke-static {v3, v3, v4, v4}, Lx71;->h(IIII)J

    .line 184
    .line 185
    .line 186
    move-result-wide v3

    .line 187
    invoke-interface {v1, v3, v4}, Ljr3;->e(J)Lc05;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    iget v3, v2, Lc05;->i:I

    .line 192
    .line 193
    iget v4, v2, Lc05;->j:I

    .line 194
    .line 195
    new-instance v5, Ltz;

    .line 196
    .line 197
    const/4 v6, 0x3

    .line 198
    invoke-direct {v5, v1, v2, v6}, Ltz;-><init>(Lc05;Lc05;B)V

    .line 199
    .line 200
    .line 201
    invoke-interface {v0, v3, v4, v11, v5}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    return-object v0

    .line 206
    :pswitch_3
    invoke-static/range {p3 .. p4}, Lw71;->k(J)I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    invoke-static/range {p3 .. p4}, Lw71;->j(J)I

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    new-instance v3, Lbq2;

    .line 215
    .line 216
    invoke-direct {v3, v8}, Lbq2;-><init>(B)V

    .line 217
    .line 218
    .line 219
    invoke-interface {v0, v1, v2, v11, v3}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 220
    .line 221
    .line 222
    move-result-object v0

    .line 223
    return-object v0

    .line 224
    :pswitch_4
    invoke-static/range {p3 .. p4}, Lw71;->i(J)I

    .line 225
    .line 226
    .line 227
    move-result v1

    .line 228
    invoke-static/range {p3 .. p4}, Lw71;->h(J)I

    .line 229
    .line 230
    .line 231
    move-result v2

    .line 232
    sget-object v3, Lbc;->i:Lef1;

    .line 233
    .line 234
    invoke-interface {v0, v1, v2, v11, v3}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    return-object v0

    .line 239
    :pswitch_5
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 240
    .line 241
    .line 242
    const/high16 v2, 0x41000000    # 8.0f

    .line 243
    .line 244
    invoke-interface {v0, v2}, Lkl1;->s0(F)I

    .line 245
    .line 246
    .line 247
    move-result v10

    .line 248
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 249
    .line 250
    .line 251
    move-result-object v2

    .line 252
    :cond_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 253
    .line 254
    .line 255
    move-result v3

    .line 256
    const/4 v13, 0x0

    .line 257
    if-eqz v3, :cond_7

    .line 258
    .line 259
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object v3

    .line 263
    move-object v4, v3

    .line 264
    check-cast v4, Ljr3;

    .line 265
    .line 266
    invoke-static {v4}, Li23;->k(Ljr3;)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    const-string v5, "start"

    .line 271
    .line 272
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 273
    .line 274
    .line 275
    move-result v4

    .line 276
    if-eqz v4, :cond_6

    .line 277
    .line 278
    goto :goto_3

    .line 279
    :cond_7
    move-object v3, v13

    .line 280
    :goto_3
    move-object v14, v3

    .line 281
    check-cast v14, Ljr3;

    .line 282
    .line 283
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 284
    .line 285
    .line 286
    move-result-object v2

    .line 287
    :cond_8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 288
    .line 289
    .line 290
    move-result v3

    .line 291
    if-eqz v3, :cond_1f

    .line 292
    .line 293
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object v3

    .line 297
    move-object v15, v3

    .line 298
    check-cast v15, Ljr3;

    .line 299
    .line 300
    invoke-static {v15}, Li23;->k(Ljr3;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    const-string v4, "center"

    .line 305
    .line 306
    invoke-static {v3, v4}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v3

    .line 310
    if-eqz v3, :cond_8

    .line 311
    .line 312
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 313
    .line 314
    .line 315
    move-result-object v1

    .line 316
    :cond_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    if-eqz v2, :cond_a

    .line 321
    .line 322
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v2

    .line 326
    move-object v3, v2

    .line 327
    check-cast v3, Ljr3;

    .line 328
    .line 329
    invoke-static {v3}, Li23;->k(Ljr3;)Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    move-result-object v3

    .line 333
    const-string v4, "end"

    .line 334
    .line 335
    invoke-static {v3, v4}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    move-result v3

    .line 339
    if-eqz v3, :cond_9

    .line 340
    .line 341
    goto :goto_4

    .line 342
    :cond_a
    move-object v2, v13

    .line 343
    :goto_4
    move-object v9, v2

    .line 344
    check-cast v9, Ljr3;

    .line 345
    .line 346
    invoke-static/range {p3 .. p4}, Lw71;->i(J)I

    .line 347
    .line 348
    .line 349
    move-result v16

    .line 350
    invoke-static/range {p3 .. p4}, Lw71;->h(J)I

    .line 351
    .line 352
    .line 353
    move-result v1

    .line 354
    invoke-static/range {p3 .. p4}, Lw71;->e(J)Z

    .line 355
    .line 356
    .line 357
    move-result v17

    .line 358
    const/4 v6, 0x0

    .line 359
    const/16 v7, 0xa

    .line 360
    .line 361
    const/4 v3, 0x0

    .line 362
    const/4 v4, 0x0

    .line 363
    const/4 v5, 0x0

    .line 364
    move/from16 p0, v8

    .line 365
    .line 366
    move v8, v1

    .line 367
    move-wide/from16 v1, p3

    .line 368
    .line 369
    invoke-static/range {v1 .. v7}, Lw71;->b(JIIIII)J

    .line 370
    .line 371
    .line 372
    move-result-wide v3

    .line 373
    if-eqz v14, :cond_b

    .line 374
    .line 375
    invoke-interface {v14, v3, v4}, Ljr3;->e(J)Lc05;

    .line 376
    .line 377
    .line 378
    move-result-object v1

    .line 379
    goto :goto_5

    .line 380
    :cond_b
    move-object v1, v13

    .line 381
    :goto_5
    if-eqz v1, :cond_c

    .line 382
    .line 383
    iget v2, v1, Lc05;->i:I

    .line 384
    .line 385
    goto :goto_6

    .line 386
    :cond_c
    move v2, v12

    .line 387
    :goto_6
    if-lez v2, :cond_d

    .line 388
    .line 389
    move/from16 v25, v10

    .line 390
    .line 391
    goto :goto_7

    .line 392
    :cond_d
    move/from16 v25, v12

    .line 393
    .line 394
    :goto_7
    sub-int v5, v16, v2

    .line 395
    .line 396
    sub-int v5, v5, v25

    .line 397
    .line 398
    if-gez v5, :cond_e

    .line 399
    .line 400
    move v5, v12

    .line 401
    :cond_e
    if-eqz v17, :cond_14

    .line 402
    .line 403
    if-eqz v9, :cond_f

    .line 404
    .line 405
    invoke-interface {v9, v8}, Ljr3;->b0(I)I

    .line 406
    .line 407
    .line 408
    move-result v6

    .line 409
    goto :goto_8

    .line 410
    :cond_f
    move v6, v12

    .line 411
    :goto_8
    sub-int v7, v5, v10

    .line 412
    .line 413
    if-gez v7, :cond_10

    .line 414
    .line 415
    move v7, v12

    .line 416
    :cond_10
    mul-int/lit8 v7, v7, 0x6

    .line 417
    .line 418
    div-int/lit8 v7, v7, 0xa

    .line 419
    .line 420
    if-le v6, v7, :cond_11

    .line 421
    .line 422
    move/from16 v21, v7

    .line 423
    .line 424
    goto :goto_9

    .line 425
    :cond_11
    move/from16 v21, v6

    .line 426
    .line 427
    :goto_9
    if-eqz v9, :cond_12

    .line 428
    .line 429
    const/16 v23, 0x0

    .line 430
    .line 431
    const/16 v24, 0xd

    .line 432
    .line 433
    const/16 v20, 0x0

    .line 434
    .line 435
    const/16 v22, 0x0

    .line 436
    .line 437
    move-wide/from16 v18, v3

    .line 438
    .line 439
    invoke-static/range {v18 .. v24}, Lw71;->b(JIIIII)J

    .line 440
    .line 441
    .line 442
    move-result-wide v3

    .line 443
    move-wide/from16 v6, v18

    .line 444
    .line 445
    invoke-interface {v9, v3, v4}, Ljr3;->e(J)Lc05;

    .line 446
    .line 447
    .line 448
    move-result-object v3

    .line 449
    goto :goto_a

    .line 450
    :cond_12
    move-wide v6, v3

    .line 451
    :cond_13
    move-object v3, v13

    .line 452
    goto :goto_a

    .line 453
    :cond_14
    move-wide v6, v3

    .line 454
    if-eqz v9, :cond_13

    .line 455
    .line 456
    invoke-interface {v9, v6, v7}, Ljr3;->e(J)Lc05;

    .line 457
    .line 458
    .line 459
    move-result-object v3

    .line 460
    :goto_a
    if-eqz v3, :cond_15

    .line 461
    .line 462
    iget v4, v3, Lc05;->i:I

    .line 463
    .line 464
    goto :goto_b

    .line 465
    :cond_15
    move v4, v12

    .line 466
    :goto_b
    if-gtz v4, :cond_16

    .line 467
    .line 468
    move v10, v12

    .line 469
    :cond_16
    if-eqz v17, :cond_18

    .line 470
    .line 471
    sub-int/2addr v5, v4

    .line 472
    sub-int/2addr v5, v10

    .line 473
    if-gez v5, :cond_17

    .line 474
    .line 475
    move/from16 v21, v12

    .line 476
    .line 477
    goto :goto_c

    .line 478
    :cond_17
    move/from16 v21, v5

    .line 479
    .line 480
    :goto_c
    const/16 v23, 0x0

    .line 481
    .line 482
    const/16 v24, 0xd

    .line 483
    .line 484
    const/16 v20, 0x0

    .line 485
    .line 486
    const/16 v22, 0x0

    .line 487
    .line 488
    move-wide/from16 v18, v6

    .line 489
    .line 490
    invoke-static/range {v18 .. v24}, Lw71;->b(JIIIII)J

    .line 491
    .line 492
    .line 493
    move-result-wide v5

    .line 494
    goto :goto_d

    .line 495
    :cond_18
    move-wide/from16 v18, v6

    .line 496
    .line 497
    move-wide/from16 v5, v18

    .line 498
    .line 499
    :goto_d
    invoke-interface {v15, v5, v6}, Ljr3;->e(J)Lc05;

    .line 500
    .line 501
    .line 502
    move-result-object v5

    .line 503
    if-eqz v1, :cond_19

    .line 504
    .line 505
    iget v6, v1, Lc05;->j:I

    .line 506
    .line 507
    goto :goto_e

    .line 508
    :cond_19
    move v6, v12

    .line 509
    :goto_e
    if-eqz v3, :cond_1a

    .line 510
    .line 511
    iget v12, v3, Lc05;->j:I

    .line 512
    .line 513
    :cond_1a
    iget v7, v5, Lc05;->j:I

    .line 514
    .line 515
    invoke-static {v7, v12}, Ljava/lang/Math;->max(II)I

    .line 516
    .line 517
    .line 518
    move-result v7

    .line 519
    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    .line 520
    .line 521
    .line 522
    move-result v7

    .line 523
    invoke-static/range {p3 .. p4}, Lw71;->j(J)I

    .line 524
    .line 525
    .line 526
    move-result v9

    .line 527
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 528
    .line 529
    .line 530
    move-result-object v14

    .line 531
    const v15, 0x7fffffff

    .line 532
    .line 533
    .line 534
    if-eq v8, v15, :cond_1b

    .line 535
    .line 536
    move-object v13, v14

    .line 537
    :cond_1b
    if-eqz v13, :cond_1c

    .line 538
    .line 539
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 540
    .line 541
    .line 542
    move-result v8

    .line 543
    goto :goto_f

    .line 544
    :cond_1c
    move v8, v7

    .line 545
    :goto_f
    invoke-static {v7, v9, v8}, Lkb3;->B(III)I

    .line 546
    .line 547
    .line 548
    move-result v8

    .line 549
    if-nez v17, :cond_1e

    .line 550
    .line 551
    add-int v9, v2, v25

    .line 552
    .line 553
    iget v13, v5, Lc05;->i:I

    .line 554
    .line 555
    add-int/2addr v9, v13

    .line 556
    add-int/2addr v9, v10

    .line 557
    add-int/2addr v9, v4

    .line 558
    invoke-static/range {p3 .. p4}, Lw71;->k(J)I

    .line 559
    .line 560
    .line 561
    move-result v4

    .line 562
    if-ge v9, v4, :cond_1d

    .line 563
    .line 564
    move/from16 v16, v4

    .line 565
    .line 566
    goto :goto_10

    .line 567
    :cond_1d
    move/from16 v16, v9

    .line 568
    .line 569
    :cond_1e
    :goto_10
    move/from16 v27, v16

    .line 570
    .line 571
    new-instance v18, Lrz0;

    .line 572
    .line 573
    move-object/from16 v23, v1

    .line 574
    .line 575
    move/from16 v24, v2

    .line 576
    .line 577
    move-object/from16 v26, v3

    .line 578
    .line 579
    move-object/from16 v21, v5

    .line 580
    .line 581
    move/from16 v20, v6

    .line 582
    .line 583
    move/from16 v19, v7

    .line 584
    .line 585
    move/from16 v22, v12

    .line 586
    .line 587
    invoke-direct/range {v18 .. v27}, Lrz0;-><init>(IILc05;ILc05;IILc05;I)V

    .line 588
    .line 589
    .line 590
    move-object/from16 v2, v18

    .line 591
    .line 592
    move/from16 v1, v27

    .line 593
    .line 594
    invoke-interface {v0, v1, v8, v11, v2}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 595
    .line 596
    .line 597
    move-result-object v13

    .line 598
    goto :goto_11

    .line 599
    :cond_1f
    invoke-static {v9}, Lsl4;->h(Ljava/lang/String;)V

    .line 600
    .line 601
    .line 602
    :goto_11
    return-object v13

    .line 603
    :pswitch_6
    invoke-static/range {p3 .. p4}, Lw71;->k(J)I

    .line 604
    .line 605
    .line 606
    move-result v1

    .line 607
    invoke-static/range {p3 .. p4}, Lw71;->j(J)I

    .line 608
    .line 609
    .line 610
    move-result v2

    .line 611
    new-instance v3, Lfb0;

    .line 612
    .line 613
    invoke-direct {v3, v5}, Lfb0;-><init>(B)V

    .line 614
    .line 615
    .line 616
    invoke-interface {v0, v1, v2, v11, v3}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 617
    .line 618
    .line 619
    move-result-object v0

    .line 620
    return-object v0

    .line 621
    :pswitch_7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 622
    .line 623
    .line 624
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 625
    .line 626
    .line 627
    move-result v2

    .line 628
    move v3, v12

    .line 629
    :goto_12
    if-ge v3, v2, :cond_23

    .line 630
    .line 631
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 632
    .line 633
    .line 634
    move-result-object v4

    .line 635
    move-object v10, v4

    .line 636
    check-cast v10, Ljr3;

    .line 637
    .line 638
    invoke-static {v10}, Li23;->k(Ljr3;)Ljava/lang/Object;

    .line 639
    .line 640
    .line 641
    move-result-object v4

    .line 642
    const-string v5, "badge"

    .line 643
    .line 644
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 645
    .line 646
    .line 647
    move-result v4

    .line 648
    if-eqz v4, :cond_22

    .line 649
    .line 650
    const/4 v7, 0x0

    .line 651
    const/16 v8, 0xb

    .line 652
    .line 653
    const/4 v4, 0x0

    .line 654
    const/4 v5, 0x0

    .line 655
    const/4 v6, 0x0

    .line 656
    move-wide/from16 v2, p3

    .line 657
    .line 658
    invoke-static/range {v2 .. v8}, Lw71;->b(JIIIII)J

    .line 659
    .line 660
    .line 661
    move-result-wide v4

    .line 662
    move-wide v6, v2

    .line 663
    invoke-interface {v10, v4, v5}, Ljr3;->e(J)Lc05;

    .line 664
    .line 665
    .line 666
    move-result-object v2

    .line 667
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 668
    .line 669
    .line 670
    move-result v3

    .line 671
    move v4, v12

    .line 672
    :goto_13
    if-ge v4, v3, :cond_21

    .line 673
    .line 674
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 675
    .line 676
    .line 677
    move-result-object v5

    .line 678
    check-cast v5, Ljr3;

    .line 679
    .line 680
    invoke-static {v5}, Li23;->k(Ljr3;)Ljava/lang/Object;

    .line 681
    .line 682
    .line 683
    move-result-object v8

    .line 684
    const-string v10, "anchor"

    .line 685
    .line 686
    invoke-static {v8, v10}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 687
    .line 688
    .line 689
    move-result v8

    .line 690
    if-eqz v8, :cond_20

    .line 691
    .line 692
    invoke-interface {v5, v6, v7}, Ljr3;->e(J)Lc05;

    .line 693
    .line 694
    .line 695
    move-result-object v1

    .line 696
    sget-object v3, Ll8;->a:Lqs2;

    .line 697
    .line 698
    invoke-virtual {v1, v3}, Lc05;->g0(Li8;)I

    .line 699
    .line 700
    .line 701
    move-result v4

    .line 702
    sget-object v5, Ll8;->b:Lqs2;

    .line 703
    .line 704
    invoke-virtual {v1, v5}, Lc05;->g0(Li8;)I

    .line 705
    .line 706
    .line 707
    move-result v6

    .line 708
    iget v7, v1, Lc05;->i:I

    .line 709
    .line 710
    iget v8, v1, Lc05;->j:I

    .line 711
    .line 712
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 713
    .line 714
    .line 715
    move-result-object v4

    .line 716
    new-instance v9, Lnw4;

    .line 717
    .line 718
    invoke-direct {v9, v3, v4}, Lnw4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 719
    .line 720
    .line 721
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 722
    .line 723
    .line 724
    move-result-object v3

    .line 725
    new-instance v4, Lnw4;

    .line 726
    .line 727
    invoke-direct {v4, v5, v3}, Lnw4;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 728
    .line 729
    .line 730
    filled-new-array {v9, v4}, [Lnw4;

    .line 731
    .line 732
    .line 733
    move-result-object v3

    .line 734
    invoke-static {v3}, Lep3;->N([Lnw4;)Ljava/util/Map;

    .line 735
    .line 736
    .line 737
    move-result-object v3

    .line 738
    new-instance v4, Ltz;

    .line 739
    .line 740
    invoke-direct {v4, v2, v1, v12}, Ltz;-><init>(Lc05;Lc05;B)V

    .line 741
    .line 742
    .line 743
    invoke-interface {v0, v7, v8, v3, v4}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 744
    .line 745
    .line 746
    move-result-object v0

    .line 747
    return-object v0

    .line 748
    :cond_20
    add-int/lit8 v4, v4, 0x1

    .line 749
    .line 750
    goto :goto_13

    .line 751
    :cond_21
    invoke-static {v9}, Luj6;->B(Ljava/lang/String;)Luy0;

    .line 752
    .line 753
    .line 754
    move-result-object v0

    .line 755
    throw v0

    .line 756
    :cond_22
    add-int/lit8 v3, v3, 0x1

    .line 757
    .line 758
    goto/16 :goto_12

    .line 759
    .line 760
    :cond_23
    invoke-static {v9}, Luj6;->B(Ljava/lang/String;)Luy0;

    .line 761
    .line 762
    .line 763
    move-result-object v0

    .line 764
    throw v0

    .line 765
    :pswitch_8
    move-wide v6, v3

    .line 766
    new-instance v2, Ljava/util/ArrayList;

    .line 767
    .line 768
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 769
    .line 770
    .line 771
    move-result v3

    .line 772
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 773
    .line 774
    .line 775
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 776
    .line 777
    .line 778
    move-result v3

    .line 779
    :goto_14
    if-ge v12, v3, :cond_24

    .line 780
    .line 781
    invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 782
    .line 783
    .line 784
    move-result-object v4

    .line 785
    check-cast v4, Ljr3;

    .line 786
    .line 787
    invoke-interface {v4, v6, v7}, Ljr3;->e(J)Lc05;

    .line 788
    .line 789
    .line 790
    move-result-object v4

    .line 791
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 792
    .line 793
    .line 794
    add-int/lit8 v12, v12, 0x1

    .line 795
    .line 796
    goto :goto_14

    .line 797
    :cond_24
    invoke-static {v6, v7}, Lw71;->i(J)I

    .line 798
    .line 799
    .line 800
    move-result v1

    .line 801
    invoke-static {v6, v7}, Lw71;->h(J)I

    .line 802
    .line 803
    .line 804
    move-result v3

    .line 805
    new-instance v4, Lac;

    .line 806
    .line 807
    invoke-direct {v4, v2, v10}, Lac;-><init>(Ljava/util/ArrayList;B)V

    .line 808
    .line 809
    .line 810
    invoke-interface {v0, v1, v3, v11, v4}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 811
    .line 812
    .line 813
    move-result-object v0

    .line 814
    return-object v0

    .line 815
    :pswitch_9
    move-wide v6, v3

    .line 816
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 817
    .line 818
    .line 819
    move-result v2

    .line 820
    if-eqz v2, :cond_27

    .line 821
    .line 822
    if-eq v2, v10, :cond_26

    .line 823
    .line 824
    new-instance v2, Ljava/util/ArrayList;

    .line 825
    .line 826
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 827
    .line 828
    .line 829
    move-result v3

    .line 830
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 831
    .line 832
    .line 833
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 834
    .line 835
    .line 836
    move-result v3

    .line 837
    move v4, v12

    .line 838
    move v5, v4

    .line 839
    move v8, v5

    .line 840
    :goto_15
    if-ge v4, v3, :cond_25

    .line 841
    .line 842
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 843
    .line 844
    .line 845
    move-result-object v9

    .line 846
    check-cast v9, Ljr3;

    .line 847
    .line 848
    invoke-interface {v9, v6, v7}, Ljr3;->e(J)Lc05;

    .line 849
    .line 850
    .line 851
    move-result-object v9

    .line 852
    iget v10, v9, Lc05;->i:I

    .line 853
    .line 854
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 855
    .line 856
    .line 857
    move-result v5

    .line 858
    iget v10, v9, Lc05;->j:I

    .line 859
    .line 860
    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    .line 861
    .line 862
    .line 863
    move-result v8

    .line 864
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 865
    .line 866
    .line 867
    add-int/lit8 v4, v4, 0x1

    .line 868
    .line 869
    goto :goto_15

    .line 870
    :cond_25
    new-instance v1, Lud;

    .line 871
    .line 872
    invoke-direct {v1, v2, v12}, Lud;-><init>(Ljava/util/ArrayList;B)V

    .line 873
    .line 874
    .line 875
    invoke-interface {v0, v5, v8, v11, v1}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 876
    .line 877
    .line 878
    move-result-object v0

    .line 879
    goto :goto_16

    .line 880
    :cond_26
    invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 881
    .line 882
    .line 883
    move-result-object v1

    .line 884
    check-cast v1, Ljr3;

    .line 885
    .line 886
    invoke-interface {v1, v6, v7}, Ljr3;->e(J)Lc05;

    .line 887
    .line 888
    .line 889
    move-result-object v1

    .line 890
    iget v2, v1, Lc05;->i:I

    .line 891
    .line 892
    iget v3, v1, Lc05;->j:I

    .line 893
    .line 894
    new-instance v4, Ltd;

    .line 895
    .line 896
    invoke-direct {v4, v1, v12}, Ltd;-><init>(Ljava/lang/Object;B)V

    .line 897
    .line 898
    .line 899
    invoke-interface {v0, v2, v3, v11, v4}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 900
    .line 901
    .line 902
    move-result-object v0

    .line 903
    goto :goto_16

    .line 904
    :cond_27
    sget-object v1, Lsd;->j:Lsd;

    .line 905
    .line 906
    invoke-interface {v0, v12, v12, v11, v1}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 907
    .line 908
    .line 909
    move-result-object v0

    .line 910
    :goto_16
    return-object v0

    .line 911
    :pswitch_a
    move-wide v6, v3

    .line 912
    new-instance v2, Ljava/util/ArrayList;

    .line 913
    .line 914
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 915
    .line 916
    .line 917
    move-result v3

    .line 918
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 919
    .line 920
    .line 921
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 922
    .line 923
    .line 924
    move-result v3

    .line 925
    move v4, v12

    .line 926
    move v5, v4

    .line 927
    move v8, v5

    .line 928
    :goto_17
    if-ge v4, v3, :cond_28

    .line 929
    .line 930
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 931
    .line 932
    .line 933
    move-result-object v9

    .line 934
    check-cast v9, Ljr3;

    .line 935
    .line 936
    invoke-interface {v9, v6, v7}, Ljr3;->e(J)Lc05;

    .line 937
    .line 938
    .line 939
    move-result-object v9

    .line 940
    iget v10, v9, Lc05;->i:I

    .line 941
    .line 942
    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    .line 943
    .line 944
    .line 945
    move-result v5

    .line 946
    iget v10, v9, Lc05;->j:I

    .line 947
    .line 948
    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    .line 949
    .line 950
    .line 951
    move-result v8

    .line 952
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 953
    .line 954
    .line 955
    add-int/lit8 v4, v4, 0x1

    .line 956
    .line 957
    goto :goto_17

    .line 958
    :cond_28
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 959
    .line 960
    .line 961
    move-result v1

    .line 962
    if-eqz v1, :cond_29

    .line 963
    .line 964
    invoke-static {v6, v7}, Lw71;->k(J)I

    .line 965
    .line 966
    .line 967
    move-result v5

    .line 968
    invoke-static {v6, v7}, Lw71;->j(J)I

    .line 969
    .line 970
    .line 971
    move-result v8

    .line 972
    :cond_29
    new-instance v1, Lac;

    .line 973
    .line 974
    invoke-direct {v1, v2, v12}, Lac;-><init>(Ljava/util/ArrayList;B)V

    .line 975
    .line 976
    .line 977
    invoke-interface {v0, v5, v8, v11, v1}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 978
    .line 979
    .line 980
    move-result-object v0

    .line 981
    return-object v0

    .line 982
    nop

    .line 983
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
