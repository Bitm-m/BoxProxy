.class public final synthetic La41;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lu92;

.field public final synthetic k:Lu92;

.field public final synthetic l:Z


# direct methods
.method public synthetic constructor <init>(Lu92;Lu92;ZI)V
    .locals 0

    .line 1
    const/4 p4, 0x1

    .line 2
    iput-byte p4, p0, La41;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La41;->j:Lu92;

    .line 8
    .line 9
    iput-object p2, p0, La41;->k:Lu92;

    .line 10
    .line 11
    iput-boolean p3, p0, La41;->l:Z

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(ZLu92;Lu92;IB)V
    .locals 0

    .line 14
    iput-byte p5, p0, La41;->i:B

    iput-boolean p1, p0, La41;->l:Z

    iput-object p2, p0, La41;->j:Lu92;

    iput-object p3, p0, La41;->k:Lu92;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, La41;->i:B

    .line 2
    .line 3
    const/16 v1, 0x181

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    sget-object v3, Lxc7;->a:Lxc7;

    .line 7
    .line 8
    iget-object v4, p0, La41;->k:Lu92;

    .line 9
    .line 10
    iget-object v5, p0, La41;->j:Lu92;

    .line 11
    .line 12
    iget-boolean p0, p0, La41;->l:Z

    .line 13
    .line 14
    check-cast p1, Lib2;

    .line 15
    .line 16
    check-cast p2, Ljava/lang/Integer;

    .line 17
    .line 18
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    packed-switch v0, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    invoke-static {v2}, Lcc3;->X(I)I

    .line 25
    .line 26
    .line 27
    move-result p2

    .line 28
    invoke-static {p2, v5, v4, p1, p0}, Lur6;->a(ILu92;Lu92;Lib2;Z)V

    .line 29
    .line 30
    .line 31
    return-object v3

    .line 32
    :pswitch_0
    invoke-static {v1}, Lcc3;->X(I)I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    invoke-static {p2, v5, v4, p1, p0}, Ln93;->j(ILu92;Lu92;Lib2;Z)V

    .line 37
    .line 38
    .line 39
    return-object v3

    .line 40
    :pswitch_1
    invoke-static {v1}, Lcc3;->X(I)I

    .line 41
    .line 42
    .line 43
    move-result p2

    .line 44
    invoke-static {p2, v5, v4, p1, p0}, Ln93;->j(ILu92;Lu92;Lib2;Z)V

    .line 45
    .line 46
    .line 47
    return-object v3

    .line 48
    :pswitch_2
    const/16 p2, 0x37

    .line 49
    .line 50
    invoke-static {p2}, Lcc3;->X(I)I

    .line 51
    .line 52
    .line 53
    move-result p2

    .line 54
    invoke-static {p2, v5, v4, p1, p0}, Lnn;->f(ILu92;Lu92;Lib2;Z)V

    .line 55
    .line 56
    .line 57
    return-object v3

    .line 58
    :pswitch_3
    invoke-static {v2}, Lcc3;->X(I)I

    .line 59
    .line 60
    .line 61
    move-result p2

    .line 62
    invoke-static {p2, v5, v4, p1, p0}, Lvj;->j(ILu92;Lu92;Lib2;Z)V

    .line 63
    .line 64
    .line 65
    return-object v3

    .line 66
    nop

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
