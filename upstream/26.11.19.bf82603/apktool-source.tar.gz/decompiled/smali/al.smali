.class public final synthetic Lal;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lbk;

.field public final synthetic k:Z

.field public final synthetic l:Z

.field public final synthetic m:Lqo0;

.field public final synthetic n:Ljava/util/List;

.field public final synthetic o:Lfa2;


# direct methods
.method public synthetic constructor <init>(Lbk;ZZLqo0;Ljava/util/List;Lfa2;B)V
    .locals 0

    .line 1
    iput-byte p7, p0, Lal;->i:B

    .line 2
    .line 3
    iput-object p1, p0, Lal;->j:Lbk;

    .line 4
    .line 5
    iput-boolean p2, p0, Lal;->k:Z

    .line 6
    .line 7
    iput-boolean p3, p0, Lal;->l:Z

    .line 8
    .line 9
    iput-object p4, p0, Lal;->m:Lqo0;

    .line 10
    .line 11
    iput-object p5, p0, Lal;->n:Ljava/util/List;

    .line 12
    .line 13
    iput-object p6, p0, Lal;->o:Lfa2;

    .line 14
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lal;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    sget-object v3, Lg21;->a:Ley0;

    .line 8
    .line 9
    const/4 v4, 0x2

    .line 10
    const/4 v5, 0x1

    .line 11
    const/4 v6, 0x0

    .line 12
    iget-object v7, v0, Lal;->o:Lfa2;

    .line 13
    .line 14
    iget-object v8, v0, Lal;->m:Lqo0;

    .line 15
    .line 16
    iget-boolean v9, v0, Lal;->l:Z

    .line 17
    .line 18
    iget-object v10, v0, Lal;->j:Lbk;

    .line 19
    .line 20
    packed-switch v1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    move-object/from16 v1, p1

    .line 24
    .line 25
    check-cast v1, Lib2;

    .line 26
    .line 27
    move-object/from16 v11, p2

    .line 28
    .line 29
    check-cast v11, Ljava/lang/Integer;

    .line 30
    .line 31
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 32
    .line 33
    .line 34
    move-result v11

    .line 35
    and-int/lit8 v12, v11, 0x3

    .line 36
    .line 37
    if-eq v12, v4, :cond_0

    .line 38
    .line 39
    move v4, v5

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    move v4, v6

    .line 42
    :goto_0
    and-int/2addr v11, v5

    .line 43
    invoke-virtual {v1, v11, v4}, Lib2;->X(IZ)Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    if-eqz v4, :cond_4

    .line 48
    .line 49
    iget-object v11, v10, Lbk;->a:Lee5;

    .line 50
    .line 51
    if-eqz v9, :cond_1

    .line 52
    .line 53
    iget-boolean v4, v8, Lqo0;->a:Z

    .line 54
    .line 55
    if-nez v4, :cond_1

    .line 56
    .line 57
    iget-boolean v4, v8, Lqo0;->b:Z

    .line 58
    .line 59
    if-eqz v4, :cond_1

    .line 60
    .line 61
    move v13, v5

    .line 62
    goto :goto_1

    .line 63
    :cond_1
    move v13, v6

    .line 64
    :goto_1
    invoke-virtual {v1, v7}, Lib2;->g(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    invoke-virtual {v1, v10}, Lib2;->i(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v5

    .line 72
    or-int/2addr v4, v5

    .line 73
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    if-nez v4, :cond_2

    .line 78
    .line 79
    if-ne v5, v3, :cond_3

    .line 80
    .line 81
    :cond_2
    new-instance v5, Llk;

    .line 82
    .line 83
    const/16 v3, 0xd

    .line 84
    .line 85
    invoke-direct {v5, v3, v10, v7}, Llk;-><init>(BLbk;Lfa2;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v1, v5}, Lib2;->p0(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_3
    move-object v15, v5

    .line 92
    check-cast v15, Lfa2;

    .line 93
    .line 94
    sget-object v3, Lee5;->c:Ljava/util/List;

    .line 95
    .line 96
    const/16 v17, 0x0

    .line 97
    .line 98
    iget-boolean v12, v0, Lal;->k:Z

    .line 99
    .line 100
    iget-object v14, v0, Lal;->n:Ljava/util/List;

    .line 101
    .line 102
    move-object/from16 v16, v1

    .line 103
    .line 104
    invoke-static/range {v11 .. v17}, Ld70;->j(Lee5;ZZLjava/util/List;Lfa2;Lib2;I)V

    .line 105
    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_4
    move-object/from16 v16, v1

    .line 109
    .line 110
    invoke-virtual/range {v16 .. v16}, Lib2;->a0()V

    .line 111
    .line 112
    .line 113
    :goto_2
    return-object v2

    .line 114
    :pswitch_0
    move-object/from16 v1, p1

    .line 115
    .line 116
    check-cast v1, Lib2;

    .line 117
    .line 118
    move-object/from16 v11, p2

    .line 119
    .line 120
    check-cast v11, Ljava/lang/Integer;

    .line 121
    .line 122
    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    .line 123
    .line 124
    .line 125
    move-result v11

    .line 126
    and-int/lit8 v12, v11, 0x3

    .line 127
    .line 128
    if-eq v12, v4, :cond_5

    .line 129
    .line 130
    move v4, v5

    .line 131
    goto :goto_3

    .line 132
    :cond_5
    move v4, v6

    .line 133
    :goto_3
    and-int/2addr v11, v5

    .line 134
    invoke-virtual {v1, v11, v4}, Lib2;->X(IZ)Z

    .line 135
    .line 136
    .line 137
    move-result v4

    .line 138
    if-eqz v4, :cond_a

    .line 139
    .line 140
    iget-object v4, v10, Lbk;->a:Lee5;

    .line 141
    .line 142
    if-eqz v9, :cond_6

    .line 143
    .line 144
    iget-boolean v9, v8, Lqo0;->a:Z

    .line 145
    .line 146
    if-nez v9, :cond_6

    .line 147
    .line 148
    iget-boolean v8, v8, Lqo0;->b:Z

    .line 149
    .line 150
    if-nez v8, :cond_7

    .line 151
    .line 152
    :cond_6
    move v5, v6

    .line 153
    :cond_7
    invoke-virtual {v1, v7}, Lib2;->g(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v6

    .line 157
    invoke-virtual {v1, v10}, Lib2;->i(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v8

    .line 161
    or-int/2addr v6, v8

    .line 162
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v8

    .line 166
    if-nez v6, :cond_8

    .line 167
    .line 168
    if-ne v8, v3, :cond_9

    .line 169
    .line 170
    :cond_8
    new-instance v8, Llk;

    .line 171
    .line 172
    const/4 v3, 0x5

    .line 173
    invoke-direct {v8, v3, v10, v7}, Llk;-><init>(BLbk;Lfa2;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v1, v8}, Lib2;->p0(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_9
    move-object v7, v8

    .line 180
    check-cast v7, Lfa2;

    .line 181
    .line 182
    sget-object v3, Lee5;->c:Ljava/util/List;

    .line 183
    .line 184
    const/4 v9, 0x0

    .line 185
    move-object v3, v4

    .line 186
    iget-boolean v4, v0, Lal;->k:Z

    .line 187
    .line 188
    iget-object v6, v0, Lal;->n:Ljava/util/List;

    .line 189
    .line 190
    move-object v8, v1

    .line 191
    invoke-static/range {v3 .. v9}, La70;->i(Lee5;ZZLjava/util/List;Lfa2;Lib2;I)V

    .line 192
    .line 193
    .line 194
    goto :goto_4

    .line 195
    :cond_a
    move-object v8, v1

    .line 196
    invoke-virtual {v8}, Lib2;->a0()V

    .line 197
    .line 198
    .line 199
    :goto_4
    return-object v2

    .line 200
    nop

    .line 201
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
