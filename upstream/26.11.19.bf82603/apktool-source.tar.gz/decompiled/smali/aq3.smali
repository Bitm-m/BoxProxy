.class public final synthetic Laq3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Z

.field public final synthetic k:Lu92;

.field public final synthetic l:B

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lu92;ZLjava/lang/String;II)V
    .locals 0

    .line 18
    const/4 p5, 0x0

    iput-byte p5, p0, Laq3;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laq3;->m:Ljava/lang/Object;

    iput-object p2, p0, Laq3;->k:Lu92;

    iput-boolean p3, p0, Laq3;->j:Z

    iput-object p4, p0, Laq3;->n:Ljava/lang/Object;

    iput-byte p6, p0, Laq3;->l:B

    return-void
.end method

.method public synthetic constructor <init>(Loo6;ZLu92;Lu92;II)V
    .locals 0

    .line 1
    const/4 p5, 0x1

    .line 2
    iput-byte p5, p0, Laq3;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Laq3;->m:Ljava/lang/Object;

    .line 8
    .line 9
    iput-boolean p2, p0, Laq3;->j:Z

    .line 10
    .line 11
    iput-object p3, p0, Laq3;->k:Lu92;

    .line 12
    .line 13
    iput-object p4, p0, Laq3;->n:Ljava/lang/Object;

    .line 14
    .line 15
    iput-byte p6, p0, Laq3;->l:B

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Laq3;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, v0, Laq3;->n:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v5, v0, Laq3;->m:Ljava/lang/Object;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object v6, v5

    .line 16
    check-cast v6, Loo6;

    .line 17
    .line 18
    move-object v9, v4

    .line 19
    check-cast v9, Lu92;

    .line 20
    .line 21
    move-object/from16 v10, p1

    .line 22
    .line 23
    check-cast v10, Lib2;

    .line 24
    .line 25
    move-object/from16 v1, p2

    .line 26
    .line 27
    check-cast v1, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-static {v3}, Lcc3;->X(I)I

    .line 33
    .line 34
    .line 35
    move-result v11

    .line 36
    iget-boolean v7, v0, Laq3;->j:Z

    .line 37
    .line 38
    iget-object v8, v0, Laq3;->k:Lu92;

    .line 39
    .line 40
    iget-byte v12, v0, Laq3;->l:B

    .line 41
    .line 42
    invoke-static/range {v6 .. v12}, Lfv6;->s(Loo6;ZLu92;Lu92;Lib2;II)V

    .line 43
    .line 44
    .line 45
    return-object v2

    .line 46
    :pswitch_0
    move-object v13, v5

    .line 47
    check-cast v13, Ljava/lang/String;

    .line 48
    .line 49
    move-object/from16 v16, v4

    .line 50
    .line 51
    check-cast v16, Ljava/lang/String;

    .line 52
    .line 53
    move-object/from16 v17, p1

    .line 54
    .line 55
    check-cast v17, Lib2;

    .line 56
    .line 57
    move-object/from16 v1, p2

    .line 58
    .line 59
    check-cast v1, Ljava/lang/Integer;

    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    invoke-static {v3}, Lcc3;->X(I)I

    .line 65
    .line 66
    .line 67
    move-result v18

    .line 68
    iget-object v14, v0, Laq3;->k:Lu92;

    .line 69
    .line 70
    iget-boolean v15, v0, Laq3;->j:Z

    .line 71
    .line 72
    iget-byte v0, v0, Laq3;->l:B

    .line 73
    .line 74
    move/from16 v19, v0

    .line 75
    .line 76
    invoke-static/range {v13 .. v19}, Lm46;->a(Ljava/lang/String;Lu92;ZLjava/lang/String;Lib2;II)V

    .line 77
    .line 78
    .line 79
    return-object v2

    .line 80
    nop

    .line 81
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
