.class public abstract La00;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lrl0;


# instance fields
.field public final a:Lsl0;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lsl0;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La00;->a:Lsl0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public a(Ldm0;Lsl0;Lw24;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p4, Lvl0;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final b(Ldm0;Lsl0;FLjava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p4, Lvl0;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public abstract d(Lol0;Lvl0;)V
.end method

.method public abstract e()Ljava/util/LinkedHashMap;
.end method

.method public abstract f(Lvl0;Lnl0;Lc34;)V
.end method

.method public abstract g(Lc34;FLck0;)Ljava/lang/Object;
.end method

.method public abstract h(Lu24;Lvl0;)V
.end method

.method public abstract i(Ldm0;Lw24;Lvl0;)V
.end method
