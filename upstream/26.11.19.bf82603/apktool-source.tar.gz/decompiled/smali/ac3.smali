.class public abstract Lac3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:Lnb3;


# direct methods
.method static constructor <clinit>()V
    .locals 21

    .line 1
    new-instance v5, Lzb3;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-direct {v5, v0}, Lzb3;-><init>(B)V

    .line 5
    .line 6
    .line 7
    invoke-static {}, Ljq;->i()Lnl1;

    .line 8
    .line 9
    .line 10
    move-result-object v9

    .line 11
    sget-object v0, Lxx1;->i:Lxx1;

    .line 12
    .line 13
    invoke-static {v0}, Ljn;->j(Ldf1;)Lca1;

    .line 14
    .line 15
    .line 16
    move-result-object v8

    .line 17
    new-instance v0, Lnb3;

    .line 18
    .line 19
    new-instance v11, Lbq2;

    .line 20
    .line 21
    const/16 v1, 0x13

    .line 22
    .line 23
    invoke-direct {v11, v1}, Lbq2;-><init>(B)V

    .line 24
    .line 25
    .line 26
    new-instance v12, Lbq2;

    .line 27
    .line 28
    const/16 v1, 0x14

    .line 29
    .line 30
    invoke-direct {v12, v1}, Lbq2;-><init>(B)V

    .line 31
    .line 32
    .line 33
    const/16 v19, 0x0

    .line 34
    .line 35
    const/16 v20, 0x0

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    const/4 v2, 0x0

    .line 39
    const/4 v3, 0x0

    .line 40
    const/4 v4, 0x0

    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x0

    .line 43
    const/4 v10, 0x0

    .line 44
    const/4 v13, 0x0

    .line 45
    sget-object v14, Lby1;->i:Lby1;

    .line 46
    .line 47
    const/4 v15, 0x0

    .line 48
    const/16 v16, 0x0

    .line 49
    .line 50
    const/16 v17, 0x0

    .line 51
    .line 52
    sget-object v18, Lip4;->i:Lip4;

    .line 53
    .line 54
    invoke-direct/range {v0 .. v20}, Lnb3;-><init>(Lpb3;IZFLpr3;FZLnf1;Lkl1;ILfa2;Lfa2;ILjava/util/List;IIILip4;II)V

    .line 55
    .line 56
    .line 57
    sput-object v0, Lac3;->a:Lnb3;

    .line 58
    .line 59
    return-void
.end method

.method public static final a(Lib2;)Lyb3;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    sget-object v2, Lyb3;->w:Lv06;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lib2;->e(I)Z

    .line 7
    .line 8
    .line 9
    move-result v3

    .line 10
    invoke-virtual {p0, v0}, Lib2;->e(I)Z

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    or-int/2addr v3, v4

    .line 15
    invoke-virtual {p0}, Lib2;->S()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    if-nez v3, :cond_0

    .line 20
    .line 21
    sget-object v3, Lg21;->a:Ley0;

    .line 22
    .line 23
    if-ne v4, v3, :cond_1

    .line 24
    .line 25
    :cond_0
    new-instance v4, Lg53;

    .line 26
    .line 27
    const/4 v3, 0x3

    .line 28
    invoke-direct {v4, v3}, Lg53;-><init>(B)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    check-cast v4, Lu92;

    .line 35
    .line 36
    invoke-static {v1, v2, v4, p0, v0}, Lm46;->c0([Ljava/lang/Object;Lu06;Lu92;Lib2;I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    check-cast p0, Lyb3;

    .line 41
    .line 42
    return-object p0
.end method
