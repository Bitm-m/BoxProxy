.class public final synthetic Lb7;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lj44;Ljava/util/Map;Lv35;Lo64;Lfa2;)V
    .locals 1

    .line 18
    const/4 v0, 0x7

    iput-byte v0, p0, Lb7;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb7;->n:Ljava/lang/Object;

    iput-object p2, p0, Lb7;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb7;->l:Ljava/lang/Object;

    iput-object p4, p0, Lb7;->j:Ljava/lang/Object;

    iput-object p5, p0, Lb7;->m:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Landroid/content/Context;Ljava/lang/String;B)V
    .locals 0

    .line 19
    iput-byte p6, p0, Lb7;->i:B

    iput-object p1, p0, Lb7;->k:Ljava/lang/Object;

    iput-object p2, p0, Lb7;->l:Ljava/lang/Object;

    iput-object p3, p0, Lb7;->m:Ljava/lang/Object;

    iput-object p4, p0, Lb7;->n:Ljava/lang/Object;

    iput-object p5, p0, Lb7;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 20
    iput-byte p6, p0, Lb7;->i:B

    iput-object p1, p0, Lb7;->k:Ljava/lang/Object;

    iput-object p2, p0, Lb7;->l:Ljava/lang/Object;

    iput-object p3, p0, Lb7;->j:Ljava/lang/Object;

    iput-object p4, p0, Lb7;->m:Ljava/lang/Object;

    iput-object p5, p0, Lb7;->n:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;B)V
    .locals 0

    .line 21
    iput-byte p6, p0, Lb7;->i:B

    iput-object p1, p0, Lb7;->k:Ljava/lang/Object;

    iput-object p2, p0, Lb7;->l:Ljava/lang/Object;

    iput-object p3, p0, Lb7;->m:Ljava/lang/Object;

    iput-object p4, p0, Lb7;->j:Ljava/lang/Object;

    iput-object p5, p0, Lb7;->n:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lu92;Lk12;Lnl6;Le87;Lu92;Lj67;F)V
    .locals 0

    .line 1
    const/4 p6, 0x5

    .line 2
    iput-byte p6, p0, Lb7;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb7;->k:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lb7;->l:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lb7;->j:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lb7;->m:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lb7;->n:Ljava/lang/Object;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb7;->i:B

    .line 4
    .line 5
    const/4 v2, 0x3

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x0

    .line 8
    const/high16 v5, 0x3f800000    # 1.0f

    .line 9
    .line 10
    const/16 v8, 0x20

    .line 11
    .line 12
    const/4 v9, 0x1

    .line 13
    const/4 v10, 0x0

    .line 14
    sget-object v11, Lxc7;->a:Lxc7;

    .line 15
    .line 16
    iget-object v12, v0, Lb7;->n:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object v13, v0, Lb7;->m:Ljava/lang/Object;

    .line 19
    .line 20
    iget-object v14, v0, Lb7;->j:Ljava/lang/Object;

    .line 21
    .line 22
    iget-object v15, v0, Lb7;->l:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v0, v0, Lb7;->k:Ljava/lang/Object;

    .line 25
    .line 26
    packed-switch v1, :pswitch_data_0

    .line 27
    .line 28
    .line 29
    check-cast v0, Lwu4;

    .line 30
    .line 31
    check-cast v15, Ltj5;

    .line 32
    .line 33
    check-cast v14, Lqj5;

    .line 34
    .line 35
    check-cast v13, Lsv4;

    .line 36
    .line 37
    check-cast v12, Lpj5;

    .line 38
    .line 39
    move-object/from16 v1, p1

    .line 40
    .line 41
    check-cast v1, Ljava/lang/Float;

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    iget-object v2, v0, Lwu4;->g:Lff0;

    .line 48
    .line 49
    invoke-static {v2}, Lwu4;->g(Lff0;)Lsu4;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    if-eqz v2, :cond_5

    .line 54
    .line 55
    iget-object v0, v0, Lzi4;->e:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Lcn1;

    .line 58
    .line 59
    iget-wide v3, v2, Lsu4;->b:J

    .line 60
    .line 61
    iget-wide v10, v2, Lsu4;->a:J

    .line 62
    .line 63
    iget-object v5, v0, Lcn1;->a:Lcf7;

    .line 64
    .line 65
    const-wide v16, 0xffffffffL

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    shr-long v6, v10, v8

    .line 71
    .line 72
    long-to-int v6, v6

    .line 73
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 74
    .line 75
    .line 76
    move-result v6

    .line 77
    invoke-virtual {v5, v3, v4, v6}, Lcf7;->a(JF)V

    .line 78
    .line 79
    .line 80
    iget-object v0, v0, Lcn1;->b:Lcf7;

    .line 81
    .line 82
    and-long v10, v10, v16

    .line 83
    .line 84
    long-to-int v5, v10

    .line 85
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    invoke-virtual {v0, v3, v4, v5}, Lcf7;->a(JF)V

    .line 90
    .line 91
    .line 92
    iget-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v0, Lsu4;

    .line 95
    .line 96
    invoke-virtual {v0, v2}, Lsu4;->a(Lsu4;)Lsu4;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    iput-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 101
    .line 102
    iget-wide v2, v0, Lsu4;->a:J

    .line 103
    .line 104
    invoke-virtual {v13, v2, v3}, Lsv4;->e(J)J

    .line 105
    .line 106
    .line 107
    move-result-wide v2

    .line 108
    invoke-static {v2, v3}, Lsv4;->g(J)F

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    iput v0, v14, Lqj5;->i:F

    .line 113
    .line 114
    sub-float/2addr v0, v1

    .line 115
    invoke-static {v0}, Li23;->o(F)Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    xor-int/2addr v0, v9

    .line 120
    iput-boolean v0, v12, Lpj5;->i:Z

    .line 121
    .line 122
    goto/16 :goto_1

    .line 123
    .line 124
    :pswitch_0
    check-cast v0, Ljava/util/List;

    .line 125
    .line 126
    check-cast v15, Lbf5;

    .line 127
    .line 128
    move-object v3, v13

    .line 129
    check-cast v3, Llp4;

    .line 130
    .line 131
    check-cast v12, Landroid/content/Context;

    .line 132
    .line 133
    check-cast v14, Ljava/lang/String;

    .line 134
    .line 135
    move-object/from16 v1, p1

    .line 136
    .line 137
    check-cast v1, Ljava/lang/Integer;

    .line 138
    .line 139
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    move-object v2, v0

    .line 148
    check-cast v2, Lbf5;

    .line 149
    .line 150
    if-eq v2, v15, :cond_0

    .line 151
    .line 152
    new-instance v5, Lxp4;

    .line 153
    .line 154
    const/16 v0, 0x15

    .line 155
    .line 156
    invoke-direct {v5, v12, v14, v0}, Lxp4;-><init>(Landroid/content/Context;Ljava/lang/String;B)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 160
    .line 161
    .line 162
    iget-object v0, v3, Llp4;->n:Lgx4;

    .line 163
    .line 164
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    move-object v4, v1

    .line 169
    check-cast v4, Lbf5;

    .line 170
    .line 171
    invoke-virtual {v0, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    iget-object v0, v3, Llp4;->a:Le27;

    .line 175
    .line 176
    new-instance v1, Lfs;

    .line 177
    .line 178
    const/4 v6, 0x0

    .line 179
    const/4 v7, 0x5

    .line 180
    invoke-direct/range {v1 .. v7}, Lfs;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 181
    .line 182
    .line 183
    const-string v2, "other-proxy-config-dns-hijack-mode"

    .line 184
    .line 185
    invoke-virtual {v0, v1, v2}, Le27;->g(Lfa2;Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    :cond_0
    return-object v11

    .line 189
    :pswitch_1
    check-cast v12, Lj44;

    .line 190
    .line 191
    check-cast v0, Ljava/util/Map;

    .line 192
    .line 193
    check-cast v15, Lv35;

    .line 194
    .line 195
    check-cast v14, Lo64;

    .line 196
    .line 197
    check-cast v13, Lfa2;

    .line 198
    .line 199
    move-object/from16 v1, p1

    .line 200
    .line 201
    check-cast v1, Ljava/lang/Long;

    .line 202
    .line 203
    if-nez v1, :cond_1

    .line 204
    .line 205
    invoke-interface {v12}, Lnl6;->getValue()Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    check-cast v0, Lu92;

    .line 210
    .line 211
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    goto :goto_0

    .line 215
    :cond_1
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v2

    .line 219
    check-cast v2, Lw35;

    .line 220
    .line 221
    if-eqz v2, :cond_4

    .line 222
    .line 223
    iget-wide v3, v2, Lw35;->a:J

    .line 224
    .line 225
    iget v2, v2, Lw35;->b:F

    .line 226
    .line 227
    const/high16 v5, -0x40800000    # -1.0f

    .line 228
    .line 229
    cmpl-float v5, v2, v5

    .line 230
    .line 231
    if-lez v5, :cond_3

    .line 232
    .line 233
    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    iget-object v0, v15, Lv35;->a:Lex4;

    .line 237
    .line 238
    invoke-virtual {v0}, Lex4;->g()J

    .line 239
    .line 240
    .line 241
    move-result-wide v0

    .line 242
    cmp-long v0, v0, v3

    .line 243
    .line 244
    if-nez v0, :cond_2

    .line 245
    .line 246
    neg-float v0, v2

    .line 247
    iput v0, v14, Lo64;->g:F

    .line 248
    .line 249
    :cond_2
    :try_start_0
    invoke-interface {v12}, Lnl6;->getValue()Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    check-cast v0, Lu92;

    .line 254
    .line 255
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 256
    .line 257
    .line 258
    invoke-virtual {v15, v3, v4}, Lv35;->a(J)Z

    .line 259
    .line 260
    .line 261
    goto :goto_0

    .line 262
    :catchall_0
    move-exception v0

    .line 263
    invoke-virtual {v15, v3, v4}, Lv35;->a(J)Z

    .line 264
    .line 265
    .line 266
    throw v0

    .line 267
    :cond_3
    invoke-interface {v13, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    :cond_4
    :goto_0
    return-object v11

    .line 271
    :pswitch_2
    const-wide v16, 0xffffffffL

    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    check-cast v0, Ly14;

    .line 277
    .line 278
    check-cast v15, Ltj5;

    .line 279
    .line 280
    check-cast v14, Lqj5;

    .line 281
    .line 282
    check-cast v13, Lh46;

    .line 283
    .line 284
    check-cast v12, Lpj5;

    .line 285
    .line 286
    move-object/from16 v1, p1

    .line 287
    .line 288
    check-cast v1, Ljava/lang/Float;

    .line 289
    .line 290
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 291
    .line 292
    .line 293
    move-result v1

    .line 294
    iget-object v2, v0, Ly14;->g:Lff0;

    .line 295
    .line 296
    invoke-static {v2}, Ly14;->h(Lff0;)Lu14;

    .line 297
    .line 298
    .line 299
    move-result-object v2

    .line 300
    if-eqz v2, :cond_5

    .line 301
    .line 302
    iget-object v0, v0, Lzi4;->e:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v0, Lcn1;

    .line 305
    .line 306
    iget-wide v3, v2, Lu14;->b:J

    .line 307
    .line 308
    iget-wide v5, v2, Lu14;->a:J

    .line 309
    .line 310
    iget-object v7, v0, Lcn1;->a:Lcf7;

    .line 311
    .line 312
    shr-long v10, v5, v8

    .line 313
    .line 314
    long-to-int v8, v10

    .line 315
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 316
    .line 317
    .line 318
    move-result v8

    .line 319
    invoke-virtual {v7, v3, v4, v8}, Lcf7;->a(JF)V

    .line 320
    .line 321
    .line 322
    iget-object v0, v0, Lcn1;->b:Lcf7;

    .line 323
    .line 324
    and-long v5, v5, v16

    .line 325
    .line 326
    long-to-int v5, v5

    .line 327
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 328
    .line 329
    .line 330
    move-result v5

    .line 331
    invoke-virtual {v0, v3, v4, v5}, Lcf7;->a(JF)V

    .line 332
    .line 333
    .line 334
    iget-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 335
    .line 336
    check-cast v0, Lu14;

    .line 337
    .line 338
    invoke-virtual {v0, v2}, Lu14;->a(Lu14;)Lu14;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    iput-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 343
    .line 344
    iget-wide v2, v0, Lu14;->a:J

    .line 345
    .line 346
    invoke-virtual {v13, v2, v3}, Lh46;->f(J)J

    .line 347
    .line 348
    .line 349
    move-result-wide v2

    .line 350
    invoke-virtual {v13, v2, v3}, Lh46;->j(J)F

    .line 351
    .line 352
    .line 353
    move-result v0

    .line 354
    iput v0, v14, Lqj5;->i:F

    .line 355
    .line 356
    sub-float/2addr v0, v1

    .line 357
    invoke-static {v0}, Lg93;->S(F)Z

    .line 358
    .line 359
    .line 360
    move-result v0

    .line 361
    xor-int/2addr v0, v9

    .line 362
    iput-boolean v0, v12, Lpj5;->i:Z

    .line 363
    .line 364
    goto :goto_1

    .line 365
    :cond_5
    move v9, v10

    .line 366
    :goto_1
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 367
    .line 368
    .line 369
    move-result-object v0

    .line 370
    return-object v0

    .line 371
    :pswitch_3
    check-cast v0, Lu92;

    .line 372
    .line 373
    check-cast v15, Lk12;

    .line 374
    .line 375
    check-cast v14, Lnl6;

    .line 376
    .line 377
    check-cast v13, Le87;

    .line 378
    .line 379
    check-cast v12, Lu92;

    .line 380
    .line 381
    move-object/from16 v1, p1

    .line 382
    .line 383
    check-cast v1, Lyh2;

    .line 384
    .line 385
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 386
    .line 387
    .line 388
    if-nez v0, :cond_6

    .line 389
    .line 390
    if-nez v15, :cond_6

    .line 391
    .line 392
    iget-object v0, v13, Le87;->p:Lgx4;

    .line 393
    .line 394
    invoke-virtual {v0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v0

    .line 398
    :goto_2
    check-cast v0, Ljava/lang/Number;

    .line 399
    .line 400
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 401
    .line 402
    .line 403
    move-result v0

    .line 404
    goto :goto_3

    .line 405
    :cond_6
    invoke-interface {v14}, Lnl6;->getValue()Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    goto :goto_2

    .line 410
    :goto_3
    invoke-interface {v12}, Lu92;->invoke()Ljava/lang/Object;

    .line 411
    .line 412
    .line 413
    move-result-object v2

    .line 414
    check-cast v2, Ljava/lang/Number;

    .line 415
    .line 416
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 417
    .line 418
    .line 419
    move-result v2

    .line 420
    invoke-static {v2, v4, v5}, Lkb3;->A(FFF)F

    .line 421
    .line 422
    .line 423
    move-result v2

    .line 424
    mul-float/2addr v2, v0

    .line 425
    invoke-interface {v1, v2}, Lyh2;->y(F)V

    .line 426
    .line 427
    .line 428
    const/high16 v0, 0x3f000000    # 0.5f

    .line 429
    .line 430
    invoke-static {v0, v4}, Lfs6;->a(FF)J

    .line 431
    .line 432
    .line 433
    move-result-wide v2

    .line 434
    invoke-interface {v1, v2, v3}, Lyh2;->t0(J)V

    .line 435
    .line 436
    .line 437
    invoke-interface {v1, v5}, Lyh2;->x0(F)V

    .line 438
    .line 439
    .line 440
    return-object v11

    .line 441
    :pswitch_4
    check-cast v0, Lta0;

    .line 442
    .line 443
    move-object v1, v15

    .line 444
    check-cast v1, Lnf1;

    .line 445
    .line 446
    check-cast v13, Lmv;

    .line 447
    .line 448
    move-object/from16 v17, v12

    .line 449
    .line 450
    check-cast v17, Landroid/content/Context;

    .line 451
    .line 452
    move-object/from16 v18, v14

    .line 453
    .line 454
    check-cast v18, Ljava/lang/String;

    .line 455
    .line 456
    move-object/from16 v4, p1

    .line 457
    .line 458
    check-cast v4, Ljava/lang/Boolean;

    .line 459
    .line 460
    move-object v14, v13

    .line 461
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 462
    .line 463
    .line 464
    move-result v13

    .line 465
    iget-object v5, v0, Lta0;->d:Lgx4;

    .line 466
    .line 467
    invoke-virtual {v5}, Lgx4;->getValue()Ljava/lang/Object;

    .line 468
    .line 469
    .line 470
    move-result-object v5

    .line 471
    check-cast v5, Ljava/lang/Boolean;

    .line 472
    .line 473
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 474
    .line 475
    .line 476
    move-result v16

    .line 477
    iget-object v5, v0, Lta0;->d:Lgx4;

    .line 478
    .line 479
    invoke-virtual {v5, v4}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 480
    .line 481
    .line 482
    new-instance v12, Lxa0;

    .line 483
    .line 484
    const/16 v19, 0x0

    .line 485
    .line 486
    move-object v15, v0

    .line 487
    invoke-direct/range {v12 .. v19}, Lxa0;-><init>(ZLmv;Lta0;ZLandroid/content/Context;Ljava/lang/String;Lea1;)V

    .line 488
    .line 489
    .line 490
    invoke-static {v1, v3, v3, v12, v2}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 491
    .line 492
    .line 493
    return-object v11

    .line 494
    :pswitch_5
    check-cast v0, Lnf1;

    .line 495
    .line 496
    move-object/from16 v17, v15

    .line 497
    .line 498
    check-cast v17, Landroid/content/Context;

    .line 499
    .line 500
    move-object/from16 v19, v13

    .line 501
    .line 502
    check-cast v19, Lta0;

    .line 503
    .line 504
    move-object/from16 v20, v14

    .line 505
    .line 506
    check-cast v20, Ljava/lang/String;

    .line 507
    .line 508
    move-object/from16 v21, v12

    .line 509
    .line 510
    check-cast v21, Ljava/lang/String;

    .line 511
    .line 512
    move-object/from16 v18, p1

    .line 513
    .line 514
    check-cast v18, Landroid/net/Uri;

    .line 515
    .line 516
    if-eqz v18, :cond_7

    .line 517
    .line 518
    new-instance v16, Lza0;

    .line 519
    .line 520
    const/16 v22, 0x0

    .line 521
    .line 522
    const/16 v23, 0x0

    .line 523
    .line 524
    invoke-direct/range {v16 .. v23}, Lza0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 525
    .line 526
    .line 527
    move-object/from16 v1, v16

    .line 528
    .line 529
    invoke-static {v0, v3, v3, v1, v2}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 530
    .line 531
    .line 532
    :cond_7
    return-object v11

    .line 533
    :pswitch_6
    check-cast v0, Lmg;

    .line 534
    .line 535
    check-cast v15, Ldx4;

    .line 536
    .line 537
    check-cast v14, Lkl1;

    .line 538
    .line 539
    check-cast v13, Lmg;

    .line 540
    .line 541
    check-cast v12, Lrk7;

    .line 542
    .line 543
    move-object/from16 v1, p1

    .line 544
    .line 545
    check-cast v1, Lyh2;

    .line 546
    .line 547
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 548
    .line 549
    .line 550
    invoke-virtual {v0}, Lmg;->e()Ljava/lang/Object;

    .line 551
    .line 552
    .line 553
    move-result-object v0

    .line 554
    check-cast v0, Ljava/lang/Number;

    .line 555
    .line 556
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 557
    .line 558
    .line 559
    move-result v0

    .line 560
    invoke-virtual {v15}, Ldx4;->g()I

    .line 561
    .line 562
    .line 563
    move-result v2

    .line 564
    int-to-float v2, v2

    .line 565
    check-cast v12, Lge3;

    .line 566
    .line 567
    invoke-virtual {v12}, Lge3;->a()J

    .line 568
    .line 569
    .line 570
    move-result-wide v6

    .line 571
    invoke-static {v6, v7}, Lpp1;->a(J)F

    .line 572
    .line 573
    .line 574
    move-result v3

    .line 575
    invoke-interface {v14, v3}, Lkl1;->L(F)F

    .line 576
    .line 577
    .line 578
    move-result v3

    .line 579
    cmpl-float v4, v2, v4

    .line 580
    .line 581
    if-gtz v4, :cond_8

    .line 582
    .line 583
    move v2, v3

    .line 584
    :cond_8
    sub-float/2addr v5, v0

    .line 585
    mul-float/2addr v5, v2

    .line 586
    invoke-virtual {v13}, Lmg;->e()Ljava/lang/Object;

    .line 587
    .line 588
    .line 589
    move-result-object v0

    .line 590
    check-cast v0, Ljava/lang/Number;

    .line 591
    .line 592
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 593
    .line 594
    .line 595
    move-result v0

    .line 596
    add-float/2addr v0, v5

    .line 597
    invoke-interface {v1, v0}, Lyh2;->R(F)V

    .line 598
    .line 599
    .line 600
    return-object v11

    .line 601
    :pswitch_7
    check-cast v0, Lz25;

    .line 602
    .line 603
    check-cast v15, Lu92;

    .line 604
    .line 605
    check-cast v13, Lf35;

    .line 606
    .line 607
    check-cast v14, Ljava/lang/String;

    .line 608
    .line 609
    check-cast v12, Lh93;

    .line 610
    .line 611
    move-object/from16 v1, p1

    .line 612
    .line 613
    check-cast v1, Lko1;

    .line 614
    .line 615
    iget-object v1, v0, Lz25;->x:Landroid/view/WindowManager;

    .line 616
    .line 617
    iget-object v2, v0, Lz25;->y:Landroid/view/WindowManager$LayoutParams;

    .line 618
    .line 619
    invoke-interface {v1, v0, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 620
    .line 621
    .line 622
    invoke-virtual {v0, v15, v13, v14, v12}, Lz25;->p(Lu92;Lf35;Ljava/lang/String;Lh93;)V

    .line 623
    .line 624
    .line 625
    new-instance v1, Ld7;

    .line 626
    .line 627
    const/4 v2, 0x2

    .line 628
    invoke-direct {v1, v0, v2}, Ld7;-><init>(Ljava/lang/Object;B)V

    .line 629
    .line 630
    .line 631
    return-object v1

    .line 632
    :pswitch_8
    check-cast v0, Ly6;

    .line 633
    .line 634
    check-cast v15, Liz0;

    .line 635
    .line 636
    check-cast v14, Ljava/lang/String;

    .line 637
    .line 638
    check-cast v13, Li23;

    .line 639
    .line 640
    check-cast v12, Lj44;

    .line 641
    .line 642
    move-object/from16 v1, p1

    .line 643
    .line 644
    check-cast v1, Lko1;

    .line 645
    .line 646
    new-instance v1, Lc7;

    .line 647
    .line 648
    invoke-direct {v1, v12, v10}, Lc7;-><init>(Ljava/lang/Object;B)V

    .line 649
    .line 650
    .line 651
    invoke-virtual {v15, v14, v13, v1}, Liz0;->c(Ljava/lang/String;Li23;Lq6;)La7;

    .line 652
    .line 653
    .line 654
    move-result-object v1

    .line 655
    iput-object v1, v0, Ly6;->a:La7;

    .line 656
    .line 657
    new-instance v1, Ld7;

    .line 658
    .line 659
    invoke-direct {v1, v0, v10}, Ld7;-><init>(Ljava/lang/Object;B)V

    .line 660
    .line 661
    .line 662
    return-object v1

    .line 663
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
