.class public final Lb24;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Lz14;

.field public final b:Ljava/lang/Object;

.field public final c:Lv21;

.field public final d:Lhh6;

.field public final e:Ldb2;

.field public f:Ljava/util/List;

.field public final g:Liz4;

.field public final h:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lz14;Ljava/lang/Object;Lv21;Lhh6;Ldb2;Ljava/util/List;Liz4;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb24;->a:Lz14;

    .line 5
    .line 6
    iput-object p2, p0, Lb24;->b:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lb24;->c:Lv21;

    .line 9
    .line 10
    iput-object p4, p0, Lb24;->d:Lhh6;

    .line 11
    .line 12
    iput-object p5, p0, Lb24;->e:Ldb2;

    .line 13
    .line 14
    iput-object p6, p0, Lb24;->f:Ljava/util/List;

    .line 15
    .line 16
    iput-object p7, p0, Lb24;->g:Liz4;

    .line 17
    .line 18
    iput-object p8, p0, Lb24;->h:Ljava/util/ArrayList;

    .line 19
    .line 20
    return-void
.end method
