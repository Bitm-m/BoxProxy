.class public final Lb64;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lf84;


# instance fields
.field public final i:Le84;


# direct methods
.method public constructor <init>(Le84;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb64;->i:Le84;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Le84;
    .locals 0

    .line 1
    iget-object p0, p0, Lb64;->i:Le84;

    .line 2
    .line 3
    return-object p0
.end method
