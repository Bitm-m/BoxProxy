.class public abstract Lb65;
.super Ld65;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lc73;


# virtual methods
.method public computeReflected()Lq63;
    .locals 1

    .line 1
    sget-object v0, Lvj5;->a:Lwj5;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public getDelegate()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ld65;->getReflected()Ld73;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Lc73;

    .line 6
    .line 7
    invoke-interface {p0}, Lc73;->getDelegate()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public bridge synthetic getGetter()La73;
    .locals 0

    .line 12
    invoke-virtual {p0}, Lb65;->getGetter()Lb73;

    const/4 p0, 0x0

    return-object p0
.end method

.method public getGetter()Lb73;
    .locals 0

    .line 1
    invoke-virtual {p0}, Ld65;->getReflected()Ld73;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Lc73;

    .line 6
    .line 7
    invoke-interface {p0}, Lc73;->getGetter()Lb73;

    .line 8
    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    return-object p0
.end method

.method public invoke()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p0}, Lc73;->get()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
