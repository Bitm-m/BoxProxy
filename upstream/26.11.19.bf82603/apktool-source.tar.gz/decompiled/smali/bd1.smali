.class public final Lbd1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Lme1;

.field public final synthetic k:Z

.field public final synthetic l:Lle1;

.field public final synthetic m:Ljava/util/List;

.field public final synthetic n:Lnf1;

.field public final synthetic o:Lj44;

.field public final synthetic p:Lj44;

.field public final synthetic q:Lj44;

.field public final synthetic r:Ljd1;

.field public final synthetic s:Lj44;

.field public final synthetic t:Lj44;

.field public final synthetic u:Lj44;

.field public final synthetic v:Ljava/util/Map;

.field public final synthetic w:Lj44;

.field public final synthetic x:Lj44;


# direct methods
.method public constructor <init>(ZLme1;ZLle1;Ljava/util/List;Lnf1;Lj44;Lj44;Lj44;Ljd1;Lj44;Lj44;Lj44;Ljava/util/Map;Lj44;Lj44;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lbd1;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Lbd1;->j:Lme1;

    .line 7
    .line 8
    iput-boolean p3, p0, Lbd1;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Lbd1;->l:Lle1;

    .line 11
    .line 12
    iput-object p5, p0, Lbd1;->m:Ljava/util/List;

    .line 13
    .line 14
    iput-object p6, p0, Lbd1;->n:Lnf1;

    .line 15
    .line 16
    iput-object p7, p0, Lbd1;->o:Lj44;

    .line 17
    .line 18
    iput-object p8, p0, Lbd1;->p:Lj44;

    .line 19
    .line 20
    iput-object p9, p0, Lbd1;->q:Lj44;

    .line 21
    .line 22
    iput-object p10, p0, Lbd1;->r:Ljd1;

    .line 23
    .line 24
    iput-object p11, p0, Lbd1;->s:Lj44;

    .line 25
    .line 26
    iput-object p12, p0, Lbd1;->t:Lj44;

    .line 27
    .line 28
    iput-object p13, p0, Lbd1;->u:Lj44;

    .line 29
    .line 30
    iput-object p14, p0, Lbd1;->v:Ljava/util/Map;

    .line 31
    .line 32
    iput-object p15, p0, Lbd1;->w:Lj44;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lbd1;->x:Lj44;

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 15

    .line 1
    iget-boolean v0, p0, Lbd1;->i:Z

    .line 2
    .line 3
    iget-object v3, p0, Lbd1;->r:Ljd1;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v10, p0, Lbd1;->j:Lme1;

    .line 8
    .line 9
    const/4 v11, 0x1

    .line 10
    iget-object v1, p0, Lbd1;->m:Ljava/util/List;

    .line 11
    .line 12
    iget-object v2, p0, Lbd1;->n:Lnf1;

    .line 13
    .line 14
    move-object v6, v3

    .line 15
    iget-object v3, p0, Lbd1;->o:Lj44;

    .line 16
    .line 17
    iget-object v4, p0, Lbd1;->p:Lj44;

    .line 18
    .line 19
    iget-object v5, p0, Lbd1;->q:Lj44;

    .line 20
    .line 21
    iget-object v7, p0, Lbd1;->s:Lj44;

    .line 22
    .line 23
    iget-object v8, p0, Lbd1;->t:Lj44;

    .line 24
    .line 25
    iget-object v9, p0, Lbd1;->u:Lj44;

    .line 26
    .line 27
    invoke-static/range {v1 .. v11}, Lko3;->T(Ljava/util/List;Lnf1;Lj44;Lj44;Lj44;Ljd1;Lj44;Lj44;Lj44;Lme1;Z)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    move-object v6, v3

    .line 32
    iget-boolean v0, p0, Lbd1;->k:Z

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    iget-object v12, p0, Lbd1;->p:Lj44;

    .line 37
    .line 38
    iget-object v7, p0, Lbd1;->j:Lme1;

    .line 39
    .line 40
    iget-object v8, p0, Lbd1;->o:Lj44;

    .line 41
    .line 42
    iget-object v9, p0, Lbd1;->s:Lj44;

    .line 43
    .line 44
    iget-object v10, p0, Lbd1;->q:Lj44;

    .line 45
    .line 46
    iget-object v11, p0, Lbd1;->t:Lj44;

    .line 47
    .line 48
    iget-object v13, p0, Lbd1;->m:Ljava/util/List;

    .line 49
    .line 50
    iget-object v14, p0, Lbd1;->v:Ljava/util/Map;

    .line 51
    .line 52
    invoke-static/range {v7 .. v14}, Lko3;->W(Lme1;Lj44;Lj44;Lj44;Lj44;Lj44;Ljava/util/List;Ljava/util/Map;)V

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    iget-object v10, p0, Lbd1;->l:Lle1;

    .line 57
    .line 58
    const/4 v11, 0x0

    .line 59
    iget-object v1, p0, Lbd1;->n:Lnf1;

    .line 60
    .line 61
    iget-object v2, p0, Lbd1;->o:Lj44;

    .line 62
    .line 63
    iget-object v4, p0, Lbd1;->s:Lj44;

    .line 64
    .line 65
    iget-object v5, p0, Lbd1;->q:Lj44;

    .line 66
    .line 67
    move-object v3, v6

    .line 68
    iget-object v6, p0, Lbd1;->t:Lj44;

    .line 69
    .line 70
    iget-object v7, p0, Lbd1;->p:Lj44;

    .line 71
    .line 72
    iget-object v8, p0, Lbd1;->w:Lj44;

    .line 73
    .line 74
    iget-object v9, p0, Lbd1;->x:Lj44;

    .line 75
    .line 76
    invoke-static/range {v1 .. v11}, Lko3;->S(Lnf1;Lj44;Ljd1;Lj44;Lj44;Lj44;Lj44;Lj44;Lj44;Lle1;Z)V

    .line 77
    .line 78
    .line 79
    :goto_0
    sget-object p0, Lxc7;->a:Lxc7;

    .line 80
    .line 81
    return-object p0
.end method
