.class public final Lap3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lg13;


# instance fields
.field public final a:Lu92;

.field public final b:Ljava/util/LinkedHashMap;

.field public final c:Lg52;


# direct methods
.method public constructor <init>(Lj34;Lu92;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lap3;->a:Lu92;

    .line 5
    .line 6
    new-instance p2, Ljava/util/LinkedHashMap;

    .line 7
    .line 8
    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p2, p0, Lap3;->b:Ljava/util/LinkedHashMap;

    .line 12
    .line 13
    iget-object p1, p1, Lj34;->a:Lxa6;

    .line 14
    .line 15
    new-instance p2, Lg52;

    .line 16
    .line 17
    const/4 v0, 0x3

    .line 18
    invoke-direct {p2, p1, p0, v0}, Lg52;-><init>(Lw42;Ljava/lang/Object;B)V

    .line 19
    .line 20
    .line 21
    iput-object p2, p0, Lap3;->c:Lg52;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final a()Lw42;
    .locals 0

    .line 1
    iget-object p0, p0, Lap3;->c:Lg52;

    .line 2
    .line 3
    return-object p0
.end method
