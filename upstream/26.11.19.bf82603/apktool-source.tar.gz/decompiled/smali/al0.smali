.class public final Lal0;
.super Lvr6;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public j:B

.field public final synthetic k:F

.field public l:Ljava/io/Serializable;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lrh6;FLfa2;Lo36;Lea1;)V
    .locals 1

    const/4 v0, 0x1

    iput-byte v0, p0, Lal0;->i:B

    .line 19
    iput-object p1, p0, Lal0;->m:Ljava/lang/Object;

    iput p2, p0, Lal0;->k:F

    iput-object p3, p0, Lal0;->n:Ljava/lang/Object;

    iput-object p4, p0, Lal0;->o:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lvr6;-><init>(ILea1;)V

    return-void
.end method

.method public constructor <init>(Ltj5;Lka2;Lzd7;FLpj5;Lea1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lal0;->i:B

    .line 3
    .line 4
    iput-object p1, p0, Lal0;->l:Ljava/io/Serializable;

    .line 5
    .line 6
    iput-object p2, p0, Lal0;->m:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lal0;->n:Ljava/lang/Object;

    .line 9
    .line 10
    iput p4, p0, Lal0;->k:F

    .line 11
    .line 12
    iput-object p5, p0, Lal0;->o:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 p1, 0x2

    .line 15
    invoke-direct {p0, p1, p6}, Lvr6;-><init>(ILea1;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lea1;)Lea1;
    .locals 11

    .line 1
    iget-byte p1, p0, Lal0;->i:B

    .line 2
    .line 3
    iget-object v0, p0, Lal0;->o:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v1, p0, Lal0;->n:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v2, p0, Lal0;->m:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch p1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    new-instance v3, Lal0;

    .line 13
    .line 14
    move-object v4, v2

    .line 15
    check-cast v4, Lrh6;

    .line 16
    .line 17
    move-object v6, v1

    .line 18
    check-cast v6, Lfa2;

    .line 19
    .line 20
    move-object v7, v0

    .line 21
    check-cast v7, Lo36;

    .line 22
    .line 23
    iget v5, p0, Lal0;->k:F

    .line 24
    .line 25
    move-object v8, p2

    .line 26
    invoke-direct/range {v3 .. v8}, Lal0;-><init>(Lrh6;FLfa2;Lo36;Lea1;)V

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :pswitch_0
    move-object v8, p2

    .line 31
    new-instance v4, Lal0;

    .line 32
    .line 33
    iget-object p1, p0, Lal0;->l:Ljava/io/Serializable;

    .line 34
    .line 35
    move-object v5, p1

    .line 36
    check-cast v5, Ltj5;

    .line 37
    .line 38
    move-object v6, v2

    .line 39
    check-cast v6, Lka2;

    .line 40
    .line 41
    move-object v7, v1

    .line 42
    check-cast v7, Lzd7;

    .line 43
    .line 44
    iget p0, p0, Lal0;->k:F

    .line 45
    .line 46
    move-object v9, v0

    .line 47
    check-cast v9, Lpj5;

    .line 48
    .line 49
    move-object v10, v8

    .line 50
    move v8, p0

    .line 51
    invoke-direct/range {v4 .. v10}, Lal0;-><init>(Ltj5;Lka2;Lzd7;FLpj5;Lea1;)V

    .line 52
    .line 53
    .line 54
    return-object v4

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget-byte v0, p0, Lal0;->i:B

    .line 2
    .line 3
    sget-object v1, Lxc7;->a:Lxc7;

    .line 4
    .line 5
    check-cast p1, Lnf1;

    .line 6
    .line 7
    check-cast p2, Lea1;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lal0;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lal0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lal0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Lal0;->create(Ljava/lang/Object;Lea1;)Lea1;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lal0;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lal0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 15

    .line 1
    iget-byte v0, p0, Lal0;->i:B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 5
    .line 6
    sget-object v7, Lof1;->i:Lof1;

    .line 7
    .line 8
    iget-object v3, p0, Lal0;->m:Ljava/lang/Object;

    .line 9
    .line 10
    iget v4, p0, Lal0;->k:F

    .line 11
    .line 12
    iget-object v6, p0, Lal0;->n:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 v8, 0x2

    .line 15
    iget-object v9, p0, Lal0;->o:Ljava/lang/Object;

    .line 16
    .line 17
    const/4 v10, 0x0

    .line 18
    const/4 v11, 0x1

    .line 19
    packed-switch v0, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    check-cast v6, Lfa2;

    .line 23
    .line 24
    move-object v0, v3

    .line 25
    check-cast v0, Lrh6;

    .line 26
    .line 27
    iget-object v12, v0, Lrh6;->a:Luh6;

    .line 28
    .line 29
    iget-byte v3, p0, Lal0;->j:B

    .line 30
    .line 31
    const/4 v13, 0x0

    .line 32
    if-eqz v3, :cond_2

    .line 33
    .line 34
    if-eq v3, v11, :cond_1

    .line 35
    .line 36
    if-ne v3, v8, :cond_0

    .line 37
    .line 38
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    move-object/from16 v0, p1

    .line 42
    .line 43
    goto/16 :goto_1

    .line 44
    .line 45
    :cond_0
    invoke-static {v2}, La02;->d(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    move-object v0, v10

    .line 49
    goto/16 :goto_1

    .line 50
    .line 51
    :cond_1
    iget-object v1, p0, Lal0;->l:Ljava/io/Serializable;

    .line 52
    .line 53
    check-cast v1, Lqj5;

    .line 54
    .line 55
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    move-object v14, v1

    .line 59
    move-object/from16 v1, p1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    iget-object v2, v0, Lrh6;->b:Lii1;

    .line 66
    .line 67
    invoke-static {v2, v13, v4}, Luj;->A(Lii1;FF)F

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    invoke-interface {v12, v4, v2}, Luh6;->c(FF)F

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    if-eqz v3, :cond_3

    .line 80
    .line 81
    const-string v3, "calculateApproachOffset returned NaN. Please use a valid value."

    .line 82
    .line 83
    invoke-static {v3}, Loy2;->c(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    :cond_3
    new-instance v14, Lqj5;

    .line 87
    .line 88
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 89
    .line 90
    .line 91
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 92
    .line 93
    .line 94
    move-result v2

    .line 95
    invoke-static {v4}, Ljava/lang/Math;->signum(F)F

    .line 96
    .line 97
    .line 98
    move-result v3

    .line 99
    mul-float/2addr v3, v2

    .line 100
    iput v3, v14, Lqj5;->i:F

    .line 101
    .line 102
    new-instance v2, Ljava/lang/Float;

    .line 103
    .line 104
    invoke-direct {v2, v3}, Ljava/lang/Float;-><init>(F)V

    .line 105
    .line 106
    .line 107
    invoke-interface {v6, v2}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-object v2, v9

    .line 111
    check-cast v2, Lo36;

    .line 112
    .line 113
    move-object v3, v2

    .line 114
    iget v2, v14, Lqj5;->i:F

    .line 115
    .line 116
    new-instance v4, Loh6;

    .line 117
    .line 118
    invoke-direct {v4, v14, v6, v1}, Loh6;-><init>(Lqj5;Lfa2;B)V

    .line 119
    .line 120
    .line 121
    iput-object v14, p0, Lal0;->l:Ljava/io/Serializable;

    .line 122
    .line 123
    iput-byte v11, p0, Lal0;->j:B

    .line 124
    .line 125
    move-object v1, v3

    .line 126
    iget v3, p0, Lal0;->k:F

    .line 127
    .line 128
    move-object v5, p0

    .line 129
    invoke-virtual/range {v0 .. v5}, Lrh6;->d(Lo36;FFLoh6;Lfa1;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v1

    .line 133
    if-eq v1, v7, :cond_5

    .line 134
    .line 135
    :goto_0
    check-cast v1, Ldi;

    .line 136
    .line 137
    invoke-virtual {v1}, Ldi;->a()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    check-cast v2, Ljava/lang/Number;

    .line 142
    .line 143
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    invoke-interface {v12, v2}, Luh6;->g(F)F

    .line 148
    .line 149
    .line 150
    move-result v2

    .line 151
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 152
    .line 153
    .line 154
    move-result v3

    .line 155
    if-eqz v3, :cond_4

    .line 156
    .line 157
    const-string v3, "calculateSnapOffset returned NaN. Please use a valid value."

    .line 158
    .line 159
    invoke-static {v3}, Loy2;->c(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    :cond_4
    iput v2, v14, Lqj5;->i:F

    .line 163
    .line 164
    check-cast v9, Lo36;

    .line 165
    .line 166
    const/16 v3, 0x1e

    .line 167
    .line 168
    invoke-static {v1, v13, v13, v3}, Lla7;->A(Ldi;FFI)Ldi;

    .line 169
    .line 170
    .line 171
    move-result-object v3

    .line 172
    iget-object v4, v0, Lrh6;->c:Lci;

    .line 173
    .line 174
    new-instance v0, Loh6;

    .line 175
    .line 176
    invoke-direct {v0, v14, v6, v11}, Loh6;-><init>(Lqj5;Lfa2;B)V

    .line 177
    .line 178
    .line 179
    iput-object v10, p0, Lal0;->l:Ljava/io/Serializable;

    .line 180
    .line 181
    iput-byte v8, p0, Lal0;->j:B

    .line 182
    .line 183
    move v1, v2

    .line 184
    move-object v6, p0

    .line 185
    move-object v5, v0

    .line 186
    move-object v0, v9

    .line 187
    invoke-static/range {v0 .. v6}, Ln93;->F(Lo36;FFLdi;Lci;Lfa2;Lfa1;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    if-ne v0, v7, :cond_6

    .line 192
    .line 193
    :cond_5
    move-object v0, v7

    .line 194
    :cond_6
    :goto_1
    return-object v0

    .line 195
    :pswitch_0
    iget-byte v0, p0, Lal0;->j:B

    .line 196
    .line 197
    if-eqz v0, :cond_9

    .line 198
    .line 199
    if-eq v0, v11, :cond_8

    .line 200
    .line 201
    if-ne v0, v8, :cond_7

    .line 202
    .line 203
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    goto :goto_3

    .line 207
    :cond_7
    invoke-static {v2}, La02;->d(Ljava/lang/String;)V

    .line 208
    .line 209
    .line 210
    move-object v7, v10

    .line 211
    goto :goto_4

    .line 212
    :cond_8
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    move-object/from16 v0, p1

    .line 216
    .line 217
    goto :goto_2

    .line 218
    :cond_9
    invoke-static/range {p1 .. p1}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    iget-object v0, p0, Lal0;->l:Ljava/io/Serializable;

    .line 222
    .line 223
    check-cast v0, Ltj5;

    .line 224
    .line 225
    iget-object v0, v0, Ltj5;->i:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Ls33;

    .line 228
    .line 229
    if-eqz v0, :cond_a

    .line 230
    .line 231
    iput-byte v11, p0, Lal0;->j:B

    .line 232
    .line 233
    invoke-static {v0, p0}, Lnn;->m(Ls33;Lvr6;)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    if-eq v0, v7, :cond_b

    .line 238
    .line 239
    :goto_2
    check-cast v0, Lxc7;

    .line 240
    .line 241
    :cond_a
    check-cast v3, Lka2;

    .line 242
    .line 243
    check-cast v6, Lzd7;

    .line 244
    .line 245
    new-instance v0, Ljava/lang/Float;

    .line 246
    .line 247
    invoke-direct {v0, v4}, Ljava/lang/Float;-><init>(F)V

    .line 248
    .line 249
    .line 250
    iput-byte v8, p0, Lal0;->j:B

    .line 251
    .line 252
    invoke-interface {v3, v6, v0, p0}, Lka2;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    if-eq v0, v7, :cond_b

    .line 257
    .line 258
    :goto_3
    check-cast v9, Lpj5;

    .line 259
    .line 260
    iput-boolean v1, v9, Lpj5;->i:Z

    .line 261
    .line 262
    sget-object v7, Lxc7;->a:Lxc7;

    .line 263
    .line 264
    :cond_b
    :goto_4
    return-object v7

    .line 265
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
