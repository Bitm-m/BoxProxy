.class public final synthetic Lbd5;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lla2;


# instance fields
.field public final synthetic A:Lj44;

.field public final synthetic i:Lxt4;

.field public final synthetic j:I

.field public final synthetic k:Lg95;

.field public final synthetic l:Z

.field public final synthetic m:Lqd5;

.field public final synthetic n:Lud5;

.field public final synthetic o:Ljava/util/Map;

.field public final synthetic p:Ljava/util/Map;

.field public final synthetic q:Ljava/util/Map;

.field public final synthetic r:Ljava/util/Set;

.field public final synthetic s:Ljava/util/Map;

.field public final synthetic t:Ljava/util/Set;

.field public final synthetic u:Lfa2;

.field public final synthetic v:Lfa2;

.field public final synthetic w:Lfa2;

.field public final synthetic x:Lja2;

.field public final synthetic y:Lfa2;

.field public final synthetic z:Lce5;


# direct methods
.method public synthetic constructor <init>(Lxt4;ILg95;ZLqd5;Lud5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Set;Lfa2;Lfa2;Lfa2;Lja2;Lfa2;Lce5;Lj44;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbd5;->i:Lxt4;

    .line 5
    .line 6
    iput p2, p0, Lbd5;->j:I

    .line 7
    .line 8
    iput-object p3, p0, Lbd5;->k:Lg95;

    .line 9
    .line 10
    iput-boolean p4, p0, Lbd5;->l:Z

    .line 11
    .line 12
    iput-object p5, p0, Lbd5;->m:Lqd5;

    .line 13
    .line 14
    iput-object p6, p0, Lbd5;->n:Lud5;

    .line 15
    .line 16
    iput-object p7, p0, Lbd5;->o:Ljava/util/Map;

    .line 17
    .line 18
    iput-object p8, p0, Lbd5;->p:Ljava/util/Map;

    .line 19
    .line 20
    iput-object p9, p0, Lbd5;->q:Ljava/util/Map;

    .line 21
    .line 22
    iput-object p10, p0, Lbd5;->r:Ljava/util/Set;

    .line 23
    .line 24
    iput-object p11, p0, Lbd5;->s:Ljava/util/Map;

    .line 25
    .line 26
    iput-object p12, p0, Lbd5;->t:Ljava/util/Set;

    .line 27
    .line 28
    iput-object p13, p0, Lbd5;->u:Lfa2;

    .line 29
    .line 30
    iput-object p14, p0, Lbd5;->v:Lfa2;

    .line 31
    .line 32
    iput-object p15, p0, Lbd5;->w:Lfa2;

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lbd5;->x:Lja2;

    .line 37
    .line 38
    move-object/from16 p1, p17

    .line 39
    .line 40
    iput-object p1, p0, Lbd5;->y:Lfa2;

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lbd5;->z:Lce5;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, Lbd5;->A:Lj44;

    .line 49
    .line 50
    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lah;

    .line 6
    .line 7
    move-object/from16 v4, p2

    .line 8
    .line 9
    check-cast v4, Lce5;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Lib2;

    .line 14
    .line 15
    move-object/from16 v3, p4

    .line 16
    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    and-int/lit8 v1, v3, 0x30

    .line 30
    .line 31
    if-nez v1, :cond_2

    .line 32
    .line 33
    and-int/lit8 v1, v3, 0x40

    .line 34
    .line 35
    if-nez v1, :cond_0

    .line 36
    .line 37
    invoke-virtual {v2, v4}, Lib2;->g(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    invoke-virtual {v2, v4}, Lib2;->i(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    :goto_0
    if-eqz v1, :cond_1

    .line 47
    .line 48
    const/16 v1, 0x20

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    const/16 v1, 0x10

    .line 52
    .line 53
    :goto_1
    or-int/2addr v3, v1

    .line 54
    :cond_2
    and-int/lit16 v1, v3, 0x91

    .line 55
    .line 56
    const/16 v5, 0x90

    .line 57
    .line 58
    if-eq v1, v5, :cond_3

    .line 59
    .line 60
    const/4 v1, 0x1

    .line 61
    goto :goto_2

    .line 62
    :cond_3
    const/4 v1, 0x0

    .line 63
    :goto_2
    and-int/lit8 v5, v3, 0x1

    .line 64
    .line 65
    invoke-virtual {v2, v5, v1}, Lib2;->X(IZ)Z

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    move-object/from16 v22, v2

    .line 70
    .line 71
    if-eqz v1, :cond_4

    .line 72
    .line 73
    new-instance v2, Lsw3;

    .line 74
    .line 75
    iget-object v1, v0, Lbd5;->i:Lxt4;

    .line 76
    .line 77
    const/4 v5, 0x0

    .line 78
    const/high16 v6, 0x41800000    # 16.0f

    .line 79
    .line 80
    invoke-direct {v2, v1, v5, v6}, Lsw3;-><init>(Lxt4;FF)V

    .line 81
    .line 82
    .line 83
    iget-object v1, v0, Lbd5;->A:Lj44;

    .line 84
    .line 85
    invoke-interface {v1}, Lnl6;->getValue()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    check-cast v1, Ljava/lang/String;

    .line 90
    .line 91
    iget-object v5, v4, Lce5;->a:Ljava/lang/String;

    .line 92
    .line 93
    iget-object v6, v0, Lbd5;->z:Lce5;

    .line 94
    .line 95
    iget-object v6, v6, Lce5;->a:Ljava/lang/String;

    .line 96
    .line 97
    invoke-virtual {v5, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v21

    .line 101
    shl-int/lit8 v3, v3, 0x3

    .line 102
    .line 103
    and-int/lit16 v3, v3, 0x380

    .line 104
    .line 105
    iget v5, v0, Lbd5;->j:I

    .line 106
    .line 107
    iget-object v6, v0, Lbd5;->k:Lg95;

    .line 108
    .line 109
    iget-boolean v7, v0, Lbd5;->l:Z

    .line 110
    .line 111
    iget-object v8, v0, Lbd5;->m:Lqd5;

    .line 112
    .line 113
    iget-object v9, v0, Lbd5;->n:Lud5;

    .line 114
    .line 115
    iget-object v10, v0, Lbd5;->o:Ljava/util/Map;

    .line 116
    .line 117
    iget-object v11, v0, Lbd5;->p:Ljava/util/Map;

    .line 118
    .line 119
    iget-object v12, v0, Lbd5;->q:Ljava/util/Map;

    .line 120
    .line 121
    iget-object v13, v0, Lbd5;->r:Ljava/util/Set;

    .line 122
    .line 123
    iget-object v14, v0, Lbd5;->s:Ljava/util/Map;

    .line 124
    .line 125
    iget-object v15, v0, Lbd5;->t:Ljava/util/Set;

    .line 126
    .line 127
    move-object/from16 p1, v1

    .line 128
    .line 129
    iget-object v1, v0, Lbd5;->u:Lfa2;

    .line 130
    .line 131
    move-object/from16 v16, v1

    .line 132
    .line 133
    iget-object v1, v0, Lbd5;->v:Lfa2;

    .line 134
    .line 135
    move-object/from16 v17, v1

    .line 136
    .line 137
    iget-object v1, v0, Lbd5;->w:Lfa2;

    .line 138
    .line 139
    move-object/from16 v18, v1

    .line 140
    .line 141
    iget-object v1, v0, Lbd5;->x:Lja2;

    .line 142
    .line 143
    iget-object v0, v0, Lbd5;->y:Lfa2;

    .line 144
    .line 145
    move-object/from16 v20, v0

    .line 146
    .line 147
    move-object/from16 v19, v1

    .line 148
    .line 149
    move/from16 v23, v3

    .line 150
    .line 151
    move-object/from16 v3, p1

    .line 152
    .line 153
    invoke-static/range {v2 .. v23}, Ll46;->j(Lsw3;Ljava/lang/String;Lce5;ILg95;ZLqd5;Lud5;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Ljava/util/Map;Ljava/util/Set;Lfa2;Lfa2;Lfa2;Lja2;Lfa2;ZLib2;I)V

    .line 154
    .line 155
    .line 156
    goto :goto_3

    .line 157
    :cond_4
    invoke-virtual/range {v22 .. v22}, Lib2;->a0()V

    .line 158
    .line 159
    .line 160
    :goto_3
    sget-object v0, Lxc7;->a:Lxc7;

    .line 161
    .line 162
    return-object v0
.end method
