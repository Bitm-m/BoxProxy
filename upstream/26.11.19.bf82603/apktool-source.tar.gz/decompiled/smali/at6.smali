.class final Lat6;
.super Lf14;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lf14;"
    }
.end annotation


# instance fields
.field public final i:Lfa2;


# direct methods
.method public constructor <init>(Lfa2;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lat6;->i:Lfa2;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Lv04;
    .locals 2

    .line 1
    new-instance v0, Lbt6;

    .line 2
    .line 3
    sget-object v1, Lm71;->F0:Li32;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lpz2;-><init>(Ltk7;)V

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Lat6;->i:Lfa2;

    .line 9
    .line 10
    iput-object p0, v0, Lbt6;->z:Lfa2;

    .line 11
    .line 12
    return-object v0
.end method

.method public final b(Lv04;)V
    .locals 1

    .line 1
    check-cast p1, Lbt6;

    .line 2
    .line 3
    iget-object v0, p1, Lbt6;->z:Lfa2;

    .line 4
    .line 5
    iget-object p0, p0, Lat6;->i:Lfa2;

    .line 6
    .line 7
    if-eq v0, p0, :cond_0

    .line 8
    .line 9
    iput-object p0, p1, Lbt6;->z:Lfa2;

    .line 10
    .line 11
    iget-object v0, p1, Lbt6;->A:Lam7;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-interface {p0, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Ltk7;

    .line 20
    .line 21
    iget-object v0, p1, Lpz2;->y:Ltk7;

    .line 22
    .line 23
    invoke-static {p0, v0}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_0

    .line 28
    .line 29
    iput-object p0, p1, Lpz2;->y:Ltk7;

    .line 30
    .line 31
    invoke-virtual {p1}, Lpz2;->G1()V

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-eq p0, p1, :cond_0

    .line 2
    .line 3
    instance-of v0, p1, Lat6;

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    check-cast p1, Lat6;

    .line 8
    .line 9
    iget-object p1, p1, Lat6;->i:Lfa2;

    .line 10
    .line 11
    iget-object p0, p0, Lat6;->i:Lfa2;

    .line 12
    .line 13
    if-ne p0, p1, :cond_1

    .line 14
    .line 15
    :cond_0
    const/4 p0, 0x1

    .line 16
    return p0

    .line 17
    :cond_1
    const/4 p0, 0x0

    .line 18
    return p0
.end method

.method public final hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lat6;->i:Lfa2;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
