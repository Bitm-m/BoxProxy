.class public final synthetic Lb01;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lb01;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 38

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Lb01;->i:B

    .line 4
    .line 5
    const/high16 v1, 0x41200000    # 10.0f

    .line 6
    .line 7
    sget-object v2, Ls47;->j:Ls47;

    .line 8
    .line 9
    const/high16 v3, 0x41900000    # 18.0f

    .line 10
    .line 11
    const v4, 0x7f0f003a

    .line 12
    .line 13
    .line 14
    const/high16 v5, 0x3f800000    # 1.0f

    .line 15
    .line 16
    const/16 v6, 0x12

    .line 17
    .line 18
    const v8, 0x7f0f0229

    .line 19
    .line 20
    .line 21
    sget-object v9, Lcy1;->i:Lcy1;

    .line 22
    .line 23
    sget-object v10, Lt04;->i:Lt04;

    .line 24
    .line 25
    const/4 v11, 0x2

    .line 26
    sget-object v12, Lg21;->a:Ley0;

    .line 27
    .line 28
    const/16 v13, 0x10

    .line 29
    .line 30
    sget-object v14, Lxc7;->a:Lxc7;

    .line 31
    .line 32
    const/4 v15, 0x1

    .line 33
    const/4 v7, 0x0

    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    move-object/from16 v0, p1

    .line 38
    .line 39
    check-cast v0, Lbc3;

    .line 40
    .line 41
    move-object/from16 v1, p2

    .line 42
    .line 43
    check-cast v1, Lib2;

    .line 44
    .line 45
    move-object/from16 v2, p3

    .line 46
    .line 47
    check-cast v2, Ljava/lang/Integer;

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    and-int/lit8 v0, v2, 0x11

    .line 57
    .line 58
    if-eq v0, v13, :cond_0

    .line 59
    .line 60
    move v7, v15

    .line 61
    :cond_0
    and-int/2addr v2, v15

    .line 62
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-eqz v0, :cond_1

    .line 67
    .line 68
    invoke-static {v8, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v16

    .line 72
    const/16 v22, 0x0

    .line 73
    .line 74
    const/16 v23, 0x1e

    .line 75
    .line 76
    const/16 v17, 0x0

    .line 77
    .line 78
    const/16 v18, 0x0

    .line 79
    .line 80
    const/16 v19, 0x0

    .line 81
    .line 82
    const/16 v20, 0x0

    .line 83
    .line 84
    move-object/from16 v21, v1

    .line 85
    .line 86
    invoke-static/range {v16 .. v23}, Lu93;->d(Ljava/lang/String;Lw04;Ljava/lang/String;Ltj0;Lyz0;Lib2;II)V

    .line 87
    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_1
    move-object/from16 v21, v1

    .line 91
    .line 92
    invoke-virtual/range {v21 .. v21}, Lib2;->a0()V

    .line 93
    .line 94
    .line 95
    :goto_0
    return-object v14

    .line 96
    :pswitch_0
    move-object/from16 v0, p1

    .line 97
    .line 98
    check-cast v0, Lvx0;

    .line 99
    .line 100
    move-object/from16 v1, p2

    .line 101
    .line 102
    check-cast v1, Lib2;

    .line 103
    .line 104
    move-object/from16 v2, p3

    .line 105
    .line 106
    check-cast v2, Ljava/lang/Integer;

    .line 107
    .line 108
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    and-int/lit8 v0, v2, 0x11

    .line 116
    .line 117
    if-eq v0, v13, :cond_2

    .line 118
    .line 119
    move v7, v15

    .line 120
    :cond_2
    and-int/2addr v2, v15

    .line 121
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-nez v0, :cond_3

    .line 126
    .line 127
    invoke-virtual {v1}, Lib2;->a0()V

    .line 128
    .line 129
    .line 130
    :cond_3
    return-object v14

    .line 131
    :pswitch_1
    move-object/from16 v0, p1

    .line 132
    .line 133
    check-cast v0, Lbc3;

    .line 134
    .line 135
    move-object/from16 v1, p2

    .line 136
    .line 137
    check-cast v1, Lib2;

    .line 138
    .line 139
    move-object/from16 v2, p3

    .line 140
    .line 141
    check-cast v2, Ljava/lang/Integer;

    .line 142
    .line 143
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 144
    .line 145
    .line 146
    move-result v2

    .line 147
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 148
    .line 149
    .line 150
    and-int/lit8 v0, v2, 0x11

    .line 151
    .line 152
    if-eq v0, v13, :cond_4

    .line 153
    .line 154
    move v7, v15

    .line 155
    :cond_4
    and-int/2addr v2, v15

    .line 156
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    if-eqz v0, :cond_5

    .line 161
    .line 162
    invoke-static {v8, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v16

    .line 166
    const/16 v21, 0x0

    .line 167
    .line 168
    const/16 v22, 0xe

    .line 169
    .line 170
    const/16 v17, 0x0

    .line 171
    .line 172
    const/16 v18, 0x0

    .line 173
    .line 174
    const/16 v19, 0x0

    .line 175
    .line 176
    move-object/from16 v20, v1

    .line 177
    .line 178
    invoke-static/range {v16 .. v22}, Lvq3;->a(Ljava/lang/String;Lw04;Ljava/lang/String;Lyz0;Lib2;II)V

    .line 179
    .line 180
    .line 181
    goto :goto_1

    .line 182
    :cond_5
    move-object/from16 v20, v1

    .line 183
    .line 184
    invoke-virtual/range {v20 .. v20}, Lib2;->a0()V

    .line 185
    .line 186
    .line 187
    :goto_1
    return-object v14

    .line 188
    :pswitch_2
    move-object/from16 v0, p1

    .line 189
    .line 190
    check-cast v0, Lwc0;

    .line 191
    .line 192
    move-object/from16 v1, p2

    .line 193
    .line 194
    check-cast v1, Lib2;

    .line 195
    .line 196
    move-object/from16 v2, p3

    .line 197
    .line 198
    check-cast v2, Ljava/lang/Integer;

    .line 199
    .line 200
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 201
    .line 202
    .line 203
    move-result v2

    .line 204
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 205
    .line 206
    .line 207
    and-int/lit8 v0, v2, 0x11

    .line 208
    .line 209
    if-eq v0, v13, :cond_6

    .line 210
    .line 211
    move v7, v15

    .line 212
    :cond_6
    and-int/2addr v2, v15

    .line 213
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    if-nez v0, :cond_7

    .line 218
    .line 219
    invoke-virtual {v1}, Lib2;->a0()V

    .line 220
    .line 221
    .line 222
    :cond_7
    return-object v14

    .line 223
    :pswitch_3
    move-object/from16 v0, p1

    .line 224
    .line 225
    check-cast v0, Lja2;

    .line 226
    .line 227
    move-object/from16 v1, p2

    .line 228
    .line 229
    check-cast v1, Lib2;

    .line 230
    .line 231
    move-object/from16 v2, p3

    .line 232
    .line 233
    check-cast v2, Ljava/lang/Integer;

    .line 234
    .line 235
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 236
    .line 237
    .line 238
    move-result v2

    .line 239
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 240
    .line 241
    .line 242
    and-int/lit8 v3, v2, 0x6

    .line 243
    .line 244
    if-nez v3, :cond_9

    .line 245
    .line 246
    invoke-virtual {v1, v0}, Lib2;->i(Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    if-eqz v3, :cond_8

    .line 251
    .line 252
    const/4 v11, 0x4

    .line 253
    :cond_8
    or-int/2addr v2, v11

    .line 254
    :cond_9
    and-int/lit8 v3, v2, 0x13

    .line 255
    .line 256
    if-eq v3, v6, :cond_a

    .line 257
    .line 258
    move v3, v15

    .line 259
    goto :goto_2

    .line 260
    :cond_a
    move v3, v7

    .line 261
    :goto_2
    and-int/2addr v2, v15

    .line 262
    invoke-virtual {v1, v2, v3}, Lib2;->X(IZ)Z

    .line 263
    .line 264
    .line 265
    move-result v2

    .line 266
    if-eqz v2, :cond_b

    .line 267
    .line 268
    new-instance v2, Lc01;

    .line 269
    .line 270
    invoke-direct {v2, v0, v7}, Lc01;-><init>(Lja2;B)V

    .line 271
    .line 272
    .line 273
    const v0, 0x50dc46ea

    .line 274
    .line 275
    .line 276
    invoke-static {v0, v2, v1}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    const/4 v2, 0x6

    .line 281
    invoke-static {v0, v1, v2}, Lbb3;->f(Lyz0;Lib2;I)V

    .line 282
    .line 283
    .line 284
    goto :goto_3

    .line 285
    :cond_b
    invoke-virtual {v1}, Lib2;->a0()V

    .line 286
    .line 287
    .line 288
    :goto_3
    return-object v14

    .line 289
    :pswitch_4
    move-object/from16 v0, p1

    .line 290
    .line 291
    check-cast v0, Lnp5;

    .line 292
    .line 293
    move-object/from16 v1, p2

    .line 294
    .line 295
    check-cast v1, Lib2;

    .line 296
    .line 297
    move-object/from16 v2, p3

    .line 298
    .line 299
    check-cast v2, Ljava/lang/Integer;

    .line 300
    .line 301
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 302
    .line 303
    .line 304
    move-result v2

    .line 305
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 306
    .line 307
    .line 308
    and-int/lit8 v0, v2, 0x11

    .line 309
    .line 310
    if-eq v0, v13, :cond_c

    .line 311
    .line 312
    move v7, v15

    .line 313
    :cond_c
    and-int/2addr v2, v15

    .line 314
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 315
    .line 316
    .line 317
    move-result v0

    .line 318
    if-nez v0, :cond_d

    .line 319
    .line 320
    invoke-virtual {v1}, Lib2;->a0()V

    .line 321
    .line 322
    .line 323
    :cond_d
    return-object v14

    .line 324
    :pswitch_5
    move-object/from16 v0, p1

    .line 325
    .line 326
    check-cast v0, Lbc3;

    .line 327
    .line 328
    move-object/from16 v1, p2

    .line 329
    .line 330
    check-cast v1, Lib2;

    .line 331
    .line 332
    move-object/from16 v2, p3

    .line 333
    .line 334
    check-cast v2, Ljava/lang/Integer;

    .line 335
    .line 336
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 337
    .line 338
    .line 339
    move-result v2

    .line 340
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    .line 342
    .line 343
    and-int/lit8 v0, v2, 0x11

    .line 344
    .line 345
    if-eq v0, v13, :cond_e

    .line 346
    .line 347
    move v7, v15

    .line 348
    :cond_e
    and-int/2addr v2, v15

    .line 349
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 350
    .line 351
    .line 352
    move-result v0

    .line 353
    if-eqz v0, :cond_f

    .line 354
    .line 355
    invoke-static {v10, v5}, Lag6;->e(Lw04;F)Lw04;

    .line 356
    .line 357
    .line 358
    move-result-object v0

    .line 359
    sget v2, Lvj0;->a:I

    .line 360
    .line 361
    sget-object v2, Lbx0;->a:Lnt1;

    .line 362
    .line 363
    invoke-virtual {v1, v2}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 364
    .line 365
    .line 366
    move-result-object v3

    .line 367
    check-cast v3, Lax0;

    .line 368
    .line 369
    invoke-virtual {v3}, Lax0;->t()J

    .line 370
    .line 371
    .line 372
    move-result-wide v16

    .line 373
    invoke-virtual {v1, v2}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    move-result-object v2

    .line 377
    check-cast v2, Lax0;

    .line 378
    .line 379
    invoke-virtual {v2}, Lax0;->j()J

    .line 380
    .line 381
    .line 382
    move-result-wide v18

    .line 383
    const/16 v21, 0x180

    .line 384
    .line 385
    const/16 v22, 0x0

    .line 386
    .line 387
    move-object/from16 v20, v1

    .line 388
    .line 389
    invoke-static/range {v16 .. v22}, Lvj0;->a(JJLib2;II)Ltj0;

    .line 390
    .line 391
    .line 392
    move-result-object v19

    .line 393
    sget-object v25, Lhr3;->m:Lyz0;

    .line 394
    .line 395
    const/16 v27, 0x6

    .line 396
    .line 397
    const/16 v28, 0x3f6

    .line 398
    .line 399
    const/16 v17, 0x0

    .line 400
    .line 401
    const/16 v18, 0x0

    .line 402
    .line 403
    move-object/from16 v26, v20

    .line 404
    .line 405
    const/16 v20, 0x0

    .line 406
    .line 407
    const/16 v21, 0x0

    .line 408
    .line 409
    const/16 v22, 0x0

    .line 410
    .line 411
    const/16 v23, 0x0

    .line 412
    .line 413
    const/16 v24, 0x0

    .line 414
    .line 415
    move-object/from16 v16, v0

    .line 416
    .line 417
    invoke-static/range {v16 .. v28}, Ltw3;->a(Lw04;FLzt4;Ltj0;Lb45;ZLu92;Lu92;ZLyz0;Lib2;II)V

    .line 418
    .line 419
    .line 420
    goto :goto_4

    .line 421
    :cond_f
    move-object/from16 v20, v1

    .line 422
    .line 423
    invoke-virtual/range {v20 .. v20}, Lib2;->a0()V

    .line 424
    .line 425
    .line 426
    :goto_4
    return-object v14

    .line 427
    :pswitch_6
    move-object/from16 v0, p1

    .line 428
    .line 429
    check-cast v0, Lvx0;

    .line 430
    .line 431
    move-object/from16 v1, p2

    .line 432
    .line 433
    check-cast v1, Lib2;

    .line 434
    .line 435
    move-object/from16 v2, p3

    .line 436
    .line 437
    check-cast v2, Ljava/lang/Integer;

    .line 438
    .line 439
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 440
    .line 441
    .line 442
    move-result v2

    .line 443
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 444
    .line 445
    .line 446
    and-int/lit8 v0, v2, 0x11

    .line 447
    .line 448
    if-eq v0, v13, :cond_10

    .line 449
    .line 450
    move v7, v15

    .line 451
    :cond_10
    and-int/2addr v2, v15

    .line 452
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 453
    .line 454
    .line 455
    move-result v0

    .line 456
    if-eqz v0, :cond_11

    .line 457
    .line 458
    invoke-static {v4, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 459
    .line 460
    .line 461
    move-result-object v16

    .line 462
    const/high16 v0, 0x41800000    # 16.0f

    .line 463
    .line 464
    invoke-static {v10, v3, v0}, Lm71;->B(Lw04;FF)Lw04;

    .line 465
    .line 466
    .line 467
    move-result-object v17

    .line 468
    sget-object v0, Lbx0;->a:Lnt1;

    .line 469
    .line 470
    invoke-virtual {v1, v0}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    check-cast v0, Lax0;

    .line 475
    .line 476
    invoke-virtual {v0}, Lax0;->n()J

    .line 477
    .line 478
    .line 479
    move-result-wide v18

    .line 480
    const/16 v36, 0x0

    .line 481
    .line 482
    const v37, 0x3fff8

    .line 483
    .line 484
    .line 485
    const-wide/16 v20, 0x0

    .line 486
    .line 487
    const/16 v22, 0x0

    .line 488
    .line 489
    const/16 v23, 0x0

    .line 490
    .line 491
    const-wide/16 v24, 0x0

    .line 492
    .line 493
    const/16 v26, 0x0

    .line 494
    .line 495
    const-wide/16 v27, 0x0

    .line 496
    .line 497
    const/16 v29, 0x0

    .line 498
    .line 499
    const/16 v30, 0x0

    .line 500
    .line 501
    const/16 v31, 0x0

    .line 502
    .line 503
    const/16 v32, 0x0

    .line 504
    .line 505
    const/16 v33, 0x0

    .line 506
    .line 507
    const/16 v35, 0x30

    .line 508
    .line 509
    move-object/from16 v34, v1

    .line 510
    .line 511
    invoke-static/range {v16 .. v37}, Lyq6;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 512
    .line 513
    .line 514
    goto :goto_5

    .line 515
    :cond_11
    move-object/from16 v34, v1

    .line 516
    .line 517
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 518
    .line 519
    .line 520
    :goto_5
    return-object v14

    .line 521
    :pswitch_7
    move-object/from16 v0, p1

    .line 522
    .line 523
    check-cast v0, Lnp5;

    .line 524
    .line 525
    move-object/from16 v1, p2

    .line 526
    .line 527
    check-cast v1, Lib2;

    .line 528
    .line 529
    move-object/from16 v2, p3

    .line 530
    .line 531
    check-cast v2, Ljava/lang/Integer;

    .line 532
    .line 533
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 534
    .line 535
    .line 536
    move-result v2

    .line 537
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 538
    .line 539
    .line 540
    and-int/lit8 v0, v2, 0x11

    .line 541
    .line 542
    if-eq v0, v13, :cond_12

    .line 543
    .line 544
    move v7, v15

    .line 545
    :cond_12
    and-int/2addr v2, v15

    .line 546
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 547
    .line 548
    .line 549
    move-result v0

    .line 550
    if-eqz v0, :cond_13

    .line 551
    .line 552
    const v0, 0x7f0f004e

    .line 553
    .line 554
    .line 555
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 556
    .line 557
    .line 558
    move-result-object v16

    .line 559
    const/16 v36, 0x0

    .line 560
    .line 561
    const v37, 0x3fffe

    .line 562
    .line 563
    .line 564
    const/16 v17, 0x0

    .line 565
    .line 566
    const-wide/16 v18, 0x0

    .line 567
    .line 568
    const-wide/16 v20, 0x0

    .line 569
    .line 570
    const/16 v22, 0x0

    .line 571
    .line 572
    const/16 v23, 0x0

    .line 573
    .line 574
    const-wide/16 v24, 0x0

    .line 575
    .line 576
    const/16 v26, 0x0

    .line 577
    .line 578
    const-wide/16 v27, 0x0

    .line 579
    .line 580
    const/16 v29, 0x0

    .line 581
    .line 582
    const/16 v30, 0x0

    .line 583
    .line 584
    const/16 v31, 0x0

    .line 585
    .line 586
    const/16 v32, 0x0

    .line 587
    .line 588
    const/16 v33, 0x0

    .line 589
    .line 590
    const/16 v35, 0x0

    .line 591
    .line 592
    move-object/from16 v34, v1

    .line 593
    .line 594
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 595
    .line 596
    .line 597
    goto :goto_6

    .line 598
    :cond_13
    move-object/from16 v34, v1

    .line 599
    .line 600
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 601
    .line 602
    .line 603
    :goto_6
    return-object v14

    .line 604
    :pswitch_8
    move-object/from16 v0, p1

    .line 605
    .line 606
    check-cast v0, Lnp5;

    .line 607
    .line 608
    move-object/from16 v1, p2

    .line 609
    .line 610
    check-cast v1, Lib2;

    .line 611
    .line 612
    move-object/from16 v2, p3

    .line 613
    .line 614
    check-cast v2, Ljava/lang/Integer;

    .line 615
    .line 616
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 617
    .line 618
    .line 619
    move-result v2

    .line 620
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 621
    .line 622
    .line 623
    and-int/lit8 v0, v2, 0x11

    .line 624
    .line 625
    if-eq v0, v13, :cond_14

    .line 626
    .line 627
    move v7, v15

    .line 628
    :cond_14
    and-int/2addr v2, v15

    .line 629
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 630
    .line 631
    .line 632
    move-result v0

    .line 633
    if-eqz v0, :cond_15

    .line 634
    .line 635
    const v0, 0x7f0f004f

    .line 636
    .line 637
    .line 638
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 639
    .line 640
    .line 641
    move-result-object v16

    .line 642
    const/16 v36, 0x0

    .line 643
    .line 644
    const v37, 0x3fffe

    .line 645
    .line 646
    .line 647
    const/16 v17, 0x0

    .line 648
    .line 649
    const-wide/16 v18, 0x0

    .line 650
    .line 651
    const-wide/16 v20, 0x0

    .line 652
    .line 653
    const/16 v22, 0x0

    .line 654
    .line 655
    const/16 v23, 0x0

    .line 656
    .line 657
    const-wide/16 v24, 0x0

    .line 658
    .line 659
    const/16 v26, 0x0

    .line 660
    .line 661
    const-wide/16 v27, 0x0

    .line 662
    .line 663
    const/16 v29, 0x0

    .line 664
    .line 665
    const/16 v30, 0x0

    .line 666
    .line 667
    const/16 v31, 0x0

    .line 668
    .line 669
    const/16 v32, 0x0

    .line 670
    .line 671
    const/16 v33, 0x0

    .line 672
    .line 673
    const/16 v35, 0x0

    .line 674
    .line 675
    move-object/from16 v34, v1

    .line 676
    .line 677
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 678
    .line 679
    .line 680
    goto :goto_7

    .line 681
    :cond_15
    move-object/from16 v34, v1

    .line 682
    .line 683
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 684
    .line 685
    .line 686
    :goto_7
    return-object v14

    .line 687
    :pswitch_9
    move-object/from16 v0, p1

    .line 688
    .line 689
    check-cast v0, Lbc3;

    .line 690
    .line 691
    move-object/from16 v1, p2

    .line 692
    .line 693
    check-cast v1, Lib2;

    .line 694
    .line 695
    move-object/from16 v2, p3

    .line 696
    .line 697
    check-cast v2, Ljava/lang/Integer;

    .line 698
    .line 699
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 700
    .line 701
    .line 702
    move-result v2

    .line 703
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 704
    .line 705
    .line 706
    and-int/lit8 v0, v2, 0x11

    .line 707
    .line 708
    if-eq v0, v13, :cond_16

    .line 709
    .line 710
    move v7, v15

    .line 711
    :cond_16
    and-int/2addr v2, v15

    .line 712
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 713
    .line 714
    .line 715
    move-result v0

    .line 716
    if-eqz v0, :cond_17

    .line 717
    .line 718
    invoke-static {v10, v5}, Lag6;->e(Lw04;F)Lw04;

    .line 719
    .line 720
    .line 721
    move-result-object v0

    .line 722
    invoke-static {v1}, Lfa3;->N(Lib2;)J

    .line 723
    .line 724
    .line 725
    move-result-wide v16

    .line 726
    const-wide/16 v18, 0x0

    .line 727
    .line 728
    const/16 v21, 0xe

    .line 729
    .line 730
    move-object/from16 v20, v1

    .line 731
    .line 732
    invoke-static/range {v16 .. v21}, Lu6;->j(JJLib2;I)Luj0;

    .line 733
    .line 734
    .line 735
    move-result-object v18

    .line 736
    sget-object v2, Lbr3;->b:Lnt1;

    .line 737
    .line 738
    invoke-virtual {v1, v2}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 739
    .line 740
    .line 741
    move-result-object v2

    .line 742
    check-cast v2, Lyq3;

    .line 743
    .line 744
    iget-object v2, v2, Lyq3;->c:Lsa6;

    .line 745
    .line 746
    iget-object v2, v2, Lsa6;->d:Lxo5;

    .line 747
    .line 748
    sget-object v21, Lj23;->j:Lyz0;

    .line 749
    .line 750
    const v23, 0x30006

    .line 751
    .line 752
    .line 753
    const/16 v24, 0x18

    .line 754
    .line 755
    const/16 v19, 0x0

    .line 756
    .line 757
    const/16 v20, 0x0

    .line 758
    .line 759
    move-object/from16 v16, v0

    .line 760
    .line 761
    move-object/from16 v22, v1

    .line 762
    .line 763
    move-object/from16 v17, v2

    .line 764
    .line 765
    invoke-static/range {v16 .. v24}, Ljn;->c(Lw04;Lma6;Luj0;Lwj0;Lh40;Lyz0;Lib2;II)V

    .line 766
    .line 767
    .line 768
    goto :goto_8

    .line 769
    :cond_17
    invoke-virtual {v1}, Lib2;->a0()V

    .line 770
    .line 771
    .line 772
    :goto_8
    return-object v14

    .line 773
    :pswitch_a
    move-object/from16 v0, p1

    .line 774
    .line 775
    check-cast v0, Lvx0;

    .line 776
    .line 777
    move-object/from16 v1, p2

    .line 778
    .line 779
    check-cast v1, Lib2;

    .line 780
    .line 781
    move-object/from16 v2, p3

    .line 782
    .line 783
    check-cast v2, Ljava/lang/Integer;

    .line 784
    .line 785
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 786
    .line 787
    .line 788
    move-result v2

    .line 789
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 790
    .line 791
    .line 792
    and-int/lit8 v0, v2, 0x11

    .line 793
    .line 794
    if-eq v0, v13, :cond_18

    .line 795
    .line 796
    move v7, v15

    .line 797
    :cond_18
    and-int/2addr v2, v15

    .line 798
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 799
    .line 800
    .line 801
    move-result v0

    .line 802
    if-eqz v0, :cond_19

    .line 803
    .line 804
    invoke-static {v4, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 805
    .line 806
    .line 807
    move-result-object v16

    .line 808
    const/high16 v0, 0x41a00000    # 20.0f

    .line 809
    .line 810
    invoke-static {v10, v0, v3}, Lm71;->B(Lw04;FF)Lw04;

    .line 811
    .line 812
    .line 813
    move-result-object v17

    .line 814
    sget-object v0, Lbr3;->b:Lnt1;

    .line 815
    .line 816
    invoke-virtual {v1, v0}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 817
    .line 818
    .line 819
    move-result-object v0

    .line 820
    check-cast v0, Lyq3;

    .line 821
    .line 822
    iget-object v0, v0, Lyq3;->a:Luv0;

    .line 823
    .line 824
    iget-wide v2, v0, Luv0;->A:J

    .line 825
    .line 826
    const/16 v36, 0x0

    .line 827
    .line 828
    const v37, 0x3fff8

    .line 829
    .line 830
    .line 831
    const-wide/16 v20, 0x0

    .line 832
    .line 833
    const/16 v22, 0x0

    .line 834
    .line 835
    const/16 v23, 0x0

    .line 836
    .line 837
    const-wide/16 v24, 0x0

    .line 838
    .line 839
    const/16 v26, 0x0

    .line 840
    .line 841
    const-wide/16 v27, 0x0

    .line 842
    .line 843
    const/16 v29, 0x0

    .line 844
    .line 845
    const/16 v30, 0x0

    .line 846
    .line 847
    const/16 v31, 0x0

    .line 848
    .line 849
    const/16 v32, 0x0

    .line 850
    .line 851
    const/16 v33, 0x0

    .line 852
    .line 853
    const/16 v35, 0x30

    .line 854
    .line 855
    move-object/from16 v34, v1

    .line 856
    .line 857
    move-wide/from16 v18, v2

    .line 858
    .line 859
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 860
    .line 861
    .line 862
    goto :goto_9

    .line 863
    :cond_19
    move-object/from16 v34, v1

    .line 864
    .line 865
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 866
    .line 867
    .line 868
    :goto_9
    return-object v14

    .line 869
    :pswitch_b
    move-object/from16 v0, p1

    .line 870
    .line 871
    check-cast v0, Lnp5;

    .line 872
    .line 873
    move-object/from16 v1, p2

    .line 874
    .line 875
    check-cast v1, Lib2;

    .line 876
    .line 877
    move-object/from16 v2, p3

    .line 878
    .line 879
    check-cast v2, Ljava/lang/Integer;

    .line 880
    .line 881
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 882
    .line 883
    .line 884
    move-result v2

    .line 885
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 886
    .line 887
    .line 888
    and-int/lit8 v0, v2, 0x11

    .line 889
    .line 890
    if-eq v0, v13, :cond_1a

    .line 891
    .line 892
    move v7, v15

    .line 893
    :cond_1a
    and-int/2addr v2, v15

    .line 894
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 895
    .line 896
    .line 897
    move-result v0

    .line 898
    if-eqz v0, :cond_1b

    .line 899
    .line 900
    const v0, 0x7f0f0034

    .line 901
    .line 902
    .line 903
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 904
    .line 905
    .line 906
    move-result-object v16

    .line 907
    const/16 v36, 0x0

    .line 908
    .line 909
    const v37, 0x3fffe

    .line 910
    .line 911
    .line 912
    const/16 v17, 0x0

    .line 913
    .line 914
    const-wide/16 v18, 0x0

    .line 915
    .line 916
    const-wide/16 v20, 0x0

    .line 917
    .line 918
    const/16 v22, 0x0

    .line 919
    .line 920
    const/16 v23, 0x0

    .line 921
    .line 922
    const-wide/16 v24, 0x0

    .line 923
    .line 924
    const/16 v26, 0x0

    .line 925
    .line 926
    const-wide/16 v27, 0x0

    .line 927
    .line 928
    const/16 v29, 0x0

    .line 929
    .line 930
    const/16 v30, 0x0

    .line 931
    .line 932
    const/16 v31, 0x0

    .line 933
    .line 934
    const/16 v32, 0x0

    .line 935
    .line 936
    const/16 v33, 0x0

    .line 937
    .line 938
    const/16 v35, 0x0

    .line 939
    .line 940
    move-object/from16 v34, v1

    .line 941
    .line 942
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 943
    .line 944
    .line 945
    goto :goto_a

    .line 946
    :cond_1b
    move-object/from16 v34, v1

    .line 947
    .line 948
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 949
    .line 950
    .line 951
    :goto_a
    return-object v14

    .line 952
    :pswitch_c
    move-object/from16 v0, p1

    .line 953
    .line 954
    check-cast v0, Lnp5;

    .line 955
    .line 956
    move-object/from16 v1, p2

    .line 957
    .line 958
    check-cast v1, Lib2;

    .line 959
    .line 960
    move-object/from16 v2, p3

    .line 961
    .line 962
    check-cast v2, Ljava/lang/Integer;

    .line 963
    .line 964
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 965
    .line 966
    .line 967
    move-result v2

    .line 968
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 969
    .line 970
    .line 971
    and-int/lit8 v0, v2, 0x11

    .line 972
    .line 973
    if-eq v0, v13, :cond_1c

    .line 974
    .line 975
    move v7, v15

    .line 976
    :cond_1c
    and-int/2addr v2, v15

    .line 977
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 978
    .line 979
    .line 980
    move-result v0

    .line 981
    if-eqz v0, :cond_1d

    .line 982
    .line 983
    const v0, 0x7f0f0033

    .line 984
    .line 985
    .line 986
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 987
    .line 988
    .line 989
    move-result-object v16

    .line 990
    const/16 v36, 0x0

    .line 991
    .line 992
    const v37, 0x3fffe

    .line 993
    .line 994
    .line 995
    const/16 v17, 0x0

    .line 996
    .line 997
    const-wide/16 v18, 0x0

    .line 998
    .line 999
    const-wide/16 v20, 0x0

    .line 1000
    .line 1001
    const/16 v22, 0x0

    .line 1002
    .line 1003
    const/16 v23, 0x0

    .line 1004
    .line 1005
    const-wide/16 v24, 0x0

    .line 1006
    .line 1007
    const/16 v26, 0x0

    .line 1008
    .line 1009
    const-wide/16 v27, 0x0

    .line 1010
    .line 1011
    const/16 v29, 0x0

    .line 1012
    .line 1013
    const/16 v30, 0x0

    .line 1014
    .line 1015
    const/16 v31, 0x0

    .line 1016
    .line 1017
    const/16 v32, 0x0

    .line 1018
    .line 1019
    const/16 v33, 0x0

    .line 1020
    .line 1021
    const/16 v35, 0x0

    .line 1022
    .line 1023
    move-object/from16 v34, v1

    .line 1024
    .line 1025
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 1026
    .line 1027
    .line 1028
    goto :goto_b

    .line 1029
    :cond_1d
    move-object/from16 v34, v1

    .line 1030
    .line 1031
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 1032
    .line 1033
    .line 1034
    :goto_b
    return-object v14

    .line 1035
    :pswitch_d
    move-object/from16 v0, p1

    .line 1036
    .line 1037
    check-cast v0, Lnp5;

    .line 1038
    .line 1039
    move-object/from16 v1, p2

    .line 1040
    .line 1041
    check-cast v1, Lib2;

    .line 1042
    .line 1043
    move-object/from16 v2, p3

    .line 1044
    .line 1045
    check-cast v2, Ljava/lang/Integer;

    .line 1046
    .line 1047
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1048
    .line 1049
    .line 1050
    move-result v2

    .line 1051
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1052
    .line 1053
    .line 1054
    and-int/lit8 v0, v2, 0x11

    .line 1055
    .line 1056
    if-eq v0, v13, :cond_1e

    .line 1057
    .line 1058
    move v7, v15

    .line 1059
    :cond_1e
    and-int/2addr v2, v15

    .line 1060
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 1061
    .line 1062
    .line 1063
    move-result v0

    .line 1064
    if-eqz v0, :cond_1f

    .line 1065
    .line 1066
    const v0, 0x7f0f0466

    .line 1067
    .line 1068
    .line 1069
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 1070
    .line 1071
    .line 1072
    move-result-object v16

    .line 1073
    const/16 v36, 0x0

    .line 1074
    .line 1075
    const v37, 0x3fffe

    .line 1076
    .line 1077
    .line 1078
    const/16 v17, 0x0

    .line 1079
    .line 1080
    const-wide/16 v18, 0x0

    .line 1081
    .line 1082
    const-wide/16 v20, 0x0

    .line 1083
    .line 1084
    const/16 v22, 0x0

    .line 1085
    .line 1086
    const/16 v23, 0x0

    .line 1087
    .line 1088
    const-wide/16 v24, 0x0

    .line 1089
    .line 1090
    const/16 v26, 0x0

    .line 1091
    .line 1092
    const-wide/16 v27, 0x0

    .line 1093
    .line 1094
    const/16 v29, 0x0

    .line 1095
    .line 1096
    const/16 v30, 0x0

    .line 1097
    .line 1098
    const/16 v31, 0x0

    .line 1099
    .line 1100
    const/16 v32, 0x0

    .line 1101
    .line 1102
    const/16 v33, 0x0

    .line 1103
    .line 1104
    const/16 v35, 0x0

    .line 1105
    .line 1106
    move-object/from16 v34, v1

    .line 1107
    .line 1108
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 1109
    .line 1110
    .line 1111
    goto :goto_c

    .line 1112
    :cond_1f
    move-object/from16 v34, v1

    .line 1113
    .line 1114
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 1115
    .line 1116
    .line 1117
    :goto_c
    return-object v14

    .line 1118
    :pswitch_e
    move-object/from16 v0, p1

    .line 1119
    .line 1120
    check-cast v0, Lnp5;

    .line 1121
    .line 1122
    move-object/from16 v0, p2

    .line 1123
    .line 1124
    check-cast v0, Lib2;

    .line 1125
    .line 1126
    move-object/from16 v1, p3

    .line 1127
    .line 1128
    check-cast v1, Ljava/lang/Integer;

    .line 1129
    .line 1130
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1131
    .line 1132
    .line 1133
    move-result v1

    .line 1134
    and-int/lit8 v2, v1, 0x11

    .line 1135
    .line 1136
    if-eq v2, v13, :cond_20

    .line 1137
    .line 1138
    move v7, v15

    .line 1139
    :cond_20
    and-int/2addr v1, v15

    .line 1140
    invoke-virtual {v0, v1, v7}, Lib2;->X(IZ)Z

    .line 1141
    .line 1142
    .line 1143
    move-result v1

    .line 1144
    if-nez v1, :cond_21

    .line 1145
    .line 1146
    invoke-virtual {v0}, Lib2;->a0()V

    .line 1147
    .line 1148
    .line 1149
    :cond_21
    return-object v14

    .line 1150
    :pswitch_f
    move-object/from16 v0, p1

    .line 1151
    .line 1152
    check-cast v0, Lnp5;

    .line 1153
    .line 1154
    move-object/from16 v0, p2

    .line 1155
    .line 1156
    check-cast v0, Lib2;

    .line 1157
    .line 1158
    move-object/from16 v1, p3

    .line 1159
    .line 1160
    check-cast v1, Ljava/lang/Integer;

    .line 1161
    .line 1162
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 1163
    .line 1164
    .line 1165
    move-result v1

    .line 1166
    and-int/lit8 v2, v1, 0x11

    .line 1167
    .line 1168
    if-eq v2, v13, :cond_22

    .line 1169
    .line 1170
    move v7, v15

    .line 1171
    :cond_22
    and-int/2addr v1, v15

    .line 1172
    invoke-virtual {v0, v1, v7}, Lib2;->X(IZ)Z

    .line 1173
    .line 1174
    .line 1175
    move-result v1

    .line 1176
    if-nez v1, :cond_23

    .line 1177
    .line 1178
    invoke-virtual {v0}, Lib2;->a0()V

    .line 1179
    .line 1180
    .line 1181
    :cond_23
    return-object v14

    .line 1182
    :pswitch_10
    move-object/from16 v0, p1

    .line 1183
    .line 1184
    check-cast v0, Lnp5;

    .line 1185
    .line 1186
    move-object/from16 v1, p2

    .line 1187
    .line 1188
    check-cast v1, Lib2;

    .line 1189
    .line 1190
    move-object/from16 v2, p3

    .line 1191
    .line 1192
    check-cast v2, Ljava/lang/Integer;

    .line 1193
    .line 1194
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1195
    .line 1196
    .line 1197
    move-result v2

    .line 1198
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1199
    .line 1200
    .line 1201
    and-int/lit8 v0, v2, 0x11

    .line 1202
    .line 1203
    if-eq v0, v13, :cond_24

    .line 1204
    .line 1205
    move v7, v15

    .line 1206
    :cond_24
    and-int/2addr v2, v15

    .line 1207
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 1208
    .line 1209
    .line 1210
    move-result v0

    .line 1211
    if-eqz v0, :cond_25

    .line 1212
    .line 1213
    const v0, 0x104000a

    .line 1214
    .line 1215
    .line 1216
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 1217
    .line 1218
    .line 1219
    move-result-object v16

    .line 1220
    const/16 v36, 0x0

    .line 1221
    .line 1222
    const v37, 0x3fffe

    .line 1223
    .line 1224
    .line 1225
    const/16 v17, 0x0

    .line 1226
    .line 1227
    const-wide/16 v18, 0x0

    .line 1228
    .line 1229
    const-wide/16 v20, 0x0

    .line 1230
    .line 1231
    const/16 v22, 0x0

    .line 1232
    .line 1233
    const/16 v23, 0x0

    .line 1234
    .line 1235
    const-wide/16 v24, 0x0

    .line 1236
    .line 1237
    const/16 v26, 0x0

    .line 1238
    .line 1239
    const-wide/16 v27, 0x0

    .line 1240
    .line 1241
    const/16 v29, 0x0

    .line 1242
    .line 1243
    const/16 v30, 0x0

    .line 1244
    .line 1245
    const/16 v31, 0x0

    .line 1246
    .line 1247
    const/16 v32, 0x0

    .line 1248
    .line 1249
    const/16 v33, 0x0

    .line 1250
    .line 1251
    const/16 v35, 0x0

    .line 1252
    .line 1253
    move-object/from16 v34, v1

    .line 1254
    .line 1255
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 1256
    .line 1257
    .line 1258
    goto :goto_d

    .line 1259
    :cond_25
    move-object/from16 v34, v1

    .line 1260
    .line 1261
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 1262
    .line 1263
    .line 1264
    :goto_d
    return-object v14

    .line 1265
    :pswitch_11
    move-object/from16 v0, p1

    .line 1266
    .line 1267
    check-cast v0, Lnp5;

    .line 1268
    .line 1269
    move-object/from16 v1, p2

    .line 1270
    .line 1271
    check-cast v1, Lib2;

    .line 1272
    .line 1273
    move-object/from16 v2, p3

    .line 1274
    .line 1275
    check-cast v2, Ljava/lang/Integer;

    .line 1276
    .line 1277
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1278
    .line 1279
    .line 1280
    move-result v2

    .line 1281
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1282
    .line 1283
    .line 1284
    and-int/lit8 v0, v2, 0x11

    .line 1285
    .line 1286
    if-eq v0, v13, :cond_26

    .line 1287
    .line 1288
    move v7, v15

    .line 1289
    :cond_26
    and-int/2addr v2, v15

    .line 1290
    invoke-virtual {v1, v2, v7}, Lib2;->X(IZ)Z

    .line 1291
    .line 1292
    .line 1293
    move-result v0

    .line 1294
    if-eqz v0, :cond_27

    .line 1295
    .line 1296
    const/high16 v0, 0x1040000

    .line 1297
    .line 1298
    invoke-static {v0, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 1299
    .line 1300
    .line 1301
    move-result-object v16

    .line 1302
    const/16 v36, 0x0

    .line 1303
    .line 1304
    const v37, 0x3fffe

    .line 1305
    .line 1306
    .line 1307
    const/16 v17, 0x0

    .line 1308
    .line 1309
    const-wide/16 v18, 0x0

    .line 1310
    .line 1311
    const-wide/16 v20, 0x0

    .line 1312
    .line 1313
    const/16 v22, 0x0

    .line 1314
    .line 1315
    const/16 v23, 0x0

    .line 1316
    .line 1317
    const-wide/16 v24, 0x0

    .line 1318
    .line 1319
    const/16 v26, 0x0

    .line 1320
    .line 1321
    const-wide/16 v27, 0x0

    .line 1322
    .line 1323
    const/16 v29, 0x0

    .line 1324
    .line 1325
    const/16 v30, 0x0

    .line 1326
    .line 1327
    const/16 v31, 0x0

    .line 1328
    .line 1329
    const/16 v32, 0x0

    .line 1330
    .line 1331
    const/16 v33, 0x0

    .line 1332
    .line 1333
    const/16 v35, 0x0

    .line 1334
    .line 1335
    move-object/from16 v34, v1

    .line 1336
    .line 1337
    invoke-static/range {v16 .. v37}, Lg07;->b(Ljava/lang/String;Lw04;JJLr82;Lt72;JLjv6;JIZIILx17;Lib2;III)V

    .line 1338
    .line 1339
    .line 1340
    goto :goto_e

    .line 1341
    :cond_27
    move-object/from16 v34, v1

    .line 1342
    .line 1343
    invoke-virtual/range {v34 .. v34}, Lib2;->a0()V

    .line 1344
    .line 1345
    .line 1346
    :goto_e
    return-object v14

    .line 1347
    :pswitch_12
    move-object/from16 v0, p1

    .line 1348
    .line 1349
    check-cast v0, Lc87;

    .line 1350
    .line 1351
    move-object/from16 v1, p2

    .line 1352
    .line 1353
    check-cast v1, Lib2;

    .line 1354
    .line 1355
    move-object/from16 v3, p3

    .line 1356
    .line 1357
    check-cast v3, Ljava/lang/Integer;

    .line 1358
    .line 1359
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1360
    .line 1361
    .line 1362
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1363
    .line 1364
    .line 1365
    const v3, -0x1c634518

    .line 1366
    .line 1367
    .line 1368
    invoke-virtual {v1, v3}, Lib2;->g0(I)V

    .line 1369
    .line 1370
    .line 1371
    invoke-interface {v0}, Lc87;->d()Ljava/lang/Object;

    .line 1372
    .line 1373
    .line 1374
    move-result-object v0

    .line 1375
    if-eq v0, v2, :cond_29

    .line 1376
    .line 1377
    const v0, 0x7bdb681d

    .line 1378
    .line 1379
    .line 1380
    invoke-virtual {v1, v0}, Lib2;->g0(I)V

    .line 1381
    .line 1382
    .line 1383
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 1384
    .line 1385
    .line 1386
    move-result-object v0

    .line 1387
    if-ne v0, v12, :cond_28

    .line 1388
    .line 1389
    new-instance v0, Lfb0;

    .line 1390
    .line 1391
    const/16 v2, 0x19

    .line 1392
    .line 1393
    invoke-direct {v0, v2}, Lfb0;-><init>(B)V

    .line 1394
    .line 1395
    .line 1396
    invoke-virtual {v1, v0}, Lib2;->p0(Ljava/lang/Object;)V

    .line 1397
    .line 1398
    .line 1399
    :cond_28
    check-cast v0, Lfa2;

    .line 1400
    .line 1401
    invoke-static {v0}, Lfv6;->B(Lfa2;)Lz73;

    .line 1402
    .line 1403
    .line 1404
    move-result-object v0

    .line 1405
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1406
    .line 1407
    .line 1408
    goto :goto_f

    .line 1409
    :cond_29
    const v0, 0x7bdecd34

    .line 1410
    .line 1411
    .line 1412
    invoke-virtual {v1, v0}, Lib2;->g0(I)V

    .line 1413
    .line 1414
    .line 1415
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v0

    .line 1419
    if-ne v0, v12, :cond_2a

    .line 1420
    .line 1421
    new-instance v0, Lfb0;

    .line 1422
    .line 1423
    const/16 v2, 0x1a

    .line 1424
    .line 1425
    invoke-direct {v0, v2}, Lfb0;-><init>(B)V

    .line 1426
    .line 1427
    .line 1428
    invoke-virtual {v1, v0}, Lib2;->p0(Ljava/lang/Object;)V

    .line 1429
    .line 1430
    .line 1431
    :cond_2a
    check-cast v0, Lfa2;

    .line 1432
    .line 1433
    invoke-static {v0}, Lfv6;->B(Lfa2;)Lz73;

    .line 1434
    .line 1435
    .line 1436
    move-result-object v0

    .line 1437
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1438
    .line 1439
    .line 1440
    :goto_f
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1441
    .line 1442
    .line 1443
    return-object v0

    .line 1444
    :pswitch_13
    move-object/from16 v0, p1

    .line 1445
    .line 1446
    check-cast v0, Lc87;

    .line 1447
    .line 1448
    move-object/from16 v1, p2

    .line 1449
    .line 1450
    check-cast v1, Lib2;

    .line 1451
    .line 1452
    move-object/from16 v3, p3

    .line 1453
    .line 1454
    check-cast v3, Ljava/lang/Integer;

    .line 1455
    .line 1456
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1457
    .line 1458
    .line 1459
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1460
    .line 1461
    .line 1462
    const v3, -0x5a652311

    .line 1463
    .line 1464
    .line 1465
    invoke-virtual {v1, v3}, Lib2;->g0(I)V

    .line 1466
    .line 1467
    .line 1468
    invoke-interface {v0}, Lc87;->d()Ljava/lang/Object;

    .line 1469
    .line 1470
    .line 1471
    move-result-object v0

    .line 1472
    if-eq v0, v2, :cond_2b

    .line 1473
    .line 1474
    const v0, -0x5f6adb46

    .line 1475
    .line 1476
    .line 1477
    invoke-virtual {v1, v0}, Lib2;->g0(I)V

    .line 1478
    .line 1479
    .line 1480
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1481
    .line 1482
    .line 1483
    const/16 v0, 0xc8

    .line 1484
    .line 1485
    sget-object v2, Lwt1;->a:Lhg1;

    .line 1486
    .line 1487
    invoke-static {v0, v7, v2, v11}, Lfv6;->M(IILut1;I)Lb97;

    .line 1488
    .line 1489
    .line 1490
    move-result-object v0

    .line 1491
    goto :goto_10

    .line 1492
    :cond_2b
    const v0, -0x5f6965b3

    .line 1493
    .line 1494
    .line 1495
    invoke-virtual {v1, v0}, Lib2;->g0(I)V

    .line 1496
    .line 1497
    .line 1498
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 1499
    .line 1500
    .line 1501
    move-result-object v0

    .line 1502
    if-ne v0, v12, :cond_2c

    .line 1503
    .line 1504
    new-instance v0, Lfb0;

    .line 1505
    .line 1506
    const/16 v2, 0x18

    .line 1507
    .line 1508
    invoke-direct {v0, v2}, Lfb0;-><init>(B)V

    .line 1509
    .line 1510
    .line 1511
    invoke-virtual {v1, v0}, Lib2;->p0(Ljava/lang/Object;)V

    .line 1512
    .line 1513
    .line 1514
    :cond_2c
    check-cast v0, Lfa2;

    .line 1515
    .line 1516
    invoke-static {v0}, Lfv6;->B(Lfa2;)Lz73;

    .line 1517
    .line 1518
    .line 1519
    move-result-object v0

    .line 1520
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1521
    .line 1522
    .line 1523
    :goto_10
    invoke-virtual {v1, v7}, Lib2;->r(Z)V

    .line 1524
    .line 1525
    .line 1526
    return-object v0

    .line 1527
    :pswitch_14
    move-object/from16 v0, p1

    .line 1528
    .line 1529
    check-cast v0, Lrk0;

    .line 1530
    .line 1531
    move-object/from16 v1, p2

    .line 1532
    .line 1533
    check-cast v1, Ljava/lang/Double;

    .line 1534
    .line 1535
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 1536
    .line 1537
    .line 1538
    move-result-wide v1

    .line 1539
    move-object/from16 v3, p3

    .line 1540
    .line 1541
    check-cast v3, Ljava/lang/Double;

    .line 1542
    .line 1543
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1544
    .line 1545
    .line 1546
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1547
    .line 1548
    .line 1549
    iget-object v0, v0, Lrk0;->a:Ljava/util/List;

    .line 1550
    .line 1551
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1552
    .line 1553
    .line 1554
    move-result-object v3

    .line 1555
    const/4 v4, 0x0

    .line 1556
    :goto_11
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1557
    .line 1558
    .line 1559
    move-result v5

    .line 1560
    if-eqz v5, :cond_2e

    .line 1561
    .line 1562
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1563
    .line 1564
    .line 1565
    move-result-object v5

    .line 1566
    check-cast v5, Lvl0;

    .line 1567
    .line 1568
    invoke-interface {v5}, Lvl0;->c()D

    .line 1569
    .line 1570
    .line 1571
    move-result-wide v5

    .line 1572
    if-eqz v4, :cond_2d

    .line 1573
    .line 1574
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 1575
    .line 1576
    .line 1577
    move-result-wide v7

    .line 1578
    invoke-static {v7, v8, v5, v6}, Llb3;->z(DD)D

    .line 1579
    .line 1580
    .line 1581
    move-result-wide v5

    .line 1582
    :cond_2d
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 1583
    .line 1584
    .line 1585
    move-result-object v4

    .line 1586
    goto :goto_11

    .line 1587
    :cond_2e
    if-eqz v4, :cond_2f

    .line 1588
    .line 1589
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 1590
    .line 1591
    .line 1592
    move-result-wide v3

    .line 1593
    goto :goto_12

    .line 1594
    :cond_2f
    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    .line 1595
    .line 1596
    :goto_12
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 1597
    .line 1598
    .line 1599
    move-result v5

    .line 1600
    if-nez v5, :cond_32

    .line 1601
    .line 1602
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1603
    .line 1604
    .line 1605
    move-result-object v0

    .line 1606
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1607
    .line 1608
    .line 1609
    move-result v5

    .line 1610
    const-wide/16 v6, 0x0

    .line 1611
    .line 1612
    if-eqz v5, :cond_31

    .line 1613
    .line 1614
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1615
    .line 1616
    .line 1617
    move-result-object v5

    .line 1618
    check-cast v5, Lvl0;

    .line 1619
    .line 1620
    invoke-interface {v5}, Lvl0;->b()D

    .line 1621
    .line 1622
    .line 1623
    move-result-wide v8

    .line 1624
    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1625
    .line 1626
    .line 1627
    move-result v5

    .line 1628
    if-eqz v5, :cond_30

    .line 1629
    .line 1630
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1631
    .line 1632
    .line 1633
    move-result-object v5

    .line 1634
    check-cast v5, Lvl0;

    .line 1635
    .line 1636
    invoke-interface {v5}, Lvl0;->b()D

    .line 1637
    .line 1638
    .line 1639
    move-result-wide v10

    .line 1640
    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->min(DD)D

    .line 1641
    .line 1642
    .line 1643
    move-result-wide v8

    .line 1644
    goto :goto_13

    .line 1645
    :cond_30
    sub-double/2addr v8, v1

    .line 1646
    cmpg-double v0, v8, v6

    .line 1647
    .line 1648
    if-eqz v0, :cond_32

    .line 1649
    .line 1650
    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    .line 1651
    .line 1652
    .line 1653
    move-result-wide v0

    .line 1654
    invoke-static {v3, v4, v0, v1}, Llb3;->z(DD)D

    .line 1655
    .line 1656
    .line 1657
    move-result-wide v3

    .line 1658
    cmpg-double v0, v3, v6

    .line 1659
    .line 1660
    if-nez v0, :cond_32

    .line 1661
    .line 1662
    const-string v0, "The x-values are too precise. The maximum precision is four decimal places."

    .line 1663
    .line 1664
    invoke-static {v0}, La02;->g(Ljava/lang/String;)V

    .line 1665
    .line 1666
    .line 1667
    :goto_14
    move-wide v3, v6

    .line 1668
    goto :goto_15

    .line 1669
    :cond_31
    invoke-static {}, Lw91;->p()V

    .line 1670
    .line 1671
    .line 1672
    goto :goto_14

    .line 1673
    :cond_32
    :goto_15
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 1674
    .line 1675
    .line 1676
    move-result-object v0

    .line 1677
    return-object v0

    .line 1678
    :pswitch_15
    move-object/from16 v0, p1

    .line 1679
    .line 1680
    check-cast v0, Lqr3;

    .line 1681
    .line 1682
    move-object/from16 v1, p2

    .line 1683
    .line 1684
    check-cast v1, Ljr3;

    .line 1685
    .line 1686
    move-object/from16 v2, p3

    .line 1687
    .line 1688
    check-cast v2, Lw71;

    .line 1689
    .line 1690
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1691
    .line 1692
    .line 1693
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1694
    .line 1695
    .line 1696
    iget-wide v3, v2, Lw71;->a:J

    .line 1697
    .line 1698
    invoke-static {v3, v4}, Lw71;->i(J)I

    .line 1699
    .line 1700
    .line 1701
    move-result v3

    .line 1702
    iget-wide v4, v2, Lw71;->a:J

    .line 1703
    .line 1704
    invoke-static {v4, v5}, Lw71;->k(J)I

    .line 1705
    .line 1706
    .line 1707
    move-result v6

    .line 1708
    invoke-interface {v0}, Lkl1;->a()F

    .line 1709
    .line 1710
    .line 1711
    move-result v7

    .line 1712
    const v8, 0x7fffffff

    .line 1713
    .line 1714
    .line 1715
    if-eq v3, v8, :cond_35

    .line 1716
    .line 1717
    if-lez v3, :cond_35

    .line 1718
    .line 1719
    int-to-float v8, v3

    .line 1720
    div-float/2addr v8, v7

    .line 1721
    sget v10, Lj40;->c:F

    .line 1722
    .line 1723
    sget v12, Lj40;->d:F

    .line 1724
    .line 1725
    add-float/2addr v12, v10

    .line 1726
    cmpg-float v8, v8, v12

    .line 1727
    .line 1728
    if-lez v8, :cond_35

    .line 1729
    .line 1730
    mul-float/2addr v10, v7

    .line 1731
    float-to-int v7, v10

    .line 1732
    if-le v7, v3, :cond_33

    .line 1733
    .line 1734
    move v7, v3

    .line 1735
    :cond_33
    if-gt v6, v3, :cond_34

    .line 1736
    .line 1737
    move v3, v6

    .line 1738
    :cond_34
    if-lt v7, v3, :cond_35

    .line 1739
    .line 1740
    move v3, v7

    .line 1741
    :cond_35
    iget-wide v12, v2, Lw71;->a:J

    .line 1742
    .line 1743
    invoke-static {v12, v13}, Lw71;->i(J)I

    .line 1744
    .line 1745
    .line 1746
    move-result v2

    .line 1747
    if-le v3, v2, :cond_36

    .line 1748
    .line 1749
    move v14, v2

    .line 1750
    goto :goto_16

    .line 1751
    :cond_36
    move v14, v3

    .line 1752
    :goto_16
    invoke-static {v4, v5}, Lw71;->i(J)I

    .line 1753
    .line 1754
    .line 1755
    move-result v2

    .line 1756
    if-le v3, v2, :cond_37

    .line 1757
    .line 1758
    move v15, v2

    .line 1759
    goto :goto_17

    .line 1760
    :cond_37
    move v15, v3

    .line 1761
    :goto_17
    const/16 v17, 0x0

    .line 1762
    .line 1763
    const/16 v18, 0xc

    .line 1764
    .line 1765
    const/16 v16, 0x0

    .line 1766
    .line 1767
    invoke-static/range {v12 .. v18}, Lw71;->b(JIIIII)J

    .line 1768
    .line 1769
    .line 1770
    move-result-wide v4

    .line 1771
    invoke-interface {v1, v4, v5}, Ljr3;->e(J)Lc05;

    .line 1772
    .line 1773
    .line 1774
    move-result-object v1

    .line 1775
    iget v2, v1, Lc05;->i:I

    .line 1776
    .line 1777
    iget v4, v1, Lc05;->j:I

    .line 1778
    .line 1779
    new-instance v5, Lk5;

    .line 1780
    .line 1781
    invoke-direct {v5, v1, v3, v11}, Lk5;-><init>(Lc05;IB)V

    .line 1782
    .line 1783
    .line 1784
    invoke-interface {v0, v2, v4, v9, v5}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 1785
    .line 1786
    .line 1787
    move-result-object v0

    .line 1788
    return-object v0

    .line 1789
    :pswitch_16
    move-object/from16 v1, p1

    .line 1790
    .line 1791
    check-cast v1, Lqr3;

    .line 1792
    .line 1793
    move-object/from16 v0, p2

    .line 1794
    .line 1795
    check-cast v0, Ljr3;

    .line 1796
    .line 1797
    move-object/from16 v2, p3

    .line 1798
    .line 1799
    check-cast v2, Lw71;

    .line 1800
    .line 1801
    iget-wide v2, v2, Lw71;->a:J

    .line 1802
    .line 1803
    invoke-interface {v0, v2, v3}, Ljr3;->e(J)Lc05;

    .line 1804
    .line 1805
    .line 1806
    move-result-object v0

    .line 1807
    iget v2, v0, Lc05;->i:I

    .line 1808
    .line 1809
    iget v3, v0, Lc05;->j:I

    .line 1810
    .line 1811
    new-instance v5, Lbn;

    .line 1812
    .line 1813
    const/16 v4, 0x15

    .line 1814
    .line 1815
    invoke-direct {v5, v4}, Lbn;-><init>(B)V

    .line 1816
    .line 1817
    .line 1818
    new-instance v6, Lz2;

    .line 1819
    .line 1820
    const/4 v4, 0x3

    .line 1821
    invoke-direct {v6, v0, v4}, Lz2;-><init>(Lc05;B)V

    .line 1822
    .line 1823
    .line 1824
    sget-object v4, Lcy1;->i:Lcy1;

    .line 1825
    .line 1826
    invoke-interface/range {v1 .. v6}, Lqr3;->r0(IILjava/util/Map;Lfa2;Lfa2;)Lpr3;

    .line 1827
    .line 1828
    .line 1829
    move-result-object v0

    .line 1830
    return-object v0

    .line 1831
    :pswitch_17
    move-object/from16 v0, p1

    .line 1832
    .line 1833
    check-cast v0, Lqr3;

    .line 1834
    .line 1835
    move-object/from16 v2, p2

    .line 1836
    .line 1837
    check-cast v2, Ljr3;

    .line 1838
    .line 1839
    move-object/from16 v3, p3

    .line 1840
    .line 1841
    check-cast v3, Lw71;

    .line 1842
    .line 1843
    invoke-interface {v0, v1}, Lkl1;->s0(F)I

    .line 1844
    .line 1845
    .line 1846
    move-result v1

    .line 1847
    iget-wide v3, v3, Lw71;->a:J

    .line 1848
    .line 1849
    shl-int/lit8 v5, v1, 0x1

    .line 1850
    .line 1851
    invoke-static {v3, v4, v7, v5}, Lx71;->i(JII)J

    .line 1852
    .line 1853
    .line 1854
    move-result-wide v3

    .line 1855
    invoke-interface {v2, v3, v4}, Ljr3;->e(J)Lc05;

    .line 1856
    .line 1857
    .line 1858
    move-result-object v2

    .line 1859
    iget v3, v2, Lc05;->j:I

    .line 1860
    .line 1861
    sub-int/2addr v3, v5

    .line 1862
    iget v4, v2, Lc05;->i:I

    .line 1863
    .line 1864
    new-instance v5, Lk5;

    .line 1865
    .line 1866
    invoke-direct {v5, v2, v1, v15}, Lk5;-><init>(Lc05;IB)V

    .line 1867
    .line 1868
    .line 1869
    invoke-interface {v0, v4, v3, v9, v5}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 1870
    .line 1871
    .line 1872
    move-result-object v0

    .line 1873
    return-object v0

    .line 1874
    :pswitch_18
    move-object/from16 v0, p1

    .line 1875
    .line 1876
    check-cast v0, Lqr3;

    .line 1877
    .line 1878
    move-object/from16 v2, p2

    .line 1879
    .line 1880
    check-cast v2, Ljr3;

    .line 1881
    .line 1882
    move-object/from16 v3, p3

    .line 1883
    .line 1884
    check-cast v3, Lw71;

    .line 1885
    .line 1886
    invoke-interface {v0, v1}, Lkl1;->s0(F)I

    .line 1887
    .line 1888
    .line 1889
    move-result v1

    .line 1890
    iget-wide v3, v3, Lw71;->a:J

    .line 1891
    .line 1892
    shl-int/lit8 v5, v1, 0x1

    .line 1893
    .line 1894
    invoke-static {v3, v4, v5, v7}, Lx71;->i(JII)J

    .line 1895
    .line 1896
    .line 1897
    move-result-wide v3

    .line 1898
    invoke-interface {v2, v3, v4}, Ljr3;->e(J)Lc05;

    .line 1899
    .line 1900
    .line 1901
    move-result-object v2

    .line 1902
    iget v3, v2, Lc05;->j:I

    .line 1903
    .line 1904
    iget v4, v2, Lc05;->i:I

    .line 1905
    .line 1906
    sub-int/2addr v4, v5

    .line 1907
    new-instance v5, Lk5;

    .line 1908
    .line 1909
    invoke-direct {v5, v2, v1, v7}, Lk5;-><init>(Lc05;IB)V

    .line 1910
    .line 1911
    .line 1912
    invoke-interface {v0, v4, v3, v9, v5}, Lqr3;->O0(IILjava/util/Map;Lfa2;)Lpr3;

    .line 1913
    .line 1914
    .line 1915
    move-result-object v0

    .line 1916
    return-object v0

    .line 1917
    :pswitch_19
    move-object/from16 v0, p1

    .line 1918
    .line 1919
    check-cast v0, Lvh;

    .line 1920
    .line 1921
    move-object/from16 v1, p2

    .line 1922
    .line 1923
    check-cast v1, Lib2;

    .line 1924
    .line 1925
    move-object/from16 v2, p3

    .line 1926
    .line 1927
    check-cast v2, Ljava/lang/Integer;

    .line 1928
    .line 1929
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1930
    .line 1931
    .line 1932
    move-result v2

    .line 1933
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1934
    .line 1935
    .line 1936
    and-int/lit8 v0, v2, 0x11

    .line 1937
    .line 1938
    if-eq v0, v13, :cond_38

    .line 1939
    .line 1940
    move v0, v15

    .line 1941
    goto :goto_18

    .line 1942
    :cond_38
    move v0, v7

    .line 1943
    :goto_18
    and-int/2addr v2, v15

    .line 1944
    invoke-virtual {v1, v2, v0}, Lib2;->X(IZ)Z

    .line 1945
    .line 1946
    .line 1947
    move-result v0

    .line 1948
    if-eqz v0, :cond_3a

    .line 1949
    .line 1950
    sget-object v0, Lag6;->c:La32;

    .line 1951
    .line 1952
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 1953
    .line 1954
    .line 1955
    move-result-object v2

    .line 1956
    if-ne v2, v12, :cond_39

    .line 1957
    .line 1958
    sget-object v2, Lwo;->e:Lwo;

    .line 1959
    .line 1960
    invoke-virtual {v1, v2}, Lib2;->p0(Ljava/lang/Object;)V

    .line 1961
    .line 1962
    .line 1963
    :cond_39
    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 1964
    .line 1965
    invoke-static {v0, v14, v2}, Lxr6;->b(Lw04;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lw04;

    .line 1966
    .line 1967
    .line 1968
    move-result-object v0

    .line 1969
    invoke-static {v0, v1, v7}, Lnb0;->a(Lw04;Lib2;I)V

    .line 1970
    .line 1971
    .line 1972
    goto :goto_19

    .line 1973
    :cond_3a
    invoke-virtual {v1}, Lib2;->a0()V

    .line 1974
    .line 1975
    .line 1976
    :goto_19
    return-object v14

    .line 1977
    :pswitch_1a
    move-object/from16 v0, p1

    .line 1978
    .line 1979
    check-cast v0, Lvh;

    .line 1980
    .line 1981
    move-object/from16 v1, p2

    .line 1982
    .line 1983
    check-cast v1, Lib2;

    .line 1984
    .line 1985
    move-object/from16 v2, p3

    .line 1986
    .line 1987
    check-cast v2, Ljava/lang/Integer;

    .line 1988
    .line 1989
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 1990
    .line 1991
    .line 1992
    move-result v2

    .line 1993
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1994
    .line 1995
    .line 1996
    and-int/lit8 v0, v2, 0x11

    .line 1997
    .line 1998
    if-eq v0, v13, :cond_3b

    .line 1999
    .line 2000
    move v0, v15

    .line 2001
    goto :goto_1a

    .line 2002
    :cond_3b
    move v0, v7

    .line 2003
    :goto_1a
    and-int/2addr v2, v15

    .line 2004
    invoke-virtual {v1, v2, v0}, Lib2;->X(IZ)Z

    .line 2005
    .line 2006
    .line 2007
    move-result v0

    .line 2008
    if-eqz v0, :cond_3d

    .line 2009
    .line 2010
    sget-object v0, Lag6;->c:La32;

    .line 2011
    .line 2012
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 2013
    .line 2014
    .line 2015
    move-result-object v2

    .line 2016
    if-ne v2, v12, :cond_3c

    .line 2017
    .line 2018
    sget-object v2, Lwo;->f:Lwo;

    .line 2019
    .line 2020
    invoke-virtual {v1, v2}, Lib2;->p0(Ljava/lang/Object;)V

    .line 2021
    .line 2022
    .line 2023
    :cond_3c
    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 2024
    .line 2025
    invoke-static {v0, v14, v2}, Lxr6;->b(Lw04;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lw04;

    .line 2026
    .line 2027
    .line 2028
    move-result-object v0

    .line 2029
    sget-object v2, Lbx0;->a:Lnt1;

    .line 2030
    .line 2031
    invoke-virtual {v1, v2}, Lib2;->k(Lh65;)Ljava/lang/Object;

    .line 2032
    .line 2033
    .line 2034
    move-result-object v2

    .line 2035
    check-cast v2, Lax0;

    .line 2036
    .line 2037
    invoke-virtual {v2}, Lax0;->w()J

    .line 2038
    .line 2039
    .line 2040
    move-result-wide v2

    .line 2041
    sget-object v4, Ld70;->V:Lus2;

    .line 2042
    .line 2043
    invoke-static {v0, v2, v3, v4}, Lhb;->D(Lw04;JLma6;)Lw04;

    .line 2044
    .line 2045
    .line 2046
    move-result-object v0

    .line 2047
    invoke-static {v0, v1, v7}, Lnb0;->a(Lw04;Lib2;I)V

    .line 2048
    .line 2049
    .line 2050
    goto :goto_1b

    .line 2051
    :cond_3d
    invoke-virtual {v1}, Lib2;->a0()V

    .line 2052
    .line 2053
    .line 2054
    :goto_1b
    return-object v14

    .line 2055
    :pswitch_1b
    move-object/from16 v0, p1

    .line 2056
    .line 2057
    check-cast v0, Lvh;

    .line 2058
    .line 2059
    move-object/from16 v1, p2

    .line 2060
    .line 2061
    check-cast v1, Lib2;

    .line 2062
    .line 2063
    move-object/from16 v2, p3

    .line 2064
    .line 2065
    check-cast v2, Ljava/lang/Integer;

    .line 2066
    .line 2067
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 2068
    .line 2069
    .line 2070
    move-result v2

    .line 2071
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2072
    .line 2073
    .line 2074
    and-int/lit8 v0, v2, 0x11

    .line 2075
    .line 2076
    if-eq v0, v13, :cond_3e

    .line 2077
    .line 2078
    move v0, v15

    .line 2079
    goto :goto_1c

    .line 2080
    :cond_3e
    move v0, v7

    .line 2081
    :goto_1c
    and-int/2addr v2, v15

    .line 2082
    invoke-virtual {v1, v2, v0}, Lib2;->X(IZ)Z

    .line 2083
    .line 2084
    .line 2085
    move-result v0

    .line 2086
    if-eqz v0, :cond_40

    .line 2087
    .line 2088
    sget-object v0, Lag6;->c:La32;

    .line 2089
    .line 2090
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 2091
    .line 2092
    .line 2093
    move-result-object v2

    .line 2094
    if-ne v2, v12, :cond_3f

    .line 2095
    .line 2096
    sget-object v2, Lwo;->g:Lwo;

    .line 2097
    .line 2098
    invoke-virtual {v1, v2}, Lib2;->p0(Ljava/lang/Object;)V

    .line 2099
    .line 2100
    .line 2101
    :cond_3f
    check-cast v2, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 2102
    .line 2103
    invoke-static {v0, v14, v2}, Lxr6;->b(Lw04;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;)Lw04;

    .line 2104
    .line 2105
    .line 2106
    move-result-object v0

    .line 2107
    invoke-static {v0, v1, v7}, Lnb0;->a(Lw04;Lib2;I)V

    .line 2108
    .line 2109
    .line 2110
    goto :goto_1d

    .line 2111
    :cond_40
    invoke-virtual {v1}, Lib2;->a0()V

    .line 2112
    .line 2113
    .line 2114
    :goto_1d
    return-object v14

    .line 2115
    :pswitch_1c
    move-object/from16 v0, p1

    .line 2116
    .line 2117
    check-cast v0, Lja2;

    .line 2118
    .line 2119
    move-object/from16 v1, p2

    .line 2120
    .line 2121
    check-cast v1, Lib2;

    .line 2122
    .line 2123
    move-object/from16 v2, p3

    .line 2124
    .line 2125
    check-cast v2, Ljava/lang/Integer;

    .line 2126
    .line 2127
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 2128
    .line 2129
    .line 2130
    move-result v2

    .line 2131
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2132
    .line 2133
    .line 2134
    and-int/lit8 v3, v2, 0x6

    .line 2135
    .line 2136
    if-nez v3, :cond_42

    .line 2137
    .line 2138
    invoke-virtual {v1, v0}, Lib2;->i(Ljava/lang/Object;)Z

    .line 2139
    .line 2140
    .line 2141
    move-result v3

    .line 2142
    if-eqz v3, :cond_41

    .line 2143
    .line 2144
    const/4 v11, 0x4

    .line 2145
    :cond_41
    or-int/2addr v2, v11

    .line 2146
    :cond_42
    and-int/lit8 v3, v2, 0x13

    .line 2147
    .line 2148
    if-eq v3, v6, :cond_43

    .line 2149
    .line 2150
    move v3, v15

    .line 2151
    goto :goto_1e

    .line 2152
    :cond_43
    move v3, v7

    .line 2153
    :goto_1e
    and-int/lit8 v4, v2, 0x1

    .line 2154
    .line 2155
    invoke-virtual {v1, v4, v3}, Lib2;->X(IZ)Z

    .line 2156
    .line 2157
    .line 2158
    move-result v3

    .line 2159
    if-eqz v3, :cond_45

    .line 2160
    .line 2161
    sget-object v3, Lag6;->c:La32;

    .line 2162
    .line 2163
    invoke-static {v1}, Lfa3;->O(Lib2;)J

    .line 2164
    .line 2165
    .line 2166
    move-result-wide v4

    .line 2167
    sget-object v6, Ld70;->V:Lus2;

    .line 2168
    .line 2169
    invoke-static {v3, v4, v5, v6}, Lhb;->D(Lw04;JLma6;)Lw04;

    .line 2170
    .line 2171
    .line 2172
    move-result-object v3

    .line 2173
    sget-object v4, Lam7;->w:Ljava/util/WeakHashMap;

    .line 2174
    .line 2175
    invoke-static {v1}, Lyq6;->j(Lib2;)Lam7;

    .line 2176
    .line 2177
    .line 2178
    move-result-object v4

    .line 2179
    iget-object v4, v4, Lam7;->l:Luc7;

    .line 2180
    .line 2181
    const/16 v5, 0xf

    .line 2182
    .line 2183
    invoke-static {v4, v5, v3}, Luj6;->g(Luc7;ILw04;)Lw04;

    .line 2184
    .line 2185
    .line 2186
    move-result-object v3

    .line 2187
    sget-object v4, Lu6;->k:Lt20;

    .line 2188
    .line 2189
    invoke-static {v4, v7}, Lnb0;->c(Lt20;Z)Lor3;

    .line 2190
    .line 2191
    .line 2192
    move-result-object v4

    .line 2193
    iget-wide v5, v1, Lib2;->T:J

    .line 2194
    .line 2195
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 2196
    .line 2197
    .line 2198
    move-result v5

    .line 2199
    invoke-virtual {v1}, Lib2;->m()Liz4;

    .line 2200
    .line 2201
    .line 2202
    move-result-object v6

    .line 2203
    invoke-static {v1, v3}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 2204
    .line 2205
    .line 2206
    move-result-object v3

    .line 2207
    sget-object v7, Lx11;->d:Lu6;

    .line 2208
    .line 2209
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2210
    .line 2211
    .line 2212
    invoke-virtual {v1}, Lib2;->j0()V

    .line 2213
    .line 2214
    .line 2215
    iget-boolean v7, v1, Lib2;->S:Z

    .line 2216
    .line 2217
    if-eqz v7, :cond_44

    .line 2218
    .line 2219
    sget-object v7, Laa3;->a0:Lg53;

    .line 2220
    .line 2221
    invoke-virtual {v1, v7}, Lib2;->l(Lu92;)V

    .line 2222
    .line 2223
    .line 2224
    goto :goto_1f

    .line 2225
    :cond_44
    invoke-virtual {v1}, Lib2;->s0()V

    .line 2226
    .line 2227
    .line 2228
    :goto_1f
    sget-object v7, Lu6;->S:Lc11;

    .line 2229
    .line 2230
    invoke-static {v7, v1, v4}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 2231
    .line 2232
    .line 2233
    sget-object v4, Lu6;->R:Lc11;

    .line 2234
    .line 2235
    invoke-static {v4, v1, v6}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 2236
    .line 2237
    .line 2238
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2239
    .line 2240
    .line 2241
    move-result-object v4

    .line 2242
    sget-object v5, Lu6;->T:Lc11;

    .line 2243
    .line 2244
    invoke-static {v5, v1, v4}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 2245
    .line 2246
    .line 2247
    invoke-static {v1}, Lwt6;->m(Lib2;)V

    .line 2248
    .line 2249
    .line 2250
    sget-object v4, Lu6;->Q:Lc11;

    .line 2251
    .line 2252
    invoke-static {v4, v1, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 2253
    .line 2254
    .line 2255
    and-int/lit8 v2, v2, 0xe

    .line 2256
    .line 2257
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2258
    .line 2259
    .line 2260
    move-result-object v2

    .line 2261
    invoke-interface {v0, v1, v2}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2262
    .line 2263
    .line 2264
    invoke-virtual {v1, v15}, Lib2;->r(Z)V

    .line 2265
    .line 2266
    .line 2267
    goto :goto_20

    .line 2268
    :cond_45
    invoke-virtual {v1}, Lib2;->a0()V

    .line 2269
    .line 2270
    .line 2271
    :goto_20
    return-object v14

    .line 2272
    nop

    .line 2273
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
