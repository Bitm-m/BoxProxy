.class public final synthetic Laq4;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:Z

.field public final synthetic j:Lu85;

.field public final synthetic k:Z

.field public final synthetic l:Llp4;

.field public final synthetic m:Landroid/content/Context;

.field public final synthetic n:Ljava/lang/String;

.field public final synthetic o:Z

.field public final synthetic p:Z

.field public final synthetic q:Z

.field public final synthetic r:Z


# direct methods
.method public synthetic constructor <init>(ZLu85;ZLlp4;Landroid/content/Context;Ljava/lang/String;ZZZZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Laq4;->i:Z

    .line 5
    .line 6
    iput-object p2, p0, Laq4;->j:Lu85;

    .line 7
    .line 8
    iput-boolean p3, p0, Laq4;->k:Z

    .line 9
    .line 10
    iput-object p4, p0, Laq4;->l:Llp4;

    .line 11
    .line 12
    iput-object p5, p0, Laq4;->m:Landroid/content/Context;

    .line 13
    .line 14
    iput-object p6, p0, Laq4;->n:Ljava/lang/String;

    .line 15
    .line 16
    iput-boolean p7, p0, Laq4;->o:Z

    .line 17
    .line 18
    iput-boolean p8, p0, Laq4;->p:Z

    .line 19
    .line 20
    iput-boolean p9, p0, Laq4;->q:Z

    .line 21
    .line 22
    iput-boolean p10, p0, Laq4;->r:Z

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Laq4;->j:Lu85;

    .line 4
    .line 5
    iget-object v2, v1, Lu85;->c:Lef5;

    .line 6
    .line 7
    move-object/from16 v3, p1

    .line 8
    .line 9
    check-cast v3, Lvx0;

    .line 10
    .line 11
    move-object/from16 v9, p2

    .line 12
    .line 13
    check-cast v9, Lib2;

    .line 14
    .line 15
    move-object/from16 v4, p3

    .line 16
    .line 17
    check-cast v4, Ljava/lang/Integer;

    .line 18
    .line 19
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    and-int/lit8 v3, v4, 0x11

    .line 27
    .line 28
    const/4 v13, 0x1

    .line 29
    const/16 v15, 0x10

    .line 30
    .line 31
    if-eq v3, v15, :cond_0

    .line 32
    .line 33
    move v3, v13

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    const/4 v3, 0x0

    .line 36
    :goto_0
    and-int/2addr v4, v13

    .line 37
    invoke-virtual {v9, v4, v3}, Lib2;->X(IZ)Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_10

    .line 42
    .line 43
    const v3, 0x7f0f038e

    .line 44
    .line 45
    .line 46
    invoke-static {v3, v9}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v6

    .line 50
    iget-boolean v3, v0, Laq4;->i:Z

    .line 51
    .line 52
    if-eqz v3, :cond_1

    .line 53
    .line 54
    sget-object v4, Lu85;->f:Ljava/util/Set;

    .line 55
    .line 56
    invoke-interface {v4, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    if-eqz v4, :cond_1

    .line 61
    .line 62
    move v8, v13

    .line 63
    goto :goto_1

    .line 64
    :cond_1
    const/4 v8, 0x0

    .line 65
    :goto_1
    iget-object v4, v0, Laq4;->l:Llp4;

    .line 66
    .line 67
    invoke-virtual {v9, v4}, Lib2;->g(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    iget-object v7, v0, Laq4;->m:Landroid/content/Context;

    .line 72
    .line 73
    invoke-virtual {v9, v7}, Lib2;->i(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v10

    .line 77
    or-int/2addr v5, v10

    .line 78
    iget-object v10, v0, Laq4;->n:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {v9, v10}, Lib2;->g(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v11

    .line 84
    or-int/2addr v5, v11

    .line 85
    invoke-virtual {v9}, Lib2;->S()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v11

    .line 89
    sget-object v12, Lg21;->a:Ley0;

    .line 90
    .line 91
    if-nez v5, :cond_2

    .line 92
    .line 93
    if-ne v11, v12, :cond_3

    .line 94
    .line 95
    :cond_2
    new-instance v11, Lpp4;

    .line 96
    .line 97
    const/16 v5, 0xf

    .line 98
    .line 99
    invoke-direct {v11, v4, v7, v10, v5}, Lpp4;-><init>(Llp4;Landroid/content/Context;Ljava/lang/String;B)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v9, v11}, Lib2;->p0(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    :cond_3
    move-object v5, v11

    .line 106
    check-cast v5, Lfa2;

    .line 107
    .line 108
    const/4 v11, 0x0

    .line 109
    move-object/from16 v16, v12

    .line 110
    .line 111
    const/16 v12, 0x1ff8

    .line 112
    .line 113
    move-object/from16 v17, v4

    .line 114
    .line 115
    iget-boolean v4, v0, Laq4;->k:Z

    .line 116
    .line 117
    move-object/from16 v18, v7

    .line 118
    .line 119
    const/4 v7, 0x0

    .line 120
    move-object/from16 v19, v10

    .line 121
    .line 122
    const/4 v10, 0x0

    .line 123
    move-object/from16 v13, v16

    .line 124
    .line 125
    move/from16 v16, v3

    .line 126
    .line 127
    move-object v3, v13

    .line 128
    move-object/from16 v13, v17

    .line 129
    .line 130
    move-object/from16 v14, v18

    .line 131
    .line 132
    move-object/from16 v15, v19

    .line 133
    .line 134
    invoke-static/range {v4 .. v12}, Lms6;->a(ZLfa2;Ljava/lang/String;Lyz0;ZLib2;III)V

    .line 135
    .line 136
    .line 137
    const v4, 0x7f0f0391

    .line 138
    .line 139
    .line 140
    invoke-static {v4, v9}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v6

    .line 144
    if-eqz v16, :cond_4

    .line 145
    .line 146
    sget-object v4, Lu85;->g:Ljava/util/Set;

    .line 147
    .line 148
    invoke-interface {v4, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-eqz v4, :cond_4

    .line 153
    .line 154
    const/4 v8, 0x1

    .line 155
    goto :goto_2

    .line 156
    :cond_4
    const/4 v8, 0x0

    .line 157
    :goto_2
    invoke-virtual {v9, v13}, Lib2;->g(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v4

    .line 161
    invoke-virtual {v9, v14}, Lib2;->i(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v5

    .line 165
    or-int/2addr v4, v5

    .line 166
    invoke-virtual {v9, v15}, Lib2;->g(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result v5

    .line 170
    or-int/2addr v4, v5

    .line 171
    invoke-virtual {v9}, Lib2;->S()Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v5

    .line 175
    if-nez v4, :cond_5

    .line 176
    .line 177
    if-ne v5, v3, :cond_6

    .line 178
    .line 179
    :cond_5
    new-instance v5, Lpp4;

    .line 180
    .line 181
    const/16 v4, 0x10

    .line 182
    .line 183
    invoke-direct {v5, v13, v14, v15, v4}, Lpp4;-><init>(Llp4;Landroid/content/Context;Ljava/lang/String;B)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v9, v5}, Lib2;->p0(Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    :cond_6
    check-cast v5, Lfa2;

    .line 190
    .line 191
    const/4 v11, 0x0

    .line 192
    const/16 v12, 0x1ff8

    .line 193
    .line 194
    iget-boolean v4, v0, Laq4;->o:Z

    .line 195
    .line 196
    const/4 v7, 0x0

    .line 197
    const/4 v10, 0x0

    .line 198
    invoke-static/range {v4 .. v12}, Lms6;->a(ZLfa2;Ljava/lang/String;Lyz0;ZLib2;III)V

    .line 199
    .line 200
    .line 201
    const v4, 0x7f0f0380

    .line 202
    .line 203
    .line 204
    invoke-static {v4, v9}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v6

    .line 208
    if-eqz v16, :cond_7

    .line 209
    .line 210
    iget-object v4, v1, Lu85;->b:Ldf5;

    .line 211
    .line 212
    sget-object v5, Ldf5;->m:Ldf5;

    .line 213
    .line 214
    if-ne v4, v5, :cond_7

    .line 215
    .line 216
    sget-object v4, Lu85;->h:Ljava/util/Set;

    .line 217
    .line 218
    invoke-interface {v4, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    move-result v2

    .line 222
    if-eqz v2, :cond_7

    .line 223
    .line 224
    const/4 v8, 0x1

    .line 225
    goto :goto_3

    .line 226
    :cond_7
    const/4 v8, 0x0

    .line 227
    :goto_3
    invoke-virtual {v9, v13}, Lib2;->g(Ljava/lang/Object;)Z

    .line 228
    .line 229
    .line 230
    move-result v2

    .line 231
    invoke-virtual {v9, v14}, Lib2;->i(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v4

    .line 235
    or-int/2addr v2, v4

    .line 236
    invoke-virtual {v9, v15}, Lib2;->g(Ljava/lang/Object;)Z

    .line 237
    .line 238
    .line 239
    move-result v4

    .line 240
    or-int/2addr v2, v4

    .line 241
    invoke-virtual {v9}, Lib2;->S()Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v4

    .line 245
    if-nez v2, :cond_8

    .line 246
    .line 247
    if-ne v4, v3, :cond_9

    .line 248
    .line 249
    :cond_8
    new-instance v4, Lpp4;

    .line 250
    .line 251
    const/16 v2, 0x11

    .line 252
    .line 253
    invoke-direct {v4, v13, v14, v15, v2}, Lpp4;-><init>(Llp4;Landroid/content/Context;Ljava/lang/String;B)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {v9, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    :cond_9
    move-object v5, v4

    .line 260
    check-cast v5, Lfa2;

    .line 261
    .line 262
    const/4 v11, 0x0

    .line 263
    const/16 v12, 0x1ff8

    .line 264
    .line 265
    iget-boolean v4, v0, Laq4;->p:Z

    .line 266
    .line 267
    const/4 v7, 0x0

    .line 268
    const/4 v10, 0x0

    .line 269
    invoke-static/range {v4 .. v12}, Lms6;->a(ZLfa2;Ljava/lang/String;Lyz0;ZLib2;III)V

    .line 270
    .line 271
    .line 272
    const v2, 0x7f0f038f

    .line 273
    .line 274
    .line 275
    invoke-static {v2, v9}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v6

    .line 279
    if-eqz v16, :cond_a

    .line 280
    .line 281
    invoke-virtual {v1}, Lu85;->e()Z

    .line 282
    .line 283
    .line 284
    move-result v2

    .line 285
    if-eqz v2, :cond_a

    .line 286
    .line 287
    const/4 v8, 0x1

    .line 288
    goto :goto_4

    .line 289
    :cond_a
    const/4 v8, 0x0

    .line 290
    :goto_4
    invoke-virtual {v9, v13}, Lib2;->g(Ljava/lang/Object;)Z

    .line 291
    .line 292
    .line 293
    move-result v2

    .line 294
    invoke-virtual {v9, v14}, Lib2;->i(Ljava/lang/Object;)Z

    .line 295
    .line 296
    .line 297
    move-result v4

    .line 298
    or-int/2addr v2, v4

    .line 299
    invoke-virtual {v9, v15}, Lib2;->g(Ljava/lang/Object;)Z

    .line 300
    .line 301
    .line 302
    move-result v4

    .line 303
    or-int/2addr v2, v4

    .line 304
    invoke-virtual {v9}, Lib2;->S()Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object v4

    .line 308
    if-nez v2, :cond_b

    .line 309
    .line 310
    if-ne v4, v3, :cond_c

    .line 311
    .line 312
    :cond_b
    new-instance v4, Lpp4;

    .line 313
    .line 314
    const/16 v2, 0x12

    .line 315
    .line 316
    invoke-direct {v4, v13, v14, v15, v2}, Lpp4;-><init>(Llp4;Landroid/content/Context;Ljava/lang/String;B)V

    .line 317
    .line 318
    .line 319
    invoke-virtual {v9, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 320
    .line 321
    .line 322
    :cond_c
    move-object v5, v4

    .line 323
    check-cast v5, Lfa2;

    .line 324
    .line 325
    const/4 v11, 0x0

    .line 326
    const/16 v12, 0x1ff8

    .line 327
    .line 328
    iget-boolean v4, v0, Laq4;->q:Z

    .line 329
    .line 330
    const/4 v7, 0x0

    .line 331
    const/4 v10, 0x0

    .line 332
    invoke-static/range {v4 .. v12}, Lms6;->a(ZLfa2;Ljava/lang/String;Lyz0;ZLib2;III)V

    .line 333
    .line 334
    .line 335
    const v2, 0x7f0f0390

    .line 336
    .line 337
    .line 338
    invoke-static {v2, v9}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v6

    .line 342
    if-eqz v16, :cond_d

    .line 343
    .line 344
    invoke-virtual {v1}, Lu85;->f()Z

    .line 345
    .line 346
    .line 347
    move-result v1

    .line 348
    if-eqz v1, :cond_d

    .line 349
    .line 350
    const/4 v8, 0x1

    .line 351
    goto :goto_5

    .line 352
    :cond_d
    const/4 v8, 0x0

    .line 353
    :goto_5
    invoke-virtual {v9, v13}, Lib2;->g(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    move-result v1

    .line 357
    invoke-virtual {v9, v14}, Lib2;->i(Ljava/lang/Object;)Z

    .line 358
    .line 359
    .line 360
    move-result v2

    .line 361
    or-int/2addr v1, v2

    .line 362
    invoke-virtual {v9, v15}, Lib2;->g(Ljava/lang/Object;)Z

    .line 363
    .line 364
    .line 365
    move-result v2

    .line 366
    or-int/2addr v1, v2

    .line 367
    invoke-virtual {v9}, Lib2;->S()Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v2

    .line 371
    if-nez v1, :cond_e

    .line 372
    .line 373
    if-ne v2, v3, :cond_f

    .line 374
    .line 375
    :cond_e
    new-instance v2, Lpp4;

    .line 376
    .line 377
    const/16 v1, 0x13

    .line 378
    .line 379
    invoke-direct {v2, v13, v14, v15, v1}, Lpp4;-><init>(Llp4;Landroid/content/Context;Ljava/lang/String;B)V

    .line 380
    .line 381
    .line 382
    invoke-virtual {v9, v2}, Lib2;->p0(Ljava/lang/Object;)V

    .line 383
    .line 384
    .line 385
    :cond_f
    move-object v5, v2

    .line 386
    check-cast v5, Lfa2;

    .line 387
    .line 388
    const/4 v11, 0x0

    .line 389
    const/16 v12, 0x1ff8

    .line 390
    .line 391
    iget-boolean v4, v0, Laq4;->r:Z

    .line 392
    .line 393
    const/4 v7, 0x0

    .line 394
    const/4 v10, 0x0

    .line 395
    invoke-static/range {v4 .. v12}, Lms6;->a(ZLfa2;Ljava/lang/String;Lyz0;ZLib2;III)V

    .line 396
    .line 397
    .line 398
    goto :goto_6

    .line 399
    :cond_10
    invoke-virtual {v9}, Lib2;->a0()V

    .line 400
    .line 401
    .line 402
    :goto_6
    sget-object v0, Lxc7;->a:Lxc7;

    .line 403
    .line 404
    return-object v0
.end method
