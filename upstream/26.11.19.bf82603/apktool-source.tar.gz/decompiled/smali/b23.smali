.class public interface abstract Lb23;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lkl1;


# virtual methods
.method public abstract F()Z
.end method

.method public abstract getLayoutDirection()Lh93;
.end method
