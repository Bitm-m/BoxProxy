.class public final Laj;
.super Landroid/text/SegmentFinder;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final synthetic a:Le27;


# direct methods
.method public constructor <init>(Le27;)V
    .locals 0

    .line 1
    iput-object p1, p0, Laj;->a:Le27;

    .line 2
    .line 3
    invoke-direct {p0}, Landroid/text/SegmentFinder;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final nextEndBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Le27;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Le27;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final nextStartBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Le27;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Le27;->l(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final previousEndBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Le27;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Le27;->m(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final previousStartBoundary(I)I
    .locals 0

    .line 1
    iget-object p0, p0, Laj;->a:Le27;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Le27;->d(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
