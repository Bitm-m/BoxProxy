.class public final Lb4;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic a:B

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lb4;->a:B

    .line 2
    .line 3
    iput-object p1, p0, Lb4;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Lp15;Lea1;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v6, p2

    .line 6
    .line 7
    iget-byte v2, v0, Lb4;->a:B

    .line 8
    .line 9
    const/4 v3, 0x3

    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v5, 0x2

    .line 12
    const/4 v7, 0x1

    .line 13
    const/4 v8, 0x0

    .line 14
    sget-object v9, Lxc7;->a:Lxc7;

    .line 15
    .line 16
    sget-object v10, Lof1;->i:Lof1;

    .line 17
    .line 18
    iget-object v0, v0, Lb4;->b:Ljava/lang/Object;

    .line 19
    .line 20
    packed-switch v2, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    new-instance v2, Lou;

    .line 24
    .line 25
    check-cast v0, Lnx6;

    .line 26
    .line 27
    const/16 v3, 0x10

    .line 28
    .line 29
    invoke-direct {v2, v0, v1, v8, v3}, Lou;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 30
    .line 31
    .line 32
    invoke-static {v2, v6}, Ljn;->D(Lja2;Lea1;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    if-ne v0, v10, :cond_0

    .line 37
    .line 38
    move-object v9, v0

    .line 39
    :cond_0
    return-object v9

    .line 40
    :pswitch_0
    new-instance v11, Lxb6;

    .line 41
    .line 42
    move-object v13, v0

    .line 43
    check-cast v13, Lcw6;

    .line 44
    .line 45
    const/16 v17, 0x0

    .line 46
    .line 47
    const/16 v18, 0x8

    .line 48
    .line 49
    const/4 v12, 0x1

    .line 50
    const-class v14, Lcw6;

    .line 51
    .line 52
    const-string v15, "tryShowContextMenu"

    .line 53
    .line 54
    const-string v16, "tryShowContextMenu-k-4lQ0M(J)V"

    .line 55
    .line 56
    invoke-direct/range {v11 .. v18}, Lxb6;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 57
    .line 58
    .line 59
    new-instance v0, Lgc;

    .line 60
    .line 61
    invoke-direct {v0, v11, v8, v7}, Lgc;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 62
    .line 63
    .line 64
    invoke-static {v1, v0, v6}, Lmm0;->z(Lp15;Lja2;Lea1;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-eq v0, v10, :cond_1

    .line 69
    .line 70
    move-object v0, v9

    .line 71
    :cond_1
    if-ne v0, v10, :cond_2

    .line 72
    .line 73
    move-object v9, v0

    .line 74
    :cond_2
    return-object v9

    .line 75
    :pswitch_1
    new-instance v2, Luc3;

    .line 76
    .line 77
    check-cast v0, Lpn6;

    .line 78
    .line 79
    invoke-direct {v2, v0, v8, v3}, Luc3;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 80
    .line 81
    .line 82
    invoke-static {v1, v2, v6}, Lmm0;->z(Lp15;Lja2;Lea1;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    if-ne v0, v10, :cond_3

    .line 87
    .line 88
    move-object v9, v0

    .line 89
    :cond_3
    return-object v9

    .line 90
    :pswitch_2
    check-cast v0, Lz66;

    .line 91
    .line 92
    iget-object v2, v0, Lz66;->D:Lb76;

    .line 93
    .line 94
    iget-object v0, v0, Lz66;->C:La76;

    .line 95
    .line 96
    invoke-static {v1, v2, v0, v6}, Lbb3;->t(Lp15;Ls14;Lrw6;Lea1;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-ne v0, v10, :cond_4

    .line 101
    .line 102
    move-object v9, v0

    .line 103
    :cond_4
    return-object v9

    .line 104
    :pswitch_3
    check-cast v0, Lu66;

    .line 105
    .line 106
    iget-object v0, v0, Lu66;->E:Lwa3;

    .line 107
    .line 108
    invoke-interface {v0}, Lwa3;->getValue()Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    check-cast v0, Ls14;

    .line 113
    .line 114
    invoke-static {v1, v0, v8, v6}, Lbb3;->t(Lp15;Ls14;Lrw6;Lea1;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    if-ne v0, v10, :cond_5

    .line 119
    .line 120
    move-object v9, v0

    .line 121
    :cond_5
    return-object v9

    .line 122
    :pswitch_4
    new-instance v2, Lx10;

    .line 123
    .line 124
    check-cast v0, Lx56;

    .line 125
    .line 126
    invoke-direct {v2, v0, v8, v3}, Lx10;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 127
    .line 128
    .line 129
    move-object v0, v1

    .line 130
    check-cast v0, Lcs6;

    .line 131
    .line 132
    invoke-virtual {v0, v2, v6}, Lcs6;->F1(Lja2;Lea1;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    if-ne v0, v10, :cond_6

    .line 137
    .line 138
    move-object v9, v0

    .line 139
    :cond_6
    return-object v9

    .line 140
    :pswitch_5
    check-cast v0, Lrw6;

    .line 141
    .line 142
    new-instance v2, Lou;

    .line 143
    .line 144
    const/4 v3, 0x5

    .line 145
    invoke-direct {v2, v1, v0, v8, v3}, Lou;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 146
    .line 147
    .line 148
    invoke-static {v2, v6}, Ljn;->D(Lja2;Lea1;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    if-eq v0, v10, :cond_7

    .line 153
    .line 154
    move-object v0, v9

    .line 155
    :cond_7
    if-ne v0, v10, :cond_8

    .line 156
    .line 157
    move-object v9, v0

    .line 158
    :cond_8
    return-object v9

    .line 159
    :pswitch_6
    new-instance v2, Lx10;

    .line 160
    .line 161
    check-cast v0, Lhr4;

    .line 162
    .line 163
    invoke-direct {v2, v0, v8, v5}, Lx10;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 164
    .line 165
    .line 166
    move-object v0, v1

    .line 167
    check-cast v0, Lcs6;

    .line 168
    .line 169
    invoke-virtual {v0, v2, v6}, Lcs6;->F1(Lja2;Lea1;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    if-ne v0, v10, :cond_9

    .line 174
    .line 175
    move-object v9, v0

    .line 176
    :cond_9
    return-object v9

    .line 177
    :pswitch_7
    new-instance v2, Lb42;

    .line 178
    .line 179
    check-cast v0, Lak1;

    .line 180
    .line 181
    const/16 v3, 0x9

    .line 182
    .line 183
    invoke-direct {v2, v1, v0, v8, v3}, Lb42;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 184
    .line 185
    .line 186
    invoke-static {v2, v6}, Ljn;->D(Lja2;Lea1;)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    if-ne v0, v10, :cond_a

    .line 191
    .line 192
    move-object v9, v0

    .line 193
    :cond_a
    return-object v9

    .line 194
    :pswitch_8
    check-cast v0, Lo13;

    .line 195
    .line 196
    new-instance v12, Ll13;

    .line 197
    .line 198
    invoke-direct {v12, v0, v7}, Ll13;-><init>(Lo13;B)V

    .line 199
    .line 200
    .line 201
    new-instance v15, Ll13;

    .line 202
    .line 203
    invoke-direct {v15, v0, v5}, Ll13;-><init>(Lo13;B)V

    .line 204
    .line 205
    .line 206
    new-instance v14, Ltv2;

    .line 207
    .line 208
    invoke-direct {v14, v0, v5}, Ltv2;-><init>(Ljava/lang/Object;B)V

    .line 209
    .line 210
    .line 211
    new-instance v13, Lt;

    .line 212
    .line 213
    const/16 v2, 0x15

    .line 214
    .line 215
    invoke-direct {v13, v0, v2}, Lt;-><init>(Ljava/lang/Object;B)V

    .line 216
    .line 217
    .line 218
    new-instance v11, Lrq1;

    .line 219
    .line 220
    const/16 v16, 0x0

    .line 221
    .line 222
    invoke-direct/range {v11 .. v16}, Lrq1;-><init>(Lfa2;Lja2;Lu92;Lfa2;Lea1;)V

    .line 223
    .line 224
    .line 225
    invoke-static {v1, v11, v6}, Lmm0;->z(Lp15;Lja2;Lea1;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    if-eq v0, v10, :cond_b

    .line 230
    .line 231
    move-object v0, v9

    .line 232
    :cond_b
    if-ne v0, v10, :cond_c

    .line 233
    .line 234
    move-object v9, v0

    .line 235
    :cond_c
    return-object v9

    .line 236
    :pswitch_9
    check-cast v0, Lzh1;

    .line 237
    .line 238
    new-instance v12, Lsh1;

    .line 239
    .line 240
    invoke-direct {v12, v0, v4}, Lsh1;-><init>(Lzh1;B)V

    .line 241
    .line 242
    .line 243
    new-instance v15, Lsh1;

    .line 244
    .line 245
    invoke-direct {v15, v0, v7}, Lsh1;-><init>(Lzh1;B)V

    .line 246
    .line 247
    .line 248
    new-instance v14, Lth1;

    .line 249
    .line 250
    invoke-direct {v14, v0, v4}, Lth1;-><init>(Lzh1;B)V

    .line 251
    .line 252
    .line 253
    new-instance v13, Lvc1;

    .line 254
    .line 255
    invoke-direct {v13, v0, v1, v7}, Lvc1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 256
    .line 257
    .line 258
    new-instance v11, Lrq1;

    .line 259
    .line 260
    const/16 v16, 0x0

    .line 261
    .line 262
    invoke-direct/range {v11 .. v16}, Lrq1;-><init>(Lfa2;Lja2;Lu92;Lfa2;Lea1;)V

    .line 263
    .line 264
    .line 265
    invoke-static {v1, v11, v6}, Lmm0;->z(Lp15;Lja2;Lea1;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    if-eq v0, v10, :cond_d

    .line 270
    .line 271
    move-object v0, v9

    .line 272
    :cond_d
    if-ne v0, v10, :cond_e

    .line 273
    .line 274
    move-object v9, v0

    .line 275
    :cond_e
    return-object v9

    .line 276
    :pswitch_a
    new-instance v2, Lgc;

    .line 277
    .line 278
    check-cast v0, Lhc;

    .line 279
    .line 280
    invoke-direct {v2, v0, v8, v4}, Lgc;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 281
    .line 282
    .line 283
    invoke-static {v1, v2, v6}, Lmm0;->z(Lp15;Lja2;Lea1;)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v0

    .line 287
    if-ne v0, v10, :cond_f

    .line 288
    .line 289
    move-object v9, v0

    .line 290
    :cond_f
    return-object v9

    .line 291
    :pswitch_b
    move-object v2, v0

    .line 292
    check-cast v2, Lp45;

    .line 293
    .line 294
    new-instance v3, Ly3;

    .line 295
    .line 296
    const/4 v4, 0x0

    .line 297
    invoke-direct {v3, v2, v4}, Ly3;-><init>(Lp45;Lea1;)V

    .line 298
    .line 299
    .line 300
    new-instance v0, Lx3;

    .line 301
    .line 302
    const/4 v5, 0x0

    .line 303
    invoke-direct/range {v0 .. v5}, Lx3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 304
    .line 305
    .line 306
    invoke-static {v0, v6}, Ljn;->D(Lja2;Lea1;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    if-eq v0, v10, :cond_10

    .line 311
    .line 312
    move-object v0, v9

    .line 313
    :cond_10
    if-ne v0, v10, :cond_11

    .line 314
    .line 315
    move-object v9, v0

    .line 316
    :cond_11
    return-object v9

    .line 317
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
