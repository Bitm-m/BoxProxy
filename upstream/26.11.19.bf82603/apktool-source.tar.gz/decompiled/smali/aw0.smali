.class public final Law0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final a:[F

.field public static final b:[F

.field public static final c:Lq77;

.field public static final d:Lq77;

.field public static final e:Lgn5;

.field public static final f:Lgn5;

.field public static final g:Lgn5;

.field public static final h:Lgn5;

.field public static final i:Lgn5;

.field public static final j:Lgn5;

.field public static final k:Lgn5;

.field public static final l:Lgn5;

.field public static final m:Lgn5;

.field public static final n:Lgn5;

.field public static final o:Lgn5;

.field public static final p:Lgn5;

.field public static final q:Lgn5;

.field public static final r:Lgn5;

.field public static final s:La83;

.field public static final t:La83;

.field public static final u:Lgn5;

.field public static final v:Lgn5;

.field public static final w:Lgn5;

.field public static final x:Lwl4;

.field public static final y:[Lyv0;


# direct methods
.method static constructor <clinit>()V
    .locals 52

    .line 1
    const/4 v0, 0x6

    .line 2
    new-array v3, v0, [F

    .line 3
    .line 4
    fill-array-data v3, :array_0

    .line 5
    .line 6
    .line 7
    sput-object v3, Law0;->a:[F

    .line 8
    .line 9
    new-array v12, v0, [F

    .line 10
    .line 11
    fill-array-data v12, :array_1

    .line 12
    .line 13
    .line 14
    sput-object v12, Law0;->b:[F

    .line 15
    .line 16
    new-array v15, v0, [F

    .line 17
    .line 18
    fill-array-data v15, :array_2

    .line 19
    .line 20
    .line 21
    new-instance v16, Lq77;

    .line 22
    .line 23
    const-wide v23, 0x3fb3d0722149b580L    # 0.07739938080495357

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    const-wide v25, 0x3fa4b5dcc63f1412L    # 0.04045

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    const-wide v17, 0x4003333333333333L    # 2.4

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    const-wide v19, 0x3fee54edcd0aeb60L    # 0.9478672985781991

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    const-wide v21, 0x3faab1232f514a03L    # 0.05213270142180095

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    invoke-direct/range {v16 .. v26}, Lq77;-><init>(DDDDD)V

    .line 49
    .line 50
    .line 51
    new-instance v17, Lq77;

    .line 52
    .line 53
    const-wide v24, 0x3fb3d0722149b580L    # 0.07739938080495357

    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    const-wide v26, 0x3fa4b5dcc63f1412L    # 0.04045

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    const-wide v18, 0x400199999999999aL    # 2.2

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    const-wide v20, 0x3fee54edcd0aeb60L    # 0.9478672985781991

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    const-wide v22, 0x3faab1232f514a03L    # 0.05213270142180095

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-direct/range {v17 .. v27}, Lq77;-><init>(DDDDD)V

    .line 79
    .line 80
    .line 81
    new-instance v18, Lq77;

    .line 82
    .line 83
    const-wide v29, 0x3fe1eac9e840f18dL    # 0.55991073

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    const-wide v31, -0x401a1076f23e9022L    # -0.685490157

    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    const-wide/high16 v19, -0x3ff8000000000000L    # -3.0

    .line 94
    .line 95
    const-wide/high16 v21, 0x4000000000000000L    # 2.0

    .line 96
    .line 97
    const-wide/high16 v23, 0x4000000000000000L    # 2.0

    .line 98
    .line 99
    const-wide v25, 0x40165e05183e19b4L    # 5.591816309728916

    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    const-wide v27, 0x3fd23803fd659be6L    # 0.28466892

    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    invoke-direct/range {v18 .. v32}, Lq77;-><init>(DDDDDDD)V

    .line 110
    .line 111
    .line 112
    sput-object v18, Law0;->c:Lq77;

    .line 113
    .line 114
    new-instance v19, Lq77;

    .line 115
    .line 116
    const-wide v30, -0x3fcd500000000000L    # -18.6875

    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    const-wide v32, 0x40191c0d56e7162bL    # 6.277394636015326

    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    const-wide/high16 v20, -0x4000000000000000L    # -2.0

    .line 127
    .line 128
    const-wide v22, -0x40071dce7cd03537L    # -1.555223

    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    const-wide v24, 0x3ffdc46b69db65edL    # 1.860454

    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    const-wide v26, 0x3f89f9b5860989b1L    # 0.012683313515655966

    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    const-wide v28, 0x4032da0000000000L    # 18.8515625

    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    invoke-direct/range {v19 .. v33}, Lq77;-><init>(DDDDDDD)V

    .line 149
    .line 150
    .line 151
    move-object/from16 v24, v19

    .line 152
    .line 153
    sput-object v24, Law0;->d:Lq77;

    .line 154
    .line 155
    new-instance v1, Lgn5;

    .line 156
    .line 157
    sget-object v4, Lm71;->y0:Lzj7;

    .line 158
    .line 159
    const/4 v6, 0x0

    .line 160
    const-string v2, "sRGB IEC61966-2.1"

    .line 161
    .line 162
    move-object/from16 v5, v16

    .line 163
    .line 164
    invoke-direct/range {v1 .. v6}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 165
    .line 166
    .line 167
    move-object/from16 v34, v1

    .line 168
    .line 169
    sput-object v34, Law0;->e:Lgn5;

    .line 170
    .line 171
    new-instance v1, Lgn5;

    .line 172
    .line 173
    const/high16 v8, 0x3f800000    # 1.0f

    .line 174
    .line 175
    const/4 v9, 0x1

    .line 176
    const-string v2, "sRGB IEC61966-2.1 (Linear)"

    .line 177
    .line 178
    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    .line 179
    .line 180
    const/4 v7, 0x0

    .line 181
    invoke-direct/range {v1 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 182
    .line 183
    .line 184
    move-object/from16 v35, v1

    .line 185
    .line 186
    sput-object v35, Law0;->f:Lgn5;

    .line 187
    .line 188
    new-instance v1, Lgn5;

    .line 189
    .line 190
    new-instance v6, La02;

    .line 191
    .line 192
    const/16 v13, 0xe

    .line 193
    .line 194
    invoke-direct {v6, v13}, La02;-><init>(B)V

    .line 195
    .line 196
    .line 197
    new-instance v7, La02;

    .line 198
    .line 199
    const/16 v14, 0xf

    .line 200
    .line 201
    invoke-direct {v7, v14}, La02;-><init>(B)V

    .line 202
    .line 203
    .line 204
    const v9, 0x40198937    # 2.399f

    .line 205
    .line 206
    .line 207
    const/4 v11, 0x2

    .line 208
    const-string v2, "scRGB-nl IEC 61966-2-2:2003"

    .line 209
    .line 210
    const/4 v5, 0x0

    .line 211
    const v8, -0x40b374bc    # -0.799f

    .line 212
    .line 213
    .line 214
    move-object/from16 v10, v16

    .line 215
    .line 216
    invoke-direct/range {v1 .. v11}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;[FLgp1;Lgp1;FFLq77;I)V

    .line 217
    .line 218
    .line 219
    move-object v10, v1

    .line 220
    sput-object v10, Law0;->g:Lgn5;

    .line 221
    .line 222
    new-instance v1, Lgn5;

    .line 223
    .line 224
    const v8, 0x40eff7cf    # 7.499f

    .line 225
    .line 226
    .line 227
    const/4 v9, 0x3

    .line 228
    const-string v2, "scRGB IEC 61966-2-2:2003"

    .line 229
    .line 230
    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    .line 231
    .line 232
    const/high16 v7, -0x41000000    # -0.5f

    .line 233
    .line 234
    invoke-direct/range {v1 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 235
    .line 236
    .line 237
    move-object v11, v1

    .line 238
    sput-object v11, Law0;->h:Lgn5;

    .line 239
    .line 240
    move-object v7, v4

    .line 241
    new-instance v4, Lgn5;

    .line 242
    .line 243
    new-array v6, v0, [F

    .line 244
    .line 245
    fill-array-data v6, :array_3

    .line 246
    .line 247
    .line 248
    new-instance v36, Lq77;

    .line 249
    .line 250
    const-wide v43, 0x3fcc71c71c71c71cL    # 0.2222222222222222

    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    const-wide v45, 0x3fb4bc6a7ef9db23L    # 0.081

    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    const-wide v37, 0x4001c71c71c71c72L    # 2.2222222222222223

    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    const-wide v39, 0x3fed1e0c942633b7L    # 0.9099181073703367

    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    const-wide v41, 0x3fb70f9b5ece624dL    # 0.09008189262966333

    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    invoke-direct/range {v36 .. v46}, Lq77;-><init>(DDDDD)V

    .line 276
    .line 277
    .line 278
    const/4 v9, 0x4

    .line 279
    const-string v5, "Rec. ITU-R BT.709-5"

    .line 280
    .line 281
    move-object/from16 v8, v36

    .line 282
    .line 283
    invoke-direct/range {v4 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 284
    .line 285
    .line 286
    move-object/from16 v36, v4

    .line 287
    .line 288
    sput-object v36, Law0;->i:Lgn5;

    .line 289
    .line 290
    new-instance v4, Lgn5;

    .line 291
    .line 292
    new-array v6, v0, [F

    .line 293
    .line 294
    fill-array-data v6, :array_4

    .line 295
    .line 296
    .line 297
    new-instance v37, Lq77;

    .line 298
    .line 299
    const-wide v44, 0x3fcc71c71c71c71cL    # 0.2222222222222222

    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    const-wide v46, 0x3fb4d9e83e425aeeL    # 0.08145

    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    const-wide v38, 0x4001c71c71c71c72L    # 2.2222222222222223

    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    const-wide v40, 0x3fed1c03d1b450c3L    # 0.9096697898662786

    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    const-wide v42, 0x3fb71fe1725d79e9L    # 0.09033021013372146

    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    invoke-direct/range {v37 .. v47}, Lq77;-><init>(DDDDD)V

    .line 325
    .line 326
    .line 327
    const/4 v9, 0x5

    .line 328
    const-string v5, "Rec. ITU-R BT.2020-1"

    .line 329
    .line 330
    move-object/from16 v8, v37

    .line 331
    .line 332
    invoke-direct/range {v4 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 333
    .line 334
    .line 335
    move-object/from16 v37, v4

    .line 336
    .line 337
    sput-object v37, Law0;->j:Lgn5;

    .line 338
    .line 339
    new-instance v25, Lgn5;

    .line 340
    .line 341
    new-array v1, v0, [F

    .line 342
    .line 343
    fill-array-data v1, :array_5

    .line 344
    .line 345
    .line 346
    new-instance v2, Lzj7;

    .line 347
    .line 348
    const v5, 0x3ea0c49c    # 0.314f

    .line 349
    .line 350
    .line 351
    const v6, 0x3eb3b646    # 0.351f

    .line 352
    .line 353
    .line 354
    invoke-direct {v2, v5, v6}, Lzj7;-><init>(FF)V

    .line 355
    .line 356
    .line 357
    const/high16 v32, 0x3f800000    # 1.0f

    .line 358
    .line 359
    const/16 v33, 0x6

    .line 360
    .line 361
    const-string v26, "SMPTE RP 431-2-2007 DCI (P3)"

    .line 362
    .line 363
    const-wide v29, 0x4004cccccccccccdL    # 2.6

    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    const/16 v31, 0x0

    .line 369
    .line 370
    move-object/from16 v27, v1

    .line 371
    .line 372
    move-object/from16 v28, v2

    .line 373
    .line 374
    invoke-direct/range {v25 .. v33}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 375
    .line 376
    .line 377
    move-object/from16 v38, v25

    .line 378
    .line 379
    sput-object v38, Law0;->k:Lgn5;

    .line 380
    .line 381
    new-instance v4, Lgn5;

    .line 382
    .line 383
    new-array v6, v0, [F

    .line 384
    .line 385
    fill-array-data v6, :array_6

    .line 386
    .line 387
    .line 388
    const/4 v9, 0x7

    .line 389
    const-string v5, "Display P3"

    .line 390
    .line 391
    move-object/from16 v8, v16

    .line 392
    .line 393
    invoke-direct/range {v4 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 394
    .line 395
    .line 396
    move-object/from16 v39, v4

    .line 397
    .line 398
    move-object/from16 v16, v7

    .line 399
    .line 400
    sput-object v39, Law0;->l:Lgn5;

    .line 401
    .line 402
    new-instance v4, Lgn5;

    .line 403
    .line 404
    sget-object v7, Lm71;->v0:Lzj7;

    .line 405
    .line 406
    new-instance v40, Lq77;

    .line 407
    .line 408
    const-wide v47, 0x3fcc71c71c71c71cL    # 0.2222222222222222

    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    const-wide v49, 0x3fb4bc6a7ef9db23L    # 0.081

    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    const-wide v41, 0x4001c71c71c71c72L    # 2.2222222222222223

    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    const-wide v43, 0x3fed1e0c942633b7L    # 0.9099181073703367

    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    const-wide v45, 0x3fb70f9b5ece624dL    # 0.09008189262966333

    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    invoke-direct/range {v40 .. v50}, Lq77;-><init>(DDDDD)V

    .line 434
    .line 435
    .line 436
    const/16 v9, 0x8

    .line 437
    .line 438
    const-string v5, "NTSC (1953)"

    .line 439
    .line 440
    move-object v6, v12

    .line 441
    move-object/from16 v8, v40

    .line 442
    .line 443
    invoke-direct/range {v4 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 444
    .line 445
    .line 446
    move-object v12, v4

    .line 447
    sput-object v12, Law0;->m:Lgn5;

    .line 448
    .line 449
    new-instance v4, Lgn5;

    .line 450
    .line 451
    new-array v6, v0, [F

    .line 452
    .line 453
    fill-array-data v6, :array_7

    .line 454
    .line 455
    .line 456
    new-instance v40, Lq77;

    .line 457
    .line 458
    invoke-direct/range {v40 .. v50}, Lq77;-><init>(DDDDD)V

    .line 459
    .line 460
    .line 461
    const/16 v9, 0x9

    .line 462
    .line 463
    const-string v5, "SMPTE-C RGB"

    .line 464
    .line 465
    move-object/from16 v7, v16

    .line 466
    .line 467
    move-object/from16 v8, v40

    .line 468
    .line 469
    invoke-direct/range {v4 .. v9}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 470
    .line 471
    .line 472
    move-object/from16 v51, v7

    .line 473
    .line 474
    move-object v7, v4

    .line 475
    move-object/from16 v4, v51

    .line 476
    .line 477
    sput-object v7, Law0;->n:Lgn5;

    .line 478
    .line 479
    new-instance v25, Lgn5;

    .line 480
    .line 481
    new-array v1, v0, [F

    .line 482
    .line 483
    fill-array-data v1, :array_8

    .line 484
    .line 485
    .line 486
    const/16 v33, 0xa

    .line 487
    .line 488
    const-string v26, "Adobe RGB (1998)"

    .line 489
    .line 490
    const-wide v29, 0x400199999999999aL    # 2.2

    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    move-object/from16 v27, v1

    .line 496
    .line 497
    move-object/from16 v28, v4

    .line 498
    .line 499
    invoke-direct/range {v25 .. v33}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 500
    .line 501
    .line 502
    sput-object v25, Law0;->o:Lgn5;

    .line 503
    .line 504
    new-instance v26, Lgn5;

    .line 505
    .line 506
    new-array v1, v0, [F

    .line 507
    .line 508
    fill-array-data v1, :array_9

    .line 509
    .line 510
    .line 511
    sget-object v29, Lm71;->w0:Lzj7;

    .line 512
    .line 513
    new-instance v40, Lq77;

    .line 514
    .line 515
    const-wide/high16 v47, 0x3fb0000000000000L    # 0.0625

    .line 516
    .line 517
    const-wide v49, 0x3f9fff79c842fa51L    # 0.031248

    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    const-wide v41, 0x3ffccccccccccccdL    # 1.8

    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    const-wide/high16 v43, 0x3ff0000000000000L    # 1.0

    .line 528
    .line 529
    const-wide/16 v45, 0x0

    .line 530
    .line 531
    invoke-direct/range {v40 .. v50}, Lq77;-><init>(DDDDD)V

    .line 532
    .line 533
    .line 534
    const/16 v31, 0xb

    .line 535
    .line 536
    const-string v27, "ROMM RGB ISO 22028-2:2013"

    .line 537
    .line 538
    move-object/from16 v28, v1

    .line 539
    .line 540
    move-object/from16 v30, v40

    .line 541
    .line 542
    invoke-direct/range {v26 .. v31}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 543
    .line 544
    .line 545
    sput-object v26, Law0;->p:Lgn5;

    .line 546
    .line 547
    new-instance v40, Lgn5;

    .line 548
    .line 549
    new-array v1, v0, [F

    .line 550
    .line 551
    fill-array-data v1, :array_a

    .line 552
    .line 553
    .line 554
    sget-object v43, Lm71;->x0:Lzj7;

    .line 555
    .line 556
    const v47, 0x477fe000    # 65504.0f

    .line 557
    .line 558
    .line 559
    const/16 v48, 0xc

    .line 560
    .line 561
    const-string v41, "SMPTE ST 2065-1:2012 ACES"

    .line 562
    .line 563
    const-wide/high16 v44, 0x3ff0000000000000L    # 1.0

    .line 564
    .line 565
    const v46, -0x38802000    # -65504.0f

    .line 566
    .line 567
    .line 568
    move-object/from16 v42, v1

    .line 569
    .line 570
    invoke-direct/range {v40 .. v48}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 571
    .line 572
    .line 573
    sput-object v40, Law0;->q:Lgn5;

    .line 574
    .line 575
    new-instance v41, Lgn5;

    .line 576
    .line 577
    new-array v1, v0, [F

    .line 578
    .line 579
    fill-array-data v1, :array_b

    .line 580
    .line 581
    .line 582
    const v48, 0x477fe000    # 65504.0f

    .line 583
    .line 584
    .line 585
    const/16 v49, 0xd

    .line 586
    .line 587
    const-string v42, "Academy S-2014-004 ACEScg"

    .line 588
    .line 589
    const-wide/high16 v45, 0x3ff0000000000000L    # 1.0

    .line 590
    .line 591
    const v47, -0x38802000    # -65504.0f

    .line 592
    .line 593
    .line 594
    move-object/from16 v44, v43

    .line 595
    .line 596
    move-object/from16 v43, v1

    .line 597
    .line 598
    invoke-direct/range {v41 .. v49}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;DFFI)V

    .line 599
    .line 600
    .line 601
    sput-object v41, Law0;->r:Lgn5;

    .line 602
    .line 603
    new-instance v27, La83;

    .line 604
    .line 605
    const-wide v29, 0x300000001L

    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    const/16 v32, 0x1

    .line 611
    .line 612
    const-string v28, "Generic XYZ"

    .line 613
    .line 614
    const/16 v31, 0xe

    .line 615
    .line 616
    invoke-direct/range {v27 .. v32}, La83;-><init>(Ljava/lang/String;JIB)V

    .line 617
    .line 618
    .line 619
    sput-object v27, Law0;->s:La83;

    .line 620
    .line 621
    new-instance v28, La83;

    .line 622
    .line 623
    const/16 v33, 0x0

    .line 624
    .line 625
    const-string v29, "Generic L*a*b*"

    .line 626
    .line 627
    const-wide v30, 0x300000002L

    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    const/16 v32, 0xf

    .line 633
    .line 634
    invoke-direct/range {v28 .. v33}, La83;-><init>(Ljava/lang/String;JIB)V

    .line 635
    .line 636
    .line 637
    move-wide/from16 v8, v30

    .line 638
    .line 639
    sput-object v28, Law0;->t:La83;

    .line 640
    .line 641
    new-instance v1, Lgn5;

    .line 642
    .line 643
    const-string v2, "None"

    .line 644
    .line 645
    const/16 v6, 0x10

    .line 646
    .line 647
    move-object/from16 v5, v17

    .line 648
    .line 649
    invoke-direct/range {v1 .. v6}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;Lq77;I)V

    .line 650
    .line 651
    .line 652
    sput-object v1, Law0;->u:Lgn5;

    .line 653
    .line 654
    move v2, v13

    .line 655
    new-instance v13, Lgn5;

    .line 656
    .line 657
    new-instance v3, La02;

    .line 658
    .line 659
    const/16 v5, 0x10

    .line 660
    .line 661
    invoke-direct {v3, v5}, La02;-><init>(B)V

    .line 662
    .line 663
    .line 664
    new-instance v5, La02;

    .line 665
    .line 666
    const/16 v6, 0x11

    .line 667
    .line 668
    invoke-direct {v5, v6}, La02;-><init>(B)V

    .line 669
    .line 670
    .line 671
    const/high16 v21, 0x3f800000    # 1.0f

    .line 672
    .line 673
    const/16 v23, 0x11

    .line 674
    .line 675
    move v6, v14

    .line 676
    const-string v14, "Hybrid Log Gamma encoding"

    .line 677
    .line 678
    const/16 v17, 0x0

    .line 679
    .line 680
    const/16 v20, 0x0

    .line 681
    .line 682
    move-object/from16 v16, v4

    .line 683
    .line 684
    move-object/from16 v19, v5

    .line 685
    .line 686
    move-object/from16 v22, v18

    .line 687
    .line 688
    move-object/from16 v18, v3

    .line 689
    .line 690
    invoke-direct/range {v13 .. v23}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;[FLgp1;Lgp1;FFLq77;I)V

    .line 691
    .line 692
    .line 693
    move-object v3, v13

    .line 694
    sput-object v3, Law0;->v:Lgn5;

    .line 695
    .line 696
    new-instance v13, Lgn5;

    .line 697
    .line 698
    new-instance v5, La02;

    .line 699
    .line 700
    const/16 v14, 0x12

    .line 701
    .line 702
    invoke-direct {v5, v14}, La02;-><init>(B)V

    .line 703
    .line 704
    .line 705
    new-instance v14, La02;

    .line 706
    .line 707
    move/from16 v29, v0

    .line 708
    .line 709
    const/16 v0, 0x13

    .line 710
    .line 711
    invoke-direct {v14, v0}, La02;-><init>(B)V

    .line 712
    .line 713
    .line 714
    const/16 v23, 0x12

    .line 715
    .line 716
    move-object/from16 v19, v14

    .line 717
    .line 718
    const-string v14, "Perceptual Quantizer encoding"

    .line 719
    .line 720
    move-object/from16 v18, v5

    .line 721
    .line 722
    move-object/from16 v22, v24

    .line 723
    .line 724
    invoke-direct/range {v13 .. v23}, Lgn5;-><init>(Ljava/lang/String;[FLzj7;[FLgp1;Lgp1;FFLq77;I)V

    .line 725
    .line 726
    .line 727
    sput-object v13, Law0;->w:Lgn5;

    .line 728
    .line 729
    new-instance v4, Lwl4;

    .line 730
    .line 731
    const-string v5, "Oklab"

    .line 732
    .line 733
    invoke-direct {v4, v8, v9, v0, v5}, Lyv0;-><init>(JILjava/lang/String;)V

    .line 734
    .line 735
    .line 736
    sput-object v4, Law0;->x:Lwl4;

    .line 737
    .line 738
    const/16 v5, 0x14

    .line 739
    .line 740
    new-array v5, v5, [Lyv0;

    .line 741
    .line 742
    const/4 v8, 0x0

    .line 743
    aput-object v34, v5, v8

    .line 744
    .line 745
    const/4 v8, 0x1

    .line 746
    aput-object v35, v5, v8

    .line 747
    .line 748
    const/4 v8, 0x2

    .line 749
    aput-object v10, v5, v8

    .line 750
    .line 751
    const/4 v8, 0x3

    .line 752
    aput-object v11, v5, v8

    .line 753
    .line 754
    const/4 v8, 0x4

    .line 755
    aput-object v36, v5, v8

    .line 756
    .line 757
    const/4 v8, 0x5

    .line 758
    aput-object v37, v5, v8

    .line 759
    .line 760
    aput-object v38, v5, v29

    .line 761
    .line 762
    const/4 v8, 0x7

    .line 763
    aput-object v39, v5, v8

    .line 764
    .line 765
    const/16 v8, 0x8

    .line 766
    .line 767
    aput-object v12, v5, v8

    .line 768
    .line 769
    const/16 v8, 0x9

    .line 770
    .line 771
    aput-object v7, v5, v8

    .line 772
    .line 773
    const/16 v7, 0xa

    .line 774
    .line 775
    aput-object v25, v5, v7

    .line 776
    .line 777
    const/16 v7, 0xb

    .line 778
    .line 779
    aput-object v26, v5, v7

    .line 780
    .line 781
    const/16 v7, 0xc

    .line 782
    .line 783
    aput-object v40, v5, v7

    .line 784
    .line 785
    const/16 v7, 0xd

    .line 786
    .line 787
    aput-object v41, v5, v7

    .line 788
    .line 789
    aput-object v27, v5, v2

    .line 790
    .line 791
    aput-object v28, v5, v6

    .line 792
    .line 793
    const/16 v2, 0x10

    .line 794
    .line 795
    aput-object v1, v5, v2

    .line 796
    .line 797
    const/16 v1, 0x11

    .line 798
    .line 799
    aput-object v3, v5, v1

    .line 800
    .line 801
    const/16 v1, 0x12

    .line 802
    .line 803
    aput-object v13, v5, v1

    .line 804
    .line 805
    aput-object v4, v5, v0

    .line 806
    .line 807
    sput-object v5, Law0;->y:[Lyv0;

    .line 808
    .line 809
    return-void

    .line 810
    nop

    .line 811
    :array_0
    .array-data 4
        0x3f23d70a    # 0.64f
        0x3ea8f5c3    # 0.33f
        0x3e99999a    # 0.3f
        0x3f19999a    # 0.6f
        0x3e19999a    # 0.15f
        0x3d75c28f    # 0.06f
    .end array-data

    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    :array_1
    .array-data 4
        0x3f2b851f    # 0.67f
        0x3ea8f5c3    # 0.33f
        0x3e570a3d    # 0.21f
        0x3f35c28f    # 0.71f
        0x3e0f5c29    # 0.14f
        0x3da3d70a    # 0.08f
    .end array-data

    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    :array_2
    .array-data 4
        0x3f353f7d    # 0.708f
        0x3e958106    # 0.292f
        0x3e2e147b    # 0.17f
        0x3f4c0831    # 0.797f
        0x3e0624dd    # 0.131f
        0x3d3c6a7f    # 0.046f
    .end array-data

    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    :array_3
    .array-data 4
        0x3f23d70a    # 0.64f
        0x3ea8f5c3    # 0.33f
        0x3e99999a    # 0.3f
        0x3f19999a    # 0.6f
        0x3e19999a    # 0.15f
        0x3d75c28f    # 0.06f
    .end array-data

    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    :array_4
    .array-data 4
        0x3f353f7d    # 0.708f
        0x3e958106    # 0.292f
        0x3e2e147b    # 0.17f
        0x3f4c0831    # 0.797f
        0x3e0624dd    # 0.131f
        0x3d3c6a7f    # 0.046f
    .end array-data

    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    :array_5
    .array-data 4
        0x3f2e147b    # 0.68f
        0x3ea3d70a    # 0.32f
        0x3e87ae14    # 0.265f
        0x3f30a3d7    # 0.69f
        0x3e19999a    # 0.15f
        0x3d75c28f    # 0.06f
    .end array-data

    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    :array_6
    .array-data 4
        0x3f2e147b    # 0.68f
        0x3ea3d70a    # 0.32f
        0x3e87ae14    # 0.265f
        0x3f30a3d7    # 0.69f
        0x3e19999a    # 0.15f
        0x3d75c28f    # 0.06f
    .end array-data

    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    :array_7
    .array-data 4
        0x3f2147ae    # 0.63f
        0x3eae147b    # 0.34f
        0x3e9eb852    # 0.31f
        0x3f1851ec    # 0.595f
        0x3e1eb852    # 0.155f
        0x3d8f5c29    # 0.07f
    .end array-data

    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    :array_8
    .array-data 4
        0x3f23d70a    # 0.64f
        0x3ea8f5c3    # 0.33f
        0x3e570a3d    # 0.21f
        0x3f35c28f    # 0.71f
        0x3e19999a    # 0.15f
        0x3d75c28f    # 0.06f
    .end array-data

    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    :array_9
    .array-data 4
        0x3f3c154d    # 0.7347f
        0x3e87d567    # 0.2653f
        0x3e236e2f    # 0.1596f
        0x3f572474    # 0.8404f
        0x3d15e9e2    # 0.0366f
        0x38d1b717    # 1.0E-4f
    .end array-data

    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    :array_a
    .array-data 4
        0x3f3c154d    # 0.7347f
        0x3e87d567    # 0.2653f
        0x0
        0x3f800000    # 1.0f
        0x38d1b717    # 1.0E-4f
        -0x42624dd3    # -0.077f
    .end array-data

    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    :array_b
    .array-data 4
        0x3f36872b    # 0.713f
        0x3e960419    # 0.293f
        0x3e28f5c3    # 0.165f
        0x3f547ae1    # 0.83f
        0x3e03126f    # 0.128f
        0x3d343958    # 0.044f
    .end array-data
.end method

.method public static a(Lq77;D)D
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    cmpg-double v1, p1, v1

    .line 6
    .line 7
    if-gez v1, :cond_0

    .line 8
    .line 9
    const-wide/high16 v4, -0x4010000000000000L    # -1.0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    .line 13
    .line 14
    :goto_0
    mul-double v6, p1, v4

    .line 15
    .line 16
    iget-wide v8, v0, Lq77;->b:D

    .line 17
    .line 18
    iget-wide v10, v0, Lq77;->c:D

    .line 19
    .line 20
    iget-wide v12, v0, Lq77;->d:D

    .line 21
    .line 22
    iget-wide v14, v0, Lq77;->e:D

    .line 23
    .line 24
    const-wide/high16 v16, 0x3ff0000000000000L    # 1.0

    .line 25
    .line 26
    iget-wide v2, v0, Lq77;->f:D

    .line 27
    .line 28
    iget-wide v0, v0, Lq77;->g:D

    .line 29
    .line 30
    add-double v0, v0, v16

    .line 31
    .line 32
    mul-double/2addr v8, v6

    .line 33
    cmpg-double v16, v8, v16

    .line 34
    .line 35
    if-gtz v16, :cond_1

    .line 36
    .line 37
    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->pow(DD)D

    .line 38
    .line 39
    .line 40
    move-result-wide v2

    .line 41
    goto :goto_1

    .line 42
    :cond_1
    sub-double/2addr v6, v2

    .line 43
    mul-double/2addr v6, v12

    .line 44
    invoke-static {v6, v7}, Ljava/lang/Math;->exp(D)D

    .line 45
    .line 46
    .line 47
    move-result-wide v2

    .line 48
    add-double/2addr v2, v14

    .line 49
    :goto_1
    mul-double/2addr v0, v4

    .line 50
    mul-double/2addr v0, v2

    .line 51
    return-wide v0
.end method

.method public static b(Lq77;D)D
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    cmpg-double v1, p1, v1

    .line 6
    .line 7
    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    .line 8
    .line 9
    if-gez v1, :cond_0

    .line 10
    .line 11
    const-wide/high16 v4, -0x4010000000000000L    # -1.0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move-wide v4, v2

    .line 15
    :goto_0
    mul-double v6, p1, v4

    .line 16
    .line 17
    iget-wide v8, v0, Lq77;->b:D

    .line 18
    .line 19
    div-double v8, v2, v8

    .line 20
    .line 21
    iget-wide v10, v0, Lq77;->c:D

    .line 22
    .line 23
    div-double v10, v2, v10

    .line 24
    .line 25
    iget-wide v12, v0, Lq77;->d:D

    .line 26
    .line 27
    div-double v12, v2, v12

    .line 28
    .line 29
    iget-wide v14, v0, Lq77;->e:D

    .line 30
    .line 31
    move-wide/from16 v16, v2

    .line 32
    .line 33
    iget-wide v2, v0, Lq77;->f:D

    .line 34
    .line 35
    iget-wide v0, v0, Lq77;->g:D

    .line 36
    .line 37
    add-double v0, v0, v16

    .line 38
    .line 39
    div-double/2addr v6, v0

    .line 40
    cmpg-double v0, v6, v16

    .line 41
    .line 42
    if-gtz v0, :cond_1

    .line 43
    .line 44
    invoke-static {v6, v7, v10, v11}, Ljava/lang/Math;->pow(DD)D

    .line 45
    .line 46
    .line 47
    move-result-wide v0

    .line 48
    mul-double/2addr v0, v8

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    sub-double/2addr v6, v14

    .line 51
    invoke-static {v6, v7}, Ljava/lang/Math;->log(D)D

    .line 52
    .line 53
    .line 54
    move-result-wide v0

    .line 55
    mul-double/2addr v0, v12

    .line 56
    add-double/2addr v0, v2

    .line 57
    :goto_1
    mul-double/2addr v4, v0

    .line 58
    return-wide v4
.end method

.method public static c(Lq77;D)D
    .locals 12

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmpg-double v2, p1, v0

    .line 4
    .line 5
    if-gez v2, :cond_0

    .line 6
    .line 7
    const-wide/high16 v2, -0x4010000000000000L    # -1.0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    .line 11
    .line 12
    :goto_0
    mul-double/2addr p1, v2

    .line 13
    iget-wide v4, p0, Lq77;->b:D

    .line 14
    .line 15
    iget-wide v6, p0, Lq77;->d:D

    .line 16
    .line 17
    iget-wide v8, p0, Lq77;->c:D

    .line 18
    .line 19
    invoke-static {p1, p2, v6, v7}, Ljava/lang/Math;->pow(DD)D

    .line 20
    .line 21
    .line 22
    move-result-wide v10

    .line 23
    mul-double/2addr v10, v8

    .line 24
    add-double/2addr v10, v4

    .line 25
    cmpg-double v4, v10, v0

    .line 26
    .line 27
    if-ltz v4, :cond_1

    .line 28
    .line 29
    move-wide v0, v10

    .line 30
    :cond_1
    iget-wide v4, p0, Lq77;->e:D

    .line 31
    .line 32
    iget-wide v8, p0, Lq77;->f:D

    .line 33
    .line 34
    invoke-static {p1, p2, v6, v7}, Ljava/lang/Math;->pow(DD)D

    .line 35
    .line 36
    .line 37
    move-result-wide p1

    .line 38
    mul-double/2addr p1, v8

    .line 39
    add-double/2addr p1, v4

    .line 40
    div-double/2addr v0, p1

    .line 41
    iget-wide p0, p0, Lq77;->g:D

    .line 42
    .line 43
    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->pow(DD)D

    .line 44
    .line 45
    .line 46
    move-result-wide p0

    .line 47
    mul-double/2addr p0, v2

    .line 48
    return-wide p0
.end method

.method public static d(Lq77;D)D
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    cmpg-double v3, p1, v1

    .line 6
    .line 7
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    .line 8
    .line 9
    if-gez v3, :cond_0

    .line 10
    .line 11
    const-wide/high16 v6, -0x4010000000000000L    # -1.0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    move-wide v6, v4

    .line 15
    :goto_0
    mul-double v8, p1, v6

    .line 16
    .line 17
    iget-wide v10, v0, Lq77;->b:D

    .line 18
    .line 19
    neg-double v10, v10

    .line 20
    iget-wide v12, v0, Lq77;->e:D

    .line 21
    .line 22
    iget-wide v14, v0, Lq77;->g:D

    .line 23
    .line 24
    div-double v14, v4, v14

    .line 25
    .line 26
    move-wide/from16 v16, v4

    .line 27
    .line 28
    iget-wide v4, v0, Lq77;->c:D

    .line 29
    .line 30
    iget-wide v1, v0, Lq77;->f:D

    .line 31
    .line 32
    neg-double v1, v1

    .line 33
    move-wide/from16 p1, v1

    .line 34
    .line 35
    iget-wide v0, v0, Lq77;->d:D

    .line 36
    .line 37
    div-double v0, v16, v0

    .line 38
    .line 39
    invoke-static {v8, v9, v14, v15}, Ljava/lang/Math;->pow(DD)D

    .line 40
    .line 41
    .line 42
    move-result-wide v2

    .line 43
    mul-double/2addr v2, v12

    .line 44
    add-double/2addr v2, v10

    .line 45
    const-wide/16 v10, 0x0

    .line 46
    .line 47
    invoke-static {v2, v3, v10, v11}, Ljava/lang/Math;->max(DD)D

    .line 48
    .line 49
    .line 50
    move-result-wide v2

    .line 51
    invoke-static {v8, v9, v14, v15}, Ljava/lang/Math;->pow(DD)D

    .line 52
    .line 53
    .line 54
    move-result-wide v8

    .line 55
    mul-double v8, v8, p1

    .line 56
    .line 57
    add-double/2addr v8, v4

    .line 58
    div-double/2addr v2, v8

    .line 59
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    .line 60
    .line 61
    .line 62
    move-result-wide v0

    .line 63
    mul-double/2addr v0, v6

    .line 64
    return-wide v0
.end method
