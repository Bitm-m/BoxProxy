.class public final synthetic Lbd3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:Lrb3;

.field public final synthetic j:I

.field public final synthetic k:F

.field public final synthetic l:Lqj5;

.field public final synthetic m:Lpj5;

.field public final synthetic n:Z

.field public final synthetic o:F

.field public final synthetic p:Lrj5;

.field public final synthetic q:I

.field public final synthetic r:I

.field public final synthetic s:Ltj5;


# direct methods
.method public synthetic constructor <init>(Lrb3;IFLqj5;Lpj5;ZFLrj5;IILtj5;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbd3;->i:Lrb3;

    .line 5
    .line 6
    iput p2, p0, Lbd3;->j:I

    .line 7
    .line 8
    iput p3, p0, Lbd3;->k:F

    .line 9
    .line 10
    iput-object p4, p0, Lbd3;->l:Lqj5;

    .line 11
    .line 12
    iput-object p5, p0, Lbd3;->m:Lpj5;

    .line 13
    .line 14
    iput-boolean p6, p0, Lbd3;->n:Z

    .line 15
    .line 16
    iput p7, p0, Lbd3;->o:F

    .line 17
    .line 18
    iput-object p8, p0, Lbd3;->p:Lrj5;

    .line 19
    .line 20
    iput p9, p0, Lbd3;->q:I

    .line 21
    .line 22
    iput p10, p0, Lbd3;->r:I

    .line 23
    .line 24
    iput-object p11, p0, Lbd3;->s:Ltj5;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    check-cast p1, Lbi;

    .line 2
    .line 3
    iget-object v0, p0, Lbd3;->i:Lrb3;

    .line 4
    .line 5
    iget v1, p0, Lbd3;->j:I

    .line 6
    .line 7
    invoke-static {v0, v1}, Lsa3;->N(Lrb3;I)Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    iget-object v3, p0, Lbd3;->m:Lpj5;

    .line 12
    .line 13
    iget-boolean v4, p0, Lbd3;->n:Z

    .line 14
    .line 15
    iget v5, p0, Lbd3;->r:I

    .line 16
    .line 17
    sget-object v6, Lxc7;->a:Lxc7;

    .line 18
    .line 19
    const/4 v7, 0x0

    .line 20
    if-nez v2, :cond_7

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    iget v8, p0, Lbd3;->k:F

    .line 24
    .line 25
    cmpl-float v2, v8, v2

    .line 26
    .line 27
    if-lez v2, :cond_0

    .line 28
    .line 29
    iget-object v2, p1, Lbi;->e:Lgx4;

    .line 30
    .line 31
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    check-cast v2, Ljava/lang/Number;

    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    cmpl-float v9, v2, v8

    .line 42
    .line 43
    if-lez v9, :cond_1

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    iget-object v2, p1, Lbi;->e:Lgx4;

    .line 47
    .line 48
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    check-cast v2, Ljava/lang/Number;

    .line 53
    .line 54
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    cmpg-float v9, v2, v8

    .line 59
    .line 60
    if-ltz v9, :cond_2

    .line 61
    .line 62
    :cond_1
    move v8, v2

    .line 63
    :cond_2
    :goto_0
    iget-object v2, p0, Lbd3;->l:Lqj5;

    .line 64
    .line 65
    iget v9, v2, Lqj5;->i:F

    .line 66
    .line 67
    sub-float/2addr v8, v9

    .line 68
    invoke-interface {v0, v8}, Lo36;->a(F)F

    .line 69
    .line 70
    .line 71
    move-result v9

    .line 72
    invoke-static {v0, v1}, Lsa3;->N(Lrb3;I)Z

    .line 73
    .line 74
    .line 75
    move-result v10

    .line 76
    if-nez v10, :cond_7

    .line 77
    .line 78
    invoke-static {v4, v0, v1, v5}, Lsa3;->y(ZLrb3;II)Z

    .line 79
    .line 80
    .line 81
    move-result v10

    .line 82
    if-nez v10, :cond_7

    .line 83
    .line 84
    cmpg-float v9, v8, v9

    .line 85
    .line 86
    if-nez v9, :cond_6

    .line 87
    .line 88
    iget v9, v2, Lqj5;->i:F

    .line 89
    .line 90
    add-float/2addr v9, v8

    .line 91
    iput v9, v2, Lqj5;->i:F

    .line 92
    .line 93
    iget v2, p0, Lbd3;->o:F

    .line 94
    .line 95
    if-eqz v4, :cond_3

    .line 96
    .line 97
    iget-object v8, p1, Lbi;->e:Lgx4;

    .line 98
    .line 99
    invoke-virtual {v8}, Lgx4;->getValue()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v8

    .line 103
    check-cast v8, Ljava/lang/Number;

    .line 104
    .line 105
    invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F

    .line 106
    .line 107
    .line 108
    move-result v8

    .line 109
    cmpl-float v2, v8, v2

    .line 110
    .line 111
    if-lez v2, :cond_4

    .line 112
    .line 113
    invoke-virtual {p1}, Lbi;->a()V

    .line 114
    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_3
    iget-object v8, p1, Lbi;->e:Lgx4;

    .line 118
    .line 119
    invoke-virtual {v8}, Lgx4;->getValue()Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    check-cast v8, Ljava/lang/Number;

    .line 124
    .line 125
    invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F

    .line 126
    .line 127
    .line 128
    move-result v8

    .line 129
    neg-float v2, v2

    .line 130
    cmpg-float v2, v8, v2

    .line 131
    .line 132
    if-gez v2, :cond_4

    .line 133
    .line 134
    invoke-virtual {p1}, Lbi;->a()V

    .line 135
    .line 136
    .line 137
    :cond_4
    :goto_1
    iget-object v2, p0, Lbd3;->p:Lrj5;

    .line 138
    .line 139
    iget v2, v2, Lrj5;->i:I

    .line 140
    .line 141
    iget v8, p0, Lbd3;->q:I

    .line 142
    .line 143
    const/4 v9, 0x2

    .line 144
    if-eqz v4, :cond_5

    .line 145
    .line 146
    if-lt v2, v9, :cond_7

    .line 147
    .line 148
    invoke-virtual {v0}, Lrb3;->e()I

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    sub-int v2, v1, v2

    .line 153
    .line 154
    if-le v2, v8, :cond_7

    .line 155
    .line 156
    sub-int v2, v1, v8

    .line 157
    .line 158
    invoke-virtual {v0, v2, v7}, Lrb3;->f(II)V

    .line 159
    .line 160
    .line 161
    goto :goto_2

    .line 162
    :cond_5
    if-lt v2, v9, :cond_7

    .line 163
    .line 164
    invoke-virtual {v0}, Lrb3;->c()I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    sub-int/2addr v2, v1

    .line 169
    if-le v2, v8, :cond_7

    .line 170
    .line 171
    add-int/2addr v8, v1

    .line 172
    invoke-virtual {v0, v8, v7}, Lrb3;->f(II)V

    .line 173
    .line 174
    .line 175
    goto :goto_2

    .line 176
    :cond_6
    invoke-virtual {p1}, Lbi;->a()V

    .line 177
    .line 178
    .line 179
    iput-boolean v7, v3, Lpj5;->i:Z

    .line 180
    .line 181
    return-object v6

    .line 182
    :cond_7
    :goto_2
    invoke-static {v4, v0, v1, v5}, Lsa3;->y(ZLrb3;II)Z

    .line 183
    .line 184
    .line 185
    move-result v2

    .line 186
    if-eqz v2, :cond_8

    .line 187
    .line 188
    invoke-virtual {v0, v1, v5}, Lrb3;->f(II)V

    .line 189
    .line 190
    .line 191
    iput-boolean v7, v3, Lpj5;->i:Z

    .line 192
    .line 193
    invoke-virtual {p1}, Lbi;->a()V

    .line 194
    .line 195
    .line 196
    return-object v6

    .line 197
    :cond_8
    invoke-static {v0, v1}, Lsa3;->N(Lrb3;I)Z

    .line 198
    .line 199
    .line 200
    move-result p1

    .line 201
    if-nez p1, :cond_9

    .line 202
    .line 203
    return-object v6

    .line 204
    :cond_9
    invoke-virtual {v0, v1}, Lrb3;->b(I)I

    .line 205
    .line 206
    .line 207
    move-result p1

    .line 208
    new-instance v0, Ll33;

    .line 209
    .line 210
    iget-object p0, p0, Lbd3;->s:Ltj5;

    .line 211
    .line 212
    iget-object p0, p0, Ltj5;->i:Ljava/lang/Object;

    .line 213
    .line 214
    check-cast p0, Ldi;

    .line 215
    .line 216
    invoke-direct {v0, p1, p0}, Ll33;-><init>(ILdi;)V

    .line 217
    .line 218
    .line 219
    throw v0
.end method
