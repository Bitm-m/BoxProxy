.class public final Lb34;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lwr1;


# instance fields
.field public final i:Lwr1;

.field public j:J


# direct methods
.method public constructor <init>(Lwr1;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb34;->i:Lwr1;

    .line 5
    .line 6
    invoke-super {p0}, Lwr1;->b()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iput-wide v0, p0, Lb34;->j:J

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final A()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0}, Lkl1;->A()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final A0(Lrc;JJJFLpv0;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p10}, Lwr1;->A0(Lrc;JJJFLpv0;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final D0()J
    .locals 2

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0}, Lwr1;->D0()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final G(Lse0;JJJFLxr1;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 5
    .line 6
    const/high16 p8, 0x3f800000    # 1.0f

    .line 7
    .line 8
    invoke-interface/range {p0 .. p9}, Lwr1;->G(Lse0;JJJFLxr1;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final G0(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkl1;->G0(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final I(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->I(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final J(J)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkl1;->J(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final K(JJJJLxr1;)V
    .locals 0

    .line 1
    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p9}, Lwr1;->K(JJJJLxr1;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final L(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->L(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final N0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkl1;->N0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final Q(Lrc;JFLpv0;I)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p6}, Lwr1;->Q(Lrc;JFLpv0;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final U0(JJJFI)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p8}, Lwr1;->U0(JJJFI)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final V()Lw27;
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0}, Lwr1;->V()Lw27;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final Z0(JFJLxr1;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p6}, Lwr1;->Z0(JFJLxr1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final a()F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0}, Lkl1;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final a1(F)J
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->a1(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final b()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lb34;->j:J

    .line 2
    .line 3
    return-wide v0
.end method

.method public final c0(J)I
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkl1;->c0(J)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final d0(JFFJJFLxr1;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p10}, Lwr1;->d0(JFFJJFLxr1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f0(J)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lkl1;->f0(J)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final getLayoutDirection()Lh93;
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0}, Lwr1;->getLayoutDirection()Lh93;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final k1(I)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->k1(I)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final o1(F)F
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->o1(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final p(Lse0;JJFLxr1;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 5
    .line 6
    invoke-interface/range {p0 .. p8}, Lwr1;->p(Lse0;JJFLxr1;I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final r(Led;Lse0;FLxr1;I)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 11
    .line 12
    invoke-interface/range {p0 .. p5}, Lwr1;->r(Led;Lse0;FLxr1;I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final s(Led;JFLxr1;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 8
    .line 9
    invoke-interface/range {p0 .. p5}, Lwr1;->s(Led;JFLxr1;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final s0(F)I
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lkl1;->s0(F)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final z0(JJJFI)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb34;->i:Lwr1;

    .line 2
    .line 3
    invoke-interface/range {p0 .. p8}, Lwr1;->z0(JJJFI)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
