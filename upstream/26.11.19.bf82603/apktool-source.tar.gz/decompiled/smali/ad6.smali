.class public final synthetic Lad6;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lee6;

.field public final synthetic k:Lge6;

.field public final synthetic l:Lbe6;

.field public final synthetic m:Landroid/content/Context;

.field public final synthetic n:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lee6;Lge6;Lbe6;Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lad6;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lad6;->j:Lee6;

    .line 8
    .line 9
    iput-object p2, p0, Lad6;->k:Lge6;

    .line 10
    .line 11
    iput-object p3, p0, Lad6;->l:Lbe6;

    .line 12
    .line 13
    iput-object p4, p0, Lad6;->m:Landroid/content/Context;

    .line 14
    .line 15
    iput-object p5, p0, Lad6;->n:Ljava/lang/String;

    .line 16
    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Lge6;Lbe6;Landroid/content/Context;Ljava/lang/String;Lee6;)V
    .locals 1

    .line 18
    const/4 v0, 0x0

    iput-byte v0, p0, Lad6;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad6;->k:Lge6;

    iput-object p2, p0, Lad6;->l:Lbe6;

    iput-object p3, p0, Lad6;->m:Landroid/content/Context;

    iput-object p4, p0, Lad6;->n:Ljava/lang/String;

    iput-object p5, p0, Lad6;->j:Lee6;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lad6;->i:B

    .line 4
    .line 5
    sget-object v2, Lxc7;->a:Lxc7;

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    const/4 v5, 0x0

    .line 10
    sget-object v6, Lg21;->a:Ley0;

    .line 11
    .line 12
    packed-switch v1, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    move-object/from16 v1, p1

    .line 16
    .line 17
    check-cast v1, Lib2;

    .line 18
    .line 19
    move-object/from16 v7, p2

    .line 20
    .line 21
    check-cast v7, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    and-int/lit8 v8, v7, 0x3

    .line 28
    .line 29
    if-eq v8, v3, :cond_0

    .line 30
    .line 31
    move v5, v4

    .line 32
    :cond_0
    and-int/2addr v7, v4

    .line 33
    invoke-virtual {v1, v7, v5}, Lib2;->X(IZ)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_6

    .line 38
    .line 39
    sget-object v3, Lt04;->i:Lt04;

    .line 40
    .line 41
    const/high16 v5, 0x3f800000    # 1.0f

    .line 42
    .line 43
    invoke-static {v3, v5}, Lag6;->e(Lw04;F)Lw04;

    .line 44
    .line 45
    .line 46
    move-result-object v7

    .line 47
    sget-object v8, Lla7;->h:Lj6;

    .line 48
    .line 49
    sget-object v9, Lu6;->t:Ls20;

    .line 50
    .line 51
    const/4 v10, 0x6

    .line 52
    invoke-static {v8, v9, v1, v10}, Llp5;->a(Luv;Ls20;Lib2;I)Lmp5;

    .line 53
    .line 54
    .line 55
    move-result-object v8

    .line 56
    iget-wide v9, v1, Lib2;->T:J

    .line 57
    .line 58
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 59
    .line 60
    .line 61
    move-result v9

    .line 62
    invoke-virtual {v1}, Lib2;->m()Liz4;

    .line 63
    .line 64
    .line 65
    move-result-object v10

    .line 66
    invoke-static {v1, v7}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    sget-object v11, Lx11;->d:Lu6;

    .line 71
    .line 72
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1}, Lib2;->j0()V

    .line 76
    .line 77
    .line 78
    iget-boolean v11, v1, Lib2;->S:Z

    .line 79
    .line 80
    if-eqz v11, :cond_1

    .line 81
    .line 82
    sget-object v11, Laa3;->a0:Lg53;

    .line 83
    .line 84
    invoke-virtual {v1, v11}, Lib2;->l(Lu92;)V

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :cond_1
    invoke-virtual {v1}, Lib2;->s0()V

    .line 89
    .line 90
    .line 91
    :goto_0
    sget-object v11, Lu6;->S:Lc11;

    .line 92
    .line 93
    invoke-static {v11, v1, v8}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    sget-object v8, Lu6;->R:Lc11;

    .line 97
    .line 98
    invoke-static {v8, v1, v10}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 102
    .line 103
    .line 104
    move-result-object v8

    .line 105
    sget-object v9, Lu6;->T:Lc11;

    .line 106
    .line 107
    invoke-static {v9, v1, v8}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    invoke-static {v1}, Lwt6;->m(Lib2;)V

    .line 111
    .line 112
    .line 113
    sget-object v8, Lu6;->Q:Lc11;

    .line 114
    .line 115
    invoke-static {v8, v1, v7}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    const/high16 v7, 0x1040000

    .line 119
    .line 120
    invoke-static {v7, v1}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v7

    .line 124
    iget-object v8, v0, Lad6;->j:Lee6;

    .line 125
    .line 126
    invoke-virtual {v1, v8}, Lib2;->g(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v9

    .line 130
    invoke-virtual {v1}, Lib2;->S()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v10

    .line 134
    if-nez v9, :cond_2

    .line 135
    .line 136
    if-ne v10, v6, :cond_3

    .line 137
    .line 138
    :cond_2
    new-instance v10, Lvc6;

    .line 139
    .line 140
    const/16 v9, 0xc

    .line 141
    .line 142
    invoke-direct {v10, v8, v9}, Lvc6;-><init>(Lee6;B)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1, v10}, Lib2;->p0(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    :cond_3
    check-cast v10, Lu92;

    .line 149
    .line 150
    new-instance v9, Lta3;

    .line 151
    .line 152
    invoke-direct {v9, v5, v4}, Lta3;-><init>(FZ)V

    .line 153
    .line 154
    .line 155
    const/16 v18, 0x0

    .line 156
    .line 157
    const/16 v19, 0xff8

    .line 158
    .line 159
    move-object v11, v8

    .line 160
    move-object v8, v10

    .line 161
    const/4 v10, 0x0

    .line 162
    move-object v12, v11

    .line 163
    const/4 v11, 0x0

    .line 164
    move-object v13, v12

    .line 165
    const/4 v12, 0x0

    .line 166
    move-object v14, v13

    .line 167
    const/4 v13, 0x0

    .line 168
    move-object v15, v14

    .line 169
    const/4 v14, 0x0

    .line 170
    move-object/from16 v16, v15

    .line 171
    .line 172
    const/4 v15, 0x0

    .line 173
    move-object/from16 v17, v16

    .line 174
    .line 175
    const/16 v16, 0x0

    .line 176
    .line 177
    move-object/from16 v20, v17

    .line 178
    .line 179
    move-object/from16 v17, v1

    .line 180
    .line 181
    move-object/from16 v1, v20

    .line 182
    .line 183
    invoke-static/range {v7 .. v19}, Lg93;->b(Ljava/lang/String;Lu92;Lw04;ZFFFLuw3;Lzt4;Lix2;Lib2;II)V

    .line 184
    .line 185
    .line 186
    move-object/from16 v7, v17

    .line 187
    .line 188
    const/high16 v8, 0x41a00000    # 20.0f

    .line 189
    .line 190
    const v9, 0x7f0f00be

    .line 191
    .line 192
    .line 193
    invoke-static {v3, v8, v7, v9, v7}, Luj6;->n(Lt04;FLib2;ILib2;)Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v3

    .line 197
    iget-object v9, v0, Lad6;->k:Lge6;

    .line 198
    .line 199
    invoke-virtual {v7, v9}, Lib2;->g(Ljava/lang/Object;)Z

    .line 200
    .line 201
    .line 202
    move-result v8

    .line 203
    iget-object v10, v0, Lad6;->l:Lbe6;

    .line 204
    .line 205
    invoke-virtual {v7, v10}, Lib2;->i(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result v11

    .line 209
    or-int/2addr v8, v11

    .line 210
    iget-object v13, v0, Lad6;->m:Landroid/content/Context;

    .line 211
    .line 212
    invoke-virtual {v7, v13}, Lib2;->i(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v11

    .line 216
    or-int/2addr v8, v11

    .line 217
    iget-object v12, v0, Lad6;->n:Ljava/lang/String;

    .line 218
    .line 219
    invoke-virtual {v7, v12}, Lib2;->g(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    or-int/2addr v8, v0

    .line 224
    invoke-virtual {v7, v1}, Lib2;->g(Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    or-int/2addr v8, v0

    .line 229
    invoke-virtual {v7}, Lib2;->S()Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    if-nez v8, :cond_4

    .line 234
    .line 235
    if-ne v0, v6, :cond_5

    .line 236
    .line 237
    :cond_4
    new-instance v8, Lgd6;

    .line 238
    .line 239
    const/4 v14, 0x2

    .line 240
    move-object v11, v1

    .line 241
    invoke-direct/range {v8 .. v14}, Lgd6;-><init>(Lge6;Lbe6;Lee6;Ljava/lang/String;Landroid/content/Context;B)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v7, v8}, Lib2;->p0(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    move-object v0, v8

    .line 248
    :cond_5
    move-object v8, v0

    .line 249
    check-cast v8, Lu92;

    .line 250
    .line 251
    new-instance v9, Lta3;

    .line 252
    .line 253
    invoke-direct {v9, v5, v4}, Lta3;-><init>(FZ)V

    .line 254
    .line 255
    .line 256
    const/high16 v18, 0xc00000

    .line 257
    .line 258
    const/16 v19, 0xf78

    .line 259
    .line 260
    const/4 v10, 0x0

    .line 261
    const/4 v11, 0x0

    .line 262
    const/4 v12, 0x0

    .line 263
    const/4 v13, 0x0

    .line 264
    sget-object v14, Luw3;->k:Luw3;

    .line 265
    .line 266
    const/4 v15, 0x0

    .line 267
    const/16 v16, 0x0

    .line 268
    .line 269
    move-object/from16 v17, v7

    .line 270
    .line 271
    move-object v7, v3

    .line 272
    invoke-static/range {v7 .. v19}, Lg93;->b(Ljava/lang/String;Lu92;Lw04;ZFFFLuw3;Lzt4;Lix2;Lib2;II)V

    .line 273
    .line 274
    .line 275
    move-object/from16 v7, v17

    .line 276
    .line 277
    invoke-virtual {v7, v4}, Lib2;->r(Z)V

    .line 278
    .line 279
    .line 280
    goto :goto_1

    .line 281
    :cond_6
    move-object v7, v1

    .line 282
    invoke-virtual {v7}, Lib2;->a0()V

    .line 283
    .line 284
    .line 285
    :goto_1
    return-object v2

    .line 286
    :pswitch_0
    move-object/from16 v15, p1

    .line 287
    .line 288
    check-cast v15, Lib2;

    .line 289
    .line 290
    move-object/from16 v1, p2

    .line 291
    .line 292
    check-cast v1, Ljava/lang/Integer;

    .line 293
    .line 294
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 295
    .line 296
    .line 297
    move-result v1

    .line 298
    and-int/lit8 v7, v1, 0x3

    .line 299
    .line 300
    if-eq v7, v3, :cond_7

    .line 301
    .line 302
    move v5, v4

    .line 303
    :cond_7
    and-int/2addr v1, v4

    .line 304
    invoke-virtual {v15, v1, v5}, Lib2;->X(IZ)Z

    .line 305
    .line 306
    .line 307
    move-result v1

    .line 308
    if-eqz v1, :cond_a

    .line 309
    .line 310
    iget-object v8, v0, Lad6;->k:Lge6;

    .line 311
    .line 312
    invoke-virtual {v15, v8}, Lib2;->g(Ljava/lang/Object;)Z

    .line 313
    .line 314
    .line 315
    move-result v1

    .line 316
    iget-object v9, v0, Lad6;->l:Lbe6;

    .line 317
    .line 318
    invoke-virtual {v15, v9}, Lib2;->i(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v3

    .line 322
    or-int/2addr v1, v3

    .line 323
    iget-object v12, v0, Lad6;->m:Landroid/content/Context;

    .line 324
    .line 325
    invoke-virtual {v15, v12}, Lib2;->i(Ljava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    move-result v3

    .line 329
    or-int/2addr v1, v3

    .line 330
    iget-object v11, v0, Lad6;->n:Ljava/lang/String;

    .line 331
    .line 332
    invoke-virtual {v15, v11}, Lib2;->g(Ljava/lang/Object;)Z

    .line 333
    .line 334
    .line 335
    move-result v3

    .line 336
    or-int/2addr v1, v3

    .line 337
    iget-object v10, v0, Lad6;->j:Lee6;

    .line 338
    .line 339
    invoke-virtual {v15, v10}, Lib2;->g(Ljava/lang/Object;)Z

    .line 340
    .line 341
    .line 342
    move-result v0

    .line 343
    or-int/2addr v1, v0

    .line 344
    invoke-virtual {v15}, Lib2;->S()Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v0

    .line 348
    if-nez v1, :cond_8

    .line 349
    .line 350
    if-ne v0, v6, :cond_9

    .line 351
    .line 352
    :cond_8
    new-instance v7, Lgd6;

    .line 353
    .line 354
    const/4 v13, 0x0

    .line 355
    invoke-direct/range {v7 .. v13}, Lgd6;-><init>(Lge6;Lbe6;Lee6;Ljava/lang/String;Landroid/content/Context;B)V

    .line 356
    .line 357
    .line 358
    invoke-virtual {v15, v7}, Lib2;->p0(Ljava/lang/Object;)V

    .line 359
    .line 360
    .line 361
    move-object v0, v7

    .line 362
    :cond_9
    move-object v8, v0

    .line 363
    check-cast v8, Lu92;

    .line 364
    .line 365
    sget-object v14, Lj23;->N:Lyz0;

    .line 366
    .line 367
    const/high16 v16, 0x30000000

    .line 368
    .line 369
    const/16 v17, 0x1fe

    .line 370
    .line 371
    const/4 v9, 0x0

    .line 372
    const/4 v10, 0x0

    .line 373
    const/4 v11, 0x0

    .line 374
    const/4 v12, 0x0

    .line 375
    const/4 v13, 0x0

    .line 376
    invoke-static/range {v8 .. v17}, Ljq;->t(Lu92;Lw04;ZLma6;Lsf0;Lzt4;Lka2;Lib2;II)V

    .line 377
    .line 378
    .line 379
    goto :goto_2

    .line 380
    :cond_a
    invoke-virtual {v15}, Lib2;->a0()V

    .line 381
    .line 382
    .line 383
    :goto_2
    return-object v2

    .line 384
    nop

    .line 385
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
