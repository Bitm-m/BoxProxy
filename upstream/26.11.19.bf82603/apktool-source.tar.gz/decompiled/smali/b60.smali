.class public final Lb60;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic a:B

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p5, p0, Lb60;->a:B

    .line 2
    .line 3
    iput-object p1, p0, Lb60;->c:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lb60;->b:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, Lb60;->d:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p4, p0, Lb60;->e:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Lp15;Lea1;)Ljava/lang/Object;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v8, p2

    .line 4
    .line 5
    iget-byte v1, v0, Lb60;->a:B

    .line 6
    .line 7
    sget-object v9, Lxc7;->a:Lxc7;

    .line 8
    .line 9
    sget-object v10, Lof1;->i:Lof1;

    .line 10
    .line 11
    iget-object v2, v0, Lb60;->e:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v3, v0, Lb60;->d:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v4, v0, Lb60;->b:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v0, v0, Lb60;->c:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object v1, v0

    .line 23
    new-instance v0, Lza0;

    .line 24
    .line 25
    move-object v5, v2

    .line 26
    move-object v2, v1

    .line 27
    check-cast v2, Lj34;

    .line 28
    .line 29
    check-cast v4, Leh6;

    .line 30
    .line 31
    check-cast v3, Lj44;

    .line 32
    .line 33
    check-cast v5, Lj44;

    .line 34
    .line 35
    const/4 v6, 0x0

    .line 36
    const/16 v7, 0x12

    .line 37
    .line 38
    move-object v1, v4

    .line 39
    move-object v4, v3

    .line 40
    move-object v3, v1

    .line 41
    move-object/from16 v1, p1

    .line 42
    .line 43
    invoke-direct/range {v0 .. v7}, Lza0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 44
    .line 45
    .line 46
    invoke-static {v0, v8}, Ljn;->D(Lja2;Lea1;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    if-ne v0, v10, :cond_0

    .line 51
    .line 52
    move-object v9, v0

    .line 53
    :cond_0
    return-object v9

    .line 54
    :pswitch_0
    move-object v1, v0

    .line 55
    move-object v5, v2

    .line 56
    move-object/from16 v0, p1

    .line 57
    .line 58
    new-instance v11, Llj2;

    .line 59
    .line 60
    move-object v12, v1

    .line 61
    check-cast v12, Lrg5;

    .line 62
    .line 63
    move-object v13, v4

    .line 64
    check-cast v13, Lnf1;

    .line 65
    .line 66
    move-object v14, v3

    .line 67
    check-cast v14, Lu92;

    .line 68
    .line 69
    move-object v15, v5

    .line 70
    check-cast v15, Lj44;

    .line 71
    .line 72
    const/16 v16, 0x0

    .line 73
    .line 74
    const/16 v17, 0x1

    .line 75
    .line 76
    invoke-direct/range {v11 .. v17}, Llj2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lra2;Ljava/lang/Object;Lea1;B)V

    .line 77
    .line 78
    .line 79
    check-cast v0, Lcs6;

    .line 80
    .line 81
    invoke-virtual {v0, v11, v8}, Lcs6;->F1(Lja2;Lea1;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    if-ne v0, v10, :cond_1

    .line 86
    .line 87
    move-object v9, v0

    .line 88
    :cond_1
    return-object v9

    .line 89
    :pswitch_1
    move-object v5, v2

    .line 90
    move-object v2, v0

    .line 91
    move-object/from16 v0, p1

    .line 92
    .line 93
    new-instance v1, La60;

    .line 94
    .line 95
    check-cast v2, Lcx4;

    .line 96
    .line 97
    check-cast v4, Lnf1;

    .line 98
    .line 99
    check-cast v3, Lmg;

    .line 100
    .line 101
    check-cast v5, Lmg;

    .line 102
    .line 103
    const/4 v6, 0x0

    .line 104
    move-object/from16 v18, v4

    .line 105
    .line 106
    move-object v4, v3

    .line 107
    move-object/from16 v3, v18

    .line 108
    .line 109
    invoke-direct/range {v1 .. v6}, La60;-><init>(Lcx4;Lnf1;Lmg;Lmg;Lea1;)V

    .line 110
    .line 111
    .line 112
    const/4 v2, 0x0

    .line 113
    const/16 v3, 0xb

    .line 114
    .line 115
    invoke-static {v0, v1, v2, v8, v3}, Lvu6;->e(Lp15;Lka2;Lfa2;Lea1;I)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    if-ne v0, v10, :cond_2

    .line 120
    .line 121
    move-object v9, v0

    .line 122
    :cond_2
    return-object v9

    .line 123
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
