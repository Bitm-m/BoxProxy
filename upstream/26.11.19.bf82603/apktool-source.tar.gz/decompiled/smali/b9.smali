.class public final Lb9;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lx42;


# instance fields
.field public final synthetic i:B

.field public final j:Ljava/lang/Object;

.field public final k:Ljava/lang/Object;

.field public final l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 25
    iput-byte p4, p0, Lb9;->i:B

    iput-object p1, p0, Lb9;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb9;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb9;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lro1;Ltj5;Lx42;)V
    .locals 1

    const/4 v0, 0x3

    iput-byte v0, p0, Lb9;->i:B

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb9;->k:Ljava/lang/Object;

    iput-object p2, p0, Lb9;->j:Ljava/lang/Object;

    iput-object p3, p0, Lb9;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lx42;Ldf1;)V
    .locals 2

    .line 1
    const/4 v0, 0x7

    .line 2
    iput-byte v0, p0, Lb9;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lb9;->j:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-static {p2}, Lhr3;->P(Ldf1;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p2

    .line 13
    iput-object p2, p0, Lb9;->k:Ljava/lang/Object;

    .line 14
    .line 15
    new-instance p2, Ly56;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    const/4 v1, 0x6

    .line 19
    invoke-direct {p2, p1, v0, v1}, Ly56;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 20
    .line 21
    .line 22
    iput-object p2, p0, Lb9;->l:Ljava/lang/Object;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;Lea1;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-byte v3, v0, Lb9;->i:B

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v5, 0x3

    .line 11
    const/4 v6, 0x2

    .line 12
    const-string v7, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    const/4 v8, 0x1

    .line 15
    const/high16 v9, -0x80000000

    .line 16
    .line 17
    sget-object v10, Lof1;->i:Lof1;

    .line 18
    .line 19
    const/4 v11, 0x0

    .line 20
    sget-object v12, Lxc7;->a:Lxc7;

    .line 21
    .line 22
    iget-object v13, v0, Lb9;->l:Ljava/lang/Object;

    .line 23
    .line 24
    iget-object v14, v0, Lb9;->k:Ljava/lang/Object;

    .line 25
    .line 26
    iget-object v15, v0, Lb9;->j:Ljava/lang/Object;

    .line 27
    .line 28
    packed-switch v3, :pswitch_data_0

    .line 29
    .line 30
    .line 31
    check-cast v15, Ldf1;

    .line 32
    .line 33
    check-cast v13, Ly56;

    .line 34
    .line 35
    invoke-static {v15, v1, v14, v13, v2}, Lej;->k0(Ldf1;Ljava/lang/Object;Ljava/lang/Object;Lja2;Lea1;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-ne v0, v10, :cond_0

    .line 40
    .line 41
    move-object v12, v0

    .line 42
    :cond_0
    return-object v12

    .line 43
    :pswitch_0
    instance-of v3, v2, Lm52;

    .line 44
    .line 45
    if-eqz v3, :cond_1

    .line 46
    .line 47
    move-object v3, v2

    .line 48
    check-cast v3, Lm52;

    .line 49
    .line 50
    iget v4, v3, Lm52;->k:I

    .line 51
    .line 52
    and-int v5, v4, v9

    .line 53
    .line 54
    if-eqz v5, :cond_1

    .line 55
    .line 56
    sub-int/2addr v4, v9

    .line 57
    iput v4, v3, Lm52;->k:I

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_1
    new-instance v3, Lm52;

    .line 61
    .line 62
    invoke-direct {v3, v0, v2}, Lm52;-><init>(Lb9;Lea1;)V

    .line 63
    .line 64
    .line 65
    :goto_0
    iget-object v0, v3, Lm52;->i:Ljava/lang/Object;

    .line 66
    .line 67
    iget v2, v3, Lm52;->k:I

    .line 68
    .line 69
    if-eqz v2, :cond_4

    .line 70
    .line 71
    if-eq v2, v8, :cond_2

    .line 72
    .line 73
    if-eq v2, v6, :cond_2

    .line 74
    .line 75
    invoke-static {v7}, La02;->d(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    move-object v10, v11

    .line 79
    goto :goto_1

    .line 80
    :cond_2
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    :cond_3
    move-object v10, v12

    .line 84
    goto :goto_1

    .line 85
    :cond_4
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    check-cast v15, Lrj5;

    .line 89
    .line 90
    iget v0, v15, Lrj5;->i:I

    .line 91
    .line 92
    add-int/2addr v0, v8

    .line 93
    iput v0, v15, Lrj5;->i:I

    .line 94
    .line 95
    check-cast v14, Lx42;

    .line 96
    .line 97
    if-ge v0, v8, :cond_5

    .line 98
    .line 99
    iput v8, v3, Lm52;->k:I

    .line 100
    .line 101
    invoke-interface {v14, v1, v3}, Lx42;->d(Ljava/lang/Object;Lea1;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    if-ne v0, v10, :cond_3

    .line 106
    .line 107
    goto :goto_1

    .line 108
    :cond_5
    iput v6, v3, Lm52;->k:I

    .line 109
    .line 110
    invoke-static {v14, v1, v13, v3}, Lmm0;->L(Lx42;Ljava/lang/Object;Ljava/lang/Object;Lea1;)V

    .line 111
    .line 112
    .line 113
    :goto_1
    return-object v10

    .line 114
    :pswitch_1
    check-cast v14, Lx42;

    .line 115
    .line 116
    check-cast v15, Lpj5;

    .line 117
    .line 118
    instance-of v3, v2, Lj52;

    .line 119
    .line 120
    if-eqz v3, :cond_6

    .line 121
    .line 122
    move-object v3, v2

    .line 123
    check-cast v3, Lj52;

    .line 124
    .line 125
    iget v4, v3, Lj52;->l:I

    .line 126
    .line 127
    and-int v16, v4, v9

    .line 128
    .line 129
    if-eqz v16, :cond_6

    .line 130
    .line 131
    sub-int/2addr v4, v9

    .line 132
    iput v4, v3, Lj52;->l:I

    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_6
    new-instance v3, Lj52;

    .line 136
    .line 137
    invoke-direct {v3, v0, v2}, Lj52;-><init>(Lb9;Lea1;)V

    .line 138
    .line 139
    .line 140
    :goto_2
    iget-object v0, v3, Lj52;->j:Ljava/lang/Object;

    .line 141
    .line 142
    iget v2, v3, Lj52;->l:I

    .line 143
    .line 144
    if-eqz v2, :cond_a

    .line 145
    .line 146
    if-eq v2, v8, :cond_8

    .line 147
    .line 148
    if-eq v2, v6, :cond_7

    .line 149
    .line 150
    if-eq v2, v5, :cond_8

    .line 151
    .line 152
    invoke-static {v7}, La02;->d(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    move-object v10, v11

    .line 156
    goto :goto_4

    .line 157
    :cond_7
    iget-object v1, v3, Lj52;->i:Ljava/lang/Object;

    .line 158
    .line 159
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 160
    .line 161
    .line 162
    goto :goto_3

    .line 163
    :cond_8
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    :cond_9
    move-object v10, v12

    .line 167
    goto :goto_4

    .line 168
    :cond_a
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    iget-boolean v0, v15, Lpj5;->i:Z

    .line 172
    .line 173
    if-eqz v0, :cond_b

    .line 174
    .line 175
    iput-object v11, v3, Lj52;->i:Ljava/lang/Object;

    .line 176
    .line 177
    iput v8, v3, Lj52;->l:I

    .line 178
    .line 179
    invoke-interface {v14, v1, v3}, Lx42;->d(Ljava/lang/Object;Lea1;)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    if-ne v0, v10, :cond_9

    .line 184
    .line 185
    goto :goto_4

    .line 186
    :cond_b
    check-cast v13, Lmg0;

    .line 187
    .line 188
    iput-object v1, v3, Lj52;->i:Ljava/lang/Object;

    .line 189
    .line 190
    iput v6, v3, Lj52;->l:I

    .line 191
    .line 192
    invoke-virtual {v13, v1, v3}, Lmg0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    if-eq v0, v10, :cond_c

    .line 197
    .line 198
    :goto_3
    check-cast v0, Ljava/lang/Boolean;

    .line 199
    .line 200
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 201
    .line 202
    .line 203
    move-result v0

    .line 204
    if-nez v0, :cond_9

    .line 205
    .line 206
    iput-boolean v8, v15, Lpj5;->i:Z

    .line 207
    .line 208
    iput-object v11, v3, Lj52;->i:Ljava/lang/Object;

    .line 209
    .line 210
    iput v5, v3, Lj52;->l:I

    .line 211
    .line 212
    invoke-interface {v14, v1, v3}, Lx42;->d(Ljava/lang/Object;Lea1;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    if-ne v0, v10, :cond_9

    .line 217
    .line 218
    :cond_c
    :goto_4
    return-object v10

    .line 219
    :pswitch_2
    move-object v0, v1

    .line 220
    check-cast v0, Lf13;

    .line 221
    .line 222
    check-cast v15, Ljava/util/ArrayList;

    .line 223
    .line 224
    instance-of v1, v0, Lzs2;

    .line 225
    .line 226
    if-eqz v1, :cond_d

    .line 227
    .line 228
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    goto :goto_5

    .line 232
    :cond_d
    instance-of v1, v0, Lat2;

    .line 233
    .line 234
    if-eqz v1, :cond_e

    .line 235
    .line 236
    check-cast v0, Lat2;

    .line 237
    .line 238
    iget-object v0, v0, Lat2;->a:Lzs2;

    .line 239
    .line 240
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 241
    .line 242
    .line 243
    goto :goto_5

    .line 244
    :cond_e
    instance-of v1, v0, Lm62;

    .line 245
    .line 246
    if-eqz v1, :cond_f

    .line 247
    .line 248
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    goto :goto_5

    .line 252
    :cond_f
    instance-of v1, v0, Ln62;

    .line 253
    .line 254
    if-eqz v1, :cond_10

    .line 255
    .line 256
    check-cast v0, Ln62;

    .line 257
    .line 258
    iget-object v0, v0, Ln62;->a:Lm62;

    .line 259
    .line 260
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    goto :goto_5

    .line 264
    :cond_10
    instance-of v1, v0, Lk45;

    .line 265
    .line 266
    if-eqz v1, :cond_11

    .line 267
    .line 268
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    goto :goto_5

    .line 272
    :cond_11
    instance-of v1, v0, Ll45;

    .line 273
    .line 274
    if-eqz v1, :cond_12

    .line 275
    .line 276
    check-cast v0, Ll45;

    .line 277
    .line 278
    iget-object v0, v0, Ll45;->a:Lk45;

    .line 279
    .line 280
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    goto :goto_5

    .line 284
    :cond_12
    instance-of v1, v0, Lj45;

    .line 285
    .line 286
    if-eqz v1, :cond_13

    .line 287
    .line 288
    check-cast v0, Lj45;

    .line 289
    .line 290
    iget-object v0, v0, Lj45;->a:Lk45;

    .line 291
    .line 292
    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    :cond_13
    :goto_5
    invoke-static {v15}, Liv0;->F0(Ljava/util/List;)Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    check-cast v0, Lf13;

    .line 300
    .line 301
    check-cast v14, Lnf1;

    .line 302
    .line 303
    new-instance v1, Lb42;

    .line 304
    .line 305
    check-cast v13, Lf42;

    .line 306
    .line 307
    invoke-direct {v1, v13, v0, v11, v4}, Lb42;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 308
    .line 309
    .line 310
    invoke-static {v14, v11, v11, v1, v5}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 311
    .line 312
    .line 313
    return-object v12

    .line 314
    :pswitch_3
    check-cast v15, Ltj5;

    .line 315
    .line 316
    check-cast v14, Lro1;

    .line 317
    .line 318
    instance-of v3, v2, Lqo1;

    .line 319
    .line 320
    if-eqz v3, :cond_14

    .line 321
    .line 322
    move-object v3, v2

    .line 323
    check-cast v3, Lqo1;

    .line 324
    .line 325
    iget v4, v3, Lqo1;->k:I

    .line 326
    .line 327
    and-int v5, v4, v9

    .line 328
    .line 329
    if-eqz v5, :cond_14

    .line 330
    .line 331
    sub-int/2addr v4, v9

    .line 332
    iput v4, v3, Lqo1;->k:I

    .line 333
    .line 334
    goto :goto_6

    .line 335
    :cond_14
    new-instance v3, Lqo1;

    .line 336
    .line 337
    invoke-direct {v3, v0, v2}, Lqo1;-><init>(Lb9;Lea1;)V

    .line 338
    .line 339
    .line 340
    :goto_6
    iget-object v0, v3, Lqo1;->i:Ljava/lang/Object;

    .line 341
    .line 342
    iget v2, v3, Lqo1;->k:I

    .line 343
    .line 344
    if-eqz v2, :cond_17

    .line 345
    .line 346
    if-ne v2, v8, :cond_16

    .line 347
    .line 348
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 349
    .line 350
    .line 351
    :cond_15
    move-object v10, v12

    .line 352
    goto :goto_7

    .line 353
    :cond_16
    invoke-static {v7}, La02;->d(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    move-object v10, v11

    .line 357
    goto :goto_7

    .line 358
    :cond_17
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 359
    .line 360
    .line 361
    iget-object v0, v14, Lro1;->j:Lfa2;

    .line 362
    .line 363
    invoke-interface {v0, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    iget-object v2, v15, Ltj5;->i:Ljava/lang/Object;

    .line 368
    .line 369
    sget-object v4, Li23;->g0:Lj76;

    .line 370
    .line 371
    if-eq v2, v4, :cond_18

    .line 372
    .line 373
    iget-object v4, v14, Lro1;->k:Lja2;

    .line 374
    .line 375
    invoke-interface {v4, v2, v0}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v2

    .line 379
    check-cast v2, Ljava/lang/Boolean;

    .line 380
    .line 381
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 382
    .line 383
    .line 384
    move-result v2

    .line 385
    if-nez v2, :cond_15

    .line 386
    .line 387
    :cond_18
    iput-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast v13, Lx42;

    .line 390
    .line 391
    iput v8, v3, Lqo1;->k:I

    .line 392
    .line 393
    invoke-interface {v13, v1, v3}, Lx42;->d(Ljava/lang/Object;Lea1;)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v0

    .line 397
    if-ne v0, v10, :cond_15

    .line 398
    .line 399
    :goto_7
    return-object v10

    .line 400
    :pswitch_4
    move-object v0, v1

    .line 401
    check-cast v0, Ljava/lang/Number;

    .line 402
    .line 403
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 404
    .line 405
    .line 406
    check-cast v15, Lj44;

    .line 407
    .line 408
    check-cast v14, Ldk0;

    .line 409
    .line 410
    check-cast v13, Lfa2;

    .line 411
    .line 412
    invoke-static {v15, v14, v13}, Lqk0;->c(Lj44;Ldk0;Lfa2;)V

    .line 413
    .line 414
    .line 415
    return-object v12

    .line 416
    :pswitch_5
    move-object v0, v1

    .line 417
    check-cast v0, Ljava/lang/Boolean;

    .line 418
    .line 419
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 420
    .line 421
    .line 422
    move-result v0

    .line 423
    check-cast v14, Lh87;

    .line 424
    .line 425
    check-cast v15, Lf55;

    .line 426
    .line 427
    if-eqz v0, :cond_19

    .line 428
    .line 429
    check-cast v13, Lj44;

    .line 430
    .line 431
    invoke-interface {v13}, Lnl6;->getValue()Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    move-result-object v0

    .line 435
    check-cast v0, Lja2;

    .line 436
    .line 437
    invoke-virtual {v14}, Lh87;->c()Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v1

    .line 441
    iget-object v2, v14, Lh87;->d:Lgx4;

    .line 442
    .line 443
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v2

    .line 447
    invoke-interface {v0, v1, v2}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    check-cast v0, Ljava/lang/Boolean;

    .line 452
    .line 453
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 454
    .line 455
    .line 456
    move-result v4

    .line 457
    :cond_19
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 458
    .line 459
    .line 460
    move-result-object v0

    .line 461
    invoke-virtual {v15, v0}, Lf55;->setValue(Ljava/lang/Object;)V

    .line 462
    .line 463
    .line 464
    return-object v12

    .line 465
    :pswitch_6
    check-cast v15, Ltj5;

    .line 466
    .line 467
    instance-of v3, v2, La9;

    .line 468
    .line 469
    if-eqz v3, :cond_1a

    .line 470
    .line 471
    move-object v3, v2

    .line 472
    check-cast v3, La9;

    .line 473
    .line 474
    iget v4, v3, La9;->l:I

    .line 475
    .line 476
    and-int v5, v4, v9

    .line 477
    .line 478
    if-eqz v5, :cond_1a

    .line 479
    .line 480
    sub-int/2addr v4, v9

    .line 481
    iput v4, v3, La9;->l:I

    .line 482
    .line 483
    goto :goto_8

    .line 484
    :cond_1a
    new-instance v3, La9;

    .line 485
    .line 486
    invoke-direct {v3, v0, v2}, La9;-><init>(Lb9;Lea1;)V

    .line 487
    .line 488
    .line 489
    :goto_8
    iget-object v0, v3, La9;->j:Ljava/lang/Object;

    .line 490
    .line 491
    iget v2, v3, La9;->l:I

    .line 492
    .line 493
    if-eqz v2, :cond_1c

    .line 494
    .line 495
    if-ne v2, v8, :cond_1b

    .line 496
    .line 497
    iget-object v1, v3, La9;->i:Ljava/lang/Object;

    .line 498
    .line 499
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 500
    .line 501
    .line 502
    goto :goto_9

    .line 503
    :cond_1b
    invoke-static {v7}, La02;->d(Ljava/lang/String;)V

    .line 504
    .line 505
    .line 506
    move-object v10, v11

    .line 507
    goto :goto_a

    .line 508
    :cond_1c
    invoke-static {v0}, Lsa3;->a0(Ljava/lang/Object;)V

    .line 509
    .line 510
    .line 511
    iget-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 512
    .line 513
    check-cast v0, Ls33;

    .line 514
    .line 515
    if-eqz v0, :cond_1d

    .line 516
    .line 517
    new-instance v2, Lu8;

    .line 518
    .line 519
    invoke-direct {v2}, Lu8;-><init>()V

    .line 520
    .line 521
    .line 522
    invoke-interface {v0, v2}, Ls33;->c(Ljava/util/concurrent/CancellationException;)V

    .line 523
    .line 524
    .line 525
    iput-object v1, v3, La9;->i:Ljava/lang/Object;

    .line 526
    .line 527
    iput v8, v3, La9;->l:I

    .line 528
    .line 529
    invoke-interface {v0, v3}, Ls33;->G(Lea1;)Ljava/lang/Object;

    .line 530
    .line 531
    .line 532
    move-result-object v0

    .line 533
    if-eq v0, v10, :cond_1e

    .line 534
    .line 535
    :cond_1d
    :goto_9
    move-object v4, v1

    .line 536
    move-object v5, v14

    .line 537
    check-cast v5, Lnf1;

    .line 538
    .line 539
    new-instance v2, Ln2;

    .line 540
    .line 541
    move-object v3, v13

    .line 542
    check-cast v3, Lja2;

    .line 543
    .line 544
    const/4 v7, 0x2

    .line 545
    const/4 v6, 0x0

    .line 546
    invoke-direct/range {v2 .. v7}, Ln2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 547
    .line 548
    .line 549
    sget-object v0, Lqf1;->l:Lqf1;

    .line 550
    .line 551
    invoke-static {v5, v6, v0, v2, v8}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 552
    .line 553
    .line 554
    move-result-object v0

    .line 555
    iput-object v0, v15, Ltj5;->i:Ljava/lang/Object;

    .line 556
    .line 557
    move-object v10, v12

    .line 558
    :cond_1e
    :goto_a
    return-object v10

    .line 559
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
