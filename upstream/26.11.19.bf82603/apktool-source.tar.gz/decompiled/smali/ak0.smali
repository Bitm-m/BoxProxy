.class public final synthetic Lak0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:F

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Lra2;


# direct methods
.method public synthetic constructor <init>(Lj44;Lj44;Lu92;F)V
    .locals 1

    .line 18
    const/4 v0, 0x1

    iput-byte v0, p0, Lak0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lak0;->k:Ljava/lang/Object;

    iput-object p2, p0, Lak0;->l:Ljava/lang/Object;

    iput-object p3, p0, Lak0;->m:Lra2;

    iput p4, p0, Lak0;->j:F

    return-void
.end method

.method public synthetic constructor <init>(Lw04;FLvv;Lfa2;I)V
    .locals 0

    .line 1
    const/4 p5, 0x3

    .line 2
    iput-byte p5, p0, Lak0;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lak0;->k:Ljava/lang/Object;

    .line 8
    .line 9
    iput p2, p0, Lak0;->j:F

    .line 10
    .line 11
    iput-object p3, p0, Lak0;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lak0;->m:Lra2;

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Lw04;FLyz0;Lyz0;I)V
    .locals 0

    .line 16
    const/4 p5, 0x2

    iput-byte p5, p0, Lak0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lak0;->k:Ljava/lang/Object;

    iput p2, p0, Lak0;->j:F

    iput-object p3, p0, Lak0;->m:Lra2;

    iput-object p4, p0, Lak0;->l:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lw04;Ltj0;FLyz0;)V
    .locals 1

    .line 17
    const/4 v0, 0x0

    iput-byte v0, p0, Lak0;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lak0;->k:Ljava/lang/Object;

    iput-object p2, p0, Lak0;->l:Ljava/lang/Object;

    iput p3, p0, Lak0;->j:F

    iput-object p4, p0, Lak0;->m:Lra2;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lak0;->i:B

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    sget-object v5, Lxc7;->a:Lxc7;

    .line 9
    .line 10
    iget-object v6, v0, Lak0;->m:Lra2;

    .line 11
    .line 12
    iget-object v7, v0, Lak0;->l:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v8, v0, Lak0;->k:Ljava/lang/Object;

    .line 15
    .line 16
    packed-switch v1, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    move-object v9, v8

    .line 20
    check-cast v9, Lw04;

    .line 21
    .line 22
    move-object v11, v7

    .line 23
    check-cast v11, Lvv;

    .line 24
    .line 25
    move-object v12, v6

    .line 26
    check-cast v12, Lfa2;

    .line 27
    .line 28
    move-object/from16 v13, p1

    .line 29
    .line 30
    check-cast v13, Lib2;

    .line 31
    .line 32
    move-object/from16 v1, p2

    .line 33
    .line 34
    check-cast v1, Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    invoke-static {v4}, Lcc3;->X(I)I

    .line 40
    .line 41
    .line 42
    move-result v14

    .line 43
    iget v10, v0, Lak0;->j:F

    .line 44
    .line 45
    invoke-static/range {v9 .. v14}, Lkb3;->g(Lw04;FLvv;Lfa2;Lib2;I)V

    .line 46
    .line 47
    .line 48
    return-object v5

    .line 49
    :pswitch_0
    move-object v15, v8

    .line 50
    check-cast v15, Lw04;

    .line 51
    .line 52
    move-object/from16 v17, v6

    .line 53
    .line 54
    check-cast v17, Lyz0;

    .line 55
    .line 56
    move-object/from16 v18, v7

    .line 57
    .line 58
    check-cast v18, Lyz0;

    .line 59
    .line 60
    move-object/from16 v19, p1

    .line 61
    .line 62
    check-cast v19, Lib2;

    .line 63
    .line 64
    move-object/from16 v1, p2

    .line 65
    .line 66
    check-cast v1, Ljava/lang/Integer;

    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    const/16 v1, 0xc01

    .line 72
    .line 73
    invoke-static {v1}, Lcc3;->X(I)I

    .line 74
    .line 75
    .line 76
    move-result v20

    .line 77
    iget v0, v0, Lak0;->j:F

    .line 78
    .line 79
    move/from16 v16, v0

    .line 80
    .line 81
    invoke-static/range {v15 .. v20}, Lmm0;->i(Lw04;FLyz0;Lyz0;Lib2;I)V

    .line 82
    .line 83
    .line 84
    return-object v5

    .line 85
    :pswitch_1
    check-cast v8, Lj44;

    .line 86
    .line 87
    check-cast v7, Lj44;

    .line 88
    .line 89
    check-cast v6, Lu92;

    .line 90
    .line 91
    move-object/from16 v15, p1

    .line 92
    .line 93
    check-cast v15, Lib2;

    .line 94
    .line 95
    move-object/from16 v1, p2

    .line 96
    .line 97
    check-cast v1, Ljava/lang/Integer;

    .line 98
    .line 99
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    and-int/lit8 v9, v1, 0x3

    .line 104
    .line 105
    if-eq v9, v2, :cond_0

    .line 106
    .line 107
    move v9, v4

    .line 108
    goto :goto_0

    .line 109
    :cond_0
    move v9, v3

    .line 110
    :goto_0
    and-int/2addr v1, v4

    .line 111
    invoke-virtual {v15, v1, v9}, Lib2;->X(IZ)Z

    .line 112
    .line 113
    .line 114
    move-result v1

    .line 115
    if-eqz v1, :cond_1

    .line 116
    .line 117
    invoke-interface {v8}, Lnl6;->getValue()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    check-cast v1, Ljava/lang/Boolean;

    .line 122
    .line 123
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    sget-object v1, Lsb0;->b:Lhg1;

    .line 128
    .line 129
    const/16 v4, 0xfa

    .line 130
    .line 131
    invoke-static {v4, v3, v1, v2}, Lfv6;->M(IILut1;I)Lb97;

    .line 132
    .line 133
    .line 134
    move-result-object v8

    .line 135
    const/16 v10, 0xe

    .line 136
    .line 137
    invoke-static {v8, v10}, Lhz1;->d(Lb97;I)Lnz1;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    invoke-static {v4, v3, v1, v2}, Lfv6;->M(IILut1;I)Lb97;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    invoke-static {v1, v2}, Lhz1;->e(Lg32;I)Lnz1;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    invoke-virtual {v8, v1}, Lnz1;->a(Lnz1;)Lnz1;

    .line 150
    .line 151
    .line 152
    move-result-object v11

    .line 153
    sget-object v1, Lsb0;->c:Lhg1;

    .line 154
    .line 155
    const/16 v4, 0x78

    .line 156
    .line 157
    invoke-static {v4, v3, v1, v2}, Lfv6;->M(IILut1;I)Lb97;

    .line 158
    .line 159
    .line 160
    move-result-object v8

    .line 161
    invoke-static {v8, v10}, Lhz1;->j(Lb97;I)Lg12;

    .line 162
    .line 163
    .line 164
    move-result-object v8

    .line 165
    invoke-static {v4, v3, v1, v2}, Lfv6;->M(IILut1;I)Lb97;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    invoke-static {v1, v2}, Lhz1;->f(Lg32;I)Lg12;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-virtual {v8, v1}, Lg12;->a(Lg12;)Lg12;

    .line 174
    .line 175
    .line 176
    move-result-object v12

    .line 177
    new-instance v1, Ldq0;

    .line 178
    .line 179
    iget v0, v0, Lak0;->j:F

    .line 180
    .line 181
    invoke-direct {v1, v7, v6, v0}, Ldq0;-><init>(Lj44;Lu92;F)V

    .line 182
    .line 183
    .line 184
    const v0, -0x4e4912f4

    .line 185
    .line 186
    .line 187
    invoke-static {v0, v1, v15}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 188
    .line 189
    .line 190
    move-result-object v14

    .line 191
    const/high16 v16, 0x30000

    .line 192
    .line 193
    const/16 v17, 0x12

    .line 194
    .line 195
    const/4 v10, 0x0

    .line 196
    const/4 v13, 0x0

    .line 197
    invoke-static/range {v9 .. v17}, Lko3;->P(ZLw04;Lnz1;Lg12;Ljava/lang/String;Lyz0;Lib2;II)V

    .line 198
    .line 199
    .line 200
    goto :goto_1

    .line 201
    :cond_1
    invoke-virtual {v15}, Lib2;->a0()V

    .line 202
    .line 203
    .line 204
    :goto_1
    return-object v5

    .line 205
    :pswitch_2
    check-cast v8, Lw04;

    .line 206
    .line 207
    check-cast v7, Ltj0;

    .line 208
    .line 209
    check-cast v6, Lyz0;

    .line 210
    .line 211
    move-object/from16 v13, p1

    .line 212
    .line 213
    check-cast v13, Lib2;

    .line 214
    .line 215
    move-object/from16 v1, p2

    .line 216
    .line 217
    check-cast v1, Ljava/lang/Integer;

    .line 218
    .line 219
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 220
    .line 221
    .line 222
    move-result v1

    .line 223
    and-int/lit8 v9, v1, 0x3

    .line 224
    .line 225
    if-eq v9, v2, :cond_2

    .line 226
    .line 227
    move v2, v4

    .line 228
    goto :goto_2

    .line 229
    :cond_2
    move v2, v3

    .line 230
    :goto_2
    and-int/2addr v1, v4

    .line 231
    invoke-virtual {v13, v1, v2}, Lib2;->X(IZ)Z

    .line 232
    .line 233
    .line 234
    move-result v1

    .line 235
    if-eqz v1, :cond_5

    .line 236
    .line 237
    invoke-virtual {v13}, Lib2;->S()Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    sget-object v2, Lg21;->a:Ley0;

    .line 242
    .line 243
    if-ne v1, v2, :cond_3

    .line 244
    .line 245
    new-instance v1, Lfb0;

    .line 246
    .line 247
    const/16 v2, 0x16

    .line 248
    .line 249
    invoke-direct {v1, v2}, Lfb0;-><init>(B)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v13, v1}, Lib2;->p0(Ljava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    :cond_3
    check-cast v1, Lfa2;

    .line 256
    .line 257
    invoke-static {v8, v3, v1}, Ln76;->a(Lw04;ZLfa2;)Lw04;

    .line 258
    .line 259
    .line 260
    move-result-object v9

    .line 261
    iget-wide v10, v7, Ltj0;->a:J

    .line 262
    .line 263
    const/4 v14, 0x0

    .line 264
    iget v12, v0, Lak0;->j:F

    .line 265
    .line 266
    invoke-static/range {v9 .. v14}, Lrk6;->j(Lw04;JFLib2;I)Lw04;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    sget-object v1, Lu6;->k:Lt20;

    .line 271
    .line 272
    invoke-static {v1, v4}, Lnb0;->c(Lt20;Z)Lor3;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    iget-wide v7, v13, Lib2;->T:J

    .line 277
    .line 278
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 279
    .line 280
    .line 281
    move-result v2

    .line 282
    invoke-virtual {v13}, Lib2;->m()Liz4;

    .line 283
    .line 284
    .line 285
    move-result-object v7

    .line 286
    invoke-static {v13, v0}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    sget-object v8, Lx11;->d:Lu6;

    .line 291
    .line 292
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 293
    .line 294
    .line 295
    invoke-virtual {v13}, Lib2;->j0()V

    .line 296
    .line 297
    .line 298
    iget-boolean v8, v13, Lib2;->S:Z

    .line 299
    .line 300
    if-eqz v8, :cond_4

    .line 301
    .line 302
    sget-object v8, Laa3;->a0:Lg53;

    .line 303
    .line 304
    invoke-virtual {v13, v8}, Lib2;->l(Lu92;)V

    .line 305
    .line 306
    .line 307
    goto :goto_3

    .line 308
    :cond_4
    invoke-virtual {v13}, Lib2;->s0()V

    .line 309
    .line 310
    .line 311
    :goto_3
    sget-object v8, Lu6;->S:Lc11;

    .line 312
    .line 313
    invoke-static {v8, v13, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    sget-object v1, Lu6;->R:Lc11;

    .line 317
    .line 318
    invoke-static {v1, v13, v7}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 319
    .line 320
    .line 321
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    sget-object v2, Lu6;->T:Lc11;

    .line 326
    .line 327
    invoke-static {v2, v13, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 328
    .line 329
    .line 330
    invoke-static {v13}, Lwt6;->m(Lib2;)V

    .line 331
    .line 332
    .line 333
    sget-object v1, Lu6;->Q:Lc11;

    .line 334
    .line 335
    invoke-static {v1, v13, v0}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    invoke-static {v3, v6, v13, v4}, Lmz1;->u(ILyz0;Lib2;Z)V

    .line 339
    .line 340
    .line 341
    goto :goto_4

    .line 342
    :cond_5
    invoke-virtual {v13}, Lib2;->a0()V

    .line 343
    .line 344
    .line 345
    :goto_4
    return-object v5

    .line 346
    nop

    .line 347
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
