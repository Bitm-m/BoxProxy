.class public final Laz1;
.super Lc83;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic j:Lh87;

.field public final synthetic k:Lu92;

.field public final synthetic l:I


# direct methods
.method public constructor <init>(Lh87;Lu92;I)V
    .locals 0

    .line 1
    iput-object p1, p0, Laz1;->j:Lh87;

    .line 2
    .line 3
    iput-object p2, p0, Laz1;->k:Lu92;

    .line 4
    .line 5
    iput p3, p0, Laz1;->l:I

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1}, Lc83;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    check-cast p1, Lib2;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Number;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 6
    .line 7
    .line 8
    iget p2, p0, Laz1;->l:I

    .line 9
    .line 10
    or-int/lit8 p2, p2, 0x1

    .line 11
    .line 12
    invoke-static {p2}, Lcc3;->X(I)I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    iget-object v0, p0, Laz1;->j:Lh87;

    .line 17
    .line 18
    iget-object p0, p0, Laz1;->k:Lu92;

    .line 19
    .line 20
    invoke-static {v0, p0, p1, p2}, Lhz1;->a(Lh87;Lu92;Lib2;I)V

    .line 21
    .line 22
    .line 23
    sget-object p0, Lxc7;->a:Lxc7;

    .line 24
    .line 25
    return-object p0
.end method
