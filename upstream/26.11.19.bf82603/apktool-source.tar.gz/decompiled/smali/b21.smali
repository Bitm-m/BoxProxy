.class public final Lb21;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final a:Landroid/view/View;

.field public b:Z

.field public c:Lq21;

.field public d:Lhf3;

.field public e:Lq06;

.field public f:Lyg7;

.field public final g:Llw2;

.field public final h:Lem5;

.field public final i:Landroid/content/res/Configuration;

.field public final j:Lgx4;

.field public final k:Lj6;

.field public final l:Lrf;

.field public final m:Loq;

.field public final n:Laa;

.field public final o:Lj6;

.field public final p:Lgx4;

.field public final q:Li05;

.field public final r:Luf;

.field public final s:Lca3;

.field public final t:Lge3;

.field public final u:Lqj0;

.field public v:I

.field public final w:Lid;

.field public x:Lpe;

.field public final y:La21;


# direct methods
.method public constructor <init>(Lb21;Landroid/view/View;Lq21;Lhf3;Lq06;Lyg7;)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_0

    .line 3
    .line 4
    iget-object v1, p1, Lb21;->a:Landroid/view/View;

    .line 5
    .line 6
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    goto :goto_0

    .line 11
    :cond_0
    move-object v1, v0

    .line 12
    :goto_0
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-static {v1, v2}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p2, p0, Lb21;->a:Landroid/view/View;

    .line 24
    .line 25
    iput-object p3, p0, Lb21;->c:Lq21;

    .line 26
    .line 27
    iput-object p4, p0, Lb21;->d:Lhf3;

    .line 28
    .line 29
    iput-object p5, p0, Lb21;->e:Lq06;

    .line 30
    .line 31
    iput-object p6, p0, Lb21;->f:Lyg7;

    .line 32
    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    iget-object p3, p1, Lb21;->g:Llw2;

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_1
    new-instance p3, Llw2;

    .line 42
    .line 43
    invoke-direct {p3}, Llw2;-><init>()V

    .line 44
    .line 45
    .line 46
    :goto_1
    iput-object p3, p0, Lb21;->g:Llw2;

    .line 47
    .line 48
    if-eqz p1, :cond_2

    .line 49
    .line 50
    iget-object p3, p1, Lb21;->h:Lem5;

    .line 51
    .line 52
    goto :goto_2

    .line 53
    :cond_2
    new-instance p3, Lem5;

    .line 54
    .line 55
    invoke-direct {p3}, Lem5;-><init>()V

    .line 56
    .line 57
    .line 58
    :goto_2
    iput-object p3, p0, Lb21;->h:Lem5;

    .line 59
    .line 60
    if-eqz v1, :cond_3

    .line 61
    .line 62
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    .line 64
    .line 65
    iget-object p3, p1, Lb21;->i:Landroid/content/res/Configuration;

    .line 66
    .line 67
    goto :goto_3

    .line 68
    :cond_3
    new-instance p3, Landroid/content/res/Configuration;

    .line 69
    .line 70
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 71
    .line 72
    .line 73
    move-result-object p4

    .line 74
    invoke-virtual {p4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 75
    .line 76
    .line 77
    move-result-object p4

    .line 78
    invoke-virtual {p4}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 79
    .line 80
    .line 81
    move-result-object p4

    .line 82
    invoke-direct {p3, p4}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 83
    .line 84
    .line 85
    :goto_3
    iput-object p3, p0, Lb21;->i:Landroid/content/res/Configuration;

    .line 86
    .line 87
    if-eqz v1, :cond_4

    .line 88
    .line 89
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    iget-object p3, p1, Lb21;->j:Lgx4;

    .line 93
    .line 94
    goto :goto_4

    .line 95
    :cond_4
    new-instance p4, Landroid/content/res/Configuration;

    .line 96
    .line 97
    invoke-direct {p4, p3}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 98
    .line 99
    .line 100
    invoke-static {p4}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 101
    .line 102
    .line 103
    move-result-object p3

    .line 104
    :goto_4
    iput-object p3, p0, Lb21;->j:Lgx4;

    .line 105
    .line 106
    const/4 p3, 0x2

    .line 107
    if-eqz v1, :cond_5

    .line 108
    .line 109
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    iget-object p4, p1, Lb21;->k:Lj6;

    .line 113
    .line 114
    goto :goto_5

    .line 115
    :cond_5
    new-instance p4, Lj6;

    .line 116
    .line 117
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 118
    .line 119
    .line 120
    move-result-object p5

    .line 121
    invoke-direct {p4, p3}, Lj6;-><init>(B)V

    .line 122
    .line 123
    .line 124
    const-string p6, "accessibility"

    .line 125
    .line 126
    invoke-virtual {p5, p6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object p5

    .line 130
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    .line 132
    .line 133
    check-cast p5, Landroid/view/accessibility/AccessibilityManager;

    .line 134
    .line 135
    :goto_5
    iput-object p4, p0, Lb21;->k:Lj6;

    .line 136
    .line 137
    if-eqz v1, :cond_6

    .line 138
    .line 139
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 140
    .line 141
    .line 142
    iget-object p4, p1, Lb21;->l:Lrf;

    .line 143
    .line 144
    goto :goto_6

    .line 145
    :cond_6
    new-instance p4, Lrf;

    .line 146
    .line 147
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 148
    .line 149
    .line 150
    move-result-object p5

    .line 151
    invoke-direct {p4, p5}, Lrf;-><init>(Landroid/content/Context;)V

    .line 152
    .line 153
    .line 154
    :goto_6
    iput-object p4, p0, Lb21;->l:Lrf;

    .line 155
    .line 156
    if-eqz v1, :cond_7

    .line 157
    .line 158
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 159
    .line 160
    .line 161
    iget-object p3, p1, Lb21;->m:Loq;

    .line 162
    .line 163
    goto :goto_7

    .line 164
    :cond_7
    new-instance p4, Loq;

    .line 165
    .line 166
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 167
    .line 168
    .line 169
    move-result-object p5

    .line 170
    invoke-direct {p4, p5, p3}, Loq;-><init>(Ljava/lang/Object;B)V

    .line 171
    .line 172
    .line 173
    move-object p3, p4

    .line 174
    :goto_7
    iput-object p3, p0, Lb21;->m:Loq;

    .line 175
    .line 176
    if-eqz v1, :cond_8

    .line 177
    .line 178
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 179
    .line 180
    .line 181
    iget-object p3, p1, Lb21;->n:Laa;

    .line 182
    .line 183
    goto :goto_8

    .line 184
    :cond_8
    new-instance p4, Laa;

    .line 185
    .line 186
    invoke-direct {p4, p3}, Laa;-><init>(Loq;)V

    .line 187
    .line 188
    .line 189
    move-object p3, p4

    .line 190
    :goto_8
    iput-object p3, p0, Lb21;->n:Laa;

    .line 191
    .line 192
    if-eqz v1, :cond_9

    .line 193
    .line 194
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    .line 196
    .line 197
    iget-object p3, p1, Lb21;->o:Lj6;

    .line 198
    .line 199
    goto :goto_9

    .line 200
    :cond_9
    new-instance p3, Lj6;

    .line 201
    .line 202
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 203
    .line 204
    .line 205
    const/4 p4, 0x4

    .line 206
    invoke-direct {p3, p4}, Lj6;-><init>(B)V

    .line 207
    .line 208
    .line 209
    :goto_9
    iput-object p3, p0, Lb21;->o:Lj6;

    .line 210
    .line 211
    if-eqz v1, :cond_a

    .line 212
    .line 213
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 214
    .line 215
    .line 216
    iget-object p3, p1, Lb21;->p:Lgx4;

    .line 217
    .line 218
    goto :goto_a

    .line 219
    :cond_a
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 220
    .line 221
    .line 222
    move-result-object p3

    .line 223
    invoke-static {p3}, Lhs;->D(Landroid/content/Context;)Lu72;

    .line 224
    .line 225
    .line 226
    move-result-object p3

    .line 227
    sget-object p4, Luj5;->j:Luj5;

    .line 228
    .line 229
    new-instance p5, Lgx4;

    .line 230
    .line 231
    invoke-direct {p5, p3, p4}, Lgx4;-><init>(Ljava/lang/Object;Lki6;)V

    .line 232
    .line 233
    .line 234
    move-object p3, p5

    .line 235
    :goto_a
    iput-object p3, p0, Lb21;->p:Lgx4;

    .line 236
    .line 237
    if-eqz p1, :cond_b

    .line 238
    .line 239
    iget-object v0, p1, Lb21;->a:Landroid/view/View;

    .line 240
    .line 241
    :cond_b
    if-ne p2, v0, :cond_c

    .line 242
    .line 243
    iget-object p3, p1, Lb21;->q:Li05;

    .line 244
    .line 245
    goto :goto_b

    .line 246
    :cond_c
    new-instance p3, Li05;

    .line 247
    .line 248
    invoke-direct {p3, p2}, Li05;-><init>(Landroid/view/View;)V

    .line 249
    .line 250
    .line 251
    :goto_b
    iput-object p3, p0, Lb21;->q:Li05;

    .line 252
    .line 253
    if-eqz v1, :cond_d

    .line 254
    .line 255
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 256
    .line 257
    .line 258
    iget-object p2, p1, Lb21;->r:Luf;

    .line 259
    .line 260
    goto :goto_c

    .line 261
    :cond_d
    new-instance p3, Luf;

    .line 262
    .line 263
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 264
    .line 265
    .line 266
    move-result-object p2

    .line 267
    invoke-static {p2}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 268
    .line 269
    .line 270
    move-result-object p2

    .line 271
    invoke-direct {p3, p2}, Luf;-><init>(Landroid/view/ViewConfiguration;)V

    .line 272
    .line 273
    .line 274
    move-object p2, p3

    .line 275
    :goto_c
    iput-object p2, p0, Lb21;->r:Luf;

    .line 276
    .line 277
    if-eqz p1, :cond_e

    .line 278
    .line 279
    iget-object p2, p1, Lb21;->s:Lca3;

    .line 280
    .line 281
    goto :goto_d

    .line 282
    :cond_e
    new-instance p2, Lca3;

    .line 283
    .line 284
    invoke-direct {p2}, Lca3;-><init>()V

    .line 285
    .line 286
    .line 287
    :goto_d
    iput-object p2, p0, Lb21;->s:Lca3;

    .line 288
    .line 289
    new-instance p2, Lge3;

    .line 290
    .line 291
    invoke-direct {p2}, Lge3;-><init>()V

    .line 292
    .line 293
    .line 294
    iput-object p2, p0, Lb21;->t:Lge3;

    .line 295
    .line 296
    if-eqz p1, :cond_f

    .line 297
    .line 298
    iget-object p1, p1, Lb21;->u:Lqj0;

    .line 299
    .line 300
    goto :goto_e

    .line 301
    :cond_f
    new-instance p1, Lqj0;

    .line 302
    .line 303
    invoke-direct {p1}, Lqj0;-><init>()V

    .line 304
    .line 305
    .line 306
    :goto_e
    iput-object p1, p0, Lb21;->u:Lqj0;

    .line 307
    .line 308
    new-instance p1, Lid;

    .line 309
    .line 310
    const/16 p2, 0x13

    .line 311
    .line 312
    invoke-direct {p1, p0, p2}, Lid;-><init>(Ljava/lang/Object;B)V

    .line 313
    .line 314
    .line 315
    iput-object p1, p0, Lb21;->w:Lid;

    .line 316
    .line 317
    new-instance p1, La21;

    .line 318
    .line 319
    invoke-direct {p1, p0}, La21;-><init>(Lb21;)V

    .line 320
    .line 321
    .line 322
    iput-object p1, p0, Lb21;->y:La21;

    .line 323
    .line 324
    return-void
.end method


# virtual methods
.method public final a(Lsa;Lyz0;Lib2;I)V
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    move/from16 v4, p4

    .line 10
    .line 11
    const v5, 0x761ec9f

    .line 12
    .line 13
    .line 14
    invoke-virtual {v3, v5}, Lib2;->h0(I)Lib2;

    .line 15
    .line 16
    .line 17
    invoke-virtual {v3, v1}, Lib2;->i(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    if-eqz v5, :cond_0

    .line 22
    .line 23
    const/4 v5, 0x4

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v5, 0x2

    .line 26
    :goto_0
    or-int/2addr v5, v4

    .line 27
    invoke-virtual {v3, v2}, Lib2;->i(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v7

    .line 31
    if-eqz v7, :cond_1

    .line 32
    .line 33
    const/16 v7, 0x20

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_1
    const/16 v7, 0x10

    .line 37
    .line 38
    :goto_1
    or-int/2addr v5, v7

    .line 39
    invoke-virtual {v3, v0}, Lib2;->i(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v7

    .line 43
    if-eqz v7, :cond_2

    .line 44
    .line 45
    const/16 v7, 0x100

    .line 46
    .line 47
    goto :goto_2

    .line 48
    :cond_2
    const/16 v7, 0x80

    .line 49
    .line 50
    :goto_2
    or-int/2addr v5, v7

    .line 51
    and-int/lit16 v7, v5, 0x93

    .line 52
    .line 53
    const/16 v8, 0x92

    .line 54
    .line 55
    const/4 v9, 0x1

    .line 56
    if-eq v7, v8, :cond_3

    .line 57
    .line 58
    move v7, v9

    .line 59
    goto :goto_3

    .line 60
    :cond_3
    const/4 v7, 0x0

    .line 61
    :goto_3
    and-int/2addr v5, v9

    .line 62
    invoke-virtual {v3, v5, v7}, Lib2;->X(IZ)Z

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    if-eqz v5, :cond_14

    .line 67
    .line 68
    const v5, 0x7f090078

    .line 69
    .line 70
    .line 71
    invoke-virtual {v1, v5}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    instance-of v8, v7, Ljava/util/Set;

    .line 76
    .line 77
    const/4 v10, 0x0

    .line 78
    if-eqz v8, :cond_5

    .line 79
    .line 80
    instance-of v8, v7, Lt63;

    .line 81
    .line 82
    if-eqz v8, :cond_4

    .line 83
    .line 84
    instance-of v8, v7, Lx63;

    .line 85
    .line 86
    if-eqz v8, :cond_5

    .line 87
    .line 88
    :cond_4
    check-cast v7, Ljava/util/Set;

    .line 89
    .line 90
    goto :goto_4

    .line 91
    :cond_5
    move-object v7, v10

    .line 92
    :goto_4
    if-nez v7, :cond_9

    .line 93
    .line 94
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 95
    .line 96
    .line 97
    move-result-object v7

    .line 98
    instance-of v8, v7, Landroid/view/View;

    .line 99
    .line 100
    if-eqz v8, :cond_6

    .line 101
    .line 102
    check-cast v7, Landroid/view/View;

    .line 103
    .line 104
    goto :goto_5

    .line 105
    :cond_6
    move-object v7, v10

    .line 106
    :goto_5
    if-eqz v7, :cond_7

    .line 107
    .line 108
    invoke-virtual {v7, v5}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object v5

    .line 112
    goto :goto_6

    .line 113
    :cond_7
    move-object v5, v10

    .line 114
    :goto_6
    instance-of v7, v5, Ljava/util/Set;

    .line 115
    .line 116
    if-eqz v7, :cond_a

    .line 117
    .line 118
    instance-of v7, v5, Lt63;

    .line 119
    .line 120
    if-eqz v7, :cond_8

    .line 121
    .line 122
    instance-of v7, v5, Lx63;

    .line 123
    .line 124
    if-eqz v7, :cond_a

    .line 125
    .line 126
    :cond_8
    move-object v10, v5

    .line 127
    check-cast v10, Ljava/util/Set;

    .line 128
    .line 129
    goto :goto_7

    .line 130
    :cond_9
    move-object v10, v7

    .line 131
    :cond_a
    :goto_7
    if-eqz v10, :cond_b

    .line 132
    .line 133
    invoke-virtual {v3}, Lib2;->A()Ls21;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    invoke-interface {v10, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    iput-boolean v9, v3, Lib2;->q:Z

    .line 141
    .line 142
    iput-boolean v9, v3, Lib2;->C:Z

    .line 143
    .line 144
    iget-object v5, v3, Lib2;->c:Lhh6;

    .line 145
    .line 146
    invoke-virtual {v5}, Lhh6;->b()V

    .line 147
    .line 148
    .line 149
    iget-object v5, v3, Lib2;->H:Lhh6;

    .line 150
    .line 151
    invoke-virtual {v5}, Lhh6;->b()V

    .line 152
    .line 153
    .line 154
    iget-object v5, v3, Lib2;->I:Lkh6;

    .line 155
    .line 156
    iget-object v7, v5, Lkh6;->a:Lhh6;

    .line 157
    .line 158
    iget-object v8, v7, Lhh6;->r:Ljava/util/HashMap;

    .line 159
    .line 160
    iput-object v8, v5, Lkh6;->e:Ljava/util/HashMap;

    .line 161
    .line 162
    iget-object v7, v7, Lhh6;->s:Lh34;

    .line 163
    .line 164
    iput-object v7, v5, Lkh6;->f:Lh34;

    .line 165
    .line 166
    :cond_b
    invoke-virtual {v1}, Lsa;->getView()Landroid/view/View;

    .line 167
    .line 168
    .line 169
    move-result-object v5

    .line 170
    invoke-virtual {v3, v5}, Lib2;->g(Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    move-result v5

    .line 174
    invoke-virtual {v3}, Lib2;->S()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v7

    .line 178
    sget-object v8, Lg21;->a:Ley0;

    .line 179
    .line 180
    if-nez v5, :cond_c

    .line 181
    .line 182
    if-ne v7, v8, :cond_d

    .line 183
    .line 184
    :cond_c
    new-instance v7, Lmh7;

    .line 185
    .line 186
    invoke-virtual {v1}, Lsa;->getView()Landroid/view/View;

    .line 187
    .line 188
    .line 189
    move-result-object v5

    .line 190
    invoke-direct {v7, v5}, Lmh7;-><init>(Landroid/view/View;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v3, v7}, Lib2;->p0(Ljava/lang/Object;)V

    .line 194
    .line 195
    .line 196
    :cond_d
    check-cast v7, Lmh7;

    .line 197
    .line 198
    sget-object v5, Lhk3;->a:Lnt1;

    .line 199
    .line 200
    invoke-virtual {v0}, Lb21;->d()Lhf3;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    invoke-virtual {v5, v9}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 205
    .line 206
    .line 207
    move-result-object v11

    .line 208
    sget-object v5, Lmk3;->a:Lh65;

    .line 209
    .line 210
    invoke-virtual {v0}, Lb21;->g()V

    .line 211
    .line 212
    .line 213
    iget-object v9, v0, Lb21;->e:Lq06;

    .line 214
    .line 215
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 216
    .line 217
    .line 218
    invoke-virtual {v5, v9}, Lh65;->a(Ljava/lang/Object;)Ll65;

    .line 219
    .line 220
    .line 221
    move-result-object v12

    .line 222
    sget-object v5, Lib;->d:Lnt1;

    .line 223
    .line 224
    iget-object v9, v0, Lb21;->g:Llw2;

    .line 225
    .line 226
    invoke-virtual {v5, v9}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 227
    .line 228
    .line 229
    move-result-object v13

    .line 230
    sget-object v5, Lib;->e:Lnt1;

    .line 231
    .line 232
    iget-object v9, v0, Lb21;->h:Lem5;

    .line 233
    .line 234
    invoke-virtual {v5, v9}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 235
    .line 236
    .line 237
    move-result-object v14

    .line 238
    sget-object v5, Lc31;->w:Lnt1;

    .line 239
    .line 240
    invoke-virtual {v3, v0}, Lib2;->i(Ljava/lang/Object;)Z

    .line 241
    .line 242
    .line 243
    move-result v9

    .line 244
    invoke-virtual {v3}, Lib2;->S()Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v15

    .line 248
    const/4 v6, 0x3

    .line 249
    if-nez v9, :cond_e

    .line 250
    .line 251
    if-ne v15, v8, :cond_f

    .line 252
    .line 253
    :cond_e
    new-instance v15, Lde0;

    .line 254
    .line 255
    invoke-direct {v15, v0, v6}, Lde0;-><init>(Ljava/lang/Object;B)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v3, v15}, Lib2;->p0(Ljava/lang/Object;)V

    .line 259
    .line 260
    .line 261
    :cond_f
    check-cast v15, Lfa2;

    .line 262
    .line 263
    invoke-virtual {v5, v15}, Lh65;->c(Lfa2;)Ll65;

    .line 264
    .line 265
    .line 266
    move-result-object v15

    .line 267
    sget-object v5, Lib;->b:Lnt1;

    .line 268
    .line 269
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 270
    .line 271
    .line 272
    move-result-object v9

    .line 273
    invoke-virtual {v5, v9}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 274
    .line 275
    .line 276
    move-result-object v5

    .line 277
    sget-object v9, Ltz2;->a:Lnt1;

    .line 278
    .line 279
    invoke-virtual {v9, v10}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 280
    .line 281
    .line 282
    move-result-object v17

    .line 283
    sget-object v9, Lib;->a:Lnt1;

    .line 284
    .line 285
    invoke-virtual {v1}, Lsa;->getConfiguration()Landroid/content/res/Configuration;

    .line 286
    .line 287
    .line 288
    move-result-object v10

    .line 289
    invoke-virtual {v9, v10}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 290
    .line 291
    .line 292
    move-result-object v18

    .line 293
    sget-object v9, Lg06;->a:Lnt1;

    .line 294
    .line 295
    invoke-virtual {v3, v1}, Lib2;->i(Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v10

    .line 299
    invoke-virtual {v3}, Lib2;->S()Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    if-nez v10, :cond_10

    .line 304
    .line 305
    if-ne v6, v8, :cond_11

    .line 306
    .line 307
    :cond_10
    new-instance v6, Lba;

    .line 308
    .line 309
    const/4 v10, 0x3

    .line 310
    invoke-direct {v6, v1, v10}, Lba;-><init>(Lsa;B)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {v3, v6}, Lib2;->p0(Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    :cond_11
    check-cast v6, Lfa2;

    .line 317
    .line 318
    invoke-virtual {v9, v6}, Lh65;->c(Lfa2;)Ll65;

    .line 319
    .line 320
    .line 321
    move-result-object v19

    .line 322
    sget-object v6, Lib;->f:Lnt1;

    .line 323
    .line 324
    invoke-virtual {v1}, Lsa;->getView()Landroid/view/View;

    .line 325
    .line 326
    .line 327
    move-result-object v9

    .line 328
    invoke-virtual {v6, v9}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 329
    .line 330
    .line 331
    move-result-object v20

    .line 332
    sget-object v6, Lc31;->y:Lnt1;

    .line 333
    .line 334
    invoke-virtual {v3, v1}, Lib2;->i(Ljava/lang/Object;)Z

    .line 335
    .line 336
    .line 337
    move-result v9

    .line 338
    invoke-virtual {v3}, Lib2;->S()Ljava/lang/Object;

    .line 339
    .line 340
    .line 341
    move-result-object v10

    .line 342
    if-nez v9, :cond_12

    .line 343
    .line 344
    if-ne v10, v8, :cond_13

    .line 345
    .line 346
    :cond_12
    new-instance v10, Lba;

    .line 347
    .line 348
    const/4 v8, 0x4

    .line 349
    invoke-direct {v10, v1, v8}, Lba;-><init>(Lsa;B)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {v3, v10}, Lib2;->p0(Ljava/lang/Object;)V

    .line 353
    .line 354
    .line 355
    :cond_13
    check-cast v10, Lfa2;

    .line 356
    .line 357
    invoke-virtual {v6, v10}, Lh65;->c(Lfa2;)Ll65;

    .line 358
    .line 359
    .line 360
    move-result-object v21

    .line 361
    sget-object v6, Lc31;->u:Lnt1;

    .line 362
    .line 363
    invoke-virtual {v1}, Lsa;->getViewConfiguration()Ljg7;

    .line 364
    .line 365
    .line 366
    move-result-object v8

    .line 367
    invoke-virtual {v6, v8}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 368
    .line 369
    .line 370
    move-result-object v22

    .line 371
    sget-object v6, Lvs2;->a:Lnt1;

    .line 372
    .line 373
    invoke-virtual {v6, v7}, Lnt1;->a(Ljava/lang/Object;)Ll65;

    .line 374
    .line 375
    .line 376
    move-result-object v23

    .line 377
    move-object/from16 v16, v5

    .line 378
    .line 379
    filled-new-array/range {v11 .. v23}, [Ll65;

    .line 380
    .line 381
    .line 382
    move-result-object v5

    .line 383
    new-instance v6, Lz11;

    .line 384
    .line 385
    invoke-direct {v6, v1, v0, v2}, Lz11;-><init>(Lsa;Lb21;Lyz0;)V

    .line 386
    .line 387
    .line 388
    const v7, 0x4e86c15f

    .line 389
    .line 390
    .line 391
    invoke-static {v7, v6, v3}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 392
    .line 393
    .line 394
    move-result-object v6

    .line 395
    const/16 v7, 0x38

    .line 396
    .line 397
    invoke-static {v5, v6, v3, v7}, Lrq;->g([Ll65;Lja2;Lib2;I)V

    .line 398
    .line 399
    .line 400
    goto :goto_8

    .line 401
    :cond_14
    invoke-virtual {v3}, Lib2;->a0()V

    .line 402
    .line 403
    .line 404
    :goto_8
    invoke-virtual {v3}, Lib2;->w()Ldj5;

    .line 405
    .line 406
    .line 407
    move-result-object v3

    .line 408
    if-eqz v3, :cond_15

    .line 409
    .line 410
    new-instance v5, Lz11;

    .line 411
    .line 412
    invoke-direct {v5, v0, v1, v2, v4}, Lz11;-><init>(Lb21;Lsa;Lyz0;I)V

    .line 413
    .line 414
    .line 415
    iput-object v5, v3, Ldj5;->d:Lja2;

    .line 416
    .line 417
    :cond_15
    return-void
.end method

.method public final b()V
    .locals 3

    .line 1
    iget v0, p0, Lb21;->v:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, -0x1

    .line 4
    .line 5
    iput v0, p0, Lb21;->v:I

    .line 6
    .line 7
    if-gez v0, :cond_0

    .line 8
    .line 9
    const-string v0, "ComposeViewContext"

    .line 10
    .line 11
    const-string v1, "View count has dropped below 0"

    .line 12
    .line 13
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput v0, p0, Lb21;->v:I

    .line 18
    .line 19
    :cond_0
    if-nez v0, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, Lb21;->a:Landroid/view/View;

    .line 22
    .line 23
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    iget-object v2, p0, Lb21;->y:La21;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Landroid/content/Context;->unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    .line 30
    .line 31
    .line 32
    iget-object p0, p0, Lb21;->t:Lge3;

    .line 33
    .line 34
    iget-object v1, p0, Lge3;->b:Lgx4;

    .line 35
    .line 36
    if-nez v1, :cond_1

    .line 37
    .line 38
    const/4 v1, 0x0

    .line 39
    iput-object v1, p0, Lge3;->a:Lid;

    .line 40
    .line 41
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-virtual {p0, v2}, Landroid/view/ViewTreeObserver;->removeOnWindowFocusChangeListener(Landroid/view/ViewTreeObserver$OnWindowFocusChangeListener;)V

    .line 46
    .line 47
    .line 48
    :cond_2
    return-void
.end method

.method public final c()Lq21;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lb21;->g()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb21;->c:Lq21;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public final d()Lhf3;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lb21;->g()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lb21;->d:Lhf3;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    return-object p0
.end method

.method public final e()V
    .locals 5

    .line 1
    iget v0, p0, Lb21;->v:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    add-int/2addr v0, v1

    .line 5
    iput v0, p0, Lb21;->v:I

    .line 6
    .line 7
    if-ne v0, v1, :cond_2

    .line 8
    .line 9
    iget-object v0, p0, Lb21;->a:Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    iget-object v2, p0, Lb21;->y:La21;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {p0, v1}, Lb21;->f(Landroid/content/res/Configuration;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/View;->hasWindowFocus()Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    iget-object v3, p0, Lb21;->t:Lge3;

    .line 36
    .line 37
    iget-object v4, v3, Lge3;->c:Lgx4;

    .line 38
    .line 39
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    invoke-virtual {v4, v1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iget-object v1, v3, Lge3;->b:Lgx4;

    .line 47
    .line 48
    iget-object p0, p0, Lb21;->w:Lid;

    .line 49
    .line 50
    if-nez v1, :cond_0

    .line 51
    .line 52
    iput-object p0, v3, Lge3;->a:Lid;

    .line 53
    .line 54
    :cond_0
    if-eqz v1, :cond_1

    .line 55
    .line 56
    invoke-virtual {p0}, Lid;->invoke()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    invoke-virtual {v1, p0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    invoke-virtual {p0, v2}, Landroid/view/ViewTreeObserver;->addOnWindowFocusChangeListener(Landroid/view/ViewTreeObserver$OnWindowFocusChangeListener;)V

    .line 68
    .line 69
    .line 70
    :cond_2
    return-void
.end method

.method public final f(Landroid/content/res/Configuration;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lb21;->i:Landroid/content/res/Configuration;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/content/res/Configuration;->updateFrom(Landroid/content/res/Configuration;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_4

    .line 8
    .line 9
    iget-object v1, p0, Lb21;->g:Llw2;

    .line 10
    .line 11
    iget-object v1, v1, Llw2;->a:Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_2

    .line 26
    .line 27
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Ljava/util/Map$Entry;

    .line 32
    .line 33
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    check-cast v2, Ljava/lang/ref/WeakReference;

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    check-cast v2, Ljw2;

    .line 44
    .line 45
    if-eqz v2, :cond_1

    .line 46
    .line 47
    iget v2, v2, Ljw2;->b:I

    .line 48
    .line 49
    invoke-static {v0, v2}, Landroid/content/res/Configuration;->needNewResources(II)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_0

    .line 54
    .line 55
    :cond_1
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    .line 56
    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_2
    iget-object v1, p0, Lb21;->j:Lgx4;

    .line 60
    .line 61
    new-instance v2, Landroid/content/res/Configuration;

    .line 62
    .line 63
    invoke-direct {v2, p1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v2}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    iget-object p1, p0, Lb21;->h:Lem5;

    .line 70
    .line 71
    monitor-enter p1

    .line 72
    :try_start_0
    iget-object v1, p1, Lem5;->a:Lh34;

    .line 73
    .line 74
    invoke-virtual {v1}, Lh34;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 75
    .line 76
    .line 77
    monitor-exit p1

    .line 78
    const/high16 p1, 0x10000000

    .line 79
    .line 80
    and-int/2addr p1, v0

    .line 81
    if-eqz p1, :cond_3

    .line 82
    .line 83
    iget-object p1, p0, Lb21;->p:Lgx4;

    .line 84
    .line 85
    iget-object v1, p0, Lb21;->a:Landroid/view/View;

    .line 86
    .line 87
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-static {v1}, Lhs;->D(Landroid/content/Context;)Lu72;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-virtual {p1, v1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    :cond_3
    const p1, 0x2fff1d80

    .line 99
    .line 100
    .line 101
    and-int/2addr v0, p1

    .line 102
    if-eqz v0, :cond_4

    .line 103
    .line 104
    iget-object p1, p0, Lb21;->t:Lge3;

    .line 105
    .line 106
    iget-object p0, p0, Lb21;->w:Lid;

    .line 107
    .line 108
    iget-object p1, p1, Lge3;->b:Lgx4;

    .line 109
    .line 110
    if-eqz p1, :cond_4

    .line 111
    .line 112
    invoke-virtual {p0}, Lid;->invoke()Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    invoke-virtual {p1, p0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    return-void

    .line 120
    :catchall_0
    move-exception p0

    .line 121
    monitor-exit p1

    .line 122
    throw p0

    .line 123
    :cond_4
    return-void
.end method

.method public final g()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lb21;->b:Z

    .line 2
    .line 3
    if-nez v0, :cond_7

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lb21;->b:Z

    .line 7
    .line 8
    iget-object v0, p0, Lb21;->c:Lq21;

    .line 9
    .line 10
    iget-object v1, p0, Lb21;->a:Landroid/view/View;

    .line 11
    .line 12
    if-nez v0, :cond_2

    .line 13
    .line 14
    invoke-static {v1}, Lqm7;->a(Landroid/view/View;)Lq21;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    :goto_0
    if-nez v0, :cond_0

    .line 25
    .line 26
    instance-of v3, v2, Landroid/view/View;

    .line 27
    .line 28
    if-eqz v3, :cond_0

    .line 29
    .line 30
    check-cast v2, Landroid/view/View;

    .line 31
    .line 32
    invoke-static {v2}, Lqm7;->a(Landroid/view/View;)Lq21;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-static {v2}, Liu6;->l(Landroid/view/View;)Landroid/view/ViewParent;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    goto :goto_0

    .line 41
    :cond_0
    if-nez v0, :cond_1

    .line 42
    .line 43
    invoke-static {v1}, Lqm7;->b(Landroid/view/View;)Lkj5;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    :cond_1
    iput-object v0, p0, Lb21;->c:Lq21;

    .line 48
    .line 49
    :cond_2
    iget-object v0, p0, Lb21;->d:Lhf3;

    .line 50
    .line 51
    if-nez v0, :cond_4

    .line 52
    .line 53
    invoke-static {v1}, Lwp6;->j(Landroid/view/View;)Lhf3;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    if-eqz v0, :cond_3

    .line 58
    .line 59
    iput-object v0, p0, Lb21;->d:Lhf3;

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_3
    const-string p0, "Composed into a View which doesn\'t propagate ViewTreeLifecycleOwner!"

    .line 63
    .line 64
    invoke-static {p0}, La02;->d(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_4
    :goto_1
    iget-object v0, p0, Lb21;->e:Lq06;

    .line 69
    .line 70
    if-nez v0, :cond_6

    .line 71
    .line 72
    invoke-static {v1}, Lcq6;->e(Landroid/view/View;)Lq06;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    if-eqz v0, :cond_5

    .line 77
    .line 78
    iput-object v0, p0, Lb21;->e:Lq06;

    .line 79
    .line 80
    goto :goto_2

    .line 81
    :cond_5
    const-string p0, "Composed into a View which doesn\'t propagate ViewTreeSavedStateRegistryOwner!"

    .line 82
    .line 83
    invoke-static {p0}, La02;->d(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_6
    :goto_2
    iget-object v0, p0, Lb21;->f:Lyg7;

    .line 88
    .line 89
    if-nez v0, :cond_7

    .line 90
    .line 91
    invoke-static {v1}, Lyq6;->r(Landroid/view/View;)Lyg7;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    iput-object v0, p0, Lb21;->f:Lyg7;

    .line 96
    .line 97
    :cond_7
    return-void
.end method
