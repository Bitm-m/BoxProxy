.class public final Lak1;
.super Law4;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# static fields
.field public static final H:Lv06;


# instance fields
.field public final G:Lgx4;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lc11;

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lc11;-><init>(B)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lef1;

    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    invoke-direct {v1, v2}, Lef1;-><init>(B)V

    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Lcc3;->M(Lja2;Lfa2;)Lv06;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    sput-object v0, Lak1;->H:Lv06;

    .line 19
    .line 20
    return-void
.end method

.method public constructor <init>(IFLu92;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Law4;-><init>(IF)V

    .line 2
    .line 3
    .line 4
    invoke-static {p3}, Lsa3;->Q(Ljava/lang/Object;)Lgx4;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lak1;->G:Lgx4;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final l()I
    .locals 0

    .line 1
    iget-object p0, p0, Lak1;->G:Lgx4;

    .line 2
    .line 3
    invoke-virtual {p0}, Lgx4;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lu92;

    .line 8
    .line 9
    invoke-interface {p0}, Lu92;->invoke()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Ljava/lang/Number;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method
