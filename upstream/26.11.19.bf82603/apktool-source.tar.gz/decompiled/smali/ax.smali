.class public final synthetic Lax;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lja2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:I

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lg67;Lyz0;Li67;Lw04;Lyz0;I)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lax;->i:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lax;->l:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lax;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lax;->n:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lax;->j:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lax;->o:Ljava/lang/Object;

    .line 16
    .line 17
    iput p6, p0, Lax;->k:I

    .line 18
    .line 19
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IB)V
    .locals 0

    .line 20
    iput-byte p7, p0, Lax;->i:B

    iput-object p1, p0, Lax;->l:Ljava/lang/Object;

    iput-object p2, p0, Lax;->m:Ljava/lang/Object;

    iput-object p3, p0, Lax;->j:Ljava/lang/Object;

    iput-object p4, p0, Lax;->n:Ljava/lang/Object;

    iput-object p5, p0, Lax;->o:Ljava/lang/Object;

    iput p6, p0, Lax;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lax;->i:B

    .line 4
    .line 5
    iget-object v2, v0, Lax;->o:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, v0, Lax;->n:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, v0, Lax;->j:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v5, v0, Lax;->m:Ljava/lang/Object;

    .line 12
    .line 13
    sget-object v6, Lxc7;->a:Lxc7;

    .line 14
    .line 15
    iget v7, v0, Lax;->k:I

    .line 16
    .line 17
    iget-object v8, v0, Lax;->l:Ljava/lang/Object;

    .line 18
    .line 19
    packed-switch v1, :pswitch_data_0

    .line 20
    .line 21
    .line 22
    move-object v9, v8

    .line 23
    check-cast v9, Lur4;

    .line 24
    .line 25
    move-object v10, v5

    .line 26
    check-cast v10, Ljava/lang/String;

    .line 27
    .line 28
    move-object v11, v4

    .line 29
    check-cast v11, Lyd3;

    .line 30
    .line 31
    move-object v12, v3

    .line 32
    check-cast v12, Lxt4;

    .line 33
    .line 34
    move-object v13, v2

    .line 35
    check-cast v13, Lu92;

    .line 36
    .line 37
    move-object/from16 v14, p1

    .line 38
    .line 39
    check-cast v14, Lib2;

    .line 40
    .line 41
    move-object/from16 v0, p2

    .line 42
    .line 43
    check-cast v0, Ljava/lang/Integer;

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    or-int/lit8 v7, v7, 0x1

    .line 49
    .line 50
    invoke-static {v7}, Lcc3;->X(I)I

    .line 51
    .line 52
    .line 53
    move-result v15

    .line 54
    invoke-static/range {v9 .. v15}, Ld70;->E(Lur4;Ljava/lang/String;Lyd3;Lxt4;Lu92;Lib2;I)V

    .line 55
    .line 56
    .line 57
    return-object v6

    .line 58
    :pswitch_0
    move-object/from16 v16, v8

    .line 59
    .line 60
    check-cast v16, Luv0;

    .line 61
    .line 62
    move-object/from16 v17, v5

    .line 63
    .line 64
    check-cast v17, Lr14;

    .line 65
    .line 66
    move-object/from16 v18, v4

    .line 67
    .line 68
    check-cast v18, Lsa6;

    .line 69
    .line 70
    move-object/from16 v19, v3

    .line 71
    .line 72
    check-cast v19, Lta7;

    .line 73
    .line 74
    move-object/from16 v20, v2

    .line 75
    .line 76
    check-cast v20, Lyz0;

    .line 77
    .line 78
    move-object/from16 v21, p1

    .line 79
    .line 80
    check-cast v21, Lib2;

    .line 81
    .line 82
    move-object/from16 v0, p2

    .line 83
    .line 84
    check-cast v0, Ljava/lang/Integer;

    .line 85
    .line 86
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    .line 88
    .line 89
    or-int/lit8 v7, v7, 0x1

    .line 90
    .line 91
    invoke-static {v7}, Lcc3;->X(I)I

    .line 92
    .line 93
    .line 94
    move-result v22

    .line 95
    invoke-static/range {v16 .. v22}, Lbr3;->b(Luv0;Lr14;Lsa6;Lta7;Lyz0;Lib2;I)V

    .line 96
    .line 97
    .line 98
    return-object v6

    .line 99
    :pswitch_1
    check-cast v8, Lyb7;

    .line 100
    .line 101
    check-cast v5, Lle1;

    .line 102
    .line 103
    move-object v9, v4

    .line 104
    check-cast v9, Lu92;

    .line 105
    .line 106
    move-object v10, v3

    .line 107
    check-cast v10, Lfa2;

    .line 108
    .line 109
    move-object v11, v2

    .line 110
    check-cast v11, Lfa2;

    .line 111
    .line 112
    move-object/from16 v12, p1

    .line 113
    .line 114
    check-cast v12, Lib2;

    .line 115
    .line 116
    move-object/from16 v0, p2

    .line 117
    .line 118
    check-cast v0, Ljava/lang/Integer;

    .line 119
    .line 120
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 121
    .line 122
    .line 123
    or-int/lit8 v7, v7, 0x1

    .line 124
    .line 125
    invoke-static {v7}, Lcc3;->X(I)I

    .line 126
    .line 127
    .line 128
    move-result v13

    .line 129
    move-object v7, v8

    .line 130
    move-object v8, v5

    .line 131
    invoke-static/range {v7 .. v13}, Lmm;->j(Lyb7;Lle1;Lu92;Lfa2;Lfa2;Lib2;I)V

    .line 132
    .line 133
    .line 134
    return-object v6

    .line 135
    :pswitch_2
    move-object v14, v8

    .line 136
    check-cast v14, Lyz0;

    .line 137
    .line 138
    move-object/from16 v19, p1

    .line 139
    .line 140
    check-cast v19, Lib2;

    .line 141
    .line 142
    move-object/from16 v1, p2

    .line 143
    .line 144
    check-cast v1, Ljava/lang/Integer;

    .line 145
    .line 146
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    invoke-static {v7}, Lcc3;->X(I)I

    .line 150
    .line 151
    .line 152
    move-result v1

    .line 153
    or-int/lit8 v20, v1, 0x1

    .line 154
    .line 155
    iget-object v15, v0, Lax;->m:Ljava/lang/Object;

    .line 156
    .line 157
    iget-object v1, v0, Lax;->j:Ljava/lang/Object;

    .line 158
    .line 159
    iget-object v2, v0, Lax;->n:Ljava/lang/Object;

    .line 160
    .line 161
    iget-object v0, v0, Lax;->o:Ljava/lang/Object;

    .line 162
    .line 163
    move-object/from16 v18, v0

    .line 164
    .line 165
    move-object/from16 v16, v1

    .line 166
    .line 167
    move-object/from16 v17, v2

    .line 168
    .line 169
    invoke-virtual/range {v14 .. v20}, Lyz0;->l(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lib2;I)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    return-object v6

    .line 173
    :pswitch_3
    check-cast v8, Lg67;

    .line 174
    .line 175
    check-cast v5, Lyz0;

    .line 176
    .line 177
    move-object v9, v3

    .line 178
    check-cast v9, Li67;

    .line 179
    .line 180
    move-object v10, v4

    .line 181
    check-cast v10, Lw04;

    .line 182
    .line 183
    move-object v11, v2

    .line 184
    check-cast v11, Lyz0;

    .line 185
    .line 186
    move-object/from16 v12, p1

    .line 187
    .line 188
    check-cast v12, Lib2;

    .line 189
    .line 190
    move-object/from16 v0, p2

    .line 191
    .line 192
    check-cast v0, Ljava/lang/Integer;

    .line 193
    .line 194
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    .line 196
    .line 197
    or-int/lit8 v7, v7, 0x1

    .line 198
    .line 199
    invoke-static {v7}, Lcc3;->X(I)I

    .line 200
    .line 201
    .line 202
    move-result v13

    .line 203
    move-object v7, v8

    .line 204
    move-object v8, v5

    .line 205
    invoke-static/range {v7 .. v13}, Lmm;->a(Lg67;Lyz0;Li67;Lw04;Lyz0;Lib2;I)V

    .line 206
    .line 207
    .line 208
    return-object v6

    .line 209
    :pswitch_4
    move-object v14, v8

    .line 210
    check-cast v14, Llx;

    .line 211
    .line 212
    move-object v15, v5

    .line 213
    check-cast v15, Ljava/lang/String;

    .line 214
    .line 215
    move-object/from16 v16, v4

    .line 216
    .line 217
    check-cast v16, Lw04;

    .line 218
    .line 219
    move-object/from16 v17, v3

    .line 220
    .line 221
    check-cast v17, Lr91;

    .line 222
    .line 223
    move-object/from16 v18, v2

    .line 224
    .line 225
    check-cast v18, Lpv0;

    .line 226
    .line 227
    move-object/from16 v19, p1

    .line 228
    .line 229
    check-cast v19, Lib2;

    .line 230
    .line 231
    move-object/from16 v0, p2

    .line 232
    .line 233
    check-cast v0, Ljava/lang/Integer;

    .line 234
    .line 235
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 236
    .line 237
    .line 238
    or-int/lit8 v7, v7, 0x1

    .line 239
    .line 240
    invoke-static {v7}, Lcc3;->X(I)I

    .line 241
    .line 242
    .line 243
    move-result v20

    .line 244
    invoke-static/range {v14 .. v20}, Llm;->b(Llx;Ljava/lang/String;Lw04;Lr91;Lpv0;Lib2;I)V

    .line 245
    .line 246
    .line 247
    return-object v6

    .line 248
    nop

    .line 249
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
