.class public final Lao;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public i:Ljava/io/InputStream;

.field public j:Ljava/util/Set;

.field public k:Landroid/content/Context;

.field public l:Ljava/io/File;

.field public m:Ljava/lang/Object;

.field public synthetic n:Ljava/lang/Object;

.field public final synthetic o:Llo;

.field public p:I


# direct methods
.method public constructor <init>(Llo;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lao;->o:Llo;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lao;->n:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lao;->p:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lao;->p:I

    .line 9
    .line 10
    iget-object p1, p0, Lao;->o:Llo;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, v0, v0, p0}, Llo;->i(Landroid/content/Context;Ljava/io/InputStream;Ljava/util/Set;Lfa1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    sget-object p1, Lof1;->i:Lof1;

    .line 18
    .line 19
    if-ne p0, p1, :cond_0

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    new-instance p1, Lsm5;

    .line 23
    .line 24
    invoke-direct {p1, p0}, Lsm5;-><init>(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-object p1
.end method
