.class public final Lba5;
.super Lfa1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public i:Ljava/lang/String;

.field public j:Ljava/util/Map;

.field public k:Ljava/lang/String;

.field public l:S

.field public synthetic m:Ljava/lang/Object;

.field public final synthetic n:Lw27;

.field public o:I


# direct methods
.method public constructor <init>(Lw27;Lfa1;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lba5;->n:Lw27;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lfa1;-><init>(Lea1;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iput-object p1, p0, Lba5;->m:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lba5;->o:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lba5;->o:I

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    iget-object v0, p0, Lba5;->n:Lw27;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x0

    .line 16
    move-object v5, p0

    .line 17
    invoke-virtual/range {v0 .. v5}, Lw27;->Y(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;ILfa1;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method
