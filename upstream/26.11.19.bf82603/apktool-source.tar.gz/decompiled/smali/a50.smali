.class public final synthetic La50;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Lnf1;

.field public final synthetic k:Lfa2;


# direct methods
.method public synthetic constructor <init>(Lnf1;Lfa2;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, La50;->i:B

    .line 2
    .line 3
    iput-object p1, p0, La50;->j:Lnf1;

    .line 4
    .line 5
    iput-object p2, p0, La50;->k:Lfa2;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 6

    .line 1
    iget-byte v0, p0, La50;->i:B

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    sget-object v2, Lxc7;->a:Lxc7;

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    iget-object v4, p0, La50;->k:Lfa2;

    .line 8
    .line 9
    iget-object p0, p0, La50;->j:Lnf1;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    new-instance v0, Lr50;

    .line 15
    .line 16
    const/4 v1, 0x7

    .line 17
    invoke-direct {v0, v4, v3, v1}, Lr50;-><init>(Lfa2;Lea1;B)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    sget-object v4, Lqf1;->l:Lqf1;

    .line 22
    .line 23
    invoke-static {p0, v3, v4, v0, v1}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 24
    .line 25
    .line 26
    return-object v2

    .line 27
    :pswitch_0
    new-instance v0, Lr50;

    .line 28
    .line 29
    const/4 v5, 0x2

    .line 30
    invoke-direct {v0, v4, v3, v5}, Lr50;-><init>(Lfa2;Lea1;B)V

    .line 31
    .line 32
    .line 33
    invoke-static {p0, v3, v3, v0, v1}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 34
    .line 35
    .line 36
    return-object v2

    .line 37
    :pswitch_1
    new-instance v0, Lr50;

    .line 38
    .line 39
    const/4 v5, 0x0

    .line 40
    invoke-direct {v0, v4, v3, v5}, Lr50;-><init>(Lfa2;Lea1;B)V

    .line 41
    .line 42
    .line 43
    invoke-static {p0, v3, v3, v0, v1}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 44
    .line 45
    .line 46
    return-object v2

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
