.class public final Lb72;
.super Lv04;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements La72;


# instance fields
.field public w:Lz62;


# virtual methods
.method public final w0(Lw62;)V
    .locals 0

    .line 1
    iget-object p0, p0, Lb72;->w:Lz62;

    .line 2
    .line 3
    iget-object p0, p0, Lz62;->a:Lfa2;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method
