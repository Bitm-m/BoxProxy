.class public final Lad1;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:Lle1;

.field public final synthetic j:Ljava/lang/String;

.field public final synthetic k:Lj44;

.field public final synthetic l:Z

.field public final synthetic m:Ljava/util/List;

.field public final synthetic n:Ljava/util/Map;

.field public final synthetic o:Lme1;

.field public final synthetic p:Ljava/lang/String;

.field public final synthetic q:Lu92;

.field public final synthetic r:Z

.field public final synthetic s:Lj44;

.field public final synthetic t:Lj44;

.field public final synthetic u:Lj44;

.field public final synthetic v:Lj44;


# direct methods
.method public constructor <init>(Lle1;Ljava/lang/String;Lj44;ZLjava/util/List;Ljava/util/Map;Lme1;Ljava/lang/String;Lu92;ZLj44;Lj44;Lj44;Lj44;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lad1;->i:Lle1;

    .line 5
    .line 6
    iput-object p2, p0, Lad1;->j:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lad1;->k:Lj44;

    .line 9
    .line 10
    iput-boolean p4, p0, Lad1;->l:Z

    .line 11
    .line 12
    iput-object p5, p0, Lad1;->m:Ljava/util/List;

    .line 13
    .line 14
    iput-object p6, p0, Lad1;->n:Ljava/util/Map;

    .line 15
    .line 16
    iput-object p7, p0, Lad1;->o:Lme1;

    .line 17
    .line 18
    iput-object p8, p0, Lad1;->p:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p9, p0, Lad1;->q:Lu92;

    .line 21
    .line 22
    iput-boolean p10, p0, Lad1;->r:Z

    .line 23
    .line 24
    iput-object p11, p0, Lad1;->s:Lj44;

    .line 25
    .line 26
    iput-object p12, p0, Lad1;->t:Lj44;

    .line 27
    .line 28
    iput-object p13, p0, Lad1;->u:Lj44;

    .line 29
    .line 30
    iput-object p14, p0, Lad1;->v:Lj44;

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lvx0;

    .line 6
    .line 7
    move-object/from16 v12, p2

    .line 8
    .line 9
    check-cast v12, Lib2;

    .line 10
    .line 11
    move-object/from16 v2, p3

    .line 12
    .line 13
    check-cast v2, Ljava/lang/Number;

    .line 14
    .line 15
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    and-int/lit8 v1, v2, 0x11

    .line 23
    .line 24
    const/16 v3, 0x10

    .line 25
    .line 26
    const/4 v15, 0x0

    .line 27
    const/4 v11, 0x1

    .line 28
    if-eq v1, v3, :cond_0

    .line 29
    .line 30
    move v1, v11

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    move v1, v15

    .line 33
    :goto_0
    and-int/2addr v2, v11

    .line 34
    invoke-virtual {v12, v2, v1}, Lib2;->X(IZ)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_8

    .line 39
    .line 40
    iget-object v1, v0, Lad1;->i:Lle1;

    .line 41
    .line 42
    iget-object v2, v1, Lle1;->b:Ljava/lang/String;

    .line 43
    .line 44
    invoke-virtual {v12, v1}, Lib2;->i(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    invoke-virtual {v12}, Lib2;->S()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    sget-object v13, Lg21;->a:Ley0;

    .line 53
    .line 54
    if-nez v3, :cond_1

    .line 55
    .line 56
    if-ne v4, v13, :cond_2

    .line 57
    .line 58
    :cond_1
    new-instance v4, Lyc1;

    .line 59
    .line 60
    iget-object v3, v0, Lad1;->k:Lj44;

    .line 61
    .line 62
    invoke-direct {v4, v1, v3, v15}, Lyc1;-><init>(Lle1;Lj44;B)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v12, v4}, Lib2;->p0(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    :cond_2
    move-object v6, v4

    .line 69
    check-cast v6, Lu92;

    .line 70
    .line 71
    const/4 v9, 0x0

    .line 72
    const/16 v10, 0xdf6

    .line 73
    .line 74
    iget-object v3, v0, Lad1;->j:Ljava/lang/String;

    .line 75
    .line 76
    const/4 v4, 0x0

    .line 77
    const/4 v5, 0x0

    .line 78
    const/4 v7, 0x0

    .line 79
    move-object v8, v12

    .line 80
    invoke-static/range {v2 .. v10}, Lfj;->f(Ljava/lang/String;Ljava/lang/String;Lja2;Lka2;Lu92;ZLib2;II)V

    .line 81
    .line 82
    .line 83
    sget-object v1, Lt04;->i:Lt04;

    .line 84
    .line 85
    const/high16 v2, 0x3f800000    # 1.0f

    .line 86
    .line 87
    invoke-static {v1, v2}, Lag6;->e(Lw04;F)Lw04;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    const/4 v8, 0x2

    .line 92
    const/high16 v4, 0x41800000    # 16.0f

    .line 93
    .line 94
    const/4 v5, 0x0

    .line 95
    const/high16 v7, 0x41400000    # 12.0f

    .line 96
    .line 97
    move v6, v4

    .line 98
    invoke-static/range {v3 .. v8}, Lm71;->E(Lw04;FFFFI)Lw04;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    new-instance v3, Lvv;

    .line 103
    .line 104
    new-instance v4, La02;

    .line 105
    .line 106
    const/4 v5, 0x3

    .line 107
    invoke-direct {v4, v5}, La02;-><init>(B)V

    .line 108
    .line 109
    .line 110
    invoke-direct {v3, v7, v11, v4}, Lvv;-><init>(FZLa02;)V

    .line 111
    .line 112
    .line 113
    sget-object v4, Lu6;->t:Ls20;

    .line 114
    .line 115
    const/4 v5, 0x6

    .line 116
    invoke-static {v3, v4, v12, v5}, Llp5;->a(Luv;Ls20;Lib2;I)Lmp5;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    iget-wide v4, v12, Lib2;->T:J

    .line 121
    .line 122
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 123
    .line 124
    .line 125
    move-result v4

    .line 126
    invoke-virtual {v12}, Lib2;->m()Liz4;

    .line 127
    .line 128
    .line 129
    move-result-object v5

    .line 130
    invoke-static {v12, v1}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    sget-object v6, Lx11;->d:Lu6;

    .line 135
    .line 136
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v12}, Lib2;->j0()V

    .line 140
    .line 141
    .line 142
    iget-boolean v6, v12, Lib2;->S:Z

    .line 143
    .line 144
    if-eqz v6, :cond_3

    .line 145
    .line 146
    sget-object v6, Laa3;->a0:Lg53;

    .line 147
    .line 148
    invoke-virtual {v12, v6}, Lib2;->l(Lu92;)V

    .line 149
    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_3
    invoke-virtual {v12}, Lib2;->s0()V

    .line 153
    .line 154
    .line 155
    :goto_1
    sget-object v6, Lu6;->S:Lc11;

    .line 156
    .line 157
    invoke-static {v6, v12, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    sget-object v3, Lu6;->R:Lc11;

    .line 161
    .line 162
    invoke-static {v3, v12, v5}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    sget-object v4, Lu6;->T:Lc11;

    .line 170
    .line 171
    invoke-static {v4, v12, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    invoke-static {v12}, Lwt6;->m(Lib2;)V

    .line 175
    .line 176
    .line 177
    sget-object v3, Lu6;->Q:Lc11;

    .line 178
    .line 179
    invoke-static {v3, v12, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    iget-boolean v1, v0, Lad1;->l:Z

    .line 183
    .line 184
    iget-object v3, v0, Lad1;->s:Lj44;

    .line 185
    .line 186
    if-eqz v1, :cond_5

    .line 187
    .line 188
    const v1, -0x1d374a03

    .line 189
    .line 190
    .line 191
    invoke-virtual {v12, v1}, Lib2;->g0(I)V

    .line 192
    .line 193
    .line 194
    const v1, 0x7f0f0192

    .line 195
    .line 196
    .line 197
    invoke-static {v1, v12}, Lya3;->c0(ILib2;)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    iget-object v4, v0, Lad1;->m:Ljava/util/List;

    .line 202
    .line 203
    invoke-virtual {v12, v4}, Lib2;->i(Ljava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    move-result v5

    .line 207
    iget-object v6, v0, Lad1;->n:Ljava/util/Map;

    .line 208
    .line 209
    invoke-virtual {v12, v6}, Lib2;->i(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    move-result v7

    .line 213
    or-int/2addr v5, v7

    .line 214
    iget-object v7, v0, Lad1;->o:Lme1;

    .line 215
    .line 216
    invoke-virtual {v12, v7}, Lib2;->i(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v8

    .line 220
    or-int/2addr v5, v8

    .line 221
    invoke-virtual {v12}, Lib2;->S()Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v8

    .line 225
    if-nez v5, :cond_4

    .line 226
    .line 227
    if-eq v8, v13, :cond_4

    .line 228
    .line 229
    move-object/from16 v20, v3

    .line 230
    .line 231
    goto :goto_2

    .line 232
    :cond_4
    new-instance v16, Lzc1;

    .line 233
    .line 234
    const/16 v25, 0x0

    .line 235
    .line 236
    iget-object v5, v0, Lad1;->t:Lj44;

    .line 237
    .line 238
    iget-object v8, v0, Lad1;->u:Lj44;

    .line 239
    .line 240
    iget-object v9, v0, Lad1;->v:Lj44;

    .line 241
    .line 242
    iget-object v10, v0, Lad1;->k:Lj44;

    .line 243
    .line 244
    move-object/from16 v20, v3

    .line 245
    .line 246
    move-object/from16 v18, v4

    .line 247
    .line 248
    move-object/from16 v21, v5

    .line 249
    .line 250
    move-object/from16 v19, v6

    .line 251
    .line 252
    move-object/from16 v17, v7

    .line 253
    .line 254
    move-object/from16 v22, v8

    .line 255
    .line 256
    move-object/from16 v23, v9

    .line 257
    .line 258
    move-object/from16 v24, v10

    .line 259
    .line 260
    invoke-direct/range {v16 .. v25}, Lzc1;-><init>(Lme1;Ljava/util/List;Ljava/util/Map;Lj44;Lj44;Lj44;Lj44;Lj44;B)V

    .line 261
    .line 262
    .line 263
    move-object/from16 v8, v16

    .line 264
    .line 265
    invoke-virtual {v12, v8}, Lib2;->p0(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    :goto_2
    move-object v3, v8

    .line 269
    check-cast v3, Lu92;

    .line 270
    .line 271
    new-instance v4, Lta3;

    .line 272
    .line 273
    invoke-direct {v4, v2, v11}, Lta3;-><init>(FZ)V

    .line 274
    .line 275
    .line 276
    invoke-static/range {v20 .. v20}, Lko3;->U(Lj44;)Z

    .line 277
    .line 278
    .line 279
    move-result v5

    .line 280
    xor-int/2addr v5, v11

    .line 281
    const/4 v13, 0x0

    .line 282
    const/16 v14, 0xff0

    .line 283
    .line 284
    const/4 v6, 0x0

    .line 285
    const/4 v7, 0x0

    .line 286
    const/4 v8, 0x0

    .line 287
    const/4 v9, 0x0

    .line 288
    const/4 v10, 0x0

    .line 289
    move/from16 v16, v11

    .line 290
    .line 291
    const/4 v11, 0x0

    .line 292
    move v0, v2

    .line 293
    move-object v2, v1

    .line 294
    move v1, v0

    .line 295
    move/from16 v0, v16

    .line 296
    .line 297
    invoke-static/range {v2 .. v14}, Lg93;->b(Ljava/lang/String;Lu92;Lw04;ZFFFLuw3;Lzt4;Lix2;Lib2;II)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v12, v15}, Lib2;->r(Z)V

    .line 301
    .line 302
    .line 303
    goto :goto_3

    .line 304
    :cond_5
    move v1, v2

    .line 305
    move-object/from16 v20, v3

    .line 306
    .line 307
    move v0, v11

    .line 308
    const v2, -0x1d3462bd

    .line 309
    .line 310
    .line 311
    invoke-virtual {v12, v2}, Lib2;->g0(I)V

    .line 312
    .line 313
    .line 314
    invoke-virtual {v12, v15}, Lib2;->r(Z)V

    .line 315
    .line 316
    .line 317
    :goto_3
    new-instance v4, Lta3;

    .line 318
    .line 319
    invoke-direct {v4, v1, v0}, Lta3;-><init>(FZ)V

    .line 320
    .line 321
    .line 322
    invoke-static/range {v20 .. v20}, Lko3;->U(Lj44;)Z

    .line 323
    .line 324
    .line 325
    move-result v1

    .line 326
    if-nez v1, :cond_6

    .line 327
    .line 328
    move-object/from16 v1, p0

    .line 329
    .line 330
    iget-boolean v2, v1, Lad1;->r:Z

    .line 331
    .line 332
    if-nez v2, :cond_7

    .line 333
    .line 334
    move v5, v0

    .line 335
    goto :goto_4

    .line 336
    :cond_6
    move-object/from16 v1, p0

    .line 337
    .line 338
    :cond_7
    move v5, v15

    .line 339
    :goto_4
    const/high16 v13, 0xc00000

    .line 340
    .line 341
    const/16 v14, 0xf70

    .line 342
    .line 343
    iget-object v2, v1, Lad1;->p:Ljava/lang/String;

    .line 344
    .line 345
    iget-object v3, v1, Lad1;->q:Lu92;

    .line 346
    .line 347
    const/4 v6, 0x0

    .line 348
    const/4 v7, 0x0

    .line 349
    const/4 v8, 0x0

    .line 350
    sget-object v9, Luw3;->j:Luw3;

    .line 351
    .line 352
    const/4 v10, 0x0

    .line 353
    const/4 v11, 0x0

    .line 354
    invoke-static/range {v2 .. v14}, Lg93;->b(Ljava/lang/String;Lu92;Lw04;ZFFFLuw3;Lzt4;Lix2;Lib2;II)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {v12, v0}, Lib2;->r(Z)V

    .line 358
    .line 359
    .line 360
    goto :goto_5

    .line 361
    :cond_8
    invoke-virtual {v12}, Lib2;->a0()V

    .line 362
    .line 363
    .line 364
    :goto_5
    sget-object v0, Lxc7;->a:Lxc7;

    .line 365
    .line 366
    return-object v0
.end method
