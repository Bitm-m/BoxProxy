.class public final La92;
.super Li84;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"


# instance fields
.field public final h:Lhn1;


# direct methods
.method public constructor <init>(Lhn1;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget-object v0, Lm84;->a:Lm84;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-direct {p0, v0, v1}, Li84;-><init>(Ln84;Z)V

    .line 8
    .line 9
    .line 10
    iput-object p1, p0, La92;->h:Lhn1;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final d()V
    .locals 0

    .line 1
    iget-object p0, p0, La92;->h:Lhn1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lo84;->a()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e()V
    .locals 0

    .line 1
    iget-object p0, p0, La92;->h:Lhn1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lo84;->b()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final f(Ld84;)V
    .locals 0

    .line 1
    iget-object p0, p0, La92;->h:Lhn1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lo84;->c(Ld84;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final g(Ld84;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, La92;->h:Lhn1;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lo84;->a:Le84;

    .line 10
    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-boolean v1, p0, Lo84;->b:Z

    .line 14
    .line 15
    if-nez v1, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0, p0, p1}, Le84;->e(Lo84;Ld84;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x1

    .line 21
    iput-boolean p1, p0, Lo84;->b:Z

    .line 22
    .line 23
    :cond_0
    return-void
.end method
