.class public final synthetic Lb2;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfa2;


# instance fields
.field public final synthetic i:B

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 17
    iput-byte p5, p0, Lb2;->i:B

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lur4;Ljava/lang/String;Lu92;)V
    .locals 1

    .line 1
    const/16 v0, 0xb

    .line 2
    .line 3
    iput-byte v0, p0, Lb2;->i:B

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lb2;->k:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p2, p0, Lb2;->j:Ljava/lang/Object;

    .line 11
    .line 12
    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    .line 13
    .line 14
    iput-object p4, p0, Lb2;->m:Ljava/lang/Object;

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/ArrayList;Lrj5;Ljava/util/List;ILnb3;)V
    .locals 0

    .line 18
    const/4 p4, 0x6

    iput-byte p4, p0, Lb2;->i:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p3, p0, Lb2;->l:Ljava/lang/Object;

    iput-object p5, p0, Lb2;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lb2;->i:B

    .line 4
    .line 5
    const/16 v6, 0x20

    .line 6
    .line 7
    const/4 v7, 0x0

    .line 8
    const/4 v8, 0x0

    .line 9
    const/4 v9, 0x0

    .line 10
    const/4 v10, 0x1

    .line 11
    sget-object v11, Lxc7;->a:Lxc7;

    .line 12
    .line 13
    iget-object v12, v0, Lb2;->m:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v13, v0, Lb2;->l:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v14, v0, Lb2;->k:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v0, v0, Lb2;->j:Ljava/lang/Object;

    .line 20
    .line 21
    packed-switch v1, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    check-cast v0, Lu92;

    .line 25
    .line 26
    check-cast v14, La10;

    .line 27
    .line 28
    check-cast v13, Liz6;

    .line 29
    .line 30
    check-cast v12, Lc27;

    .line 31
    .line 32
    move-object/from16 v1, p1

    .line 33
    .line 34
    check-cast v1, Ljw6;

    .line 35
    .line 36
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    if-eqz v14, :cond_0

    .line 40
    .line 41
    invoke-virtual {v14}, La10;->invoke()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    check-cast v0, Ljava/lang/Boolean;

    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 48
    .line 49
    .line 50
    move-result v10

    .line 51
    :cond_0
    if-eqz v10, :cond_1

    .line 52
    .line 53
    invoke-interface {v1}, Ljw6;->close()V

    .line 54
    .line 55
    .line 56
    :cond_1
    invoke-virtual {v13, v12}, Liz6;->x(Lc27;)V

    .line 57
    .line 58
    .line 59
    return-object v11

    .line 60
    :pswitch_0
    check-cast v0, Lfa2;

    .line 61
    .line 62
    move-object v1, v14

    .line 63
    check-cast v1, Lwv3;

    .line 64
    .line 65
    move-object v14, v13

    .line 66
    check-cast v14, Lvq6;

    .line 67
    .line 68
    check-cast v12, Ljava/util/List;

    .line 69
    .line 70
    move-object/from16 v2, p1

    .line 71
    .line 72
    check-cast v2, Ljava/lang/Integer;

    .line 73
    .line 74
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    invoke-interface {v12, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    move-object/from16 v16, v2

    .line 83
    .line 84
    check-cast v16, Ljava/lang/String;

    .line 85
    .line 86
    const/16 v30, 0x0

    .line 87
    .line 88
    const v31, 0xffffd

    .line 89
    .line 90
    .line 91
    const/4 v15, 0x0

    .line 92
    const/16 v17, 0x0

    .line 93
    .line 94
    const/16 v18, 0x0

    .line 95
    .line 96
    const/16 v19, 0x0

    .line 97
    .line 98
    const/16 v20, 0x0

    .line 99
    .line 100
    const/16 v21, 0x0

    .line 101
    .line 102
    const/16 v22, 0x0

    .line 103
    .line 104
    const/16 v23, 0x0

    .line 105
    .line 106
    const/16 v24, 0x0

    .line 107
    .line 108
    const/16 v25, 0x0

    .line 109
    .line 110
    const/16 v26, 0x0

    .line 111
    .line 112
    const/16 v27, 0x0

    .line 113
    .line 114
    const/16 v28, 0x0

    .line 115
    .line 116
    const/16 v29, 0x0

    .line 117
    .line 118
    invoke-static/range {v14 .. v31}, Lvq6;->a(Lvq6;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lvq6;

    .line 119
    .line 120
    .line 121
    move-result-object v6

    .line 122
    const/16 v7, 0xf

    .line 123
    .line 124
    const/4 v2, 0x0

    .line 125
    const/4 v3, 0x0

    .line 126
    const/4 v4, 0x0

    .line 127
    const/4 v5, 0x0

    .line 128
    invoke-static/range {v1 .. v7}, Lwv3;->a(Lwv3;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLvq6;I)Lwv3;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    invoke-interface {v0, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    return-object v11

    .line 136
    :pswitch_1
    check-cast v0, Lvk6;

    .line 137
    .line 138
    move-object v15, v14

    .line 139
    check-cast v15, Lov0;

    .line 140
    .line 141
    check-cast v13, Lvh2;

    .line 142
    .line 143
    move-object v14, v12

    .line 144
    check-cast v14, Lxc;

    .line 145
    .line 146
    move-object/from16 v1, p1

    .line 147
    .line 148
    check-cast v1, Lca3;

    .line 149
    .line 150
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    iget-object v7, v1, Lca3;->i:Lpj0;

    .line 154
    .line 155
    invoke-interface {v7}, Lwr1;->b()J

    .line 156
    .line 157
    .line 158
    move-result-wide v16

    .line 159
    const-wide v18, 0xffffffffL

    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    shr-long v4, v16, v6

    .line 165
    .line 166
    long-to-int v4, v4

    .line 167
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 168
    .line 169
    .line 170
    move-result v4

    .line 171
    invoke-interface {v7}, Lwr1;->b()J

    .line 172
    .line 173
    .line 174
    move-result-wide v16

    .line 175
    and-long v2, v16, v18

    .line 176
    .line 177
    long-to-int v2, v2

    .line 178
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 179
    .line 180
    .line 181
    move-result v2

    .line 182
    invoke-static {v4, v2}, Ljava/lang/Math;->max(FF)F

    .line 183
    .line 184
    .line 185
    move-result v2

    .line 186
    const/high16 v3, 0x45000000    # 2048.0f

    .line 187
    .line 188
    cmpg-float v2, v2, v3

    .line 189
    .line 190
    if-gtz v2, :cond_3

    .line 191
    .line 192
    if-eqz v15, :cond_2

    .line 193
    .line 194
    iget-wide v2, v15, Lov0;->a:J

    .line 195
    .line 196
    const/16 v24, 0x0

    .line 197
    .line 198
    const/16 v25, 0x7e

    .line 199
    .line 200
    const-wide/16 v19, 0x0

    .line 201
    .line 202
    const-wide/16 v21, 0x0

    .line 203
    .line 204
    const/16 v23, 0x0

    .line 205
    .line 206
    move-object/from16 v16, v1

    .line 207
    .line 208
    move-wide/from16 v17, v2

    .line 209
    .line 210
    invoke-static/range {v16 .. v25}, Lwr1;->n0(Lwr1;JJJFII)V

    .line 211
    .line 212
    .line 213
    :cond_2
    invoke-virtual {v1}, Lca3;->c()V

    .line 214
    .line 215
    .line 216
    invoke-static {v1, v0, v10, v10}, Lrk6;->c(Lca3;Lvk6;ZZ)V

    .line 217
    .line 218
    .line 219
    goto/16 :goto_3

    .line 220
    .line 221
    :cond_3
    new-instance v2, Lip3;

    .line 222
    .line 223
    invoke-direct {v2, v1, v10}, Lip3;-><init>(Lca3;B)V

    .line 224
    .line 225
    .line 226
    invoke-interface {v7}, Lwr1;->b()J

    .line 227
    .line 228
    .line 229
    move-result-wide v3

    .line 230
    invoke-static {v3, v4}, Lvj;->X(J)J

    .line 231
    .line 232
    .line 233
    move-result-wide v3

    .line 234
    invoke-virtual {v1, v13, v3, v4, v2}, Lca3;->e(Lvh2;JLfa2;)V

    .line 235
    .line 236
    .line 237
    invoke-interface {v7}, Lwr1;->b()J

    .line 238
    .line 239
    .line 240
    move-result-wide v2

    .line 241
    shr-long/2addr v2, v6

    .line 242
    long-to-int v2, v2

    .line 243
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 244
    .line 245
    .line 246
    move-result v2

    .line 247
    invoke-interface {v7}, Lwr1;->b()J

    .line 248
    .line 249
    .line 250
    move-result-wide v3

    .line 251
    and-long v3, v3, v18

    .line 252
    .line 253
    long-to-int v3, v3

    .line 254
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 255
    .line 256
    .line 257
    move-result v3

    .line 258
    iget-object v4, v7, Lpj0;->j:Lw27;

    .line 259
    .line 260
    invoke-virtual {v4}, Lw27;->u()Lnj0;

    .line 261
    .line 262
    .line 263
    move-result-object v12

    .line 264
    move v4, v6

    .line 265
    invoke-interface {v7}, Lwr1;->b()J

    .line 266
    .line 267
    .line 268
    move-result-wide v5

    .line 269
    invoke-virtual {v0, v9, v5, v6}, Lvk6;->d(IJ)F

    .line 270
    .line 271
    .line 272
    move-result v9

    .line 273
    invoke-virtual {v0, v10, v5, v6}, Lvk6;->d(IJ)F

    .line 274
    .line 275
    .line 276
    move-result v5

    .line 277
    invoke-static {v9, v5}, Ljava/lang/Math;->max(FF)F

    .line 278
    .line 279
    .line 280
    move-result v5

    .line 281
    invoke-interface {v7}, Lwr1;->b()J

    .line 282
    .line 283
    .line 284
    move-result-wide v9

    .line 285
    const/4 v6, 0x2

    .line 286
    invoke-virtual {v0, v6, v9, v10}, Lvk6;->d(IJ)F

    .line 287
    .line 288
    .line 289
    move-result v6

    .line 290
    move/from16 v24, v4

    .line 291
    .line 292
    const/4 v4, 0x3

    .line 293
    invoke-virtual {v0, v4, v9, v10}, Lvk6;->d(IJ)F

    .line 294
    .line 295
    .line 296
    move-result v4

    .line 297
    invoke-static {v6, v4}, Ljava/lang/Math;->max(FF)F

    .line 298
    .line 299
    .line 300
    move-result v4

    .line 301
    add-float v6, v5, v4

    .line 302
    .line 303
    cmpg-float v6, v3, v6

    .line 304
    .line 305
    if-gtz v6, :cond_4

    .line 306
    .line 307
    const/16 v22, 0x1

    .line 308
    .line 309
    const/16 v23, 0x0

    .line 310
    .line 311
    const/16 v19, 0x0

    .line 312
    .line 313
    const/16 v21, 0x1

    .line 314
    .line 315
    move-object/from16 v18, v0

    .line 316
    .line 317
    move-object/from16 v16, v1

    .line 318
    .line 319
    move/from16 v20, v3

    .line 320
    .line 321
    move-object/from16 v17, v13

    .line 322
    .line 323
    move v13, v2

    .line 324
    invoke-static/range {v12 .. v23}, Lrk6;->b(Lnj0;FLxc;Lov0;Lca3;Lvh2;Lvk6;FFZZZ)V

    .line 325
    .line 326
    .line 327
    goto/16 :goto_3

    .line 328
    .line 329
    :cond_4
    move-object/from16 v18, v0

    .line 330
    .line 331
    move-object/from16 v16, v1

    .line 332
    .line 333
    move v0, v3

    .line 334
    move-object/from16 v17, v13

    .line 335
    .line 336
    move v13, v2

    .line 337
    float-to-double v1, v5

    .line 338
    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    .line 339
    .line 340
    .line 341
    move-result-wide v1

    .line 342
    double-to-float v1, v1

    .line 343
    sub-float v3, v0, v4

    .line 344
    .line 345
    float-to-double v2, v3

    .line 346
    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    .line 347
    .line 348
    .line 349
    move-result-wide v2

    .line 350
    double-to-float v2, v2

    .line 351
    cmpl-float v3, v5, v8

    .line 352
    .line 353
    if-lez v3, :cond_5

    .line 354
    .line 355
    const/16 v22, 0x0

    .line 356
    .line 357
    const/16 v23, 0x1

    .line 358
    .line 359
    const/16 v19, 0x0

    .line 360
    .line 361
    const/16 v21, 0x1

    .line 362
    .line 363
    move/from16 v20, v1

    .line 364
    .line 365
    invoke-static/range {v12 .. v23}, Lrk6;->b(Lnj0;FLxc;Lov0;Lca3;Lvh2;Lvk6;FFZZZ)V

    .line 366
    .line 367
    .line 368
    :goto_0
    move v3, v13

    .line 369
    move-object/from16 v13, v17

    .line 370
    .line 371
    move-object/from16 v1, v18

    .line 372
    .line 373
    goto :goto_1

    .line 374
    :cond_5
    move/from16 v20, v1

    .line 375
    .line 376
    goto :goto_0

    .line 377
    :goto_1
    invoke-interface {v7}, Lwr1;->b()J

    .line 378
    .line 379
    .line 380
    move-result-wide v5

    .line 381
    shr-long v5, v5, v24

    .line 382
    .line 383
    long-to-int v5, v5

    .line 384
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 385
    .line 386
    .line 387
    move-result v28

    .line 388
    iget-object v5, v7, Lpj0;->j:Lw27;

    .line 389
    .line 390
    invoke-virtual {v5}, Lw27;->G()J

    .line 391
    .line 392
    .line 393
    move-result-wide v6

    .line 394
    invoke-virtual {v5}, Lw27;->u()Lnj0;

    .line 395
    .line 396
    .line 397
    move-result-object v9

    .line 398
    invoke-interface {v9}, Lnj0;->l()V

    .line 399
    .line 400
    .line 401
    :try_start_0
    iget-object v9, v5, Lw27;->j:Ljava/lang/Object;

    .line 402
    .line 403
    move-object/from16 v25, v9

    .line 404
    .line 405
    check-cast v25, Luh7;

    .line 406
    .line 407
    const/16 v26, 0x0

    .line 408
    .line 409
    const/16 v30, 0x1

    .line 410
    .line 411
    move/from16 v29, v2

    .line 412
    .line 413
    move/from16 v27, v20

    .line 414
    .line 415
    invoke-virtual/range {v25 .. v30}, Luh7;->l(FFFFI)V

    .line 416
    .line 417
    .line 418
    if-eqz v15, :cond_6

    .line 419
    .line 420
    iget-wide v9, v15, Lov0;->a:J

    .line 421
    .line 422
    const/16 v24, 0x0

    .line 423
    .line 424
    const/16 v25, 0x7e

    .line 425
    .line 426
    const-wide/16 v19, 0x0

    .line 427
    .line 428
    const-wide/16 v21, 0x0

    .line 429
    .line 430
    const/16 v23, 0x0

    .line 431
    .line 432
    move-wide/from16 v17, v9

    .line 433
    .line 434
    invoke-static/range {v16 .. v25}, Lwr1;->n0(Lwr1;JJJFII)V

    .line 435
    .line 436
    .line 437
    move-object/from16 v2, v16

    .line 438
    .line 439
    goto :goto_2

    .line 440
    :cond_6
    move-object/from16 v2, v16

    .line 441
    .line 442
    :goto_2
    invoke-static {v2, v13}, Llm;->w(Lwr1;Lvh2;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 443
    .line 444
    .line 445
    invoke-static {v5, v6, v7}, Luj6;->y(Lw27;J)V

    .line 446
    .line 447
    .line 448
    cmpl-float v4, v4, v8

    .line 449
    .line 450
    if-lez v4, :cond_7

    .line 451
    .line 452
    const/16 v22, 0x1

    .line 453
    .line 454
    const/16 v23, 0x1

    .line 455
    .line 456
    const/16 v21, 0x0

    .line 457
    .line 458
    move/from16 v20, v0

    .line 459
    .line 460
    move-object/from16 v18, v1

    .line 461
    .line 462
    move-object/from16 v16, v2

    .line 463
    .line 464
    move-object/from16 v17, v13

    .line 465
    .line 466
    move/from16 v19, v29

    .line 467
    .line 468
    move v13, v3

    .line 469
    invoke-static/range {v12 .. v23}, Lrk6;->b(Lnj0;FLxc;Lov0;Lca3;Lvh2;Lvk6;FFZZZ)V

    .line 470
    .line 471
    .line 472
    :cond_7
    :goto_3
    return-object v11

    .line 473
    :catchall_0
    move-exception v0

    .line 474
    invoke-static {v5, v6, v7}, Luj6;->y(Lw27;J)V

    .line 475
    .line 476
    .line 477
    throw v0

    .line 478
    :pswitch_2
    check-cast v0, Lqj5;

    .line 479
    .line 480
    check-cast v14, Lwu4;

    .line 481
    .line 482
    check-cast v13, Lrv4;

    .line 483
    .line 484
    check-cast v12, Lb7;

    .line 485
    .line 486
    move-object/from16 v1, p1

    .line 487
    .line 488
    check-cast v1, Lbi;

    .line 489
    .line 490
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 491
    .line 492
    .line 493
    iget-object v2, v1, Lbi;->e:Lgx4;

    .line 494
    .line 495
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v2

    .line 499
    check-cast v2, Ljava/lang/Number;

    .line 500
    .line 501
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 502
    .line 503
    .line 504
    move-result v2

    .line 505
    iget v3, v0, Lqj5;->i:F

    .line 506
    .line 507
    sub-float/2addr v2, v3

    .line 508
    invoke-static {v2}, Li23;->o(F)Z

    .line 509
    .line 510
    .line 511
    move-result v3

    .line 512
    if-nez v3, :cond_9

    .line 513
    .line 514
    iget-object v3, v14, Lzi4;->d:Ljava/lang/Object;

    .line 515
    .line 516
    check-cast v3, Lsv4;

    .line 517
    .line 518
    invoke-virtual {v3, v13, v2, v10}, Lsv4;->b(Lrv4;FI)F

    .line 519
    .line 520
    .line 521
    move-result v3

    .line 522
    sub-float v3, v2, v3

    .line 523
    .line 524
    invoke-static {v3}, Li23;->o(F)Z

    .line 525
    .line 526
    .line 527
    move-result v3

    .line 528
    if-nez v3, :cond_8

    .line 529
    .line 530
    invoke-virtual {v1}, Lbi;->a()V

    .line 531
    .line 532
    .line 533
    goto :goto_4

    .line 534
    :cond_8
    iget v3, v0, Lqj5;->i:F

    .line 535
    .line 536
    add-float/2addr v3, v2

    .line 537
    iput v3, v0, Lqj5;->i:F

    .line 538
    .line 539
    :cond_9
    iget v0, v0, Lqj5;->i:F

    .line 540
    .line 541
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 542
    .line 543
    .line 544
    move-result-object v0

    .line 545
    invoke-virtual {v12, v0}, Lb7;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 546
    .line 547
    .line 548
    move-result-object v0

    .line 549
    check-cast v0, Ljava/lang/Boolean;

    .line 550
    .line 551
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 552
    .line 553
    .line 554
    move-result v0

    .line 555
    if-eqz v0, :cond_a

    .line 556
    .line 557
    invoke-virtual {v1}, Lbi;->a()V

    .line 558
    .line 559
    .line 560
    :cond_a
    :goto_4
    return-object v11

    .line 561
    :pswitch_3
    move-object v3, v14

    .line 562
    check-cast v3, Ljava/lang/String;

    .line 563
    .line 564
    move-object v4, v0

    .line 565
    check-cast v4, Lur4;

    .line 566
    .line 567
    move-object v5, v13

    .line 568
    check-cast v5, Ljava/lang/String;

    .line 569
    .line 570
    move-object v6, v12

    .line 571
    check-cast v6, Lu92;

    .line 572
    .line 573
    move-object/from16 v0, p1

    .line 574
    .line 575
    check-cast v0, Lnd3;

    .line 576
    .line 577
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 578
    .line 579
    .line 580
    if-eqz v3, :cond_b

    .line 581
    .line 582
    new-instance v2, Ljl;

    .line 583
    .line 584
    const/16 v7, 0x10

    .line 585
    .line 586
    invoke-direct/range {v2 .. v7}, Ljl;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 587
    .line 588
    .line 589
    new-instance v1, Lyz0;

    .line 590
    .line 591
    const v3, -0x3d240a0b

    .line 592
    .line 593
    .line 594
    invoke-direct {v1, v3, v10, v2}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 595
    .line 596
    .line 597
    const-string v2, "status"

    .line 598
    .line 599
    const/4 v6, 0x2

    .line 600
    invoke-static {v0, v2, v1, v6}, Lnd3;->l0(Lnd3;Ljava/lang/String;Lka2;I)V

    .line 601
    .line 602
    .line 603
    :cond_b
    iget-object v1, v4, Lur4;->b:Ljava/util/List;

    .line 604
    .line 605
    new-instance v2, Lzf4;

    .line 606
    .line 607
    const/16 v3, 0x17

    .line 608
    .line 609
    invoke-direct {v2, v3}, Lzf4;-><init>(B)V

    .line 610
    .line 611
    .line 612
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 613
    .line 614
    .line 615
    move-result v3

    .line 616
    new-instance v6, Lc0;

    .line 617
    .line 618
    const/16 v7, 0x12

    .line 619
    .line 620
    invoke-direct {v6, v2, v1, v7}, Lc0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 621
    .line 622
    .line 623
    new-instance v2, Ld0;

    .line 624
    .line 625
    const/16 v7, 0xb

    .line 626
    .line 627
    invoke-direct {v2, v1, v7}, Ld0;-><init>(Ljava/util/List;B)V

    .line 628
    .line 629
    .line 630
    new-instance v7, Lpr4;

    .line 631
    .line 632
    invoke-direct {v7, v1, v4, v5, v10}, Lpr4;-><init>(Ljava/util/List;Lur4;Ljava/lang/Object;B)V

    .line 633
    .line 634
    .line 635
    new-instance v1, Lyz0;

    .line 636
    .line 637
    const v4, 0x2fd4df92

    .line 638
    .line 639
    .line 640
    invoke-direct {v1, v4, v10, v7}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 641
    .line 642
    .line 643
    invoke-virtual {v0, v3, v6, v2, v1}, Lnd3;->m0(ILfa2;Lfa2;Lyz0;)V

    .line 644
    .line 645
    .line 646
    return-object v11

    .line 647
    :pswitch_4
    check-cast v0, Ljava/util/List;

    .line 648
    .line 649
    check-cast v14, Lfa2;

    .line 650
    .line 651
    check-cast v13, Lj44;

    .line 652
    .line 653
    check-cast v12, Lj44;

    .line 654
    .line 655
    move-object/from16 v1, p1

    .line 656
    .line 657
    check-cast v1, Lye4;

    .line 658
    .line 659
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 660
    .line 661
    .line 662
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 663
    .line 664
    invoke-interface {v13, v2}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 665
    .line 666
    .line 667
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 668
    .line 669
    .line 670
    move-result v0

    .line 671
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 672
    .line 673
    .line 674
    move-result-object v0

    .line 675
    invoke-interface {v12, v0}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 676
    .line 677
    .line 678
    invoke-interface {v14, v1}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 679
    .line 680
    .line 681
    return-object v11

    .line 682
    :pswitch_5
    check-cast v0, Lqj5;

    .line 683
    .line 684
    check-cast v14, Ly14;

    .line 685
    .line 686
    check-cast v13, Lf46;

    .line 687
    .line 688
    check-cast v12, Lb7;

    .line 689
    .line 690
    move-object/from16 v1, p1

    .line 691
    .line 692
    check-cast v1, Lbi;

    .line 693
    .line 694
    iget-object v2, v1, Lbi;->e:Lgx4;

    .line 695
    .line 696
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    move-result-object v2

    .line 700
    check-cast v2, Ljava/lang/Number;

    .line 701
    .line 702
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 703
    .line 704
    .line 705
    move-result v2

    .line 706
    iget v3, v0, Lqj5;->i:F

    .line 707
    .line 708
    sub-float/2addr v2, v3

    .line 709
    invoke-static {v2}, Lg93;->S(F)Z

    .line 710
    .line 711
    .line 712
    move-result v3

    .line 713
    if-nez v3, :cond_d

    .line 714
    .line 715
    invoke-virtual {v14, v13, v2}, Ly14;->d(Lf46;F)F

    .line 716
    .line 717
    .line 718
    move-result v3

    .line 719
    sub-float v3, v2, v3

    .line 720
    .line 721
    invoke-static {v3}, Lg93;->S(F)Z

    .line 722
    .line 723
    .line 724
    move-result v3

    .line 725
    if-nez v3, :cond_c

    .line 726
    .line 727
    invoke-virtual {v1}, Lbi;->a()V

    .line 728
    .line 729
    .line 730
    goto :goto_5

    .line 731
    :cond_c
    iget v3, v0, Lqj5;->i:F

    .line 732
    .line 733
    add-float/2addr v3, v2

    .line 734
    iput v3, v0, Lqj5;->i:F

    .line 735
    .line 736
    :cond_d
    iget v0, v0, Lqj5;->i:F

    .line 737
    .line 738
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    invoke-virtual {v12, v0}, Lb7;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 743
    .line 744
    .line 745
    move-result-object v0

    .line 746
    check-cast v0, Ljava/lang/Boolean;

    .line 747
    .line 748
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 749
    .line 750
    .line 751
    move-result v0

    .line 752
    if-eqz v0, :cond_e

    .line 753
    .line 754
    invoke-virtual {v1}, Lbi;->a()V

    .line 755
    .line 756
    .line 757
    :cond_e
    :goto_5
    return-object v11

    .line 758
    :pswitch_6
    check-cast v0, Luy3;

    .line 759
    .line 760
    check-cast v14, Lij;

    .line 761
    .line 762
    check-cast v13, Lv67;

    .line 763
    .line 764
    check-cast v12, Lj44;

    .line 765
    .line 766
    move-object/from16 v1, p1

    .line 767
    .line 768
    check-cast v1, Ljava/lang/Float;

    .line 769
    .line 770
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 771
    .line 772
    .line 773
    move-result v2

    .line 774
    if-eqz v0, :cond_f

    .line 775
    .line 776
    if-eqz v14, :cond_f

    .line 777
    .line 778
    iget-object v3, v0, Luy3;->b:Ljava/util/LinkedHashMap;

    .line 779
    .line 780
    invoke-interface {v3, v14, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 781
    .line 782
    .line 783
    iget-object v1, v0, Luy3;->c:Lij;

    .line 784
    .line 785
    if-ne v14, v1, :cond_10

    .line 786
    .line 787
    iget-object v0, v0, Luy3;->d:Lv67;

    .line 788
    .line 789
    if-eqz v0, :cond_10

    .line 790
    .line 791
    iget-object v0, v0, Lv67;->c:Lcx4;

    .line 792
    .line 793
    invoke-virtual {v0, v2}, Lcx4;->h(F)V

    .line 794
    .line 795
    .line 796
    goto :goto_6

    .line 797
    :cond_f
    invoke-interface {v12}, Lnl6;->getValue()Ljava/lang/Object;

    .line 798
    .line 799
    .line 800
    move-result-object v0

    .line 801
    check-cast v0, Ljava/lang/Boolean;

    .line 802
    .line 803
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 804
    .line 805
    .line 806
    move-result v0

    .line 807
    if-eqz v0, :cond_10

    .line 808
    .line 809
    iget-object v0, v13, Lv67;->c:Lcx4;

    .line 810
    .line 811
    invoke-virtual {v0, v2}, Lcx4;->h(F)V

    .line 812
    .line 813
    .line 814
    :cond_10
    :goto_6
    return-object v11

    .line 815
    :pswitch_7
    check-cast v0, Lzc3;

    .line 816
    .line 817
    check-cast v14, Lnc3;

    .line 818
    .line 819
    check-cast v13, Lvo6;

    .line 820
    .line 821
    check-cast v12, Lz35;

    .line 822
    .line 823
    move-object/from16 v1, p1

    .line 824
    .line 825
    check-cast v1, Lko1;

    .line 826
    .line 827
    new-instance v1, Lnn1;

    .line 828
    .line 829
    invoke-direct {v1, v14, v13, v12}, Lnn1;-><init>(Lnc3;Lvo6;Lz35;)V

    .line 830
    .line 831
    .line 832
    iput-object v1, v0, Lzc3;->c:Lnn1;

    .line 833
    .line 834
    new-instance v1, Ld7;

    .line 835
    .line 836
    const/16 v2, 0xa

    .line 837
    .line 838
    invoke-direct {v1, v0, v2}, Ld7;-><init>(Ljava/lang/Object;B)V

    .line 839
    .line 840
    .line 841
    return-object v1

    .line 842
    :pswitch_8
    move/from16 v24, v6

    .line 843
    .line 844
    const-wide v18, 0xffffffffL

    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    check-cast v0, Ljava/util/ArrayList;

    .line 850
    .line 851
    check-cast v14, Lrj5;

    .line 852
    .line 853
    check-cast v13, Ljava/util/List;

    .line 854
    .line 855
    check-cast v12, Lnb3;

    .line 856
    .line 857
    move-object/from16 v1, p1

    .line 858
    .line 859
    check-cast v1, Ly35;

    .line 860
    .line 861
    iget-object v2, v1, Ly35;->e:Luo6;

    .line 862
    .line 863
    if-eqz v2, :cond_11

    .line 864
    .line 865
    invoke-interface {v2}, Luo6;->d()I

    .line 866
    .line 867
    .line 868
    move-result v2

    .line 869
    goto :goto_7

    .line 870
    :cond_11
    move v2, v9

    .line 871
    :goto_7
    move v3, v9

    .line 872
    :goto_8
    if-ge v9, v2, :cond_15

    .line 873
    .line 874
    iget-object v4, v12, Lnb3;->r:Lip4;

    .line 875
    .line 876
    iget-object v5, v1, Ly35;->e:Luo6;

    .line 877
    .line 878
    const-wide/16 v6, 0x0

    .line 879
    .line 880
    sget-object v8, Lip4;->i:Lip4;

    .line 881
    .line 882
    if-ne v4, v8, :cond_13

    .line 883
    .line 884
    if-eqz v5, :cond_12

    .line 885
    .line 886
    invoke-interface {v5, v9}, Luo6;->c(I)J

    .line 887
    .line 888
    .line 889
    move-result-wide v6

    .line 890
    :cond_12
    and-long v6, v6, v18

    .line 891
    .line 892
    :goto_9
    long-to-int v4, v6

    .line 893
    goto :goto_a

    .line 894
    :cond_13
    if-eqz v5, :cond_14

    .line 895
    .line 896
    invoke-interface {v5, v9}, Luo6;->c(I)J

    .line 897
    .line 898
    .line 899
    move-result-wide v6

    .line 900
    :cond_14
    shr-long v6, v6, v24

    .line 901
    .line 902
    goto :goto_9

    .line 903
    :goto_a
    add-int/2addr v3, v4

    .line 904
    add-int/lit8 v9, v9, 0x1

    .line 905
    .line 906
    goto :goto_8

    .line 907
    :cond_15
    if-eqz v0, :cond_16

    .line 908
    .line 909
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 910
    .line 911
    .line 912
    move-result-object v1

    .line 913
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 914
    .line 915
    .line 916
    :cond_16
    iget v0, v14, Lrj5;->i:I

    .line 917
    .line 918
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 919
    .line 920
    .line 921
    move-result v1

    .line 922
    if-eq v0, v1, :cond_17

    .line 923
    .line 924
    iget v0, v14, Lrj5;->i:I

    .line 925
    .line 926
    add-int/2addr v0, v10

    .line 927
    iput v0, v14, Lrj5;->i:I

    .line 928
    .line 929
    :cond_17
    return-object v11

    .line 930
    :pswitch_9
    check-cast v0, Lj44;

    .line 931
    .line 932
    check-cast v14, Lay2;

    .line 933
    .line 934
    check-cast v13, Lqj5;

    .line 935
    .line 936
    check-cast v12, Lnf1;

    .line 937
    .line 938
    move-object/from16 v1, p1

    .line 939
    .line 940
    check-cast v1, Ljava/lang/Long;

    .line 941
    .line 942
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 943
    .line 944
    .line 945
    move-result-wide v1

    .line 946
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 947
    .line 948
    .line 949
    move-result-object v0

    .line 950
    check-cast v0, Lnl6;

    .line 951
    .line 952
    if-eqz v0, :cond_18

    .line 953
    .line 954
    invoke-interface {v0}, Lnl6;->getValue()Ljava/lang/Object;

    .line 955
    .line 956
    .line 957
    move-result-object v0

    .line 958
    check-cast v0, Ljava/lang/Number;

    .line 959
    .line 960
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 961
    .line 962
    .line 963
    move-result-wide v3

    .line 964
    goto :goto_b

    .line 965
    :cond_18
    move-wide v3, v1

    .line 966
    :goto_b
    iget-wide v5, v14, Lay2;->c:J

    .line 967
    .line 968
    iget-object v0, v14, Lay2;->a:Ll44;

    .line 969
    .line 970
    const-wide/high16 v15, -0x8000000000000000L

    .line 971
    .line 972
    cmp-long v5, v5, v15

    .line 973
    .line 974
    if-eqz v5, :cond_19

    .line 975
    .line 976
    iget v5, v13, Lqj5;->i:F

    .line 977
    .line 978
    invoke-interface {v12}, Lnf1;->e()Ldf1;

    .line 979
    .line 980
    .line 981
    move-result-object v6

    .line 982
    invoke-static {v6}, Lur6;->p(Ldf1;)F

    .line 983
    .line 984
    .line 985
    move-result v6

    .line 986
    cmpg-float v5, v5, v6

    .line 987
    .line 988
    if-eqz v5, :cond_1b

    .line 989
    .line 990
    :cond_19
    iput-wide v1, v14, Lay2;->c:J

    .line 991
    .line 992
    iget-object v1, v0, Ll44;->i:[Ljava/lang/Object;

    .line 993
    .line 994
    iget v2, v0, Ll44;->k:I

    .line 995
    .line 996
    move v5, v9

    .line 997
    :goto_c
    if-ge v5, v2, :cond_1a

    .line 998
    .line 999
    aget-object v6, v1, v5

    .line 1000
    .line 1001
    check-cast v6, Lxx2;

    .line 1002
    .line 1003
    iput-boolean v10, v6, Lxx2;->n:Z

    .line 1004
    .line 1005
    add-int/lit8 v5, v5, 0x1

    .line 1006
    .line 1007
    goto :goto_c

    .line 1008
    :cond_1a
    invoke-interface {v12}, Lnf1;->e()Ldf1;

    .line 1009
    .line 1010
    .line 1011
    move-result-object v1

    .line 1012
    invoke-static {v1}, Lur6;->p(Ldf1;)F

    .line 1013
    .line 1014
    .line 1015
    move-result v1

    .line 1016
    iput v1, v13, Lqj5;->i:F

    .line 1017
    .line 1018
    :cond_1b
    iget v1, v13, Lqj5;->i:F

    .line 1019
    .line 1020
    cmpg-float v2, v1, v8

    .line 1021
    .line 1022
    if-nez v2, :cond_1c

    .line 1023
    .line 1024
    iget-object v1, v0, Ll44;->i:[Ljava/lang/Object;

    .line 1025
    .line 1026
    iget v0, v0, Ll44;->k:I

    .line 1027
    .line 1028
    :goto_d
    if-ge v9, v0, :cond_21

    .line 1029
    .line 1030
    aget-object v2, v1, v9

    .line 1031
    .line 1032
    check-cast v2, Lxx2;

    .line 1033
    .line 1034
    iget-object v3, v2, Lxx2;->l:Lwu6;

    .line 1035
    .line 1036
    iget-object v3, v3, Lwu6;->c:Ljava/lang/Object;

    .line 1037
    .line 1038
    iget-object v4, v2, Lxx2;->k:Lgx4;

    .line 1039
    .line 1040
    invoke-virtual {v4, v3}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1041
    .line 1042
    .line 1043
    iput-boolean v10, v2, Lxx2;->n:Z

    .line 1044
    .line 1045
    add-int/lit8 v9, v9, 0x1

    .line 1046
    .line 1047
    goto :goto_d

    .line 1048
    :cond_1c
    iget-wide v5, v14, Lay2;->c:J

    .line 1049
    .line 1050
    sub-long/2addr v3, v5

    .line 1051
    long-to-float v2, v3

    .line 1052
    div-float/2addr v2, v1

    .line 1053
    float-to-long v1, v2

    .line 1054
    iget-object v3, v0, Ll44;->i:[Ljava/lang/Object;

    .line 1055
    .line 1056
    iget v0, v0, Ll44;->k:I

    .line 1057
    .line 1058
    move v4, v9

    .line 1059
    move v5, v10

    .line 1060
    :goto_e
    if-ge v4, v0, :cond_20

    .line 1061
    .line 1062
    aget-object v6, v3, v4

    .line 1063
    .line 1064
    check-cast v6, Lxx2;

    .line 1065
    .line 1066
    iget-boolean v7, v6, Lxx2;->m:Z

    .line 1067
    .line 1068
    if-nez v7, :cond_1e

    .line 1069
    .line 1070
    iget-object v7, v6, Lxx2;->p:Lay2;

    .line 1071
    .line 1072
    iget-object v7, v7, Lay2;->b:Lgx4;

    .line 1073
    .line 1074
    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1075
    .line 1076
    invoke-virtual {v7, v8}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1077
    .line 1078
    .line 1079
    iget-boolean v7, v6, Lxx2;->n:Z

    .line 1080
    .line 1081
    if-eqz v7, :cond_1d

    .line 1082
    .line 1083
    iput-boolean v9, v6, Lxx2;->n:Z

    .line 1084
    .line 1085
    iput-wide v1, v6, Lxx2;->o:J

    .line 1086
    .line 1087
    :cond_1d
    iget-wide v7, v6, Lxx2;->o:J

    .line 1088
    .line 1089
    sub-long v7, v1, v7

    .line 1090
    .line 1091
    iget-object v12, v6, Lxx2;->l:Lwu6;

    .line 1092
    .line 1093
    invoke-virtual {v12, v7, v8}, Lwu6;->b(J)Ljava/lang/Object;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v12

    .line 1097
    iget-object v13, v6, Lxx2;->k:Lgx4;

    .line 1098
    .line 1099
    invoke-virtual {v13, v12}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1100
    .line 1101
    .line 1102
    iget-object v12, v6, Lxx2;->l:Lwu6;

    .line 1103
    .line 1104
    invoke-interface {v12, v7, v8}, Lxh;->g(J)Z

    .line 1105
    .line 1106
    .line 1107
    move-result v7

    .line 1108
    iput-boolean v7, v6, Lxx2;->m:Z

    .line 1109
    .line 1110
    :cond_1e
    if-nez v7, :cond_1f

    .line 1111
    .line 1112
    move v5, v9

    .line 1113
    :cond_1f
    add-int/lit8 v4, v4, 0x1

    .line 1114
    .line 1115
    goto :goto_e

    .line 1116
    :cond_20
    xor-int/2addr v5, v10

    .line 1117
    iget-object v0, v14, Lay2;->d:Lgx4;

    .line 1118
    .line 1119
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1120
    .line 1121
    .line 1122
    move-result-object v1

    .line 1123
    invoke-virtual {v0, v1}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1124
    .line 1125
    .line 1126
    :cond_21
    return-object v11

    .line 1127
    :pswitch_a
    check-cast v0, Lu92;

    .line 1128
    .line 1129
    check-cast v14, Lk12;

    .line 1130
    .line 1131
    check-cast v13, Le87;

    .line 1132
    .line 1133
    check-cast v12, Lu92;

    .line 1134
    .line 1135
    move-object/from16 v1, p1

    .line 1136
    .line 1137
    check-cast v1, Lyh2;

    .line 1138
    .line 1139
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1140
    .line 1141
    .line 1142
    if-eqz v0, :cond_22

    .line 1143
    .line 1144
    invoke-interface {v0}, Lu92;->invoke()Ljava/lang/Object;

    .line 1145
    .line 1146
    .line 1147
    move-result-object v0

    .line 1148
    check-cast v0, Ljava/lang/Number;

    .line 1149
    .line 1150
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1151
    .line 1152
    .line 1153
    move-result v0

    .line 1154
    :goto_f
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1155
    .line 1156
    .line 1157
    move-result-object v7

    .line 1158
    goto :goto_10

    .line 1159
    :cond_22
    if-eqz v14, :cond_23

    .line 1160
    .line 1161
    iget-object v0, v14, Lk12;->a:Lv67;

    .line 1162
    .line 1163
    if-eqz v0, :cond_23

    .line 1164
    .line 1165
    iget-object v2, v0, Lv67;->b:Lcx4;

    .line 1166
    .line 1167
    invoke-virtual {v2}, Lcx4;->g()F

    .line 1168
    .line 1169
    .line 1170
    move-result v2

    .line 1171
    iget-object v0, v0, Lv67;->c:Lcx4;

    .line 1172
    .line 1173
    invoke-virtual {v0}, Lcx4;->g()F

    .line 1174
    .line 1175
    .line 1176
    move-result v0

    .line 1177
    add-float/2addr v0, v2

    .line 1178
    goto :goto_f

    .line 1179
    :cond_23
    :goto_10
    const/high16 v0, 0x3f800000    # 1.0f

    .line 1180
    .line 1181
    if-eqz v7, :cond_24

    .line 1182
    .line 1183
    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    .line 1184
    .line 1185
    .line 1186
    move-result v2

    .line 1187
    neg-float v2, v2

    .line 1188
    const/high16 v3, 0x42400000    # 48.0f

    .line 1189
    .line 1190
    invoke-interface {v1}, Lkl1;->a()F

    .line 1191
    .line 1192
    .line 1193
    move-result v4

    .line 1194
    mul-float/2addr v4, v3

    .line 1195
    div-float/2addr v2, v4

    .line 1196
    invoke-static {v2, v8, v0}, Lkb3;->A(FFF)F

    .line 1197
    .line 1198
    .line 1199
    move-result v2

    .line 1200
    goto :goto_11

    .line 1201
    :cond_24
    iget-object v2, v13, Le87;->p:Lgx4;

    .line 1202
    .line 1203
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v2

    .line 1207
    check-cast v2, Ljava/lang/Number;

    .line 1208
    .line 1209
    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    .line 1210
    .line 1211
    .line 1212
    move-result v2

    .line 1213
    :goto_11
    invoke-interface {v12}, Lu92;->invoke()Ljava/lang/Object;

    .line 1214
    .line 1215
    .line 1216
    move-result-object v3

    .line 1217
    check-cast v3, Ljava/lang/Number;

    .line 1218
    .line 1219
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 1220
    .line 1221
    .line 1222
    move-result v3

    .line 1223
    invoke-static {v3, v8, v0}, Lkb3;->A(FFF)F

    .line 1224
    .line 1225
    .line 1226
    move-result v0

    .line 1227
    mul-float/2addr v0, v2

    .line 1228
    invoke-interface {v1, v0}, Lyh2;->y(F)V

    .line 1229
    .line 1230
    .line 1231
    return-object v11

    .line 1232
    :pswitch_b
    check-cast v0, Ljava/util/List;

    .line 1233
    .line 1234
    check-cast v14, Lj44;

    .line 1235
    .line 1236
    check-cast v13, Lj44;

    .line 1237
    .line 1238
    check-cast v12, Lj44;

    .line 1239
    .line 1240
    move-object/from16 v1, p1

    .line 1241
    .line 1242
    check-cast v1, Lle1;

    .line 1243
    .line 1244
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1245
    .line 1246
    .line 1247
    :try_start_1
    sget-object v2, Lne1;->a:Lne1;

    .line 1248
    .line 1249
    invoke-static {v1}, Lne1;->g(Lle1;)V

    .line 1250
    .line 1251
    .line 1252
    new-instance v2, Ljava/util/ArrayList;

    .line 1253
    .line 1254
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 1255
    .line 1256
    .line 1257
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1258
    .line 1259
    .line 1260
    move-result-object v0

    .line 1261
    :cond_25
    :goto_12
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1262
    .line 1263
    .line 1264
    move-result v3

    .line 1265
    if-eqz v3, :cond_26

    .line 1266
    .line 1267
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1268
    .line 1269
    .line 1270
    move-result-object v3

    .line 1271
    move-object v4, v3

    .line 1272
    check-cast v4, Lle1;

    .line 1273
    .line 1274
    iget-object v4, v4, Lle1;->a:Ljava/lang/String;

    .line 1275
    .line 1276
    iget-object v5, v1, Lle1;->a:Ljava/lang/String;

    .line 1277
    .line 1278
    invoke-static {v4, v5}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1279
    .line 1280
    .line 1281
    move-result v4

    .line 1282
    if-nez v4, :cond_25

    .line 1283
    .line 1284
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1285
    .line 1286
    .line 1287
    goto :goto_12

    .line 1288
    :cond_26
    invoke-static {v2, v1}, Liv0;->K0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1289
    .line 1290
    .line 1291
    move-result-object v0

    .line 1292
    invoke-static {v0, v10}, Lne1;->f(Ljava/util/ArrayList;Z)V

    .line 1293
    .line 1294
    .line 1295
    invoke-interface {v14, v7}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 1296
    .line 1297
    .line 1298
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1299
    .line 1300
    invoke-interface {v13, v0}, Lj44;->setValue(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 1301
    .line 1302
    .line 1303
    goto :goto_13

    .line 1304
    :catch_0
    move-exception v0

    .line 1305
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v0

    .line 1309
    if-nez v0, :cond_27

    .line 1310
    .line 1311
    const-string v0, "Error"

    .line 1312
    .line 1313
    :cond_27
    invoke-interface {v12, v0}, Lj44;->setValue(Ljava/lang/Object;)V

    .line 1314
    .line 1315
    .line 1316
    :goto_13
    return-object v11

    .line 1317
    :pswitch_c
    check-cast v0, Ljava/util/List;

    .line 1318
    .line 1319
    check-cast v14, Ljo3;

    .line 1320
    .line 1321
    check-cast v13, Lta0;

    .line 1322
    .line 1323
    check-cast v12, Lmv;

    .line 1324
    .line 1325
    move-object/from16 v1, p1

    .line 1326
    .line 1327
    check-cast v1, Ljava/lang/Boolean;

    .line 1328
    .line 1329
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1330
    .line 1331
    .line 1332
    move-result v1

    .line 1333
    iget-object v2, v14, Ljo3;->c:Ldx4;

    .line 1334
    .line 1335
    invoke-virtual {v2}, Ldx4;->g()I

    .line 1336
    .line 1337
    .line 1338
    move-result v2

    .line 1339
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1340
    .line 1341
    .line 1342
    invoke-static {v2, v0}, Liv0;->z0(ILjava/util/List;)Ljava/lang/Object;

    .line 1343
    .line 1344
    .line 1345
    move-result-object v0

    .line 1346
    check-cast v0, Li40;

    .line 1347
    .line 1348
    if-nez v0, :cond_28

    .line 1349
    .line 1350
    sget-object v0, Li40;->m:Li40;

    .line 1351
    .line 1352
    :cond_28
    invoke-static {v1}, Luj;->h0(Z)Ljava/util/List;

    .line 1353
    .line 1354
    .line 1355
    move-result-object v2

    .line 1356
    invoke-static {v2, v0}, Luj;->U(Ljava/util/List;Li40;)I

    .line 1357
    .line 1358
    .line 1359
    move-result v0

    .line 1360
    if-eqz v1, :cond_29

    .line 1361
    .line 1362
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1363
    .line 1364
    .line 1365
    move-result-object v0

    .line 1366
    iget-object v2, v13, Lta0;->i:Lgx4;

    .line 1367
    .line 1368
    invoke-virtual {v2, v0}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1369
    .line 1370
    .line 1371
    goto :goto_14

    .line 1372
    :cond_29
    invoke-virtual {v14, v0}, Ljo3;->b(I)V

    .line 1373
    .line 1374
    .line 1375
    :goto_14
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1376
    .line 1377
    .line 1378
    new-instance v0, Lzr;

    .line 1379
    .line 1380
    const/16 v2, 0xc

    .line 1381
    .line 1382
    invoke-direct {v0, v2, v1}, Lzr;-><init>(BZ)V

    .line 1383
    .line 1384
    .line 1385
    invoke-virtual {v12, v0}, Lmv;->c(Lfa2;)V

    .line 1386
    .line 1387
    .line 1388
    return-object v11

    .line 1389
    :pswitch_d
    check-cast v0, Lmg;

    .line 1390
    .line 1391
    check-cast v14, Ldi;

    .line 1392
    .line 1393
    check-cast v13, Lfa2;

    .line 1394
    .line 1395
    check-cast v12, Lpj5;

    .line 1396
    .line 1397
    move-object/from16 v1, p1

    .line 1398
    .line 1399
    check-cast v1, Lbi;

    .line 1400
    .line 1401
    iget-object v2, v0, Lmg;->c:Ldi;

    .line 1402
    .line 1403
    invoke-static {v1, v2}, Lur6;->t(Lbi;Ldi;)V

    .line 1404
    .line 1405
    .line 1406
    iget-object v2, v1, Lbi;->e:Lgx4;

    .line 1407
    .line 1408
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 1409
    .line 1410
    .line 1411
    move-result-object v3

    .line 1412
    invoke-virtual {v0, v3}, Lmg;->c(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v3

    .line 1416
    invoke-virtual {v2}, Lgx4;->getValue()Ljava/lang/Object;

    .line 1417
    .line 1418
    .line 1419
    move-result-object v2

    .line 1420
    invoke-static {v3, v2}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1421
    .line 1422
    .line 1423
    move-result v2

    .line 1424
    if-nez v2, :cond_2b

    .line 1425
    .line 1426
    iget-object v2, v0, Lmg;->c:Ldi;

    .line 1427
    .line 1428
    iget-object v2, v2, Ldi;->j:Lgx4;

    .line 1429
    .line 1430
    invoke-virtual {v2, v3}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1431
    .line 1432
    .line 1433
    iget-object v2, v14, Ldi;->j:Lgx4;

    .line 1434
    .line 1435
    invoke-virtual {v2, v3}, Lgx4;->setValue(Ljava/lang/Object;)V

    .line 1436
    .line 1437
    .line 1438
    if-eqz v13, :cond_2a

    .line 1439
    .line 1440
    invoke-interface {v13, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1441
    .line 1442
    .line 1443
    :cond_2a
    invoke-virtual {v1}, Lbi;->a()V

    .line 1444
    .line 1445
    .line 1446
    iput-boolean v10, v12, Lpj5;->i:Z

    .line 1447
    .line 1448
    goto :goto_15

    .line 1449
    :cond_2b
    if-eqz v13, :cond_2c

    .line 1450
    .line 1451
    invoke-interface {v13, v0}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1452
    .line 1453
    .line 1454
    :cond_2c
    :goto_15
    return-object v11

    .line 1455
    :pswitch_e
    check-cast v0, Lrf;

    .line 1456
    .line 1457
    check-cast v14, Ljava/lang/String;

    .line 1458
    .line 1459
    check-cast v13, Lja2;

    .line 1460
    .line 1461
    check-cast v12, Landroid/content/Context;

    .line 1462
    .line 1463
    move-object/from16 v1, p1

    .line 1464
    .line 1465
    check-cast v1, Lnd3;

    .line 1466
    .line 1467
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1468
    .line 1469
    .line 1470
    new-instance v2, Lc2;

    .line 1471
    .line 1472
    invoke-direct {v2, v0, v14, v9}, Lc2;-><init>(Lrf;Ljava/lang/String;B)V

    .line 1473
    .line 1474
    .line 1475
    new-instance v0, Lyz0;

    .line 1476
    .line 1477
    const v3, 0x290b7044

    .line 1478
    .line 1479
    .line 1480
    invoke-direct {v0, v3, v10, v2}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1481
    .line 1482
    .line 1483
    const/4 v5, 0x3

    .line 1484
    invoke-static {v1, v7, v0, v5}, Lnd3;->l0(Lnd3;Ljava/lang/String;Lka2;I)V

    .line 1485
    .line 1486
    .line 1487
    new-instance v0, Ld2;

    .line 1488
    .line 1489
    invoke-direct {v0, v13, v12, v9}, Ld2;-><init>(Lja2;Landroid/content/Context;B)V

    .line 1490
    .line 1491
    .line 1492
    new-instance v2, Lyz0;

    .line 1493
    .line 1494
    const v3, 0xa6505fb

    .line 1495
    .line 1496
    .line 1497
    invoke-direct {v2, v3, v10, v0}, Lyz0;-><init>(IZLjava/lang/Object;)V

    .line 1498
    .line 1499
    .line 1500
    invoke-static {v1, v7, v2, v5}, Lnd3;->l0(Lnd3;Ljava/lang/String;Lka2;I)V

    .line 1501
    .line 1502
    .line 1503
    return-object v11

    .line 1504
    nop

    .line 1505
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
