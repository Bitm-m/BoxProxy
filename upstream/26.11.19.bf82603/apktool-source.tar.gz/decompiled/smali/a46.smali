.class public final La46;
.super Lwq1;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lp73;
.implements Lo76;


# instance fields
.field public final R:Laa4;

.field public S:Lt;

.field public T:Lk4;

.field public U:Z

.field public V:Z

.field public W:Ly14;

.field public X:Lo77;

.field public final Y:Lpj1;

.field public final Z:Lh46;

.field public final a0:Lx36;

.field public final b0:Lk72;

.field public final c0:Ld91;


# direct methods
.method public constructor <init>(Loe0;Lo32;Lj34;Lip4;Lar4;Lb46;ZZ)V
    .locals 10

    .line 1
    move/from16 v9, p7

    .line 2
    .line 3
    sget-object v0, Li23;->a:Li;

    .line 4
    .line 5
    invoke-direct {p0, v0, v9, p3, p4}, Lwq1;-><init>(Lfa2;ZLj34;Lip4;)V

    .line 6
    .line 7
    .line 8
    new-instance v0, Laa4;

    .line 9
    .line 10
    invoke-direct {v0}, Laa4;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, La46;->R:Laa4;

    .line 14
    .line 15
    new-instance v0, Lpj1;

    .line 16
    .line 17
    sget-object v1, Lv36;->c:Lbw4;

    .line 18
    .line 19
    new-instance v3, Lf95;

    .line 20
    .line 21
    invoke-direct {v3, v1}, Lf95;-><init>(Lkl1;)V

    .line 22
    .line 23
    .line 24
    new-instance v1, Lii1;

    .line 25
    .line 26
    invoke-direct {v1, v3}, Lii1;-><init>(Lu32;)V

    .line 27
    .line 28
    .line 29
    invoke-direct {v0, v1}, Lpj1;-><init>(Lii1;)V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, La46;->Y:Lpj1;

    .line 33
    .line 34
    if-nez p2, :cond_0

    .line 35
    .line 36
    move-object v3, v0

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    move-object v3, p2

    .line 39
    :goto_0
    iget-object v6, p0, La46;->R:Laa4;

    .line 40
    .line 41
    new-instance v0, Lh46;

    .line 42
    .line 43
    new-instance v8, Ly36;

    .line 44
    .line 45
    const/4 v1, 0x0

    .line 46
    invoke-direct {v8, p0, v1}, Ly36;-><init>(La46;B)V

    .line 47
    .line 48
    .line 49
    move-object v7, p0

    .line 50
    move-object v4, p4

    .line 51
    move-object v2, p5

    .line 52
    move-object/from16 v1, p6

    .line 53
    .line 54
    move/from16 v5, p8

    .line 55
    .line 56
    invoke-direct/range {v0 .. v8}, Lh46;-><init>(Lb46;Lar4;Lo32;Lip4;ZLaa4;La46;Ly36;)V

    .line 57
    .line 58
    .line 59
    iput-object v0, p0, La46;->Z:Lh46;

    .line 60
    .line 61
    new-instance v8, Lx36;

    .line 62
    .line 63
    invoke-direct {v8, v0, v9}, Lx36;-><init>(Lh46;Z)V

    .line 64
    .line 65
    .line 66
    iput-object v8, p0, La46;->a0:Lx36;

    .line 67
    .line 68
    new-instance v1, Lk72;

    .line 69
    .line 70
    const/16 v2, 0xa

    .line 71
    .line 72
    const/4 v3, 0x2

    .line 73
    const/4 v4, 0x0

    .line 74
    invoke-direct {v1, v3, v4, v2}, Lk72;-><init>(ILja2;I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p0, v1}, Lbl1;->F1(Lal1;)V

    .line 78
    .line 79
    .line 80
    iput-object v1, p0, La46;->b0:Lk72;

    .line 81
    .line 82
    new-instance v1, Ld91;

    .line 83
    .line 84
    new-instance v6, Ly36;

    .line 85
    .line 86
    const/4 v2, 0x1

    .line 87
    invoke-direct {v6, p0, v2}, Ly36;-><init>(La46;B)V

    .line 88
    .line 89
    .line 90
    move-object v5, p1

    .line 91
    move-object v2, p4

    .line 92
    move/from16 v4, p8

    .line 93
    .line 94
    move-object v3, v0

    .line 95
    invoke-direct/range {v1 .. v6}, Ld91;-><init>(Lip4;Lh46;ZLoe0;Ly36;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p0, v1}, Lbl1;->F1(Lal1;)V

    .line 99
    .line 100
    .line 101
    iput-object v1, p0, La46;->c0:Ld91;

    .line 102
    .line 103
    iget-object v0, p0, La46;->R:Laa4;

    .line 104
    .line 105
    new-instance v2, Lea4;

    .line 106
    .line 107
    invoke-direct {v2, v8, v0}, Lea4;-><init>(Lx94;Laa4;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p0, v2}, Lbl1;->F1(Lal1;)V

    .line 111
    .line 112
    .line 113
    new-instance v0, Lle0;

    .line 114
    .line 115
    invoke-direct {v0}, Lv04;-><init>()V

    .line 116
    .line 117
    .line 118
    iput-object v1, v0, Lle0;->w:Ld91;

    .line 119
    .line 120
    invoke-virtual {p0, v0}, Lbl1;->F1(Lal1;)V

    .line 121
    .line 122
    .line 123
    return-void
.end method


# virtual methods
.method public final J1(Lx3;Luu0;)Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, Lkh2;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/16 v2, 0x10

    .line 5
    .line 6
    iget-object p0, p0, La46;->Z:Lh46;

    .line 7
    .line 8
    invoke-direct {v0, p1, p0, v1, v2}, Lkh2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 9
    .line 10
    .line 11
    sget-object p1, Lp44;->j:Lp44;

    .line 12
    .line 13
    invoke-virtual {p0, p1, v0, p2}, Lh46;->g(Lp44;Lja2;Lfa1;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    sget-object p1, Lof1;->i:Lof1;

    .line 18
    .line 19
    if-ne p0, p1, :cond_0

    .line 20
    .line 21
    return-object p0

    .line 22
    :cond_0
    sget-object p0, Lxc7;->a:Lxc7;

    .line 23
    .line 24
    return-object p0
.end method

.method public final O1(J)V
    .locals 0

    .line 1
    return-void
.end method

.method public final P1(Liq1;)V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lv04;->v:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, La46;->R:Laa4;

    .line 7
    .line 8
    invoke-virtual {v0}, Laa4;->d()Lnf1;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    new-instance v1, Lb42;

    .line 13
    .line 14
    const/16 v2, 0x1c

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    invoke-direct {v1, p1, p0, v3, v2}, Lb42;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lea1;B)V

    .line 18
    .line 19
    .line 20
    const/4 p0, 0x3

    .line 21
    invoke-static {v0, v3, v3, v1, p0}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final Q0(Ly76;)V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lwq1;->A:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    iget-object v0, p0, La46;->S:Lt;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, La46;->T:Lk4;

    .line 11
    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    :cond_0
    new-instance v0, Lt;

    .line 15
    .line 16
    const/4 v2, 0x4

    .line 17
    invoke-direct {v0, p0, v2}, Lt;-><init>(Ljava/lang/Object;B)V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, La46;->S:Lt;

    .line 21
    .line 22
    new-instance v0, Lk4;

    .line 23
    .line 24
    invoke-direct {v0, p0, v1}, Lk4;-><init>(La46;Lea1;)V

    .line 25
    .line 26
    .line 27
    iput-object v0, p0, La46;->T:Lk4;

    .line 28
    .line 29
    :cond_1
    iget-object v0, p0, La46;->S:Lt;

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    sget-object v2, Lw76;->a:[Ld73;

    .line 34
    .line 35
    sget-object v2, Lk76;->d:Lx76;

    .line 36
    .line 37
    new-instance v3, Lp4;

    .line 38
    .line 39
    invoke-direct {v3, v1, v0}, Lp4;-><init>(Ljava/lang/String;Lra2;)V

    .line 40
    .line 41
    .line 42
    invoke-interface {p1, v2, v3}, Ly76;->a(Lx76;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_2
    iget-object p0, p0, La46;->T:Lk4;

    .line 46
    .line 47
    if-eqz p0, :cond_3

    .line 48
    .line 49
    sget-object v0, Lw76;->a:[Ld73;

    .line 50
    .line 51
    sget-object v0, Lk76;->e:Lx76;

    .line 52
    .line 53
    invoke-interface {p1, v0, p0}, Ly76;->a(Lx76;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    :cond_3
    return-void
.end method

.method public final X1()Z
    .locals 1

    .line 1
    iget-object p0, p0, La46;->Z:Lh46;

    .line 2
    .line 3
    iget-object v0, p0, Lh46;->a:Lb46;

    .line 4
    .line 5
    invoke-interface {v0}, Lb46;->b()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_1

    .line 10
    .line 11
    iget-object p0, p0, Lh46;->b:Lar4;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    if-eqz p0, :cond_0

    .line 15
    .line 16
    invoke-interface {p0}, Lar4;->c()Z

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    move p0, v0

    .line 22
    :goto_0
    if-nez p0, :cond_1

    .line 23
    .line 24
    return v0

    .line 25
    :cond_1
    const/4 p0, 0x1

    .line 26
    return p0
.end method

.method public final a2(Loe0;Lo32;Lj34;Lip4;Lar4;Lb46;ZZ)V
    .locals 6

    .line 1
    iget-boolean v3, p0, Lwq1;->A:Z

    .line 2
    .line 3
    if-eq v3, p7, :cond_0

    .line 4
    .line 5
    iget-object v3, p0, La46;->a0:Lx36;

    .line 6
    .line 7
    iput-boolean p7, v3, Lx36;->j:Z

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    iput-object v3, p0, La46;->S:Lt;

    .line 11
    .line 12
    iput-object v3, p0, La46;->T:Lk4;

    .line 13
    .line 14
    invoke-static {p0}, Lcc3;->J(Lo76;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    if-nez p2, :cond_1

    .line 18
    .line 19
    iget-object p2, p0, La46;->Y:Lpj1;

    .line 20
    .line 21
    :cond_1
    iget-object v3, p0, La46;->Z:Lh46;

    .line 22
    .line 23
    iget-object v4, v3, Lh46;->a:Lb46;

    .line 24
    .line 25
    invoke-static {v4, p6}, Lj23;->q(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    const/4 v5, 0x1

    .line 30
    if-nez v4, :cond_2

    .line 31
    .line 32
    iput-object p6, v3, Lh46;->a:Lb46;

    .line 33
    .line 34
    move v0, v5

    .line 35
    goto :goto_0

    .line 36
    :cond_2
    const/4 v0, 0x0

    .line 37
    :goto_0
    iput-object p5, v3, Lh46;->b:Lar4;

    .line 38
    .line 39
    iget-object p5, v3, Lh46;->d:Lip4;

    .line 40
    .line 41
    if-eq p5, p4, :cond_3

    .line 42
    .line 43
    iput-object p4, v3, Lh46;->d:Lip4;

    .line 44
    .line 45
    move-object p5, p4

    .line 46
    move v0, v5

    .line 47
    :cond_3
    iget-boolean v4, v3, Lh46;->e:Z

    .line 48
    .line 49
    if-eq v4, p8, :cond_4

    .line 50
    .line 51
    iput-boolean p8, v3, Lh46;->e:Z

    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_4
    move v5, v0

    .line 55
    :goto_1
    iput-object p2, v3, Lh46;->c:Lo32;

    .line 56
    .line 57
    iget-object p2, p0, La46;->R:Laa4;

    .line 58
    .line 59
    iput-object p2, v3, Lh46;->f:Laa4;

    .line 60
    .line 61
    iget-object p2, p0, La46;->c0:Ld91;

    .line 62
    .line 63
    iput-object p4, p2, Ld91;->w:Lip4;

    .line 64
    .line 65
    iput-boolean p8, p2, Ld91;->y:Z

    .line 66
    .line 67
    iput-object p1, p2, Ld91;->z:Loe0;

    .line 68
    .line 69
    sget-object v1, Li23;->a:Li;

    .line 70
    .line 71
    sget-object p1, Lip4;->i:Lip4;

    .line 72
    .line 73
    if-ne p5, p1, :cond_5

    .line 74
    .line 75
    :goto_2
    move-object v0, p0

    .line 76
    move-object v4, p1

    .line 77
    move-object v3, p3

    .line 78
    move v2, p7

    .line 79
    goto :goto_3

    .line 80
    :cond_5
    sget-object p1, Lip4;->j:Lip4;

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :goto_3
    invoke-virtual/range {v0 .. v5}, Lwq1;->Z1(Lfa2;ZLj34;Lip4;Z)V

    .line 84
    .line 85
    .line 86
    return-void
.end method

.method public final d()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lwq1;->S0()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, La46;->W:Ly14;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 13
    .line 14
    iput-object v1, v0, Lzi4;->b:Lkl1;

    .line 15
    .line 16
    :cond_0
    iget-object v0, p0, La46;->X:Lo77;

    .line 17
    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 25
    .line 26
    iput-object v1, v0, Lzi4;->b:Lkl1;

    .line 27
    .line 28
    :cond_1
    invoke-virtual {p0}, Lwq1;->S0()V

    .line 29
    .line 30
    .line 31
    iget-boolean v0, p0, Lv04;->v:Z

    .line 32
    .line 33
    if-nez v0, :cond_2

    .line 34
    .line 35
    return-void

    .line 36
    :cond_2
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    iget-object v0, v0, Laa3;->G:Lkl1;

    .line 41
    .line 42
    iget-object p0, p0, La46;->Y:Lpj1;

    .line 43
    .line 44
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    new-instance v1, Lf95;

    .line 48
    .line 49
    invoke-direct {v1, v0}, Lf95;-><init>(Lkl1;)V

    .line 50
    .line 51
    .line 52
    new-instance v0, Lii1;

    .line 53
    .line 54
    invoke-direct {v0, v1}, Lii1;-><init>(Lu32;)V

    .line 55
    .line 56
    .line 57
    iput-object v0, p0, Lpj1;->a:Lii1;

    .line 58
    .line 59
    return-void
.end method

.method public final e0(Ld15;Le15;J)V
    .locals 19

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v8, p1

    .line 4
    .line 5
    move-object/from16 v9, p2

    .line 6
    .line 7
    iget-object v0, v8, Ld15;->a:Ljava/util/List;

    .line 8
    .line 9
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    if-ge v3, v1, :cond_1

    .line 15
    .line 16
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    check-cast v4, Ll15;

    .line 21
    .line 22
    iget-object v5, v2, Lwq1;->z:Lfa2;

    .line 23
    .line 24
    iget-byte v4, v4, Ll15;->i:B

    .line 25
    .line 26
    new-instance v6, Lt15;

    .line 27
    .line 28
    invoke-direct {v6, v4}, Lt15;-><init>(I)V

    .line 29
    .line 30
    .line 31
    invoke-interface {v5, v6}, Lfa2;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    check-cast v4, Ljava/lang/Boolean;

    .line 36
    .line 37
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_0

    .line 42
    .line 43
    invoke-super/range {p0 .. p4}, Lwq1;->e0(Ld15;Le15;J)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    :goto_1
    iget-boolean v0, v2, Lwq1;->A:Z

    .line 51
    .line 52
    if-eqz v0, :cond_f

    .line 53
    .line 54
    iget-object v0, v2, Lwq1;->I:Lxb2;

    .line 55
    .line 56
    if-nez v0, :cond_2

    .line 57
    .line 58
    new-instance v0, Lxb2;

    .line 59
    .line 60
    invoke-direct {v0, v2}, Lxb2;-><init>(Lwb2;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v2, v0}, Lbl1;->F1(Lal1;)V

    .line 64
    .line 65
    .line 66
    iput-object v0, v2, Lwq1;->I:Lxb2;

    .line 67
    .line 68
    :cond_2
    const/16 v12, 0xf

    .line 69
    .line 70
    const/4 v13, 0x0

    .line 71
    const/4 v14, 0x6

    .line 72
    sget-object v15, Le15;->i:Le15;

    .line 73
    .line 74
    const/4 v0, 0x1

    .line 75
    if-ne v9, v15, :cond_4

    .line 76
    .line 77
    iget-byte v1, v8, Ld15;->f:B

    .line 78
    .line 79
    if-ne v1, v14, :cond_4

    .line 80
    .line 81
    iget-boolean v1, v2, La46;->U:Z

    .line 82
    .line 83
    if-nez v1, :cond_3

    .line 84
    .line 85
    new-instance v1, Ly14;

    .line 86
    .line 87
    new-instance v3, Lj5;

    .line 88
    .line 89
    invoke-static {v2}, Lgn;->a0(Lal1;)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 94
    .line 95
    .line 96
    move-result-object v4

    .line 97
    invoke-static {v4}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    const/4 v5, 0x2

    .line 102
    invoke-direct {v3, v4, v5}, Lj5;-><init>(Ljava/lang/Object;B)V

    .line 103
    .line 104
    .line 105
    move v4, v0

    .line 106
    new-instance v0, Lxz0;

    .line 107
    .line 108
    const/4 v6, 0x4

    .line 109
    const/4 v7, 0x3

    .line 110
    move-object v5, v1

    .line 111
    const/4 v1, 0x2

    .line 112
    move-object/from16 v16, v3

    .line 113
    .line 114
    const-class v3, La46;

    .line 115
    .line 116
    move/from16 v17, v4

    .line 117
    .line 118
    const-string v4, "onMouseWheelScrollStopped"

    .line 119
    .line 120
    move-object/from16 v18, v5

    .line 121
    .line 122
    const-string v5, "onMouseWheelScrollStopped-TH1AsA0(J)V"

    .line 123
    .line 124
    move-object/from16 v14, v16

    .line 125
    .line 126
    move/from16 v11, v17

    .line 127
    .line 128
    move-object/from16 v10, v18

    .line 129
    .line 130
    invoke-direct/range {v0 .. v7}, Lxz0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 131
    .line 132
    .line 133
    invoke-static {v2}, Lpm;->Q(Lal1;)Laa3;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 138
    .line 139
    iget-object v3, v2, La46;->Z:Lh46;

    .line 140
    .line 141
    invoke-direct {v10, v3, v14, v0, v1}, Ly14;-><init>(Lh46;Lj5;Lxz0;Lkl1;)V

    .line 142
    .line 143
    .line 144
    iput-object v10, v2, La46;->W:Ly14;

    .line 145
    .line 146
    iput-boolean v11, v2, La46;->U:Z

    .line 147
    .line 148
    goto :goto_2

    .line 149
    :cond_3
    move v11, v0

    .line 150
    :goto_2
    iget-object v0, v2, La46;->W:Ly14;

    .line 151
    .line 152
    if-eqz v0, :cond_5

    .line 153
    .line 154
    invoke-virtual {v2}, Lv04;->t1()Lnf1;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    iget-object v3, v0, Ly14;->h:Lal6;

    .line 159
    .line 160
    if-nez v3, :cond_5

    .line 161
    .line 162
    new-instance v3, Lg9;

    .line 163
    .line 164
    invoke-direct {v3, v0, v13, v12}, Lg9;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 165
    .line 166
    .line 167
    const/4 v4, 0x3

    .line 168
    invoke-static {v1, v13, v13, v3, v4}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 169
    .line 170
    .line 171
    move-result-object v1

    .line 172
    iput-object v1, v0, Ly14;->h:Lal6;

    .line 173
    .line 174
    goto :goto_3

    .line 175
    :cond_4
    move v11, v0

    .line 176
    :cond_5
    :goto_3
    iget-object v0, v2, La46;->W:Ly14;

    .line 177
    .line 178
    sget-object v10, Le15;->j:Le15;

    .line 179
    .line 180
    if-eqz v0, :cond_8

    .line 181
    .line 182
    iget-byte v1, v8, Ld15;->f:B

    .line 183
    .line 184
    const/4 v3, 0x6

    .line 185
    if-ne v1, v3, :cond_8

    .line 186
    .line 187
    iget-object v1, v8, Ld15;->a:Ljava/util/List;

    .line 188
    .line 189
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 190
    .line 191
    .line 192
    move-result v3

    .line 193
    const/4 v4, 0x0

    .line 194
    :goto_4
    if-ge v4, v3, :cond_6

    .line 195
    .line 196
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v5

    .line 200
    check-cast v5, Ll15;

    .line 201
    .line 202
    invoke-virtual {v5}, Ll15;->c()Z

    .line 203
    .line 204
    .line 205
    move-result v5

    .line 206
    if-nez v5, :cond_8

    .line 207
    .line 208
    add-int/lit8 v4, v4, 0x1

    .line 209
    .line 210
    goto :goto_4

    .line 211
    :cond_6
    if-ne v9, v15, :cond_7

    .line 212
    .line 213
    iget-boolean v1, v0, Lzi4;->c:Z

    .line 214
    .line 215
    if-eqz v1, :cond_7

    .line 216
    .line 217
    invoke-virtual {v0, v8}, Ly14;->g(Ld15;)Z

    .line 218
    .line 219
    .line 220
    invoke-static {v8}, Lzi4;->a(Ld15;)V

    .line 221
    .line 222
    .line 223
    :cond_7
    if-ne v9, v10, :cond_8

    .line 224
    .line 225
    iget-boolean v1, v0, Lzi4;->c:Z

    .line 226
    .line 227
    if-nez v1, :cond_8

    .line 228
    .line 229
    invoke-virtual {v0, v8}, Ly14;->g(Ld15;)Z

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    if-eqz v0, :cond_8

    .line 234
    .line 235
    invoke-static {v8}, Lzi4;->a(Ld15;)V

    .line 236
    .line 237
    .line 238
    :cond_8
    const/16 v14, 0xc

    .line 239
    .line 240
    const/16 v0, 0xb

    .line 241
    .line 242
    const/16 v1, 0xa

    .line 243
    .line 244
    if-ne v9, v15, :cond_b

    .line 245
    .line 246
    iget-byte v3, v8, Ld15;->f:B

    .line 247
    .line 248
    if-eq v3, v1, :cond_9

    .line 249
    .line 250
    if-eq v3, v0, :cond_9

    .line 251
    .line 252
    if-ne v3, v14, :cond_b

    .line 253
    .line 254
    :cond_9
    iget-boolean v3, v2, La46;->V:Z

    .line 255
    .line 256
    if-nez v3, :cond_a

    .line 257
    .line 258
    new-instance v3, Lo77;

    .line 259
    .line 260
    new-instance v0, Lxz0;

    .line 261
    .line 262
    const/4 v6, 0x4

    .line 263
    const/4 v7, 0x4

    .line 264
    const/4 v1, 0x2

    .line 265
    move-object/from16 v16, v3

    .line 266
    .line 267
    const-class v3, La46;

    .line 268
    .line 269
    const-string v4, "onTrackpadScrollStopped"

    .line 270
    .line 271
    const-string v5, "onTrackpadScrollStopped-TH1AsA0(J)V"

    .line 272
    .line 273
    move-object/from16 v14, v16

    .line 274
    .line 275
    invoke-direct/range {v0 .. v7}, Lxz0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 276
    .line 277
    .line 278
    invoke-static {v2}, Lpm;->Q(Lal1;)Laa3;

    .line 279
    .line 280
    .line 281
    move-result-object v1

    .line 282
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 283
    .line 284
    iget-object v3, v2, La46;->Z:Lh46;

    .line 285
    .line 286
    invoke-direct {v14, v3, v0, v1}, Lo77;-><init>(Lh46;Lxz0;Lkl1;)V

    .line 287
    .line 288
    .line 289
    iput-object v14, v2, La46;->X:Lo77;

    .line 290
    .line 291
    iput-boolean v11, v2, La46;->V:Z

    .line 292
    .line 293
    :cond_a
    iget-object v0, v2, La46;->X:Lo77;

    .line 294
    .line 295
    if-eqz v0, :cond_b

    .line 296
    .line 297
    invoke-virtual {v2}, Lv04;->t1()Lnf1;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    iget-object v3, v0, Lo77;->g:Lal6;

    .line 302
    .line 303
    if-nez v3, :cond_b

    .line 304
    .line 305
    new-instance v3, Luu0;

    .line 306
    .line 307
    invoke-direct {v3, v0, v13, v12}, Luu0;-><init>(Ljava/lang/Object;Lea1;B)V

    .line 308
    .line 309
    .line 310
    const/4 v4, 0x3

    .line 311
    invoke-static {v1, v13, v13, v3, v4}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 312
    .line 313
    .line 314
    move-result-object v1

    .line 315
    iput-object v1, v0, Lo77;->g:Lal6;

    .line 316
    .line 317
    :cond_b
    iget-object v0, v2, La46;->X:Lo77;

    .line 318
    .line 319
    if-eqz v0, :cond_f

    .line 320
    .line 321
    iget-byte v1, v8, Ld15;->f:B

    .line 322
    .line 323
    const/16 v5, 0xa

    .line 324
    .line 325
    if-eq v1, v5, :cond_c

    .line 326
    .line 327
    const/16 v4, 0xb

    .line 328
    .line 329
    if-eq v1, v4, :cond_c

    .line 330
    .line 331
    const/16 v2, 0xc

    .line 332
    .line 333
    if-ne v1, v2, :cond_f

    .line 334
    .line 335
    :cond_c
    iget-object v1, v8, Ld15;->a:Ljava/util/List;

    .line 336
    .line 337
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 338
    .line 339
    .line 340
    move-result v2

    .line 341
    const/4 v3, 0x0

    .line 342
    :goto_5
    if-ge v3, v2, :cond_d

    .line 343
    .line 344
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v4

    .line 348
    check-cast v4, Ll15;

    .line 349
    .line 350
    invoke-virtual {v4}, Ll15;->c()Z

    .line 351
    .line 352
    .line 353
    move-result v4

    .line 354
    if-nez v4, :cond_f

    .line 355
    .line 356
    add-int/lit8 v3, v3, 0x1

    .line 357
    .line 358
    goto :goto_5

    .line 359
    :cond_d
    if-ne v9, v15, :cond_e

    .line 360
    .line 361
    iget-boolean v1, v0, Lzi4;->c:Z

    .line 362
    .line 363
    if-eqz v1, :cond_e

    .line 364
    .line 365
    invoke-virtual {v0, v8}, Lo77;->e(Ld15;)Z

    .line 366
    .line 367
    .line 368
    invoke-static {v8}, Lzi4;->a(Ld15;)V

    .line 369
    .line 370
    .line 371
    :cond_e
    if-ne v9, v10, :cond_f

    .line 372
    .line 373
    iget-boolean v1, v0, Lzi4;->c:Z

    .line 374
    .line 375
    if-nez v1, :cond_f

    .line 376
    .line 377
    invoke-virtual {v0, v8}, Lo77;->e(Ld15;)Z

    .line 378
    .line 379
    .line 380
    move-result v0

    .line 381
    if-eqz v0, :cond_f

    .line 382
    .line 383
    invoke-static {v8}, Lzi4;->a(Ld15;)V

    .line 384
    .line 385
    .line 386
    :cond_f
    return-void
.end method

.method public final u1()Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final x(Landroid/view/KeyEvent;)Z
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final x1()V
    .locals 2

    .line 1
    iget-object v0, p0, La46;->W:Ly14;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 10
    .line 11
    iput-object v1, v0, Lzi4;->b:Lkl1;

    .line 12
    .line 13
    :cond_0
    iget-object v0, p0, La46;->X:Lo77;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v1, v1, Laa3;->G:Lkl1;

    .line 22
    .line 23
    iput-object v1, v0, Lzi4;->b:Lkl1;

    .line 24
    .line 25
    :cond_1
    iget-boolean v0, p0, Lv04;->v:Z

    .line 26
    .line 27
    if-nez v0, :cond_2

    .line 28
    .line 29
    return-void

    .line 30
    :cond_2
    invoke-static {p0}, Lpm;->Q(Lal1;)Laa3;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v0, v0, Laa3;->G:Lkl1;

    .line 35
    .line 36
    iget-object p0, p0, La46;->Y:Lpj1;

    .line 37
    .line 38
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    .line 40
    .line 41
    new-instance v1, Lf95;

    .line 42
    .line 43
    invoke-direct {v1, v0}, Lf95;-><init>(Lkl1;)V

    .line 44
    .line 45
    .line 46
    new-instance v0, Lii1;

    .line 47
    .line 48
    invoke-direct {v0, v1}, Lii1;-><init>(Lu32;)V

    .line 49
    .line 50
    .line 51
    iput-object v0, p0, Lpj1;->a:Lii1;

    .line 52
    .line 53
    return-void
.end method

.method public final y0(Landroid/view/KeyEvent;)Z
    .locals 10

    .line 1
    iget-boolean v0, p0, Lwq1;->A:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_5

    .line 5
    .line 6
    invoke-static {p1}, Lvj;->M(Landroid/view/KeyEvent;)J

    .line 7
    .line 8
    .line 9
    move-result-wide v2

    .line 10
    sget-wide v4, Li73;->D:J

    .line 11
    .line 12
    invoke-static {v2, v3, v4, v5}, Li73;->a(JJ)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    invoke-static {v0}, Lpm;->f(I)J

    .line 23
    .line 24
    .line 25
    move-result-wide v2

    .line 26
    sget-wide v4, Li73;->C:J

    .line 27
    .line 28
    invoke-static {v2, v3, v4, v5}, Li73;->a(JJ)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_5

    .line 33
    .line 34
    :cond_0
    invoke-static {p1}, Lvj;->N(Landroid/view/KeyEvent;)I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    const/4 v2, 0x2

    .line 39
    if-ne v0, v2, :cond_5

    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isCtrlPressed()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_5

    .line 46
    .line 47
    iget-object v0, p0, La46;->Z:Lh46;

    .line 48
    .line 49
    iget-object v0, v0, Lh46;->d:Lip4;

    .line 50
    .line 51
    sget-object v2, Lip4;->i:Lip4;

    .line 52
    .line 53
    const/4 v3, 0x1

    .line 54
    if-ne v0, v2, :cond_1

    .line 55
    .line 56
    move v1, v3

    .line 57
    :cond_1
    iget-object v0, p0, La46;->c0:Ld91;

    .line 58
    .line 59
    if-eqz v1, :cond_3

    .line 60
    .line 61
    invoke-virtual {v0}, Ld91;->G1()J

    .line 62
    .line 63
    .line 64
    move-result-wide v0

    .line 65
    const-wide v4, 0xffffffffL

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    and-long/2addr v0, v4

    .line 71
    long-to-int v0, v0

    .line 72
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    invoke-static {p1}, Lpm;->f(I)J

    .line 77
    .line 78
    .line 79
    move-result-wide v1

    .line 80
    sget-wide v6, Li73;->C:J

    .line 81
    .line 82
    invoke-static {v1, v2, v6, v7}, Li73;->a(JJ)Z

    .line 83
    .line 84
    .line 85
    move-result p1

    .line 86
    if-eqz p1, :cond_2

    .line 87
    .line 88
    int-to-float p1, v0

    .line 89
    goto :goto_0

    .line 90
    :cond_2
    int-to-float p1, v0

    .line 91
    neg-float p1, p1

    .line 92
    :goto_0
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 93
    .line 94
    .line 95
    move-result p1

    .line 96
    int-to-long v0, p1

    .line 97
    and-long/2addr v0, v4

    .line 98
    :goto_1
    move-wide v6, v0

    .line 99
    goto :goto_3

    .line 100
    :cond_3
    invoke-virtual {v0}, Ld91;->G1()J

    .line 101
    .line 102
    .line 103
    move-result-wide v0

    .line 104
    const/16 v2, 0x20

    .line 105
    .line 106
    shr-long/2addr v0, v2

    .line 107
    long-to-int v0, v0

    .line 108
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 109
    .line 110
    .line 111
    move-result p1

    .line 112
    invoke-static {p1}, Lpm;->f(I)J

    .line 113
    .line 114
    .line 115
    move-result-wide v4

    .line 116
    sget-wide v6, Li73;->C:J

    .line 117
    .line 118
    invoke-static {v4, v5, v6, v7}, Li73;->a(JJ)Z

    .line 119
    .line 120
    .line 121
    move-result p1

    .line 122
    if-eqz p1, :cond_4

    .line 123
    .line 124
    int-to-float p1, v0

    .line 125
    goto :goto_2

    .line 126
    :cond_4
    int-to-float p1, v0

    .line 127
    neg-float p1, p1

    .line 128
    :goto_2
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 129
    .line 130
    .line 131
    move-result p1

    .line 132
    int-to-long v0, p1

    .line 133
    shl-long/2addr v0, v2

    .line 134
    goto :goto_1

    .line 135
    :goto_3
    invoke-virtual {p0}, Lv04;->t1()Lnf1;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    new-instance v4, Lk4;

    .line 140
    .line 141
    const/4 v9, 0x1

    .line 142
    const/4 v8, 0x0

    .line 143
    move-object v5, p0

    .line 144
    invoke-direct/range {v4 .. v9}, Lk4;-><init>(La46;JLea1;B)V

    .line 145
    .line 146
    .line 147
    const/4 p0, 0x3

    .line 148
    invoke-static {p1, v8, v8, v4, p0}, Lpm;->E(Lnf1;Lb3;Lqf1;Lja2;I)Lal6;

    .line 149
    .line 150
    .line 151
    return v3

    .line 152
    :cond_5
    return v1
.end method
