.class public final synthetic Lb37;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# instance fields
.field public final synthetic i:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lb37;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte p0, p0, Lb37;->i:B

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p0, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    check-cast p1, Lu27;

    .line 8
    .line 9
    check-cast p2, Lib2;

    .line 10
    .line 11
    check-cast p3, Ljava/lang/Integer;

    .line 12
    .line 13
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const p0, -0x60d67ad0

    .line 20
    .line 21
    .line 22
    invoke-virtual {p2, p0}, Lib2;->g0(I)V

    .line 23
    .line 24
    .line 25
    invoke-static {p1, p2}, Lfs6;->h(Lu27;Lib2;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    invoke-virtual {p2, v0}, Lib2;->r(Z)V

    .line 30
    .line 31
    .line 32
    return-object p0

    .line 33
    :pswitch_0
    check-cast p1, Lw40;

    .line 34
    .line 35
    check-cast p2, Lib2;

    .line 36
    .line 37
    check-cast p3, Ljava/lang/Integer;

    .line 38
    .line 39
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    const p0, 0x1b3ec14f

    .line 46
    .line 47
    .line 48
    invoke-virtual {p2, p0}, Lib2;->g0(I)V

    .line 49
    .line 50
    .line 51
    invoke-static {p1, p2}, Lfs6;->d(Lw40;Lib2;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-virtual {p2, v0}, Lib2;->r(Z)V

    .line 56
    .line 57
    .line 58
    return-object p0

    .line 59
    :pswitch_1
    check-cast p1, Lyb7;

    .line 60
    .line 61
    check-cast p2, Lib2;

    .line 62
    .line 63
    check-cast p3, Ljava/lang/Integer;

    .line 64
    .line 65
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    const p0, 0x4532de0

    .line 72
    .line 73
    .line 74
    invoke-virtual {p2, p0}, Lib2;->g0(I)V

    .line 75
    .line 76
    .line 77
    invoke-static {p1, p2}, Lfs6;->j(Lyb7;Lib2;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    invoke-virtual {p2, v0}, Lib2;->r(Z)V

    .line 82
    .line 83
    .line 84
    return-object p0

    .line 85
    :pswitch_2
    check-cast p1, Lo27;

    .line 86
    .line 87
    check-cast p2, Lib2;

    .line 88
    .line 89
    check-cast p3, Ljava/lang/Integer;

    .line 90
    .line 91
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 92
    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    const p0, -0x784b7a49

    .line 98
    .line 99
    .line 100
    invoke-virtual {p2, p0}, Lib2;->g0(I)V

    .line 101
    .line 102
    .line 103
    invoke-static {p1, p2}, Lfs6;->f(Lo27;Lib2;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    invoke-virtual {p2, v0}, Lib2;->r(Z)V

    .line 108
    .line 109
    .line 110
    return-object p0

    .line 111
    :pswitch_3
    check-cast p1, Ls27;

    .line 112
    .line 113
    check-cast p2, Lib2;

    .line 114
    .line 115
    check-cast p3, Ljava/lang/Integer;

    .line 116
    .line 117
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 118
    .line 119
    .line 120
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    .line 122
    .line 123
    const p0, 0x24408440

    .line 124
    .line 125
    .line 126
    invoke-virtual {p2, p0}, Lib2;->g0(I)V

    .line 127
    .line 128
    .line 129
    invoke-static {p1, p2}, Lfs6;->g(Ls27;Lib2;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    invoke-virtual {p2, v0}, Lib2;->r(Z)V

    .line 134
    .line 135
    .line 136
    return-object p0

    .line 137
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
