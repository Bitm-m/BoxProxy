.class public final synthetic Lb10;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lu92;


# instance fields
.field public final synthetic i:Lw77;

.field public final synthetic j:La02;

.field public final synthetic k:Liz6;

.field public final synthetic l:Laj2;

.field public final synthetic m:Lur0;

.field public final synthetic n:Lkl1;

.field public final synthetic o:Z


# direct methods
.method public synthetic constructor <init>(Lw77;La02;Liz6;Laj2;Lur0;Lg10;Lkl1;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb10;->i:Lw77;

    .line 5
    .line 6
    iput-object p2, p0, Lb10;->j:La02;

    .line 7
    .line 8
    iput-object p3, p0, Lb10;->k:Liz6;

    .line 9
    .line 10
    iput-object p4, p0, Lb10;->l:Laj2;

    .line 11
    .line 12
    iput-object p5, p0, Lb10;->m:Lur0;

    .line 13
    .line 14
    iput-object p7, p0, Lb10;->n:Lkl1;

    .line 15
    .line 16
    iput-boolean p8, p0, Lb10;->o:Z

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, Lb10;->i:Lw77;

    .line 2
    .line 3
    iget-object v1, p0, Lb10;->j:La02;

    .line 4
    .line 5
    iput-object v1, v0, Lw77;->b:La02;

    .line 6
    .line 7
    iget-object v0, p0, Lb10;->k:Liz6;

    .line 8
    .line 9
    iget-boolean v1, p0, Lb10;->o:Z

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    iget-object v2, v0, Liz6;->d:Lj57;

    .line 14
    .line 15
    iget-object v2, v2, Lj57;->a:Lmw6;

    .line 16
    .line 17
    if-eqz v2, :cond_0

    .line 18
    .line 19
    iget-object v3, v2, Lmw6;->C:Lal6;

    .line 20
    .line 21
    if-eqz v3, :cond_0

    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-virtual {v3, v4}, Lz33;->c(Ljava/util/concurrent/CancellationException;)V

    .line 25
    .line 26
    .line 27
    iput-object v4, v2, Lmw6;->C:Lal6;

    .line 28
    .line 29
    :cond_0
    iget-object v2, p0, Lb10;->l:Laj2;

    .line 30
    .line 31
    iput-object v2, v0, Liz6;->j:Laj2;

    .line 32
    .line 33
    iget-object v2, p0, Lb10;->m:Lur0;

    .line 34
    .line 35
    iput-object v2, v0, Liz6;->g:Lur0;

    .line 36
    .line 37
    iget-object p0, p0, Lb10;->n:Lkl1;

    .line 38
    .line 39
    iput-object p0, v0, Liz6;->c:Lkl1;

    .line 40
    .line 41
    iput-boolean v1, v0, Liz6;->i:Z

    .line 42
    .line 43
    sget-object p0, Lxc7;->a:Lxc7;

    .line 44
    .line 45
    return-object p0
.end method
