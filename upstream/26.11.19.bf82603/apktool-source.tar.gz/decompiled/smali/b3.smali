.class public abstract Lb3;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lbf1;


# instance fields
.field public final i:Lcf1;


# direct methods
.method public constructor <init>(Lcf1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb3;->i:Lcf1;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public bridge A(Lcf1;)Ldf1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llm;->I(Lbf1;Lcf1;)Ldf1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final getKey()Lcf1;
    .locals 0

    .line 1
    iget-object p0, p0, Lb3;->i:Lcf1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final bridge k(Ldf1;)Ldf1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llm;->T(Lbf1;Ldf1;)Ldf1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge p(Lcf1;)Lbf1;
    .locals 0

    .line 1
    invoke-static {p0, p1}, Llm;->B(Lbf1;Lcf1;)Lbf1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final v(Lja2;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-interface {p1, p2, p0}, Lja2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
