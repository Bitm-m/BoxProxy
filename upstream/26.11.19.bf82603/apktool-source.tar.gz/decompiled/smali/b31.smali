.class public final Lb31;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lfj6;


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    return-void
.end method
