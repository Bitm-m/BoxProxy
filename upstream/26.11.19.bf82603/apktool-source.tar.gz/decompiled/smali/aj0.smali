.class public final Laj0;
.super Ljava/lang/Object;
.source "r8-map-id-9db6e13e3456b9032bb45828cb629dd15920b31c2e34f6c419876b223f1baa81"

# interfaces
.implements Lka2;


# static fields
.field public static final j:Laj0;

.field public static final k:Laj0;

.field public static final l:Laj0;

.field public static final m:Laj0;

.field public static final n:Laj0;

.field public static final o:Laj0;

.field public static final p:Laj0;

.field public static final q:Laj0;


# instance fields
.field public final synthetic i:B


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Laj0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Laj0;->j:Laj0;

    .line 8
    .line 9
    new-instance v0, Laj0;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Laj0;->k:Laj0;

    .line 16
    .line 17
    new-instance v0, Laj0;

    .line 18
    .line 19
    const/4 v1, 0x2

    .line 20
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Laj0;->l:Laj0;

    .line 24
    .line 25
    new-instance v0, Laj0;

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 29
    .line 30
    .line 31
    sput-object v0, Laj0;->m:Laj0;

    .line 32
    .line 33
    new-instance v0, Laj0;

    .line 34
    .line 35
    const/4 v1, 0x4

    .line 36
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Laj0;->n:Laj0;

    .line 40
    .line 41
    new-instance v0, Laj0;

    .line 42
    .line 43
    const/4 v1, 0x5

    .line 44
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 45
    .line 46
    .line 47
    sput-object v0, Laj0;->o:Laj0;

    .line 48
    .line 49
    new-instance v0, Laj0;

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 53
    .line 54
    .line 55
    sput-object v0, Laj0;->p:Laj0;

    .line 56
    .line 57
    new-instance v0, Laj0;

    .line 58
    .line 59
    const/4 v1, 0x7

    .line 60
    invoke-direct {v0, v1}, Laj0;-><init>(B)V

    .line 61
    .line 62
    .line 63
    sput-object v0, Laj0;->q:Laj0;

    .line 64
    .line 65
    return-void
.end method

.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Laj0;->i:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v0, v0, Laj0;->i:B

    .line 4
    .line 5
    sget-object v1, Laa3;->a0:Lg53;

    .line 6
    .line 7
    sget-object v2, Lt04;->i:Lt04;

    .line 8
    .line 9
    const/high16 v3, 0x41400000    # 12.0f

    .line 10
    .line 11
    const/high16 v4, 0x3f800000    # 1.0f

    .line 12
    .line 13
    const/4 v5, 0x3

    .line 14
    const/16 v6, 0x12

    .line 15
    .line 16
    const/4 v7, 0x4

    .line 17
    const/4 v8, 0x6

    .line 18
    sget-object v9, Lxc7;->a:Lxc7;

    .line 19
    .line 20
    const/4 v10, 0x0

    .line 21
    const/4 v11, 0x2

    .line 22
    const/4 v12, 0x1

    .line 23
    packed-switch v0, :pswitch_data_0

    .line 24
    .line 25
    .line 26
    move-object/from16 v0, p1

    .line 27
    .line 28
    check-cast v0, Lov0;

    .line 29
    .line 30
    iget-wide v0, v0, Lov0;->a:J

    .line 31
    .line 32
    move-object/from16 v2, p2

    .line 33
    .line 34
    check-cast v2, Lib2;

    .line 35
    .line 36
    move-object/from16 v3, p3

    .line 37
    .line 38
    check-cast v3, Ljava/lang/Number;

    .line 39
    .line 40
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    and-int/lit8 v5, v3, 0x6

    .line 45
    .line 46
    if-nez v5, :cond_1

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1}, Lib2;->f(J)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-nez v5, :cond_0

    .line 53
    .line 54
    move v7, v11

    .line 55
    :cond_0
    or-int/2addr v3, v7

    .line 56
    :cond_1
    and-int/lit8 v5, v3, 0x13

    .line 57
    .line 58
    if-eq v5, v6, :cond_2

    .line 59
    .line 60
    move v5, v12

    .line 61
    goto :goto_0

    .line 62
    :cond_2
    move v5, v10

    .line 63
    :goto_0
    and-int/2addr v3, v12

    .line 64
    invoke-virtual {v2, v3, v5}, Lib2;->X(IZ)Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_3

    .line 69
    .line 70
    new-instance v3, Lta3;

    .line 71
    .line 72
    invoke-direct {v3, v4, v12}, Lta3;-><init>(FZ)V

    .line 73
    .line 74
    .line 75
    const/high16 v4, 0x411c0000    # 9.75f

    .line 76
    .line 77
    invoke-static {v3, v4}, Lag6;->f(Lw04;F)Lw04;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    const/high16 v4, 0x409c0000    # 4.875f

    .line 82
    .line 83
    invoke-static {v4}, Lzo5;->a(F)Lxo5;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    invoke-static {v3, v4}, Lgn;->y(Lw04;Lma6;)Lw04;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    sget-object v4, Ld70;->V:Lus2;

    .line 92
    .line 93
    invoke-static {v3, v0, v1, v4}, Lhb;->D(Lw04;JLma6;)Lw04;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    invoke-static {v0, v2, v10}, Lnb0;->a(Lw04;Lib2;I)V

    .line 98
    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_3
    invoke-virtual {v2}, Lib2;->a0()V

    .line 102
    .line 103
    .line 104
    :goto_1
    return-object v9

    .line 105
    :pswitch_0
    move-object/from16 v0, p1

    .line 106
    .line 107
    check-cast v0, Lov0;

    .line 108
    .line 109
    iget-wide v0, v0, Lov0;->a:J

    .line 110
    .line 111
    move-object/from16 v2, p2

    .line 112
    .line 113
    check-cast v2, Lib2;

    .line 114
    .line 115
    move-object/from16 v5, p3

    .line 116
    .line 117
    check-cast v5, Ljava/lang/Number;

    .line 118
    .line 119
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v5

    .line 123
    and-int/lit8 v8, v5, 0x6

    .line 124
    .line 125
    if-nez v8, :cond_5

    .line 126
    .line 127
    invoke-virtual {v2, v0, v1}, Lib2;->f(J)Z

    .line 128
    .line 129
    .line 130
    move-result v8

    .line 131
    if-nez v8, :cond_4

    .line 132
    .line 133
    move v7, v11

    .line 134
    :cond_4
    or-int/2addr v5, v7

    .line 135
    :cond_5
    and-int/lit8 v7, v5, 0x13

    .line 136
    .line 137
    if-eq v7, v6, :cond_6

    .line 138
    .line 139
    move v6, v12

    .line 140
    goto :goto_2

    .line 141
    :cond_6
    move v6, v10

    .line 142
    :goto_2
    and-int/2addr v5, v12

    .line 143
    invoke-virtual {v2, v5, v6}, Lib2;->X(IZ)Z

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    if-eqz v5, :cond_7

    .line 148
    .line 149
    new-instance v5, Lta3;

    .line 150
    .line 151
    invoke-direct {v5, v4, v12}, Lta3;-><init>(FZ)V

    .line 152
    .line 153
    .line 154
    invoke-static {v5, v3}, Lag6;->f(Lw04;F)Lw04;

    .line 155
    .line 156
    .line 157
    move-result-object v3

    .line 158
    const/high16 v4, 0x40c00000    # 6.0f

    .line 159
    .line 160
    invoke-static {v4}, Lzo5;->a(F)Lxo5;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    invoke-static {v3, v4}, Lgn;->y(Lw04;Lma6;)Lw04;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    sget-object v4, Ld70;->V:Lus2;

    .line 169
    .line 170
    invoke-static {v3, v0, v1, v4}, Lhb;->D(Lw04;JLma6;)Lw04;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-static {v0, v2, v10}, Lnb0;->a(Lw04;Lib2;I)V

    .line 175
    .line 176
    .line 177
    goto :goto_3

    .line 178
    :cond_7
    invoke-virtual {v2}, Lib2;->a0()V

    .line 179
    .line 180
    .line 181
    :goto_3
    return-object v9

    .line 182
    :pswitch_1
    move-object/from16 v11, p1

    .line 183
    .line 184
    check-cast v11, Lwr1;

    .line 185
    .line 186
    move-object/from16 v0, p2

    .line 187
    .line 188
    check-cast v0, Lll4;

    .line 189
    .line 190
    iget-wide v0, v0, Lll4;->a:J

    .line 191
    .line 192
    move-object/from16 v2, p3

    .line 193
    .line 194
    check-cast v2, Lov0;

    .line 195
    .line 196
    iget-wide v12, v2, Lov0;->a:J

    .line 197
    .line 198
    sget-object v2, Log6;->a:Log6;

    .line 199
    .line 200
    const/high16 v2, 0x40800000    # 4.0f

    .line 201
    .line 202
    invoke-interface {v11, v2}, Lkl1;->L(F)F

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    const/high16 v3, 0x40000000    # 2.0f

    .line 207
    .line 208
    div-float v14, v2, v3

    .line 209
    .line 210
    const/16 v17, 0x0

    .line 211
    .line 212
    const/16 v18, 0x78

    .line 213
    .line 214
    move-wide v15, v0

    .line 215
    invoke-static/range {v11 .. v18}, Lwr1;->W(Lwr1;JFJLxr1;I)V

    .line 216
    .line 217
    .line 218
    return-object v9

    .line 219
    :pswitch_2
    const/4 v0, 0x0

    .line 220
    return-object v0

    .line 221
    :pswitch_3
    move-object/from16 v0, p1

    .line 222
    .line 223
    check-cast v0, Lov0;

    .line 224
    .line 225
    iget-wide v13, v0, Lov0;->a:J

    .line 226
    .line 227
    move-object/from16 v0, p2

    .line 228
    .line 229
    check-cast v0, Lib2;

    .line 230
    .line 231
    move-object/from16 v15, p3

    .line 232
    .line 233
    check-cast v15, Ljava/lang/Number;

    .line 234
    .line 235
    invoke-virtual {v15}, Ljava/lang/Number;->intValue()I

    .line 236
    .line 237
    .line 238
    move-result v15

    .line 239
    and-int/lit8 v16, v15, 0x6

    .line 240
    .line 241
    if-nez v16, :cond_9

    .line 242
    .line 243
    invoke-virtual {v0, v13, v14}, Lib2;->f(J)Z

    .line 244
    .line 245
    .line 246
    move-result v16

    .line 247
    if-nez v16, :cond_8

    .line 248
    .line 249
    move v7, v11

    .line 250
    :cond_8
    or-int/2addr v15, v7

    .line 251
    :cond_9
    and-int/lit8 v7, v15, 0x13

    .line 252
    .line 253
    if-eq v7, v6, :cond_a

    .line 254
    .line 255
    move v6, v12

    .line 256
    goto :goto_4

    .line 257
    :cond_a
    move v6, v10

    .line 258
    :goto_4
    and-int/2addr v15, v12

    .line 259
    invoke-virtual {v0, v15, v6}, Lib2;->X(IZ)Z

    .line 260
    .line 261
    .line 262
    move-result v6

    .line 263
    if-eqz v6, :cond_c

    .line 264
    .line 265
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 266
    .line 267
    .line 268
    move-result-object v2

    .line 269
    new-instance v4, Lvv;

    .line 270
    .line 271
    new-instance v6, La02;

    .line 272
    .line 273
    invoke-direct {v6, v5}, La02;-><init>(B)V

    .line 274
    .line 275
    .line 276
    invoke-direct {v4, v3, v12, v6}, Lvv;-><init>(FZLa02;)V

    .line 277
    .line 278
    .line 279
    sget-object v3, Lu6;->w:Lr20;

    .line 280
    .line 281
    invoke-static {v4, v3, v0, v8}, Lsx0;->a(Lwv;Lr20;Lib2;I)Lux0;

    .line 282
    .line 283
    .line 284
    move-result-object v3

    .line 285
    iget-wide v4, v0, Lib2;->T:J

    .line 286
    .line 287
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 288
    .line 289
    .line 290
    move-result v4

    .line 291
    invoke-virtual {v0}, Lib2;->m()Liz4;

    .line 292
    .line 293
    .line 294
    move-result-object v5

    .line 295
    invoke-static {v0, v2}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 296
    .line 297
    .line 298
    move-result-object v2

    .line 299
    sget-object v6, Lx11;->d:Lu6;

    .line 300
    .line 301
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 302
    .line 303
    .line 304
    invoke-virtual {v0}, Lib2;->j0()V

    .line 305
    .line 306
    .line 307
    iget-boolean v6, v0, Lib2;->S:Z

    .line 308
    .line 309
    if-eqz v6, :cond_b

    .line 310
    .line 311
    invoke-virtual {v0, v1}, Lib2;->l(Lu92;)V

    .line 312
    .line 313
    .line 314
    goto :goto_5

    .line 315
    :cond_b
    invoke-virtual {v0}, Lib2;->s0()V

    .line 316
    .line 317
    .line 318
    :goto_5
    sget-object v1, Lu6;->S:Lc11;

    .line 319
    .line 320
    invoke-static {v1, v0, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    sget-object v1, Lu6;->R:Lc11;

    .line 324
    .line 325
    invoke-static {v1, v0, v5}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 329
    .line 330
    .line 331
    move-result-object v1

    .line 332
    sget-object v3, Lu6;->T:Lc11;

    .line 333
    .line 334
    invoke-static {v3, v0, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 335
    .line 336
    .line 337
    invoke-static {v0}, Lwt6;->m(Lib2;)V

    .line 338
    .line 339
    .line 340
    sget-object v1, Lu6;->Q:Lc11;

    .line 341
    .line 342
    invoke-static {v1, v0, v2}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 343
    .line 344
    .line 345
    new-instance v1, Lud0;

    .line 346
    .line 347
    const/16 v2, 0xb

    .line 348
    .line 349
    invoke-direct {v1, v13, v14, v2}, Lud0;-><init>(JB)V

    .line 350
    .line 351
    .line 352
    const v2, -0x607d1333

    .line 353
    .line 354
    .line 355
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 356
    .line 357
    .line 358
    move-result-object v1

    .line 359
    new-instance v2, Lud0;

    .line 360
    .line 361
    const/16 v3, 0xc

    .line 362
    .line 363
    invoke-direct {v2, v13, v14, v3}, Lud0;-><init>(JB)V

    .line 364
    .line 365
    .line 366
    const v3, 0x4ae9c24e    # 7659815.0f

    .line 367
    .line 368
    .line 369
    invoke-static {v3, v2, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 370
    .line 371
    .line 372
    move-result-object v2

    .line 373
    new-array v3, v11, [Lja2;

    .line 374
    .line 375
    aput-object v1, v3, v10

    .line 376
    .line 377
    aput-object v2, v3, v12

    .line 378
    .line 379
    invoke-static {v3}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 380
    .line 381
    .line 382
    move-result-object v18

    .line 383
    const/16 v20, 0xc00

    .line 384
    .line 385
    const/16 v21, 0x17

    .line 386
    .line 387
    const/4 v15, 0x0

    .line 388
    const/16 v16, 0x0

    .line 389
    .line 390
    const/16 v17, 0x0

    .line 391
    .line 392
    move-object/from16 v19, v0

    .line 393
    .line 394
    invoke-static/range {v15 .. v21}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 395
    .line 396
    .line 397
    new-instance v1, Lud0;

    .line 398
    .line 399
    const/16 v2, 0xd

    .line 400
    .line 401
    invoke-direct {v1, v13, v14, v2}, Lud0;-><init>(JB)V

    .line 402
    .line 403
    .line 404
    const v2, -0x6768e7ca

    .line 405
    .line 406
    .line 407
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 408
    .line 409
    .line 410
    move-result-object v1

    .line 411
    new-instance v2, Lud0;

    .line 412
    .line 413
    const/16 v3, 0xe

    .line 414
    .line 415
    invoke-direct {v2, v13, v14, v3}, Lud0;-><init>(JB)V

    .line 416
    .line 417
    .line 418
    const v3, 0x59e9177

    .line 419
    .line 420
    .line 421
    invoke-static {v3, v2, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 422
    .line 423
    .line 424
    move-result-object v2

    .line 425
    new-array v3, v11, [Lja2;

    .line 426
    .line 427
    aput-object v1, v3, v10

    .line 428
    .line 429
    aput-object v2, v3, v12

    .line 430
    .line 431
    invoke-static {v3}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 432
    .line 433
    .line 434
    move-result-object v18

    .line 435
    invoke-static/range {v15 .. v21}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 436
    .line 437
    .line 438
    invoke-virtual {v0, v12}, Lib2;->r(Z)V

    .line 439
    .line 440
    .line 441
    goto :goto_6

    .line 442
    :cond_c
    invoke-virtual {v0}, Lib2;->a0()V

    .line 443
    .line 444
    .line 445
    :goto_6
    return-object v9

    .line 446
    :pswitch_4
    move-object/from16 v0, p1

    .line 447
    .line 448
    check-cast v0, Lov0;

    .line 449
    .line 450
    iget-wide v0, v0, Lov0;->a:J

    .line 451
    .line 452
    move-object/from16 v2, p2

    .line 453
    .line 454
    check-cast v2, Lib2;

    .line 455
    .line 456
    move-object/from16 v3, p3

    .line 457
    .line 458
    check-cast v3, Ljava/lang/Number;

    .line 459
    .line 460
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 461
    .line 462
    .line 463
    move-result v3

    .line 464
    and-int/lit8 v4, v3, 0x6

    .line 465
    .line 466
    if-nez v4, :cond_e

    .line 467
    .line 468
    invoke-virtual {v2, v0, v1}, Lib2;->f(J)Z

    .line 469
    .line 470
    .line 471
    move-result v4

    .line 472
    if-nez v4, :cond_d

    .line 473
    .line 474
    move v7, v11

    .line 475
    :cond_d
    or-int/2addr v3, v7

    .line 476
    :cond_e
    and-int/lit8 v4, v3, 0x13

    .line 477
    .line 478
    if-eq v4, v6, :cond_f

    .line 479
    .line 480
    move v4, v12

    .line 481
    goto :goto_7

    .line 482
    :cond_f
    move v4, v10

    .line 483
    :goto_7
    and-int/2addr v3, v12

    .line 484
    invoke-virtual {v2, v3, v4}, Lib2;->X(IZ)Z

    .line 485
    .line 486
    .line 487
    move-result v3

    .line 488
    if-eqz v3, :cond_10

    .line 489
    .line 490
    new-instance v3, Lud0;

    .line 491
    .line 492
    const/16 v4, 0x8

    .line 493
    .line 494
    invoke-direct {v3, v0, v1, v4}, Lud0;-><init>(JB)V

    .line 495
    .line 496
    .line 497
    const v4, -0x3e41e01

    .line 498
    .line 499
    .line 500
    invoke-static {v4, v3, v2}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 501
    .line 502
    .line 503
    move-result-object v3

    .line 504
    new-instance v4, Lud0;

    .line 505
    .line 506
    const/16 v6, 0x9

    .line 507
    .line 508
    invoke-direct {v4, v0, v1, v6}, Lud0;-><init>(JB)V

    .line 509
    .line 510
    .line 511
    const v6, 0x68520600

    .line 512
    .line 513
    .line 514
    invoke-static {v6, v4, v2}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 515
    .line 516
    .line 517
    move-result-object v4

    .line 518
    new-instance v6, Lud0;

    .line 519
    .line 520
    const/16 v7, 0xa

    .line 521
    .line 522
    invoke-direct {v6, v0, v1, v7}, Lud0;-><init>(JB)V

    .line 523
    .line 524
    .line 525
    const v0, -0x2b77d5ff

    .line 526
    .line 527
    .line 528
    invoke-static {v0, v6, v2}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 529
    .line 530
    .line 531
    move-result-object v0

    .line 532
    new-array v1, v5, [Lja2;

    .line 533
    .line 534
    aput-object v3, v1, v10

    .line 535
    .line 536
    aput-object v4, v1, v12

    .line 537
    .line 538
    aput-object v0, v1, v11

    .line 539
    .line 540
    invoke-static {v1}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 541
    .line 542
    .line 543
    move-result-object v16

    .line 544
    const/16 v18, 0xc00

    .line 545
    .line 546
    const/16 v19, 0x17

    .line 547
    .line 548
    const/4 v13, 0x0

    .line 549
    const/4 v14, 0x0

    .line 550
    const/4 v15, 0x0

    .line 551
    move-object/from16 v17, v2

    .line 552
    .line 553
    invoke-static/range {v13 .. v19}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 554
    .line 555
    .line 556
    goto :goto_8

    .line 557
    :cond_10
    move-object/from16 v17, v2

    .line 558
    .line 559
    invoke-virtual/range {v17 .. v17}, Lib2;->a0()V

    .line 560
    .line 561
    .line 562
    :goto_8
    return-object v9

    .line 563
    :pswitch_5
    move-object/from16 v0, p1

    .line 564
    .line 565
    check-cast v0, Lov0;

    .line 566
    .line 567
    iget-wide v13, v0, Lov0;->a:J

    .line 568
    .line 569
    move-object/from16 v0, p2

    .line 570
    .line 571
    check-cast v0, Lib2;

    .line 572
    .line 573
    move-object/from16 v3, p3

    .line 574
    .line 575
    check-cast v3, Ljava/lang/Number;

    .line 576
    .line 577
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 578
    .line 579
    .line 580
    move-result v3

    .line 581
    and-int/lit8 v15, v3, 0x6

    .line 582
    .line 583
    if-nez v15, :cond_12

    .line 584
    .line 585
    invoke-virtual {v0, v13, v14}, Lib2;->f(J)Z

    .line 586
    .line 587
    .line 588
    move-result v15

    .line 589
    if-nez v15, :cond_11

    .line 590
    .line 591
    move v7, v11

    .line 592
    :cond_11
    or-int/2addr v3, v7

    .line 593
    :cond_12
    and-int/lit8 v7, v3, 0x13

    .line 594
    .line 595
    if-eq v7, v6, :cond_13

    .line 596
    .line 597
    move v6, v12

    .line 598
    goto :goto_9

    .line 599
    :cond_13
    move v6, v10

    .line 600
    :goto_9
    and-int/2addr v3, v12

    .line 601
    invoke-virtual {v0, v3, v6}, Lib2;->X(IZ)Z

    .line 602
    .line 603
    .line 604
    move-result v3

    .line 605
    if-eqz v3, :cond_15

    .line 606
    .line 607
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 608
    .line 609
    .line 610
    move-result-object v3

    .line 611
    new-instance v6, Lvv;

    .line 612
    .line 613
    new-instance v7, La02;

    .line 614
    .line 615
    invoke-direct {v7, v5}, La02;-><init>(B)V

    .line 616
    .line 617
    .line 618
    const/high16 v5, 0x41200000    # 10.0f

    .line 619
    .line 620
    invoke-direct {v6, v5, v12, v7}, Lvv;-><init>(FZLa02;)V

    .line 621
    .line 622
    .line 623
    sget-object v5, Lu6;->w:Lr20;

    .line 624
    .line 625
    invoke-static {v6, v5, v0, v8}, Lsx0;->a(Lwv;Lr20;Lib2;I)Lux0;

    .line 626
    .line 627
    .line 628
    move-result-object v5

    .line 629
    iget-wide v6, v0, Lib2;->T:J

    .line 630
    .line 631
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 632
    .line 633
    .line 634
    move-result v6

    .line 635
    invoke-virtual {v0}, Lib2;->m()Liz4;

    .line 636
    .line 637
    .line 638
    move-result-object v7

    .line 639
    invoke-static {v0, v3}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 640
    .line 641
    .line 642
    move-result-object v3

    .line 643
    sget-object v8, Lx11;->d:Lu6;

    .line 644
    .line 645
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 646
    .line 647
    .line 648
    invoke-virtual {v0}, Lib2;->j0()V

    .line 649
    .line 650
    .line 651
    iget-boolean v8, v0, Lib2;->S:Z

    .line 652
    .line 653
    if-eqz v8, :cond_14

    .line 654
    .line 655
    invoke-virtual {v0, v1}, Lib2;->l(Lu92;)V

    .line 656
    .line 657
    .line 658
    goto :goto_a

    .line 659
    :cond_14
    invoke-virtual {v0}, Lib2;->s0()V

    .line 660
    .line 661
    .line 662
    :goto_a
    sget-object v1, Lu6;->S:Lc11;

    .line 663
    .line 664
    invoke-static {v1, v0, v5}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 665
    .line 666
    .line 667
    sget-object v1, Lu6;->R:Lc11;

    .line 668
    .line 669
    invoke-static {v1, v0, v7}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 670
    .line 671
    .line 672
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 673
    .line 674
    .line 675
    move-result-object v1

    .line 676
    sget-object v5, Lu6;->T:Lc11;

    .line 677
    .line 678
    invoke-static {v5, v0, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    invoke-static {v0}, Lwt6;->m(Lib2;)V

    .line 682
    .line 683
    .line 684
    sget-object v1, Lu6;->Q:Lc11;

    .line 685
    .line 686
    invoke-static {v1, v0, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 687
    .line 688
    .line 689
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 690
    .line 691
    .line 692
    move-result-object v15

    .line 693
    new-instance v1, Lm01;

    .line 694
    .line 695
    invoke-direct {v1, v13, v14, v10}, Lm01;-><init>(JB)V

    .line 696
    .line 697
    .line 698
    const v3, -0x6eafe5a2

    .line 699
    .line 700
    .line 701
    invoke-static {v3, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 702
    .line 703
    .line 704
    move-result-object v24

    .line 705
    const/16 v26, 0x6

    .line 706
    .line 707
    const/16 v27, 0x3fe

    .line 708
    .line 709
    const/16 v16, 0x0

    .line 710
    .line 711
    const/16 v17, 0x0

    .line 712
    .line 713
    const/16 v18, 0x0

    .line 714
    .line 715
    const/16 v19, 0x0

    .line 716
    .line 717
    const/16 v20, 0x0

    .line 718
    .line 719
    const/16 v21, 0x0

    .line 720
    .line 721
    const/16 v22, 0x0

    .line 722
    .line 723
    const/16 v23, 0x0

    .line 724
    .line 725
    move-object/from16 v25, v0

    .line 726
    .line 727
    invoke-static/range {v15 .. v27}, Ltw3;->a(Lw04;FLzt4;Ltj0;Lb45;ZLu92;Lu92;ZLyz0;Lib2;II)V

    .line 728
    .line 729
    .line 730
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 731
    .line 732
    .line 733
    move-result-object v15

    .line 734
    new-instance v1, Lm01;

    .line 735
    .line 736
    invoke-direct {v1, v13, v14, v12}, Lm01;-><init>(JB)V

    .line 737
    .line 738
    .line 739
    const v3, 0x2e120995

    .line 740
    .line 741
    .line 742
    invoke-static {v3, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 743
    .line 744
    .line 745
    move-result-object v24

    .line 746
    invoke-static/range {v15 .. v27}, Ltw3;->a(Lw04;FLzt4;Ltj0;Lb45;ZLu92;Lu92;ZLyz0;Lib2;II)V

    .line 747
    .line 748
    .line 749
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 750
    .line 751
    .line 752
    move-result-object v15

    .line 753
    new-instance v1, Lm01;

    .line 754
    .line 755
    invoke-direct {v1, v13, v14, v11}, Lm01;-><init>(JB)V

    .line 756
    .line 757
    .line 758
    const v2, 0x76af8256

    .line 759
    .line 760
    .line 761
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 762
    .line 763
    .line 764
    move-result-object v24

    .line 765
    invoke-static/range {v15 .. v27}, Ltw3;->a(Lw04;FLzt4;Ltj0;Lb45;ZLu92;Lu92;ZLyz0;Lib2;II)V

    .line 766
    .line 767
    .line 768
    invoke-virtual {v0, v12}, Lib2;->r(Z)V

    .line 769
    .line 770
    .line 771
    goto :goto_b

    .line 772
    :cond_15
    invoke-virtual {v0}, Lib2;->a0()V

    .line 773
    .line 774
    .line 775
    :goto_b
    return-object v9

    .line 776
    :pswitch_6
    move-object/from16 v0, p1

    .line 777
    .line 778
    check-cast v0, Lov0;

    .line 779
    .line 780
    iget-wide v13, v0, Lov0;->a:J

    .line 781
    .line 782
    move-object/from16 v0, p2

    .line 783
    .line 784
    check-cast v0, Lib2;

    .line 785
    .line 786
    move-object/from16 v15, p3

    .line 787
    .line 788
    check-cast v15, Ljava/lang/Number;

    .line 789
    .line 790
    invoke-virtual {v15}, Ljava/lang/Number;->intValue()I

    .line 791
    .line 792
    .line 793
    move-result v15

    .line 794
    and-int/lit8 v16, v15, 0x6

    .line 795
    .line 796
    if-nez v16, :cond_17

    .line 797
    .line 798
    invoke-virtual {v0, v13, v14}, Lib2;->f(J)Z

    .line 799
    .line 800
    .line 801
    move-result v16

    .line 802
    if-eqz v16, :cond_16

    .line 803
    .line 804
    move/from16 v16, v7

    .line 805
    .line 806
    goto :goto_c

    .line 807
    :cond_16
    move/from16 v16, v11

    .line 808
    .line 809
    :goto_c
    or-int v15, v15, v16

    .line 810
    .line 811
    :cond_17
    move/from16 p0, v10

    .line 812
    .line 813
    and-int/lit8 v10, v15, 0x13

    .line 814
    .line 815
    if-eq v10, v6, :cond_18

    .line 816
    .line 817
    move v6, v12

    .line 818
    goto :goto_d

    .line 819
    :cond_18
    move/from16 v6, p0

    .line 820
    .line 821
    :goto_d
    and-int/2addr v15, v12

    .line 822
    invoke-virtual {v0, v15, v6}, Lib2;->X(IZ)Z

    .line 823
    .line 824
    .line 825
    move-result v6

    .line 826
    if-eqz v6, :cond_1a

    .line 827
    .line 828
    invoke-static {v2, v4}, Lag6;->e(Lw04;F)Lw04;

    .line 829
    .line 830
    .line 831
    move-result-object v2

    .line 832
    new-instance v4, Lvv;

    .line 833
    .line 834
    new-instance v6, La02;

    .line 835
    .line 836
    invoke-direct {v6, v5}, La02;-><init>(B)V

    .line 837
    .line 838
    .line 839
    invoke-direct {v4, v3, v12, v6}, Lvv;-><init>(FZLa02;)V

    .line 840
    .line 841
    .line 842
    sget-object v3, Lu6;->w:Lr20;

    .line 843
    .line 844
    invoke-static {v4, v3, v0, v8}, Lsx0;->a(Lwv;Lr20;Lib2;I)Lux0;

    .line 845
    .line 846
    .line 847
    move-result-object v3

    .line 848
    move-object v4, v9

    .line 849
    iget-wide v8, v0, Lib2;->T:J

    .line 850
    .line 851
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 852
    .line 853
    .line 854
    move-result v8

    .line 855
    invoke-virtual {v0}, Lib2;->m()Liz4;

    .line 856
    .line 857
    .line 858
    move-result-object v9

    .line 859
    invoke-static {v0, v2}, Lnn;->J(Lib2;Lw04;)Lw04;

    .line 860
    .line 861
    .line 862
    move-result-object v2

    .line 863
    sget-object v10, Lx11;->d:Lu6;

    .line 864
    .line 865
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 866
    .line 867
    .line 868
    invoke-virtual {v0}, Lib2;->j0()V

    .line 869
    .line 870
    .line 871
    iget-boolean v10, v0, Lib2;->S:Z

    .line 872
    .line 873
    if-eqz v10, :cond_19

    .line 874
    .line 875
    invoke-virtual {v0, v1}, Lib2;->l(Lu92;)V

    .line 876
    .line 877
    .line 878
    goto :goto_e

    .line 879
    :cond_19
    invoke-virtual {v0}, Lib2;->s0()V

    .line 880
    .line 881
    .line 882
    :goto_e
    sget-object v1, Lu6;->S:Lc11;

    .line 883
    .line 884
    invoke-static {v1, v0, v3}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 885
    .line 886
    .line 887
    sget-object v1, Lu6;->R:Lc11;

    .line 888
    .line 889
    invoke-static {v1, v0, v9}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 890
    .line 891
    .line 892
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 893
    .line 894
    .line 895
    move-result-object v1

    .line 896
    sget-object v3, Lu6;->T:Lc11;

    .line 897
    .line 898
    invoke-static {v3, v0, v1}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 899
    .line 900
    .line 901
    invoke-static {v0}, Lwt6;->m(Lib2;)V

    .line 902
    .line 903
    .line 904
    sget-object v1, Lu6;->Q:Lc11;

    .line 905
    .line 906
    invoke-static {v1, v0, v2}, Lwt6;->p(Lja2;Lib2;Ljava/lang/Object;)V

    .line 907
    .line 908
    .line 909
    new-instance v1, Lud0;

    .line 910
    .line 911
    invoke-direct {v1, v13, v14, v12}, Lud0;-><init>(JB)V

    .line 912
    .line 913
    .line 914
    const v2, -0x22a30c57

    .line 915
    .line 916
    .line 917
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 918
    .line 919
    .line 920
    move-result-object v1

    .line 921
    new-instance v2, Lud0;

    .line 922
    .line 923
    invoke-direct {v2, v13, v14, v11}, Lud0;-><init>(JB)V

    .line 924
    .line 925
    .line 926
    const v3, 0x513b9bea

    .line 927
    .line 928
    .line 929
    invoke-static {v3, v2, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 930
    .line 931
    .line 932
    move-result-object v2

    .line 933
    new-array v3, v11, [Lja2;

    .line 934
    .line 935
    aput-object v1, v3, p0

    .line 936
    .line 937
    aput-object v2, v3, v12

    .line 938
    .line 939
    invoke-static {v3}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 940
    .line 941
    .line 942
    move-result-object v18

    .line 943
    const/16 v20, 0xc00

    .line 944
    .line 945
    const/16 v21, 0x17

    .line 946
    .line 947
    const/4 v15, 0x0

    .line 948
    const/16 v16, 0x0

    .line 949
    .line 950
    const/16 v17, 0x0

    .line 951
    .line 952
    move-object/from16 v19, v0

    .line 953
    .line 954
    invoke-static/range {v15 .. v21}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 955
    .line 956
    .line 957
    new-instance v1, Lud0;

    .line 958
    .line 959
    invoke-direct {v1, v13, v14, v5}, Lud0;-><init>(JB)V

    .line 960
    .line 961
    .line 962
    const v2, 0x944afd2

    .line 963
    .line 964
    .line 965
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 966
    .line 967
    .line 968
    move-result-object v1

    .line 969
    new-instance v2, Lud0;

    .line 970
    .line 971
    invoke-direct {v2, v13, v14, v7}, Lud0;-><init>(JB)V

    .line 972
    .line 973
    .line 974
    const v3, 0x1a4bd3

    .line 975
    .line 976
    .line 977
    invoke-static {v3, v2, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 978
    .line 979
    .line 980
    move-result-object v2

    .line 981
    new-instance v3, Lud0;

    .line 982
    .line 983
    const/4 v7, 0x5

    .line 984
    invoke-direct {v3, v13, v14, v7}, Lud0;-><init>(JB)V

    .line 985
    .line 986
    .line 987
    const v7, -0x910182c

    .line 988
    .line 989
    .line 990
    invoke-static {v7, v3, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 991
    .line 992
    .line 993
    move-result-object v3

    .line 994
    new-array v5, v5, [Lja2;

    .line 995
    .line 996
    aput-object v1, v5, p0

    .line 997
    .line 998
    aput-object v2, v5, v12

    .line 999
    .line 1000
    aput-object v3, v5, v11

    .line 1001
    .line 1002
    invoke-static {v5}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v18

    .line 1006
    invoke-static/range {v15 .. v21}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 1007
    .line 1008
    .line 1009
    new-instance v1, Lud0;

    .line 1010
    .line 1011
    const/4 v6, 0x6

    .line 1012
    invoke-direct {v1, v13, v14, v6}, Lud0;-><init>(JB)V

    .line 1013
    .line 1014
    .line 1015
    const v2, -0x46537fcf

    .line 1016
    .line 1017
    .line 1018
    invoke-static {v2, v1, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 1019
    .line 1020
    .line 1021
    move-result-object v1

    .line 1022
    new-instance v2, Lud0;

    .line 1023
    .line 1024
    const/4 v3, 0x7

    .line 1025
    invoke-direct {v2, v13, v14, v3}, Lud0;-><init>(JB)V

    .line 1026
    .line 1027
    .line 1028
    const v3, -0x4f7de3ce

    .line 1029
    .line 1030
    .line 1031
    invoke-static {v3, v2, v0}, Lmm;->X(ILra2;Lib2;)Lyz0;

    .line 1032
    .line 1033
    .line 1034
    move-result-object v2

    .line 1035
    new-array v3, v11, [Lja2;

    .line 1036
    .line 1037
    aput-object v1, v3, p0

    .line 1038
    .line 1039
    aput-object v2, v3, v12

    .line 1040
    .line 1041
    invoke-static {v3}, Lgn;->P([Ljava/lang/Object;)Ljava/util/List;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v18

    .line 1045
    invoke-static/range {v15 .. v21}, Lvq3;->d(Lw04;Ljava/lang/String;Lyz0;Ljava/util/List;Lib2;II)V

    .line 1046
    .line 1047
    .line 1048
    invoke-virtual {v0, v12}, Lib2;->r(Z)V

    .line 1049
    .line 1050
    .line 1051
    goto :goto_f

    .line 1052
    :cond_1a
    move-object v4, v9

    .line 1053
    invoke-virtual {v0}, Lib2;->a0()V

    .line 1054
    .line 1055
    .line 1056
    :goto_f
    return-object v4

    .line 1057
    :pswitch_7
    move-object v4, v9

    .line 1058
    move-object/from16 v0, p1

    .line 1059
    .line 1060
    check-cast v0, Ljava/lang/Throwable;

    .line 1061
    .line 1062
    move-object/from16 v1, p2

    .line 1063
    .line 1064
    check-cast v1, Lmm5;

    .line 1065
    .line 1066
    move-object/from16 v2, p3

    .line 1067
    .line 1068
    check-cast v2, Ldf1;

    .line 1069
    .line 1070
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1071
    .line 1072
    .line 1073
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1074
    .line 1075
    .line 1076
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1077
    .line 1078
    .line 1079
    invoke-virtual {v1}, Lmm5;->close()V

    .line 1080
    .line 1081
    .line 1082
    return-object v4

    .line 1083
    :pswitch_8
    move-object v4, v9

    .line 1084
    move-object/from16 v0, p1

    .line 1085
    .line 1086
    check-cast v0, Ljava/lang/Throwable;

    .line 1087
    .line 1088
    move-object/from16 v0, p2

    .line 1089
    .line 1090
    check-cast v0, Lmm5;

    .line 1091
    .line 1092
    move-object/from16 v1, p3

    .line 1093
    .line 1094
    check-cast v1, Ldf1;

    .line 1095
    .line 1096
    :try_start_0
    invoke-static {v0}, Lx35;->t(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1097
    .line 1098
    .line 1099
    :catch_0
    return-object v4

    .line 1100
    :catch_1
    move-exception v0

    .line 1101
    throw v0

    .line 1102
    nop

    .line 1103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
